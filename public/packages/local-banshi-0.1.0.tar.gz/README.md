# banshi（版式）

中文 Word 文档的版式模型，接到 Typst 上。Word 把这一套叫「中文版式」：页面设置与文档网格、
行盒与行距、中西文字体角色与字距、段落、表格——这个包把它们逐条矫正成 Word 排出来的样子，
数都是从 Word 导出的 PDF 上量的（量法与数记在各文件的注释里）。模板（学校、单位）只管自己的
样式表、词条与页面，版面的算法从这里取。

抽自 iota-hit（哈尔滨工业大学学位论文模板）@ 256102f，历史不迁；那边的 README 有各机制的来龙去脉，
本文件只记接口。

## 装

```sh
ln -s "$(pwd)" ~/Library/Application\ Support/typst/packages/local/banshi/0.1.0
```

```typst
#import "@local/banshi:0.1.0" as banshi
#import banshi.layout as _layout     // 整组当命名空间
#import banshi.fonts: zihao, songti  // 或只取几个名字
```

## 分组

按 Word 的框架切，每组一个模块（`lib.typ`），组内一个领域一个文件：

| 组 | Word 里的位置 | 里面有什么 |
|---|---|---|
| `layout` | 布局 → 页面设置 | `resolve`（版心、文档网格、行跨度的折算与并表：page-setup、merge、merge-page-setup；断行引擎 linebreaks）`rules`（落到 set page：页眉横线）`section`（一节的 set：版面加正文的字与段，页眉页脚 header: / footer: 作闭包传入）`chars`（字符网格一格的宽：ccwd、halfspace）`state` |
| `fonts` | 开始 → 字体对话框 | `presets`（六档中文字体预设、字号表 zihao、标定常数）`resolve`（fontset：字体表解析、角色 → 字体；fontset-state）`probes`（开机探针：真粗真斜、基线矫正量、run 边界丢字距）`fake`（伪粗伪斜）`tracking`（字符间距与 run 边界的补偿）`super-sub` `underline` `case`（英文大小写）`quotes`（引号用哪副字）`hant`（繁体档转字） |
| `paragraph` | 开始 → 段落对话框 | `linebox`（一条样式在网格下折成行盒、缩进、段前段后，纯函数）`latin`（纯西文行／段的行盒、断字、长词）`enter`（段落标记 ¶：paragraph-mark）`enum` `list`（编号与圆点列表悬不悬挂）`terms`（悬挂缩进的术语表）`group-heading` |
| `styles` | 开始 → 样式窗格 | `sheet`（验键、并局部字典：styles(base, local)）`state`（文档级那份与局部的栈：current-styles(default:)）`local`（new-styles / restore-styles）`rules`（一条样式落成 set / show）`body`（接到正文上：纯西文段换行盒）`parts`（按样式发的零件：段、居中行、行内公式、排不下的提示）`table`（Word 的表格模型：格里的行盒是一个网格行、内边距从线内沿量、内容居中、比版心宽的居中、表头首行注一格每页重算） |
| `equation` | 插入 → 公式 | 数学字体、国标字形、块级公式的行盒 |
| `msword` | | Word 的度量与判据：缇、EMU、厘米（cm：按 567 缇取整），汉字与西文的判别，run 的正则 |
| `content` | | 读内容：plain-text、折换行、按宽度折行、找标签与 metadata |
| `errors` | | 报错的措辞、「只印一次」 |
| `options` | 文件 → 选项 | 文档级开关：伪粗、伪斜、编号列表与圆点列表悬挂（options-overrides / option-of） |

## 一篇文档立起来

```typst
#import "@local/banshi:0.1.0" as banshi

#let layout = banshi.layout.page-setup(margin: (top: 2.5cm, rest: 2cm), line-pitch: 20pt, ...)
#let styles = banshi.styles.styles(default-styles, user-styles)   // body 必有，figure.table 是表格那一档
#let fonts  = banshi.fonts.fontset("windows")

#show: banshi.document.with(
  layout, styles, fonts,
  lang: "zh",
  options: banshi.options(fake-bold: auto, fake-italic: auto),
  header: () => [X 大学硕士学位论文],
  footer: () => context counter(page).display(),
  rules: doc => { show heading: ...; show figure.caption: ...; doc },   // 模板自己的规则
)
```

`document` 把三张表写进 state，再按定好的次序装 show 链：字的规则（`text-rules`）→ 模板的
`rules:` → 段的规则（`paragraph-rules`）→ 一节的 set（`layout.section`）→ 最内的 `baseline-rules`。
次序与理由在 `src/document.typ` 抬头；三截各自也公开。换版面的一节调 `banshi.layout.section`，
页眉页脚同样以 `header:` / `footer:` 递进去。

## 验

对拍件眼下仍在 iota-hit 的 `tests/`（`bash tests/run.sh`），Word 行为那一半待搬过来。
