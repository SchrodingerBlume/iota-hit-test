# banshi（版式）

banshi 在 Typst 中复现中文 Microsoft Word 文档的版式模型，包括页面设置、文档网格、
中西文字体槽、段落、公式和表格。学校或单位模板负责文档结构与具体样式，本包提供可复用的
换算和排版规则。

完整说明见 [`docs/manual.typ`](docs/manual.typ)。该手册由 banshi 自身排版，API 参考使用
[tidy](https://typst.app/universe/package/tidy/) 从源码的 `///` 注释生成。

## 安装

开发时可把仓库链接到 Typst 的本地包目录：

```sh
ln -s "$(pwd)" ~/Library/Application\ Support/typst/packages/local/banshi/0.1.0
```

```typ
#import "@local/banshi:0.1.0" as banshi
#import banshi.layout as layout
#import banshi.fonts: zihao, songti
```

## 文档入口

先准备页面设置、模板的默认样式表和字体表，再安装文档规则。下面的 `default-styles` 由上层模板
提供，字段说明见用户手册：

```typ
#import "@local/banshi:0.1.0" as banshi

#let page = banshi.layout.page-setup(
  paper: "a4",                       // Typst 的纸张名，或 (width:, height:)
  margin: (top: 2.54cm, bottom: 2.54cm, left: 3.18cm, right: 3.18cm),
  line-pitch: 20pt,
  char-pitch: 12pt,
  base-size: 12pt,
  grid: false,
  header: (shown: false),
  footer: (shown: false),
)

#let styles = banshi.styles.styles(default-styles, user-styles)
#let fonts = banshi.fonts.fontset("windows")

#show: banshi.document.with(page, styles, fonts)
```

`document` 按固定顺序安装文本、模板、段落、节和字体基线规则。模板自己的标题、题注与参考文献
规则通过 `rules:` 传入；新节使用 `banshi.layout.section`。

## 模块

| 模块 | 对应概念 |
|---|---|
| `layout` | Word 的节、页面设置、页眉页脚和文档网格 |
| `fonts` | 东亚/西文字体槽、字号、字距、基线校正与合成字形 |
| `paragraph` | 缩进、段前段后、行距、列表和空段 |
| `styles` | 样式表、局部样式、正文规则和表格规则 |
| `equation` | 数学字体、GB/T 3102.11 字形和块级公式行高 |
| `units` | twip、EMU、`w:spacing` 与 `w:charSpace` 的换算 |
| `content` | content 的文本提取、折行、标签和 metadata 查询 |

## 字体度量

版式按 Word 目标字体的度量计算，不随运行机器上的替代字体变化。每个字体角色保存：

- `single`：Word 单倍行高与字号的比值；
- `ascent`：上升部系数，配合固定项 `0.082pt` 使用。

已标定字体见 `src/fonts/presets.typ`。未收录的字体可传入家族名对应的度量，或直接提供
`(single: ..., ascent: ...)`。中文字体的值应从 Word 导出的 PDF 测量；西文字体可用
`tools/font-metrics.py` 读取 OpenType `hhea` 表。

## 验证

```sh
bash tests/run.sh
typst compile --root . docs/manual.typ docs/manual.pdf
```

回归测试覆盖版心、基线、文档网格、混排行、标点、纯西文行、缩进、公式、空段与字体替换。
