// banshi 在 Typst 中复现中文 Microsoft Word 文档的版式模型。
#import "src/document.typ": document, text-rules, paragraph-rules
#import "src/layout.typ"
#import "src/fonts.typ"
#import "src/paragraph.typ"
#import "src/styles.typ"
#import "src/equation.typ"
#import "src/units.typ"
#import "src/runs.typ"
#import "src/content.typ"
#import "src/errors.typ"
#import "src/options.typ": options
