// banshi（版式）：中文 Word 文档的版式模型。Word 把这一套叫「中文版式」——页面设置与
// 文档网格、行高与行距、中西文字体角色与字距、段落、表格；这个包把它们逐条接到 Typst 上，
// 数都是从 Word 排出来的 PDF 上量的。模板（学校、单位）只管自己的样式表、词条与页面，
// 版面的算法从这里取。抽自 iota-hit（哈工大学位论文模板），见 README。
//
// document(layout, styles, fontset, lang:, options:, header:, footer:, rules:, doc) 把一篇文档立起来
// （src/document.typ 说次序）；options(...) 造选项表。别的按目录分组导出，每组一个模块：
//
//   layout     页面设置：版心、文档网格、行跨度的折算与并表（page-setup、merge、merge-page-setup）、
//              set page（page-rules）、一节的 set（section）、字符网格的字宽（ccwd）
//   fonts      字体：中文字体集与角色表（presets、resolve）、开机探针（probes）、伪粗伪斜
//              （fake）、run 边界的字距补偿（tracking）、上下标、下划线、英文大小写、引号、
//              繁简
//   paragraph  段落：「缩进和间距」的折算（spacing、indent、tracking-of）、纯西文段（latin）、断字与长词
//              （hyphenate）、段落标记 ¶（enter：paragraph-mark）、编号列表与
//              圆点列表（enum、list）、词条列表（terms）
//   styles     样式表：验键与并表（sheet）、文档级与局部的 state（state、local）、一档样式
//              落成 set／show（rules、body）、部件用的段与行（parts）、Word 的表格模型（table）
//   equation   公式：字体、国标字形、块级公式的行高
//   units      Word 存盘的单位：缇（twips）、EMU、run 的字距、charSpace
//   runs       run：按码位判文种、切 run 的正则、字体角色的标签
//   content    读内容：取纯文本、折换行、找标签与 metadata
//   errors     报错的措辞与「只印一次」
#import "src/document.typ": document, text-rules, paragraph-rules
#import "src/layout.typ"
#import "src/fonts.typ"
#import "src/paragraph.typ"
#import "src/styles.typ"
#import "src/equation.typ"
#import "src/units.typ"
#import "src/runs.typ"
#import "src/content.typ"
#import "src/errors.typ"
#import "src/options.typ": options
