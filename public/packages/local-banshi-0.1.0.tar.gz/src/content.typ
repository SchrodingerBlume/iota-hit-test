// content 上的操作：压成字面文字（plain-text，Typst 内部同名）、折掉手动换行
// （fold-linebreaks）、按量出来的宽度折成纯文本的行（wrap-lines）、挖挂着的标签（label-of）、
// 挖埋在里面的 metadata（metadata-of）、判空（blank）、裁掉末尾的空白（trim-tail）。
// 判文种（有没有汉字、是不是纯西文）不在这儿，见 src/msword.typ。
#import "./msword.typ": has-cjk

// 标题里手动换的行折掉。
//
// *markup 里的「\ 」是两个元素*：linebreak 之后还跟着一个 space（实测
// `[研究\ 与实现]` ＝ sequence([研究], linebreak(), [ ], [与实现])，写成行末的「\」
// 加换行也一样）。只把 linebreak 折掉，那个空格就留在了字里——先前目录、页眉、书签、
// plain-text() 读出来的都是「研究 与实现」，中间多一个空格；范例的目录条目是直接接上的。
// 汉字之间的换行折掉不留空格，西文之间折成一个空格（「Design of the Thing\ and」
// 本来就该有空格）：看换行两边紧挨着的字，任一边是汉字就不留。
//
// *只折 justify: false 的*：#tocbreak() 换出来的那一种带 justify: true，目录要它换行，
// 见 iota-hit/src/heading/heading.typ 的 replace-tocbreak。
// 收内容或内容数组（sequence 的 children），返回同类型；不进 styled / 别的元素的里面。
#let _edge(c, last) = {
  // 元素两头的那个字（用来判两边是不是汉字）；空串＝看不出来
  if c == none { return "" }
  if type(c) == str { return if c == "" { "" } else if last { c.clusters().last() } else { c.clusters().first() } }
  if type(c) != content { return "" }
  if c.func() == [ ].func() { return " " }
  if c.has("text") and type(c.text) == str { return _edge(c.text, last) }
  if c.has("children") {
    let ch = c.children
    return if ch.len() == 0 { "" } else { _edge(if last { ch.last() } else { ch.first() }, last) }
  }
  if c.has("child") { return _edge(c.child, last) }
  if c.has("body") { return _edge(c.body, last) }
  ""
}
#let _is-space(c) = type(c) == content and c.func() == [ ].func()
#let _is-fold(c) = (
  type(c) == content and c.func() == linebreak and not c.at("justify", default: false)
)
#let fold-linebreaks(c) = {
  if type(c) == array {
    let out = ()
    let i = 0
    while i < c.len() {
      let x = c.at(i)
      if not _is-fold(x) { out.push(fold-linebreaks(x)); i += 1; continue }
      // 折掉换行；两侧的 space 也吃掉，再按两边的字决定补不补一个空格
      while out.len() > 0 and _is-space(out.last()) { let _ = out.pop() }
      i += 1
      while i < c.len() and _is-space(c.at(i)) { i += 1 }
      let before = _edge(if out.len() > 0 { out.last() } else { none }, true)
      let after = _edge(if i < c.len() { c.at(i) } else { none }, false)
      if before != "" and after != "" and not has-cjk(before) and not has-cjk(after) { out.push([ ]) }
    }
    return out
  }
  if type(c) != content { return c }
  if c.has("children") { return fold-linebreaks(c.children).join() }
  c
}

#let plain-text(c) = {
  if c == none { return "" }
  if type(c) == str { return c }
  if type(c) != content { return "" }
  // *markup 里的空格自成一个元素*（[a b].children ＝ text, space, text），
  // 它一个字段都没有，落到最后那一行就成了空串——「School (Department)」读出来
  // 是「School(Department)」，报告首页那一格照着排，空格就没了。空格是字面文字
  // 的一部分，读出来就得有
  if c.func() == [ ].func() { return " " }
  // *智能引号也是字面文字。* 它是个 smartquote 元素，没有 text 字段，
  // 先前落到最后那一行成了空串——「Bachelor's Thesis」读出来是「Bachelors
  // Thesis」，封面照它折行就把撇号折没了，书签与英文标题的大小写也一样丢。
  // 方向由排版时的上下文定（见 src/fonts/quotes.typ），这里取闭合那一个：
  // 撇号就是它，成对的引号读出来是左右哪一个不影响谁在用这个函数
  if c.func() == smartquote { return if c.double { "”" } else { "’" } }
  // *text 这一格不一定是字符串*——有的元素把内容放在同名的字段里
  // （实测走到过一个 text 是内容的元素，has-cjk 拿到内容序列当场炸）。
  if c.has("text") {
    let t = c.text
    return if type(t) == str { t } else { plain-text(t) }
  }
  // *空的 children 要单独接住*：Typst 里 ().join("") 给的是 none，不是 ""，
  // 上一层再 join 一次就把整串变成了内容序列，has-cjk 当场炸（element sequence
  // has no method `clusters`）。
  // *styled 元素（set 过的一段内容）要往 child 里走。* 词条页标题的正文槽就是
  // 一个 styled(child: [Contents])——页眉拿它判「这一行是不是纯西文」，不进去就读到
  // 空串，纯西文的页眉抬不上去。
  if c.has("child") { return plain-text(c.child) }
  if c.has("children") {
    // 手动换行折掉再读，见 fold-linebreaks
    let parts = fold-linebreaks(c.children).map(plain-text)
    return if parts.len() == 0 { "" } else { parts.join("") }
  }
  if c.has("body") { return plain-text(c.body) }
  ""
}


// *按量出来的宽度折行*，交回一串纯文本的行。要在 context 里调。
//
// 表单上那几处「填进去的字长了要折行」都用它：深圳本科封面题目那一格、硕博六格
// 的值。*自己折不交给 Typst*，因为折出来的每一行还要各自补白到线的右端／
// 在格子里居中，Typst 折完之后我们看不见断在哪儿。
//
// *断在空格处*（西文），一个词长到整行都装不下才逐字断——与 Word 同。
// 汉字之间没有空格，逐字断正是它该有的样子。
//
// *每一行都 trim。* 行末留着那个空格，居中时它会算进行宽，整行往左偏半个
// 空格（英文档下深圳本科封面的校名折行后偏了 4.05，正是半个小初空格）。
//
// *居中的行也要自己折*：Typst 自然折行时把行末那个空格算进行宽，整行因此
// 偏半个空格——同一段文字改用显式 linebreak 排，两行的中线才落在一处（实测
// 24pt 下偏 3.00，正是半个空格；英文档下深圳本科封面的小初校名偏 4.05）。
//
// room 给的是这一行能用的宽，size 是量的时候用的字号（那几处的字号与当前生效的
// 不同，量错就折错）。first 只在第一行与后面几行宽度不同时给。measure-as 是
// 「按什么样子量」——封面的校名压着 90% 的字宽还带字距，照原样量就折早了。
#let wrap-lines(body, room, size: auto, first: auto, measure-as: auto) = {
  let text-of = if type(body) == str { body } else { plain-text(body) }
  if text-of == none { return () }
  let text-of = text-of.trim()
  if text-of == "" { return () }
  let sized(t) = if measure-as != auto {
    (measure-as)(t)
  } else if size == auto { text(t) } else { text(size: size, t) }
  let fits(t, w) = measure(sized(t)).width <= w
  let first-room = if first == auto { room } else { first }
  let lines = ()
  let cur = ""
  let now = first-room
  for word in text-of.split(" ") {
    let next = if cur == "" { word } else { cur + " " + word }
    if fits(next, now) {
      cur = next
      continue
    }
    if cur != "" {
      lines.push(cur)
      cur = ""
      now = room
    }
    // 这一个词自己就装不下：逐字断
    let rest = word
    while not fits(rest, now) and rest.clusters().len() > 1 {
      let take = ""
      for c in rest.clusters() {
        if not fits(take + c, now) { break }
        take += c
      }
      if take == "" { break }
      lines.push(take)
      now = room
      rest = rest.slice(take.len())
    }
    cur = rest
  }
  if cur != "" { lines.push(cur) }
  lines.map(l => l.trim())
}

// 内容里挂着的*第一个*标签。
//
// 分图题要靠它：用户写 #subs([静压 <fig:static>], …) 时，那个标签挂在会被
// title-of 摘掉的元素上（写成 #en[Aerostatic]<1> 的话就挂在 #en 那个 metadata
// 上），不把它捞出来重新安置，标签根本进不了文档，@fig:static 报的是
// 「label does not exist in the document」。
#let label-of(c) = {
  if type(c) != content { return none }
  let l = c.at("label", default: none)
  if l != none { return l }
  if c.has("children") {
    for k in c.children {
      let r = label-of(k)
      if r != none { return r }
    }
  }
  if c.has("body") { return label-of(c.body) }
  none
}

// 往内容里埋 metadata 当记号。*一种机制几个用户。* Typst 的 heading / figure 不收自定义
// 字段，想给某一个元素附加信息（这一章的英文名、这一章要不要右翻页、图题里的分图题），办法
// 是往它的*正文*里塞一个 metadata——不显示、不占位、也不造 text run 边界（实测 18pt 加 1pt
// 字距的居中标题，塞与不塞逐字步进都是 19.0、左右缘都是 162.500 / 237.500），而 show
// 规则拿到 it.body 就能挖出来。塞的函数各住各的主人那儿（en / zh 在 iota-hit/src/terms/lang.typ，
// openright / leveled / tocbreak 在 iota-hit/src/heading/heading.typ，subs / continued 在
// iota-hit/src/figure/caption.typ，algorithm 在 iota-hit/src/figure/kinds.typ）；挖的机制只有这一个。
//
// 从一段内容里挖出某个记号。一路往下找，头一个算数——一个标题不该有第二个。
//
// *返回的是数组，不是值本身。* 记号的值可能就是 false（openright 那一个），
// 拿 none 当「没找到」会与它撞。空数组表示没找到，单元素数组表示找到了。
#let metadata-of(c, key) = {
  if type(c) != content { return () }
  if c.func() == metadata {
    let v = c.value
    return if type(v) == dictionary and key in v { (v.at(key),) } else { () }
  }
  if c.has("children") {
    for x in c.children {
      let r = metadata-of(x, key)
      if r.len() != 0 { return r }
    }
  }
  if c.has("body") { return metadata-of(c.body, key) }
  // styled 元素（set 过的一段）：记号可能在它的 child 里，同 plain-text
  if c.has("child") { return metadata-of(c.child, key) }
  ()
}

// 这份记号里是不是什么都没有。*#en[] 与没写 #en 是一回事*——作者敲了壳子
// 忘了填，两种都该走回落那条路。分不开的代价实测过：英文目录里那一条正身是
// *整个空白*的（「Chapter 1 …………… 1」），连警告都够不着——两句警告挂在汉字
// 占比上，而空串的占比是 0。图表题注同理：双语题注会多排一行空的英文名。
//
// 空的形态不止一种：#en[] 是空序列，#en[ ] 削到底只剩一个空格，#en[#label] 这
// 类只剩 metadata。递归下去逐个判，全空才算空。
#let blank(c) = {
  if c == none { return true }
  if type(c) != content { return false }
  if c.func() == metadata or _is-space(c) { return true }
  if c.has("text") { return c.text.trim() == "" }
  if c.has("children") { return c.children.all(blank) }
  if c.has("body") { return blank(c.body) }
  false
}

// 把内容末尾的空白与 metadata 裁掉。
//
// *给目录条目用。*「= 绪论 #en[…]」里那个字面空格会跟进 heading.body，
// 排到目录里就落在标题与点线之间——实测点线前多出一个空格。右端不受影响
// （点线是填到制表位的），但点的相位偏了，Word 那边没有这个空格。
//
// *字面空格是 space 元素，不是 text。*实测 [ ].func() 给的是 space，
// 它没有 text 字段——按 has("text") 判会漏掉，那正是这个空格躲过第一版
// 裁剪的原因。所以拿 [ ].func() 当样本比对。

#let trim-tail(c) = {
  if type(c) != content or not c.has("children") { return c }
  let ks = c.children
  while ks.len() > 0 {
    let last = ks.last()
    let blank = (
      last.func() == metadata
        or _is-space(last)
        or (last.has("text") and last.text.trim() == "")
    )
    if not blank { break }
    ks = ks.slice(0, -1)
  }
  // *没削掉东西就原样交回*：重拼一遍等于重发，span（源码位置）跟着换人，
  // tinymist 从预览跳回源码时会落进本文件。同一条道理见 src/fonts/case.typ
  if ks.len() == 0 { none } else if ks.len() == c.children.len() { c } else { ks.join() }
}
