// 一篇文档立起来：三张表落进 state、通用的 show 链按定好的次序装上。
#import "./paragraph/spacing.typ": font-zh-of
#import "./layout/resolve.typ" as _layout
#import "./layout/state.typ": page-setup-state
#import "./layout/section.typ": section
#import "./fonts/resolve.typ" as _fonts
#import "./fonts/fake.typ" as _fake
#import "./fonts/tracking.typ": tracking-rules
#import "./fonts/super-sub.typ": super-sub-rules
#import "./fonts/underline.typ": underline-rules
#import "./fonts/quotes.typ": quote-rules, unit-rules
#import "./fonts/hant.typ": hant-rules
#import "./equation.typ": math-rules
#import "./styles/state.typ": styles-state
#import "./styles/body.typ": body-rules
#import "./styles/figure.typ": figure-rules
#import "./styles/headings.typ" as _headings
#import "./styles/captions.typ" as _captions
#import "./paragraph/enum.typ": enum-rules
#import "./paragraph/list.typ": list-rules
#import "./options.typ" as _options

// 字的规则。
/// 字的规则：断字、贪心断行、正文字体与语言、代码字体、繁简、引号、单位、数学、
/// 字距补偿、上下标、下划线与伪粗。`document` 把它装在模板规则之前。
/// -> content
#let text-rules(fontset, styles, lang: "zh", doc) = {
  let f = fontset
  let body = styles.body
  let family = f.at(font-zh-of(body))
  set text(hyphenate: false)
  set par(linebreaks: if par.linebreaks == auto { "simple" } else { par.linebreaks })
  set text(font: family, lang: lang, region: "cn")
  show raw: set text(font: f.mono)
  show raw: set text(.._fonts.mono-text-em(body.size, f.serif, f.mono))
  show raw.where(block: true): it => block(width: 100%, it)
  show: hant-rules.with(f)
  show: quote-rules.with(latin-font: f.serif)
  show: unit-rules
  show: math-rules.with(font: f.math, cjk: f.families.songti)
  show: if _layout.engine-linebreaks == none { tracking-rules } else { it => it }
  show: super-sub-rules
  show: underline-rules
  show: _fake.rules
  doc
}

// 段的规则。
/// 段的规则：表格字号、正文的西文片段与纯西文行、编号与项目符号列表。
/// `document` 把它装在模板规则之后。
/// -> content
#let paragraph-rules(layout, styles, lang: "zh", doc) = {
  show table: set text(size: styles.figure.table.size)
  show: body-rules.with(layout, styles.body)
  show: enum-rules.with(lang)
  show: list-rules
  doc
}

/// 文档入口。初始化页面设置、样式、字体和选项状态，然后按固定顺序安装文字、图表、
/// 模板、段落、节与字体基线规则。通常一篇文档只安装一次。
///
/// - `layout`：`layout.page-setup` 的结果。
/// - `styles`：`styles.styles` 合并后的完整样式表，至少含 `body`。
/// - `fontset`：`fonts.fontset` 的结果。
/// - `header`、`footer`：逐页求值的零参数函数；传 `none` 不排。
/// - `rules`：模板自己的 show 规则。标题、题注和参考文献规则应从这里安装。
/// - `options`：`options(...)` 返回的文档选项。
///
/// ```typ
/// #show: banshi.document.with(
///   layout, styles, fonts,
///   header: () => [论文题目],
///   footer: () => context counter(page).display(),
///   rules: template-rules,
/// )
/// ```
/// -> content
#let document(
  layout,                 // 折好的页面设置（page-setup(...) 的结果）
  styles,                 // 解好的样式表（styles(base, local) 的结果；body 必有，figure.table 是表格那一档）
  fontset,                // 解好的字体表（fontset(...) 的结果）
  lang: "zh",
  options: (:),           // options(...) 的结果：伪粗、伪斜、列表悬挂
  header: none,           // 页眉页脚：逐页调用的函数，none ＝ 不排。递给 section
  footer: none,
  headings: none,         // 标题的关系表（headings.typ）；none ＝ 不装标题规则
  captions: none,         // 题注的关系表（captions.typ）；none ＝ 不装题注规则
  rules: doc => doc,      // 模板自己的 show 链
  doc,
) = context {
  page-setup-state.update(layout)
  styles-state.update(styles)
  _fonts.fontset-state.update(fontset)
  _fonts.probes.update(_fonts.probe-all(fontset.families))
  _fonts.boundary-probe.update(_fonts.probe-boundary())
  _options.options-overrides(options)
  show: text-rules.with(fontset, styles, lang: lang)
  // 图表块的三段空当：在模板的规则之前，模板里分图那条 0 才压得过
  show: figure-rules.with(styles, layout: layout, metrics: fontset.metrics)
  // 标题：装在模板规则之前——模板里按 heading 元素做的事（计数器重置、检查）要先跑
  let heading-relation = if headings == none { none } else { _headings.headings(styles, headings) }
  show: if heading-relation == none { doc => doc } else { _headings.heading-rules.with(styles, heading-relation) }
  // 题注：编号归零要认「章节起始样式」的标题，从标题关系表里取「这条标题用的样式」
  show: if captions == none { doc => doc } else {
    _captions.caption-rules.with(styles, _captions.captions(styles, captions),
      heading-style: if heading-relation == none { none } else { _headings.style-of-heading(heading-relation) })
  }
  show: rules
  show: paragraph-rules.with(layout, styles, lang: lang)
  section(layout, styles: styles, fontset: fontset, header: header, footer: footer,
    _fonts.baseline-rules(doc))
}
