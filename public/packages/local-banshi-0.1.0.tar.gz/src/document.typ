// 一篇文档立起来：三张表落进 state、通用的 show 链按定好的次序装上。模板自己的规则
// （标题、题注、参考文献……）从 rules: 递进来，装在字的规则之后、段的规则之前。
//
// 次序（外 → 内）与为什么：
//
//   text-rules        字：Word 默认不断字、贪心断行、正文字体与语言、代码的字与行高、繁简、
//                     引号、单位、数学字体与国标字形、run 边界的字距补偿、上下标、下划线、伪粗
//   rules:            模板的——标题、题注、公式编号、参考文献……它们造的元素照样被上面
//                     那截字的规则罩着（show regex 按文本切，不看谁造的）
//   paragraph-rules   段：表格那一档的字号、正文的西文 run 与纯西文行、编号与圆点列表
//   section           一节的 set：版心、页眉页脚、正文的 set text / set par、断行引擎
//   baseline-rules    最内：换中文字体时汉字仍落在中易那一档的高度。它按正则切汉字段，
//                     得等引用、缩略语那些「记号 → 字面」的改写都做完再切
//
// 同一选择器上后定义的 show 规则压过先定义的，所以模板里「谁压谁」的次序在 rules: 里
// 自己排；与两截通用规则之间没有同选择器的争抢（对拍过：iota-hit 的规则链整段搬进
// rules: 后逐字不变）。三截各自也公开，对拍件只装一截、别的模板自己拼都行。
#import "./paragraph/spacing.typ": font-zh-of
#import "./layout/resolve.typ" as _layout
#import "./layout/state.typ": page-setup-state
#import "./layout/section.typ": section
#import "./fonts/resolve.typ" as _fonts
#import "./fonts/fake.typ" as _fake
#import "./fonts/tracking.typ": tracking-rules
#import "./fonts/super-sub.typ": super-sub-rules
#import "./fonts/underline.typ": underline-rules
#import "./fonts/quotes.typ": quote-rules, unit-rules
#import "./fonts/hant.typ": hant-rules
#import "./equation.typ": math-rules
#import "./styles/state.typ": styles-state
#import "./styles/body.typ": body-rules
#import "./paragraph/enum.typ": enum-rules
#import "./paragraph/list.typ": list-rules
#import "./options.typ" as _options

// 字的规则。fontset 是解好的字体表，styles 是解好的样式表（正文字体从 body 取）
#let text-rules(fontset, styles, lang: "zh", doc) = {
  let f = fontset
  let body = styles.body
  let family = f.at(font-zh-of(body))
  // *断字默认关*：原生默认是 auto——「两端对齐就断字」，而正文正是两端对齐的，不压住就成了
  // 默认断字，与 Word 相反（docx 的 settings.xml 里没有 w:autoHyphenation，Word 默认关）。
  // 用户在 #show 之后写 #set text(hyphenate: true) 就能压回来——那一句在内层，赢
  set text(hyphenate: false)
  // *断行按贪心，照 Word*：Word 逐行首次适配；Typst 原生的 auto 在两端对齐时走整段最优
  // （Knuth–Plass），会为了后面的行把前面的行断得早或晚。开关是原生的 par.linebreaks，
  // 不另设：用户在 #show 之前写了 #set par(linebreaks: "optimized")，这里读到的就不是
  // auto，照他的；写在 #show 之后的那一句在内层，本来就赢
  set par(linebreaks: if par.linebreaks == auto { "simple" } else { par.linebreaks })
  // *region 一律 cn，不跟 lang 走*：它是给汉字标点用的旋钮（tw 会关掉相邻标点压缩），
  // 判据是「这段字是不是中文」而不是「这篇文档是哪一版」——英文版里照样有中文摘要
  set text(font: family, lang: lang, region: "cn")
  // 代码里的汉字：仿宋 → 楷体 → 宋体，见 fonts/resolve.typ 的 mono-table。*raw 没有 font 参数*，
  // 只能由 show 规则给下面的 text 设
  show raw: set text(font: f.mono)
  // 代码的字号与行高，见 fonts/resolve.typ 的 mono-text：字号照 MatchLowercase 按 x 高缩、取到
  // 半磅格；行高是等宽字体自己的单倍行高。*写成 show-set*：codly / zebraw 这些代码包自己的
  // show raw 在用户文档里、更内层，raw 到不了我们的规则；show-set 的值它们的输出照样吃到
  show raw: set text(.._fonts.mono-text-em(body.size, f.serif, f.mono))
  // *代码块整宽*：Word 里代码就是一个段落，占满版心；裹一层整宽的块，不 set block(width:)
  // ——set 会钻进 codly / zebraw 内部那些块，它们的定位就散了
  show raw.where(block: true): it => block(width: 100%, it)
  // 楷体是繁体档时才发转字规则，别的档一条都不发
  show: hant-rules.with(f)
  show: quote-rules.with(latin-font: f.serif)
  show: unit-rules
  show: math-rules.with(font: f.math, cjk: f.families.songti)
  // 引擎自己画字符网格时补偿那几条不装：没有模拟出来的字距就没有可丢的，装上只多几处
  // run 边界（见 layout/resolve.typ 的「断行引擎」）
  show: if _layout.engine-linebreaks == none { tracking-rules } else { it => it }
  // 上下标钉到 Word 的数，见 fonts/super-sub.typ；下划线按 Word 画，见 fonts/underline.typ
  show: super-sub-rules
  show: underline-rules
  // 伪粗：中易宋体没有粗体面，不合成的话 #strong 完全哑掉，见 fonts/fake.typ
  show: _fake.rules
  doc
}

// 段的规则。layout 是折好的页面设置
#let paragraph-rules(layout, styles, lang: "zh", doc) = {
  // 表格那一档的字号，写成 show-set——用户就地 #[ #show table: set text(size: …) … ] 在内层、
  // 压得过，重建格子时读的是样式链上的值（styles/table.typ）。字体不 set，跟正文
  show table: set text(size: styles.figure.table.size)
  // 正文那一档的 show 规则（西文 run 的字距、纯西文行的行高），只装这一次；它的
  // set text / set par 在下面 section 里
  show: body-rules.with(layout, styles.body)
  // 编号列表排成段、不悬挂（Word 那样），圆点列表默认照原生悬挂，见 paragraph/enum.typ、list.typ
  show: enum-rules.with(lang)
  show: list-rules
  doc
}

#let document(
  layout,                 // 折好的页面设置（page-setup(...) 的结果）
  styles,                 // 解好的样式表（styles(base, local) 的结果；body 必有，figure.table 是表格那一档）
  fontset,                // 解好的字体表（fontset(...) 的结果）
  lang: "zh",
  options: (:),           // options(...) 的结果：伪粗、伪斜、列表悬挂
  header: none,           // 页眉页脚：逐页调用的函数，none ＝ 不排。递给 section
  footer: none,
  rules: doc => doc,      // 模板自己的 show 链
  doc,
) = context {
  // 三张表落进 state：正文的 show 规则、局部的 new-styles / new-layout、字符网格的 ccwd 都从
  // state 现取。字体表连开机探针一起（真粗真斜、run 边界丢字距——见 fonts/probes.typ）
  page-setup-state.update(layout)
  styles-state.update(styles)
  _fonts.fontset-state.update(fontset)
  _fonts.probes.update(_fonts.probe-all(fontset.families))
  _fonts.boundary-probe.update(_fonts.probe-boundary())
  _options.options-overrides(options)
  show: text-rules.with(fontset, styles, lang: lang)
  show: rules
  show: paragraph-rules.with(layout, styles, lang: lang)
  // 一节的 set：版心、页眉页脚、正文的字与段。这是文档级那一次；段级换版面时再发一次
  section(layout, styles: styles, fontset: fontset, header: header, footer: footer,
    _fonts.baseline-rules(doc))
}
