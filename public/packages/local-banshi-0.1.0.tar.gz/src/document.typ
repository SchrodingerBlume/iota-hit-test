// 一篇文档立起来：三张表落进 state、通用的 show 链按定好的次序装上。
#import "./paragraph/spacing.typ": font-zh-of
#import "./layout/resolve.typ" as _layout
#import "./layout/state.typ": page-setup-state
#import "./layout/section.typ": section
#import "./fonts/resolve.typ" as _fonts
#import "./fonts/fake.typ" as _fake
#import "./fonts/tracking.typ": tracking-rules
#import "./fonts/super-sub.typ": super-sub-rules
#import "./fonts/underline.typ": underline-rules
#import "./fonts/quotes.typ": quote-rules, unit-rules
#import "./fonts/hant.typ": hant-rules
#import "./equation.typ": math-rules
#import "./styles/state.typ": styles-state
#import "./styles/body.typ": body-rules
#import "./styles/figure.typ": figure-rules
#import "./paragraph/enum.typ": enum-rules
#import "./paragraph/list.typ": list-rules
#import "./options.typ" as _options

// 字的规则。
#let text-rules(fontset, styles, lang: "zh", doc) = {
  let f = fontset
  let body = styles.body
  let family = f.at(font-zh-of(body))
  set text(hyphenate: false)
  set par(linebreaks: if par.linebreaks == auto { "simple" } else { par.linebreaks })
  set text(font: family, lang: lang, region: "cn")
  show raw: set text(font: f.mono)
  show raw: set text(.._fonts.mono-text-em(body.size, f.serif, f.mono))
  show raw.where(block: true): it => block(width: 100%, it)
  show: hant-rules.with(f)
  show: quote-rules.with(latin-font: f.serif)
  show: unit-rules
  show: math-rules.with(font: f.math, cjk: f.families.songti)
  show: if _layout.engine-linebreaks == none { tracking-rules } else { it => it }
  show: super-sub-rules
  show: underline-rules
  show: _fake.rules
  doc
}

// 段的规则。
#let paragraph-rules(layout, styles, lang: "zh", doc) = {
  show table: set text(size: styles.figure.table.size)
  show: body-rules.with(layout, styles.body)
  show: enum-rules.with(lang)
  show: list-rules
  doc
}

/// 安装字体、段落、页面与模板 show 规则，并初始化文档状态。
///
/// `layout`、`styles` 与 `fontset` 分别接收对应解析函数的结果。模板专属规则通过
/// `rules` 插入；页眉和页脚是逐页求值的闭包。
/// -> content
#let document(
  layout,                 // 折好的页面设置（page-setup(...) 的结果）
  styles,                 // 解好的样式表（styles(base, local) 的结果；body 必有，figure.table 是表格那一档）
  fontset,                // 解好的字体表（fontset(...) 的结果）
  lang: "zh",
  options: (:),           // options(...) 的结果：伪粗、伪斜、列表悬挂
  header: none,           // 页眉页脚：逐页调用的函数，none ＝ 不排。递给 section
  footer: none,
  rules: doc => doc,      // 模板自己的 show 链
  doc,
) = context {
  page-setup-state.update(layout)
  styles-state.update(styles)
  _fonts.fontset-state.update(fontset)
  _fonts.probes.update(_fonts.probe-all(fontset.families))
  _fonts.boundary-probe.update(_fonts.probe-boundary())
  _options.options-overrides(options)
  show: text-rules.with(fontset, styles, lang: lang)
  // 图表块的三段空当：在模板的规则之前，模板里分图那条 0 才压得过
  show: figure-rules.with(styles, layout: layout, metrics: fontset.metrics)
  show: rules
  show: paragraph-rules.with(layout, styles, lang: lang)
  section(layout, styles: styles, fontset: fontset, header: header, footer: footer,
    _fonts.baseline-rules(doc))
}
