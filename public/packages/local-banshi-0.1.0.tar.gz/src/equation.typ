// 对照 hithesis 的 src/utils/hit-math.dtx。

// 积分号的样式集。GB 要直立形，而各家字体把它放在不同的样式集里。逐字体把 ∫
// 在 ss01–ss20 下排出并量墨迹宽高比：STIX Two Math 的 ss08 从 0.718 变为
// 0.551，XITS Math 同样使用 ss08；New Computer Modern Math 的 ss02 在本机
// 开关前后都是 0.599；TeX Gyre Termes 二十档均无变化；Cambria Math 无需切换，
// 默认宽高比已是 0.541。由于 New CM 的 ss02 当前无效，积分号 feature 暂不安装，
// 但保留此表，等 Typst/字体行为确认后再启用。
#import "./fonts/presets.typ": integral-features
#import "paragraph/spacing.typ": spacing
#import "./layout/resolve.typ" as _layout


// GB/T 3102.11—1993 要求偏微分、实部、虚部使用正体，并采用倾斜的“小于等于”与
// “大于等于”字形。Typst 默认已正确处理大小写希腊字母和微分符号。
#let _gb-shapes(doc) = {
  show sym.partial: math.upright
  show sym.Re: math.op("Re")
  show sym.Im: math.op("Im")
  show sym.lt.eq: sym.lt.eq.slant
  show sym.gt.eq: sym.gt.eq.slant
  doc
}

/// GB/T 3102.11 规定的有限增量符号：正体 U+2206 INCREMENT。
/// -> content
#let increment = math.upright("\u{2206}")

// 块级公式的上方不另补空白：分式所在行的“上一行基线到公式基线”量得 26.93pt，
// 正好等于正文行深 7.275pt 加公式上升部 19.65pt，验证了 Word 按实际内容高度
// 计算这一侧。额外行距只补在公式下方。
/// 按 Word 的算法给块级公式补行高：行距倍数乘公式自然高度，或贴网格时取整数个网格行，
/// 多出的部分补在公式下方。`style` 为 `none` 时不发。
/// -> content
#let line-height-rules(style, doc) = {
  show math.equation.where(block: true): it => context {
    if style == none { return it }
    let metrics = spacing(style, layout: _layout.current-page-setup())
    let nat = measure(text(top-edge: "ascender", bottom-edge: "descender", it)).height
    let want = if metrics.snap {
      let g = metrics.docgrid.line-pitch
      calc.ceil(nat / g) * g
    } else {
      metrics.line-height / metrics.single * nat
    }
    let extra = want - measure(it).height
    if extra <= 0pt { it } else { block(below: extra, it) }
  }
  doc
}

/// 设置数学字体，并可启用 GB/T 3102.11 字形替换。
/// -> content
#let math-rules(font: "TeX Gyre Termes Math", cjk: none, gb: true, doc) = {
  show math.equation: set text(
    font: if cjk == none { font } else {
      ((name: cjk, covers: regex("∥")), font, cjk)
    },
  )
  show math.equation: it => if gb { _gb-shapes(it) } else { it }
  doc
}
