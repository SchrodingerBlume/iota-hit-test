// 错误消息沿用 Typst 的小写句首、无句号和 Oxford comma。值域错误报告实际值，
// 以免 `found string` 掩盖真正的错误输入。

/// 将一组已经格式化的候选值连接为英文枚举。
/// -> str
#let one-of(items) = {
  if items.len() < 2 { return items.join("") }
  if items.len() == 2 { return items.join(" or ") }
  items.join(", ", last: ", or ")
}

/// 生成 Typst 风格的值域错误消息。
/// -> str
#let expected-one-of(allowed, found) = (
  "expected " + one-of(allowed.map(repr)) + ", found " + repr(found)
)
