// 报错文案。*照 Typst 原生的写法*，实测抓下来的几条：
//
//   expected integer, float, length, angle, ratio, fraction, or decimal, found string
//   expected "ascender", "cap-height", "x-height", "baseline", "bounds", or length
//   expected length, found content
//   dictionary does not contain key "b" and no default value was specified
//   array index out of bounds (index: 5, len: 2)
//   unknown variable: nope
//   unexpected argument: nope
//   duplicate key: a
//   label `<nope>` does not exist in the document
//   file not found (searched at /……/nope.png)
//
// 归纳出四条：*全小写开头、句末不加句点*；枚举写「a, b, or c」，*两项时
// 不加逗号*；字符串值用 repr 引起来，auto / none / 类型名不引；附带的细节放进
// 括号，写成「key: value」。
//
// *一处与原生不同，是有意的。* 原生的 found 报的是*类型*
// （found string），因为它那几处是类型对不上；我们这几处类型是对的、*值*
// 不在集合里（degree-level 收到 "phd"），报类型等于什么也没说。所以 found 报值。
// 形状不动，信息才落得下来。
//
// *提示只能写进句子里。* 原生的 hint: 那一行是编译器自己发的，用户代码里
// panic / assert 发不出来；所以「要原样排就写成内容」这类话跟在括号里。

// 「a」「a or b」「a, b, or c」。items 是*已经成品*的字符串——auto 与
// none 不引号，字符串值引，两种混在一张表里的时候由调用方自己决定。
#let one-of(items) = {
  if items.len() < 2 { return items.join("") }
  if items.len() == 2 { return items.join(" or ") }
  items.join(", ", last: ", or ")
}

// 值域不对：expected "bachelor", "master", or "doctor", found "phd"
#let expected-one-of(allowed, found) = (
  "expected " + one-of(allowed.map(repr)) + ", found " + repr(found)
)

// ── 只该印一次的页：第二次调用当场报错，不静默多印一份。
//
// 用计数器不用 state：step 是独立元素、落在读它的 context 之前，第 n 次调用稳稳读到
// n（同 iota-hit/src/layout/matter.typ 的 cover-exit-count；state 读一次写一次会来回跳）。
// 报错要多排一轮才出现（计数器是 introspection），编译照样停。
//
// key 给目录、图表清单这类按语言各出一份的页：同一种语言印两次才算重复。
#let _count(name, key) = counter("banshi-once:" + name + (if key == none { "" } else { ":" + key }))

// *对拍件把这道门关掉。* 页面模块自己发 once（公开面直接导出它们，套一层
// 包装 LSP 就没了，见 iota-hit/lib.typ），所以「在一篇里排几份变体」不能再靠绕开公开名。
// 不是公开面：iota-hit/lib.typ 不导出，只有 tests/ 的对拍件 import 得到
#let _repeatable = state("banshi-once-repeatable", false)
#let allow-repeats() = _repeatable.update(true)

#let once(name, key: none, hint: "") = {
  let c = _count(name, key)
  c.step()
  context {
    if c.get().first() > 1 and not _repeatable.get() {
      panic(
        "#" + name + "() appears more than once"
          + (if key != none { " for lang " + repr(key) } else { "" })
          + "; each page is printed once" + hint,
      )
    }
  }
}

// 两个页互斥：other 在文档里*任何位置*出现过就报错（final，不看先后）。
#let never-with(name, other, hint) = context {
  if _count(other, none).final().first() > 0 {
    panic("#" + name + "() cannot be used together with #" + other + "(): " + hint)
  }
}
