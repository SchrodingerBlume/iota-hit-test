// 错误消息沿用 Typst 的小写句首、无句号和 Oxford comma。值域错误报告实际值，
// 以免 `found string` 掩盖真正的错误输入。

/// 将一组已经格式化的候选值连接为英文枚举。
/// -> str
#let one-of(items) = {
  if items.len() < 2 { return items.join("") }
  if items.len() == 2 { return items.join(" or ") }
  items.join(", ", last: ", or ")
}

/// 生成 Typst 风格的值域错误消息。
/// -> str
#let expected-one-of(allowed, found) = (
  "expected " + one-of(allowed.map(repr)) + ", found " + repr(found)
)

// 计数器用于检测只能出现一次的页面。相较于读写同一 state，独立的 step 元素能让
// introspection 稳定收敛。`key` 可区分不同语言的同类页面。
#let _count(name, key) = counter("banshi-once:" + name + (if key == none { "" } else { ":" + key }))

// 测试夹具可关闭重复检查；模板不应导出此状态。
#let _repeatable = state("banshi-once-repeatable", false)
#let allow-repeats() = _repeatable.update(true)

#let once(name, key: none, hint: "") = {
  let c = _count(name, key)
  c.step()
  context {
    if c.get().first() > 1 and not _repeatable.get() {
      panic(
        "#" + name + "() appears more than once"
          + (if key != none { " for lang " + repr(key) } else { "" })
          + "; each page is printed once" + hint,
      )
    }
  }
}

// `final` 检查整篇文档，因此互斥页面的书写顺序不影响结果。
#let never-with(name, other, hint) = context {
  if _count(other, none).final().first() > 0 {
    panic("#" + name + "() cannot be used together with #" + other + "(): " + hint)
  }
}
