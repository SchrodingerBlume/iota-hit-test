// 英文标题的大小写：花括号保护与两档转换。
//
// *开关* iota-hit(title-case:)：auto（＝本档默认，现在是 none）、none（原样）、
// "sentence"（首词大写、其余小写）、"title"（实词大写、小词小写、首末词与冒号后
// 首词总大写）。名与义照 omni-gb7714 的 titles-text-case（CSL 的 text-case 两档），
// 用户在参考文献那边学过的规则这边一样；单数是因为它是一个开关管全部英文标题，
// 不是字段容器（omni 那个 s 说的是十二个字段）。默认 none：学校自己的字样三种
// 写法都有（Innovative achievements for Ph.D 句式、List of Dissertation Reviewers…
// 题式、Statement of copyright and Letter of authorization 各半），不动是对的。
//
// *花括号是保护记号，跟 .bib 一个方案*：{DNA} 里的照写，括号本身剥掉——
// *开没开转换都剥*，否则关开关时括号会时隐时现；想印花括号写两个（{{ 与 }}）；
// 不支持嵌套；一对括号得落在同一段文本里，不能跨 #emph[…] 这类元素的边界。
// 没配对的括号当场报错（不静默失效）。
//
// *整条全大写的先整串小写再转*（RESEARCH ON … → Research on …），见 _all-caps。
// *词里有非首字母大写或数字的词自动不动*（DNA、pH、FLUENT、3D、Ph.D）：查准
// 接近 100%，查全约一半——专名（Harbin、Reynolds）认不出，要留就 {Harbin}。
// 拿本机 30 个 .bib 里 403 条英文标题量的：句式标题里 22.8% 含这种专名。
//
// *管到哪*：学校英文字样、#en[…]、英文档的标题正文、题注的英文名；目录、
// 页眉、书签跟着标题走。含汉字的整条跳过（omni 同样）——中文没有大小写。
// 公式、raw、记号不碰；#emph / #strong / 上下标 / 链接递归进去。
#import "../content.typ": plain-text
#import "../msword.typ": has-cjk

// 存的是用户写的原值（标量或字典），auto 在入口折成 none
#let title-case-state = state("banshi-title-case", none)

#let modes = (none, "sentence", "title")

// *也收字典，按「谁写的」分槽*：term 学校字样、heading 章节名（#en、英文档标题、
// 目录、页眉）、caption 图表题注的英文名（含图表索引）；rest 兜底，缺的键按它，rest 也
// 没写按 none。形状照 omni 的 titles-text-case: (title: …, rest: …)。键单数：值是一个
// 档名，不是一堆东西。标量 ＝ 三个槽同一个值。
#let slots = ("term", "heading", "caption")

#let _expected = "auto, none, \"sentence\", \"title\", or a dictionary with keys "
  + slots.map(repr).join(", ") + ", rest"

#let check-title-case(v) = {
  if v == auto or v in modes { return }
  if type(v) != dictionary {
    panic("title-case: expected " + _expected + "; found " + repr(v))
  }
  for (k, m) in v {
    if k not in slots + ("rest",) {
      panic("title-case: unknown key " + repr(k) + "; expected one of " + (slots + ("rest",)).map(repr).join(", "))
    }
    if m not in modes {
      panic("title-case." + k + ": expected none, \"sentence\", or \"title\", found " + repr(m))
    }
  }
}

// 某一槽落到哪一档
#let mode-for(v, slot) = {
  if type(v) == dictionary { v.at(slot, default: v.at("rest", default: none)) } else { v }
}


// CSL 的小词表（text-case="title" 不大写的那些）
#let _small = (
  "a", "an", "and", "as", "at", "but", "by", "down", "for", "from", "in", "into",
  "nor", "of", "on", "onto", "or", "over", "so", "the", "till", "to", "up", "via",
  "with", "yet",
)

// 一个词要不要自动不动：非首字母里有大写，或含数字
#let _protected(w) = w.slice(1).match(regex("[A-Z]")) != none or w.match(regex("[0-9]")) != none

// *整条全大写的先整串小写，再照常转*——CSL 两档都这么定（Sentence Case Conversion
// 「uppercase strings are lowercased before the first character is uppercased」；Title Case
// 那节同）。这一步*必须在自动保护之前*：全大写标题的每一个词都「词内有大写」，
// 不先降下来的话整条会被保护冻住，两档都一字不改（实测 RESEARCH ON KEY TECHNOLOGIES
// OF POROUS BEARINGS 原样印出来）。
//
// 判据是「有字母，且一个小写字母都没有」，*花括号里的不算*——那几个词本来就说了
// 「别看我」，把它们算进来，「STUDY OF {mRNA} SEQUENCING」里那个 m 会让整条不算全大写，
// 于是又退回逐词保护、一字不改（实测）。摘花括号只为这一判：真正的剥括号在 _segments
#let _unbraced(s) = s.replace("{{", "").replace("}}", "").replace(regex("\\{[^{}]*\\}"), "")
#let _all-caps(s) = {
  let t = _unbraced(s)
  t.match(regex("[A-Z]")) != none and t.match(regex("[a-z]")) == none
}

#let _cap(w) = upper(w.slice(0, 1)) + lower(w.slice(1))

// 把一段文本切成 (text, kind)：kind 是 "word" / "sep" / "keep"（花括号里的）。
// 花括号在这一层剥：{{ }} 是字面。
#let _segments(s) = {
  // 按码位走，不按字节：s.at(i) 是字节下标，碰上 — ’ 这类多字节字符会踩在字符中间
  // 报错（实测题注英文名里一个破折号就炸）。闭包改不了外层变量，cur 的收尾写两遍
  let cps = s.codepoints()
  let out = ()
  let i = 0
  let n = cps.len()
  let cur = ""
  while i < n {
    let ch = cps.at(i)
    if ch == "{" {
      if i + 1 < n and cps.at(i + 1) == "{" { cur += "{"; i += 2; continue }
      // 找配对的 }（不认嵌套）
      let close = cps.slice(i + 1).position(x => x == "}")
      if close == none { panic("title-case: unmatched \"{\" in English title: " + repr(s)) }
      if cur != "" { out.push((cur, "raw")); cur = "" }
      out.push((cps.slice(i + 1, i + 1 + close).join(), "keep"))
      i = i + 1 + close + 1
      continue
    }
    if ch == "}" {
      if i + 1 < n and cps.at(i + 1) == "}" { cur += "}"; i += 2; continue }
      panic("title-case: unmatched \"}\" in English title: " + repr(s))
    }
    cur += ch
    i += 1
  }
  if cur != "" { out.push((cur, "raw")) }
  // raw 段再切成词与分隔
  let fine = ()
  for (t, kind) in out {
    if kind == "keep" { fine.push((t, "keep")); continue }
    for m in t.matches(regex("[A-Za-z0-9][A-Za-z0-9'’\\-\\.]*|[^A-Za-z0-9]+")) {
      fine.push((m.text, if m.text.match(regex("^[A-Za-z0-9]")) != none { "word" } else { "sep" }))
    }
  }
  fine
}

// 走内容树。f 收 (word, index, total, after-colon) 给新词；返回 (内容, 新 index, 新 after-colon)。
// 数词那一遍 f 给 none，只数不改。
//
// *一个字都没改就原样交回，不重建。* 重建等于*重新发*一段文字，它的 span
// （源码位置）就成了本文件这一行——tinymist 从预览跳回源码时，英文标题与题注全落进
// case.typ。而默认档（mode: none）走这里*只为剥花括号*，绝大多数标题一个括号
// 都没有，纯属白重建一遍。同一条道理见 src/styles/rules.typ 的 latin-run-led。
#let _walk(c, f, index, total, after-colon, count: false) = {
  if type(c) == str { return _walk(text(c), f, index, total, after-colon, count: count) }
  if type(c) != content { return (c, index, after-colon) }
  if c.func() == text {
    let segs = _segments(c.text)
    let out = ""
    let idx = index
    let ac = after-colon
    for (t, kind) in segs {
      if kind == "word" {
        if count { idx += 1 } else {
          out += f(t, idx, total, ac); idx += 1
        }
        ac = false
      } else {
        if not count { out += t }
        // 冒号、问号、叹号、破折号之后的词按句首处理
        if kind == "sep" and t.match(regex("[:?!—–]\\s*$")) != none { ac = true }
        if kind == "keep" { idx += 1; ac = false }
      }
    }
    // 串一模一样就是没改
    return (if count or out == c.text { c } else { text(out) }, idx, ac)
  }
  if c.has("children") {
    let kids = ()
    let idx = index
    let ac = after-colon
    let changed = false
    for k in c.children {
      let (nk, ni, na) = _walk(k, f, idx, total, ac, count: count)
      if nk != k { changed = true }
      kids.push(nk); idx = ni; ac = na
    }
    return (if count or not changed { c } else { kids.join() }, idx, ac)
  }
  // 能重建的带 body 的元素：递归进去再装回去
  if c.has("body") and c.func() in (emph, strong, sub, super, smallcaps, underline, strike, highlight, overline, link) {
    let (nb, ni, na) = _walk(c.body, f, index, total, after-colon, count: count)
    if count or nb == c.body { return (c, ni, na) }
    let rebuilt = if c.func() == link { link(c.dest, nb) } else { (c.func())(nb) }
    return (rebuilt, ni, na)
  }
  // 公式、raw、记号、盒子、context……原样
  (c, index, after-colon)
}

#let _count-words(c) = _walk(c, none, 0, 0, false, count: true).at(1)

#let _convert(w, index, total, after-colon, mode, all-caps) = {
  // 整条全大写那一档：先降成小写，自动保护这一遍不做（做了就没有一个词转得动）
  let w = if all-caps { lower(w) } else if _protected(w) { return w } else { w }
  if mode == "sentence" {
    return if index == 0 or after-colon { _cap(w) } else { lower(w) }
  }
  // title
  let bare = lower(w)
  if index == 0 or index == total - 1 or after-colon { return _cap(w) }
  if bare in _small { bare } else { _cap(w) }
}

// 一条英文标题按当前档转过来，花括号剥掉。*要在 context 里调*（读开关）。
// slot 是这条标题归哪一槽（见 slots）；mode 显式给了就不读开关。
#let english-title(c, slot: "heading", mode: auto) = {
  if slot not in slots { panic("english-title: unknown slot " + repr(slot)) }
  let mode = if mode == auto { mode-for(title-case-state.get(), slot) } else { mode }
  if c == none { return none }
  // 含汉字的整条跳过，连括号都不剥——中文标题里的花括号不是记号
  if has-cjk(plain-text(c)) { return c }
  if mode == none {
    return _walk(c, (w, i, n, ac) => w, 0, 0, false).at(0)
  }
  let total = _count-words(c)
  let all-caps = _all-caps(plain-text(c))
  _walk(c, (w, i, n, ac) => _convert(w, i, n, ac, mode, all-caps), 0, total, false).at(0)
}
