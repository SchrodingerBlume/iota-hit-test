// 为什么要自己合成。 Typst 从不合成；要的那一面没有就静默换成最近的一面。
#import "./resolve.typ" as fonts
#import "../options.typ" as _options
#import "../runs.typ": latin-slot-run
#import "./presets.typ": fake-roles, fake-bold-coef, fake-italic-angle

#let _in-roles(which) = {
  let f = fonts.fontset-state.get().families
  let now = text.font
  let family = if type(now) == array and now.len() > 0 {
    let last = now.last()
    if type(last) == dictionary { last.at("name", default: "") } else { last }
  } else if type(now) == str { now } else { "" }
  fake-roles.at(which).find(role => lower(family) == lower(f.at(role)))
}

// 伪粗：在填充之外描一圈同色的边，线宽 字号/35。
#let fake-bold(body) = {
  set text(stroke: fake-bold-coef * 1em + text.fill)
  show latin-slot-run: set text(stroke: none)
  body
}

// 伪斜：斜切。
#let fake-italic(body) = box(skew(
  ax: fake-italic-angle, reflow: false, body,
))

// 按角色问，不按字体名问；部件自己知道排的是哪一档（style 的 font/font-zh），不必再从 text.font 反推。
#let wants-bold-for(role) = {
  let gate = _options.option-of("fake-bold")
  if gate == false { return false }
  if role == none or role not in fake-roles.bold { return false }
  if gate == true { return true }
  fonts.lacks-bold(role)
}

#let wants-bold() = wants-bold-for(_in-roles("bold"))

#let rules(doc) = {
  show strong: it => context {
    if wants-bold() { fake-bold(it) } else { it }
  }
  doc
}
