// 伪粗与伪斜。
//
// *为什么要自己合成。* Typst 从不合成——要的那一面没有就静默换成最近的一面。
// 中易宋体没有粗体面，于是 #strong[加粗] 排出来与正文*一模一样*（实测同一个
// SimSun 子集，字重纹丝不动）；汉字更没有斜体面。Word 两样都合成，我们跟 Word。
//
// *只给宋体那一档发*，见 src/fonts/presets.typ 的 fake-roles：正文与封面的绝大多数字是它，而标题
// 走黑体、本来就靠换字体加重。判「现在是不是宋体那一档」用当前生效的 text.font ——
// 与 styles.typ 里「判当前 top-edge 是不是本档的」同一个办法，样式查询，不进布局回路。
//
// *挂在已有的规则上，不另开 show regex。* 实测 cutix 全篇铺开时会把汉字接西文
// 的字距从 15.4543 吃成 15.0000——两个包各自用 regex 重切同一段文本，谁后跑谁把对方
// 插的间距吃掉。这里只加 show strong，不碰文本的切分。
#import "./resolve.typ" as fonts
#import "../options.typ" as _options
#import "../msword.typ": latin-slot-run
#import "./presets.typ": fake-roles, fake-bold-coef, fake-italic-angle

// 当前这一段是不是某个吃合成的角色；是就给出*角色名*，不是给 none。
// 要在 context 里调
#let _in-roles(which) = {
  let f = fonts.fontset-state.get().families
  // *比家族名，不比整张表*。text.font 拿到的是 fonts.font 拼出来的那一串
  // （全宽符号一条、西文两条、再是本角色的家族），整串相等这个判据太脆；
  // 而*最后一条*就是本角色的家族名——那才是「现在排的是哪一种字」。
  let now = text.font
  let family = if type(now) == array and now.len() > 0 {
    let last = now.last()
    if type(last) == dictionary { last.at("name", default: "") } else { last }
  } else if type(now) == str { now } else { "" }
  // *按小写比*：Typst 把 text.font 里的家族名规范成了小写（"simsun"），
  // 而角色表里写的是 "SimSun"——直接比字符串永远不中。与 is-hant-only 同一个办法。
  fake-roles.at(which).find(role => lower(family) == lower(f.at(role)))
}

// 伪粗：在填充之外描一圈同色的边，线宽 字号/35。
//
// *不换掉 strong 元素，只加描边*——换成 it.body 会把 weight 一起丢掉，
// 夹在中文里的西文就从真粗体面掉回常规体（实测 bold 从 TimesNewRomanPS-BoldMT
// 变成 TimesNewRomanPSMT，还被描了一圈）。
//
// *西文槽那些 run 再把描边撤掉*：它们有真粗体面，描了就是双重加粗。选择器是字体表
// 分槽的补集 latin-slot-run——凡是排在西文槽上的字都撤，纯数字、希腊字母、± % 一个不漏；
// 先前用 latin-ink-run（拉丁字母与数字），#strong[αβγ]、#strong[±%] 在真粗面上又描了一圈。
#let fake-bold(body) = {
  set text(stroke: fake-bold-coef * 1em + text.fill)
  show latin-slot-run: set text(stroke: none)
  body
}

// 伪斜：斜切。reflow: false 让它不改变周围的排版
#let fake-italic(body) = box(skew(
  ax: fake-italic-angle, reflow: false, body,
))

// 该不该给这个角色发伪粗。要在 context 里调。
//
// *按角色问，不按字体名问*——部件自己知道排的是哪一档（style 的 font/font-zh），
// 不必再从 text.font 反推。封面那些加粗走的是 part 的 weight: "bold"，不是 #strong，
// 反推那条路在那里够不着。
#let wants-bold-for(role) = {
  let gate = _options.option-of("fake-bold")
  if gate == false { return false }
  if role == none or role not in fake-roles.bold { return false }
  if gate == true { return true }
  // auto：家族在、且没有真粗面才轮得到合成，判据与 latin-bold 那一路共一句，
  // 见 src/fonts/probes.typ 的 lacks-bold
  fonts.lacks-bold(role)
}

// 该不该给这一段发伪粗。要在 context 里调。#strong 那一路用它——那里没有 style，
// 只能从当前生效的字体反推角色。
#let wants-bold() = wants-bold-for(_in-roles("bold"))

#let rules(doc) = {
  show strong: it => context {
    if wants-bold() { fake-bold(it) } else { it }
  }
  doc
}
