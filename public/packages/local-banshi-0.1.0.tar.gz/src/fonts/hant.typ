// 仅有繁体字形的楷体需要在文本整形前转为繁体；其他字体不安装此 show rule。
// zhconv 在规则体内才 import：不用繁体楷体的文档不解析这个包。

#import "./resolve.typ" as fonts
#let _uses-hant(font) = {
  let families = if type(font) == array { font } else { (font,) }
  families.any(f => fonts.is-hant-only(
    if type(f) == dictionary { f.name } else { f },
  ))
}

#let _needs-hant(fontset) = fontset.families.values().any(v => (
  type(v) == str and fonts.is-hant-only(v)
))

#let hant-rules(fontset, doc) = {
  if not _needs-hant(fontset) { return doc }
  show regex("\p{Han}+"): it => context {
    if _uses-hant(text.font) {
      import "@preview/zhconv:0.3.1": zhconv
      zhconv(it.text, "zh-hant")
    } else { it }
  }
  doc
}
