// 字体预设与标定常数。*只放值*——解析（resolve）、探针（probe-all）与四个中文
// 字族的入口住在 src/fonts/resolve.typ，Word 的换算函数与 run 正则住在
// src/msword.typ。
//
// 对照 hithesis 的 fontset / fontset-zh / fontset-en / fontset-math 四个类选项
// （声明在 src/setup/hit-thesis-options.dtx，实现在 src/utils/hit-fonts.dtx 与
// src/utils/hit-math.dtx）。这边收成一个 fonts 参数。
//
// *为什么是一个参数。* hithesis 分四个键，是因为 fontset 要转给 ctex、
// fontset-zh 给了值才由模板自己设，两者语义不同；Typst 没有 ctex 可转，
// 那个区分就不存在了。而中文档与西文档拆成两个轴也不成立——西文的选择本来就
// 是平台决定的（Windows/macOS 有 Times，Web App 与 TeX 发行版场景只有 TeX Gyre），
// hithesis 的 fontset-en auto 从 fontset 推，推的就是这件事。
//
// 所以每一档是*一整套完整方案*，按「字体从哪来」命名，八个角色拍平在
// 一张表里。规矩一句话：*预设是整套，覆盖是逐角色*。
//
// 参数收*一整套*，而不是「档名」与「覆盖」两个参数：六档本身就是完整方案，
// 想以某一档为底改几个角色，用 Typst 自己的字典合并即可——
//
//     fontset: presets.founder + (kaishu: "TW-MOE-Std-Kai")
//
// 所以*那张表要导出*（iota-hit/lib.typ 的 presets）：不导出的话「选不了底」，
// 写一份角色字典只能盖在默认档上，要以 founder 为底就得手抄整张表。
//
// 这个形状与 Typst 自己的复合字典参数一路（page 的 margin、text 的 costs），
// 也与 modern-nju-thesis 的 fonts 一致。

// 八个角色。名字互不冲突，所以不需要轴那一层。
// 中文四个照 hithesis 的字族名（zhsong / zhhei / zhkai / zhfs），
// 西文三个照 fontspec 的三件套，数学一个。

// *楷体_GB2312 与隶书是两副真字，不是别名。* 报告那两份表单上，顶部空段
// 用楷体_GB2312、「哈尔滨工业大学教务处制」用隶书；论文封面的校名那一行 docx
// 里写的也是楷体_GB2312。
//
// *度量上它们与中易那一族没有差别*，所以下面的两张系数表
// 不为它们多开一档——六副字（SimSun / SimHei / KaiTi / FangSong / KaiTi_GB2312 /
// LiSu）读出来的垂直度量*逐字段相同*：unitsPerEm 256、hhea 升 220 降 −36
// 行隙 36、winAscent 220 winDescent 36。字形是两副（GB2312 只有 7580 个字形、
// 中易楷体有 28562，「哈」的轮廓框也不同），行高与上升部却同源。
// 钉在 iota-hit/tests/check-font-metrics.py。
#let zh-roles = (
  "songti", "heiti", "kaishu", "kaishu-gb2312", "fangsong", "lishu", "xinwei",
)
#let en-roles = ("serif", "sans", "mono")
#let roles = zh-roles + en-roles + ("math",)

// 代码那一档的西文等宽。*取 Typst 自带的那一个*——它随发行版走，任何平台、
// 连 Web App 都在，不会缺字。先前各档各写各的（Courier New / TeX Gyre Cursor），
// 是从 fontspec 三件套抄来的想当然：Courier New 在 Linux 与 Web App 上没有、
// TeX Gyre Cursor 在 Windows 上没有，实测本机编 fandol 档就多一条
// unknown font family: tex gyre cursor。规范对代码字体一个字没提，那就取一个
// *到处都在*的。要换就改这个角色，改了就生效。

// 六档。每一档都是完整方案，所以六个名字同类、可比，字符串路也不残缺。
//
// *去掉过 adobe 那一档*（AdobeSongStd-Light 那一系）：它是 Adobe 随 Acrobat
// 装的一套，装了的人极少，而少一档就少一份没人验的配置。要用照旧写得出来——
// fontset 收字典，fontset: (songti: "AdobeSongStd-Light", …) 与预设等价。
//
// 中文取值照抄 hithesis 各档的 \setCJKfamilyfont；西文跟着平台走
// （Windows/macOS 有 Times 三件套，Web App 与 TeX 发行版场景用 TeX Gyre）；
// 数学全档 TeX Gyre Termes Math，与 hithesis 的 fontset-math auto 一致，
// 理由见 src/equation.typ。
#let presets = (
  windows: (
    songti: "SimSun", heiti: "SimHei", kaishu: "KaiTi", fangsong: "FangSong",
    // *这两格只有 windows 档写*。楷体_GB2312 与隶书没有平台对应物——别的
    // 系统上就是没有这两副字，而不是「换了个名字」。别的档不写，于是从默认档
    // （windows）继承这两个名字：装了的机器用得上，没装的由回落链接住，
    // 见 src/fonts/resolve.typ 的 role-chain。resolve 里 presets.windows + 本档
    // 那一句就是这个机制
    kaishu-gb2312: "KaiTi_GB2312", lishu: "LiSu",
    // *华文新魏*：深圳本科那两份表单的校名与文种是这一副字（那两份 docx 的
    // w:eastAsia 写的就是「华文新魏」）。这一格与楷体_GB2312、隶书同一个办法：
    // *只写默认档，别的档继承*，装了的机器用得上、没装的由回落链接住。
    //
    // *写西文那个名字*，与 LiSu／KaiTi_GB2312 一路：中文那个名字实测在
    // macOS 上匹配不上（那边同一副字只报 STXinwei），而西文名两边都在
    xinwei: "STXinwei",
    serif: "Times New Roman", sans: "Arial", mono: "Consolas",
    math: "Cambria Math",
  ),
  macos: (
    songti: "Songti SC", heiti: "Heiti SC",
    kaishu: "Kaiti SC", fangsong: "STFangsong",
    serif: "Times New Roman", sans: "Arial", mono: "Menlo",
    math: "STIX Two Math",
  ),
  founder: (
    songti: "FZShuSong-Z01", heiti: "FZHei-B01",
    kaishu: "FZKai-Z03", fangsong: "FZFangSong-Z02",
    serif: "Times New Roman", sans: "Arial", mono: "DejaVu Sans Mono",
    math: "TeX Gyre Termes Math",
  ),
  // Web App 自带 TeX Gyre 与 Noto CJK，反而没有 SimSun 与 Times New Roman
  // （universal-hit-thesis 的 README 专门写了这一条）。楷体用教育部标准楷书，
  // 它只有繁体字形，配 zhconv 转字，见 src/fonts/resolve.typ 的 is-hant-only。
  webapp: (
    songti: "Noto Serif CJK SC", heiti: "Noto Sans CJK SC",
    kaishu: "TW-MOE-Std-Kai", fangsong: "Noto Serif CJK SC",
    serif: "TeX Gyre Termes", sans: "TeX Gyre Heros", mono: "DejaVu Sans Mono",
    math: "TeX Gyre Termes Math",
  ),
  // Typst 自带的那一套。与 webapp 的差别只在西文与数学：西文用 Libertinus Serif
  // （Typst 的默认正文字体），数学用 New Computer Modern Math（它的默认数学字体）。
  // *好处是一个字体都不用装*——两样都随发行版走，任何平台、任何 Web App 都在。
  typst: (
    songti: "Noto Serif CJK SC", heiti: "Noto Sans CJK SC",
    kaishu: "TW-MOE-Std-Kai", fangsong: "Noto Serif CJK SC",
    serif: "Libertinus Serif", sans: "TeX Gyre Heros", mono: "DejaVu Sans Mono",
    math: "New Computer Modern Math",
  ),
  fandol: (
    songti: "FandolSong", heiti: "FandolHei",
    kaishu: "FandolKai", fangsong: "FandolFang",
    serif: "TeX Gyre Termes", sans: "TeX Gyre Heros", mono: "Latin Modern Mono",
    math: "New Computer Modern Math",
  ),
)

// 默认档。中易那一系正是全部标定常数的对象，而且本地编译的机器上装得最全。
//
// 不取 webapp 是实测定的：本机没有 TeX Gyre Termes，拿 webapp 那套编译会报
// 一条 unknown font family，西文连同数字一起落进 Noto，而且那两条 covers 挂在
// 一个不存在的家族上会被整条跳过——引号、破折号、省略号全归 Noto，
// 整套 covers 机制静默失效。Web App 用户写一句 fontset: "webapp" 即可。
#let default-preset = "windows"

// 只有繁体字形的楷体。用到它时要把汉字转成繁体，否则简体字缺字。
// 名字取自 ElegantBook 的 _uses-traditional-moe-font。
#let hant-only = ("tw-moe-std-kai", "moesongun")

// 视觉矫正的锚字与基准。
//
// *问题。* 行盒的两条边写死之后，换字体基线逐条不变（iota-hit/tests/check-fonts.sh
// 一直在验）——可*字画在基线之上多高*是各家字体自己的事，差得不少。实测同一
// 段 12pt 正文里 `国` 的墨迹中心离基线：中易宋体 0.36133em，苹方那边的 Songti SC
// 只有 0.292，FandolSong 0.297——汉字整体低 0.8pt，与旁边的西文的关系也跟着变。
// Noto Serif CJK SC 是 0.3715，反过来高 0.14pt。
//
// *锚字取「国」*。它在几乎所有中日韩字体里都填满字身框，是字身框位置最好的
// 代用品。不是完美的：同一字体里「口」量出来 0.3477 而「国」「永」「哈」都在
// 0.361–0.363——「口」本来就画得矮，那是字形设计不是字身框。
//
// *基准是 Windows 那一档*同角色*的家族*，不是一律拿宋体。中易黑体本来
// 就比中易宋体低 0.023em，那是 Word 在 Windows 下的样子，不该「修」。
//
// 这四个数是量出来的（100pt 下探针，与 PDF 里逐字量的分毫不差），*必须写死*
// ——没装中易的机器也要算得出矫正量。
#let ink-anchor = "国"
// *只有繁体字形的那几副楷体用这一个*（教育部标准楷书，webapp 那一档）：它们没有「国」这个
// 字形，拿 fallback: false 去量等于量一个空格，探出来的矫正量是废数——实测 webapp 档
// #kaishu[] 那一行整段被压低 0.72～0.90。那几副字排的本来就是繁体（正文由 zhconv 转过去，
// 见 src/fonts/hant.typ），量它自己排得出的那一个才算数
#let ink-anchor-hant = "國"
#let baseline-reference = (
  songti: 0.361328125, heiti: 0.337890625, kaishu: 0.328125, fangsong: 0.341796875,
  // 后两档同样量出来的（同一支探针、同一个「国」、100pt）。六个数全落在 1/256
  // 的整数倍上——中易那一族的 unitsPerEm 就是 256，轮廓点本来就在整格上。
  //
  // *楷体_GB2312 与中易楷体差 0.015625*（88/256 对 84/256，四百分之一 em）：
  // 两副字的「国」不在同一高度上，所以这一格不能与 kaishu 共用；隶书更低
  // （78/256），它本来就是扁字。
  kaishu-gb2312: 0.34375, lishu: 0.3046875,
  // *新魏不在中易那一族*，所以这个数不落在 1/256 的整数倍上（同一支探针、
  // 同一个「国」、100pt，量的是 STXinwei——Windows 上的华文新魏是同一副字）。
  // 它比隶书还低两成：新魏是斜势的行楷，字身本来就靠下
  xinwei: 0.2385,
)

// *哪些角色吃伪粗伪斜。* 往后要扩展改这一处，*公开面不动*。
//
// 伪粗收*宋体与楷体*。宋体是正文与封面的绝大多数字；楷体是封面那一行校名
// ——范例的 rPr 写着「楷体 18pt *加粗*」，而中易楷体没有粗体面，Word 自己
// 合成，我们也得合成。先前这里只登记宋体，windows 档的「哈尔滨工业大学」于是
// 只有填充没有描边（实测同一页的「本科毕业论文（设计）」填充描边都在），
// 排出来不粗。
//
// *黑体不收*：标题走黑体本来就靠换字体加重，中文题目那一行 w:rPr 里根本
// 没有 w:b。真有粗体面的家族也不会被描——那道闸在 wants-bold-for 里，按入口
// 探好的表判（见 src/fonts/probes.typ 的 probe-all）。
//
// 伪斜只有宋体：楷体本身就是「汉字的斜体」那一档，没楷体才退到斜切宋体。
// *楷体_GB2312 也在里头*：报告封面的校名就是它（三份表单的那一段 run 都写着
// <w:b/>，楷体_GB2312 小二），而这一家没有粗体面——学校自己发的
// 硕士学位中期报告模板.pdf 里那七个字正是 fill + stroke，Word 也在描。先前这一档
// 不在表里，校名的 bold: true 一路走到底却什么都没发生（实测只有 fill）。
// *角色名要与 style 里的 font 对上*——_role-of 优先读 font 那个键，封面写的是
// font: "kaishu-gb2312"，写 kaishu 匹配不上。
// *新魏也收伪粗*：深圳本科那两份表单的校名与文种那两行 run 都写着 <w:b/>，
// 而华文新魏（STXinwei 实测）没有粗体面
#let fake-roles = (
  bold: ("songti", "kaishu", "kaishu-gb2312", "xinwei"),
  italic: ("songti",),
)

// 伪粗的描边线宽系数：字号/35，与 Word 一致（cutix 由 docx 导出 PDF 实测标定：
// 48.025pt 加粗给 1.3721w、24pt 给 0.68571w，都精确等于 字号/35）。
#let fake-bold-coef = 1 / 35

// 伪斜的倾角，与 cutix 同源
#let fake-italic-angle = -18.4deg

// ── Word 标定出来的数 ──────────────────────────────────────────────
//
// 这些数不是从字体文件里读的，是 hithesis 拿 Word 对照文档标定出来的：
// 四轮文档、三十组、一百六十多条基线，量法记在 hithesis 的
// src/utils/hit-msword.dtx。照抄，不要按字体度量重算。

// 自然行高系数：字号乘这个数就是 Word 的单倍行高，只跟字体有关。
// 1.296875 是 332/256，中易宋体的 unitsPerEm 正好是 256。
// 苹方是 1.82，差了四成，所以这个系数必须按字体查，不能当通用常数——
// 但模板一律按中易排，不问实际加载的是哪一个宋体，好让各字体之间版面一致。
#let natural-coefs = (
  songti: 1.296875,
  heiti: 1.296875,
  kaishu: 1.296875,
  fangsong: 1.296875,
  lishu: 1.296875,
  // *华文新魏不在中易那一族，数是从深圳本科原件量的*：2026 年 9 月版开题与中期
  // 两份的 Word PDF 里，校名与文种是两行连着的小初（36pt）新魏、行距 1.2 倍
  // （w:line="288"），两行基线步进 57.10 ＝ 1.2 × 36 × 1.3218。
  //
  // *这个数只对带 w:w 字宽缩放的 run 成立*——那两行写着 w:w="90"。探针（原件为底，
  // 各字号两段连排量步进）：素 run 的行高是 1.35 × 字号（12/24/36/48pt 单倍 16.08/
  // 32.40/48.48/64.56，1.2 倍 19.44/38.64/58.32/77.52）；一旦 run 带 w:w（90、80、
  // 110 都一样），1.2 倍那一行就是 57.12（36pt）／38.16（24pt）＝ 1.2 × 1.3222 × 字号。
  // Word 对缩放的 run 走另一条度量路径。先前写的 1.35 正是素 run 的数，可本包只在
  // 那两行压 90% 字宽处用新魏，所以存缩放那一档；上升部同理，见 ascent-coefs。
  // 字体文件的 hhea 1.036、win 1.017、typo 1.144 哪个都对不上，照抄不得
  xinwei: 1.3218,
  latin: 1.15, // 纯西文段落：这一行没有汉字，行高只有 Times 参与
  // *段落标记那一格*：空段的高按 ¶ 的字体算，¶ 取 w:rFonts 的 ascii 槽（Times），
  // 与 latin 同一个数。分开写是因为 latin-line-height 那一档（住页面设置里，见 src/layout/resolve.typ 的 fold）
  // 关掉时把 latin 折回中文行高，而空段（src/paragraph/enter.typ）是 Word 的段落标记
  // 机制，不是「英文用不用自然行高」的事，不能跟着动。
  ascii: 1.15,
)
#let natural-default = 1.296875

// 上升部不是纯比例，是 系数 × 字号 + 0.082pt。常数项那 0.082 是十八个字号
// （9 到 60pt）各量一次首行基线、在正负 0.12pt 的量化窗口下扫参数平面逼出来的
// ——「上升部 = 系数乘字号」这个模型无解，加上常数项才只剩唯一解。
//
// *系数按字体分，这一条我们比 hithesis 多走一步。* hithesis 一律用 1.008，
// 并记着「纯西文的段落因此会比 Word 宽一点点，英文摘要与英文目录受影响，
// 先记着」。我们把 Times 那一档量出来了：造一份标定 docx（每个西文行前面放一行
// 12pt 宋体做基准，八个字号 9–24pt），用 *Word 本身*转 PDF 再量步进，
// 减掉基准行的行深就是西文的上升部：
//
//   字号   9     10.5   12     14     16     18     22     24
//   上升部 8.386 9.866 11.366 13.146 15.116 16.866 20.616 22.366
//
// 常数项固定成 0.082（与中易共用）后拟合出 0.93261，最大残差 0.112——
// 与自由拟合的 0.93064/+0.116（残差 0.109）等价，所以两个字体只有系数不同，
// 常数项是同一个。18pt 处算 16.866，而封面页上独立量到的是 16.84，两条
// 互不相干的路子得同一个数。
#let ascent-coefs = (
  songti: 1.008, heiti: 1.008, kaishu: 1.008,
  fangsong: 1.008, lishu: 1.008,
  // *新魏不跟中易那一档*：造一份探针 docx（六个字号 9–48pt、单倍行距、
  // 每档三段），拿 Word 导成 PDF 逐段量首行基线与步进，反推上升部
  //
  //   字号    9      12     18     24     36     48
  //   上升部  8.64   11.28  17.04  22.80  34.08  45.60
  //
  // 常数项固定成 0.082（与中易共用）后拟合出 0.9443，最大残差 0.12——正是 Word
  // 落笔的量化窗口。写 1.008 的话小初（36pt）那一行的基线要低 2.3，深圳本科
  // 首页的校名与文种整体就掉下去。
  //
  // *可那份探针是素 run；本包用新魏的两行（深圳本科首页校名与文种）带着
  // w:w="90" 字宽缩放，Word 对缩放的 run 走另一条度量路径*：行高从 1.35 变成
  // 1.3222（见 natural-coefs），上升部也跟着缩。直接从原件反推：勾选行（固定值
  // 19pt，基线在 0.8h，Δ60 的变体验实到 0.00）→ 二号空段（复制一个空段校名下移
  // 43.68，就是它的高）→ 校名基线，80.71 − 3.8 − 43.68 ＝ 33.23 ＝ 0.9208 × 36 ＋
  // 0.082。只量了 36pt 带缩放这一档——新魏别处不用，够了；素 run 要用的话是 0.9443
  xinwei: 0.9208,
  latin: 0.93261,
  ascii: 0.93261, // 同 latin，理由见 natural-coefs 那一条
)
#let ascent-default = 1.008
#let ascent-const = 0.082pt

// 等宽字体（代码）的单倍行高与上升部，按家族名查，*Word 量的*：造探针 docx（三种等宽字体
// × 9～14pt 六档、单倍行距、不贴网格，每档四段），Word 导 PDF 量基线步进，Word 按 1/300 英寸
// 量化所以逐档在 ±0.01 内抖，取的是各档的均值：
//
//   Consolas     10.56 / 11.76 / 12.24 / 12.96 / 14.16 / 16.32   → 1.1709
//   Menlo        10.56 / 11.52 / 12.24 / 12.72 / 13.92 / 16.32   → 1.1641
//   Courier New  10.08 / 11.28 / 12.00 / 12.48 / 13.68 / 15.84   → 1.1328
//
// 三个数与字体表 hhea 的「上升部 ＋ 下降部 ＋ 行间隙」/upm 一位不差（Consolas 1521+527+350、
// Menlo 1901+483+0、Courier New 1705+615+0，upm 都是 2048）——Times 那档量出来的 1.15 也正是
// 1825+443+87 ＝ 2355/2048。上升部照 Times 那次的结论：行间隙整个落在上面，＝ (hhea 上升部
// ＋ 行间隙)/upm，再加 ascent-const；Times 这么算是 0.9336，标定值 0.93261。
//
// DejaVu Sans Mono 本机没有、Word 里也不常见，按字体表存（1901+483+0，与 Menlo 同一副度量）。
// 表里没有的等宽字体，Typst 只读得到上升部与下降部（text 的 "ascender" / "descender"），读不到
// 行间隙，就按那两项之和算，见 src/fonts/resolve.typ 的 mono-metrics
#let mono-metrics = (
  "Consolas": (natural: 1.1709, ascent: 0.9136),
  "Menlo": (natural: 1.1641, ascent: 0.9282),
  "Courier New": (natural: 1.1328, ascent: 0.8325),
  "DejaVu Sans Mono": (natural: 1.1641, ascent: 0.9282),
)

// 下划线：线心到基线的距离、线宽——Word 画的。深圳本科报告首页那张表的线是格里那串
// 空格的下划线，填了字就是字的下划线，所以线跟着*这一行的字体*走（见
// iota-hit/src/pages/report/shenzhen/cover.typ 的 ruled）。
//
// *西文照字体的 post 表*：线顶 ＝ −underlinePosition，线宽 ＝ underlineThickness，线心
// 就是两者折出来的。Times New Roman 是 −223/2048 与 100/2048；拿 Calibri、Arial、Times
// 各在 18、36 磅排带下划线的段，Word 导出的 PDF 里线顶、线宽都逐档对上各自的 post 值
// （按 1/300 英寸取整）。Typst 读不到 post 表，所以这两个数存在这儿——是字体自己的度量。
//
// *中文字 Word 不照 post 表*：中易六副字的 post 都写着 −22/256，Word 画的不是；把
// 西文槽换成 Calibri／Arial 也不跟着变。黑体、宋体、楷体各排 8～48 磅十六个字号量下来，
// 线心 ＝ 1/8 em ＋ 0.5 磅，三副字一样、误差都在取整单位 0.24 之内；线宽照 post 表的
// 12/256（Word 画出来与 Times 那一档同样取整到 0.72／0.96）。这一条与上面 ascent-coefs
// 里那个 1.008 同类：是 Word 对这些字的处理，不是字体表——那 0.5 磅在小字号上占到
// 线心的两成，去掉它 18 磅那一档就差 0.4，写不成纯 em。
#let underlines = (
  latin: (center: (223 + 50) / 2048 * 1em, thickness: 100 / 2048 * 1em),
  cjk: (center: 1em / 8 + 0.5pt, thickness: 12 / 256 * 1em),
)

// Word 固定值模式：基线在盒顶下方 0.8 倍盒高，与网格开关无关。
#let exact-first-ratio = 0.8

// 中易宋体全字符集 20992 个汉字的墨迹高度实测均值，视觉白换基线距用。
// 注意这量的是墨迹不是 em 框，与 OpenType 的 hhea.lineGap 定义不同。
#let ink-height = 0.9050

// 中文字号表。*名字用拼音*——「五号」「小四」是中文排版自己的一套刻度，
// 英文里没有对应的词（point size 说的是另一件事），拿 font-sizes 那种译名反而
// 认不出来。用户那一头写 zihao.wuhao，与 songti / heiti / ccwd 同一个路子。
#let zihao = (
  chuhao: 42pt, xiaochu: 36pt,
  yihao: 26pt, xiaoyi: 24pt,
  erhao: 22pt, xiaoer: 18pt,
  sanhao: 16pt, xsanhao: 15.9pt, xiaosan: 15pt,
  sihao: 14pt, xiaosi: 12pt,
  wuhao: 10.5pt, xiaowu: 9pt,
  liuhao: 7.5pt, xiaoliu: 6.5pt,
  qihao: 5.5pt, bahao: 5pt,
)

// 正文下划线的位置与粗细，*写死，不留 auto*。auto 读的是那一段字所用字体的 post
// 表，同一行里宋体与 Times 两截错开（12pt 上 1.032 对 1.742），而 Word 是*一个 run
// 一条线*，混排的 run 也只画一条。
//
// 数是自己造 docx 量的：中易宋体 + Times New Roman，纯汉字、纯西文、数字、空格、混排
// 五种 run 各加下划线，24 / 48 / 96pt 三档，macOS Word 导出 PDF（大字号是为了躲开
// Word 输出坐标 1/300 英寸的取整）。西文、数字、空格、混排四种 run 三档全是
// *线心在基线下 0.135em、粗 0.050em*；纯汉字 run 在 0.1275～0.145em 之间随字号晃，
// 那是 Word 自己按设备像素取整，不另设一档。
//
// *与报告封面那对数不是一回事*：封面填空线量自学校 Windows 排的表单 PDF（三号
// 空格 run：线心 0.155em、粗 0.09em），粗细差一倍——平台不同、对象不同，各用各的，
// 见 iota-hit/src/pages/report/cover.typ。正文这一对没有 Windows 那边的实测，手上有的话再校。
//
// Typst 的 offset 指线心（实测 12pt 上 offset 0.135em 线心正落在基线下 1.620）。
#let underline-offset = 0.135em
#let underline-stroke = 0.05em
