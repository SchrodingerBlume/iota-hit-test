// 字体角色、预设与 Word 度量常数。解析逻辑见 resolve.typ。

// 楷体_GB2312 与隶书是两副真字，不是别名。
#let zh-roles = (
  "songti", "heiti", "kaishu", "kaishu-gb2312", "fangsong", "lishu", "xinwei",
)
#let en-roles = ("serif", "sans", "mono")
/// 全部字体角色：中文角色、西文角色与 `math`。
/// -> array
#let roles = zh-roles + en-roles + ("math",)

/// 字体预设：`windows`、`macos`、`founder`、`webapp`、`typst`、`fandol`，每档给出各角色的字体家族。
/// 未写的角色继承 `windows` 档。
/// -> dictionary
#let presets = (
  windows: (
    songti: "SimSun", heiti: "SimHei", kaishu: "KaiTi", fangsong: "FangSong",
    kaishu-gb2312: "KaiTi_GB2312", lishu: "LiSu",
    xinwei: "STXinwei",
    serif: "Times New Roman", sans: "Arial", mono: "Consolas",
    math: "Cambria Math",
  ),
  macos: (
    songti: "Songti SC", heiti: "Heiti SC",
    kaishu: "Kaiti SC", fangsong: "STFangsong",
    serif: "Times New Roman", sans: "Arial", mono: "Menlo",
    math: "STIX Two Math",
  ),
  founder: (
    songti: "FZShuSong-Z01", heiti: "FZHei-B01",
    kaishu: "FZKai-Z03", fangsong: "FZFangSong-Z02",
    serif: "Times New Roman", sans: "Arial", mono: "DejaVu Sans Mono",
    math: "TeX Gyre Termes Math",
  ),
  webapp: (
    songti: "Noto Serif CJK SC", heiti: "Noto Sans CJK SC",
    kaishu: "TW-MOE-Std-Kai", fangsong: "Noto Serif CJK SC",
    serif: "TeX Gyre Termes", sans: "TeX Gyre Heros", mono: "DejaVu Sans Mono",
    math: "TeX Gyre Termes Math",
  ),
  typst: (
    songti: "Noto Serif CJK SC", heiti: "Noto Sans CJK SC",
    kaishu: "TW-MOE-Std-Kai", fangsong: "Noto Serif CJK SC",
    serif: "Libertinus Serif", sans: "TeX Gyre Heros", mono: "DejaVu Sans Mono",
    math: "New Computer Modern Math",
  ),
  fandol: (
    songti: "FandolSong", heiti: "FandolHei",
    kaishu: "FandolKai", fangsong: "FandolFang",
    serif: "TeX Gyre Termes", sans: "TeX Gyre Heros", mono: "Latin Modern Mono",
    math: "New Computer Modern Math",
  ),
)

// 默认预设必须只引用可用字体，否则带 `covers` 的字体项会整体失效，标点也会落入系统回退字体。
#let default-preset = "windows"

// 名字取自 ElegantBook 的 _uses-traditional-moe-font。
#let hant-only = ("tw-moe-std-kai", "moesongun")

// 行盒不随实际字体变化，因此另以墨迹中心差校正汉字的绘制基线。
// 锚字必须用「国」：100pt 探针中，「口」的墨迹中心是 0.3477em，而「国」「永」「哈」
// 都在 0.361–0.363em。「口」偏矮是字形设计，不能代表字身框的位置。
#let ink-anchor = "国"
// 仅有繁体字形的字体改用「國」作为墨迹探针，避免缺字回退污染测量。
#let ink-anchor-hant = "國"
#let baseline-reference = (
  songti: 0.361328125, heiti: 0.337890625, kaishu: 0.328125, fangsong: 0.341796875,
  kaishu-gb2312: 0.34375, lishu: 0.3046875,
  xinwei: 0.2385,
)

// 中易宋体、楷体、新魏缺少原件所需的字面时，按 Word 的方式合成。
#let fake-roles = (
  bold: ("songti", "kaishu", "kaishu-gb2312", "xinwei"),
  italic: ("songti",),
)

// 伪粗描边为字号的 1/35。docx 导出 PDF 后，48.025pt 与 24pt 分别量得
// 1.3721pt、0.68571pt，均与该比例相符。
#let fake-bold-coef = 1 / 35

// 伪斜的倾角，与 cutix 同源。
#let fake-italic-angle = -18.4deg

// ── Word 标定值 ───────────────────────────────────────────────────

/// 各字体家族在 Word 中的单倍行高系数 `single` 与上升部系数 `ascent`。中文家族与
/// Times、Consolas、Menlo、Courier New 为 Word 实测；其余西文家族读自 hhea 表，`ascent` 只是近似。
/// -> dictionary
#let metrics = (
  "SimSun": (single: 1.296875, ascent: 1.008),
  "SimHei": (single: 1.296875, ascent: 1.008),
  "KaiTi": (single: 1.296875, ascent: 1.008),
  "FangSong": (single: 1.296875, ascent: 1.008),
  "KaiTi_GB2312": (single: 1.296875, ascent: 1.008),
  "LiSu": (single: 1.296875, ascent: 1.008),
  // 这两个数只适用于带 `w:w` 字宽缩放的华文新魏 run。深圳本科原件的两行 36pt
  // 新魏带 `w:w="90"`，1.2 倍行距的基线步进约 57.10pt，反推 single=1.3218；
  // 同一原件反推 ascent=0.9208。素 run 探针得到 1.35 / 0.9443，而字体的 hhea
  // 给出 1.036，三者互不相同。本包只在那两行 90% 字宽处使用新魏；若以后支持
  // 素 run，应另设度量，不能把这里“校正”为 1.35。
  "STXinwei": (single: 1.3218, ascent: 0.9208),
  // Times New Roman 的 ascent 不是只按 hhea 猜的。Word 探针在 9、10.5、12、14、
  // 16、18、22、24pt 下量得上升部 8.386、9.866、11.366、13.146、15.116、
  // 16.866、20.616、22.366pt。固定常数项 0.082pt 后拟合得到系数 0.93261，
  // 最大残差 0.112pt；自由拟合 0.93064x+0.116 的残差几乎相同。这个常数项也
  // 解释了为什么不能把整份上升部写成纯 em。
  "Times New Roman": (single: 1.15, ascent: 0.93261), // Word 量过：1825+443+87，upm 2048
  "Consolas": (single: 1.1709, ascent: 0.9136), // Word 量过：1521+527+350
  "Menlo": (single: 1.1641, ascent: 0.9282), // Word 量过：1901+483+0
  "Courier New": (single: 1.1328, ascent: 0.8325), // Word 量过：1705+615+0
  "DejaVu Sans Mono": (single: 1.1641, ascent: 0.9282), // 读自 hhea：1901+483+0（本机没有，与 Menlo 同一副度量）
  "Calibri": (single: 1.2207, ascent: 0.9537), // Word 量过：hhea 1536+512+452，upm 2048
  "Cambria": (single: 1.1724, ascent: 0.9543), // Word 量过：hhea 1946+455+0
  "Arial": (single: 1.1499, ascent: 0.9428), // Word 量过：hhea 1854+434+67
  "Arial Narrow": (single: 1.1475, ascent: 0.9355), // 读自 hhea：1916+434+0，upm 2048
  "Georgia": (single: 1.1362, ascent: 0.9181), // Word 量过：hhea 1878+449+0
  "Verdana": (single: 1.2153, ascent: 1.0054), // 读自 hhea：2059+430+0，upm 2048
  "Tahoma": (single: 1.2070, ascent: 1.0005), // 读自 hhea：2049+423+0，upm 2048
  "Trebuchet MS": (single: 1.1611, ascent: 0.9390), // 读自 hhea：1923+455+0，upm 2048
  "Garamond": (single: 1.1250, ascent: 0.8618), // 读自 hhea：1765+539+0，upm 2048
  "Book Antiqua": (single: 1.2056, ascent: 0.9233), // 读自 hhea：1891+578+0，upm 2048
  "Palatino Linotype": (single: 1.3491, ascent: 1.0498), // 读自 hhea：2150+613+0，upm 2048
  "Century": (single: 1.2021, ascent: 0.9858), // 读自 hhea：2019+443+0，upm 2048
  "Century Schoolbook": (single: 1.2021, ascent: 0.9858), // 读自 hhea：2019+443+0，upm 2048
  "Segoe UI": (single: 1.3301, ascent: 1.0791), // 读自 hhea：2210+514+0，upm 2048
)
#let ascent-const = 0.082pt

/// 各角色默认按哪个家族取度量：中易系列与 Times New Roman。
/// -> dictionary
#let default-metrics = (
  songti: "SimSun", heiti: "SimHei", kaishu: "KaiTi", fangsong: "FangSong",
  "kaishu-gb2312": "KaiTi_GB2312", lishu: "LiSu", xinwei: "STXinwei",
  latin: "Times New Roman", ascii: "Times New Roman",
)

// 下划线的线心位置与线宽：西文照字体 post 表，中文照 Word 实测。
// -> dictionary
#let underlines = (
  latin: (center: (223 + 50) / 2048 * 1em, thickness: 100 / 2048 * 1em),
  cjk: (center: 1em / 8 + 0.5pt, thickness: 12 / 256 * 1em),
)

// Word 固定值模式：基线在盒顶下方 0.8 倍盒高，与网格开关无关。
#let exact-first-ratio = 0.8

// 中易宋体全字符集 20992 个汉字的墨迹高度实测均值，视觉白换基线距用。
#let ink-height = 0.9050

/// 中文字号表：`chuhao`、`xiaochu`、`yihao`……`bahao`，值为磅。
/// -> dictionary
#let zihao = (
  chuhao: 42pt, xiaochu: 36pt,
  yihao: 26pt, xiaoyi: 24pt,
  erhao: 22pt, xiaoer: 18pt,
  sanhao: 16pt, xiaosan: 15pt,
  sihao: 14pt, xiaosi: 12pt,
  wuhao: 10.5pt, xiaowu: 9pt,
  liuhao: 7.5pt, xiaoliu: 6.5pt,
  qihao: 5.5pt, bahao: 5pt,
)

// 正文下划线的位置与粗细，写死，不留 auto。
#let underline-offset = 0.135em
#let underline-stroke = 0.05em

// 各数学字体中使积分号直立的样式集。目前不发出（见上），仅保留标定结果。
// -> dictionary
#let integral-features = (
  "XITS Math": ("ss08",),
  "STIX Two Math": ("ss08",),
  "New Computer Modern Math": ("ss02",),
)
