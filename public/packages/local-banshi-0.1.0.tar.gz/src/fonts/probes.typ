// 开机探针：问字体几个 Typst 自己答不了的问题——有没有真粗体、真斜体，字画在基线之上多高
// （视觉矫正的量），以及 run 边界丢不丢字距（上游 #5353，修了这里自动归零）。答案记进 state，
// 各处规则在 context 里读。从 resolve.typ 搬来：那边只管「字体表 → 角色 → 字体」的解析。
#import "./presets.typ": hant-only, ink-anchor, ink-anchor-hant, baseline-reference, zh-roles, en-roles, roles

// 这个家族是不是只有繁体面（探针量墨迹时锚点不同）。与 resolve.typ 那份同一个判据
#let is-hant-only(family) = lower(str(family)) in hant-only

// ── 探针：问字体两个问题 ──────────────────────────────────────────
//
// Typst 自己*从不合成*粗体与斜体：要的那一面没有就静默换成最近的一面
// （文档原话：weight 取「closest in weight」，style 取 normal）。所以「这个字体
// 有没有真粗」问不出来——除非自己量。
//
// 办法是把字重推到 701 再量*墨迹*（top-edge / bottom-edge 取 "bounds"）：
// 动了就是换到了另一面，没动就是回落到了同一面。做法与 cutix 同源。
//
// *要在 context 里调*
#let _PROBE-SIZE = 100pt
#let _EPS = 0.01
#let _cjk-probe = ("一", "二")

// *只问这一个家族，且关掉回落*。带着整串字体去问是问不出来的：要的字重
// 这个家族没有，Typst 会跨家族回落到*别人的*粗体面，墨迹一动就被判成
// 「有真粗」（实测宋体就是这么误判的）。
#let _ink(body, family, weight, style: "normal") = {
  let m = measure(text(
    font: (family,), fallback: false, size: _PROBE-SIZE, weight: weight, style: style,
    top-edge: "bounds", bottom-edge: "bounds", body,
  ))
  (m.width.pt(), m.height.pt())
}

// 这个家族有没有真粗体
#let has-real-bold(family) = _cjk-probe.any(c => {
  let a = _ink(c, family, "regular")
  let b = _ink(c, family, 701)
  calc.abs(a.at(0) - b.at(0)) > _EPS or calc.abs(a.at(1) - b.at(1)) > _EPS
})

// 这个家族有没有真斜体面。同一个办法：把 style 推到 italic 再量墨迹——Typst 也不合成
// 斜体，没有斜体面就静默用常规面，墨迹不动
#let has-real-italic(family) = _cjk-probe.any(c => {
  let a = _ink(c, family, "regular")
  let b = _ink(c, family, "regular", style: "italic")
  calc.abs(a.at(0) - b.at(0)) > _EPS or calc.abs(a.at(1) - b.at(1)) > _EPS
})

// 这个家族排不排得出汉字。
//
// *关掉回落再量*——缺字时 Typst 会静默换字体，量出来照样有宽度，问不出
// 「这个家族在不在」。关掉之后缺字宽度是 0（实测装了的 KaiTi / SimSun 出 200pt，
// 没装的 TW-MOE-Std-Kai 出 0pt）。
//
// *代价*：家族真的不存在时 Typst 会打一条 unknown font family 的警告，
// 这个探测会把它提前引出来——今天只有排到那一处才出现，往后每篇都会出现一次。
#let family-usable(family) = {
  measure(text(font: family, fallback: false, size: _PROBE-SIZE)[一二]).width > 0pt
}

// 小于这个就当没有。中易那四档自己探出来与基准*完全相等*，本该得 0；
// 可基准若写成四舍五入的 0.36133，差出来的 1.9e-6 em 也不是 0，那两条规则照发，
// 中西文的基线就差了个微米——量基线的那一步当场把一行看成两行（实测
// check-mixed 报「步进 -0.000040」）。基准取精确值之后这一步用不上了，
// 留着是给用户自己指定的家族兜底：0.001em 在 12pt 下是 0.012pt，肉眼与打印
// 都不存在，不值得为它多发两条 show 规则。
#let _baseline-eps = 0.001

// 锚字的墨迹中心离基线多高，折成 em。要在 context 里调
#let ink-center(family) = {
  // 只有繁体字形的那几副（教育部标准楷书）没有「国」，量它得用繁体那一个，见 ink-anchor-hant
  let anchor = if is-hant-only(family) { ink-anchor-hant } else { ink-anchor }
  let edge(top, bottom) = measure(text(
    font: (family,), fallback: false, size: _PROBE-SIZE,
    top-edge: top, bottom-edge: bottom, anchor,
  )).height
  (edge("bounds", "baseline") - edge("baseline", "bounds")) / 2 / _PROBE-SIZE
}

// 探测的结果：角色名 → 有没有真粗体。
//
// *在入口探一次，别到处现探*。探针是 measure，会*继承所在上下文*——
// 描边、字体列表、回落开关都继承。先前放在每个 #strong 当场做，于是同一个家族
// 在正文里探出「有真粗」、在别处探出「没有」，正文的粗体被在真粗面上又描了一圈
// （实测 webapp 档下 NotoSerifCJKsc-Bold 上还有一层 stroke_text）。
//
// 由 iota-hit 在函数体里写一次（那里是 context），排版时零成本查表。
#let probes = state("banshi-font-probes", (:))


// *run 边界丢多少字距，开机量一次。* Typst 把文本切成不同样式的 run 分别整形，
// 一个 run 末尾那个字的 tracking 不发（typst/typst#5353，2024-11 报的，维护者确认
// 「样式不同就切成不同的 shaping run，就会这样」，至今 open）。本包在五处补这份丢掉
// 的字距：西文 run 前、行内代码前、行内标记两侧、下划线两端、目录编号后。
//
// *不写死「丢一份」，量出来。* 量「ax」一体排与拆成两个 run 排的宽度差，除以
// 字距，得到丢的份数：现在的 Typst 是 1，上游哪天修了就是 0——五处补偿一起归零，
// 一行不用改，也不会在新版本上把字距补成双份。拆 run 靠两截不同的填色，与上游那条
// issue 里维护者给的复现同一个法子。两次 measure，与上面探真粗体的一个量级。
#let probe-boundary() = {
  let t = 4pt
  let one = measure(text(tracking: t, fill: black)[ax]).width
  let two = measure(text(tracking: t, fill: black)[a] + text(tracking: t, fill: rgb("#000001"))[x]).width
  calc.max(0, calc.min(1, (one - two) / t))
}

// 份数自己一份 state，不挤进 probes 那张按角色分的表——那张表的值是每个角色一条
// 记录（usable / bold / baseline），谁遍历它都按记录读，塞一个数进去就炸
// （iota-hit/tests/demo-ink.typ 先前就是这么红的）。入口与 probes 一起写，见 iota-hit/lib.typ
#let boundary-probe = state("banshi-boundary-loss", 1)

// 补偿量要乘的份数；探针还没写进来的地方（第一页页眉）按现在的 Typst 算
#let boundary-loss() = boundary-probe.get()

// 这一档中文角色*缺粗体面*：家族在这台机器上，而且没有真粗面。要在 context 里调，
// 查的是入口探好的那张表（probe-all），不当场探——当场探会继承上下文（描边、字体列表、
// 回落开关），同一个家族在不同地方答案不一样。
//
// *两个条件都要。* 家族不在时这一档的字由 Typst 的回落排，回落到哪一家我们无从知道，
// 那一家多半有真粗面。两路都问这一句：伪粗那一路（src/fonts/fake.typ 的
// wants-bold-for）缺才描边；latin-bold 那一路（src/styles/rules.typ 的 shows）缺才敢
// 整段 set weight——汉字落空、只有西文换上真粗面。
#let lacks-bold(role) = {
  let p = probes.get().at(role, default: (usable: false, bold: false))
  p.usable and not p.bold
}
// 同一句话问斜体：#emph 那一路缺才敢整段 set style italic（楷体落空、Times 换上真斜体面），
// 见 src/fonts/resolve.typ 的 kaishu
#let lacks-italic(role) = {
  let p = probes.get().at(role, default: (usable: false, italic: false))
  p.usable and not p.italic
}

// 把当前字体表探一遍。要在 context 里调。
//
// *只探吃伪粗的那几个角色*，不是四个中文角色都探。探针关着回落，家族没装
// 就会引出一条 unknown font family 的警告（见 family-usable）——探不吃伪粗的角色
// 是白探一次、白报一条：实测 fandol 那一档本机没装 FandolFang，整篇编译多出
// 一条「unknown font family: fandolfang」，而仿宋从来不吃伪粗。
// fake-roles 往后扩了，这里自动跟上。
#let probe-all(table) = {
  let out = (:)
  for role in zh-roles {
    let family = table.at(role)
    // *家族在不在，要先问一遍。* 不在的时候两次探针都量到 0，两个字重
    // 「一样」，has-real-bold 于是答「没有真粗」——可这一档的字根本不由它排，
    // Typst 早回落到别家去了，而那一家多半有真粗面，描上去就是双重加粗。
    // 实测：fontset 里写一个不存在的家族（No Such Song），探针答「没有真粗」，
    // 正文的加粗落在回落的 SIL-Hei-Med-Jian 上、仍被描了一圈。
    //
    // 这条路不难走到：默认的 fontset "windows" 在没装中易的机器上、模板写的
    // "fandol" 在没装 Fandol 的机器上，都是整档家族缺席。
    let usable = family-usable(family)
    out.insert(role, (
      usable: usable,
      // 家族不在就不必再探，省下的 measure 与 unknown font family 都是白花的。
      // *七个角色都探*，不只吃伪粗那四个：latin-bold 那一路要问「这一档中文字整段
      // set weight 会不会真的变粗」，见上面的 lacks-bold
      bold: if usable { has-real-bold(family) } else { false },
      italic: if usable { has-real-italic(family) } else { false },
      // *视觉矫正量*：把这一档的字挪到 Windows 同角色那一档的高度。
      // 负数是上移。家族不在时给 0——回落到哪一家我们不知道，按名义家族算出来
      // 的矫正量落在别人头上只会更歪。
      baseline: if usable {
        let d = ink-center(family) - baseline-reference.at(role)
        if calc.abs(d) < _baseline-eps { 0pt } else { d * 1em }
      } else { 0pt },
    ))
  }
  out
}
