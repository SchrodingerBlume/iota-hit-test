// 开机探针：问字体几个 Typst 自己答不了的问题；有没有真粗体、真斜体，字画在基线之上多高（视觉矫正的量），以及 run 边界丢不丢字距（上游 #5353，修了这里自动归零）。
#import "./presets.typ": hant-only, ink-anchor, ink-anchor-hant, baseline-reference, zh-roles, en-roles, roles

#let is-hant-only(family) = lower(str(family)) in hant-only

// Typst 自己从不合成粗体与斜体：要的那一面没有就静默换成最近的一面（文档原话：weight 取「closest in weight」，style 取 normal）。
#let _PROBE-SIZE = 100pt
#let _EPS = 0.01
#let _cjk-probe = ("一", "二")

// 这个家族没有，Typst 会跨家族回落到别人的粗体面，墨迹一动就被判成。
#let _ink(body, family, weight, style: "normal") = {
  let m = measure(text(
    font: (family,), fallback: false, size: _PROBE-SIZE, weight: weight, style: style,
    top-edge: "bounds", bottom-edge: "bounds", body,
  ))
  (m.width.pt(), m.height.pt())
}

#let has-real-bold(family) = _cjk-probe.any(c => {
  let a = _ink(c, family, "regular")
  let b = _ink(c, family, 701)
  calc.abs(a.at(0) - b.at(0)) > _EPS or calc.abs(a.at(1) - b.at(1)) > _EPS
})

// 这个家族有没有真斜体面。
#let has-real-italic(family) = _cjk-probe.any(c => {
  let a = _ink(c, family, "regular")
  let b = _ink(c, family, "regular", style: "italic")
  calc.abs(a.at(0) - b.at(0)) > _EPS or calc.abs(a.at(1) - b.at(1)) > _EPS
})

// 关掉回落再量；缺字时 Typst 会静默换字体，量出来照样有宽度，问不出「这个家族在不在」。
#let family-usable(family) = {
  measure(text(font: family, fallback: false, size: _PROBE-SIZE)[一二]).width > 0pt
}

// 小于阈值的基线差视为零，避免舍入误差安装无意义的校正规则。
#let _baseline-eps = 0.001

#let ink-center(family) = {
  let anchor = if is-hant-only(family) { ink-anchor-hant } else { ink-anchor }
  let edge(top, bottom) = measure(text(
    font: (family,), fallback: false, size: _PROBE-SIZE,
    top-edge: top, bottom-edge: bottom, anchor,
  )).height
  (edge("bounds", "baseline") - edge("baseline", "bounds")) / 2 / _PROBE-SIZE
}

// 在入口探一次，别到处现探。探针是 measure，会继承所在上下文；（实测 webapp 档下 NotoSerifCJKsc-Bold 上还有一层 stroke_text）。
#let probes = state("banshi-font-probes", (:))


// 启动时测量文本整形片段边界丢失的字距，用于兼容 typst/typst#5353。
#let probe-boundary() = {
  let t = 4pt
  let one = measure(text(tracking: t, fill: black)[ax]).width
  let two = measure(text(tracking: t, fill: black)[a] + text(tracking: t, fill: rgb("#000001"))[x]).width
  calc.max(0, calc.min(1, (one - two) / t))
}

// 记录（usable / bold / baseline），谁遍历它都按记录读，塞一个数进去就炸。
#let boundary-probe = state("banshi-boundary-loss", 1)

// 补偿量要乘的份数；探针还没写进来的地方（第一页页眉）按现在的 Typst 算。
#let boundary-loss() = boundary-probe.get()

// 仅当字体家族可用且缺少对应字形面时合成粗体或斜体。
#let lacks-bold(role) = {
  let p = probes.get().at(role, default: (usable: false, bold: false))
  p.usable and not p.bold
}
// 同一句话问斜体：#emph 那一路缺才敢整段 set style italic（楷体落空、Times 换上真斜体面），见 src/fonts/resolve.typ 的 kaishu。
#let lacks-italic(role) = {
  let p = probes.get().at(role, default: (usable: false, italic: false))
  p.usable and not p.italic
}

// 只探测需要合成字形且字体可用的角色，避免无意义的 unknown font family 警告。
#let probe-all(table) = {
  let out = (:)
  for role in zh-roles {
    let family = table.at(role)
    let usable = family-usable(family)
    out.insert(role, (
      usable: usable,
      bold: if usable { has-real-bold(family) } else { false },
      italic: if usable { has-real-italic(family) } else { false },
      baseline: if usable {
        let d = ink-center(family) - baseline-reference.at(role)
        if calc.abs(d) < _baseline-eps { 0pt } else { d * 1em }
      } else { 0pt },
    ))
  }
  out
}
