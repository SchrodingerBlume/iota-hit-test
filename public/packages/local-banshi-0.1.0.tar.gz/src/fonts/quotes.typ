#import "../layout/resolve.typ" as _layout
#import "./resolve.typ": boundary-loss
// 「“」「”」「‘」「’」这四个字中易与 Times 都有，中文里该是全宽的中易字形，西文里该是 Times 的窄字形；而它们是\同一个码位，按码位分派（字体的 covers）分不开。

// latin-font 由调用方从角色表的 serif 传进来，不在这里写死家族名。
#let quote-rules(latin-font: ("Times New Roman",), doc) = {
  show smartquote: it => context {
    let l = _layout.current-page-setup()
    let half = if _layout.emulated(l) { l.docgrid.tracking / 2 } else { 0pt }
    let pad = half * boundary-loss()
    {
      set text(font: latin-font, tracking: half)
      it
    }
    h(pad)
  }
  doc
}

// 「℃」U+2103 是 Unicode 的兼容字，兼容分解就是 <square> °C；GB/T 3101与 SI 手册写的也都是「°C」（度符号加大写 C），不是那个方块。
#let unit-rules(doc) = {
  doc
}
