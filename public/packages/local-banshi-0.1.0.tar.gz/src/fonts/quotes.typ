#import "../layout/resolve.typ" as _layout
#import "./resolve.typ": boundary-loss
// 弯引号归谁，由源码怎么打决定，不由码位决定。
//
// 「“」「”」「‘」「’」这四个字中易与 Times 都有，中文里该是全宽的中易字形，
// 西文里该是 Times 的窄字形——而它们是\同一个码位，按码位分派（字体的 covers）
// 分不开。分得开的是\来路：源码里字面打的弯引号是文本，而傻引号
// U+0022/U+0027 经 Typst 的智能引号转出来的是 smartquote 元素。
//
//   源码打弯引号 “...”   → 文本，走 covers → 中易，全宽，在字符网格上
//   源码打傻引号 "..."   → smartquote 元素 → 被下面这条 show 换成西文字体
//
// 一句话：**要中文引号就打弯引号，要西文引号就打傻引号**，不用管段落是中是英。
//
// *为什么 show 在 smartquote 上而不在 regex 上。* new-neu-thesis 的做法是
// \verb|show regex("[‘’“”]")| 把弯引号拉回宋体（src/layout/final.typ），
// 分派的依据同样是来路——智能引号出来的不是文本，逃得过 regex。但那样每个
// 引号要付字符网格的代价：Typst 在*任何* text run 的边界都会丢掉尾部的
// tracking，而 show regex 就是在造边界。实测把 \verb|show regex| 换成恒等式
// \verb|it => it| 照样丢——不是换字体造成的，是边界本身。一对引号两侧合计
// 少 0.909pt，「汉“」从 12.4543 掉到 12.0000，格子就散了。
//
// 挂在 smartquote 上则一个字也不碰字面弯引号，中文那一路的网格分毫不动；
// 边界只落在傻引号那一路，而那本来就是西文引号，不占网格的格子。
//
// 另外 raw 里不做智能引号，所以代码块天然不受影响，不用再写豁免。

// latin-font 由调用方从角色表的 serif 传进来，不在这里写死家族名。
//
// *两侧补回边界丢的字距。* 智能引号是元素，前后各一道 run 边界，边界前那个字的
// 字距丢掉（typst/typst#5353）。引号本身是西文字，照 Word 吃半格；前面那个字多半也是
// 西文（said "hello"），丢的也是半份——两侧各补半份，补多少份由开机探针定（见
// src/fonts/probes.typ 的 probe-boundary），上游修了自动归零。没有字符网格的段
// （报告、代码）半份是 0，什么都不补。
//
// *不写 weak*：弱间距紧挨着空格时是取代空格，不是取较大者（实测「码 `abc`」
// 里的空格被吃掉），而开引号前面几乎总有个空格。代价是段尾的闭引号后多一段看不见的空。
// 前面若是汉字（中文里打了傻引号），它丢的是整份，这里只补半份；中文语境该打弯引号，
// 那一路走字面文本不造边界。
//
// *引号前面那一份补不得*——补了引号就转错向。Typst 判开引号还是闭引号看的是
// *紧挨着的前一个字符*，在它前面插任何东西（h、box、零宽空格都一样）都会让它
// 判成「句首」：实测 \verb|Master's| 排成 Master\u{2018}s、\verb|"quoted"| 两头都是开引号。
// 每个英文档里的撇号都要错，而补的那一份是 0.227——两害相权，前面那一份不补，
// 只补引号自己丢的那一份（它后面那道边界）。逐档量在 iota-hit/tests/check-quotes.py。
#let quote-rules(latin-font: ("Times New Roman",), doc) = {
  show smartquote: it => context {
    // 引擎自己画字符网格时这半份不发，见 src/layout/resolve.typ 的「断行引擎」
    let l = _layout.current-page-setup()
    let half = if _layout.emulated(l) { l.docgrid.tracking / 2 } else { 0pt }
    let pad = half * boundary-loss()
    {
      set text(font: latin-font, tracking: half)
      it
    }
    h(pad)
  }
  doc
}

// 单位符号里的*方块兼容字*拆开排。
//
// 「℃」U+2103 是 Unicode 的*兼容字*，兼容分解就是 <square> °C；GB/T 3101
// 与 SI 手册写的也都是「°C」（度符号加大写 C），不是那个方块。
//
// *拆开是唯一能让它走西文字体的办法*：Times New Roman *根本没有*
// U+2103 这个字形（实测 ° Ω × 都有，℃ ℉ 没有），所以在字体表里给它挂再多
// covers 也只会落回宋体的全宽方块。拆成 ° 与 C 之后两个字符 Times 都有，
// 自然就归西文了，行盒也照旧算西文（° 与 C 都在 latin-run 的字符集里）。
//
// *与范例不同。* 本科范例第 14 页那条表题里的「℃」run 写着
// w:hint="eastAsia"，Word 排的是宋体全宽——与乘号那一条同一类情形（见
// src/fonts/resolve.typ 的 cjk-first）。这里按*用户的要求*取西文那一头。
//
// ℉ 一并拆：同一个字符块、同一个毛病、同一个解法，只拆一个反而不一致。
#let unit-rules(doc) = {
  //show "℃": [°C]
  //show "℉": [°F]
  doc
}
