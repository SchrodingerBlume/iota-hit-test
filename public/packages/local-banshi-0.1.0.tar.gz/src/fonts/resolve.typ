// 字体解析与探针。预设、角色表与标定常数只放值，住在 src/fonts/presets.typ；这里是拿它们干活的机制：resolve、probe-all、baseline-rules 与四个中文字族的入口。

#import "../errors.typ" as _errors
#import "../runs.typ": cjk-run, role-features, role-tags, latin-run as _latin-run, latin-slot-run
#import "../options.typ" as _options
// 重新导出 probes.typ 的探针接口，保持 `fonts.probes` 等既有访问路径。
#import "./probes.typ": probes, probe-boundary, boundary-probe, boundary-loss, lacks-bold, lacks-italic, probe-all, family-usable, has-real-bold, has-real-italic, ink-center
#import "./presets.typ": (
  presets, default-preset, hant-only, zh-roles, en-roles, roles,
  ink-anchor, ink-anchor-hant, baseline-reference, fake-roles, fake-bold-coef, fake-italic-angle,
  metrics as metrics-presets, default-metrics, ascent-const, exact-first-ratio,
)

// 字号照 fontspec 的 `Scale=MatchLowercase`，按小写 x 的实际墨迹高度匹配，再量化到
// Word 的半磅字号格。不能用 cap-height 代替：Typst 自带的 DejaVu Sans Mono 没有
// 有效 sxHeight，读取 x-height、cap-height、ascender 都得到 0.7598；按这个数缩放会
// 把正文代码压到 7pt。实际测量字形 `x` 不依赖字体是否填写该度量。
#let x-height(family) = (
  measure(text(font: family, size: 100pt, top-edge: "bounds", bottom-edge: "baseline")[x]).height / 100pt
)
#let mono-size(size, serif, mono) = calc.round((size * x-height(serif) / x-height(mono)) / 0.5pt) * 0.5pt

// 等宽字体的单倍行高与上升部（每 em）：表里有的取表里的（src/fonts/presets.typ 的 metrics），没有的按 Typst 读得到的上升部与下降部之和算；差的只是行间隙，多数等宽字体是 0。
#let mono-line(mono) = {
  let family = if type(mono) == array { mono.first() } else { mono }
  let known = metrics-presets.at(str(family), default: none)
  if known != none { return known }
  let edge(top, bottom) = measure(text(font: mono, size: 100pt, top-edge: top, bottom-edge: bottom)[x]).height / 100pt
  (single: edge("ascender", "descender"), ascent: edge("ascender", "baseline"))
}

// 代码那一档的 text 设定：字号照 mono-size，行高是等宽字体自己的单倍行高（Word 的「单倍模型（src/paragraph/spacing.typ 的 _ascent-of），只是系数换成等宽字体的。
#let mono-text(size, serif, mono) = {
  let s = mono-size(size, serif, mono)
  let m = mono-line(mono)
  let ascent = m.ascent * s + ascent-const
  (size: s, top-edge: ascent, bottom-edge: -(m.single * s - ascent))
}

// `mono-text-em` 使用相对单位，以便 show-set 能作用于代码包重建后的内容。
#let mono-edges-em(mono, line-spacing) = {
  let m = mono-line(mono)
  let ls = if line-spacing == "single" { 1.0 } else if line-spacing == "double" { 2.0 } else { line-spacing }
  if type(ls) == dictionary and "exactly" in ls {
    let box = ls.at("exactly")
    (top-edge: exact-first-ratio * box, bottom-edge: -(1 - exact-first-ratio) * box)
  } else {
    let ls = if type(ls) in (int, float) { float(ls) } else { 1.0 }
    (
      top-edge: m.ascent * 1em + ascent-const,
      bottom-edge: -(ls * m.single - m.ascent) * 1em + ascent-const,
    )
  }
}

// 全篇那一条给单倍，1.25 那一份由我们自己排代码行时再加（iota-hit/src/figure/kinds/raw.typ 的_lines）。
#let mono-text-em(body, serif, mono, line-spacing: 1) = {
  let k = mono-size(body, serif, mono) / body / 0.8
  (size: k * 1em, ..mono-edges-em(mono, line-spacing))
}

// 这副楷体是不是只有繁体字形，查 src/fonts/presets.typ 的 hant-only。
#let is-hant-only(family) = lower(str(family)) in hant-only

// universal-hit-thesis 的 宋体: ("Times New Roman", "SimSun") 就没写，它的中文引号是 Times 的窄字形。
#let latin-entries(family, em-dash: "cjk") = (
  (name: family, covers: regex(if em-dash == "latin" { "[\u{2013}\u{2014}]" } else { "\u{2013}" })),
  (name: family, covers: "latin-in-cjk"),
)

// 箭头和几何符号在 Word 中文字体槽中按全宽排版，须在 `latin-in-cjk` 之前由中文字体认领。
// 原始对照中，「↑」在 Word 里是 SimSun 12.0pt，本包未抢占时落入 Times，只有
// 6.0pt；「□」在 Word 里是 SimSun 18.0pt，落入 Times 时只有 10.872pt。
// 这两组测量值是 `cjk-first` 必须位于西文字体项之前的依据。
#let cjk-first = regex("[\u{00D7}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}]")

// 汉字先由本角色的中文字体认领，再轮到西文。
#let cjk-scripts = regex(
  "[\p{Han}\p{Hiragana}\p{Katakana}\p{Hangul}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}]"
)
#let cjk-claim(family) = if type(family) == array {
  family.map(f => (name: f, covers: cjk-scripts))
} else { ((name: family, covers: cjk-scripts),) }

// 楷体_GB2312、隶书、新魏三个角色有回落链，别的角色只有自己。
#let role-chain(r, role) = {
  let own = r.at(role)
  let head = if type(own) == array { own } else { (own,) }
  let kai = if is-hant-only(r.kaishu) { () } else { (r.kaishu,) }
  let tail = if role == "kaishu-gb2312" { (r.kaishu,) }
    else if role in ("lishu", "xinwei") { kai + (r.songti,) }
    else { () }
  head + tail.filter(f => f != none)
}

// 西文那三个角色（serif / sans / mono）的字体表。
#let latin-table(r, role) = (
  (name: r.songti, covers: cjk-first), ..cjk-claim(r.songti), r.at(role), r.songti,
)

// 汉字要有归宿。 先前 mono 这个角色根本没人用（全项目一处 set raw 都没有），代码里的中文落到 Typst 的全局兜底上；实测排出来是 LiSu（隶书），随手抓的。
#let mono-table(r) = (
  ..(if type(r.mono) == array { r.mono } else { (r.mono,) }),
  r.fangsong,
  ..(if is-hant-only(r.kaishu) { () } else { (r.kaishu,) }),
  r.songti,
)


#let _check(value) = {
  if type(value) == str {
    assert(
      value in presets,
      message: _errors.expected-one-of(presets.keys(), value),
    )
    return presets.at(value)
  }
  if type(value) != dictionary {
    panic("expected string or dictionary, found " + str(type(value))
      + " (a preset name, or a table of font roles)")
  }
  let stray = value.keys().filter(k => k not in roles)
  if stray.len() > 0 {
    panic("unexpected font role: " + stray.join(", "))
  }
  value
}

// auto ＝ 不写 ＝ 默认档，与包里别处的三态同义；先前 auto 会一路撞进_check 报「expected string or dictionary, found auto」，而默认档名同时被 iota-hit/lib.typ抄了一份。
#let _metrics(local) = {
  if type(local) != dictionary {
    panic("metrics: expected a dictionary (role -> family name or (single:, ascent:)), found " + repr(local))
  }
  for role in local.keys() {
    if role not in default-metrics {
      panic("metrics: unknown role " + repr(role) + "; " + _errors.expected-one-of(default-metrics.keys(), role))
    }
  }
  let of(role) = {
    let v = local.at(role, default: default-metrics.at(role))
    if type(v) == str {
      if v not in metrics-presets {
        panic(
          "metrics." + role + ": no numbers for " + repr(v) + "; "
            + _errors.expected-one-of(metrics-presets.keys(), v)
            + " (or write (single: …, ascent: …) measured from Word, see tools/font-metrics.py)",
        )
      }
      metrics-presets.at(v)
    } else if type(v) == dictionary and v.keys().sorted() == ("ascent", "single") and v.values().all(x => type(x) in (int, float)) {
      (single: v.single, ascent: v.ascent)
    } else {
      panic("metrics." + role + ": expected a family name or (single: …, ascent: …), found " + repr(v))
    }
  }
  default-metrics.keys().map(role => (role, of(role))).to-dict()
}

/// 解析字体预设或角色字典，并生成用于排版和度量的字体表。
/// `auto` 使用默认预设；传入字典时在默认预设上覆盖同名角色。
/// -> dictionary
#let fontset(value: auto, em-dash: "cjk", metrics: (:)) = {
  let value = if value == auto { default-preset } else { value }
  let r = presets.at(default-preset) + _check(value)
  let metrics = _metrics(metrics)
  let latin = latin-entries(r.serif, em-dash: em-dash)
  let table(role) = {
    let chain = role-chain(r, role)
    ((name: r.songti, covers: cjk-first), ..cjk-claim(chain), ..latin, ..chain)
  }
  (
    songti: table("songti"),
    heiti: table("heiti"),
    kaishu: table("kaishu"),
    kaishu-gb2312: table("kaishu-gb2312"),
    fangsong: table("fangsong"),
    lishu: table("lishu"),
    xinwei: table("xinwei"),
    serif: latin-table(r, "serif"),
    sans: latin-table(r, "sans"),
    mono: mono-table(r),
    math: r.math,
    latin: latin,
    em-dash: em-dash,
    families: r,
    metrics: metrics,
  )
}

// 做法学自 new-neu-thesis 与 ElegantBook 的 current。
#let fontset-state = state("banshi-fontset", fontset())

// 文档级 show rule 只校正含汉字的文本整形片段，并按当前字体查找基线偏移。
#let baseline-rules(doc) = {
  let role-of(f, families) = {
    let xs = if type(f) == array { f } else { (f,) }
    for x in xs {
      let name = if type(x) == dictionary {
        if "covers" in x { continue }
        x.at("name", default: none)
      } else { x }
      if name == none { continue }
      for role in zh-roles {
        let fam = families.at(role, default: none)
        if type(fam) == str and lower(fam) == lower(name) { return role }
      }
    }
    none
  }
  let tagged(fs) = {
    if type(fs) != dictionary { return none }
    for (role, tag) in role-tags { if fs.at(tag, default: 0) == 1 { return role } }
    none
  }
  show cjk-run: it => context {
    let role = tagged(text.features)
    if role == none { role = role-of(text.font, fontset-state.get().families) }
    let shift = if role == none { 0pt } else {
      probes.get().at(role, default: (baseline: 0pt)).baseline
    }
    if shift == 0pt { it } else {
      set text(baseline: shift)
      it
    }
  }
  doc
}

// 不写家族名；用楷体的地方写 kaishu，换字体档时自动全线跟上。

#let _use(role, latin, body) = context {
  assert(
    latin in en-roles,
    message: _errors.expected-one-of(en-roles, latin)
      + " (to name a family directly, set the font on text instead)",
  )
  let cur = fontset-state.get()
  let f = cur.families
  let chain = role-chain(f, role)
  set text(
    font: (
      (name: f.songti, covers: cjk-first),
      ..cjk-claim(chain),
      ..latin-entries(f.at(latin), em-dash: cur.at("em-dash", default: "cjk")),
      ..chain,
    ),
    features: role-features(role),
  )
  body
}

/// 使用当前字体表的宋体角色。
/// -> content
#let songti(latin: "serif", body) = _use("songti", latin, body)
/// 使用当前字体表的黑体角色。
/// -> content
#let heiti(latin: "serif", body) = _use("heiti", latin, body)
/// 使用当前字体表的楷体角色；字体不可用时可按文档选项合成斜体。
/// -> content
#let kaishu(latin: "serif", italic: false, body) = context {
  let gate = _options.option-of("fake-italic")
  let family = fontset-state.get().families.kaishu
  let slant(role, body) = if not italic { body } else if lacks-italic(role) {
    set text(style: "italic")
    body
  } else {
    show latin-slot-run: set text(style: "italic")
    body
  }
  if gate != true and family-usable(family) {
    _use("kaishu", latin, slant("kaishu", body))
  } else if gate == false {
    _use("songti", latin, slant("songti", body))
  } else {
    box(skew(ax: fake-italic-angle, reflow: false, {
      show latin-slot-run: r => box(skew(ax: -fake-italic-angle, reflow: false, r))
      _use("songti", latin, slant("songti", body))
    }))
  }
}
#let fangsong(latin: "serif", body) = _use("fangsong", latin, body)

/// 按角色名生成可传给 `text(font:)` 的字体列表。
/// -> array
#let font(role, families, latin: "serif", em-dash: "cjk") = {
  if role in en-roles {
    latin-table(families, role)
  } else {
    let chain = role-chain(families, role)
    (
      (name: families.songti, covers: cjk-first),
      ..cjk-claim(chain),
      ..latin-entries(families.at(latin), em-dash: em-dash),
      ..chain,
    )
  }
}
