// 「几个字」的度量：chars（Word 段落对话框的「字符」单位：字号加字符网格增量）、halfspace（半格）、
// resolve-chars（长度或 (chars: n)）、h-chars（正文里空几个字）。

#import "../paragraph/spacing.typ": no-docgrid
#import "./resolve.typ" as _layout
#import "./state.typ": page-setup-state

/// 返回 Word“n 字符”对应的长度。一个字符等于当前字号加字符网格增量，不一定是
/// `1em`。省略 `n` 时返回一个字符；`layout: auto` 读取当前节。
///
/// 用于尺寸参数，如 `first-line-indent: chars(2)`。正文中插入空白应使用 `h-chars`。
/// -> length
#let chars(..n, layout: auto) = {
  let l = if _layout.is-page-setup(layout) {
    layout
  } else {
    let s = page-setup-state.get()
    if s == none { no-docgrid } else { _layout.merge-page-setup(s, layout) }
  }
  let count = n.pos().at(0, default: 1)
  count * 1em + count * l.docgrid.tracking
}

// Word 文档网格中的半角空格占半个固定网格单元。
/// 插入 `n` 个半角空格的宽度：每个占半个字符跨度，整段再加一份网格增量。
/// -> content
#let halfspace(n, layout) = h(n * layout.docgrid.char-pitch / 2 + layout.docgrid.tracking)

/// 将长度或 `(chars: n)` 转为长度。
/// -> length
#let resolve-chars(value, layout) = {
  if type(value) == length { return value }
  if type(value) == dictionary and "chars" in value {
    let n = value.at("chars")
    if type(n) not in (int, float) {
      panic("expected number for \"chars\", found " + str(type(n)))
    }
    return chars(n, layout: layout)
  }
  panic("expected length or dictionary with \"chars\", found " + repr(value))
}

/// 在正文中插入 `n` 个 Word 字符宽度；负值退格。省略 `n` 时为一个字符。
///
/// ```typ
/// [图 1-1#h-chars()系统结构]
/// ```
///
/// 全角空格「　」也占一个字符，但 `h-chars` 不会把空白写入复制出来的文本。
/// -> content
#let h-chars(..n, layout: auto) = context h(chars(..n, layout: layout))
