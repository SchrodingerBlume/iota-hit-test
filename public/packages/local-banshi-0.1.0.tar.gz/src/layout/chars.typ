// 「几个字」的度量：chars（Word 段落对话框的「字符」单位：字号加字符网格增量）、halfspace（半格）、
// resolve-chars（长度或 (chars: n)）、h-chars（正文里空几个字）。

#import "../paragraph/spacing.typ": no-docgrid
#import "./resolve.typ" as _layout
#import "./state.typ": page-setup-state

/// `n` 个字符的长度（Word 的「n 字符」：字号加字符网格增量）；省略 `n` 时为一个。
/// -> length
#let chars(..n, layout: auto) = {
  let l = if _layout.is-page-setup(layout) {
    layout
  } else {
    let s = page-setup-state.get()
    if s == none { no-docgrid } else { _layout.merge-page-setup(s, layout) }
  }
  let count = n.pos().at(0, default: 1)
  count * 1em + count * l.docgrid.tracking
}

// Word 文档网格中的半角空格占半个固定网格单元。
#let halfspace(n, layout) = h(n * layout.docgrid.char-pitch / 2 + layout.docgrid.tracking)

/// 将长度或 `(chars: n)` 转为长度。
/// -> length
#let resolve-chars(value, layout) = {
  if type(value) == length { return value }
  if type(value) == dictionary and "chars" in value {
    let n = value.at("chars")
    if type(n) not in (int, float) {
      panic("expected number for \"chars\", found " + str(type(n)))
    }
    return chars(n, layout: layout)
  }
  panic("expected length or dictionary with \"chars\", found " + repr(value))
}

/// 空出 `n` 个字符的宽度，正文里直接写；负值退格。全角空格「　」也是一个字符。
/// -> content
#let h-chars(..n, layout: auto) = context h(chars(..n, layout: layout))
