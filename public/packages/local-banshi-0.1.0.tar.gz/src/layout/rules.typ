// 页眉页脚落到 set page 上：版心、页眉段落的下边框。

#import "../paragraph/latin.typ" as western
#import "../paragraph/spacing.typ": role-of, families-of, spacing, tracking-of
#import "../units.typ": twip
#import "../runs/regex.typ": role-features, latin-par-features, latin-any-run
#import "../styles/rules.typ" as style-rules

// 细＋粗双线（thinThickSmallGap）里定死的那两段：间隙与细线各 0.75 磅，Word 不让改。
#let _rule-gap = 0.75pt
#let _rule-thin = 0.75pt

#let _rule-over = 1.56pt

// 横线使用显式版心宽；盒内的 `100%` 会产生约 0.021pt 的宽度误差。
#let _rule(width, over, text-width) = box(width: text-width, height: width, {
  place(left + top, dx: -over, rect(
    width: text-width + 2 * over, height: width, fill: black, stroke: none,
  ))
})

// 边框整块的高：文字到线（w:space）加线本身；双线再加间隙与细线。
#let _border-height(border) = if border == none or border.thickness <= 0pt { 0pt } else {
  border.from-text + border.thickness + (
    if border.style == "thin-thick-small-gap" { _rule-gap + _rule-thin } else { 0pt }
  )
}

// 画在段落底下的边框。Word 那边是页眉段落的下边框，跟着文字走：隔一个 w:space 再画线。
#let _border(border, text-width) = {
  v(border.from-text, weak: false)
  _rule(border.thickness, _rule-over, text-width)
  if border.style == "thin-thick-small-gap" {
    v(_rule-gap, weak: false)
    _rule(_rule-thin, _rule-over, text-width)
  }
}

// 版心与页眉页脚一起设。header / footer 是逐页调用的函数，给 none 就整块不出；排不排由调用方按
// layout.header.shown 定好再传进来。
//
// 位置照 Word：页眉距边界量到页眉块的*顶*，页脚距边界量到页脚块的*底*（实测范例 PDF：页脚
// w:footer=1304 缇＝65.20，「- 2 -」基线离页底 67.02 ＝ 65.20 ＋ Times 小五的行高 10.35 − 上升部 8.48，
// 差的 0.05 是范例页码那个文本框自己的 y=1 缇）。
//
// 一行里全是西文（页码「- 3 -」也算，数字与短横都是西文字体的字）时 Word 按西文字体的行高：
// 每个西文 run 给西文的行盒，行高由行里的字自己定；块按中文行盒的高定死，页眉的字顶在块顶、
// 页脚的字坐在块底，差额就落在该空的那一头。set page 那两个数因此只算一次。
#let page-rules(
  layout,
  fontset: (:),
  header: none,
  footer: none,
  doc,
) = {
  let header-style = layout.header.style
  let footer-style = layout.footer.style
  let header-metrics = spacing(header-style, docgrid: layout.docgrid, char-grid: false)
  let footer-metrics = spacing(footer-style, docgrid: layout.docgrid, char-grid: false)

  let head-height = header-metrics.line-height + _border-height(layout.header.border)
  let foot-height = footer-metrics.line-height + _border-height(layout.footer.border)

  let head-ascent = layout.margin.top - layout.header.from-edge - head-height

  // 页眉块比天头还高时把版心往下推
  let margin-top = if header == none { layout.margin.top } else {
    calc.max(layout.margin.top, layout.margin.top - head-ascent)
  }
  let margin = layout.margin + (top: margin-top)
  let head-ascent = head-ascent + (margin-top - layout.margin.top)

  let foot-descent = layout.margin.bottom - layout.footer.from-edge - foot-height

  let styled(metrics, style, content) = {
    let latin = spacing(style, docgrid: layout.docgrid, char-grid: false, latin: true)
    set text(
      font: families-of(style, fontset),
      size: metrics.size,
      top-edge: metrics.top-edge,
      bottom-edge: -metrics.bottom-edge,
      tracking: tracking-of(metrics),
      baseline: 0pt,
      features: role-features(role-of(style)) + latin-par-features(false),
    )
    set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
    show par: it => it
    show: western.latin-line-rules.with(style, docgrid: layout.docgrid)
    // 页码「- 3 -」这种只有数字与标点的西文也按西文行盒。这儿没有字符网格，切开 run 不丢字距
    show latin-any-run: set text(top-edge: latin.top-edge, bottom-edge: -latin.bottom-edge)
    content
  }
  // 一块：那一行加它底下的边框，在定高的块里顶着块顶或坐在块底
  let piece(height, border, side, c) = block(height: height, width: 100%, align(side, {
    c
    if _border-height(border) > 0pt { _border(border, layout.text-width) }
  }))

  set page(
    width: layout.paper-width,
    height: layout.paper-height,
    margin: margin,
    header-ascent: head-ascent,
    footer-descent: foot-descent,
    header: if header == none { none } else {
      styled(header-metrics, header-style, context {
        let c = (header)()
        if c != none { piece(head-height, layout.header.border, top + center, c) }
      })
    },
    footer: if footer == none { none } else {
      styled(footer-metrics, footer-style, context {
        let c = (footer)()
        if c != none { piece(foot-height, layout.footer.border, bottom + center, c) }
      })
    },
  )

  doc
}
