// 页眉页脚落到 set page 上：版心、页眉横线（thinThickSmallGap）、页码的「- n -」装饰、
// 页脚横向那一点补偿。版面字典的折算与并表在 resolve.typ。

#import "../msword.typ": twip, role-features, latin-par-features, has-cjk
#import "../paragraph/linebox.typ" as linebox
#import "../styles/rules.typ" as style-rules
#import "../paragraph/latin.typ" as western
#import "../content.typ": plain-text

// 页眉块的高不是独立的量，是三段之和：页眉那一行的自然行高、文字到横线的
// 距离、横线本身。Word 那边横线是页眉段落的下边框，位置就是这么定的——
// 跟着文字走，隔一个 w:space，再画线。所以这里照着算，手写一个数就失去了
// 这层关系。
//
// 横线是 thinThickSmallGap：粗线取 border.thickness（Word 的 w:sz），间隙与细线
// 各 0.75pt，比例由线型定义写死，Word 也不让改。画的顺序照 hithesis：
// 先粗后细。
#let _rule-gap = 0.75pt
#let _rule-thin = 0.75pt

// 横线比版心宽出来的那一截，两边各一份。
#let _rule-over = 1.56pt

// 线宽写显式的版心宽，不写 100%：盒子里的 100% 实测比版心窄 0.021pt，
// 来路说不清，而版心宽是这一层本来就知道的量。
#let _rule(width, over, text-width) = box(width: text-width, height: width, {
  place(left + top, dx: -over, rect(
    width: text-width + 2 * over, height: width, fill: black, stroke: none,
  ))
})

// 页码的装饰：`- 3 -`。两侧是普通连字符 U+002D，与 hithesis 的
// \hit@page@number@decorated 一样，不是破折号也不是短横线——那两个都太长。
//
// separator 是短横与数字之间的距离，写死 4.5pt 不写 .5em：范例里那段间距在
// 300ppi 下量出来是二十个像素，页脚是小五、一个字宽 9pt，一半 4.5pt 折
// 18.75 个像素，加上短横右侧与数字左侧的空白正好二十。
//
// 整块的横向偏移不在这里：那是 footer.move.dx，由 page-rules 套在外面。
#let decorated-number(n, separator: 4.5pt) = {
  // *没有号就什么都不排*：page.numbering 是 none 时 counter.display() 交回空的
  // ——照排就成了「-  -」两道杠。报告那两档的封面与目录正是这一档（页码从正文起数，
  // 见 iota-hit/src/layout/presets.typ）
  if n == none or n == [] { return }
  [-]
  h(separator)
  n
  h(separator)
  [-]
}

// 整块横向挪 dx：前后一正一负两段 kern，盒子对外的宽度不变，里头的内容整体
// 右移。范例的页码是个文本框，框按版心居中、框里左对齐，框宽是内容的自然宽，
// 那一串下来落点与居中排出来差 300ppi 下一个像素，折 0.24pt，往右补
// ——这就是终稿 footer.move.dx 那个数（layout/presets.typ）。
#let _shift(dx, body) = {
  if dx != 0pt { h(dx) }
  body
  if dx != 0pt { h(-dx) }
}

// 版心与页眉页脚一起设。header-content / footer-content 是逐页调用的函数，
// 给 none 就整块不出——排不排由调用方按 layout.header.shown 定好再传进来。
//
// 这一整条是 set page，能重发：src/layout/section.typ 把它与正文的 set text / set par
// 合成「一节的 set」，iota-hit 在文档级发一次，三个 matter 用并好的版面再发一次。
// 页眉页脚的内容闭包跟着 set page 走，不从 layout-state 读——那边说了为什么。
#let page-rules(
  layout,
  font-table: (:),
  // 由调用方从角色表传进来，这个默认值只是兜底
  body-font: ("Times New Roman", "SimSun"),
  header-content: none,
  footer-content: none,
  doc,
) = {
  let header-style = layout.header.style
  let footer-style = layout.footer.style
  // 页眉页脚记录不在字符网格上（char-grid: false）：范例页眉「章→绪」空一字正好
  // 9.000，没有那 0.4543 的增量；正文故事里的段落才吃，见 src/paragraph/linebox.typ 的 _snap-of
  let header-metrics = linebox.resolve(header-style, docgrid: layout.docgrid, char-grid: false)
  let footer-metrics = linebox.resolve(footer-style, docgrid: layout.docgrid, char-grid: false)

  let border = layout.header.border
  let has-rule = border != none and border.thickness > 0pt

  // 页眉块的高：文字行盒 + 文字到横线 + 粗线 + 间隙 + 细线
  let head-height = header-metrics.box + (
    if has-rule { border.from-text + border.thickness + _rule-gap + _rule-thin } else { 0pt }
  )

  // 页眉块的顶要落在「页眉距边界」处，Typst 量的是块的底，所以从版心顶倒推。
  // move.dy 往下为正，与 Typst 的 move(dy:) 同向
  let head-ascent = layout.margin.top - layout.header.from-edge - head-height - layout.header.move.dy

  // *页眉伸到版心里去时，正文让开。* 页眉距边界大于上边距的版面，页眉块的
  // 底会落在版心顶之下——Word 那边正文从页眉块底下接着排，我们不让的话正文第一行
  // 会贴上横线（深圳本科中期就是这一档：上边距 2.85cm ＝ 80.8、页眉距边界 3cm，
  // 加上文字与横线，页眉块底在 101.5；原件正文第一行的行盒顶量出来正是 101.58）。
  //
  // 排不出页眉的那一档不算——header-content 为 none 时页眉块根本不发
  let top = if header-content == none { layout.margin.top } else {
    calc.max(layout.margin.top, layout.margin.top - head-ascent)
  }
  let margin = layout.margin + (top: top)
  // 让开之后页眉块自己的位置不变：Typst 量的是页眉块底到版心顶的距离
  let head-ascent = head-ascent + (top - layout.margin.top)

  // 页脚：规范给的是页脚基线的位置，Typst 量的是页脚块的顶，差一个上升部。
  // footskip 是版心底到页脚基线的距离，与 hithesis 的 geometry 同一个量。
  let footskip = layout.margin.bottom - layout.footer.from-edge + layout.footer.move.dy
  let foot-descent = footskip - footer-metrics.ascent

  let styled(metrics, style, content) = {
    set text(
      font: font-table.at(style.at("font-zh", default: "songti"), default: body-font),
      size: metrics.size,
      // 行盒边写「em 系数 + 绝对量」的复合长度，与别处同一条规矩（见 style-rules.sets）：
      // 一行里混进大字号的 run，行盒跟着长高，与 Word「行高取这一行实际用到的各字体
      // 的最大值」一致。*先前这一处写的是折好的 pt*，为的是躲正文那条 show par
      // ——它曾拿 text.top-edge 的 em 式子认「是不是正文的段」，页眉写同一个式子就漏
      // 进去（混排页眉「Chapter 1 绪论」整行抬 1.944）。那条规则现在按下面 features 里的
      // 标签认（latin-par-features），躲不躲已与式子无关，所以写回 em
      top-edge: metrics.top-edge,
      bottom-edge: -metrics.bottom-edge,
      tracking: linebox.tracking(metrics),
      // *视觉矫正的基线也在这儿归零。* set page 的页眉页脚是按*分页那一刻*
      // 正文的样式排的：正文那一页末尾若落在汉字段里，baseline-rules 给那一段
      // set 的 baseline 就跟着进来（实测页脚里 text.baseline 读到 -0.07em），页码
      // 「- 1 -」和页眉横线整体掉一份 0.624。这一行跟上面重设字体、字号、行盒、字距
      // 是同一件事——页眉页脚的每一项 text 样式都由这儿定，不吃正文的。页眉里的
      // 汉字仍由 baseline-rules 在段内矫正，与此不冲突。
      baseline: 0pt,
      // 角色写进 text，给视觉矫正认，见 src/msword.typ 的 role-tags；
      // 页眉页脚不参与正文那条 show par（分页那一刻正文的样式会漏进来，得显式写 0）
      features: role-features(style.at("font-zh", default: "songti")) + latin-par-features(false),
    )
    set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
    // 正文那条收窄段落宽度的规则也一并关掉：行末余量只属于版心里的汉字行
    show par: it => it
    // 纯西文行的行盒要按本处自己的行距倍数算，所以在这里重发一份。
    // 不发的话正文那一份会漏进来：set page 的页眉页脚是在正文的样式里排的，
    // 于是页眉里的「第 1 章」那个 1 会拿到正文 1.25 倍的西文行深，
    // 页眉行被撑高 1.27，基线从 94.204 掉到 92.938（横线位置不变，
    // 因为它跟着块底走）。
    show: western.latin-line-rules.with(
      style, docgrid: layout.docgrid,
    )
    content
  }

  set page(
    width: layout.paper-width,
    height: layout.paper-height,
    margin: margin,
    header-ascent: head-ascent,
    footer-descent: foot-descent,
    // header-content 是个函数，逐页调用，返回 none 就整块不出——文字与横线
    // 一起没有。
    header: if header-content == none { none } else {
      styled(header-metrics, header-style, context {
        let c = (header-content)()
        if c != none {
          align(center, _shift(layout.header.move.dx, c))
          if has-rule {
            v(border.from-text, weak: false)
            _rule(border.thickness, _rule-over, layout.text-width)
            v(_rule-gap, weak: false)
            _rule(_rule-thin, _rule-over, layout.text-width)
          }
          // *纯西文的页眉整体上抬。* Word 的页眉框顶在「页眉距边界」上，行盒按这一行
          // 实际用到的字体算：纯英文的行只有 Times 参与、按 1.15 算，比汉字行矮，字与横线
          // 都跟着往上走。自己造 docx 量的（博士范例的页眉换成 Harbin Institute of
          // Technology Doctoral Dissertation，Word 导出）：字的基线上抬 0.72、横线上抬
          // 1.68。我们的页眉框是按汉字行盒定高、底边锚在 header-ascent 上的，纯西文那
          // 一行的行盒矮下去的那一截，先前落在框顶，字和横线反而往下掉（实测字掉 0.64、
          // 横线不动）。在框底补上这一截，字和横线就顶回框顶。latin-line-height 是
          // "cjk" 时两份行盒相等，补 0。
          // 读不到字（用户自己的页眉函数返回了 context 块）就不动——宁可不抬，
          // 不能把中文页眉当成西文抬上去
          let words = plain-text(c)
          if words.trim() != "" and not has-cjk(words) {
            let latin = linebox.resolve(
              header-style + (font-zh: "latin"), docgrid: layout.docgrid, char-grid: false,
            )
            v(header-metrics.box - latin.box, weak: false)
          }
        }
      })
    },
    footer: if footer-content == none { none } else {
      styled(footer-metrics, footer-style, align(center, context {
        _shift(layout.footer.move.dx, (footer-content)())
      }))
    },
  )

  doc
}
