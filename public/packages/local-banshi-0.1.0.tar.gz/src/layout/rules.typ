// 页眉页脚落到 set page 上：版心、页眉横线（thinThickSmallGap）、页码的「- n -」装饰、。

#import "../paragraph/latin.typ" as western
#import "../paragraph/spacing.typ": font-zh-of, spacing, tracking-of
#import "../units.typ": twip
#import "../runs.typ": has-cjk
#import "../runs/regex.typ": role-features, latin-par-features
#import "../styles/rules.typ" as style-rules
#import "../content.typ": plain-text

// 距离、横线本身。Word 那边横线是页眉段落的下边框，位置就是这么定的；跟着文字走，隔一个 w:space，再画线。
#let _rule-gap = 0.75pt
#let _rule-thin = 0.75pt

#let _rule-over = 1.56pt

// 横线使用显式版心宽；盒内的 `100%` 会产生约 0.021pt 的宽度误差。
#let _rule(width, over, text-width) = box(width: text-width, height: width, {
  place(left + top, dx: -over, rect(
    width: text-width + 2 * over, height: width, fill: black, stroke: none,
  ))
})

// 那一串下来落点与居中排出来差 300ppi 下一个像素，折 0.24pt，往右补；这就是终稿 footer.move.dx 那个数（layout/presets.typ）。
#let _shift(dx, body) = {
  if dx != 0pt { h(dx) }
  body
  if dx != 0pt { h(-dx) }
}

// 版心与页眉页脚一起设。header / footer 是逐页调用的函数，给 none 就整块不出；排不排由调用方按 layout.header.shown 定好再传进来。
#let page-rules(
  layout,
  fontset: (:),
  body-font: ("Times New Roman", "SimSun"),
  header: none,
  footer: none,
  doc,
) = {
  let header-style = layout.header.style
  let footer-style = layout.footer.style
  let header-metrics = spacing(header-style, docgrid: layout.docgrid, char-grid: false)
  let footer-metrics = spacing(footer-style, docgrid: layout.docgrid, char-grid: false)

  let border = layout.header.border
  let has-rule = border != none and border.thickness > 0pt

  let head-height = header-metrics.line-height + (
    if has-rule { border.from-text + border.thickness + _rule-gap + _rule-thin } else { 0pt }
  )

  let head-ascent = layout.margin.top - layout.header.from-edge - head-height - layout.header.move.dy

  let top = if header == none { layout.margin.top } else {
    calc.max(layout.margin.top, layout.margin.top - head-ascent)
  }
  let margin = layout.margin + (top: top)
  let head-ascent = head-ascent + (top - layout.margin.top)

  let footskip = layout.margin.bottom - layout.footer.from-edge + layout.footer.move.dy
  let foot-descent = footskip - footer-metrics.ascent

  let styled(metrics, style, content) = {
    set text(
      font: fontset.at(font-zh-of(style), default: body-font),
      size: metrics.size,
      top-edge: metrics.top-edge,
      bottom-edge: -metrics.bottom-edge,
      tracking: tracking-of(metrics),
      baseline: 0pt,
      features: role-features(font-zh-of(style)) + latin-par-features(false),
    )
    set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
    show par: it => it
    show: western.latin-line-rules.with(
      style, docgrid: layout.docgrid,
    )
    content
  }

  set page(
    width: layout.paper-width,
    height: layout.paper-height,
    margin: margin,
    header-ascent: head-ascent,
    footer-descent: foot-descent,
    header: if header == none { none } else {
      styled(header-metrics, header-style, context {
        let c = (header)()
        if c != none {
          align(center, _shift(layout.header.move.dx, c))
          if has-rule {
            v(border.from-text, weak: false)
            _rule(border.thickness, _rule-over, layout.text-width)
            v(_rule-gap, weak: false)
            _rule(_rule-thin, _rule-over, layout.text-width)
          }
          let words = plain-text(c)
          if words.trim() != "" and not has-cjk(words) {
            let latin = spacing(
              header-style + (font-zh: "latin"), docgrid: layout.docgrid, char-grid: false,
            )
            v(header-metrics.line-height - latin.line-height, weak: false)
          }
        }
      })
    },
    footer: if footer == none { none } else {
      styled(footer-metrics, footer-style, align(center, context {
        _shift(layout.footer.move.dx, (footer)())
      }))
    },
  )

  doc
}
