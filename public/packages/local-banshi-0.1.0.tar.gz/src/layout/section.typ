// 节级设置可以在局部 show 作用域中重设；会叠加补偿的 show 规则只在文档级安装一次。

#import "./resolve.typ" as _layout
#import "./rules.typ": page-rules
#import "../styles/rules.typ" as style-rules
#import "../styles/sheet.typ" as sheet
#import "../fonts/resolve.typ" as _fonts

/// 应用一个 Word“节”的页面设置，并重装该节的页眉、页脚、正文行盒与字符网格。
/// `layout` 必须是 `page-setup` 或 `merge-page-setup` 的结果；`styles` 与 `fontset` 为
/// `auto` 时沿用当前文档状态。
///
/// `section` 是 show rule，不会自动换页或重置页码。若新节应另起一页，先调用
/// `pagebreak()`；若页码制式变化，再设置 `page(numbering:)` 并更新页码计数器。
///
/// ```typ
/// #show: section.with(
///   layout,
///   header: () => [附录],
///   footer: () => context counter(page).display("I"),
/// )
/// ```
/// -> content
#let section(layout, styles: auto, fontset: auto, header: none, footer: none, doc) = {
  let styles = if styles == auto { sheet.current-styles() } else { styles }
  let f = if fontset == auto { _fonts.fontset-state.get() } else { fontset }
  let body = styles.body
  // 节的起始位置：连续不翻页；下一页／奇数页／偶数页各翻到相应的页（已在页首就不翻）
  if layout.section-start != "continuous" {
    pagebreak(weak: true, to: (new-page: none, odd-page: "odd", even-page: "even").at(layout.section-start))
  }
  show: page-rules.with(layout, fontset: f, header: header, footer: footer)
  show: style-rules.sets.with(body, layout: layout, latin-par: true)
  show: _layout.linebreaks-sets.with(layout)
  doc
}
