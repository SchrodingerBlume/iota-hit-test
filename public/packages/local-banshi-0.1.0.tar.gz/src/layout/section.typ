// 一节的 set 规则：版心与页眉页脚（set page）加正文那一档的字与段（set text /
// set par）。
//
// 五层梯子里「段」那一层落地的地方。版面分两类规则接到 Typst 上：
//
//   set 规则   能重发——内层压外层，重发不叠加。iota-hit 在文档级发一次，
//              frontmatter / mainmatter / backmatter 在自己的 show 作用域里用并好的
//              版面再发一次，段级改的版心、行跨度、页眉页脚就落到那一段的页上。
//   show 规则  绝不能重发——latin-run 那条会在西文前补 h(tracking)，重发就补两次。
//              只在文档级装一次（iota-hit/lib.typ），规则里用到版面的数都在各自的 context 里
//              从 page-setup-state 现取（src/styles/rules.typ 的 shows、iota-hit/src/blocks 的
//              heading-rules / caption-rules / equation-rules / body-rules）。
//
// *页眉页脚的内容闭包跟着 set page 一起重发，不从 state 读。* 自己量过
// （typst 0.15）：页眉里 state.get() 读到的是*本页开头之前*的值，页脚读到的是
// *本页末尾*的值。段的 update 只能落在某一页上——落在跳页之前，上一页的页脚
// 就读到下一段的；落在跳页之后，下一页的页眉就读到上一段的。两头总有一页错。
// set page 是按作用域切页的，页眉页脚跟着它走一页不差，所以整条 set page 连内容
// 一起重发；重发的只是内容闭包，不是 show 规则。
//
// 段边界的 set page 会引起分页，而 matter 入口本来就跳页，不多一页（对拍
// iota-hit/tests/check-assemble.py 与 tests/matrix 的页序不变）。

#import "./resolve.typ" as _layout
#import "./rules.typ": page-rules
#import "../styles/rules.typ" as style-rules
#import "../styles/sheet.typ" as sheet
#import "../fonts/resolve.typ" as _fonts

// 发一节的 set：版心与页眉页脚（set page）加正文那一档的字与段（set text / set par）。
// styles 是样式表（正文那一档从里面取），fontset 是解析好的角色表，两样给 auto 就从
// state 取——matter 在 context 里这么调；iota-hit 自己刚算好，直接传，不必等 state 落地。
// header / footer 是页眉页脚的内容闭包（none ＝ 不排）：出不出、印什么是
// 模板的事（按 stage、按学位），在 iota-hit/src/layout/matter.typ 的 section 里定好再传进来；
// 这里只管把它们与版面一起落到 set page 上
#let section(layout, styles: auto, fontset: auto, header: none, footer: none, doc) = {
  let styles = if styles == auto { sheet.current-styles() } else { styles }
  let f = if fontset == auto { _fonts.fontset-state.get() } else { fontset }
  let body = styles.body
  let family = f.at(body.at("font-zh", default: "songti"))
  show: page-rules.with(
    layout,
    fontset: f,
    body-font: family,
    header: header,
    footer: footer,
  )
  // 正文那一档的字与段。字体不在这里设——那是 iota-hit 在最外层设的一句
  // set text(font:)，与版面无关。latin-par: true ＝ 正文的段参与「纯西文段换西文行盒」
  // 那条 show par（src/styles/body.typ），别的部件默认不参与
  show: style-rules.sets.with(body, layout: layout, latin-par: true)
  // 引擎画字符网格那一档的 set par(linebreaks:)——文档级与每个 matter 段各发一次，
  // 没给 --input linebreaks 就什么都不发，见 src/layout/resolve.typ 的「断行引擎」
  show: _layout.linebreaks-sets.with(layout)
  doc
}
