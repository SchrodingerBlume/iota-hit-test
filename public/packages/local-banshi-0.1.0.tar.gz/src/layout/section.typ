// 节级设置可以在局部 show 作用域中重设；会叠加补偿的 show 规则只在文档级安装一次。

#import "../paragraph/spacing.typ": font-zh-of
#import "./resolve.typ" as _layout
#import "./rules.typ": page-rules
#import "../styles/rules.typ" as style-rules
#import "../styles/sheet.typ" as sheet
#import "../fonts/resolve.typ" as _fonts

/// 应用一个 Word“节”的页面设置、页眉页脚和正文段落设置。
/// `styles` 与 `fontset` 为 `auto` 时读取当前文档状态。
/// -> content
#let section(layout, styles: auto, fontset: auto, header: none, footer: none, doc) = {
  let styles = if styles == auto { sheet.current-styles() } else { styles }
  let f = if fontset == auto { _fonts.fontset-state.get() } else { fontset }
  let body = styles.body
  let family = f.at(font-zh-of(body))
  show: page-rules.with(
    layout,
    fontset: f,
    body-font: family,
    header: header,
    footer: footer,
  )
  show: style-rules.sets.with(body, layout: layout, latin-par: true)
  show: _layout.linebreaks-sets.with(layout)
  doc
}
