// 当前节的页面设置。独立成模块是为了避免 layout 与 styles 的循环导入。
#let page-setup-state = state("banshi-layout", none)

// shows 里的 context 取版面：current 关着就是装规则时那一份（部件层）；开着从page-setup-state 取当前这一节的（正文那一档）。
#let layout-of(layout, current) = {
  if not current { return layout }
  let s = page-setup-state.get()
  if s == none { layout } else { s }
}
