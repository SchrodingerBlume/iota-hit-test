// 当前生效的版面（一节）。
//
// iota-hit 在最外层写进来（文档层），三个 matter 在它上面并（段层），页函数从这里
// 取再并部件差额与自己那一份；ccwd 这类给用户用的函数也从这里取——与 fonts.fontset-state
// 同一个路子。
//
// *单独成一个文件，只为断开一个环*：src/layout/resolve.typ 要用 src/styles/rules.typ
// 的换算（页眉页脚的行高），而 styles.typ 里正文那几条 show 规则又要在 context 里
// 读这个 state（段级改了版面，规则里的数得跟着换，见那边的 shows）。Typst 不许互相
// import，所以 state 落在两边都能 import 的地方。写 page-setup-state 或
// layout.page-setup-state 的地方一个字不用改——两边都再导出一次。
// *state 名是站内预览的接口*（iota4web 直接读过它；现在有公开的 current-page-setup()，但名字仍别动）
#let page-setup-state = state("banshi-layout", none)

// shows 里的 context 取版面：current 关着就是装规则时那一份（部件层）；开着从
// page-setup-state 取当前这一节的（正文那一档）。state 还是 none 的地方——第一页的页眉
// 在文档级那次 update 之前就排了（实测页眉读到的是本页开头之前的值）——退回装规则
// 时那一份，与先前一字不差。*要在 context 里调*
#let layout-of(layout, current) = {
  if not current { return layout }
  let s = page-setup-state.get()
  if s == none { layout } else { s }
}
