// Word「选项」那一层：Typst→Word 的几处矫正各带一个文档级的开关（伪粗、伪斜、列表
// 悬挂），show 规则在自己的 context 里读。*只放开关，不放值*——
// 值（描边线宽、倾角）住在 fonts/presets.typ。
//
// 模板从自己的具名参数喂进来（iota-hit 的 settings-overrides 把同名的键转发到
// options-overrides），不喂 ＝ auto ＝ 各处按自己的 auto 解（伪粗探真粗面在不在、伪斜
// 探楷体在不在、编号列表不悬挂、圆点列表悬挂）。
#import "./errors.typ" as _errors

#let option-defaults = (
  fake-bold: auto,
  fake-italic: auto,
  enum-hanging: auto,
  list-hanging: auto,
)

#let options-state = state("banshi-options", option-defaults)

// 造一份选项表：只写真的给了的（auto ＝ 不写），认不得的键当场报错。交给 document(options:)
#let options(..args) = {
  if args.pos().len() > 0 { panic("options: expected named arguments only") }
  for (key, v) in args.named() {
    if key not in option-defaults {
      panic(
        "unknown option: " + key + " (" + _errors.one-of(
          option-defaults.keys().map(k => repr(k)),
        ) + ")",
      )
    }
  }
  args.named().pairs().filter(((_, v)) => v != auto).to-dict()
}

// 文档级覆盖，document 里调：并到 state 上
#let options-overrides(value) = {
  let _ = options(..value)
  options-state.update(old => old + value)
}

// 取一个开关。*要在 context 里调*
#let option-of(key) = {
  let all = options-state.get()
  if key not in all { panic("unknown option: " + key) }
  all.at(key)
}
