// 文档级选项。与 Word 设置对应的，名字与取值方向一一照 OOXML（settings.xml、编号级别里的那个元素）；
// 其余几个是 banshi 自己怎么模仿 Word 的开关。`auto` 由各功能根据字体或 Word 默认值解释。
#import "./errors.typ" as _errors

#let option-defaults = (
  fake-bold: auto,
  fake-italic: auto,
  enum-hanging: auto,
  list-hanging: auto,
  html-paragraph-auto-spacing: true,
  adjust-line-height-in-table: false,
  numbering-suffix: auto,
  numbering-tab-stop: auto,
  default-tab-stop: auto,
)

#let options-state = state("banshi-options", option-defaults)

/// 创建供 `document(options:)` 使用的选项字典。只接受具名参数；`auto` 表示沿用默认。
///
/// - `fake-bold`、`fake-italic`：控制缺少真实字面时是否合成。
/// - `enum-hanging`、`list-hanging`：控制编号列表与项目符号列表是否使用悬挂缩进。
///
/// 照 Word 的（Typst 有原生概念就用原生词；没有的，对 OOXML 元素与 Word 选项卡的说法，词性照 Typst 的习惯——
/// 开关用肯定的名词或动词，不用 do-not- 式的否定）：
/// - `html-paragraph-auto-spacing`：Word「版式选项」里「不使用 HTML 段落自动间距」的肯定说法（Typst 的开关不用
///   否定式），与 `w:compat/w:doNotUseHTMLParagraphAutoSpacing` 方向相反。`true`（新建文档）：相邻两段取前段
///   段后与后段段前的较大者；`false`（docx 里写着那个元素）：两者相加。
/// - `adjust-line-height-in-table`：`w:compat/w:adjustLineHeightInTable`（「调整表格中的行高以适应网格高度」）。
///   `false`：单元格里的行不贴文档网格；`true`：照段落自己的贴网格设置。
/// - `numbering-suffix`：编号级别的 `w:suff`——编号之后跟 `"tab"`、`"space"` 还是 `"nothing"`；`auto`：
///   手打编号的排法（编号后空一格，全角括号收尾的不空）。
/// - `numbering-tab-stop`：编号级别里 `w:tab w:val="num"` 的位置（Word「制表位添加位置」，离段落左缘多远）；`numbering-suffix: "tab"` 时
///   编号后跳到它，编号已越过它就跳下一个默认制表位。
/// - `default-tab-stop`：`w:settings/w:defaultTabStop`（「默认制表位」）；`auto` 是 Word 新建文档的 21 磅。
/// banshi 自己的：
///
/// ```typ
/// #let opts = options(fake-bold: true, enum-hanging: false)
/// ```
/// -> dictionary
#let options(..args) = {
  if args.pos().len() > 0 { panic("options: expected named arguments only") }
  for (key, v) in args.named() {
    if key not in option-defaults {
      panic(
        "unknown option: " + key + " (" + _errors.one-of(
          option-defaults.keys().map(k => repr(k)),
        ) + ")",
      )
    }
    if key in ("html-paragraph-auto-spacing", "adjust-line-height-in-table") and type(v) != bool {
      panic(key + ": expected true or false, found " + repr(v))
    }
    if key == "numbering-suffix" and v not in (auto, "tab", "space", "nothing") {
      panic("numbering-suffix: " + _errors.expected-one-of((auto, "tab", "space", "nothing"), v))
    }
  }
  args.named().pairs().filter(((_, v)) => v != auto).to-dict()
}

// 将显式选项写入文档状态。
#let options-overrides(value) = {
  let _ = options(..value)
  options-state.update(old => old + value)
}

// 读取当前文档选项；调用方必须处于 context 中。
#let option-of(key) = {
  let all = options-state.get()
  if key not in all { panic("unknown option: " + key) }
  all.at(key)
}
