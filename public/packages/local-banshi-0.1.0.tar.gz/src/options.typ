// 文档级兼容选项。`auto` 由各功能根据字体或 Word 默认值解释。
#import "./errors.typ" as _errors

#let option-defaults = (
  fake-bold: auto,
  fake-italic: auto,
  enum-hanging: auto,
  list-hanging: auto,
)

#let options-state = state("banshi-options", option-defaults)

/// 创建供 `document(options:)` 使用的选项字典。只接受具名参数；值为 `auto` 的项不写入结果。
/// -> dictionary
#let options(..args) = {
  if args.pos().len() > 0 { panic("options: expected named arguments only") }
  for (key, v) in args.named() {
    if key not in option-defaults {
      panic(
        "unknown option: " + key + " (" + _errors.one-of(
          option-defaults.keys().map(k => repr(k)),
        ) + ")",
      )
    }
  }
  args.named().pairs().filter(((_, v)) => v != auto).to-dict()
}

// 将显式选项写入文档状态。
#let options-overrides(value) = {
  let _ = options(..value)
  options-state.update(old => old + value)
}

// 读取当前文档选项；调用方必须处于 context 中。
#let option-of(key) = {
  let all = options-state.get()
  if key not in all { panic("unknown option: " + key) }
  all.at(key)
}
