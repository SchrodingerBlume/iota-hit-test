// 模拟 Word 里单独按一次回车留下的空段。

#import "./spacing.typ": spacing, no-docgrid
#import "../styles/sheet.typ" as sheet
#import "../errors.typ" as _errors

#import "../fonts/presets.typ": roles as _roles, en-roles as _en-roles
// 段落标记能用的字体角色：中文七档与西文三档
#let _mark-fonts = _roles.filter(r => r != "math")

// 回车次数写成位置参数，好让 #enter() 与 #enter(3) 都能用。
#let _line-spacing-of(value) = if value != auto { value } else {
  sheet.current-styles().body.at("line-spacing", default: 1)
}

// 空段高度由段落标记 ¶ 的字体槽决定。¶ 默认使用 `w:rFonts/@w:ascii`，即 Times。
// hithesis 使用的西文系数是 1.1472，本包按摘要标定采用 1.15；现有空段探针无法
// 区分二者：三个空段总高量得 41.276pt，两种模型给 41.30/41.40pt；七个空段
// 量得 108.91pt，两种模型给 108.41/108.675pt，均落在 Word 约 0.24pt 的量化
// 噪声内。因此沿用统一的 1.15，不另设常数。
/// 计算一个空段的高度：按段落标记 ¶ 所用字体槽（默认 `"serif"`）的单倍行高乘以行距，
/// 贴网格时向上取整到整数个网格行。`line-spacing` 为 `auto` 时跟随当前正文样式。
/// -> length
#let paragraph-mark-height(size, font: "serif", line-spacing: auto, snap: false, layout: no-docgrid) = {
  assert(font in _mark-fonts, message: _errors.expected-one-of(_mark-fonts, font))
  spacing(
    (
      size: size,
      asian-font: if font in _en-roles { "songti" } else { font },
      line-spacing: _line-spacing-of(line-spacing),
      snap-to-grid: snap,
    ),
    docgrid: layout.docgrid,
    latin: font in _en-roles,
  ).baseline-gap
}

/// 插入一个或多个 Word 段落标记所形成的空段高度。
/// 位置参数是段落标记数；`weak: true` 时改用可折叠的垂直间距。
/// -> content
#let paragraph-mark(
  ..args,
  size: auto,
  font: "serif",
  line-spacing: auto,
  spacing: 0pt,
  snap: false,
  layout: no-docgrid,
  weak: false,
) = context {
  assert(
    args.pos().len() <= 1 and args.named().len() == 0,
    message: "unexpected argument",
  )
  let n = if args.pos().len() == 0 { 1 } else { args.pos().first() }
  assert(font in _mark-fonts, message: _errors.expected-one-of(_mark-fonts, font))
  assert(
    size == auto or (type(size) == length and size.em == 0),
    message: "size: expected absolute length such as zihao.xiaosi or 12pt, found " + repr(size),
  )
  let sz = if size == auto { text.size } else { size }
  let ls = _line-spacing-of(line-spacing)
  let h = paragraph-mark-height(sz, font: font, line-spacing: ls, snap: snap, layout: layout)
  if weak {
    v(n * h, weak: true)
  } else {
    for _ in range(n) { block(height: h, above: spacing, below: 0pt, []) }
  }
}
