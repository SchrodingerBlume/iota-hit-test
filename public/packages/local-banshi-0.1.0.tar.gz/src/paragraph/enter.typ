// 模拟 Word 里单独按一次回车留下的空段。
//
// 对照 hithesis 的 \hitenter。Word 里空一行靠的是单独按一次回车，那一段的
// 高度由*段落标记（¶）自己的字体与字号*决定，与段里有没有字无关：
//
//   空段高 = 行距倍数 × 自然行高(¶ 的字体, ¶ 的字号)
//
// *¶ 取 w:rFonts 的 ascii 槽。* 段落标记是西文位置的字符，所以默认走
// 文档的西文字体；ascii 被显式指定成中文字体时才走中文系数。这一条是从
// 「1-8 页+规范章补全+中英摘要 本科毕业论文书写范例（理工类）.docx」的封面页
// 拟合出来的，三处都对得上（数是 Word 排出来的 PDF 上量的）：
//
//   第 31 段  ¶ ascii=宋体 sz44 行距 1.25   1.25×1.296875×22 = 35.664   量 35.64
//   第 35 段  ¶ 只有 eastAsia=黑体          走西文 1.1472
//   第 36–41  ¶ 没有 rFonts                 走西文 1.1472
//
// hithesis 那句「Word 的段落标记是西文字符，故取西文档 1.434em」说的就是这件事，
// 它还留着 font-zh 的口子，正是为第 31 段那种情形。
//
// *高度不另写公式。* 拿 ¶ 的属性喂给 linebox.resolve，与正文、标题、
// 页眉走的是同一套换算。所以 size 与 line-spacing 的取值文法也与 styles 同词汇。
//
// *西文系数取 1.15 还是 1.1472，眼下判不出来。* hithesis 的 hitenter 用
// 1.1472，我们的换算层用 1.15（有范例英文摘要 17.25 的实测撑着）。拿封面页
// 拟合，两个都落在 Word 的量化噪声里：页顶三个空段量出总高 41.276，
// 1.1472 算 41.30、1.15 算 41.40；而第 35–41 那七个空段量出 108.91，
// 1.15 算 108.675、1.1472 算 108.41——两处各偏向一边，差都不到 Word 那
// 0.24pt 的落笔取整。所以沿用换算层的 1.15，不为这一处另开常数。

#import "./linebox.typ" as linebox
#import "../styles/sheet.typ" as sheet
#import "./linebox.typ": no-docgrid
#import "../errors.typ" as _errors

// 角色名 → linebox.resolve 的 font-zh。西文三个角色折成 "ascii"（¶ 取 ascii 槽，自然
// 行高按 Times 的 1.15 算；*不写 "latin"*，那一档会被 layout.latin-line-height: "cjk" 折回中文
// 行高，而空段是 Word 的段落标记机制，与「英文用不用自然行高」无关），中文四个折成自己。
#let _coef-of = (
  serif: "ascii", sans: "ascii", mono: "ascii",
  songti: "songti", heiti: "heiti", kaishu: "kaishu", fangsong: "fangsong",
  // 楷体_GB2312 与隶书的自然行高*与中易那四档同数*（六副字读出来逐字段
  // 相同，见 src/fonts/presets.typ 抬头），新魏是自己那一档 1.35。空段照样要认
  // 这三个角色——深圳本科那份首页的头一个空段写着「隶书二号」
  "kaishu-gb2312": "kaishu-gb2312", lishu: "lishu", xinwei: "xinwei",
)

// 回车次数写成位置参数，好让 #enter() 与 #enter(3) 都能用。Typst 的位置参数
// 不能带默认值，所以走 ..args 收一个。
// *空段与别的段吃同样的东西*，所以除了字号、字体、行距，还收段前段后与
// 行网格两档。这两档不是为哪一页开的口子——Word 里空段就是段：
//
//   spacing  段前段后。报告首页那两份本科表单每一段都写着 before=60 after=60
//            ＝ 各 3pt，空段也不例外；两段相邻时折叠成较大者，而 Typst 的块间距
//            本来就是这个语义（iota-hit/tests/check-adjacent.py 验的是同一条）。
//            *Word 的 before 与 after 在这几处恒相等*，所以收一个值就够；
//            真要分开写的那天再拆，别现在就摆两个参数。
//   snap     贴不贴行网格，以及贴的是哪一张（layout）。硕博三份报告的 sectPr
//            写着 docGrid w:type="lines" linePitch="312"，小二空段的自然行高
//            20.7 要往上取整成 2 格 ＝ 31.2——实测两个空段的基线差正是 31.2。
//
// *先前这两档都没有*，报告首页的空段因此改走了 paragraph([])。那是拿另一
// 个部件冒充空段：同一页上「空段」与「有字的段」走两套代码，谁改谁都不知道对方
// 会不会跟着变。补在这儿，整页仍旧是「一段一段照 Word 排」。
// *一个空段有多高。* 抽出来是因为「靠减空段收版面」的地方要拿它算——
// 报告首页题目长了要吃掉几个空段，吃的时候算的高必须与发的时候一模一样。
// 先前那儿自己写了一份（linebox.metrics(…).box），字体系数与贴不贴网格两处都跟
// 这儿不同：标题与题目之间那个空段实发 31.2（小三贴 15.6 的网格，占两格），
// 那份算出 20.75，于是余量落在了错的组上。
//
// *行距的 auto ＝ 跟正文那一档*（styles.body 的 line-spacing）。Word 里空段
// 就是段：它吃的是所在那一节的段落属性，正文 1.25 倍，空段也是 1.25 倍——先前
// 这儿的默认写死 1（单倍），于是模板里一句 #enter() 发出来的空段比正文矮一截，
// 「正文 → 空段 → 节标题」这一跳短了 1.67（原件 45.60，我们 43.93）。
//
// *封面那几页照旧写 1*：那几份原件的空段确实是单倍（本部研究生 Normal 里
// 一个 w:spacing 都没有），它们各自在调用处写明，不吃这条默认。
// *要在 context 里调*。
#let _line-spacing-of(value) = if value != auto { value } else {
  sheet.current-styles().body.at("line-spacing", default: 1)
}

// size 收长度，其余与 enter 同名同义。
#let paragraph-mark-height(size, font: "serif", line-spacing: auto, snap: false, layout: no-docgrid) = {
  assert(font in _coef-of, message: _errors.expected-one-of(_coef-of.keys(), font))
  linebox.resolve(
    (
      size: size,
      font-zh: _coef-of.at(font),
      line-spacing: _line-spacing-of(line-spacing),
      // 空段只有纵向可言：一个字都没有，横向的字距网格无从谈起
      snap-to-docgrid: snap,
    ),
    docgrid: layout.docgrid,
  ).baseline-gap
}

#let paragraph-mark(
  ..args,
  size: auto,
  font: "serif",
  // auto ＝ 跟正文那一档，见 _line-spacing-of
  line-spacing: auto,
  spacing: 0pt,
  snap: false,
  layout: no-docgrid,
  weak: false,
) = context {
  assert(
    args.pos().len() <= 1 and args.named().len() == 0,
    message: "unexpected argument",
  )
  let n = if args.pos().len() == 0 { 1 } else { args.pos().first() }
  assert(
    font in _coef-of,
    message: _errors.expected-one-of(_coef-of.keys(), font),
  )
  assert(
    size == auto or (type(size) == length and size.em == 0),
    message: "size: expected absolute length such as zihao.xiaosi or 12pt, found " + repr(size),
  )
  let sz = if size == auto { text.size } else { size }
  let ls = _line-spacing-of(line-spacing)
  let h = paragraph-mark-height(sz, font: font, line-spacing: ls, snap: snap, layout: layout)
  // 两支底下是*两套不同的机制*，不只是开关一个属性：
  //
  //              weak: false（默认）      weak: true
  //   发的是      n 个真实空行盒          一段间距
  //   N 次回车    相加                    塌缩取大者
  //   页首        占位                    丢弃
  //   跨页        能劈开                  不能
  //   段前段后    照发                    *无从谈起*（间距没有前后之分）
  //   像谁        Word                    Typst
  //
  // Typst 里拿不到「丢弃但不塌缩」——v(weak: true) 必带塌缩，
  // block(height:) 必不丢弃，中间没有第三种。所以只能二选一。
  //
  // 默认走 Word：三次回车就是三个空段，不了解 weak 的人碰不到塌缩。
  // 显式写 weak: true 的人是在主动要 Typst 那套，塌缩是它的定义的一部分。
  if weak {
    v(n * h, weak: true)
  } else {
    // 每行一个真实的空行盒，盒不可弃、盒间是合法断点，所以页底装得下几行
    // 装几行，剩下的落到新页页首照常占位。整段 v() 劈不开，这一支不能用 v。
    // *段前只发在上面*：spacing 收的是 Word 的 w:spacing w:before，写成
    // block 的 spacing 会上下各发一份——空段与下一段之间凭空多出一截（深圳本科
    // 报告首页那个二号空段实测多出 12，校名因此低了 12）。段后是另一回事，
    // 表里从来没有一处要它
    for _ in range(n) { block(height: h, above: spacing, below: 0pt, []) }
  }
}
