// 编号列表（enum）：默认照 Word 排成段，不悬挂；#enum-hanging 单次改回悬挂。
#import "../layout/chars.typ" as chars
#import "../content.typ": plain-text
#import "../options.typ": option-of

// 列表悬挂设置有文档级默认值和局部覆盖；局部值以栈记录，`auto` 继承外层设置。
#let _switch(key, default) = {
  let stack = state("banshi-" + key, ())
  (
    once: (..args, body) => {
      let v = args.pos().at(0, default: true)
      if args.pos().len() > 1 or args.named().len() > 0 or v not in (auto, true, false) {
        panic(key + ": expected auto, true, or false, then the body, found " + repr(args.pos()))
      }
      stack.update(s => s + (v,))
      block(body)
      stack.update(s => s.slice(0, -1))
    },
    now: () => {
      let local = stack.get().rev().find(v => v != auto)
      if local != none { return local }
      let doc = option-of(key)
      if doc == auto { default } else { doc }
    },
  )
}

#let _enum = _switch("enum-hanging", false)
/// 局部切换编号列表的续行是否悬挂：`#enum-hanging[…]`、`#enum-hanging(false)[…]`。
/// 不写时跟随文档选项。
/// -> content
#let enum-hanging = _enum.once
#let _hanging = _enum.now

// _ref-gap）同一条判据。
#let _gap(num) = if plain-text(num).ends-with(regex("[）。．、）】」]")) { [] } else { " " }

// 栈记录外层各级编号，用于生成多级 numbering。
#let _numbers = state("banshi-enum-numbers", ())

// 编号串是 Typst 自己的 enum(numbering:)，默认 "1."（Word 的默认编号也是它）；要「（1）」的模板自己 set
#let enum-rules(doc) = {
  show enum: it => context {
    if _hanging() { return it }
    let outer = _numbers.get()
    let depth = outer.len()
    let count = it.children.len()
    let n = if it.start != auto { it.start } else if it.reversed { count } else { 1 }
    let step = if it.reversed { -1 } else { 1 }
    for item in it.children {
      let given = item.at("number", default: auto)
      if given != auto and given != none { n = given }
      let num = if it.full { numbering(it.numbering, ..outer, n) } else { numbering(it.numbering, n) }
      let gap = if it.body-indent == 0.5em { _gap(num) } else { h(it.body-indent) }
      _numbers.update(s => s + (n,))
      let given = it.indent != 0pt
      block(
        inset: (left: if not given and depth > 0 { chars.chars(2 * depth) } else { 0pt }),
        ..(if it.spacing != auto { (above: it.spacing, below: it.spacing) } else { (:) }),
        {
          set par(first-line-indent: (amount: it.indent, all: true)) if given
          parbreak()
          num + gap + item.body
        },
      )
      _numbers.update(s => s.slice(0, -1))
      n += step
    }
  }
  doc
}
