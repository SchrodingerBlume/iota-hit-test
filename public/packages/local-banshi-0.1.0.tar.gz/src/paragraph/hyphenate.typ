// 西文的「换行和分页」卡：断字（Word 默认关；开关是原生的 text.hyphenate）与长到一行放不下的
// 单词（Word 在单词内部按字符断行把行填满，Typst 不会——插零宽空格造断点）。

#import "../runs.typ": latin-run

// 西文断字。
//
// *光开 hyphenate 没用，必须连 lang 一起给。* Typst 按 text.lang 选断字
// 规则表，中文没有那张表——实测同一个 electroencephalographically，lang=en 断成
// electroen-cephalographically，lang=zh 整词甩到下一行，设不设 hyphenate 都一样。
//
// 挂在 latin-run 上：那条正则本来就在挑「至少含一个拉丁字母」的 run（行高那一档
// 也用它），西文断字要的正是同一批 run。汉字不受影响——它本来就随处可断。
//
// *lang 只在这条规则的作用域里改。* 文档语言由 iota-hit/src/terms/lang.typ 的 doc-lang
// 这个 state 管，入口写一次，之后没人再读 text.lang，所以这里改它不影响标题取哪
// 一份、词条走哪一层。
//
// *开关是原生的 text.hyphenate，我们不另设一条。* Typst 自己就有这个属性，
// 三种粒度实测都通：全篇 #set text(hyphenate: true)、按元素
// #show figure.caption: set text(hyphenate: true)（子图题也命中，还能再
// .where(kind: image) 分开图题表题）、按页把 #set 裹在那次调用外面（穿得进去，
// 连那两页的页眉页脚一起）。比我们先前那个只有 body / caption 两档的字典细得多。
//
// *判据只认 true。* 原生默认是 auto——「两端对齐就断字」，而正文正是两端
// 对齐的，照 auto 走就成了默认断字，与范例相反（两份 .docx 的 settings.xml 里
// 都没有 w:autoHyphenation，Word 默认关）。所以 auto 与 false 一样当不断。
#let hyphenate-rules(doc) = {
  show latin-run: it => context {
    // *set 而不是包一层*：包成 text(lang: "en", it) 也能排对，但那是*重发*
    // 一段文字，span（源码位置）跟着换成本文件——tinymist 从预览跳回源码时西文会落进
    // 包里。set 只改样式，元素连同 span 原样过。同一条道理见 latin-run-led 那一处
    if text.hyphenate == true { set text(lang: "en"); it } else { it }
  }
  doc
}

// 一个西文单词长到一行都放不下时，Word 会*在单词内部按字符断行*把行填满
// （拿范例改一处英文题目、由 Word 导出实测）。Typst 不会——它把整个单词摆在
// 一行上排到版心外面，PDF 一裁那个词*整个看不见*。
//
// 所以给放不下的单词插零宽空格 U+200B 造断点，实测 Typst 认它，断出来同样
// 把行填满。二十二个字母起才看，且要 measure 量出来确实放不下：二号下一个
// 字母约 15.4pt，装满 425.2 的版心要 28 个；最长的常用英文单词也就二十个上下
// （internationalization 是 20），所以正常单词永远碰不到这条。
#let long-word-min = 22

// 拆超长单词时最多拆成多少段。*256 是 Typst 的硬上限*——超长单词是靠在字母
// 之间插零宽空格拆开的（见下面 latin-run 那条规则），而*一个 run 里的断点
// 过多，Typst 当场停编译*：
//
//   error: maximum grouping depth exceeded
//     while calling `measure` at iota-hit/src/pages/cover.typ:322
//
// 实测边界干净利落：一个单词 255 个字母过，256 个不过，与字号、版心宽、是不是
// 在 measure 里都无关（封面那一处是量高度时先撞上的，直接排也一样炸）。
//
// *所以按段数封顶，不按字母数。* 长过头就每 k 个字母插一个断点，
// k = ⌈字母数 ÷ 250⌉：常见的超长单词（几十到二百来个字母）k 仍是 1，与先前
// 逐字母拆逐字节相同；只有 250 个字母以上的才变粗，代价是行末最多空出 k−1 个
// 字母的位置——比拦住整篇文档不让编译强得多。
#let _long-word-pieces = 250

// 把字母按 k 个一组并起来，好在组与组之间插断点。
#let long-word-chunks(cs) = {
  let k = calc.max(1, calc.ceil(cs.len() / _long-word-pieces))
  if k == 1 { return cs }
  range(0, cs.len(), step: k).map(i => cs.slice(i, calc.min(i + k, cs.len())).join())
}
