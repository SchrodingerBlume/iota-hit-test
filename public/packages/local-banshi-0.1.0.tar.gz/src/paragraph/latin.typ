// 纯西文那一支：整行／整段没有一个汉字时，行高按西文字体的 1.15 算（Word 的「单倍行距」
// 跟着这一行实际用到的字体走）。字距那一半（西文只拿半份）在 ./spacing.typ，断字与长词在
// ./hyphenate.typ；落到 set / show 上的入口在 styles/rules.typ 与 styles/body.typ。

#import "./spacing.typ": spacing, zero-docgrid, latin-tracking
#import "../paragraph/hyphenate.typ" as hyphenate
#import "../content.typ": plain-text
#import "../runs.typ": latin-run, latin-only
#import "../fonts/resolve.typ" as fonts
#import "./spacing.typ": spacing, latin-tracking

// 纯西文行的行高。
//
// *要解决的事。* Word 里一行的行高取这一行*实际用到*的各个字体的
// 最大值，所以同一个设置下，有汉字的行按中易的 1.296875 算，纯英文的行只有
// Times 参与，按 1.15 算。范例的两份摘要就是这样：段落设置相同，中文那份
// 量出 19.4531，英文那份 17.2500。
//
// Typst 的行高本来就是取全行各 run 的最大值——*与 Word 同一条规则*。
// 只是我们把 top-edge / bottom-edge 写成了显式的量（为的是不问加载的是哪个
// 字体、一律按中易的标定排），一写死就对所有 run 一视同仁，纯西文行也拿到了
// 汉字那一份，比 Word 高 2.2pt，合 11%。
//
// 所以给西文 run 单发一份行高，让 Typst 的 max 自己去挑：
//   纯西文行   全是西文 run  → 17.2500
//   混排行     max(西文, 汉字) → 19.4531
//   汉字行     全是汉字 run  → 19.4531
//
// 取值不另写公式，就是同一个 style 把 font-zh 换成 none 再算一遍——
// 换算层认这件事，1.15 那一支有 hithesis 的回归值撑着。
//
// *为什么要求段里至少有一个拉丁字母。* Typst 有个原生的 script 分段行为：
// 拉丁*字母*自成一个 shaping run，而 run 的最后一个字形拿不到 tracking-of；
// 数字和符号算 Common，留在汉字那个 run 里，所以不丢。实测（单一字体、
// 无 covers、无 show 规则、连 cjk-latin-spacing 都关掉，tracking-of 设 2pt，
// 汉字步进该是 14.000）：
//
//   汉→汉 14.000   汉→A 12.000   汉→a 12.000   汉→1 14.000   汉→% 14.000
//
// 所以规则若写成「西文+」，「共12页」里的 1 会被划成独立的 run，那 0.4543
// 的字距就丢了，15.4543 掉到 15.0000。写成「至少含一个字母」就把光是数字的
// 那种放过去，字距保住；而真正要救的纯西文行必然带字母，一个不漏。
//
// 顺带也救了页眉：「第1章」里的 1 不再自成 run，正文那条规则漏进页眉也不
// 起作用了。漏是躲不掉的——set page 的页眉是在正文的样式里排的，而内外两条
// 规则同时命中时同一属性上外层赢（实测：内层设 size 外层设 fill，两个都生效；
// 都设 fill 则外层赢），从页眉内部盖不住。
//
// *上游若修了怎么办。* CJK-Latin 这一带是 typst 公认的粗糙区
// （issue 7475 / 6539 / 2702 / 2703 / 2538）。根因见 PR 7521：
// add_cjk_latin_spacing 不是插入一个间距项，而是去改汉字字形的 x_advance
// 与 offset；作者说正经重构 shaper 这一套「架构改动大、回归风险高」。
// 哪天 run 边界不再吞 tracking-of 了，「至少含一个字母」这条限制就可以松掉，
// 改成「西文+」，光是数字的行也能拿到西文行高；判据是 tests/check-pitch.py
// 里那条汉字接数字的断言在松掉之后还过不过（现在是 15.4543）。
//
// *对齐到网格时这条规则不发。* Word 贴网格时行高就是整数个格，与这一行
// 用了哪些字体无关——按字体分高矮只是不贴格那一档的事。技术上也非发不可：
// Typst 是把各 run 的 top-edge 取一次最大、bottom-edge 再取一次最大，两份
// 行高贴格后居中量不同，凑出来比任何一份都高。实测研究生那一档（单倍贴格）
// 行距从 19.5500 涨到 20.4312，一页少排两行。
//
// *范围为什么写码位。* 见 runs.typ 的 latin-run。
#let latin-line-rules(style, docgrid: zero-docgrid, doc) = {
  let metrics = spacing(style, docgrid: docgrid)
  if metrics.snap { return doc }
  // latin-line-height 是 "cjk"：西文 run 也走汉字那一份行高，什么都不发
  if docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = spacing(style + (font-zh: "latin"), docgrid: docgrid)
  show latin-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  // *智能引号也要换成西文的行高。* 它是 smartquote *元素*，不是文本，
  // latin-run 那条 regex 匹配不到——于是一整行纯西文里只要有一对引号，
  // 那一行就退回汉字的行高，比别的行高 0.9（实测英文摘要里含引号的那两行
  // 比 Word 多 0.9 与 2.2）。挂在 smartquote 上正好补齐，而且与 src/fonts/quotes.typ
  // 里那条换字体的规则落在同一个元素上，不另造 run 边界。
  show smartquote: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 整段换成西文的行高——*只换盒，不碰字距*。
//
// 这一段没有汉字时，行高该按真正在排的那副字（Times）算，而不是按本档挂的中文
// 字体算。判据与换法与正文那一支同源，见 latin-par；*标题、题注走这一支*：
// 它们的字距是本级自己的 w:spacing，Word 对西文照样整份发，不折半。
//
// *而且字距一动就把加粗弄丢了。* style-rules.rules 里那条 show latin-run-led 拿
// 「当前字距等不等于本档 set 的那一份」认「还没被处理过的本档文本」（见
// set-tracking），latin-par 把字距换成西文那半份，守门就认不出来，于是英文档
// 标题的西文那一槽不再加粗——实测深圳研究生英文报告的章节标题掉成
// TimesNewRomanPSMT。只换盒不动字距，守门照旧认得。
#let latin-box(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = spacing(style + (font-zh: "latin"), docgrid: layout.docgrid)
  set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 纯西文段：整段没有一个汉字的段落。Word 里一行的行高取这一行实际用到的字体的
// 最大值，整段都是 Times 的段落每一行都按 Times 算（范例英文摘要 17.25 对中文摘要
// 19.45）。这里把行高、字体表、字距整段换成西文那一份，与 font-zh: "latin" 的样式
// （英文题目、英文内封）走同一支——整段直接 set，不逐 run 挑。
//
// *为什么不靠 latin-line-rules 逐 run 换。* 那一条按 latin-run 收拾纯西文的 run，
// 而 latin-run 要求至少含一个拉丁字母（理由见 runs.typ）。一段英文里夹的引号是
// smartquote 元素、两对引号之间的「, 」只有标点和空格——都不匹配，那一行就退回汉字
// 行高把整行撑高，实测英文摘要含引号的两行比 Word 高 2 到 4pt。整段换就没有漏网的
// 碎片；先前另立的拉丁段落制度（latin-par，英文摘要手动接入）就是这么做的，现在由
// src/styles/body.typ 的 show par 按「整段有没有汉字」自动挑，不用任何标记。
//
// *这里不设 lang。* text.lang 在本项目里是文档语言（哪一份标题上台、词条走哪一层，
// 见 iota-hit/src/terms/lang.typ），同一个字段两种含义会打架；断字由 hyphenate-rules 按
// text.hyphenate 单独管，行高走的是 font-zh: "latin"，都不经过 lang。
//
// 字体：中文语境里弯引号、破折号、省略号、间隔号归中易（见 src/fonts/spacing.typ 的
// covers），英文段落里它们该是西文形。*不能整张字体表换掉*——par 这一层的
// set text(font:) 压得过 iota-hit/lib.typ 里 show raw 的 set（代码字在段落成形之前就已经排好，
// 实测代码里的引号掉到了 Times），所以只把这几个字符挑出来换：一条 regex 规则，
// 与 src/fonts/quotes.typ 里智能引号那条落在同一份字体上。字距直接 set 成半份；shows 里 latin-run 那条规则在这
// 一段里照常跑（它先于 par 那一层跑，读到的还是正文的整份字距），拆超长单词照做，
// 边界补偿它自己按「前面有没有汉字」判，这一段里没有汉字，一处都不补。
//
// *要在 context 里调*（读字体表）；调用方已判过整段没有汉字。
#let latin-par(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  // 贴行网格的段落照汉字行高（西文行也落在格子上）；latin-line-height 是 "cjk" 时
  // 西文也走汉字那一份——两条与 latin-line-rules 同一个判据
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = spacing(style + (font-zh: "latin"), docgrid: layout.docgrid)
  let f = fonts.fontset-state.get()
  set text(tracking: latin-tracking(style, l))
  show regex("[\u{2018}\u{2019}\u{201C}\u{201D}\u{2014}\u{2026}\u{00B7}]"): set text(font: fonts.font("serif", f.families))
  // 行高那一半与标题、题注共用，见 latin-box
  latin-box(style, layout, doc)
}

// 一段字该拿哪一份行高：*段里没有汉字就整段换西文的，有就只换西文那几个 run*。
// 在 show par 里调，要在 context 里（版面由调用方按当前这一节取）。
//
// *判据在段这一级，不在 run 这一级。* 题序那个「2.1.1」是数字，而 latin-run
// 那条 regex 认的是拉丁*字母*——数字与点号是 Common，留在汉字那个 run 里，
// 于是一行西文标题只要带着题序，整行就退回汉字行高。实测英文报告：章标题两行之间
// 26.65（原件 25.92）、节→条 29.31（26.64）、条→正文 25.78（24.48）。正文早就是
// 段级判据了（src/styles/body.typ），标题与题注跟着走同一条。
//
// *「真有西文才算」那一条判的是「有没有排字用的可见字符」*：报告首页那几格
// 填空格的段落 plain 只抽得出一个零宽空格，空段、只有方框（□，不在 ASCII 里）
// 占位的段都不是西文段。判据取「有 ASCII 可见字符」——先前写的是「有拉丁字母或
// 数字」，于是一段纯半角句点（英文表单里那几行「.......」）落在了外面，行高退回
// 汉字那一份，段与段之间因此多 0.91。省略号那几个 ambiguous 码位怎么算，见
// runs.typ 的 latin-only。
#let latin-auto(style, layout, it) = {
  if latin-only(plain-text(it.body)) {
    latin-par(style, layout, it)
  } else {
    latin-line-rules(style, docgrid: layout.docgrid, it)
  }
}
