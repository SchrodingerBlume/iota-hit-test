// 纯西文那一支：整行／整段没有一个汉字时，行盒按西文字体的 1.15 算（Word 的「单倍行距」跟着
// 这一行实际用到的字体走），字距只拿半份；断字与长词（Word 的「换行和分页」卡）也在这儿。
// 落到 set / show 上的入口在 styles/rules.typ。

#import "../content.typ": plain-text
#import "../msword.typ": latin-run, latin-run-led, latin-slot-run, latin-par-features, latin-only
#import "../fonts/resolve.typ" as fonts
#import "../layout/state.typ": page-setup-state
#import "../styles/state.typ": current-styles
#import "./linebox.typ" as linebox

// 纯西文行的行盒。
//
// *要解决的事。* Word 里一行的行高取这一行*实际用到*的各个字体的
// 最大值，所以同一个设置下，有汉字的行按中易的 1.296875 算，纯英文的行只有
// Times 参与，按 1.15 算。范例的两份摘要就是这样：段落设置相同，中文那份
// 量出 19.4531，英文那份 17.2500。
//
// Typst 的行盒本来就是取全行各 run 的最大值——*与 Word 同一条规则*。
// 只是我们把 top-edge / bottom-edge 写成了显式的量（为的是不问加载的是哪个
// 字体、一律按中易的标定排），一写死就对所有 run 一视同仁，纯西文行也拿到了
// 汉字那一份，比 Word 高 2.2pt，合 11%。
//
// 所以给西文 run 单发一份行盒，让 Typst 的 max 自己去挑：
//   纯西文行   全是西文 run  → 17.2500
//   混排行     max(西文, 汉字) → 19.4531
//   汉字行     全是汉字 run  → 19.4531
//
// 取值不另写公式，就是同一个 style 把 font-zh 换成 none 再算一遍——
// 换算层认这件事，1.15 那一支有 hithesis 的回归值撑着。
//
// *为什么要求段里至少有一个拉丁字母。* Typst 有个原生的 script 分段行为：
// 拉丁*字母*自成一个 shaping run，而 run 的最后一个字形拿不到 linebox.tracking；
// 数字和符号算 Common，留在汉字那个 run 里，所以不丢。实测（单一字体、
// 无 covers、无 show 规则、连 cjk-latin-spacing 都关掉，linebox.tracking 设 2pt，
// 汉字步进该是 14.000）：
//
//   汉→汉 14.000   汉→A 12.000   汉→a 12.000   汉→1 14.000   汉→% 14.000
//
// 所以规则若写成「西文+」，「共12页」里的 1 会被划成独立的 run，那 0.4543
// 的字距就丢了，15.4543 掉到 15.0000。写成「至少含一个字母」就把光是数字的
// 那种放过去，字距保住；而真正要救的纯西文行必然带字母，一个不漏。
//
// 顺带也救了页眉：「第1章」里的 1 不再自成 run，正文那条规则漏进页眉也不
// 起作用了。漏是躲不掉的——set page 的页眉是在正文的样式里排的，而内外两条
// 规则同时命中时同一属性上外层赢（实测：内层设 size 外层设 fill，两个都生效；
// 都设 fill 则外层赢），从页眉内部盖不住。
//
// *上游若修了怎么办。* CJK-Latin 这一带是 typst 公认的粗糙区
// （issue 7475 / 6539 / 2702 / 2703 / 2538）。根因见 PR 7521：
// add_cjk_latin_spacing 不是插入一个间距项，而是去改汉字字形的 x_advance
// 与 offset；作者说正经重构 shaper 这一套「架构改动大、回归风险高」。
// 哪天 run 边界不再吞 linebox.tracking 了，「至少含一个字母」这条限制就可以松掉，
// 改成「西文+」，光是数字的行也能拿到西文行盒；判据是 iota-hit/tests/check-pitch.py
// 里那条汉字接数字的断言在松掉之后还过不过（现在是 15.4543）。
//
// *对齐到网格时这条规则不发。* Word 贴网格时行盒就是整数个格，与这一行
// 用了哪些字体无关——按字体分高矮只是不贴格那一档的事。技术上也非发不可：
// Typst 是把各 run 的 top-edge 取一次最大、bottom-edge 再取一次最大，两份
// 行盒贴格后居中量不同，凑出来比任何一份都高。实测研究生那一档（单倍贴格）
// 行距从 19.5500 涨到 20.4312，一页少排两行。
//
// *范围为什么写码位。* 见 msword.typ 的 latin-run。
// 西文断字。
//
// *光开 hyphenate 没用，必须连 lang 一起给。* Typst 按 text.lang 选断字
// 规则表，中文没有那张表——实测同一个 electroencephalographically，lang=en 断成
// electroen-cephalographically，lang=zh 整词甩到下一行，设不设 hyphenate 都一样。
//
// 挂在 latin-run 上：那条正则本来就在挑「至少含一个拉丁字母」的 run（行盒那一档
// 也用它），西文断字要的正是同一批 run。汉字不受影响——它本来就随处可断。
//
// *lang 只在这条规则的作用域里改。* 文档语言由 iota-hit/src/terms/lang.typ 的 doc-lang
// 这个 state 管，入口写一次，之后没人再读 text.lang，所以这里改它不影响标题取哪
// 一份、词条走哪一层。
//
// *开关是原生的 text.hyphenate，我们不另设一条。* Typst 自己就有这个属性，
// 三种粒度实测都通：全篇 #set text(hyphenate: true)、按元素
// #show figure.caption: set text(hyphenate: true)（子图题也命中，还能再
// .where(kind: image) 分开图题表题）、按页把 #set 裹在那次调用外面（穿得进去，
// 连那两页的页眉页脚一起）。比我们先前那个只有 body / caption 两档的字典细得多。
//
// *判据只认 true。* 原生默认是 auto——「两端对齐就断字」，而正文正是两端
// 对齐的，照 auto 走就成了默认断字，与范例相反（两份 .docx 的 settings.xml 里
// 都没有 w:autoHyphenation，Word 默认关）。所以 auto 与 false 一样当不断。
#let hyphenate-rules(doc) = {
  show latin-run: it => context {
    // *set 而不是包一层*：包成 text(lang: "en", it) 也能排对，但那是*重发*
    // 一段文字，span（源码位置）跟着换成本文件——tinymist 从预览跳回源码时西文会落进
    // 包里。set 只改样式，元素连同 span 原样过。同一条道理见 latin-run-led 那一处
    if text.hyphenate == true { set text(lang: "en"); it } else { it }
  }
  doc
}

#let latin-line-rules(style, docgrid: linebox.zero-docgrid, doc) = {
  let metrics = linebox.resolve(style, docgrid: docgrid)
  if metrics.snap { return doc }
  // latin-line-height 是 "cjk"：西文 run 也走汉字那一份行盒，什么都不发
  if docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = linebox.resolve(style + (font-zh: "latin"), docgrid: docgrid)
  show latin-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  // *智能引号也要换成西文的行盒。* 它是 smartquote *元素*，不是文本，
  // latin-run 那条 regex 匹配不到——于是一整行纯西文里只要有一对引号，
  // 那一行就退回汉字的行盒，比别的行高 0.9（实测英文摘要里含引号的那两行
  // 比 Word 多 0.9 与 2.2）。挂在 smartquote 上正好补齐，而且与 src/fonts/quotes.typ
  // 里那条换字体的规则落在同一个元素上，不另造 run 边界。
  show smartquote: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 一个西文单词长到一行都放不下时，Word 会*在单词内部按字符断行*把行填满
// （拿范例改一处英文题目、由 Word 导出实测）。Typst 不会——它把整个单词摆在
// 一行上排到版心外面，PDF 一裁那个词*整个看不见*。
//
// 所以给放不下的单词插零宽空格 U+200B 造断点，实测 Typst 认它，断出来同样
// 把行填满。二十二个字母起才看，且要 measure 量出来确实放不下：二号下一个
// 字母约 15.4pt，装满 425.2 的版心要 28 个；最长的常用英文单词也就二十个上下
// （internationalization 是 20），所以正常单词永远碰不到这条。
#let long-word-min = 22

// 拆超长单词时最多拆成多少段。*256 是 Typst 的硬上限*——超长单词是靠在字母
// 之间插零宽空格拆开的（见下面 latin-run 那条规则），而*一个 run 里的断点
// 过多，Typst 当场停编译*：
//
//   error: maximum grouping depth exceeded
//     while calling `measure` at iota-hit/src/pages/cover.typ:322
//
// 实测边界干净利落：一个单词 255 个字母过，256 个不过，与字号、版心宽、是不是
// 在 measure 里都无关（封面那一处是量高度时先撞上的，直接排也一样炸）。
//
// *所以按段数封顶，不按字母数。* 长过头就每 k 个字母插一个断点，
// k = ⌈字母数 ÷ 250⌉：常见的超长单词（几十到二百来个字母）k 仍是 1，与先前
// 逐字母拆逐字节相同；只有 250 个字母以上的才变粗，代价是行末最多空出 k−1 个
// 字母的位置——比拦住整篇文档不让编译强得多。
#let _long-word-pieces = 250

// 把字母按 k 个一组并起来，好在组与组之间插断点。

// 把字母按 k 个一组并起来，好在组与组之间插断点。

// 把字母按 k 个一组并起来，好在组与组之间插断点。
#let long-word-chunks(cs) = {
  let k = calc.max(1, calc.ceil(cs.len() / _long-word-pieces))
  if k == 1 { return cs }
  range(0, cs.len(), step: k).map(i => cs.slice(i, calc.min(i + k, cs.len())).join())
}

// 角色名 → 发给 text(font:) 的字体表。
//
// 内部一律写角色（songti / heiti / kaishu / fangsong / serif …），不写家族名，
// 换字体档自动跟上。
//
// *全宽符号先由宋体抢回来，两支都抢。* Typst 的 "latin-in-cjk" 会把「↑」
// 「□」收去排成西文半宽，而 Word 排的是中易全宽——它们是无字符集归属的字，
// Word 按 w:hint="eastAsia" 判给 eastAsia 那一槽，而全文的 eastAsia 默认是宋体。
//
// *抢的是宋体，不是当前角色的家族。* 先前中文那一支写的是
// families.at(role)，于是黑体行里的「□」跟着变黑体；西文那一支*整个没有
// 这一层*，「□」只能靠 Typst 的全局兜底，兜到哪算哪——英文内封那三个「□□□」
// 眼下落在宋体上是兜出来的，换一台机器上 Times 若带这个字形就变成西文半宽了。
// latin 收*这一档的西文走哪个角色*。默认 serif：论文范例里黑体行的西文就是
// Times（内封「Candidate：」「Date of Defence：」那几行逐行量过，SimHei 14 ＋
// TimesNewRomanPS-Bold），hithesis 也把「标题西文换无衬线」做成默认关着的选项。
// 写 sans 的地方*是原件自己把西文槽也写成了中文字体*——深圳本科封面题目那一格
// 的 w:rFonts 是 ascii/hAnsi/eastAsia 全黑体，黑体自带的西文就是无衬线的。
// em-dash：破折号排哪一副字，从 fonts.fontset-state 的表里读着传进来（fonts.resolve 存的）

// shows 里的 context 取版面：current 关着就是装规则时那一份（部件层）；开着从
// page-setup-state 取当前这一节的（正文那一档）。state 还是 none 的地方——第一页的页眉
// 在文档级那次 update 之前就排了（实测页眉读到的是本页开头之前的值）——退回装规则
// 时那一份，与先前一字不差。*要在 context 里调*

// 纯西文段（font-zh: "latin"——这一段没有汉字）：西文吃半格，直接 set，不发
// latin-run 那条 show 规则里的边界补偿。那条规则给每个西文 run 前面补「前一个汉字在
// run 边界丢掉的字距」，可这一段前面没有汉字，补出来就是一段假缩进（实测目录里
// 「Abstract」的 A 落在 85.50，Word 85.03）。英文摘要、英文目录、英文内封、英文题注
// 都走这一支。
#let pure-latin(style) = style.at("font-zh", default: "songti") == "latin"

// latin-bold 这一档的加粗走哪条路。要在 context 里调（查探针那张表）。
//
// *字体表那条*：整段 set weight，中西两槽各自挑面——这一档中文字没有真粗面才走得成，
// 详见下面 shows 里那段注释。*show 规则那条*：中文字有真粗面（或家族不在）的那几档，
// 只能逐段挑西文槽的字包一层 weight（latin-slot-run）。两条互斥。

// shows 里的 context 取版面：current 关着就是装规则时那一份（部件层）；开着从
// page-setup-state 取当前这一节的（正文那一档）。state 还是 none 的地方——第一页的页眉
// 在文档级那次 update 之前就排了（实测页眉读到的是本页开头之前的值）——退回装规则
// 时那一份，与先前一字不差。*要在 context 里调*
#let layout-of(layout, current) = {
  if not current { return layout }
  let s = page-setup-state.get()
  if s == none { layout } else { s }
}
// 同一件事的样式那一半：正文那一档（current 开着）的规则从 styles-state 现取 body——局部
// new-styles 改了行距、缩进，规则里的行盒与字距才跟得上；部件层照旧用装规则时那一份。
// *要在 context 里调*
#let style-of(style, current) = if current { current-styles().body } else { style }
// 整段换成西文的行盒——*只换盒，不碰字距*。
//
// 这一段没有汉字时，行高该按真正在排的那副字（Times）算，而不是按本档挂的中文
// 字体算。判据与换法与正文那一支同源，见 latin-par；*标题、题注走这一支*：
// 它们的字距是本级自己的 w:spacing，Word 对西文照样整份发，不折半。
//
// *而且字距一动就把加粗弄丢了。* style-rules.rules 里那条 show latin-run-led 拿
// 「当前字距等不等于本档 set 的那一份」认「还没被处理过的本档文本」（见
// set-tracking），latin-par 把字距换成西文那半份，守门就认不出来，于是英文档
// 标题的西文那一槽不再加粗——实测深圳研究生英文报告的章节标题掉成
// TimesNewRomanPSMT。只换盒不动字距，守门照旧认得。

// 西文的字距是汉字的一半——两截都是。
//
// *网格增量*：Word 按「占几格」发，全宽字占一格拿整份（charSpace/4096 =
// 0.4543），半宽的西文占半格拿半份 0.227，见 shows 里 latin-run 那条规则的注释。
//
// *样式的字符间距*（字体对话框「字符间距：加宽／紧缩 n 磅」）：Word 给汉字
// 发*两份*、给西文发*一份*。量官方本科理工范例 PDF 第 11 页的章标题
// 「第4章 基于FLUENT软件的轴承静态特性分析」（heading 1 样式紧缩 0.2 磅）：汉字
// 实排步进 18.04 = 18 + 0.4543 − 0.4，紧缩了对话框的两倍；F/L/U/E/N/T 的步进
// 10.008 / 10.998 / 12.996 就是 Times 18pt 的字身宽——半格 0.227 与一份 0.2
// 相抵。样式表里 linebox.tracking 存的是汉字实排的那两份（chapter −0.4pt），西文对半：
//
//   西文每字   字身宽 + 0.227 − 0.2 = 字身宽 + 0.027（范例 +0.004，差在 Word
//              1/300 英寸落笔）
//   汉字每字   字号 + 0.4543 − 0.4 = 字号 + 0.054
//
// 对拍：iota-hit/tests/check-heading.py 逐字量 FLUENT 的步进。
#let latin-tracking(style, computed) = (
  (if computed.snap-h { computed.docgrid.tracking / 2 } else { 0pt })
    + style.at("tracking", default: 0pt) / 2
)

// 这一档 set 给正文的字距：纯西文段是半份，别的是整份。shows 里的守门拿它认
// 「还没被处理过的本档文本」
#let set-tracking(style, computed) = if pure-latin(style) {
  latin-tracking(style, computed)
} else {
  linebox.tracking(computed, tracking: style.at("tracking", default: 0pt))
}

// shows 里的 context 取版面：current 关着就是装规则时那一份（部件层）；开着从
// page-setup-state 取当前这一节的（正文那一档）。state 还是 none 的地方——第一页的页眉
// 在文档级那次 update 之前就排了（实测页眉读到的是本页开头之前的值）——退回装规则
// 时那一份，与先前一字不差。*要在 context 里调*

// 纯西文行的行盒。
//
// *要解决的事。* Word 里一行的行高取这一行*实际用到*的各个字体的
// 最大值，所以同一个设置下，有汉字的行按中易的 1.296875 算，纯英文的行只有
// Times 参与，按 1.15 算。范例的两份摘要就是这样：段落设置相同，中文那份
// 量出 19.4531，英文那份 17.2500。
//
// Typst 的行盒本来就是取全行各 run 的最大值——*与 Word 同一条规则*。
// 只是我们把 top-edge / bottom-edge 写成了显式的量（为的是不问加载的是哪个
// 字体、一律按中易的标定排），一写死就对所有 run 一视同仁，纯西文行也拿到了
// 汉字那一份，比 Word 高 2.2pt，合 11%。
//
// 所以给西文 run 单发一份行盒，让 Typst 的 max 自己去挑：
//   纯西文行   全是西文 run  → 17.2500
//   混排行     max(西文, 汉字) → 19.4531
//   汉字行     全是汉字 run  → 19.4531
//
// 取值不另写公式，就是同一个 style 把 font-zh 换成 none 再算一遍——
// 换算层认这件事，1.15 那一支有 hithesis 的回归值撑着。
//
// *为什么要求段里至少有一个拉丁字母。* Typst 有个原生的 script 分段行为：
// 拉丁*字母*自成一个 shaping run，而 run 的最后一个字形拿不到 linebox.tracking；
// 数字和符号算 Common，留在汉字那个 run 里，所以不丢。实测（单一字体、
// 无 covers、无 show 规则、连 cjk-latin-spacing 都关掉，linebox.tracking 设 2pt，
// 汉字步进该是 14.000）：
//
//   汉→汉 14.000   汉→A 12.000   汉→a 12.000   汉→1 14.000   汉→% 14.000
//
// 所以规则若写成「西文+」，「共12页」里的 1 会被划成独立的 run，那 0.4543
// 的字距就丢了，15.4543 掉到 15.0000。写成「至少含一个字母」就把光是数字的
// 那种放过去，字距保住；而真正要救的纯西文行必然带字母，一个不漏。
//
// 顺带也救了页眉：「第1章」里的 1 不再自成 run，正文那条规则漏进页眉也不
// 起作用了。漏是躲不掉的——set page 的页眉是在正文的样式里排的，而内外两条
// 规则同时命中时同一属性上外层赢（实测：内层设 size 外层设 fill，两个都生效；
// 都设 fill 则外层赢），从页眉内部盖不住。
//
// *上游若修了怎么办。* CJK-Latin 这一带是 typst 公认的粗糙区
// （issue 7475 / 6539 / 2702 / 2703 / 2538）。根因见 PR 7521：
// add_cjk_latin_spacing 不是插入一个间距项，而是去改汉字字形的 x_advance
// 与 offset；作者说正经重构 shaper 这一套「架构改动大、回归风险高」。
// 哪天 run 边界不再吞 linebox.tracking 了，「至少含一个字母」这条限制就可以松掉，
// 改成「西文+」，光是数字的行也能拿到西文行盒；判据是 iota-hit/tests/check-pitch.py
// 里那条汉字接数字的断言在松掉之后还过不过（现在是 15.4543）。
//
// *对齐到网格时这条规则不发。* Word 贴网格时行盒就是整数个格，与这一行
// 用了哪些字体无关——按字体分高矮只是不贴格那一档的事。技术上也非发不可：
// Typst 是把各 run 的 top-edge 取一次最大、bottom-edge 再取一次最大，两份
// 行盒贴格后居中量不同，凑出来比任何一份都高。实测研究生那一档（单倍贴格）
// 行距从 19.5500 涨到 20.4312，一页少排两行。
//
// *范围为什么写码位。* 见 msword.typ 的 latin-run。
// 西文断字。
//
// *光开 hyphenate 没用，必须连 lang 一起给。* Typst 按 text.lang 选断字
// 规则表，中文没有那张表——实测同一个 electroencephalographically，lang=en 断成
// electroen-cephalographically，lang=zh 整词甩到下一行，设不设 hyphenate 都一样。
//
// 挂在 latin-run 上：那条正则本来就在挑「至少含一个拉丁字母」的 run（行盒那一档
// 也用它），西文断字要的正是同一批 run。汉字不受影响——它本来就随处可断。
//
// *lang 只在这条规则的作用域里改。* 文档语言由 iota-hit/src/terms/lang.typ 的 doc-lang
// 这个 state 管，入口写一次，之后没人再读 text.lang，所以这里改它不影响标题取哪
// 一份、词条走哪一层。
//
// *开关是原生的 text.hyphenate，我们不另设一条。* Typst 自己就有这个属性，
// 三种粒度实测都通：全篇 #set text(hyphenate: true)、按元素
// #show figure.caption: set text(hyphenate: true)（子图题也命中，还能再
// .where(kind: image) 分开图题表题）、按页把 #set 裹在那次调用外面（穿得进去，
// 连那两页的页眉页脚一起）。比我们先前那个只有 body / caption 两档的字典细得多。
//
// *判据只认 true。* 原生默认是 auto——「两端对齐就断字」，而正文正是两端
// 对齐的，照 auto 走就成了默认断字，与范例相反（两份 .docx 的 settings.xml 里
// 都没有 w:autoHyphenation，Word 默认关）。所以 auto 与 false 一样当不断。

// 整段换成西文的行盒——*只换盒，不碰字距*。
//
// 这一段没有汉字时，行高该按真正在排的那副字（Times）算，而不是按本档挂的中文
// 字体算。判据与换法与正文那一支同源，见 latin-par；*标题、题注走这一支*：
// 它们的字距是本级自己的 w:spacing，Word 对西文照样整份发，不折半。
//
// *而且字距一动就把加粗弄丢了。* style-rules.rules 里那条 show latin-run-led 拿
// 「当前字距等不等于本档 set 的那一份」认「还没被处理过的本档文本」（见
// set-tracking），latin-par 把字距换成西文那半份，守门就认不出来，于是英文档
// 标题的西文那一槽不再加粗——实测深圳研究生英文报告的章节标题掉成
// TimesNewRomanPSMT。只换盒不动字距，守门照旧认得。
#let latin-box(style, layout, doc) = {
  let metrics = linebox.resolve(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = linebox.resolve(style + (font-zh: "latin"), docgrid: layout.docgrid)
  set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}


// 纯西文段：整段没有一个汉字的段落。Word 里一行的行高取这一行实际用到的字体的
// 最大值，整段都是 Times 的段落每一行都按 Times 算（范例英文摘要 17.25 对中文摘要
// 19.45）。这里把行盒、字体表、字距整段换成西文那一份，与 font-zh: "latin" 的样式
// （英文题目、英文内封）走同一支——整段直接 set，不逐 run 挑。
//
// *为什么不靠 latin-line-rules 逐 run 换。* 那一条按 latin-run 收拾纯西文的 run，
// 而 latin-run 要求至少含一个拉丁字母（理由见 msword.typ）。一段英文里夹的引号是
// smartquote 元素、两对引号之间的「, 」只有标点和空格——都不匹配，那一行就退回汉字
// 行盒把整行撑高，实测英文摘要含引号的两行比 Word 高 2 到 4pt。整段换就没有漏网的
// 碎片；先前另立的拉丁段落制度（latin-par，英文摘要手动接入）就是这么做的，现在由
// src/styles/body.typ 的 show par 按「整段有没有汉字」自动挑，不用任何标记。
//
// *这里不设 lang。* text.lang 在本项目里是文档语言（哪一份标题上台、词条走哪一层，
// 见 iota-hit/src/terms/lang.typ），同一个字段两种含义会打架；断字由 hyphenate-rules 按
// text.hyphenate 单独管，行高走的是 font-zh: "latin"，都不经过 lang。
//
// 字体：中文语境里弯引号、破折号、省略号、间隔号归中易（见 src/fonts/linebox.resolve.typ 的
// covers），英文段落里它们该是西文形。*不能整张字体表换掉*——par 这一层的
// set text(font:) 压得过 iota-hit/lib.typ 里 show raw 的 set（代码字在段落成形之前就已经排好，
// 实测代码里的引号掉到了 Times），所以只把这几个字符挑出来换：一条 regex 规则，
// 与 src/fonts/quotes.typ 里智能引号那条落在同一份字体上。字距直接 set 成半份；shows 里 latin-run 那条规则在这
// 一段里照常跑（它先于 par 那一层跑，读到的还是正文的整份字距），拆超长单词照做，
// 边界补偿它自己按「前面有没有汉字」判，这一段里没有汉字，一处都不补。
//
// *要在 context 里调*（读字体表）；调用方已判过整段没有汉字。
#let latin-par(style, layout, doc) = {
  let metrics = linebox.resolve(style, docgrid: layout.docgrid)
  // 贴行网格的段落照汉字行盒（西文行也落在格子上）；latin-line-height 是 "cjk" 时
  // 西文也走汉字那一份——两条与 latin-line-rules 同一个判据
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = linebox.resolve(style + (font-zh: "latin"), docgrid: layout.docgrid)
  let f = fonts.fontset-state.get()
  set text(tracking: latin-tracking(style, l))
  show regex("[\u{2018}\u{2019}\u{201C}\u{201D}\u{2014}\u{2026}\u{00B7}]"): set text(font: fonts.font("serif", f.families))
  // 行盒那一半与标题、题注共用，见 latin-box
  latin-box(style, layout, doc)
}

// 一段字该拿哪一份行盒：*段里没有汉字就整段换西文的，有就只换西文那几个 run*。
// 在 show par 里调，要在 context 里（版面由调用方按当前这一节取）。
//
// *判据在段这一级，不在 run 这一级。* 题序那个「2.1.1」是数字，而 latin-run
// 那条 regex 认的是拉丁*字母*——数字与点号是 Common，留在汉字那个 run 里，
// 于是一行西文标题只要带着题序，整行就退回汉字行盒。实测英文报告：章标题两行之间
// 26.65（原件 25.92）、节→条 29.31（26.64）、条→正文 25.78（24.48）。正文早就是
// 段级判据了（src/styles/body.typ），标题与题注跟着走同一条。
//
// *「真有西文才算」那一条判的是「有没有排字用的可见字符」*：报告首页那几格
// 填空格的段落 plain 只抽得出一个零宽空格，空段、只有方框（□，不在 ASCII 里）
// 占位的段都不是西文段。判据取「有 ASCII 可见字符」——先前写的是「有拉丁字母或
// 数字」，于是一段纯半角句点（英文表单里那几行「.......」）落在了外面，行盒退回
// 汉字那一份，段与段之间因此多 0.91。省略号那几个 ambiguous 码位怎么算，见
// msword.typ 的 latin-only。
#let latin-auto(style, layout, it) = {
  if latin-only(plain-text(it.body)) {
    latin-par(style, layout, it)
  } else {
    latin-line-rules(style, docgrid: layout.docgrid, it)
  }
}

// 一条样式的 set 那一半：字与段。families 给了就一并设字体（已经解析好的家族表），
// none 不碰字体——正文那一档的字体是 iota-hit 在最外层设的。
// latin-par：这一档的段落参不参与正文那条「纯西文段换西文行盒」的 show par，
// 见 src/msword.typ 的 latin-par-features。默认不参与
