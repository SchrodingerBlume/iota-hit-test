// 纯西文行和段使用西文字体的单倍行高度量；断字规则位于 hyphenate.typ。

#import "./spacing.typ": spacing, zero-docgrid, latin-tracking
#import "../paragraph/hyphenate.typ" as hyphenate
#import "../content.typ": plain-text
#import "../runs.typ": latin-run, latin-only
#import "../fonts/resolve.typ" as fonts
#import "./spacing.typ": spacing, latin-tracking

// Word 行高取该行实际字体度量的最大值；两份摘要在相同段落设置下分别量得
// 纯西文 17.2500pt、含汉字 19.4531pt。规则要求 latin-run 至少包含一个
// 拉丁字母，原因、上游 issue 与解除限制的测试判据见 runs.typ。
#let latin-line-rules(style, docgrid: zero-docgrid, doc) = {
  let metrics = spacing(style, docgrid: docgrid)
  if metrics.snap { return doc }
  if docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = spacing(style + (font-zh: "latin"), docgrid: docgrid)
  show latin-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  show smartquote: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 纯西文行按实际西文字体计算行高；样式自身的 `w:spacing` 不因西文而折半。
#let latin-box(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = spacing(style + (font-zh: "latin"), docgrid: layout.docgrid)
  set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 纯西文段：整段没有一个汉字的段落。Word 里一行的行高取这一行实际用到的字体的最大值，整段都是 Times 的段落每一行都按 Times 算（范例英文摘要 17.25 对中文摘要19.45）。
#let latin-par(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = spacing(style + (font-zh: "latin"), docgrid: layout.docgrid)
  let f = fonts.fontset-state.get()
  set text(tracking: latin-tracking(style, l))
  show regex("[\u{2018}\u{2019}\u{201C}\u{201D}\u{2014}\u{2026}\u{00B7}]"): set text(font: fonts.font("serif", f.families))
  latin-box(style, layout, doc)
}

// 一段字该拿哪一份行高：段里没有汉字就整段换西文的，有就只换西文那几个 run。
#let latin-auto(style, layout, it) = {
  if latin-only(plain-text(it.body)) {
    latin-par(style, layout, it)
  } else {
    latin-line-rules(style, docgrid: layout.docgrid, it)
  }
}
