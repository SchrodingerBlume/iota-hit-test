// 纯西文行和段使用西文字体的单倍行高度量；断字规则位于 hyphenate.typ。

#import "./spacing.typ": spacing, zero-docgrid, latin-tracking
#import "../paragraph/hyphenate.typ" as hyphenate
#import "../content.typ": plain-text
#import "../runs.typ": latin-only
#import "../runs/regex.typ": latin-run, latin-slot-run, latin-line-features
#import "../fonts/resolve.typ" as fonts
#import "./spacing.typ": spacing, latin-tracking

// Word 行高取该行实际字体度量的最大值；两份摘要在相同段落设置下分别量得
// 纯西文 17.2500pt、含汉字 19.4531pt。
/// 逐片段给西文换行高：不贴网格时西文片段按西文字体的单倍行高，含汉字的行仍按中文。
/// `char-grid: false` 用于不吃字符网格增量的地方（页眉页脚）。
/// -> content
#let latin-line-rules(style, docgrid: zero-docgrid, char-grid: true, doc) = {
  let metrics = spacing(style, docgrid: docgrid, char-grid: char-grid)
  if metrics.snap { return doc }
  let l = spacing(style, docgrid: docgrid, latin: true)
  show smartquote: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  // 字符网格下西文段由 styles/rules 的 latin-runs 连行高一起切：这里再切一刀就丢字距，只打标记
  if metrics.snap-h or style.at("latin-bold", default: false) {
    set text(features: latin-line-features(true))
    doc
  } else {
    show latin-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
    doc
  }
}

/// 给西文槽的片段换西文行高，汉字照旧：一行里全是西文时行高按西文字体，混着汉字时取
/// 最大值。不看是否贴网格，供表单那类逐行按自己字体排的页面使用。
/// -> content
#let latin-slot-box(style, layout, doc) = {
  let l = spacing(style, layout: layout, latin: true)
  show latin-slot-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

/// 整段换成西文行高，不改字距；供纯西文的标题与题注使用。
/// -> content
#let latin-box(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  let l = spacing(style, docgrid: layout.docgrid, latin: true)
  set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 纯西文段整段使用西文字体行高；混排段只替换其中的西文片段。
#let latin-par(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  let l = spacing(style, docgrid: layout.docgrid, latin: true)
  let f = fonts.fontset-state.get()
  set text(tracking: latin-tracking(style, l))
  show regex("[\u{2018}\u{2019}\u{201C}\u{201D}\u{2014}\u{2026}\u{00B7}]"): set text(font: fonts.font("serif", f.families))
  latin-box(style, layout, doc)
}

#let _latin-by-text(style, layout, s, doc) = if latin-only(s) {
  latin-par(style, layout, doc)
} else {
  latin-line-rules(style, docgrid: layout.docgrid, doc)
}

#let latin-auto(style, layout, it) = _latin-by-text(style, layout, plain-text(it.body), it)

/// 不成 par 的一块字（格子里没分段的字）照正文逐段的规则换西文行高；块里分了段的各段自己判。
/// -> content
#let latin-block(style, layout, body) = {
  show par: it => latin-auto(style, layout, it)
  _latin-by-text(style, layout, plain-text(body), body)
}
