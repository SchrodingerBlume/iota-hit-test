// 行盒的换算：一条样式（字号、行距、贴不贴网格……）在网格下折成绝对量——行盒的两截、
// 首行基线落点、缩进、段前段后、字距。对照 hithesis 的 src/utils/hit-format.dtx「换算」一节。
// 纯函数，不碰排版，好拿回归值逐条对拍。

#import "../fonts/presets.typ": zihao, ascent-const, ascent-coefs, ascent-default, exact-first-ratio, ink-height, natural-coefs, natural-default
#import "../msword.typ": floor-to-twip, latin-run

// 每个纵向的量都记成一个*复合长度*：em 系数 × 字号 + 绝对量。
//
// 两截分开记不是为了好看，是为了让行盒在*任何*字号上都精确。上升部是
// 1.008 × 字号 + 0.082pt，那个常数项不随字号缩放；整个量先在正文字号上折成
// 一个数、再按比例套给别的字号的话，常数项会跟着被缩放一次，行内混进大字时
// 就差那么一点。两截原样写进 top-edge / bottom-edge 即可。
//
// *直接用 Typst 的 length，不自己造记录。* length 本身就有 abs 与 em
// 两个字段（typst-library/src/layout/length.rs 的 Fields 一节），加减乘也是
// 原生的：
//
//     let a = 1.25em + 0.082pt      a.abs = 0.082pt   a.em = 1.25
//     a + 0.5em - 1pt               2 * a
//
// 这里先前自造了 (em:, abs:) 字典加六个算术函数，是在重造这个类型。
//
// 只有一处 Typst 给不了：*按指定字号折算*。to-absolute() 折的是当前
// 生效的字号，而我们要按这一档 style 自己的字号折——所以留下 _absolute。
// 没有文档网格时的三个量。resolve 的默认参数，也给下面的 no-docgrid 用。
#let zero-docgrid = (
  line-pitch: 0pt, char-pitch: 0pt, tracking: 0pt,
  // 没网格就没网格：贴不了，「一行」也无从谈起（(lines: n) 折出 0）
  grid: false, line-unit: 0pt,
)

// 没有网格的场合（独立小部件、enter 之类）用它，省得各处拼一个假 layout。

// 没有网格的场合（独立小部件、enter 之类）用它，省得各处拼一个假 layout。
#let no-docgrid = (
  docgrid: zero-docgrid,
  base-size: 12pt,
  cells: 0,
  text-width: 0pt,
)

#let _absolute(len, size) = len.abs + len.em * size
// 在这个字号上谁大取谁。复合长度比不了大小，得先各自折成绝对量。

// 在这个字号上谁大取谁。复合长度比不了大小，得先各自折成绝对量。
#let _max(a, b, size) = if _absolute(a, size) >= _absolute(b, size) { a } else { b }

// 倍数写法。对齐到网格时是网格行距的倍数，一行装不下就往上取整到整数个格；
// 关掉时是自然行高的倍数，与网格无关。
//
// 不贴网格那一支是纯 em：行距与字号成正比，换个字号照样对。
// 贴网格那一支是纯绝对量：格子是死的，跟字号无关。
#let _multiple-baseline-gap(k, coef, size, docgrid, snap) = {
  if not snap { return k * coef * 1em }
  let len = k * docgrid.line-pitch
  let floor = calc.ceil(coef * size / docgrid.line-pitch) * docgrid.line-pitch
  calc.max(len, floor)
}

// 一个行距端点折成基线距。倍数没有单位，光看写下来的字不知道有多长，
// 所以要等字号、自然行高、网格行距都齐了才折。
//
//   "single" / "double"   Word 下拉框里的词，折成 1 与 2
//   1.25                  倍数
//   (exactly: 25pt)       Word 的固定值，网格与字号都不介入，比字号小也照给
//   (at-least: 10pt)      Word 的最小值
//   (white: 3mm)          视觉白，模板的扩展，换基线距要加一个字面高
//   19pt                  就是这么长，不设下限
//
// 返回 (mode, gap)：mode 只有 "exactly" 那一档会改基线落点。
#let _baseline-gap-endpoint(value, coef, size, docgrid, snap) = {
  if value == "single" {
    return (mode: "multiple", gap: _multiple-baseline-gap(1.0, coef, size, docgrid, snap))
  }
  if value == "double" {
    return (mode: "multiple", gap: _multiple-baseline-gap(2.0, coef, size, docgrid, snap))
  }
  if type(value) in (int, float) {
    return (mode: "multiple", gap: _multiple-baseline-gap(float(value), coef, size, docgrid, snap))
  }
  if type(value) == length {
    return (mode: "length", gap: value)
  }
  if type(value) == dictionary {
    if "exactly" in value {
      return (mode: "exactly", gap: value.at("exactly"))
    }
    if "at-least" in value {
      // 网格开看网格行距，网格关看自然行高
      let given = value.at("at-least")
      let floor = if snap { docgrid.line-pitch } else { coef * 1em }
      if given >= _absolute(floor, size) {
        return (mode: "at-least", gap: given)
      }
      return (mode: "at-least", gap: floor)
    }
    if "white" in value {
      // 基线距 = 视觉白 + 0.9050 × 字号
      return (mode: "white", gap: ink-height * 1em + value.at("white"))
    }
  }
  panic("expected number, length, or dictionary with \"at-least\" or \"white\", " + "found " + repr(value))
}

// 基线在行盒里的位置。
// 对齐到网格时行盒居中，基线在盒顶下方「行盒高减自然行高的一半，再加上升部」；
// 关掉时顶对齐，倍数多出来的量全落在基线之下，基线就在上升部处。
// 固定值是另一套，基线在盒顶下方 0.8 倍盒高，与网格开关无关。
//
// 居中多出来的那一段归进绝对量而不是 em 系数：它是这一段所在的网格的性质，
// 不是这个字号的性质。行内混进别的字号时，Word 那边也是按该 run 的上升部
// 算，不按网格重新居中。
//
// *「整份居中」这一条有一处反例，记在这儿省得再查一遍。* 居中现在是拿
// 整份（行盒高 − 自然行高）算的，靶子是本科范例内封那张真表格（四号 1.5 倍、
// 贴 19.75 的网格，见 iota-hit/tests/check-titlepage.py 的七条基线），改成「只居中取整
// 多出来的那一截」会让七行整体上移 5.1、全红。可*正文故事里的段落不是
// 这样*：深圳硕士开题的节标题（小三 1.35 倍、贴 19.55 的网格）逐条量下来，
// 一级→二级 40.08、二级→正文 33.12 两处同时对上的只有「倍数多出来的那一截
// 落在基线下」那一解，整份居中要差 3.5。两处都是实测，一条公式盖不住，
// 所以没有动这里。哪天要统一，得先弄清 Word 在表格里与在正文里贴网格是不是
// 两套算法。
#let _ascent-of(mode, baseline-gap, coef, size, snap, asc-coef) = {
  if mode == "exactly" { return exact-first-ratio * baseline-gap }
  let ascent = asc-coef * 1em + ascent-const
  if not snap { return ascent }
  let center = (_absolute(baseline-gap, size) - coef * size) / 2
  ascent + center
}

// 段前段后的量。「行」这个单位恒指网格行距，与该段自己的行距无关，也与这一段
// 对不对齐网格无关。折成长度以后要往下截到整缇，Word 存盘时就是这么干的。
//
// *只收「行」，不收「字」。* 单位跟着 Word 的对话框走：段前段后那一栏只给
// 「行」和「磅」两种，缩进那一栏才给「字符」。范例的 docx 里数得出来——
// firstLineChars 124 次、beforeLines / afterLines 11 / 9 次，
// beforeChars / afterChars *零次*（OOXML 里根本没有这两个属性）。
//
// 先前这里多收一个 (chars: n)，全项目一次没用过，而且是串了轴的——docgrid.char-pitch
// 是一格的*横向*宽度，拿它量*纵向*间距不对。已删。
#let amount(value, docgrid) = {
  if value == none { return 0pt }
  if type(value) == length { return value }
  if type(value) == dictionary and "lines" in value {
    // *乘的是 line-unit 不是 line-pitch*：Word 的「一行」在网格启用时
    // 是一个网格行，不启用时是正文的一个字号，见 src/layout/resolve.typ 的 fold
    return floor-to-twip(value.at("lines") * docgrid.line-unit)
  }
  panic("expected length or dictionary with \"lines\", found " + repr(value))
}

// 首行缩进与悬挂缩进。两个键名照 Typst 的 par.first-line-indent /
// par.hanging-indent。先前是一个 indent-special 键收一个 (first-line: n) 字典
// ——多包一层，键名也与 Typst 对不上。
//
// 收 (chars: n) 就是「几个字」，收长度就照长度。
//
// *「几个字」跟当前字号走，不钉在基准字号上。* 与 chars.ccwd 同一个式子
// （n × 1em + n × 字距增量）——这边不能 import part（那边 import 了本文件），
// 所以把式子抄一遍，改一处要改两处。依据是范例的 docx：w:firstLineChars 折成
// w:firstLine 的比值*随本段字号变*，五号那几段每字 10.9500 / 10.9556
// （＝ 10.5 + 0.4543），继承小四的那些每字 12.4490～12.4563（＝ 12 + 0.4543）。
// 先前这里乘的是 docgrid.char-pitch，钉死在基准字号上，五号段落会多缩 3pt。
//
// *两个方向各出一个值，不折成带符号的一个数。* 折了就得在用的地方
// calc.max 拆回来，而带 em 的长度在 context 外比不了大小（eqdenote 那边踩过
// 一次，见 iota-hit/src/math/eqdenote.typ 的 to-absolute）。
#let _indent(style, docgrid) = {
  let pick(v) = {
    if type(v) == length { return v }
    if type(v) == dictionary and "chars" in v {
      let n = v.at("chars")
      return n * 1em + n * docgrid.tracking
    }
    panic("expected length or dictionary with \"chars\", found " + repr(v))
  }
  // *整段左缩进（w:ind left）单出一格。* Typst 的 par 没有这一档——它只有
  // first-line-indent 与 hanging-indent，整段推开要靠块的 inset。所以这里只算
  // 出长度，交给发块的那一层（src/styles/parts.typ 的 paragraph）落到 inset 上。
  //
  // 用得上它的是报告首页的字段表：硕博那六格写着 w:ind left="1260"（63pt），
  // 整段（含折行）都从那里起排。
  let left = style.at("left-indent", default: none)
  let left = if left == none { 0pt } else { pick(left) }
  let first-line = style.at("first-line-indent", default: none)
  if first-line != none { return (first-line: pick(first-line), hanging: 0pt, left: left) }
  let hanging = style.at("hanging-indent", default: none)
  if hanging != none { return (first-line: 0pt, hanging: pick(hanging), left: left) }
  (first-line: 0pt, hanging: 0pt, left: left)
}

// snap-to-docgrid 就是 Word 段落对话框上「对齐到网格」那一个勾，*只管纵向*。
//
// 横向（字距增量）不由段落定，由*版面*定：这一节的文档网格写了 char-pitch，
// 正文故事里每一段都吃增量，勾没勾都一样。官方本科理工范例 PDF 量的：节标题
// 15pt 步进 15.48 = 15 + 0.4543，而 heading 2 样式写着 snapToGrid=0；题注五号
// 步进 10.94（第 12 页「表6-1」，1/300 英寸取整）= 10.5 + 0.4543，那一段也是
// snapToGrid=0；英文摘要段 snapToGrid=0，Times 逐字比字身宽多 0.21（半格）。
// 页眉页脚不在这个故事里，不吃——范例页眉「章→绪」空一字正好 9.000，没有增量。
//
// 先前这一键收 (vertical:, horizontal:) 两轴，横轴逐段手写，题注那一档漏写就
// 没吃到增量。写了字典当场报错，指路到这里。
#let _snap-of(style) = {
  let v = style.at("snap-to-docgrid", default: false)
  if type(v) != bool {
    panic(
      "snap-to-docgrid: expected a boolean (Word's \"snap to grid\" checkbox, vertical "
        + "only), found " + repr(v) + "; the character grid comes from the layout "
        + "(char-pitch), so delete the \"horizontal\" key",
    )
  }
  v
}

// 字距增量：发给 text(tracking:) 的那一段，取网格的字距增量本身。
//
// *不是「一格减字号」。* 那个式子只在基准字号上成立——封面的中文题目
// 是 22pt，一格 12.4543，减出来是 −9.5。Word 的模型是每个全宽字后面加一段
// 定长（w:charSpace/4096），与字号无关，见 src/layout/resolve.typ 的规则八。
// 正文、各级标题、页眉三处 set text 都从这里取，标题另加自己的 tracking。
// 补偿那一头不从这里取——它读当前生效的 text.tracking，见 src/fonts/tracking.typ。
#let tracking(metrics, tracking: 0pt) = {
  (if metrics.snap-h { metrics.docgrid.tracking } else { 0pt }) + tracking
}

// 字符网格的行末余量，也就是 hithesis 发给 \rightskip 的那一段。
//
// *眼下没有接。* 横轴的目标是用 tracking 调到与 Word 大体一致，
// 这一段是追精确的：接上去行末从 510.2258 挪到 509.7713，正好落在 Word 的
// 模型上；不接则偏差从行首往行尾线性累积到 0.4543pt（0.16mm），
// 与横轴上其余几处已有的偏差同级。接法见 src/styles/body.typ 里注释掉的那两行。
// 两档来路完全不同：
//
//   贴网格   整数格除不尽的零头。一行放得下 n 个格，n 个字连着排占
//            n 个字号加 n−1 段字距胶，版心宽减掉它就是余量。范例版心宽
//            425.18、字距 12.4544，34 个字占 423.45，右边留 1.73 空着。
//   不贴网格 末字省掉的那一个字距增量。行末那个字不带增量，Word 把行拉到
//            425.18 − 0.4543 = 424.72。
//
// 不扣的话 TeX 与 Typst 都会把整行拉满版心，每个字缝多出来一点。
#let line-end-slack(metrics, text-width: 0pt, cells: 0) = {
  if not metrics.snap-h { return 0pt }
  let glue = metrics.docgrid.char-pitch - metrics.size
  if not metrics.snap { return glue }
  text-width - cells * metrics.size - (cells - 1) * glue
}

// 把一个元素的键值算成行盒。
//
// 网格行距为零说明没走过 page-setup，那时候不存在网格，
// snap-to-docgrid 勾了也没有可对齐的东西，一律按关掉算。
// char-grid：这一处在不在字符网格上。正文故事里的段落都在（默认）；页眉页脚
// 记录不在，src/layout/rules.typ 的 page-rules 传 false。
#let resolve(style, docgrid: zero-docgrid, char-grid: true) = {
  let size = style.at("size", default: zihao.xiaosi)
  let font-zh = style.at("font-zh", default: "songti")
  // *latin-line-height 是 "cjk" 时，纯西文行按中文行高算*——英文目录、英文页眉
  // 那些就不再随内容是中是英而挪位。这一档住 layout 里、随 docgrid 一起传（见
  // src/layout/resolve.typ 的 fold），每一处 resolve 都不必多传一个参数；auto 与
  // "latin" 都是照 Word 按西文算。"ascii"（空段）不在此列，见 src/fonts/presets.typ。
  let font-zh = if font-zh == "latin" and docgrid.at("latin-line-height", default: auto) == "cjk" {
    "songti"
  } else { font-zh }
  let coef = natural-coefs.at(font-zh, default: natural-default)

  // *网格没启用就不贴*——先前只看 line-pitch 是不是 0，可原件那一节的
  // docGrid 数照写着、只是没有 w:type（深圳本科那两份报告），照贴就把表格的
  // 行排成了 19.55，而 Word 排出来是 19.44
  let snap = _snap-of(style) and docgrid.grid and docgrid.line-pitch != 0pt
  // 横向由版面定，见 _snap-of。*引擎自己画字符网格时不贴*（docgrid.linebreaks 不是
  // none，见 src/layout/resolve.typ 的「断行引擎」）：字距增量的数照记，发不发全看这一位——
  // set text(tracking:) 的整份与半份、西文 run 那几条 show 规则装不装，都从这儿走
  let snap-h = char-grid and docgrid.tracking != 0pt and docgrid.at("linebreaks", default: none) == none

  // auto 只有目录那四条有，且到这儿之前该由 resolve-toc-line-spacing（sheet.typ） 按学位填好；
  // 漏填不能静默当单倍排
  let line-spacing = style.at("line-spacing", default: 1)
  if line-spacing == auto {
    panic("line-spacing: auto reached resolve unresolved; call resolve-toc-line-spacing first")
  }
  let (mode, gap: baseline-gap) = _baseline-gap-endpoint(
    line-spacing,
    coef, size, docgrid, snap,
  )
  let ascent = _ascent-of(
    mode, baseline-gap, coef, size, snap,
    ascent-coefs.at(font-zh, default: ascent-default),
  )
  // 行盒高：*倍数那一档取行距与自然行高的较大者*。这一步照 hithesis 那根
  // 撑杆（\hit@format@strut:）来，是为页眉设的：页眉那一行的行距写着 0（倍数 0，
  // 不是固定值），光看它撑出来的盒子没有深度，页眉横线会整块上移 2pt。
  //
  // *固定值那一档不取大，那个数就是盒高*——Word 的「固定值」小于字高时
  // *让字挤出去*，不把行撑开。深圳本科报告首页 2026 年 9 月版新加的勾选行
  // 就是这一档：小一 24pt 的字写着 w:line="380" exact ＝ 19pt，Word 排出来那一行
  // 就占 19（下一行的基线量出 99.12 → 179.83，中间只隔着一个空段）；取大的话
  // 盒子成了 31.13，整页往下坠 12。
  //
  // *裸长度那一档也不取大*——上面写的就是「就是这么长，不设下限」，先前代码却跟着倍数
  // 一起取了大。深圳本科报告首页压缩行距时靠它把行盒压到自然行高以下（基线仍在上升部
  // 处，缩掉的全是基线以下那一截），见 iota-hit/src/pages/report/shenzhen/cover.typ 的 ls-of
  let natural = coef * 1em
  let box = if mode in ("exactly", "length") { baseline-gap } else {
    _max(baseline-gap, natural, size)
  }
  // *裸长度比上升部还矮时基线落到盒底*：盒顶不能低于基线（bottom-edge 写成正值 Typst
  // 当 0，盒会被撑回上升部那么高，写下的长度就不作数），所以上升部收成盒高、深度为 0。
  // 深圳本科报告首页压缩英文行时要用到：Times 的上升部 0.891em，字的墨迹只到 0.66em，
  // 行盒压到上升部以下字还碰不到上一行的线
  let ascent = if mode == "length" and _absolute(box, size) < _absolute(ascent, size) { box } else { ascent }
  let depth = box - ascent

  (
    size: size,
    natural: coef * size,
    box: _absolute(box, size),
    // 折在这个元素自己字号上的量，换算与对拍看这几个
    baseline-gap: _absolute(baseline-gap, size),
    ascent: _absolute(ascent, size),
    depth: _absolute(depth, size),
    // 跟着 run 的字号走的量，top-edge / bottom-edge 用这两个
    top-edge: ascent,
    bottom-edge: depth,
    above: amount(style.at("above", default: none), docgrid),
    below: amount(style.at("below", default: none), docgrid),
    indent: _indent(style, docgrid),
    snap: snap,
    snap-h: snap-h,
    docgrid: docgrid,
  )
}

// 纯西文行的行盒。
//
// *要解决的事。* Word 里一行的行高取这一行*实际用到*的各个字体的
// 最大值，所以同一个设置下，有汉字的行按中易的 1.296875 算，纯英文的行只有
// Times 参与，按 1.15 算。范例的两份摘要就是这样：段落设置相同，中文那份
// 量出 19.4531，英文那份 17.2500。
//
// Typst 的行盒本来就是取全行各 run 的最大值——*与 Word 同一条规则*。
// 只是我们把 top-edge / bottom-edge 写成了显式的量（为的是不问加载的是哪个
// 字体、一律按中易的标定排），一写死就对所有 run 一视同仁，纯西文行也拿到了
// 汉字那一份，比 Word 高 2.2pt，合 11%。
//
// 所以给西文 run 单发一份行盒，让 Typst 的 max 自己去挑：
//   纯西文行   全是西文 run  → 17.2500
//   混排行     max(西文, 汉字) → 19.4531
//   汉字行     全是汉字 run  → 19.4531
//
// 取值不另写公式，就是同一个 style 把 font-zh 换成 none 再算一遍——
// 换算层认这件事，1.15 那一支有 hithesis 的回归值撑着。
//
// *为什么要求段里至少有一个拉丁字母。* Typst 有个原生的 script 分段行为：
// 拉丁*字母*自成一个 shaping run，而 run 的最后一个字形拿不到 tracking；
// 数字和符号算 Common，留在汉字那个 run 里，所以不丢。实测（单一字体、
// 无 covers、无 show 规则、连 cjk-latin-spacing 都关掉，tracking 设 2pt，
// 汉字步进该是 14.000）：
//
//   汉→汉 14.000   汉→A 12.000   汉→a 12.000   汉→1 14.000   汉→% 14.000
//
// 所以规则若写成「西文+」，「共12页」里的 1 会被划成独立的 run，那 0.4543
// 的字距就丢了，15.4543 掉到 15.0000。写成「至少含一个字母」就把光是数字的
// 那种放过去，字距保住；而真正要救的纯西文行必然带字母，一个不漏。
//
// 顺带也救了页眉：「第1章」里的 1 不再自成 run，正文那条规则漏进页眉也不
// 起作用了。漏是躲不掉的——set page 的页眉是在正文的样式里排的，而内外两条
// 规则同时命中时同一属性上外层赢（实测：内层设 size 外层设 fill，两个都生效；
// 都设 fill 则外层赢），从页眉内部盖不住。
//
// *上游若修了怎么办。* CJK-Latin 这一带是 typst 公认的粗糙区
// （issue 7475 / 6539 / 2702 / 2703 / 2538）。根因见 PR 7521：
// add_cjk_latin_spacing 不是插入一个间距项，而是去改汉字字形的 x_advance
// 与 offset；作者说正经重构 shaper 这一套「架构改动大、回归风险高」。
// 哪天 run 边界不再吞 tracking 了，「至少含一个字母」这条限制就可以松掉，
// 改成「西文+」，光是数字的行也能拿到西文行盒；判据是 iota-hit/tests/check-pitch.py
// 里那条汉字接数字的断言在松掉之后还过不过（现在是 15.4543）。
//
// *对齐到网格时这条规则不发。* Word 贴网格时行盒就是整数个格，与这一行
// 用了哪些字体无关——按字体分高矮只是不贴格那一档的事。技术上也非发不可：
// Typst 是把各 run 的 top-edge 取一次最大、bottom-edge 再取一次最大，两份
// 行盒贴格后居中量不同，凑出来比任何一份都高。实测研究生那一档（单倍贴格）
// 行距从 19.5500 涨到 20.4312，一页少排两行。
//
// *范围为什么写码位。* 见 msword.typ 的 latin-run。
// 西文断字。
//
// *光开 hyphenate 没用，必须连 lang 一起给。* Typst 按 text.lang 选断字
// 规则表，中文没有那张表——实测同一个 electroencephalographically，lang=en 断成
// electroen-cephalographically，lang=zh 整词甩到下一行，设不设 hyphenate 都一样。
//
// 挂在 latin-run 上：那条正则本来就在挑「至少含一个拉丁字母」的 run（行盒那一档
// 也用它），西文断字要的正是同一批 run。汉字不受影响——它本来就随处可断。
//
// *lang 只在这条规则的作用域里改。* 文档语言由 iota-hit/src/terms/lang.typ 的 doc-lang
// 这个 state 管，入口写一次，之后没人再读 text.lang，所以这里改它不影响标题取哪
// 一份、词条走哪一层。
//
// *开关是原生的 text.hyphenate，我们不另设一条。* Typst 自己就有这个属性，
// 三种粒度实测都通：全篇 #set text(hyphenate: true)、按元素
// #show figure.caption: set text(hyphenate: true)（子图题也命中，还能再
// .where(kind: image) 分开图题表题）、按页把 #set 裹在那次调用外面（穿得进去，
// 连那两页的页眉页脚一起）。比我们先前那个只有 body / caption 两档的字典细得多。
//
// *判据只认 true。* 原生默认是 auto——「两端对齐就断字」，而正文正是两端
// 对齐的，照 auto 走就成了默认断字，与范例相反（两份 .docx 的 settings.xml 里
// 都没有 w:autoHyphenation，Word 默认关）。所以 auto 与 false 一样当不断。

// 算行盒，网格三个参数从版面字典里取。部件一律走这个口；resolve 是它的裸版（收 docgrid）。
#let metrics(style, layout: no-docgrid) = resolve(style, docgrid: layout.docgrid)
