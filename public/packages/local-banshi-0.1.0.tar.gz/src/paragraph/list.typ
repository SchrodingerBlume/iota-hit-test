// 圆点列表（list）：默认照原生悬挂；list-hanging: false 排成段，与编号列表那一档同一个排法。
//
// *指南对圆点列表没有规定*，两份范例的 docx 里也没有圆点（一个 w:numPr 都没有），原生的
// 悬挂就是它该有的样子——所以这儿 auto ＝ 悬挂，与编号列表相反（那边 auto ＝ 不悬挂，
// 因为「（1）……」在范例里就是普通段落）。要它跟编号列表一样排成段——圆点顶在首行缩进处、
// 续行回左缘、嵌在条目里的块回到页边——写 list-hanging: false，或单次 #list-hanging(false)[…]。
//
// *三层开关与编号列表同一副*（src/paragraph/enum.typ 的 _switch）：文档级 list-hanging:
// auto | true | false；单次 #list-hanging[…]（＝ true）／#list-hanging(false)[…]／
// #list-hanging(auto)[…]（跟文档级，收着是为了三态齐全）。
//
// *排成段那一档，原生参数照它们本来的意思映射到段上*，与 enum-rules 同：
//   marker       圆点。原生按嵌套深度从数组里轮着取（出厂 •、‣、–），这儿也轮
//   indent       写了就*替换*首行缩进（圆点从那儿起，嵌套的自动缩进让位）；没写顶在
//                正文的首行缩进处，嵌套一层多两字
//   body-indent  圆点与正文之间的空当，照写的（出厂 0.5em）
//   spacing      条与条之间的距离，写了就发到条的上下
//   tight        只对原生那张 grid 有意义，不管
#import "../layout/chars.typ" as chars
#import "./enum.typ": _switch

#let _list = _switch("list-hanging", true)
#let list-hanging = _list.once

// 嵌套深度：进一条压一层、出来弹掉，圆点按它从数组里取
#let _depth = state("banshi-list-depth", 0)

#let _marker(marker, depth) = {
  if type(marker) == array {
    if marker.len() == 0 { [] } else { marker.at(calc.rem(depth, marker.len())) }
  } else if type(marker) == function { marker(depth) } else { marker }
}

#let list-rules(doc) = {
  show list: it => context {
    if (_list.now)() { return it }
    let depth = _depth.get()
    let dot = _marker(it.marker, depth)
    for item in it.children {
      // 嵌套多缩两字、块里先发一个 parbreak：理由见 enum-rules 里同一处
      let given = it.indent != 0pt
      _depth.update(d => d + 1)
      block(
        inset: (left: if not given and depth > 0 { chars.ccwd(2 * depth) } else { 0pt }),
        ..(if it.spacing != auto { (above: it.spacing, below: it.spacing) } else { (:) }),
        {
          set par(first-line-indent: (amount: it.indent, all: true)) if given
          parbreak()
          dot + h(it.body-indent) + item.body
        },
      )
      _depth.update(d => d - 1)
    }
  }
  doc
}
