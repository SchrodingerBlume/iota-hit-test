// 圆点列表（list）：默认照原生悬挂；list-hanging: false 排成段，与编号列表那一档同一个排法。
#import "../layout/chars.typ" as chars
#import "./enum.typ": _switch

#let _list = _switch("list-hanging", true)
#let list-hanging = _list.once

#let _depth = state("banshi-list-depth", 0)

#let _marker(marker, depth) = {
  if type(marker) == array {
    if marker.len() == 0 { [] } else { marker.at(calc.rem(depth, marker.len())) }
  } else if type(marker) == function { marker(depth) } else { marker }
}

#let list-rules(doc) = {
  show list: it => context {
    if (_list.now)() { return it }
    let depth = _depth.get()
    let dot = _marker(it.marker, depth)
    for item in it.children {
      let given = it.indent != 0pt
      _depth.update(d => d + 1)
      block(
        inset: (left: if not given and depth > 0 { chars.chars(2 * depth) } else { 0pt }),
        ..(if it.spacing != auto { (above: it.spacing, below: it.spacing) } else { (:) }),
        {
          set par(first-line-indent: (amount: it.indent, all: true)) if given
          parbreak()
          dot + h(it.body-indent) + item.body
        },
      )
      _depth.update(d => d - 1)
    }
  }
  doc
}
