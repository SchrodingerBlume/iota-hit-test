// Word「段落」对话框「缩进和间距」那张卡的折算：一条样式（字号、行距、贴不贴网格……）在（indent）、字距（tracking-of）。

#import "../fonts/presets.typ": en-roles, zihao, ascent-const, exact-first-ratio
#import "../fonts/resolve.typ": fontset-state, font as _font
#import "../layout/state.typ": page-setup-state
#import "../units.typ": twips
#import "../runs/regex.typ": latin-run

/// 没有文档网格时的网格记录：跨度与字距增量均为 0。
/// -> dictionary
#let zero-docgrid = (
  line-pitch: 0pt, char-pitch: 0pt, tracking: 0pt,
  grid: false, line-unit: 0pt,
)

/// 没有文档网格的最简页面设置，供独立部件与测试使用。
/// -> dictionary
#let no-docgrid = (
  docgrid: zero-docgrid,
  font-size: 12pt,
  cells: 0,
  text-width: 0pt,
)

#let _absolute(len, size) = len.abs + len.em * size
#let _max(a, b, size) = if _absolute(a, size) >= _absolute(b, size) { a } else { b }

#let _multiple-baseline-gap(k, coef, size, docgrid, snap) = {
  if not snap { return k * coef * 1em }
  let len = k * docgrid.line-pitch
  let floor = calc.ceil(coef * size / docgrid.line-pitch) * docgrid.line-pitch
  calc.max(len, floor)
}

// 行距接受 Word 的“单倍”“双倍”“多倍”“固定值”“最小值”。
#let _baseline-gap-endpoint(value, coef, size, docgrid, snap) = {
  if value == "single" {
    return (mode: "multiple", gap: _multiple-baseline-gap(1.0, coef, size, docgrid, snap))
  }
  if value == "double" {
    return (mode: "multiple", gap: _multiple-baseline-gap(2.0, coef, size, docgrid, snap))
  }
  if type(value) in (int, float) {
    return (mode: "multiple", gap: _multiple-baseline-gap(float(value), coef, size, docgrid, snap))
  }
  if type(value) == length {
    return (mode: "length", gap: value)
  }
  if type(value) == dictionary {
    if "exactly" in value {
      return (mode: "exactly", gap: value.at("exactly"))
    }
    if "at-least" in value {
      let given = value.at("at-least")
      let floor = if snap { docgrid.line-pitch } else { coef * 1em }
      if given >= _absolute(floor, size) {
        return (mode: "at-least", gap: given)
      }
      return (mode: "at-least", gap: floor)
    }
  }
  panic("expected number, length, or dictionary with \"exactly\" or \"at-least\", found " + repr(value))
}

// 固定值是另一套，基线在盒顶下方 0.8 倍盒高，与网格开关无关。
#let _ascent-of(mode, baseline-gap, coef, size, snap, asc-coef) = {
  if mode == "exactly" { return exact-first-ratio * baseline-gap }
  let ascent = asc-coef * 1em + ascent-const
  if not snap { return ascent }
  let center = (_absolute(baseline-gap, size) - coef * size) / 2
  ascent + center
}

// 折成长度以后往下截到整缇，Word 存盘时就是这么干的。
/// 将段前、段后或图表空当折成长度。绝对长度原样返回；`(lines: n)` 乘当前网格行
/// 跨度，再按 Word 的方式向下截到整缇。没有文档网格时不要使用 `(lines:)`。
/// -> length
#let amount(value, docgrid) = {
  if value == none { return 0pt }
  if type(value) == length { return value }
  if type(value) == dictionary and "lines" in value {
    return twips(value.at("lines") * docgrid.line-unit, floor: true)
  }
  panic("expected length or dictionary with \"lines\", found " + repr(value))
}

#let _docgrid-of(layout) = if layout == none { zero-docgrid } else if layout == auto {
  let s = page-setup-state.get()
  if s == none { panic("no page setup in effect: pass layout: or docgrid:, or write the document-level show first") }
  s.docgrid
} else { layout.docgrid }

/// 将样式中的首行缩进、悬挂缩进和左缩进解析为长度。`(chars: n)` 按该样式字号加
/// 字符网格增量计算，不按文档基准字号计算。`layout: auto` 读取当前节；`none` 表示无网格。
/// -> dictionary
#let indent(style, layout: auto, docgrid: none) = {
  let docgrid = if docgrid != none { docgrid } else { _docgrid-of(layout) }
  let pick(v) = {
    if type(v) == length { return v }
    if type(v) == dictionary and "chars" in v {
      let n = v.at("chars")
      return n * 1em + n * docgrid.tracking
    }
    panic("expected length or dictionary with \"chars\", found " + repr(v))
  }
  let left = style.at("left-indent", default: none)
  let left = if left == none { 0pt } else { pick(left) }
  let first-line = style.at("first-line-indent", default: none)
  if first-line != none { return (first-line: pick(first-line), hanging: 0pt, left: left) }
  let hanging = style.at("hanging-indent", default: none)
  if hanging != none { return (first-line: 0pt, hanging: pick(hanging), left: left) }
  (first-line: 0pt, hanging: 0pt, left: left)
}

// snap-to-grid 就是 Word 段落对话框上「如果定义了文档网格，则对齐到网格」那一个勾，只管纵向。
#let _snap-of(style) = {
  let v = style.at("snap-to-grid", default: false)
  if type(v) != bool {
    panic(
      "snap-to-grid: expected a boolean (Word's \"snap to grid\" checkbox, vertical "
        + "only), found " + repr(v) + "; the character grid comes from the layout "
        + "(char-pitch), so delete the \"horizontal\" key",
    )
  }
  v
}

/// 计算发给 `text(tracking:)` 的字距：横向贴网格时加上字符网格增量，再加样式自身的字符间距。
/// -> length
#let tracking-of(metrics, tracking: 0pt) = {
  (if metrics.snap-h { metrics.docgrid.tracking } else { 0pt }) + tracking
}

// Word 字体对话框的两格：中文字体（Asian text font）与西文字体（Latin text font）。一段字两副同时生效，
// 汉字走前者、西文走后者；行高按行里实际的字——有汉字按中文字体的度量，全是西文按西文字体的。
/// 样式的中文字体角色，未写为 `"songti"`。
/// -> str
#let asian-font-of(style) = style.at("asian-font", default: "songti")
/// 样式的西文字体角色，未写为 `"serif"`。
/// -> str
#let latin-font-of(style) = style.at("latin-font", default: "serif")
// 中文角色兼作这一档的「角色」：OpenType 标签、伪粗、繁简都按它问。
#let role-of(style) = asian-font-of(style)

/// 一条样式落到 `text(font:)` 的字体列表：汉字走中文字体、西文走西文字体；`latin: true`
/// 时这一段全是西文，只给西文字体那一串。
/// -> array
#let families-of(style, fontset, latin: false) = if latin {
  _font(latin-font-of(style), fontset.families, asian: asian-font-of(style))
} else {
  _font(asian-font-of(style), fontset.families, latin: latin-font-of(style), em-dash: fontset.at("em-dash", default: "cjk"))
}

/// 将一条 Word 段落样式解析为 Typst 行盒度量。结果包含字号、单倍行高、基线间距、
/// `top-edge`、`bottom-edge`、段前段后、是否贴纵向网格以及横向网格增量。
///
/// `style` 至少应含 `size`；`line-spacing` 可写倍数、`"single"`、`"double"`、
/// `(exactly: 18pt)` 或 `(at-least: 18pt)`。`layout` / `metrics` 为 `auto` 时读取当前
/// 文档状态。行高按中文字体的度量；`latin: true` 表示这一行全是西文，按西文字体的（Word
/// 的行高取行里实际的字）。模板通常不直接调用它，而是把样式交给 `styles.paragraph` 或文档规则。
/// -> dictionary
#let spacing(style, layout: auto, docgrid: none, metrics: auto, char-grid: true, latin: false) = {
  let docgrid = if docgrid != none { docgrid } else { _docgrid-of(layout) }
  let metrics = if metrics == auto { fontset-state.get().metrics } else { metrics }
  let size = style.at("size", default: zihao.xiaosi)
  let measured = if latin { "latin" } else { asian-font-of(style) }
  let coef = metrics.at(measured).single

  let snap = _snap-of(style) and docgrid.grid and docgrid.line-pitch != 0pt
  let snap-h = char-grid and docgrid.tracking != 0pt and docgrid.at("linebreaks", default: none) == none

  let line-spacing = style.at("line-spacing", default: 1)
  if line-spacing == auto {
    panic("line-spacing: auto reached resolve unresolved; call resolve-toc-line-spacing first")
  }
  let (mode, gap: baseline-gap) = _baseline-gap-endpoint(
    line-spacing,
    coef, size, docgrid, snap,
  )
  let ascent = _ascent-of(
    mode, baseline-gap, coef, size, snap,
    metrics.at(measured).ascent,
  )
  // “固定值”与裸长度就是行盒高度，不与字体自然行高取最大值。Word 探针中，
  // 小一 24pt 的 run 写 `w:line="380" w:lineRule="exact"`，仍只占 19pt；
  // 后续基线由 99.12pt 到 179.83pt，符合中间空段按 19pt 计算。若取自然行高，
  // 该页会额外下移约 12pt。只有倍数行距需要与单倍行高取较大者。
  let natural = coef * 1em
  let box = if mode in ("exactly", "length") { baseline-gap } else {
    _max(baseline-gap, natural, size)
  }
  let ascent = if mode == "length" and _absolute(box, size) < _absolute(ascent, size) { box } else { ascent }
  let depth = box - ascent

  (
    size: size,
    single: coef * size,
    line-height: _absolute(box, size),
    baseline-gap: _absolute(baseline-gap, size),
    ascent: _absolute(ascent, size),
    depth: _absolute(depth, size),
    top-edge: ascent,
    bottom-edge: depth,
    above: amount(style.at("above", default: none), docgrid),
    below: amount(style.at("below", default: none), docgrid),
    snap: snap,
    snap-h: snap-h,
    docgrid: docgrid,
  )
}

// Word 行高取该行实际字体度量的最大值，因此纯西文行与含汉字行可能采用不同单倍行高。
// 两份摘要的段落设置相同，Word PDF 中纯西文行为 17.2500pt，含汉字行为
// 19.4531pt；这两个观测值分别对应 Times 1.15 与中易 1.296875 的单倍行高。


// Word 按字符所占网格单元分配间距：全宽字符一份，半宽西文字符半份。
#let latin-tracking(style, computed) = (
  (if computed.snap-h { computed.docgrid.tracking / 2 } else { 0pt })
    + style.at("tracking", default: 0pt) / 2
)

// 这一档 set 给正文的字距：全是西文的段是半份，别的是整份。
#let set-tracking(style, computed, latin: false) = if latin {
  latin-tracking(style, computed)
} else {
  tracking-of(computed, tracking: style.at("tracking", default: 0pt))
}
