// Word「段落」对话框「缩进和间距」那张卡的折算：一条样式（字号、行距、贴不贴网格……）在（indent）、字距（tracking-of）。

#import "../fonts/presets.typ": en-roles, zihao, ascent-const, exact-first-ratio, ink-height
#import "../fonts/resolve.typ": fontset-state
#import "../layout/state.typ": page-setup-state
#import "../units.typ": twips
#import "../runs.typ": latin-run

// 1.008 × 字号 + 0.082pt，那个常数项不随字号缩放；整个量先在正文字号上折成直接用 Typst 的 length，不自己造记录。
#let zero-docgrid = (
  line-pitch: 0pt, char-pitch: 0pt, tracking: 0pt,
  grid: false, line-unit: 0pt,
)

// 没有网格的场合（独立小部件、enter 之类）用它，省得各处拼一个假 layout。
#let no-docgrid = (
  docgrid: zero-docgrid,
  base-size: 12pt,
  cells: 0,
  text-width: 0pt,
)

#let _absolute(len, size) = len.abs + len.em * size
#let _max(a, b, size) = if _absolute(a, size) >= _absolute(b, size) { a } else { b }

#let _multiple-baseline-gap(k, coef, size, docgrid, snap) = {
  if not snap { return k * coef * 1em }
  let len = k * docgrid.line-pitch
  let floor = calc.ceil(coef * size / docgrid.line-pitch) * docgrid.line-pitch
  calc.max(len, floor)
}

// 行距接受 Word 的“单倍”“双倍”“多倍”“固定值”“最小值”；`white` 是视觉留白扩展。
#let _baseline-gap-endpoint(value, coef, size, docgrid, snap) = {
  if value == "single" {
    return (mode: "multiple", gap: _multiple-baseline-gap(1.0, coef, size, docgrid, snap))
  }
  if value == "double" {
    return (mode: "multiple", gap: _multiple-baseline-gap(2.0, coef, size, docgrid, snap))
  }
  if type(value) in (int, float) {
    return (mode: "multiple", gap: _multiple-baseline-gap(float(value), coef, size, docgrid, snap))
  }
  if type(value) == length {
    return (mode: "length", gap: value)
  }
  if type(value) == dictionary {
    if "exactly" in value {
      return (mode: "exactly", gap: value.at("exactly"))
    }
    if "at-least" in value {
      let given = value.at("at-least")
      let floor = if snap { docgrid.line-pitch } else { coef * 1em }
      if given >= _absolute(floor, size) {
        return (mode: "at-least", gap: given)
      }
      return (mode: "at-least", gap: floor)
    }
    if "white" in value {
      return (mode: "white", gap: ink-height * 1em + value.at("white"))
    }
  }
  panic("expected number, length, or dictionary with \"at-least\" or \"white\", " + "found " + repr(value))
}

// 固定值是另一套，基线在盒顶下方 0.8 倍盒高，与网格开关无关。
#let _ascent-of(mode, baseline-gap, coef, size, snap, asc-coef) = {
  if mode == "exactly" { return exact-first-ratio * baseline-gap }
  let ascent = asc-coef * 1em + ascent-const
  if not snap { return ascent }
  let center = (_absolute(baseline-gap, size) - coef * size) / 2
  ascent + center
}

// 对不对齐网格无关。折成长度以后要往下截到整缇，Word 存盘时就是这么干的。
#let amount(value, docgrid) = {
  if value == none { return 0pt }
  if type(value) == length { return value }
  if type(value) == dictionary and "lines" in value {
    return twips(value.at("lines") * docgrid.line-unit, floor: true)
  }
  panic("expected length or dictionary with \"lines\", found " + repr(value))
}

/// 将 Word 的首行、悬挂和左缩进解析为 Typst 段落缩进。
/// -> dictionary
#let _docgrid-of(layout) = if layout == none { zero-docgrid } else if layout == auto {
  let s = page-setup-state.get()
  if s == none { panic("no page setup in effect: pass layout: or docgrid:, or write the document-level show first") }
  s.docgrid
} else { layout.docgrid }

#let indent(style, layout: auto, docgrid: none) = {
  let docgrid = if docgrid != none { docgrid } else { _docgrid-of(layout) }
  let pick(v) = {
    if type(v) == length { return v }
    if type(v) == dictionary and "chars" in v {
      let n = v.at("chars")
      return n * 1em + n * docgrid.tracking
    }
    panic("expected length or dictionary with \"chars\", found " + repr(v))
  }
  let left = style.at("left-indent", default: none)
  let left = if left == none { 0pt } else { pick(left) }
  let first-line = style.at("first-line-indent", default: none)
  if first-line != none { return (first-line: pick(first-line), hanging: 0pt, left: left) }
  let hanging = style.at("hanging-indent", default: none)
  if hanging != none { return (first-line: 0pt, hanging: pick(hanging), left: left) }
  (first-line: 0pt, hanging: 0pt, left: left)
}

// snap-to-docgrid 就是 Word 段落对话框上「对齐到网格」那一个勾，只管纵向。
#let _snap-of(style) = {
  let v = style.at("snap-to-docgrid", default: false)
  if type(v) != bool {
    panic(
      "snap-to-docgrid: expected a boolean (Word's \"snap to grid\" checkbox, vertical "
        + "only), found " + repr(v) + "; the character grid comes from the layout "
        + "(char-pitch), so delete the \"horizontal\" key",
    )
  }
  v
}

// 字符网格的间距增量映射到 `text.tracking`。
#let tracking-of(metrics, tracking: 0pt) = {
  (if metrics.snap-h { metrics.docgrid.tracking } else { 0pt }) + tracking
}

// 计算字符网格的行末余量；当前未接入排版规则。接入后，满行末字右缘会从
// 510.2258pt 移到 Word 模型的 509.7713pt；当前最大累计误差为一个字符网格
// 增量 0.4543pt。保留此函数和数据，等横轴模型需要追到这一档精度时再启用。
#let line-end-slack(metrics, text-width: 0pt, cells: 0) = {
  if not metrics.snap-h { return 0pt }
  let glue = metrics.docgrid.char-pitch - metrics.size
  if not metrics.snap { return glue }
  text-width - cells * metrics.size - (cells - 1) * glue
}

// `font-zh` 选择行高度量，`font` 选择字体角色；纯西文行可使用 `font-zh: "latin"`。
#let font-zh-of(style) = style.at("font-zh", default: {
  let font = style.at("font", default: "songti")
  if font in en-roles { "latin" } else { font }
})
#let role-of(style) = style.at("font", default: {
  let zh = style.at("font-zh", default: "songti")
  if zh == "latin" { "serif" } else { zh }
})

/// 将字号、行距、段前段后与文档网格解析为 Typst 的行盒度量。
/// `layout` 或 `metrics` 为 `auto` 时读取当前文档状态。
/// -> dictionary
#let spacing(style, layout: auto, docgrid: none, metrics: auto, char-grid: true) = {
  let docgrid = if docgrid != none { docgrid } else { _docgrid-of(layout) }
  let metrics = if metrics == auto { fontset-state.get().metrics } else { metrics }
  let size = style.at("size", default: zihao.xiaosi)
  let font-zh = font-zh-of(style)
  let font-zh = if font-zh == "latin" and docgrid.at("latin-line-height", default: auto) == "cjk" {
    "songti"
  } else { font-zh }
  let coef = metrics.at(font-zh).single

  let snap = _snap-of(style) and docgrid.grid and docgrid.line-pitch != 0pt
  let snap-h = char-grid and docgrid.tracking != 0pt and docgrid.at("linebreaks", default: none) == none

  let line-spacing = style.at("line-spacing", default: 1)
  if line-spacing == auto {
    panic("line-spacing: auto reached resolve unresolved; call resolve-toc-line-spacing first")
  }
  let (mode, gap: baseline-gap) = _baseline-gap-endpoint(
    line-spacing,
    coef, size, docgrid, snap,
  )
  let ascent = _ascent-of(
    mode, baseline-gap, coef, size, snap,
    metrics.at(font-zh).ascent,
  )
  // “固定值”与裸长度就是行盒高度，不与字体自然行高取最大值。Word 探针中，
  // 小一 24pt 的 run 写 `w:line="380" w:lineRule="exact"`，仍只占 19pt；
  // 后续基线由 99.12pt 到 179.83pt，符合中间空段按 19pt 计算。若取自然行高，
  // 该页会额外下移约 12pt。只有倍数行距需要与单倍行高取较大者。
  let natural = coef * 1em
  let box = if mode in ("exactly", "length") { baseline-gap } else {
    _max(baseline-gap, natural, size)
  }
  let ascent = if mode == "length" and _absolute(box, size) < _absolute(ascent, size) { box } else { ascent }
  let depth = box - ascent

  (
    size: size,
    single: coef * size,
    line-height: _absolute(box, size),
    baseline-gap: _absolute(baseline-gap, size),
    ascent: _absolute(ascent, size),
    depth: _absolute(depth, size),
    top-edge: ascent,
    bottom-edge: depth,
    above: amount(style.at("above", default: none), docgrid),
    below: amount(style.at("below", default: none), docgrid),
    snap: snap,
    snap-h: snap-h,
    docgrid: docgrid,
  )
}

// Word 行高取该行实际字体度量的最大值，因此纯西文行与含汉字行可能采用不同单倍行高。
// 两份摘要的段落设置相同，Word PDF 中纯西文行为 17.2500pt，含汉字行为
// 19.4531pt；这两个观测值分别对应 Times 1.15 与中易 1.296875 的单倍行高。


// 纯西文段直接使用半份字符网格间距，不安装中西文边界补偿。
#let pure-latin(style) = font-zh-of(style) == "latin"

// Word 按字符所占网格单元分配间距：全宽字符一份，半宽西文字符半份。
#let latin-tracking(style, computed) = (
  (if computed.snap-h { computed.docgrid.tracking / 2 } else { 0pt })
    + style.at("tracking", default: 0pt) / 2
)

// 这一档 set 给正文的字距：纯西文段是半份，别的是整份。
#let set-tracking(style, computed) = if pure-latin(style) {
  latin-tracking(style, computed)
} else {
  tracking-of(computed, tracking: style.at("tracking", default: 0pt))
}
