// 符号表按两列 description list 排版，续行与说明列对齐。

// thuthesis / bithesis 的 labelwidth（auto 的下限）与 labelsep。
#let _label-width = 2.5cm
#let _label-sep = 0.5cm
// auto 的上限：首列不超过版心的这个比例。
#let _label-ratio = 1 / 3

// markup 里拿到的是一串 terms.item，不是一个 terms。
#let items(c) = {
  if c.func() == terms.item { (c,) }
  else if c.func() == terms { c.children.map(items).flatten() }
  else if c.has("children") { c.children.map(items).flatten() }
  else { () }
}

#let check-hanging-indent(name, value) = {
  if value != auto and type(value) != length {
    panic(name + ": hanging-indent: expected length or auto, found " + repr(value))
  }
  if value != auto and value <= _label-sep {
    panic(
      name + ": hanging-indent: must be larger than the gap between label and description ("
        + repr(_label-sep) + ")",
    )
  }
}

// 列头：页函数收的是开关，三态布尔；auto ＝ 跟模板（眼下＝不印，hithesis 与thu 都不印列头）、true ＝ 印、false ＝ 不印。
#let check-header(name, value) = {
  if value not in (auto, true, false) {
    panic(
      name + ": header: expected auto, true, or false (the column headings are terms; "
        + "change the words with overrides, as in list-of-symbols-column-symbol: [...]), found "
        + repr(value),
    )
  }
}

#let resolve-header(value, pair) = if value == true { pair } else { none }

// hanging-indent 的 auto 档解出来的值：最宽的、没超过版心 1/3 的标签，下限 2.5cm，再加 0.5cm 间距。
#let auto-hanging-indent(labels, size) = {
  let cap = size.width * _label-ratio
  calc.max(_label-width, ..labels.map(l => measure(l).width).filter(w => w <= cap)) + _label-sep
}

/// 排版术语表或符号表。`rows` 是 `(标签, 说明)` 数组；`header` 可给出两个列标题。
/// -> content
#let term-list(rows, hanging-indent: auto, header: none) = {
  if header != none and (type(header) != array or header.len() != 2) {
    panic("term-list: header: expected none or an array of exactly two items, found " + repr(header))
  }
  let labels = rows.map(((label, _)) => label) + (
    if header == none { () } else { (header.first(),) }
  )
  std.layout(size => {
    let width = (
      if hanging-indent != auto { hanging-indent } else { auto-hanging-indent(labels, size) }
    ) - _label-sep
    let row = ((label, description)) => {
      let overflow = measure(label).width - width
      (box(label), if overflow > 0pt { h(overflow) + description } else { description })
    }
    grid(
      columns: (width, 1fr), column-gutter: _label-sep, row-gutter: 0pt,
      align: left + top,
      ..(if header == none { () } else { row(header) }),
      ..rows.map(row).flatten(),
    )
  })
}
