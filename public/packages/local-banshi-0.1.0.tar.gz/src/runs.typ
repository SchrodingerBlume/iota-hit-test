// 这里的 run 指 OOXML 的 `w:r` 与 Typst 的文本整形片段。按码位判文种，不看 text.lang；
// 切 run 的正则与字体角色的标签在 ./runs/regex.typ。
#import "./runs/regex.typ": latin-slot-run

/// 判断字符串是否含汉字（Unicode 脚本 `Han`）。
/// -> bool
#let has-han(value) = value.contains(regex("\\p{Han}"))

// 中日文字：汉字（含扩展 A、兼容表意）、假名、CJ 标点、全角形式。词间不用空格的那些脚本。
#let _cj(n) = (
  (0x3000 <= n and n <= 0x30FF)
    or (0x31F0 <= n and n <= 0x31FF)
    or (0x3400 <= n and n <= 0x4DBF)
    or (0x4E00 <= n and n <= 0x9FFF)
    or (0xF900 <= n and n <= 0xFAFF)
    or (0xFF00 <= n and n <= 0xFFEF)
    or (0x20000 <= n and n <= 0x2FA1F)
)
// 谚文：Word 的东亚字体槽也管它，但它靠空格断词
#let _hangul(n) = (
  (0x1100 <= n and n <= 0x11FF) or (0x3130 <= n and n <= 0x318F) or (0xAC00 <= n and n <= 0xD7AF)
)

/// 判断字符串是否含中日文字（汉字、假名、CJ 标点、全角形式）——这些脚本词间不留空格，
/// 拼接时两侧都是它就不加空格。
/// -> bool
#let has-cj(s) = s.clusters().any(ch => _cj(str.to-unicode(ch)))

/// 判断字符串是否含 Word 按东亚字体排的字（中日文字加谚文）——含有即按中文行高排。
/// -> bool
#let has-cjk(s) = s.clusters().any(ch => {
  let n = str.to-unicode(ch)
  _cj(n) or _hangul(n)
})

/// 判断字符串里有没有 Word 用中文字体排的字：汉字、中文标点、全角形式，加上 ×、箭头与几何
/// 符号（U+00D7、U+2190–21FF、U+25A0–25FF，与 fonts/resolve.typ 的 cjk-first 同一张表）。
/// 一行里有这样的字，行高就按中文字体算。
/// -> bool
#let has-asian(s) = has-cjk(s) or s.clusters().any(ch => {
  let n = str.to-unicode(ch)
  n == 0xD7 or (0x2190 <= n and n <= 0x21FF) or (0x25A0 <= n and n <= 0x25FF)
})

// 纯西文段判定，供西文行高规则使用。
/// 判断一段字面文本是否为纯西文段：有 ASCII 可见字符且不含汉字。省略号等歧义码位的归属见实现。
/// -> bool
#let latin-only(s) = (
  s.match(regex("[!-~]")) != none
    and not has-cjk(s)
    and (
      s.match(regex("\p{Latin}")) != none
        or s.match(regex("[\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}]")) == none
    )
)


// 语言判定只统计汉字和拉丁字母；空白、数字与标点不进入分母。
/// 字符串中汉字在“汉字 ＋ 拉丁字母”里的占比，用于判定一段文字的语言。
/// -> float
#let cjk-ratio(s) = {
  let cs = s.clusters()
  let cjk = cs.filter(has-cjk).len()
  let latin = cs.filter(ch => {
    let n = str.to-unicode(ch)
    (0x41 <= n and n <= 0x5A) or (0x61 <= n and n <= 0x7A)
  }).len()
  if cjk + latin == 0 { 0.0 } else { cjk / (cjk + latin) }
}

/// 判断字符串是否含由字体表西文槽处理的字符（西文字母、数字、半角标点）。
/// -> bool
#let has-latin-slot(s) = s.match(latin-slot-run) != none
