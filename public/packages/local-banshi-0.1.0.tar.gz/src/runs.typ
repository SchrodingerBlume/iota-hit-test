// 这里的 run 指 OOXML 的 `w:r` 与 Typst 的文本整形片段。
#let has-han(value) = value.contains(regex("\\p{Han}"))

#let has-cjk(s) = s.clusters().any(ch => {
  let n = str.to-unicode(ch)
  (
    (0x4E00 <= n and n <= 0x9FFF)
      or (0x3000 <= n and n <= 0x303F)
      or (0xFF00 <= n and n <= 0xFFEF)
  )
})

// 纯西文段判定，供西文行高规则使用。
#let latin-only(s) = (
  s.match(regex("[!-~]")) != none
    and not has-cjk(s)
    and (
      s.match(regex("\p{Latin}")) != none
        or s.match(regex("[\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}]")) == none
    )
)


// 语言判定只统计汉字和拉丁字母；空白、数字与标点不进入分母。
#let cjk-ratio(s) = {
  let cs = s.clusters()
  let cjk = cs.filter(has-cjk).len()
  let latin = cs.filter(ch => {
    let n = str.to-unicode(ch)
    (0x41 <= n and n <= 0x5A) or (0x61 <= n and n <= 0x7A)
  }).len()
  if cjk + latin == 0 { 0.0 } else { cjk / (cjk + latin) }
}

// 一段连续的西文。必须至少包含一个拉丁字母，不能把纯数字也收进来：Typst 原生
// 整形会让拉丁字母单独成 run，而数字属于 Common，通常留在汉字段。若数字也由本
// 规则切出，「共12页」中的“共→1”步进会从 15.4543pt 降到 15.0000pt，丢失
// 一个字符网格增量。相关上游问题为 typst/typst#7475、#6539、#2702、#2703、
// #2538，根因讨论见 PR #7521。将来只有在放宽正则后 tests/check-pitch.py 的
// 汉字接数字断言仍通过，才能删除“至少一个拉丁字母”的限制。
#let latin-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "\p{Latin}"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 将西文片段前的非西文字符一并匹配，以补偿整形片段边界丢失的字距。
#let latin-run-lead = "[^\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}\s\u{200B}\u{2060}\p{Co}]"
// 「run 以前导字起头」；rules.typ 里每个西文 run 都要 match 一次。
#let latin-run-lead-at-start = regex("^" + latin-run-lead)
#let latin-run-led = regex(
  "(?:" + latin-run-lead + ")?"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "\p{Latin}"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 匹配字体表中由西文字体槽处理的连续字符，供局部字重规则使用。
#let latin-slot-run = regex(
  "[^\p{Han}\p{Hiragana}\p{Katakana}\p{Hangul}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}"
  + "\u{00D7}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}"
  + "\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}"
  + "\n\p{Co}\u{200B}\u{2060}]+"
)

// 同一个字符集，但纯数字也算。给伪粗描边用（见 src/fonts/fake.typ）：那一族有真粗体面；描了就是双重加粗。
#let latin-ink-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "[0-9\p{Latin}]"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 匹配含汉字的整形片段，供字体基线校正规则使用。
#let role-tags = (
  songti: "izst", heiti: "izht", kaishu: "izks", kaishu-gb2312: "izkg",
  fangsong: "izfs", lishu: "izls",
)
// 每次把六个标签全写一遍：本角色 1，其余 0。
#let role-features(role) = {
  if role not in role-tags { return (:) }
  let out = (:)
  for (r, t) in role-tags { out.insert(t, if r == role { 1 } else { 0 }) }
  out
}

// 用 OpenType feature 标签标记是否参与正文的纯西文段规则。
#let latin-par-tag = "izlp"
#let latin-par-features(on) = ((latin-par-tag): if on { 1 } else { 0 })

// 两翼必须贪婪。 写成惰性（? 与 ??）会让每个汉字各自成一段；一段正文几百处匹配，Typst 当场 maximum grouping depth exceeded（与超长单词那一处同一个上限）。
#let cjk-run = regex(
  "(?:[^\p{Latin}\p{Co}\u{2060}\s][^\p{Latin}\p{Co}\u{2060}]*)?"
  + "[\p{Han}\p{Hiragana}\p{Katakana}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}]"
  + "(?:[^\p{Latin}\p{Co}\u{2060}]*[^\p{Latin}\p{Co}\u{2060}\s])?"
)
