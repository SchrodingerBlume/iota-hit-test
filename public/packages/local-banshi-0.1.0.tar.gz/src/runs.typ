// 这里的 run 指 OOXML 的 `w:r` 与 Typst 的文本整形片段。按码位判文种，不看 text.lang；
// 切 run 的正则与字体角色的标签在 ./runs/regex.typ。
#import "./runs/regex.typ": latin-slot-run

/// 判断字符串是否含汉字（Unicode 脚本 `Han`）。
/// -> bool
#let has-han(value) = value.contains(regex("\\p{Han}"))

/// 判断字符串是否含中日韩表意文字、中文标点或全角形式——含有即按中文行高排。
/// -> bool
#let has-cjk(s) = s.clusters().any(ch => {
  let n = str.to-unicode(ch)
  (
    (0x4E00 <= n and n <= 0x9FFF)
      or (0x3000 <= n and n <= 0x303F)
      or (0xFF00 <= n and n <= 0xFFEF)
  )
})

// 纯西文段判定，供西文行高规则使用。
/// 判断一段字面文本是否为纯西文段：有 ASCII 可见字符且不含汉字。省略号等歧义码位的归属见实现。
/// -> bool
#let latin-only(s) = (
  s.match(regex("[!-~]")) != none
    and not has-cjk(s)
    and (
      s.match(regex("\p{Latin}")) != none
        or s.match(regex("[\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}]")) == none
    )
)


// 语言判定只统计汉字和拉丁字母；空白、数字与标点不进入分母。
/// 字符串中汉字在“汉字 ＋ 拉丁字母”里的占比，用于判定一段文字的语言。
/// -> float
#let cjk-ratio(s) = {
  let cs = s.clusters()
  let cjk = cs.filter(has-cjk).len()
  let latin = cs.filter(ch => {
    let n = str.to-unicode(ch)
    (0x41 <= n and n <= 0x5A) or (0x61 <= n and n <= 0x7A)
  }).len()
  if cjk + latin == 0 { 0.0 } else { cjk / (cjk + latin) }
}

/// 判断字符串是否含由字体表西文槽处理的字符（西文字母、数字、半角标点）。
/// -> bool
#let has-latin-slot(s) = s.match(latin-slot-run) != none
