// 切 run 的正则与字体角色的标签：包内的 show 规则用，不导出。

// 一段连续的西文。必须至少包含一个拉丁字母，不能把纯数字也收进来：Typst 原生
// 整形会让拉丁字母单独成 run，而数字属于 Common，通常留在汉字段。若数字也由本
// 规则切出，「共12页」中的“共→1”步进会从 15.4543pt 降到 15.0000pt，丢失
// 一个字符网格增量。相关上游问题为 typst/typst#7475、#6539、#2702、#2703、
// #2538，根因讨论见 PR #7521。将来只有在放宽正则后 tests/check-pitch.py 的
// 汉字接数字断言仍通过，才能删除“至少一个拉丁字母”的限制。
// 匹配一段连续的西文：ASCII、拉丁-1 补充、拉丁扩展 A/B 与短横线，且至少含一个拉丁字母。
// 用于给西文片段换行高与补字距。
// -> regex
#let latin-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "\p{Latin}"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 将西文片段前的非西文字符一并匹配，以补偿整形片段边界丢失的字距。
// `latin-run-led` 里“前导字”的字符类（字符串形式，供拼接）：不属于西文片段的单个字符。
// -> str
#let latin-run-lead = "[^\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}\s\u{200B}\u{2060}\p{Co}]"
// 「run 以前导字起头」；rules.typ 里每个西文 run 都要 match 一次。
// 匹配位于字符串开头的前导字。
// -> regex
#let latin-run-lead-at-start = regex("^" + latin-run-lead)
// 匹配“一个前导字 ＋ 一段西文”，用于在片段边界补回丢失的字距。
// -> regex
#let latin-run-led = regex(
  "(?:" + latin-run-lead + ")?"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "\p{Latin}"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 匹配字体表中由西文字体槽处理的连续字符，供局部字重规则使用。
// 匹配由字体表西文槽处理的连续字符（不含汉字、中文标点、全角形式与中文形的引号、破折号、省略号）。
// -> regex
#let latin-slot-run = regex(
  "[^\p{Han}\p{Hiragana}\p{Katakana}\p{Hangul}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}"
  + "\u{00D7}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}"
  + "\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}"
  + "\n\p{Co}\u{200B}\u{2060}]+"
)

// 同一个字符集，但纯数字也算。给伪粗描边用（见 src/fonts/fake.typ）：那一族有真粗体面；描了就是双重加粗。
// 同 `latin-run` 的字符集，但纯数字也算；供伪粗描边判断哪些字已有真粗体面。
// -> regex
#let latin-ink-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "[0-9\p{Latin}]"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 匹配含汉字的整形片段，供字体基线校正规则使用。
// 各字体角色对应的 OpenType feature 标签，用于在 `text.features` 中标记当前角色。
// -> dictionary
#let role-tags = (
  songti: "izst", heiti: "izht", kaishu: "izks", kaishu-gb2312: "izkg",
  fangsong: "izfs", lishu: "izls",
)
// 每次把六个标签全写一遍：本角色 1，其余 0。
// 生成某角色的 `text(features:)` 字典：本角色为 1，其余为 0。
// -> dictionary
#let role-features(role) = {
  if role not in role-tags { return (:) }
  let out = (:)
  for (r, t) in role-tags { out.insert(t, if r == role { 1 } else { 0 }) }
  out
}

// 用 OpenType feature 标签标记是否参与正文的纯西文段规则。
// 标记“参与纯西文段规则”的 feature 标签名。
// -> str
#let latin-par-tag = "izlp"
// 生成打开或关闭纯西文段规则的 `text(features:)` 字典。
// -> dictionary
#let latin-par-features(on) = ((latin-par-tag): if on { 1 } else { 0 })

// 两翼必须贪婪；惰性匹配会把每个汉字切成独立 run，并触发 Typst 的分组深度上限。
// 匹配含汉字（或假名、中文标点、全角形式）的整形片段，供字体基线校正使用。
// -> regex
#let cjk-run = regex(
  "(?:[^\p{Latin}\p{Co}\u{2060}\s][^\p{Latin}\p{Co}\u{2060}]*)?"
  + "[\p{Han}\p{Hiragana}\p{Katakana}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}]"
  + "(?:[^\p{Latin}\p{Co}\u{2060}]*[^\p{Latin}\p{Co}\u{2060}\s])?"
)
