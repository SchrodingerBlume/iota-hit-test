// 切 run 的正则与字体角色的标签：包内的 show 规则用，不导出。

// 一段连续的西文，至少含一个拉丁字母：西文行高（没有字符网格时）与断字用。字符网格下的字距不走它，
// 走 `latin-mixed`（styles/rules.typ 的 latin-runs），那边连数字一起切。
// -> regex
#let latin-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "\p{Latin}"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 字符网格下的西文由 latin-runs 一条规则整段处理：Typst 在 run 边界丢前一个字的字距（typst/typst#5353），
// 插 h 补又会顶掉它自己的中西文间距，所以含字母或数字的整段文字交给它一次切开、交界的空当由它发。
// 私用区（模板的记号）、U+2060 与引号（regex 跨过 smartquote 会把它还原成直引号）不跨过。
// -> regex
#let latin-mixed = regex("[^\p{Co}\u{2060}\"'\n]*[0-9\p{Latin}][^\p{Co}\u{2060}\"'\n]*")
// Typst 的中西文间距只加在中日文字（不含标点）与字母、数字之间，交界两侧照这个判。
// -> regex
#let cj-char = regex("^[\p{Han}\p{Hiragana}\p{Katakana}]$")
// -> regex
#let alnum-char = regex("^[\p{L}\p{N}]$")

// 匹配字体表中由西文字体槽处理的连续字符，供局部字重规则使用。
// 匹配由字体表西文槽处理的连续字符（不含汉字、中文标点、全角形式与中文形的引号、破折号、省略号）。
// -> regex
#let latin-slot-run = regex(
  "[^\p{Han}\p{Hiragana}\p{Katakana}\p{Hangul}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}"
  + "\u{00D7}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}"
  + "\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}"
  + "\n\p{Co}\u{200B}\u{2060}]+"
)

// 同 `latin-run` 的字符集，但纯数字也算：伪粗描边判断哪些字已有真粗体面（src/fonts/fake.typ），
// latin-runs 按它切西文段（Word 里数字与字母一样是半宽字，字距取半份）。
// -> regex
#let latin-ink-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "[0-9\p{Latin}]"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 同一个字符集，不要求有字母也不要求有数字：页眉页脚里「- 3 -」这种行也按西文行盒。
// 引号不在字符集里（U+0022、U+0027）：regex show 跨过 smartquote 会把它还原成直引号。
// -> regex
#let latin-any-run = regex("[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]+")

// 匹配含汉字的整形片段，供字体基线校正规则使用。
// 各字体角色对应的 OpenType feature 标签，用于在 `text.features` 中标记当前角色。
// -> dictionary
#let role-tags = (
  songti: "izst", heiti: "izht", kaishu: "izks", kaishu-gb2312: "izkg",
  fangsong: "izfs", lishu: "izls",
)
// 每次把六个标签全写一遍：本角色 1，其余 0。
// 生成某角色的 `text(features:)` 字典：本角色为 1，其余为 0。
// -> dictionary
#let role-features(role) = {
  if role not in role-tags { return (:) }
  let out = (:)
  for (r, t) in role-tags { out.insert(t, if r == role { 1 } else { 0 }) }
  out
}

// 用 OpenType feature 标签标记是否参与正文的纯西文段规则。
// 标记“参与纯西文段规则”的 feature 标签名。
// -> str
#let latin-par-tag = "izlp"
// 生成打开或关闭纯西文段规则的 `text(features:)` 字典。
// -> dictionary
#let latin-par-features(on) = ((latin-par-tag): if on { 1 } else { 0 })
// 这一段的西文行要不要换西文行高：字符网格下 latin-line-rules 不切 run，只打这个标记，由 latin-runs 照办。
// -> str
#let latin-line-tag = "izle"
// -> dictionary
#let latin-line-features(on) = ((latin-line-tag): if on { 1 } else { 0 })

// 两翼必须贪婪；惰性匹配会把每个汉字切成独立 run，并触发 Typst 的分组深度上限。
// 匹配含汉字（或假名、中文标点、全角形式）的整形片段，供字体基线校正使用。
// -> regex
#let cjk-run = regex(
  "(?:[^\p{Latin}\p{Co}\u{2060}\s][^\p{Latin}\p{Co}\u{2060}]*)?"
  + "[\p{Han}\p{Hiragana}\p{Katakana}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}]"
  + "(?:[^\p{Latin}\p{Co}\u{2060}]*[^\p{Latin}\p{Co}\u{2060}\s])?"
)
