#import "./styles/sheet.typ": styles
#import "./styles/state.typ": current-styles
#import "./styles/local.typ": new-styles, restore-styles
#import "./styles/rules.typ": rules
#import "./styles/parts.typ": inline-math, overflow-note, paragraph
#import "./styles/table.typ": built-mark, cell-style, table-rules, table-style
#import "./styles/figure.typ": figure-spacing, figure-rules
