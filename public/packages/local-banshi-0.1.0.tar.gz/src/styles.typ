#import "./styles/sheet.typ": styles
#import "./styles/state.typ": current-styles
#import "./styles/local.typ": new-styles, restore-styles
#import "./styles/rules.typ": rules
#import "./styles/parts.typ": inline-math, overflow-note, paragraph
#import "./styles/table.typ": cell-style, table-rules, table-style, verbatim-mark
#import "./styles/figure.typ": figure-spacing, figure-rules
