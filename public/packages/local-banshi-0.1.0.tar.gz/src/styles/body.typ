// 换算层算出来的行高在这里落到 Typst 的三个 set 上。

#import "../paragraph/latin.typ" as western
#import "../paragraph/spacing.typ": spacing
#import "../paragraph/hyphenate.typ" as hyphenate
#import "../styles/state.typ": style-of
#import "./rules.typ" as style-rules
#import "./sheet.typ" as sheet
#import "../fonts/resolve.typ" as fonts
#import "../runs/regex.typ": latin-run, latin-par-tag
#import "../fonts/tracking.typ": tracking-pad
#import "../layout/resolve.typ" as _layout

// 行盒采用目标 Word 字体的度量，不随当前机器加载的替代字体变化。
#let body-rules(layout, style, doc) = {
  show: style-rules.shows.with(style, layout: layout, current: true)

  show emph: it => tracking-pad(
    fonts.kaishu(it.body, italic: true),
    probe: it.body,
  )

  show: hyphenate.hyphenate-rules

  show par: it => context {
    if text.features.at(latin-par-tag, default: 0) != 1 { return it }
    if par.leading != 0pt {
      panic(
        "set par(leading: " + repr(par.leading) + ") does not set the line spacing "
          + "here: this template keeps leading at zero and puts the whole line box "
          + "into the text edges (Word's model), so your value is added on top of it. "
          + "The body line spacing is currently "
          + repr(sheet.current-styles().body.at("line-spacing", default: auto))
          + "; change it in the body style (document(styles: (body: (line-spacing: ...))))",
      )
    }
    let layout = _layout.current-page-setup()
    let style = style-of(style, true)
    western.latin-auto(style, layout, it)
  }


  doc
}
