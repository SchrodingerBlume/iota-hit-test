// 题注：Word 的“题注”对话框——标签、位置——与它的“编号”子对话框——格式、包含章节号、章节
// 起始样式、分隔符。题注那一行按“题注”样式排（样式表里 figure.caption 那一档）。编号与题名
// 之间是 Typst 的 `figure.caption(separator:)`；从题注中排除标签是 `figure(supplement: none)`。
// 题注的字在 Word 里是打上去的，模板要在排的时候改字（换语言、双语、附录前缀）就给 `lines:`。

#import "../paragraph/spacing.typ": spacing, font-zh-of
#import "../paragraph/latin.typ": latin-box, latin-line-rules
#import "../paragraph/hyphenate.typ": hyphenate-rules
#import "../layout/resolve.typ" as _layout
#import "../layout/chars.typ": chars
#import "../fonts/resolve.typ": fontset-state
#import "../content.typ": plain-text, trim-tail
#import "../runs.typ": has-cjk
#import "./rules.typ" as style-rules
#import "../errors.typ" as _errors

// 解好的关系表；document 写入，模板自己排一条题注时 caption-body 从这儿取
#let captions-state = state("banshi-captions", none)

// 位置是 Typst 的 figure.caption(position:)：top / bottom（Word 叫 Above / Below selected item）
#let _positions = (top, bottom)
#let _separators = ("-", ".", ":", "—", "–")

/// 校验“题注”对话框那张关系表并补默认。键：`style`（题注样式名，默认样式表的
/// `figure.caption`）、`kinds`（每种 kind 一条 `(supplement:, position:)`——Word 的标签与位置，
/// 名字是 Typst 的：位置 `top` / `bottom`）、`numbering`（`format`、`include-chapter-number`、
/// `chapter-starts-with-style`、`separator`、`chapter-number: (loc, n) => content`）、`lines`
/// （`it => 数组`，每项 `(supplement:, body:, latin:)`，默认一行原文）。
/// -> dictionary
#let captions(styles, value) = {
  if type(value) != dictionary { panic("captions: expected a dictionary, found " + repr(value)) }
  let keys = ("style", "kinds", "numbering", "lines")
  for k in value.keys() {
    if k not in keys { panic("captions: unknown key " + repr(k) + "; " + _errors.expected-one-of(keys, k)) }
  }
  let style = value.at("style", default: none)
  let style = if style == none { styles.at("figure", default: (:)).at("caption", default: (:)) }
    else if type(style) == str {
      if style not in styles { panic("captions.style: no style named " + repr(style) + "; " + _errors.expected-one-of(styles.keys(), style)) }
      styles.at(style)
    } else { panic("captions.style: expected a style name, found " + repr(style)) }
  let kinds = value.at("kinds", default: (:))
  if type(kinds) != dictionary { panic("captions.kinds: expected a dictionary of kind -> (supplement:, position:), found " + repr(kinds)) }
  for (k, v) in kinds {
    if type(v) != dictionary or v.keys().any(x => x not in ("supplement", "position")) {
      panic("captions.kinds." + k + ": expected (supplement:, position:), found " + repr(v))
    }
    if "position" in v and v.position not in _positions {
      panic("captions.kinds." + k + ".position: " + _errors.expected-one-of(_positions, v.position))
    }
  }
  let num = value.at("numbering", default: (:))
  if type(num) != dictionary { panic("captions.numbering: expected a dictionary, found " + repr(num)) }
  let nkeys = ("format", "include-chapter-number", "chapter-starts-with-style", "separator", "chapter-number")
  for k in num.keys() {
    if k not in nkeys { panic("captions.numbering: unknown key " + repr(k) + "; " + _errors.expected-one-of(nkeys, k)) }
  }
  let with-chapter = num.at("include-chapter-number", default: false)
  if type(with-chapter) != bool { panic("captions.numbering.include-chapter-number: expected true or false, found " + repr(with-chapter)) }
  let starts = num.at("chapter-starts-with-style", default: none)
  if with-chapter and (type(starts) != str or starts not in styles) {
    panic("captions.numbering.chapter-starts-with-style: expected a style name when include-chapter-number is true, found " + repr(starts))
  }
  let sep = num.at("separator", default: "-")
  if sep not in _separators { panic("captions.numbering.separator: " + _errors.expected-one-of(_separators, sep)) }
  let chapter-number = num.at("chapter-number", default: (loc, n) => str(n))
  if type(chapter-number) != function { panic("captions.numbering.chapter-number: expected a function (loc, n) => content, found " + repr(chapter-number)) }
  let lines = value.at("lines", default: it => ((supplement: auto, body: it.body),))
  if type(lines) != function { panic("captions.lines: expected a function of the caption, found " + repr(lines)) }
  (
    style: style,
    kinds: kinds,
    numbering: (
      format: num.at("format", default: "1"),
      include-chapter-number: with-chapter,
      chapter-starts-with-style: starts,
      separator: sep,
      chapter-number: chapter-number,
    ),
    lines: lines,
  )
}

/// 按“编号”对话框把序号排成字：包含章节号就在前面接章节号与分隔符。`loc` 是图表所在处，
/// `seq` 是它在本 kind 计数器里的值（数组）。必须在 context 中调用。
/// -> content
#let caption-number(relation, loc, seq) = {
  let n = relation.numbering
  // 章节号闭包给 none 就是「这一处没有章节号」（比如只有一个附录，不编字母）
  let head = if n.include-chapter-number {
    let ch = counter(heading).at(loc).first()
    let mark = if ch == 0 { none } else { (n.chapter-number)(loc, ch) }
    if mark == none { none } else { mark + n.separator }
  }
  head + numbering(n.format, ..seq)
}

// 编号闭包：figure.numbering 收的是计数器的值，章节号从排它的位置取
#let _numbering-of(relation) = (..seq) => context caption-number(relation, here(), seq.pos())

/// 一条题注排出来的样子：每一行 ＝ 标签 ＋ 编号 ＋ 分隔符 ＋ 题名，按题注样式排，`latin: true`
/// 的行按西文行高；一行放不下就整段折行（Word 的题注是普通段落）。`caption-rules` 的
/// show 规则就是它；模板要在自己的规则里排一条普通题注（拆页的续片那类）也调它。
/// 必须在 context 中调用。`relation` 为 `auto` 时取 `document` 装的那一张。
/// -> content
#let caption-body(it, relation: auto) = {
  let relation = if relation == auto {
    let r = captions-state.get()
    if r == none { panic("caption-body: no captions relation in effect; pass captions: to document first") }
    r
  } else { relation }
  let layout = _layout.current-page-setup()
  let f = fontset-state.get()
  let style = relation.style
  // 按排它的位置取序号与章号：show 规则里 here() 就是题注自己；模板拿 query 出来的题注
  // 元素来排（拆页的续片）时元素没有位置，here() 是排它的地方
  let number = if it.numbering == none { none } else { caption-number(relation, here(), it.counter.get()) }
  // query 出来的题注元素还没落地，position / separator 读不到，按样式链上的值
  let position = it.at("position", default: figure.caption.position)
  let separator = it.at("separator", default: figure.caption.separator)
  let sep = if separator == auto { h(chars(1, layout: layout)) } else { separator }
  for line in (relation.lines)(it) {
    let latin = line.at("latin", default: false)
    let st = if latin { style + (font-zh: "latin", font: "serif", snap-to-grid: false) } else { style }
    let supplement = if "supplement" in line and line.supplement != auto { line.supplement } else { it.supplement }
    let body = trim-tail(line.body)
    block(above: 0pt, below: 0pt, width: 100%, sticky: position == top, {
      show: style-rules.rules.with(st, layout: layout, families: f.at(font-zh-of(st)), set-font: true)
      show: hyphenate-rules
      set align(style.at("align", default: left))
      show: if latin { latin-box.with(st, layout) } else { latin-line-rules.with(st, docgrid: layout.docgrid) }
      // 不编号的题注只剩题名：Word 的题注是「标签 ＋ 编号」，没有编号就没有那半截
      if number != none {
        supplement
        if latin { [ ] }
        number
        sep
      }
      body
    })
  }
}

/// “题注”对话框落成规则：每种 kind 的标签与位置、编号（含章节号时遇到章节起始样式的标题
/// 归零）、题注那一行按题注样式排——一行放不下时整段折行，居中就整段居中（Word 就是普通
/// 段落）。`heading-style` 是「这条标题用的样式名」（从 headings 那张表来），归零靠它认章。
/// `document` 按 `captions:` 装。
/// -> content
#let caption-rules(styles, relation, heading-style: none, doc) = {
  let numbering-of = _numbering-of(relation)
  let kind-of(k) = if k == "image" { image } else if k == "table" { table } else if k == "raw" { raw } else { k }
  // 标签与位置按 kind：show-set 写在循环体里只管循环体，得一层一层套在 doc 外面
  let with-kinds = relation.kinds.pairs().fold(d => d, (inner, (k, entry)) => d => {
    show figure.where(kind: kind-of(k)): set figure(supplement: entry.supplement) if "supplement" in entry
    show figure.where(kind: kind-of(k)): set figure.caption(position: entry.position) if "position" in entry
    inner(d)
  })
  show: with-kinds
  set figure(numbering: numbering-of)
  // 包含章节号：遇到章节起始样式的标题，各 kind 的计数器归零
  show heading: it => {
    if relation.numbering.include-chapter-number and heading-style != none and heading-style(it) == relation.numbering.chapter-starts-with-style {
      // 文档里出现过的每一种 kind 各自归零——自造的 kind 也编在各自的序列里
      context { for kind in query(figure).map(f => f.kind).dedup() { counter(figure.where(kind: kind)).update(0) } }
    }
    it
  }
  captions-state.update(relation)
  show figure.caption: it => caption-body(it, relation: relation)
  doc
}
