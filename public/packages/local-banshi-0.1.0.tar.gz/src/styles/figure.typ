// 图表块的三段空当：above（块前）、gap（图与题注之间）、below（块后），Word 里是图表前后
// 各空一行、装图段多倍行距多出来的那一截。只做映射：收装图段、表格、题注三条样式，给出长度；
// 套到哪些 figure 上（set figure(gap:)、set block(above:, below:)）是模板的规则。

#import "../paragraph/spacing.typ": spacing, amount

/// 把三段空当解成长度：`(image: (above:, gap:, below:), table: (…))`。`image`、`table` 是装图段与
/// 表格那两条样式，`caption` 是题注样式。above / below 收长度或 `(lines: n)`，写 auto 当场报错；
/// gap 写 auto 按 Word 算：网格开着时装图行占整数个网格行、图在里面居中，多出来的已在余量里，
/// gap 就是题注的段前；关着是 (倍数 − 1) × 单倍行高再加题注段前。表的 gap 是题注那一段的段后。
/// -> dictionary
#let figure-spacing(layout, metrics, image: (:), table: (:), caption: (:)) = {
  let sides = ("above", "gap", "below")
  let records = (image: image, table: table)
  let cap = spacing(caption, layout: layout, metrics: metrics)
  // 装图段自己的行高：三段空当不是段属性，剥掉再折。段里只有图和段落标记，行高按标记的
  // 西文字体算（与空段同一条规则，见 paragraph/enter.typ）
  let m = spacing(
    image.pairs().filter(((k, v)) => k not in sides).to-dict(),
    layout: layout, metrics: metrics, latin: true,
  )
  let side(which, key) = {
    let v = records.at(which).at(key, default: 0pt)
    if v == auto { panic("figure-spacing: " + which + "." + key + " is auto; only gap has a Word rule, resolve the others first") }
    amount(v, layout.docgrid)
  }
  let of(which, gap-auto) = (
    above: side(which, "above"),
    gap: if records.at(which).at("gap", default: auto) == auto { gap-auto } else { side(which, "gap") },
    below: side(which, "below"),
  )
  let snapped = layout.docgrid.grid and layout.docgrid.line-pitch != 0pt
  (
    image: of("image", (if snapped { 0pt } else { m.line-height - m.single }) + cap.above),
    table: of("table", cap.below),
  )
}
