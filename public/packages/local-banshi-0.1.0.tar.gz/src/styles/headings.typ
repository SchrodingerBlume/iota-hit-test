// 标题：Word 的样式“标题 1～n”加“定义新多级列表”对话框那张关系表——哪一级链接到哪条样式、
// 编号之后跟什么。分页、段前段后、与下段同页都是样式里段落对话框的键；编号格式是 Typst 的
// `set heading(numbering:)`。标题的字在 Word 里是打上去的，模板要在排的时候改字（换语言、
// 转大小写）就给 `body:` 闭包。

#import "../paragraph/spacing.typ": spacing, font-zh-of
#import "../paragraph/latin.typ": latin-box, latin-line-rules
#import "../layout/resolve.typ" as _layout
#import "../layout/chars.typ": resolve-chars
#import "../fonts/resolve.typ": fontset-state
#import "../content.typ": plain-text
#import "../runs.typ": has-cjk
#import "./rules.typ" as style-rules
#import "../errors.typ" as _errors

#let _follow = ("tab", "space", "nothing")

/// 校验“定义新多级列表”那张关系表并补默认。键：`link-level-to-style`（各级链接到的样式名，
/// 更深的级用末条；或 `it => 样式名`）、`follow-number-with`（`"tab"`、`"space"`、`"nothing"`，或直接写长度／
/// `(chars: n)`，或 `level => …`）、`tab-stop-at`（`"tab"` 那档的制表位）、`numbering`
/// （`it => content`，默认按 `it.numbering` 显示）、`body`（`it => content`，默认原文）。
/// -> dictionary
#let headings(styles, value) = {
  if type(value) != dictionary {
    panic("headings: expected a dictionary, found " + repr(value))
  }
  let keys = ("link-level-to-style", "follow-number-with", "tab-stop-at", "numbering", "body")
  for k in value.keys() {
    if k not in keys { panic("headings: unknown key " + repr(k) + "; " + _errors.expected-one-of(keys, k)) }
  }
  let linked = value.at("link-level-to-style", default: none)
  // 数组按级取；函数收标题元素、给样式名——模板里同一级有几种标题（摘要那种词条页与
  // 正文的章）时用
  if type(linked) == array {
    if linked.len() == 0 or linked.any(n => type(n) != str) {
      panic("headings.link-level-to-style: expected an array of style names, found " + repr(linked))
    }
    for n in linked {
      if n not in styles { panic("headings.link-level-to-style: no style named " + repr(n) + "; " + _errors.expected-one-of(styles.keys(), n)) }
    }
  } else if type(linked) != function {
    panic("headings.link-level-to-style: expected an array of style names or a function of the heading, found " + repr(linked))
  }
  let follow = value.at("follow-number-with", default: "space")
  let ok(v) = v in _follow or type(v) == length or (type(v) == dictionary and "chars" in v)
  if not (ok(follow) or type(follow) == function) {
    panic("headings.follow-number-with: " + _errors.expected-one-of(_follow, follow) + ", a length, (chars: n), or a function of the level")
  }
  let tab = value.at("tab-stop-at", default: none)
  if follow == "tab" and type(tab) != length {
    panic("headings.tab-stop-at: expected a length when follow-number-with is \"tab\", found " + repr(tab))
  }
  for k in ("numbering", "body") {
    let f = value.at(k, default: none)
    if f != none and type(f) != function { panic("headings." + k + ": expected a function of the heading, found " + repr(f)) }
  }
  (
    link-level-to-style: linked,
    follow-number-with: follow,
    tab-stop-at: tab,
    numbering: value.at("numbering", default: it => if it.numbering != none { counter(heading).display(it.numbering) }),
    body: value.at("body", default: it => it.body),
  )
}

// 编号之后跟什么：Word 的“空格”是这一档字体的一个空格；制表符跳到制表位；长度与
// (chars: n) 照给
#let _after-number(follow, tab, level, layout, number) = {
  let v = if type(follow) == function { follow(level) } else { follow }
  if v == "nothing" { none }
  else if v == "space" { [ ] }
  else if v == "tab" { h(tab - measure(number).width) }
  else { h(resolve-chars(v, layout)) }
}

/// 标题的 show 规则：按级取样式，段前分页、段前段后、与下段同页、字与段都按样式；
/// 纯西文的标题按西文行高；编号、编号之后、正文依次排。`document` 按 `headings:` 装。
/// -> content
#let heading-rules(styles, relation, doc) = {
  let linked = relation.link-level-to-style
  show heading: it => context {
    let layout = _layout.current-page-setup()
    let f = fontset-state.get()
    let name = if type(linked) == function { linked(it) } else { linked.at(calc.min(it.level, linked.len()) - 1) }
    if name not in styles { panic("headings: no style named " + repr(name) + "; " + _errors.expected-one-of(styles.keys(), name)) }
    let style = styles.at(name)
    let sp = spacing(style, layout: layout, metrics: f.metrics)
    let family = f.at(font-zh-of(style))
    let break-before = style.at("page-break-before", default: false)
    if break-before { pagebreak(weak: true) }
    // 段前：分页之后的页顶照给（Word 保留手动分页后的段前），别处由块间距给
    if break-before and sp.above != 0pt { v(sp.above, weak: false) }
    block(
      above: if break-before { 0pt } else { sp.above },
      below: sp.below,
      width: 100%,
      sticky: style.at("keep-with-next", default: false),
      breakable: not style.at("keep-lines-together", default: false),
      {
        show: style-rules.rules.with(style, layout: layout, families: family)
        set align(style.at("align", default: left))
        let body = (relation.body)(it)
        let number = (relation.numbering)(it)
        let text = plain-text(body)
        // 纯西文的标题整段按西文行高；含汉字的逐 run 换
        show: if text.match(regex("[\\p{Latin}0-9]")) != none and not has-cjk(text) {
          latin-box.with(style, layout)
        } else {
          latin-line-rules.with(style, docgrid: layout.docgrid)
        }
        if number != none {
          // 编号以括号起头时垫一个零宽空格，躲开行首标点压缩
          if plain-text(number).starts-with(regex("[（［【「『〔《〈]")) { sym.zws }
          number
          _after-number(relation.follow-number-with, relation.tab-stop-at, it.level, layout, number)
        }
        body
      },
    )
  }
  doc
}
