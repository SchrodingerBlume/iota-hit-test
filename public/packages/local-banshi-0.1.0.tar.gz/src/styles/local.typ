// 局部样式：new-styles / restore-styles——「发」的那一半。哪些键接了、两路怎么发见
// src/styles/sheet.typ 的 new-styles 那一段；住在这儿是因为要读当前版面（layout/resolve），
// 而 resolve 反过来 import sheet 验样式。
//
// 机制是 src/styles/state.typ 的那个栈：进作用域压一份局部字典、出作用域弹掉，
// restore-styles 压一个 none（＝从这儿起回到文档级那份）。压弹都是 update(f)，一个字不读；
// 要读当前那份（发正文的 set、判要不要发）的 context 都在压栈之后、弹栈之前，读到的就是
// 压过之后的值，自己不写——没有「读自己将要写的 state」这回事，五轮内必收敛。
#import "./sheet.typ" as sheet
#import "./rules.typ" as style-rules
#import "../layout/resolve.typ" as _layout

// 在栈已经压好的作用域里：正文那一档要重发一次 set（字号、行盒边、字距、缩进、对齐，与
// section 发的同一个式子）——它们是节级 set 的，光改 state 改不到；西文 run 与纯西文段
// 那几条规则则从 current-styles 现取。with-body 假就原样交回
#let _emit(with-body, body) = if not with-body { body } else {
  context style-rules.sets(sheet.current-styles().body, layout: _layout.current-page-setup(), latin-par: true, body)
}

// `#show: new-styles.with((body: (line-spacing: (exactly: 18pt))))`：从这儿起换一份，块里用出块
// 自动回（弹栈），顶层用配 restore-styles。figure.table 的字号有原生对应，折成 show table: set text
#let new-styles(local, body) = {
  sheet.check-local(local)
  let t = local.at("figure", default: (:)).at("table", default: (:))
  let body = if "size" in t {
    show table: set text(size: t.size)
    body
  } else { body }
  sheet.local-styles.update(st => st + (local,))
  _emit("body" in local, body)
  sheet.local-styles.update(st => st.slice(0, -1))
}

// 回到文档级那一份：压一个 none。正文的 set 只在 body 真变了才重发（没开过、或已经回过
// 就什么都不发，瞎用不坏事）——读的是压过 none 之后的值与文档级那份，自己不写
#let restore-styles(body) = {
  sheet.local-styles.update(st => st + (none,))
  context {
    let before = {
      // 压 none 之前那份：把栈顶的 none 去掉再并一遍
      let document = sheet.styles-state.get()
      let s = document
      for local in sheet.local-styles.get().slice(0, -1) {
        s = if local == none { document } else { sheet.merge-local(s, local) }
      }
      s
    }
    _emit(before.body != sheet.styles-state.get().body, body)
  }
  sheet.local-styles.update(st => st.slice(0, -1))
}
