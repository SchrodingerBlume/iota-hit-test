// 安装和恢复局部样式；状态合并逻辑位于 state.typ。
#import "./sheet.typ" as sheet
#import "./rules.typ" as style-rules
#import "../layout/resolve.typ" as _layout

// 正文属性属于节级 set rule，修改 state 后还需在局部作用域重新安装。
#let _emit(with-body, body) = if not with-body { body } else {
  context style-rules.sets(sheet.current-styles().body, layout: _layout.current-page-setup(), latin-par: true, body)
}

/// 在局部 show 作用域内覆盖正文或表格样式，离开作用域后自动恢复。`local` 的结构与
/// `styles` 相同，但只允许局部可安全重装的键。
///
/// ```typ
/// #show: new-styles.with((body: (size: 10.5pt, line-spacing: "single")))
/// 这一段使用五号单倍行距。
/// ```
/// -> content
#let new-styles(local, body) = {
  sheet.check-local(local)
  let t = local.at("figure", default: (:)).at("table", default: (:))
  let body = if "size" in t {
    show table: set text(size: t.size)
    body
  } else { body }
  sheet.local-styles.update(st => st + (local,))
  _emit("body" in local, body)
  sheet.local-styles.update(st => st.slice(0, -1))
}

/// 暂时清空所有局部样式，恢复 `document` 安装的文档级样式。用于嵌套组件不应继承
/// 外层局部正文设置的场合。
/// -> content
#let restore-styles(body) = {
  sheet.local-styles.update(st => st + (none,))
  context {
    let before = {
      let document = sheet.styles-state.get()
      let s = document
      for local in sheet.local-styles.get().slice(0, -1) {
        s = if local == none { document } else { sheet.merge-local(s, local) }
      }
      s
    }
    _emit(before.body != sheet.styles-state.get().body, body)
  }
  sheet.local-styles.update(st => st.slice(0, -1))
}
