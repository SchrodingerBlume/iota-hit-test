// 安装和恢复局部样式；状态合并逻辑位于 state.typ。
#import "./sheet.typ" as sheet
#import "./rules.typ" as style-rules
#import "../layout/resolve.typ" as _layout

// 正文属性属于节级 set rule，修改 state 后还需在局部作用域重新安装。
#let _emit(with-body, body) = if not with-body { body } else {
  context style-rules.sets(sheet.current-styles().body, layout: _layout.current-page-setup(), latin-par: true, body)
}

/// 在 show 作用域内应用局部正文或表格样式。
/// -> content
#let new-styles(local, body) = {
  sheet.check-local(local)
  let t = local.at("figure", default: (:)).at("table", default: (:))
  let body = if "size" in t {
    show table: set text(size: t.size)
    body
  } else { body }
  sheet.local-styles.update(st => st + (local,))
  _emit("body" in local, body)
  sheet.local-styles.update(st => st.slice(0, -1))
}

/// 在当前作用域中恢复文档级样式。
/// -> content
#let restore-styles(body) = {
  sheet.local-styles.update(st => st + (none,))
  context {
    let before = {
      let document = sheet.styles-state.get()
      let s = document
      for local in sheet.local-styles.get().slice(0, -1) {
        s = if local == none { document } else { sheet.merge-local(s, local) }
      }
      s
    }
    _emit(before.body != sheet.styles-state.get().body, body)
  }
  sheet.local-styles.update(st => st.slice(0, -1))
}
