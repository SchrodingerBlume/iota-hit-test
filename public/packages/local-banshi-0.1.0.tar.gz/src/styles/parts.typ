
#import "../paragraph/spacing.typ": indent, spacing, amount
#import "../fonts/presets.typ": zihao
#import "./rules.typ" as style-rules
#import "../content.typ": plain-text
#import "../fonts/resolve.typ" as fonts
#import "../layout/resolve.typ" as _layout
// Typst 没有「警告」这一档，只有拦编译；为了一页封面卡住整篇文档不任何基线；走 page 的 foreground 是为了「每一页都有」；溢出时是两页。
#let overflow-note(body, off, lang: "zh") = place(top + left, dx: 8mm, dy: 8mm, block(
  width: 180mm,
  {
    let f = fonts.fontset-state.get()
    set text(
      size: zihao.xiaoer, fill: rgb("#cc0000"), weight: "bold",
      font: if lang == "en" { f.sans } else { f.heiti }, lang: lang,
      top-edge: "ascender", bottom-edge: "descender",
    )
    set par(leading: 0.5em)
    body
    linebreak()
    off
  },
))

// 封面上的一行。收的是 Word 段落对话框上的那几格，折成 style 交给部件层；排一个 Word 段。
#let _open-puncts = ("（", "〔", "［", "｛", "〈", "《", "「", "『", "【")

#let _needs-zws(body) = {
  let s = plain-text(body)
  if s == none { return false }
  let cs = s.clusters()
  cs.len() > 0 and cs.first() in _open-puncts
}

// 封面、内封、声明页排的都是 Word 段，Word 段里没有行间公式这一档。
#let inline-math(body) = {
  show math.equation.where(block: true): it => math.equation(block: false, numbering: none, it.body)
  body
}

// leading：段内行与行之间的空当，auto ＝ 跟 sets 里的 0（行高定高，行距全在盒里）；深圳本科报告首页折了行的格要按段前排折出来的行，从这儿给；写在内容里的 set par(leading:) layout：这一页的页面设置。
#let paragraph(
  body,
  style,
  layout: auto,
  metrics: auto,
  above: auto,
  at-page-start: false,
  leading: auto,
) = {
  if layout == auto or metrics == auto {
    return context paragraph(
      body, style,
      layout: if layout == auto { _layout.current-page-setup() } else { layout },
      metrics: if metrics == auto { fonts.fontset-state.get().metrics } else { metrics },
      above: above, at-page-start: at-page-start, leading: leading,
    )
  }
  if type(at-page-start) != bool {
    panic("at-page-start: expected true or false, found " + repr(at-page-start))
  }
  let lines(key) = {
    let v = style.at(key, default: 0pt)
    if type(v) == dictionary and "lines" in v {
      let n = v.at("lines")
      if type(n) not in (int, float) {
        panic("expected number for \"lines\", found " + str(type(n)))
      }
      n * layout.docgrid.line-unit
    } else if type(v) == length { v } else {
      panic("expected length or dictionary with \"lines\", found " + repr(v))
    }
  }
  let computed = spacing(style, layout: layout, metrics: metrics)
  let ind = indent(style, layout: layout)
  let before = if above == auto { lines("above") } else { above }
  // `block.above` 在页首没有前项，会消失；调用方确认段落位于页首时改发不可折叠间距。
  if at-page-start and before != 0pt {
    v(before, weak: false)
  }
  block(
    above: if at-page-start { 0pt } else { before },
    below: lines("below"),
    width: 100%,
    inset: (left: ind.at("left", default: 0pt)),
    {
      show: style-rules.rules.with(style, layout: layout, set-font: true)
      show: inline-math
      if style.at("align", default: left) == center {
        align(center, par(
          ..(if leading != auto { (leading: leading) } else { (:) }),
          body,
        ))
      } else {
        par(
          first-line-indent: (amount: ind.first-line, all: true),
          hanging-indent: ind.hanging,
          (if _needs-zws(body) { sym.zws }) + body,
        )
      }
    },
  )
}
