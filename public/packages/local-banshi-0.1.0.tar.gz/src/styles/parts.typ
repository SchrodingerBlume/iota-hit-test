
#import "../paragraph/spacing.typ": indent, spacing, amount
#import "../fonts/presets.typ": zihao
#import "./rules.typ" as style-rules
#import "../content.typ": plain-text
#import "../fonts/resolve.typ" as fonts
#import "../layout/resolve.typ" as _layout
#import "../runs.typ": has-asian

// Typst 会压缩的那几个全角开标点（typst-layout 的 shaping.rs 按码表判，不看 lang）；Word 段首不压，
// 前面垫一个零宽空格挡住。
#let _open-puncts = ("（", "〔", "［", "｛", "〈", "《", "「", "『", "【")

#let _needs-zws(body) = {
  let s = plain-text(body)
  if s == none { return false }
  let cs = s.clusters()
  cs.len() > 0 and cs.first() in _open-puncts
}

// 封面、内封、声明页排的都是 Word 段，Word 段里没有行间公式这一档。
/// 把块级公式改排为行内：Word 段落中没有行间公式。
/// -> content
#let inline-math(body) = {
  show math.equation.where(block: true): it => math.equation(block: false, numbering: none, it.body)
  body
}

// leading：段内行与行之间的空当，auto ＝ 跟 sets 里的 0（行高定高，行距全在盒里）；深圳本科报告首页折了行的格要按段前排折出来的行，从这儿给。
/// 按一条已解析样式排一个 Word 段落。字体角色、字号、行盒、字距、首行/悬挂缩进、
/// 对齐、段前段后和西文行高都由样式决定。
///
/// `layout` 与 `metrics` 为 `auto` 时读取当前文档状态；`above` 可临时覆盖段前；
/// `at-page-start: true` 表示该段位于页首，Word 会吞掉段前。`latin` 是这一段全不全是西文
/// （行盒按西文字体、字距半份），`auto` 看内容：读得到字且没有汉字就是。标题与题注规则应
/// 使用本函数，不要只套 `text(...)`，否则段落度量不会安装。
///
/// ```typ
/// #show heading.where(level: 1): it => paragraph(
///   it.body, styles.heading-1,
///   at-page-start: true,
/// )
/// ```
/// -> content
#let paragraph(
  body,
  style,
  layout: auto,
  metrics: auto,
  above: auto,
  at-page-start: false,
  leading: auto,
  latin: auto,
) = {
  if layout == auto or metrics == auto {
    return context paragraph(
      body, style,
      layout: if layout == auto { _layout.current-page-setup() } else { layout },
      metrics: if metrics == auto { fonts.fontset-state.get().metrics } else { metrics },
      above: above, at-page-start: at-page-start, leading: leading, latin: latin,
    )
  }
  // 藏在 context 后面的字读不到，那就按有汉字算——行里的西文 run 自会换西文行盒
  let latin = if latin != auto { latin } else {
    let words = plain-text(body)
    words.trim() != "" and not has-asian(words)
  }
  if type(at-page-start) != bool {
    panic("at-page-start: expected true or false, found " + repr(at-page-start))
  }
  let lines(key) = {
    let v = style.at(key, default: 0pt)
    if type(v) == dictionary and "lines" in v {
      let n = v.at("lines")
      if type(n) not in (int, float) {
        panic("expected number for \"lines\", found " + str(type(n)))
      }
      n * layout.docgrid.line-unit
    } else if type(v) == length { v } else {
      panic("expected length or dictionary with \"lines\", found " + repr(v))
    }
  }
  let computed = spacing(style, layout: layout, metrics: metrics, latin: latin)
  let ind = indent(style, layout: layout)
  let before = if above == auto { lines("above") } else { above }
  // `block.above` 在页首没有前项，会消失；调用方确认段落位于页首时改发不可折叠间距。
  if at-page-start and before != 0pt {
    v(before, weak: false)
  }
  block(
    above: if at-page-start { 0pt } else { before },
    below: lines("below"),
    width: 100%,
    inset: (left: ind.at("left", default: 0pt)),
    {
      show: style-rules.rules.with(style, layout: layout, set-font: true, latin: latin)
      show: inline-math
      if style.at("align", default: left) == center {
        align(center, par(
          ..(if leading != auto { (leading: leading) } else { (:) }),
          body,
        ))
      } else {
        par(
          first-line-indent: (amount: ind.first-line, all: true),
          hanging-indent: ind.hanging,
          (if _needs-zws(body) { sym.zws }) + body,
        )
      }
    },
  )
}
