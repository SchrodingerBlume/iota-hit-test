// 样式落到 Typst 上：sets（set text / set par）、shows（纯西文段、伪粗、字距补偿……）、rules 是两者合一。

#import "../paragraph/latin.typ" as western
#import "../paragraph/spacing.typ": role-of, latin-font-of, families-of, indent, spacing, tracking-of, amount, no-docgrid, latin-tracking, set-tracking
#import "../paragraph/hyphenate.typ" as hyphenate
#import "../layout/state.typ": layout-of
#import "../styles/state.typ": style-of
#import "../runs/regex.typ": latin-slot-run, latin-ink-run, latin-mixed, cj-char, alnum-char, role-features, latin-par-features, latin-line-tag, latin-line-features
#import "../fonts/resolve.typ" as fonts
#import "../fonts/fake.typ" as _synth
#import "../layout/state.typ": page-setup-state

// 将 Word 段落属性换算后映射到 Typst 的 text 与 par set rule。

// 「角色」是样式的中文字体（paragraph/spacing.typ 的 role-of）：伪粗、OpenType 标签都按它问。
#let _role-of = role-of

// 纯西文段直接使用半份字符网格间距，不安装中西文边界补偿。

#let _table-bold(style) = (
  style.at("latin-bold", default: false) and fonts.lacks-bold(_role-of(style))
)

#let _regex-bold(style) = (
  style.at("latin-bold", default: false) and not fonts.lacks-bold(_role-of(style))
)

// Word 按字符所占网格单元分配间距：全宽字符一份，半宽西文字符半份。

// latin：这一段全是西文——行盒按西文字体、字距半份（Word 半宽字占半格）。
#let sets(style, layout: no-docgrid, families: none, latin-par: false, latin: false, doc) = {
  let computed = spacing(style, docgrid: layout.docgrid, latin: latin)
  let ind = indent(style, docgrid: layout.docgrid)
  let bold = style.at("bold", default: false)
  set text(
    size: computed.size,
    top-edge: computed.top-edge,
    bottom-edge: -computed.bottom-edge,
    costs: (widow: 0%, orphan: 0%),
    tracking: set-tracking(style, computed, latin: latin),
    weight: if bold { "bold" } else { "regular" },
    ..(if families != none { (font: families) } else { (:) }),
    features: role-features(_role-of(style)) + latin-par-features(latin-par) + latin-line-features(false),
  )
  show raw.where(block: false): set text(
    top-edge: computed.top-edge.abs + computed.top-edge.em * computed.size,
    bottom-edge: -(computed.bottom-edge.abs + computed.bottom-edge.em * computed.size),
  )
  set par(
    leading: 0pt,
    spacing: calc.max(computed.above, computed.below),
    justify: style.at("justify", default: false),
    first-line-indent: (amount: ind.first-line, all: true),
    hanging-indent: ind.hanging,
  )
  doc
}

// 一个西文段里长到一行放不下的词：Word 在词内按字符断行，这里插零宽空格造断点。
#let _long-words(t, avail) = {
  let long(w) = w.clusters().len() >= hyphenate.long-word-min and measure(text(w)).width > avail
  let words = t.split(" ")
  if avail == 0pt or not words.any(long) { return t }
  words.map(w => if long(w) { hyphenate.long-word-chunks(w.clusters()).join("\u{200B}") } else { w }).join(" ")
}

// 字符网格下的西文段：字距半份（Word 半宽字占半格）、不贴网格时换西文行高、长词词内断。Typst 在 run 边界丢
// 前一个字的字距，插 h 补又顶掉它自己的中西文间距，所以整段在这里切开，交界的空当全由这里发：挨着中日文字
// 两侧都是整份字距 ＋ 1/4 字（Word 实测，见 tests/check-boundary.py），别的交界只补丢掉的那份。
/// 西文段的规则（通常经 `shows` 装上；正文那一条由 `document` 装在最里层，赶在别的切 run 规则之前）。
/// -> content
#let latin-runs(style, layout: no-docgrid, current: false, latin: false, doc) = {
  show latin-mixed: it => context {
    let l = layout-of(layout, current)
    let style = style-of(style, current)
    let computed = spacing(style, docgrid: l.docgrid)
    if not (computed.snap-h or style.at("latin-bold", default: false)) { return it }
    let full = tracking-of(computed, tracking: style.at("tracking", default: 0pt))
    let half = latin-tracking(style, computed)
    let latin-line = spacing(style, docgrid: l.docgrid, latin: true)
    let in-math = text.font.contains(lower(fonts.fontset-state.get().math))
    let own-line = (
      not in-math and (text.top-edge == computed.top-edge or text.top-edge == latin-line.top-edge)
    )
    if not own-line or text.tracking != set-tracking(style, computed, latin: latin) { return it }
    let s = it.text
    if latin {
      let t = _long-words(s, l.text-width)
      return if t == s { it } else { t }
    }
    let runs = s.matches(latin-ink-run)
    if runs.len() == 0 { return it }
    let edges = if computed.snap or text.features.at(latin-line-tag, default: 0) != 1 { (:) } else {
      (top-edge: latin-line.top-edge, bottom-edge: -latin-line.bottom-edge)
    }
    let loss = fonts.boundary-loss()
    let spaced = text.cjk-latin-spacing == auto
    let cj(c) = c.match(cj-char) != none
    let alnum(c) = c.match(alnum-char) != none and not cj(c)
    let out = ()
    let pos = 0
    for (i, r) in runs.enumerate() {
      let first = r.text.clusters().first()
      let last = r.text.clusters().last()
      if r.start > pos {
        let lead = s.slice(pos, r.start)
        let e = lead.clusters().last()
        out.push(lead)
        // 西文段以空格起头时 weak 会顶掉那个空格
        out.push(if first == " " { h(full * loss) } else {
          h(full * loss + if spaced and cj(e) and alnum(first) { 0.25em } else { 0pt }, weak: true)
        })
      }
      out.push(text(tracking: half, ..edges, _long-words(r.text, l.text-width)))
      let stop = if i + 1 < runs.len() { runs.at(i + 1).start } else { s.len() }
      if stop > r.end and last != " " {
        let e = s.slice(r.end, stop).clusters().first()
        out.push(h(half * loss + if spaced and alnum(last) and cj(e) { 0.25em + full - half } else { 0pt }, weak: true))
      }
      pos = r.end
    }
    if pos < s.len() { out.push(s.slice(pos)) }
    out.join()
  }
  doc
}
#let _latin-runs = latin-runs

// 一条样式的 show 那一半：伪粗、代码字的字距、西文 run 的字距与加粗。
#let shows(style, layout: no-docgrid, current: false, latin: false, latin-runs: true, doc) = {
  let installed = spacing(style, docgrid: layout.docgrid, latin: latin)
  let bold = style.at("bold", default: false)
  // 全是西文的一段，粗体按西文字体问（Times 有真粗面，不合成）
  let role = if latin { latin-font-of(style) } else { _role-of(style) }
  let latin-bold = style.at("latin-bold", default: false)
  show: it => context {
    if bold and _synth.wants-bold-for(role) { _synth.fake-bold(it) } else if _table-bold(style) {
      set text(weight: "bold")
      if not fonts.lacks-bold("songti") {
        show fonts.cjk-first: set text(weight: "regular")
        it
      } else { it }
    } else { it }
  }
  let raw-rules(body) = if installed.snap-h {
    show raw: it => context {
      let style = style-of(style, current)
      let computed = spacing(style, docgrid: layout-of(layout, current).docgrid)
      let full-tracking = tracking-of(computed, tracking: style.at("tracking", default: 0pt))
      if text.tracking != full-tracking { it } else {
        if not it.block { h(full-tracking * fonts.boundary-loss()) }
        set text(tracking: latin-tracking(style, computed))
        it
      }
    }
    body
  } else {
    body
  }
  show: raw-rules
  let bold-rules(body) = context {
    if not _regex-bold(style) { return body }
    show latin-slot-run: r => context {
      if text.font.contains(lower(fonts.fontset-state.get().math)) { r } else { text(weight: "bold", r) }
    }
    body
  }
  show: bold-rules
  let wanted = latin-runs and (current or installed.snap-h or latin-bold)
  if wanted { _latin-runs(style, layout: layout, current: current, latin: latin, doc) } else { doc }
}

// 两半叠起来：set 在外、show 在内。
/// 把一条样式落成 set 与 show 规则：字号、行盒、字距、缩进、对齐，以及西文片段的
/// 加粗、行高与字距补偿。`set-font` 为真时同时设置字体（中文字体管汉字、西文字体管西文）；
/// `latin-par` 为真时该样式的段落参与“纯西文段换西文行高”的规则；`latin: true` 表示这一段
/// 全是西文——行盒按西文字体、字距半份、只给西文字体。
/// -> content
#let rules(
  style,
  layout: no-docgrid,
  set-font: false,
  families: auto,
  latin-par: false,
  latin: false,
  doc,
) = {
  let apply(families) = {
    show: sets.with(style, layout: layout, families: families, latin-par: latin-par, latin: latin)
    show: shows.with(style, layout: layout, latin: latin)
    doc
  }
  if families != auto {
    return apply(families)
  }
  if set-font {
    context apply(families-of(style, fonts.fontset-state.get(), latin: latin))
  } else {
    apply(none)
  }
}

// Word 的样式窗格：一条 = 字体对话框 + 段落对话框。
