// 样式落到 Typst 上：sets（set text / set par）、shows（纯西文段、伪粗、字距补偿……）、rules 是两者合一。

#import "../paragraph/latin.typ" as western
#import "../paragraph/spacing.typ": role-of, font-zh-of, indent, spacing, tracking-of, amount, no-docgrid, pure-latin, latin-tracking, set-tracking
#import "../paragraph/hyphenate.typ" as hyphenate
#import "../layout/state.typ": layout-of
#import "../styles/state.typ": style-of
#import "../runs/regex.typ": latin-run, latin-run-lead-at-start, latin-run-led, latin-slot-run, role-features, latin-par-features
#import "../fonts/resolve.typ" as fonts
#import "../fonts/fake.typ" as _synth
#import "../layout/state.typ": page-setup-state

// 将 Word 段落属性换算后映射到 Typst 的 text 与 par set rule。

// 字体角色与行高档位互推的两条在 paragraph/spacing.typ 的 role-of / font-zh-of。
#let _role-of = role-of

// 纯西文段直接使用半份字符网格间距，不安装中西文边界补偿。

#let _table-bold(style) = (
  style.at("latin-bold", default: false) and fonts.lacks-bold(_role-of(style))
)

#let _regex-bold(style) = (
  style.at("latin-bold", default: false) and not fonts.lacks-bold(_role-of(style))
)

// Word 按字符所占网格单元分配间距：全宽字符一份，半宽西文字符半份。

#let sets(style, layout: no-docgrid, families: none, latin-par: false, doc) = {
  let computed = spacing(style, docgrid: layout.docgrid)
  let ind = indent(style, docgrid: layout.docgrid)
  let bold = style.at("bold", default: false)
  set text(
    size: computed.size,
    top-edge: computed.top-edge,
    bottom-edge: -computed.bottom-edge,
    costs: (widow: 0%, orphan: 0%),
    tracking: set-tracking(style, computed),
    weight: if bold { "bold" } else { "regular" },
    ..(if families != none { (font: families) } else { (:) }),
    features: role-features(_role-of(style)) + latin-par-features(latin-par),
  )
  show raw.where(block: false): set text(
    top-edge: computed.top-edge.abs + computed.top-edge.em * computed.size,
    bottom-edge: -(computed.bottom-edge.abs + computed.bottom-edge.em * computed.size),
  )
  set par(
    leading: 0pt,
    spacing: calc.max(computed.above, computed.below),
    justify: style.at("justify", default: false),
    first-line-indent: (amount: ind.first-line, all: true),
    hanging-indent: ind.hanging,
  )
  doc
}

// 一条样式的 show 那一半：伪粗、代码字的字距、西文 run 的字距与加粗。
#let shows(style, layout: no-docgrid, current: false, doc) = {
  let installed = spacing(style, docgrid: layout.docgrid)
  let bold = style.at("bold", default: false)
  let role = _role-of(style)
  let pure-latin = pure-latin(style)
  let latin-bold = style.at("latin-bold", default: false)
  show: it => context {
    if bold and _synth.wants-bold-for(role) { _synth.fake-bold(it) } else if _table-bold(style) {
      set text(weight: "bold")
      if not fonts.lacks-bold("songti") {
        show fonts.cjk-first: set text(weight: "regular")
        it
      } else { it }
    } else { it }
  }
  let raw-rules(body) = if installed.snap-h {
    show raw: it => context {
      let style = style-of(style, current)
      let computed = spacing(style, docgrid: layout-of(layout, current).docgrid)
      let full-tracking = tracking-of(computed, tracking: style.at("tracking", default: 0pt))
      if text.tracking != full-tracking { it } else {
        if not it.block { h(full-tracking * fonts.boundary-loss()) }
        set text(tracking: latin-tracking(style, computed))
        it
      }
    }
    body
  } else {
    body
  }
  show: raw-rules
  let bold-rules(body) = context {
    if not _regex-bold(style) { return body }
    show latin-slot-run: r => context {
      if text.font.contains(lower(fonts.fontset-state.get().math)) { r } else { text(weight: "bold", r) }
    }
    body
  }
  show: bold-rules
  if installed.snap-h or latin-bold {
    // 西文只取半份字符网格增量，样式自身的 `w:spacing` 也取半份。曾经整份应用时，
    // 章标题中 F 的步进为 10.062pt = 10.008 + 0.4543 − 0.4；Word 的模型是
    // 全宽汉字占两个半格，半宽西文占一个半格，因此应使用 0.227pt 网格增量与
    // 0.2pt 紧缩。这里同时接受中文和西文 top-edge，是为了让标题中的西文 run
    // 也进入这条规则。
    show latin-run-led: it => context {
    let l = layout-of(layout, current)
    let style = style-of(style, current)
    let computed = spacing(style, docgrid: l.docgrid)
    let full-tracking = tracking-of(computed, tracking: style.at("tracking", default: 0pt))
    let set-tracking = set-tracking(style, computed)
    let latin-tracking = latin-tracking(style, computed)
    let latin-line = spacing(style + (font-zh: "latin"), docgrid: l.docgrid)
    let in-math = text.font.contains(lower(fonts.fontset-state.get().math))
    let own-line = (
      not in-math and (
        text.top-edge == computed.top-edge or text.top-edge == latin-line.top-edge
      )
    )
    let lead = it.text.match(latin-run-lead-at-start)
    let latin-text = if lead == none { it.text } else { it.text.slice(lead.end) }
    if not own-line or text.tracking != set-tracking { it } else {
      let avail = l.text-width
      let words = latin-text.split(" ")
      let needs-break = avail != 0pt and words.any(w => (
        w.clusters().len() >= hyphenate.long-word-min and measure(text(w)).width > avail
      ))
      let body = if not needs-break { latin-text } else {
        words.map(w => {
          if w.clusters().len() >= hyphenate.long-word-min and measure(text(w)).width > avail {
            text(tracking: latin-tracking, hyphenate.long-word-chunks(w.clusters()).join("\u{200B}"))
          } else { w }
        }).join(" ")
      }
      if not needs-break {
        let loss = if lead == none or pure-latin { 0 } else { fonts.boundary-loss() }
        show latin-run: r => {
          if loss != 0 { h(full-tracking * loss) }
          set text(tracking: latin-tracking)
          r
        }
        if loss != 0 { h(full-tracking * loss) }
        it
      } else {
        if lead != none {
          if pure-latin { lead.text } else {
            let loss = fonts.boundary-loss()
            h(full-tracking * loss); lead.text; h(full-tracking * loss)
          }
        }
        {
          set text(tracking: latin-tracking)
          body
        }
      }
    }
    }
    doc
  } else {
    doc
  }
}

// 两半叠起来：set 在外、show 在内。
/// 把一条样式落成 set 与 show 规则：字号、行盒、字距、缩进、对齐，以及西文片段的
/// 加粗、行高与字距补偿。`set-font` 为真时同时设置字体；`latin-par` 为真时该样式的段落
/// 参与“纯西文段换西文行高”的规则。
/// -> content
#let rules(
  style,
  layout: no-docgrid,
  set-font: false,
  families: auto,
  latin-par: false,
  doc,
) = {
  let apply(families) = {
    show: sets.with(style, layout: layout, families: families, latin-par: latin-par)
    show: shows.with(style, layout: layout)
    doc
  }
  if families != auto {
    return apply(families)
  }
  if set-font {
    context apply(fonts.font(
      _role-of(style),
      fonts.fontset-state.get().families,
      latin: style.at("font-latin", default: "serif"),
      em-dash: fonts.fontset-state.get().at("em-dash", default: "cjk"),
    ))
  } else {
    apply(none)
  }
}

// Word 的样式窗格：一条 = 字体对话框 + 段落对话框。
