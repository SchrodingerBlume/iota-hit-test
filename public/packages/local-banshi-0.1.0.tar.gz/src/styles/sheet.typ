// Word 样式表：一条记录同时保存字体与段落属性。

#import "../paragraph/spacing.typ": spacing
#import "../fonts/presets.typ": zihao, en-roles, zh-roles
#import "../errors.typ" as _errors
#import "./rules.typ" as style-rules

#let style-keys = (
  // 字体对话框：中文字体、西文字体、字号、加粗、字符间距
  "asian-font", "latin-font", "size", "bold", "latin-bold", "tracking", "line-spacing",
  "above", "below",
  "first-line-indent", "hanging-indent", "left-indent",
  "align", "snap-to-grid", "justify",
  // 段落对话框“换行和分页”卡：段前分页、与下段同页（Typst 的 sticky）、段中不分页（Typst 的 breakable）
  "page-break-before", "sticky", "breakable",
)

// 样式值在合并前校验，避免拼错键名或把字符串 `"center"` 当作 Typst alignment。

#let _line-spacing-ok(v) = (
  v in ("single", "double")
    or type(v) in (int, float)
    or type(v) == length
    or (type(v) == dictionary and v.keys().len() == 1 and (
      "exactly" in v or "at-least" in v
    ))
)

// line-spacing-auto：这一条的行距收不收 auto；只有基准表里本来就写 auto 的那几条收（模板自己按别的条件解），别的条写 auto 没有解法，当场报错。
// 子记录：基准表里值是字典、又不是样式键的键（figure.image、theorem.head……）。形状由基准表定，
// 用户只能写基准表里有的子键；子记录各自再按样式验。
// gap / inset / stroke 是图表那几档的额外键（Typst 的 figure.gap、Word 的单元格边距与边框），值也可以是字典，不算子记录
#let _extra-keys = ("gap", "inset", "stroke")
#let _sub-keys(base) = if base == none { () } else {
  base.pairs().filter(((k, v)) => k not in style-keys and k not in _extra-keys and type(v) == dictionary).map(((k, v)) => k)
}

// kind：正在验的是哪个子键（"image" / "table" / "caption" / "head"……），顶层是 none。
#let validate-style(entry, name, line-spacing-auto: false, kind: none, base: none) = {
  if type(entry) != dictionary {
    panic(name + ": expected a dictionary, found " + repr(entry))
  }
  let subs = _sub-keys(base)
  for (key, v) in entry {
    if subs.len() > 0 and key not in style-keys {
      if key not in subs {
        panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(subs, key))
      }
      validate-style(
        v, name + "." + key, kind: key, base: base.at(key),
        line-spacing-auto: base.at(key).at("line-spacing", default: none) == auto,
      )
      continue
    }
    if kind in ("image", "table") and key in ("above", "gap", "below") {
      if not (v == auto or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))) {
        panic(name + "." + key + ": expected auto, a length, or a dictionary with \"lines\", found " + repr(v))
      }
      continue
    }
    if kind == "table" and key == "inset" {
      let ok(x) = type(x) == length
      if not (ok(v) or (type(v) == dictionary and v.keys().all(k => k in ("x", "y")) and v.values().all(ok))) {
        panic(name + ".inset: expected a length or a dictionary with \"x\" and \"y\" (Word's cell margins), found " + repr(v))
      }
      continue
    }
    if kind == "table" and key == "stroke" {
      let edges = ("top", "bottom", "left", "right", "inside-horizontal", "inside-vertical", "header")
      if not (v == auto or type(v) == length or (type(v) == dictionary and v.keys().all(k => k in edges) and v.values().all(x => type(x) == length or x == none))) {
        panic(name + ".stroke: expected auto (Word's grid, all 0.5pt), a length, or a dictionary of edges "
          + _errors.one-of(edges.map(repr)) + " in pt, found " + repr(v))
      }
      continue
    }
    if key not in style-keys {
      panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(style-keys, key))
    }
    let where = name + "." + key + ": "
    if key == "asian-font" and v not in zh-roles {
      panic(where + _errors.expected-one-of(zh-roles, v))
    } else if key == "latin-font" and v not in en-roles {
      panic(where + _errors.expected-one-of(en-roles, v))
    } else if key == "size" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length such as zihao.xiaosi or 12pt, found " + repr(v))
    } else if key in ("bold", "latin-bold", "snap-to-grid", "justify", "page-break-before", "sticky", "breakable") and type(v) != bool {
      panic(where + "expected true or false, found " + repr(v))
    } else if key == "tracking" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length (Word's character spacing, in pt), found " + repr(v))
    } else if key == "line-spacing" and not (_line-spacing-ok(v) or (line-spacing-auto and v == auto)) {
      panic(
        where + "expected \"single\", \"double\", a number, a length, or a dictionary with "
          + "\"exactly\" or \"at-least\""
          + (if line-spacing-auto { ", or auto (this style resolves it by itself)" } else { "" })
          + ", found " + repr(v),
      )
    } else if key in ("above", "below") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))
    ) {
      panic(where + "expected length or dictionary with \"lines\", found " + repr(v))
    } else if key in ("first-line-indent", "hanging-indent", "left-indent") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("chars",))
    ) {
      panic(where + "expected length or dictionary with \"chars\", found " + repr(v))
    } else if key == "align" and type(v) != alignment {
      panic(where + "expected alignment (left, center, or right), found " + repr(v))
    }
  }
}

#import "./state.typ": styles-state, local-styles, current-styles, merge-local

// 局部样式通过 styles/state.typ 的栈生效；离开 show 作用域后自动恢复。
#let _local-keys = ("body", "figure")
#let _check-local(local) = {
  if type(local) != dictionary {
    panic("new-styles: expected a dictionary (the same shape as document(styles:)), found " + repr(local))
  }
  for (name, entry) in local {
    if name not in _local-keys or (name == "figure" and (type(entry) != dictionary or entry.keys().any(k => k != "table"))) {
      panic(
        "#show: new-styles.with(...): only body and (figure: (table: ...)) can be changed locally for now; "
          + "change " + repr(name) + " at document level with document(styles: ...)",
      )
    }
    if name == "figure" {
      for (k, v) in entry { validate-style(v, "styles.figure." + k, kind: k) }
    } else {
      validate-style(entry, "styles." + name)
    }
  }
}
// 状态合并与规则安装分离在 state.typ 和 local.typ 中，以避免循环导入。
#let local-keys = _local-keys
#let check-local = _check-local

/// 校验并合并基准样式、模板预设与用户覆盖，优先级为 `base < preset < local`。
/// 每条同名样式逐键合并，不会因局部覆盖而丢掉模板中的其余属性。
///
/// `body` 是必需样式；图、表和题注放在 `figure.image`、`figure.table`、
/// `figure.caption`。哪些条目带子记录由基准表的形状决定（值是字典、又不是样式键的键），
/// 上层模板可以照样声明自己的（如 `theorem: (head: …, body: …)`）。标题等名称由上层模板决定。
///
/// ```typ
/// #let resolved = styles(
///   (body: (size: 12pt, line-spacing: 1.25)),
///   (body: (first-line-indent: (chars: 2), justify: true)),
/// )
/// ```
/// -> dictionary
#let styles(base, local, preset: (:)) = {
  if type(local) != dictionary {
    panic("styles: expected a dictionary, found " + repr(local))
  }
  // 子记录逐键合并，别的键整个盖过去
  let join(base, entry) = {
    let out = base + entry
    for key in _sub-keys(base) {
      if key in entry { out.insert(key, base.at(key) + entry.at(key)) }
    }
    out
  }
  let merged = base
  for (name, entry) in preset { merged.insert(name, join(merged.at(name), entry)) }
  for (name, entry) in local {
    if name not in base {
      panic(
        "styles: unknown style \"" + name + "\"; "
          + _errors.expected-one-of(base.keys(), name),
      )
    }
    validate-style(
      entry, "styles." + name, base: base.at(name),
      line-spacing-auto: base.at(name).at("line-spacing", default: none) == auto,
    )
    merged.insert(name, join(merged.at(name), entry))
  }
  merged
}
