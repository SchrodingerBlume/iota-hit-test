// Word 样式表：一条记录同时保存字体与段落属性。

#import "../paragraph/spacing.typ": spacing
#import "../fonts/presets.typ": zihao, en-roles, zh-roles
#import "../errors.typ" as _errors
#import "./rules.typ" as style-rules

#let style-keys = (
  // 字体对话框：中文字体、西文字体、字号、加粗、字符间距
  "asian-font", "latin-font", "size", "bold", "latin-bold", "tracking", "line-spacing",
  "above", "below",
  "first-line-indent", "hanging-indent", "left-indent",
  "align", "snap-to-grid", "justify",
  // 段落对话框“换行和分页”卡：段前分页、与下段同页（Typst 的 sticky）、段中不分页（Typst 的 breakable）
  "pagebreak-before", "sticky", "breakable",
)

// 样式值在合并前校验，避免拼错键名或把字符串 `"center"` 当作 Typst alignment。

#let _line-spacing-ok(v) = (
  v in ("single", "double")
    or type(v) in (int, float)
    or type(v) == length
    or (type(v) == dictionary and v.keys().len() == 1 and (
      "exactly" in v or "at-least" in v
    ))
)

// line-spacing-auto：这一条的行距收不收 auto；只有基准表里本来就写 auto 的那几条收（模板自己按别的条件解），别的条写 auto 没有解法，当场报错。
// 子记录：基准表里值是样式记录（有样式键，或空）或记录的记录（值全是字典）的键——figure.image、theorem.head……
// 形状由基准表定，用户只能写基准表里有的子键；子记录各自再按样式验。值是长度字典的（模板自己的
// inset: (x:, y:) 之类）不算子记录，原样放过、归模板验
#let is-record(v) = type(v) == dictionary and (
  v.len() == 0 or v.keys().any(k => k in style-keys) or v.values().all(x => type(x) == dictionary)
)
#let _sub-keys(base) = if base == none { () } else {
  base.pairs().filter(((k, v)) => k not in style-keys and is-record(v)).map(((k, v)) => k)
}

// lenient：拿不到基准表时（局部样式）只验样式键，别的键放过、字典往里再验
#let validate-style(entry, name, line-spacing-auto: false, base: none, lenient: false) = {
  if type(entry) != dictionary {
    panic(name + ": expected a dictionary, found " + repr(entry))
  }
  let subs = _sub-keys(base)
  for (key, v) in entry {
    if key not in style-keys and key in subs {
      validate-style(
        v, name + "." + key, base: base.at(key),
        line-spacing-auto: base.at(key).at("line-spacing", default: none) == auto,
      )
      continue
    }
    // 模板自己的键（基准表里有、又不是样式键，如表格的 inset、stroke）：原样放过，归模板验
    if key not in style-keys and base != none and key in base { continue }
    if subs.len() > 0 and key not in style-keys {
      panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(subs, key))
    }
    if key not in style-keys and lenient {
      if type(v) == dictionary { validate-style(v, name + "." + key, lenient: true) }
      continue
    }
    if key not in style-keys {
      panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(style-keys, key))
    }
    let where = name + "." + key + ": "
    if key == "asian-font" and v not in zh-roles {
      panic(where + _errors.expected-one-of(zh-roles, v))
    } else if key == "latin-font" and v not in en-roles {
      panic(where + _errors.expected-one-of(en-roles, v))
    } else if key == "size" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length such as zihao.xiaosi or 12pt, found " + repr(v))
    } else if key in ("bold", "latin-bold", "snap-to-grid", "justify", "pagebreak-before", "sticky", "breakable") and type(v) != bool {
      panic(where + "expected true or false, found " + repr(v))
    } else if key == "tracking" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length (Word's character spacing, in pt), found " + repr(v))
    } else if key == "line-spacing" and not (_line-spacing-ok(v) or (line-spacing-auto and v == auto)) {
      panic(
        where + "expected \"single\", \"double\", a number, a length, or a dictionary with "
          + "\"exactly\" or \"at-least\""
          + (if line-spacing-auto { ", or auto (this style resolves it by itself)" } else { "" })
          + ", found " + repr(v),
      )
    } else if key in ("above", "below") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))
    ) {
      panic(where + "expected length or dictionary with \"lines\", found " + repr(v))
    } else if key in ("first-line-indent", "hanging-indent", "left-indent") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("chars",))
    ) {
      panic(where + "expected length or dictionary with \"chars\", found " + repr(v))
    } else if key == "align" and type(v) != alignment {
      panic(where + "expected alignment (left, center, or right), found " + repr(v))
    }
  }
}

#import "./state.typ": styles-state, local-styles, current-styles, merge-local

// 局部样式通过 styles/state.typ 的栈生效；离开 show 作用域后自动恢复。这里拿不到基准表，只验样式键，
// 按形状并在 state.typ 里做；只有 body 会就地重装，别的条目由读它的模板自己在排的时候取
#let check-local(local) = {
  if type(local) != dictionary {
    panic("new-styles: expected a dictionary (the same shape as document(styles:)), found " + repr(local))
  }
  for (name, entry) in local {
    if type(entry) != dictionary { panic("new-styles: " + name + ": expected a dictionary, found " + repr(entry)) }
    validate-style(entry, "styles." + name, lenient: true)
  }
}

/// 校验并合并基准样式、模板预设与用户覆盖，优先级为 `base < preset < local`。
/// 每条同名样式逐键合并，不会因局部覆盖而丢掉模板中的其余属性。
///
/// `body` 是必需样式，别的条目叫什么、怎么分由上层模板定。哪些条目带子记录由基准表的形状决定
/// （值是样式记录或记录的记录，如 `theorem: (head: …, body: …)`）；基准表里模板自己的键（如表格的
/// `inset`、`stroke`）banshi 不认识，原样放过，由模板验。
///
/// ```typ
/// #let resolved = styles(
///   (body: (size: 12pt, line-spacing: 1.25)),
///   (body: (first-line-indent: (chars: 2), justify: true)),
/// )
/// ```
/// -> dictionary
#let styles(base, local, preset: (:)) = {
  if type(local) != dictionary {
    panic("styles: expected a dictionary, found " + repr(local))
  }
  // 子记录逐键合并，别的键整个盖过去
  let join(base, entry) = {
    let out = base + entry
    for key in _sub-keys(base) {
      if key in entry { out.insert(key, base.at(key) + entry.at(key)) }
    }
    out
  }
  let merged = base
  for (name, entry) in preset { merged.insert(name, join(merged.at(name), entry)) }
  for (name, entry) in local {
    if name not in base {
      panic(
        "styles: unknown style \"" + name + "\"; "
          + _errors.expected-one-of(base.keys(), name),
      )
    }
    validate-style(
      entry, "styles." + name, base: base.at(name),
      line-spacing-auto: base.at(name).at("line-spacing", default: none) == auto,
    )
    merged.insert(name, join(merged.at(name), entry))
  }
  merged
}
