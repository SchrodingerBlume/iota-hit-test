// 文档级样式存于 state；局部样式以栈记录，离开 show 作用域后恢复。
#let styles-state = state("banshi-styles", none)
#let local-styles = state("banshi-local-styles", ())

// 当前仅允许局部覆盖 `body` 与 `figure.table`。
#let merge-local(cur, local) = {
  let merged = cur
  if "body" in local { merged.insert("body", cur.body + local.body) }
  if "figure" in local {
    merged.insert("figure", cur.figure + (table: cur.figure.table + local.figure.table))
  }
  merged
}

/// 读取合并后的当前样式表。必须在 context 中调用。
/// -> dictionary
#let current-styles(default: none) = {
  let document = styles-state.get()
  if document == none {
    document = default
    if document == none { panic("no styles in effect: the document-level styles have not been set (banshi.styles.styles-state)") }
  }
  let s = document
  for local in local-styles.get() {
    s = if local == none { document } else { merge-local(s, local) }
  }
  s
}

// `current` 为真时读取局部覆盖后的正文样式，否则使用调用方提供的样式。
#let style-of(style, current) = if current { current-styles().body } else { style }
