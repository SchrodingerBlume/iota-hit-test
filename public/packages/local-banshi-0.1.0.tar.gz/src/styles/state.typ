// 样式表的 state。iota-hit 把文档级那一份写进 styles-state；局部的 new-styles 不改它，
// 往 local-styles 这个*栈*上压一份（出作用域弹掉），谁要「当前生效的样式表」就调 current-styles()
// ——文档级那份逐个并上栈里的局部字典。目录（toc-1/2/3/4）、正文那一档的 show 规则（西文 run、
// 纯西文段）、表格、成果页都在各自的 context 里这么读，局部改了行距、缩进才跟得上。
//
// *为什么是栈不是「读一下、改一下、出作用域改回去」*：那种写法要在同一个 context 里读自己
// 将要 update 的 state，探针（metadata）的落点又按同形元素编号，三个一模一样的局部作用域在
// context 里外会错位，实测五轮不收敛。压栈弹栈只发 update(f)，一个字不读。
//
// *单独成一个文件，只为断开一个环*：sheet.typ 要用 styles/rules.typ 的换算，而 rules.typ
// 与 paragraph/latin.typ 的规则又要读这里。与 src/layout/state.typ 同一条理由。
// 文档级那一份由模板在文档开头写（iota-hit 的 sheet.styles-state.update），写之前读到的是 none
#let styles-state = state("banshi-styles", none)
#let local-styles = state("banshi-local-styles", ())

// 一份局部字典并到样式表上：body 整条并，figure 只并 table 那一格（眼下只接了这两个键，
// 验键在 sheet.typ 的 check-local）
#let merge-local(cur, local) = {
  let merged = cur
  if "body" in local { merged.insert("body", cur.body + local.body) }
  if "figure" in local {
    merged.insert("figure", cur.figure + (table: cur.figure.table + local.figure.table))
  }
  merged
}

// 当前生效的样式表。栈里的 none 是 restore-styles 压的：从它起回到文档级那份。*要在 context 里调*。
// default 是「没进过文档级 show 时按哪张表」（对拍件直接调页函数那条路），不给就报错，
// 不静默按某一档排；模板自己那份带默认的包装在 iota-hit/src/styles/lookup.typ
#let current-styles(default: none) = {
  let document = styles-state.get()
  if document == none {
    document = default
    if document == none { panic("no styles in effect: the document-level styles have not been set (banshi.styles.styles-state)") }
  }
  let s = document
  for local in local-styles.get() {
    s = if local == none { document } else { merge-local(s, local) }
  }
  s
}

// 同一件事的样式那一半：正文那一档（current 开着）的规则从 styles-state 现取 body——局部
// new-styles 改了行距、缩进，规则里的行高与字距才跟得上；部件层照旧用装规则时那一份。
// *要在 context 里调*
#let style-of(style, current) = if current { current-styles().body } else { style }
