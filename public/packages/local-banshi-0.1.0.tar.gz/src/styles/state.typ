// 文档级样式存于 state；局部样式以栈记录，离开 show 作用域后恢复。
#let styles-state = state("banshi-styles", none)
#let local-styles = state("banshi-local-styles", ())

// 局部样式按基准表的形状并：样式记录逐键盖；记录的记录（figure: (table: …)）逐条再并
#let _merge(c, l) = if type(c) == dictionary and c.len() > 0 and c.values().all(x => type(x) == dictionary) {
  let out = c
  for (k, v) in l { out.insert(k, if k in c { _merge(c.at(k), v) } else { v }) }
  out
} else { c + l }
#let merge-local(cur, local) = {
  let merged = cur
  for (name, entry) in local { merged.insert(name, if name in cur { _merge(cur.at(name), entry) } else { entry }) }
  merged
}

/// 读取合并后的当前样式表。必须在 context 中调用。
/// -> dictionary
#let current-styles(default: none) = {
  let document = styles-state.get()
  if document == none {
    document = default
    if document == none { panic("no styles in effect: the document-level styles have not been set (banshi.styles.styles-state)") }
  }
  let s = document
  for local in local-styles.get() {
    s = if local == none { document } else { merge-local(s, local) }
  }
  s
}

// 选择规则使用的正文样式：`current` 为真时读取局部覆盖后的当前样式，否则返回传入的 `style`。
// 必须在 context 中调用。
// -> dictionary
#let style-of(style, current) = if current { current-styles().body } else { style }
