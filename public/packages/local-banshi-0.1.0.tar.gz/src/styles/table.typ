// 将 Word 表格的行高、单元格边距和三线表边框映射到 Typst table。
#import "../paragraph/spacing.typ": spacing
#import "../units.typ": twips
#import "../layout/resolve.typ" as _layout
#import "./rules.typ" as style-rules
#import "./state.typ" as _state

// 表格行高取当前节的文档网格行距；线宽与单元格边距来自 `figure.table` 样式。
// 本科范例第 12 页所在节的网格为 383 twips（19.15pt）：五号单倍行高 13.617pt
// 在网格行中居中后，首基线约为 (19.15−13.617)/2+10.66=13.43pt，PDF 量得
// 13.50pt。由此可知上下留白就是“网格行距减行高后平分”，无需再保存常数。
// 该页来自单独拷入的 FLUENT 章节，只有这一节使用 19.15pt；普通正文节是
// 391 twips（19.55pt），所以实现必须读取当前节，不能把 19.15pt 写死。

/// 读取当前生效的表格样式，`inset` 统一为 `(x:, y:)`；未写时取 Word 的默认单元格边距。
/// 必须在 context 中调用。
/// -> dictionary
#let table-style() = {
  let ts = _state.current-styles().figure.table
  // 没写就是 Word 的默认单元格边距：左右 0.19cm（108 缇）、上下 0
  let inset = ts.at("inset", default: (x: twips(0.19cm), y: 0pt))
  let inset = if type(inset) == length { (x: inset, y: inset) } else {
    (x: inset.at("x", default: 0pt), y: inset.at("y", default: 0pt))
  }
  ts + (inset: inset)
}

/// 由表格样式生成单元格段落样式：去掉边框、边距与空当，字号换成 `size`。
/// -> dictionary
#let cell-style(ts, size) = {
  let st = ts
  for k in ("above", "gap", "below", "inset", "stroke") { let _ = st.remove(k, default: none) }
  st + (size: size)
}

// Typst 自己的默认值。用来分辨「用户显式写的」与「没写」；fields()两者都给得出来，只有拿默认值比对能分开。
#let typst-default-inset = 0% + 5pt

// 重建出来的表再次命中 `show table` 时靠它放行；内层写恒等 show 规则拦不住（maximum show rule depth exceeded）。
/// 放进任一格里，这张表就不按 Word 重建（表单那类不是数据表的用它）；`table-rules`
/// 重建出来的表也带着它，据此识别自己的输出、避免递归。
/// -> content
#let verbatim-mark = metadata((banshi-table-built: true))

#let built(c) = {
  if type(c) != content { return false }
  if c.func() == metadata {
    return type(c.value) == dictionary and "banshi-table-built" in c.value
  }
  if c.has("children") {
    for k in c.children { if built(k) { return true } }
  }
  if c.has("body") { return built(c.body) }
  false
}

// 单元格是单倍行距，不是题注那一档的 1.25。另用 Word 在同一节生成的 docx
// 探针核过：正文汉字、正文纯西文约为 19.44/19.68pt，表格内的汉字、纯西文和
// 混排则全部为 19.68pt，即一个网格行。因此表格中的纯西文行不得切换为西文行高。
// 边框：Word“边框和底纹”里的几条——外框四边（top / bottom / left / right）、内部横线
// （inside-h）、内部竖线（inside-v），外加表头行下边线（header，三线表用）。样式没写就是
// Word 插入表格的默认：网格型，全部 0.5pt（w:sz=4）；写了字典就只有写到的边，没写的边无线；
// 写一个长度是四边与内部都用它。
#let borders = ("top", "bottom", "left", "right", "inside-h", "inside-v", "header")
#let word-grid = borders.map(k => (k, 0.5pt)).to-dict()
#let _borders(value) = {
  if value == none or value == auto { return word-grid }
  if type(value) == length { return borders.map(k => (k, value)).to-dict() }
  borders.map(k => (k, value.at(k, default: none))).to-dict()
}
#let _t(v) = if v == none { 0pt } else { v }

// 单元格 (x, y) 四边挨着哪条线
#let _edges(b, n, off, header-rows, last) = (x, y) => (
  top: if y == off { b.top } else if header-rows > 0 and y == off + header-rows { b.header } else { b.inside-h },
  bottom: if y == last { b.bottom } else if header-rows > 0 and y == off + header-rows - 1 { b.header } else { b.inside-h },
  left: if x == 0 { b.left } else { b.inside-v },
  right: if x == n - 1 { b.right } else { b.inside-v },
)

// 边距从线的内沿量：Word 的线占自己的厚度，Typst 把线画在格子边界正中，所以挨着线的
// 那一边各垫半条线。
#let cell-inset(margin, b, n, off, header-rows, last) = {
  let side(keys) = if type(margin) == length { margin } else {
    let hit = keys.find(k => k in margin)
    if hit == none { margin.at("rest", default: 0pt) } else { margin.at(hit) }
  }
  let mx = side(("x", "left", "right"))
  let my = side(("y", "top", "bottom"))
  let edges = _edges(b, n, off, header-rows, last)
  (x, y) => {
    let e = edges(x, y)
    (left: mx + _t(e.left) / 2, right: mx + _t(e.right) / 2, top: my + _t(e.top) / 2, bottom: my + _t(e.bottom) / 2)
  }
}

/// 将作用域内的 Typst `table` 重建为 Word 风格表格：字号和行高取当前表格样式，
/// 单元格按文档网格居中，边距从边线内沿计算，边框按 `figure.table.stroke` 生成。
///
/// `header-rows` 是 `table.header` 中属于表头的行数，用于画表头下边线。`note` 是
/// `(metrics, top-stroke) => content` 函数，其结果插入重复表头最上方，可用于续页的
/// “表 N-N（续表）”。没有 `table.header` 时会添加一个只含内部标记的重复表头。
///
/// 原生 `stroke` 或 `inset` 会覆盖样式表对应值。表单、布局表等不应按数据表重建时，
/// 在任一单元格放入 `verbatim-mark`。
///
/// ```typ
/// #show: table-rules
/// #table(
///   columns: 3,
///   table.header([名称], [符号], [单位]),
///   [速度], [$v$], [m/s],
/// )
/// ```
/// -> content
#let table-rules(header-rows: 1, note: none, doc) = {
  show table: it => context {
    if built(it) { return it }
    let layout = _layout.current-page-setup()
    let ts = table-style()
    let cell = cell-style(ts, text.size)
    let b = _borders(ts.at("stroke", default: auto))
    let m = spacing(cell, layout: layout)
    let f = it.fields()
    let kids = f.remove("children")
    let raw-stroke = f.remove("stroke", default: none)
    let raw-inset = f.remove("inset", default: none)
    let raw-align = f.remove("align", default: auto)
    let stroke-untouched = (
      type(raw-stroke) == stroke
        and raw-stroke.thickness == auto
        and raw-stroke.paint == auto
    )
    let inset-untouched = raw-inset == typst-default-inset
    let margin = if not inset-untouched { raw-inset }
      else if table.inset != typst-default-inset { table.inset }
      else { ts.inset }
    let cols = f.at("columns", default: 1)
    let n = if type(cols) == int { calc.max(cols, 1) } else if type(cols) == array {
      calc.max(cols.len(), 1)
    } else { 1 }
    let has-header = kids.any(k => k.func() == table.header)
    let mark-cell = table.cell(
      colspan: n, stroke: none, inset: (bottom: _t(b.top) / 2, rest: 0pt),
      verbatim-mark + (if note != none { note(m, _t(b.top)) }),
    )
    let kids = if not has-header {
      (table.header(mark-cell), ..kids)
    } else {
      kids.map(k => if k.func() != table.header { k } else {
        table.header(
          mark-cell, ..k.fields().children,
          repeat: k.at("repeat", default: true),
          level: k.at("level", default: 1),
        )
      })
    }
    let off = 1
    let f = {
      let rs = f.at("rows", default: ())
      if type(rs) != array or rs.len() == 0 { f } else { f + (rows: (auto, ..rs)) }
    }
    let header-rows = if has-header { header-rows } else { 0 }
    let slots(k) = if k.func() == table.cell {
      k.at("colspan", default: 1) * k.at("rowspan", default: 1)
    } else if k.func() == table.header {
      k.fields().children.filter(c => c != mark-cell).map(slots).sum(default: 0)
    } else if k.func() in (table.hline, table.vline) { 0 } else { 1 }
    let last = off + calc.ceil(kids.map(slots).sum(default: 0) / n) - 1
    let inset = cell-inset(margin, b, n, off, header-rows, last)
    // 底线追加成 hline：stroke 闭包只对真实存在的格子调用，拿不到总行数；不带 y 的 hline 落在
    // 最后一格之后，长表跨页也只出现在末页
    let kids = if stroke-untouched and b.bottom != none { kids + (table.hline(stroke: b.bottom),) } else { kids }
    let built = {
      show: style-rules.rules.with(cell, layout: layout)
      set table(
        align: if raw-align == auto { center } else { raw-align },
        inset: inset,
        // 每条线只由一侧的格子画：横线归下面那一格的 top（表头下线归表头行的 bottom——跨页
        // 时重复出来的表头 y 仍是 0，画在它自己的下边才跟得上），竖线归左边那一格的 right、
        // 首列的 left；底线是上面追加的 hline
        stroke: if not stroke-untouched { raw-stroke } else { (x, y) => {
          let e = _edges(b, n, off, header-rows, last)(x, y)
          (
            top: if y == off { e.top } else if header-rows > 0 and y == off + header-rows { none } else { e.top },
            bottom: if header-rows > 0 and y == off + header-rows - 1 { b.header } else { none },
            left: if x == 0 { e.left } else { none },
            right: e.right,
          )
        } },
      )
      table(..f, ..kids)
    }
    let built = if stroke-untouched { pad(bottom: _t(b.bottom) / 2, built) } else { built }
    let over = measure(built).width - layout.text-width
    if over > 0.05pt { pad(x: -over / 2, built) } else { built }
  }
  doc
}
