// Word 的表格模型接到 Typst 的 table 上：单元格的行盒是一个网格行、内边距从线的内沿量
// （挨线的边补半条线）、内容居中、比版心宽的表居中、表头首行注一格每页重算的内容。
// 三条线的粗细与内边距的数住样式表（figure.table），线是哪三条、注的那一格印什么由模板给
// （iota-hit 的三线表与「（续表）」在 iota-hit/src/figure/kinds/table.typ）。
#import "../layout/resolve.typ" as _layout
#import "./rules.typ" as style-rules
#import "./state.typ" as _state
#import "../paragraph/linebox.typ" as linebox

// 数据行：*行高就是文档网格的行距，行盒在行里垂直居中*。
//
// 实测本科范例第 12 页那张表（trace 读三条线，stext 读基线）：
//
//   顶线 327.35–328.85（1.5）  表头下 386.12–387.12（1.0）  底线 521.40–522.90（1.5）
//   数据基线 400.62 … 515.65，七行六步共 115.03，一步 19.17
//   行高 = (521.40 − 387.12) / 7 = 19.18
//   首基线距行顶 = 400.62 − 387.12 = 13.50
//
// 那一节（第 4～6 章，拷贝进来的 FLUENT）的 docGrid 是 linePitch=383，也就是
// 19.15 磅——步进与行高都是它。而 13.50 由模型算得出来：五号行盒 1.296875 × 10.5
// = 13.617 在 19.15 的行里居中，上留 (19.15 − 13.617) / 2 = 2.77，基线 = 2.77 +
// 上升部 10.66 = 13.43，与量到的 13.50 差 0.07。
//
// 所以两个内边距都是 (网格行距 − 行盒高) / 2，*一个常数都不用存*。终稿默认
// 的跨度是 391 缇 ＝ 19.55（见 iota-hit/src/layout/presets.typ），表在正文里排出来的行高就是
// 19.55、首基线距行顶 13.63——范例那张表落在 383 的节里才是 19.15，规则不变。
//
// *先前这里存过 13.98 / 19.24*，还写着一段「为什么不是上下对称」——那是
// 当初把行高当成了 15.84（行盒加两个 1.11）才得出的结论；行高取网格的 19.15
// 之后，对称居中恰好就是对的。
//
// 横向那一份是读出来的：范例的表没写 tblCellMar，用的是 styles.xml 里
// docDefaults 那一份——上下 0、左右各 0.19 厘米（「表格属性 → 单元格边距」上
// 就是这么显示的，存进 docx 是 108 缇）。
// *数住样式表*（模板的表格那一档，iota-hit 的在 iota-hit/src/styles/presets.typ 的 _table，Word 那张
// 「表格」卡），排的时候读当前那一份（style），局部 #show: new-styles.with(…) 改得动

// 当前生效的表格那一档样式（文档级并过局部的），inset 折成 (x:, y:) 字典。*要在 context 里调*。
// 单元格里的段落属性（字号、行距、贴格、缩进）从这一份取，字号由 show table: set text(size:)
// 那条 show-set 给、用户就地 set 的压过它，所以排格子时字号读样式链、不读这里
#let table-style() = {
  let ts = _state.current-styles().figure.table
  let inset = ts.inset
  let inset = if type(inset) == length { (x: inset, y: inset) } else {
    (x: inset.at("x", default: 0pt), y: inset.at("y", default: 0pt))
  }
  ts + (inset: inset)
}
// 格子那一档的段落样式：表格那一档去掉不是段属性的键，字号按样式链上当前的

// 格子那一档的段落样式：表格那一档去掉不是段属性的键，字号按样式链上当前的
#let cell-style(ts, size) = {
  let st = ts
  for k in ("above", "gap", "below", "inset", "stroke") { let _ = st.remove(k, default: none) }
  st + (size: size)
}

// Typst 自己的默认值。*用来分辨「用户显式写的」与「没写」*——fields()
// 两者都给得出来，只有拿默认值比对能分开。见 show table 那一段。
// Typst 没被碰过时 inset 的样子。stroke 那一档比不了相等，判结构，见 show table
#let typst-default-inset = 0% + 5pt

// 重造过的表自带这个记号，见下面 show table 那一段的说明
#let built-mark = metadata((banshi-table-built: true))

#let built(c) = {
  if type(c) != content { return false }
  if c.func() == metadata {
    return type(c.value) == dictionary and "banshi-table-built" in c.value
  }
  if c.has("children") {
    for k in c.children { if built(k) { return true } }
  }
  if c.has("body") { return built(c.body) }
  false
}

// *单元格是单倍行距，不是题注那一档的 1.25。* 六张三线表（本科范例三张、
// 博士范例三张）的单元格段落一个 w:line 都没写，也就是单倍。
//
// *而且对齐到文档网格：格里*每一行*都占一个网格行。* 那六张表的单元格
// 段落也一个 snapToGrid 都没写——Word 的默认就是对齐，所以格内折行与整行同待遇。
// 逐条量过（本科范例表6-1，那一节的网格是 383 ＝ 19.15）：数据行之间 19.08–19.20，
// 表头那一格自己折的三行（「流量修正值」／「M (m³/s)」／「×10⁻⁴」）也是 19.08、
// 19.20，与数据行一模一样。
//
// *西文行不例外。* 那三行里第二行「M (m³/s) lgΔP lg M」通篇没有汉字，照样
// 是一个网格行。中文档里「纯西文段走自然行高」那一条（src/styles/body.typ 的
// show par）不适用于格里——那一条的出处（英文摘要、英文题注、英文版表格）在范例里
// 每一处都写着 snapToGrid=0 或非单倍行距，是段落上的显式设定，不是 Word 按脚本判的。
// 自造探针核实过：拿范例 d-stem.docx 本身追加一页（同一节、同一份 Normal），Word
// 导出实测正文汉字 19.44/19.68、正文纯西文 19.44/19.68、格内汉字 19.68、格内纯西文
// 19.68、混排 19.68——都是一个网格行。
//
// *范例里 19.15 那个数不跟*：它是那一节的 w:docGrid linePitch=383，两份范例
// 各十一节里只有放这张表的那一节是 383，其余 391（19.55）。要跟的是「每行一个
// 网格行」这条规矩，落到我们的网格上就是 19.55。
//
// *行距按网格开关分两档。* 贴网格那一档设*单倍*——范例那几格的
// pPr 里一个 w:line 都没写，走 Normal 的单倍，再由网格撑成一个网格行；倍数
// 在贴网格时乘的是*网格行*（写 1.25 排出来是 24.44，不是 19.55）。
//
// *网格不启用的那一档就差在这儿*：深圳本科那两份报告的 docGrid 没有
// w:type、单元格还显式写着 <w:snapToGrid w:val="0"/>，没有网格行可贴，行盒
// 只能按行距算——原件那几格写的正是 <w:spacing w:line="300"/> ＝ 1.25 倍，
// 与题注那一档同数，所以跟着 style 走（用户改 styles.figure.caption 也一并跟上）。
// 写死单倍的话那一档会塌成 13.62。
//
// *以上是标定的记录；数现在住在 styles.figure.table（iota-hit/src/styles/presets.typ 的 _table）*：
// 单倍贴格是那一档的默认，网格不启用的那几档在 variant-styles 里写 1.25。排格子时读
// 当前那一份（style），文档级 iota-hit(styles:) 与局部 #show: new-styles.with(…) 都改得动
// *纵向内边距只有线的那一半，而且只在挨着线的那一边。* 贴网格之后行盒自己就是
// 一个网格行、自然行盒在里面居中（见 src/paragraph/linebox.typ 的 _ascent-of），垫的活儿
// 都在行盒里；剩下的是 *Word 的线占自己的厚度*：格子的内容框从线的内沿起排，
// Typst 把线画在格子边界的正中——所以挨着线的那一边各垫半条线，不挨线的边是 0。
// 三条线各自算：顶线垫在首行的上边、表头线垫在表头行的下边与首个数据行的上边、
// 底线垫在末行的下边；顶线与底线探出表外的那一半由 pad 补（见下面 built）。
//
// 两份 Word 排的表都对得上：
//
//   本科范例 p15（贴网格 383 ＝ 19.15，线 1.5 / 1 / 1.5）：表题基线 → 顶线心 7.22
//   ＝ 五号 1.25 倍的行深 6.44 ＋ 0.75；三行的表头 58.80 ＝ 0.75 ＋ 3 × 19.15 ＋ 0.5；
//   末行基线 → 底线心 6.44 ＝ 格内居中的下半 5.80 ＋ 0.75（p16）
//   深圳本科中期表 2-1（不贴网格，三条都 1.5）：表头线心 → 首行基线 12.96
//   ＝ 0.75 ＋ 上升部 12.1；末行基线 → 底线心 8.16 ＝ 行深 7.35 ＋ 0.75
//
// 先前上边 +半条、下边 −半条，行高不变、线心落在内容框顶上：一张表比 Word 矮
// 「三条线之和」（2.5～3pt），后面的标题跟着高。
//
// *用户写的 inset 也当 Word 的边距收*（元素上的 table(inset:)、或 show table: set
// table(inset:)）：他抄的是表格属性对话框上的数，从线内沿量，挨线的半条线照补。先前
// 原样用，比 Word 少半条线
// 边距收长度或字典；fields() 里用户写的 (x: 1cm) 已被 Typst 摊成 left / right / top / bottom
// （实测），这几种拼法都认。*左右一份、上下一份*：Word 的边距就这两栏
#let cell-inset(margin, strokes, off, header-rows, last) = {
  let side(keys) = if type(margin) == length { margin } else {
    let hit = keys.find(k => k in margin)
    if hit == none { margin.at("rest", default: 0pt) } else { margin.at(hit) }
  }
  let mx = side(("x", "left", "right"))
  let my = side(("y", "top", "bottom"))
  (x, y) => (
    x: mx,
    top: my + (if y == off { strokes.top / 2 }
      else if header-rows > 0 and y == off + header-rows { strokes.header / 2 }
      else { 0pt }),
    bottom: my + (if off <= y and y < off + header-rows { strokes.header / 2 }
      else if y == last { strokes.bottom / 2 }
      else { 0pt }),
  )
}

// ── 接到 table 上：三线表重建、比版心宽的居中、表头里每页重算的那一格 ────────────
// header-rows 表头占几行（格里的字号从样式链读，题注那一档的 style 用不着）。note 是注进
// 表头首行的那一格里的内容闭包 (metrics, top-rule) => content，每页重算一次——续排页上的
// 「表N-N（续表）」就是这么来的（模板给，见 iota-hit/src/figure/kinds/table.typ）；none ＝ 那一格是空的
#let table-rules(header-rows: 1, note: none, doc) = {
  // 三线表，外加表头里那一格*每页重算*。
  //
  // 顶线与表头线走 stroke 闭包；*底线是追加在末尾的 table.hline*——那个闭包只对
  // 真实存在的格子调用（y 取 0..行数−1），拿不到总行数，实测让它对 y == 行数
  // 返回线宽什么也不画；不带 y 的 hline 落在它所在的位置，摆在最后一格之后就是
  // 表底，长表跨页也只出现在末页。*先前是在表外面包一个 block 画下边*：块在流里
  // 取版心宽，表比版心宽（深圳本科英文中期原件那张表列宽加起来 15.11cm，版心
  // 15.0cm）时底线就比顶线短一截。表头下那条画成*表头行的下边*而不是首个数据行的
  // 上边：跨页时 Typst 重复 table.header，重复出来的那份 y 仍是 0，画上边线跟
  // 得上；而首个数据行留在前一页，画它的上边线在续页就没了（实测续页只有顶线
  // 与底线，缺那条 0.5）。
  //
  // *比版心宽的表居中*，照 Word：表单里那张表 w:jc="center"，排出来两边各探出
  // 1.5（83.52–511.68 对版心 85.05–510.23）；Typst 把超宽的块顶在左边、全探到右边。
  // 用负的左右 pad 把容器撑到表那么宽，表就落在正中。列宽有 auto／fr 的表撑不
  // 过版心，量出来不比版心宽，这一支不走。
  //
  // *「（续表）」这一行是往 table.header 里注入的。* 指南 2.12 要求转页时
  // 「表右上角注明编号，编号后加『（续表）』，并重复表头」——重复表头 Typst 自己
  // 会做，那一行标注它没有钩子。办法是插一格跨列、右对齐、无边线的内容，里面
  // 放一个 context：*实测重复出来的表头里 context 会按页重算*（同一个探针
  // 在第 1/2/3 页分别报 1/2/3），所以它能自己判断「这一页不是表的起始页」。
  //
  // *这是全项目唯一一处重造用户的元素。* 别处的 show 规则都只设属性。
  // 重造要防递归：新建的 table 会再次命中这条规则，而内层写一条 identity 的
  // show 规则*拦不住*（实测 maximum show rule depth exceeded）。改成让它
  // *自识别*——注入的那一格里埋一个 metadata，再进来看见就原样放行。
  //
  // *用户显式写的 stroke / inset 要留住。* 重建把它们一并丢弃过——实测
  // 写了 inset 也毫无效果。fields() 分不出「用户写的」与「没写」，只能拿 Typst
  // 的默认值比对：没人会去显式写一个与默认一模一样的值。
  //
  // *stroke 不能用相等比。* 实测默认那一个与 1pt + black *既不 ==
  // 也不 repr 相同*，虽然打印出来一模一样。能分的是结构：没被碰过的 stroke，
  // thickness 与 paint 都是 auto；用户写 0.4pt 的那个 thickness 就是 0.4pt。
  show table: it => context {
    if built(it) { return it }
    let layout = _layout.current-page-setup()
    // 格里的字号读样式链：iota-hit/lib.typ 那句 show table: set text(size:) 给的默认（表格样式的
    // 五号），用户就地 show table: set text(size: …) 压过它。字体同理，这里不 set
    let ts = table-style()
    let cell = cell-style(ts, text.size)
    let strokes = ts.stroke
    let m = linebox.metrics(cell, layout: layout)
    let f = it.fields()
    let kids = f.remove("children")
    // fields() 给的是「显式值或 Typst 默认值」，不含 set 规则的值——实测重建后
    // inset 回到 5pt（Typst 的默认）而不是我们 set 的 1.11，..f 展开时会盖过
    // 下面的 set。所以这两项先摘出来，判过是不是默认再决定用谁的。
    let raw-stroke = f.remove("stroke", default: none)
    let raw-inset = f.remove("inset", default: none)
    let raw-align = f.remove("align", default: auto)
    let stroke-untouched = (
      type(raw-stroke) == stroke
        and raw-stroke.thickness == auto
        and raw-stroke.paint == auto
    )
    // 边距三处来源：元素上写的、show table: set table(inset:) 写的（读样式链）、表格样式
    // 里的，前面的压后面的，都当 Word 的边距
    let inset-untouched = raw-inset == typst-default-inset
    let margin = if not inset-untouched { raw-inset }
      else if table.inset != typst-default-inset { table.inset }
      else { ts.inset }
    // *不写 columns 的表列数是 1。* 那个字段*总是在*，没写时是空数组
    // ——default: 1 永远走不到，空数组的 len() 是 0，注入格 colspan: 0 当场报
    // 「number must be positive」，而 #table([甲], [乙]) 在 Typst 原生是合法的单列表
    let cols = f.at("columns", default: 1)
    let n = if type(cols) == int { calc.max(cols, 1) } else if type(cols) == array {
      calc.max(cols.len(), 1)
    } else { 1 }
    let has-header = kids.any(k => k.func() == table.header)
    // 注入的那一格。*记号要在 context 外面*——built 走的是 children /
    // body，钻不进 context 元素里，塞进去就自识别不出来，当场无限递归。
    // *内边距要清零*：起始页那一格是空的，留着内边距会让它照样占一行高
    // ——实测同一份长表从 2 页涨到 4 页，起始页表头上方还多出一道空隙。
    // 续排页要的那点间距由 note 的内容自己发。
    // *下边垫顶线的那一半*：顶线画在这一格与首行的边界正中，Word 里线整条在表里、
    // 标注段落的底就是线的上沿（本科范例 p16：标注基线 → 顶线心 6.52 ＝ 网格行里
    // 居中的下半 5.80 ＋ 0.75）。起始页这一格是空的，垫的这半条就是顶线探出表外的那一半
    let mark-cell = table.cell(
      colspan: n, stroke: none, inset: (bottom: strokes.top / 2, rest: 0pt),
      built-mark + (if note != none { note(m, strokes.top) }),
    )
    // *没写 table.header 的表也注入一个*，里面只装那一格。两个理由：
    //
    // 一、指南 2.12 说转页时「表右上角注明编号，编号后加『（续表）』，并重复表
    // 头」——前半句*不以有没有表头为条件*，没有表头的长表转页照样要标。
    //
    // 二、这是*递归的出口*。重建出来的表靠注入格里的 built-mark 自识别，
    // 先前没有表头就什么都不注入，重建出来的表再次命中这条规则——*一张不带
    // table.header 的表根本编译不了*（maximum show rule depth exceeded）。
    let kids = if not has-header {
      (table.header(mark-cell), ..kids)
    } else {
      kids.map(k => if k.func() != table.header { k } else {
        // *repeat 与 level 要一起搬过去。* 只搬 children 的话
        // table.header(repeat: false) 被静默丢掉——实测 60 行的长表跨三页，
        // 写了 repeat: false 表头照样每页重复。别处（figure.caption.separator、
        // figure.numbering）遇到没法兑现的写法是当场 panic，这一处不该一声不响
        table.header(
          mark-cell, ..k.fields().children,
          repeat: k.at("repeat", default: true),
          level: k.at("level", default: 1),
        )
      })
    }
    // 注入那一行占了 y == 0，三条线的位置整体后移一格
    let off = 1
    // *注入那一行也得给个高*，不然它跟着吃用户写的 rows:——`rows: 100pt`
    // 的表在表头之上凭空多出 100pt（实测题注基线到顶线 106.35，该是 6.35；
    // `rows: 30pt` 那份是 36.36）。
    //
    // track 的写法是「给的不够就重复最后一个」（实测 rows: (0pt, 30pt) 排五行
    // 得 0/30/30/30/30），所以在前面补*一格*就正好，后面几行照旧。
    //
    // *补的那一格写 auto，不写 0pt。* 它两页上的高本来就该不同：首页那一格是空的，
    // auto 给的就是 0（`rows: 100pt` 那个毛病不会回来，实测题注到表头 21.5）；续页
    // 标注一印，auto 给的是标注的自然高。先前写死 0pt，续页那一页整个错位——标注
    // 与表头只差 0.7（该差 21.0，字叠在一起）、顶线被顶到版心顶 107.75（该在 128.05），
    // 与页眉那条双线（97.72／100.72）之间只剩 7pt，看着就是表框贴着页眉。
    //
    // *没写 rows 时 fields() 交回的是空数组，不是 auto*（实测；写了
    // rows: 30pt 交回的也已经是数组 (30pt,)）。空的就别动——那一档整张表本来就是
    // 每行按内容自然高，注入的那一格也一样，补不补一个 auto 都一样
    let f = {
      let rs = f.at("rows", default: ())
      if type(rs) != array or rs.len() == 0 { f } else { f + (rows: (auto, ..rs)) }
    }
    // 表头线只有*真有表头*时才画：注入的那一格不是表头，它下面没有线
    let header-rows = if has-header { header-rows } else { 0 }
    // *末行是第几行*：底线那半条垫在它的下边。行数 ＝ 各格占的格位（colspan × rowspan）
    // 之和除以列数——表排得满时正好整除；线、注入的那一格不算
    let slots(k) = if k.func() == table.cell {
      k.at("colspan", default: 1) * k.at("rowspan", default: 1)
    } else if k.func() == table.header {
      k.fields().children.filter(c => c != mark-cell).map(slots).sum(default: 0)
    } else if k.func() in (table.hline, table.vline) { 0 } else { 1 }
    let last = off + calc.ceil(kids.map(slots).sum(default: 0) / n) - 1
    let inset = cell-inset(margin, strokes, off, header-rows, last)
    // 底线只在*我们自己画三线*时才补。用户给了 stroke 就整表听他的，
    // 再补一条会在表底多出一根线
    let kids = if stroke-untouched { kids + (table.hline(stroke: strokes.bottom),) } else { kids }
    let built = {
      // *字号、行盒与内边距都要在这里设。* 重建出来的表是新元素，外面那两条
      // show table: set … 规则罩不到它——实测重建后字号回到正文的 12、内边距回到
      // Typst 默认的 5pt，行步进涨到 29.45，长表页数翻倍。
      //
      // *罩的是 style-rules.rules 而不是只设字号*：行高得按模型的行盒来，只设字号
      // 的话走 Typst 自己的字体度量（实测五号内容盒 9.07，模型是 13.617），
      // 上面按 m.box 算出来的居中内边距就白算了。
      show: style-rules.rules.with(cell, layout: layout)
      set table(
        // *单元格内容居中。* 范例那几张表的数据格段落都写着
        // <w:jc w:val="center"/>——同一格里「供气压力」起笔 93.30、「Ps (MPa)」
        // 95.05，两行不齐正是居中的痕迹。Typst 默认靠左，续表标注把列撑宽之后
        // 尤其显眼（文字缩在左边，表框却伸到右边）。用户自己写了 align 就听他的。
        align: if raw-align == auto { center } else { raw-align },
        inset: inset,
        stroke: if not stroke-untouched { raw-stroke } else { (x, y) => (
          top: if y == off { strokes.top } else { none },
          bottom: if off <= y and y < header-rows + off { strokes.header } else { none },
        ) },
      )
      table(..f, ..kids)
    }
    // *底线探出表外的那一半*：Typst 把线画在表的下边界正中，Word 的线整条都在表里，
    // 底线的下沿才是下一段的起点（顶线的那一半垫在注入的那一格里，见 mark-cell）。
    // 只在我们自己画三线时垫；用户给了 stroke 就不知道线多粗
    let built = if stroke-untouched { pad(bottom: strokes.bottom / 2, built) } else { built }
    // 比版心宽就居中（见抬头）；量的是重建出来的整张表
    let over = measure(built).width - layout.text-width
    if over > 0.05pt { pad(x: -over / 2, built) } else { built }
  }
  doc
}
