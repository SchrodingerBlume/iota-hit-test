// 表格只做映射：把 Word 表格里的几个量换成 Typst 的值。表格样式、线怎么画、哪些表按 Word 排，归上层模板。
#import "./units.typ": twips
#import "./options.typ": option-of
#import "./paragraph/latin.typ": latin-block

/// Word 的默认单元格边距（表格属性 → 选项）：左右 0.19cm（108 缇）、上下 0。
/// -> dictionary
#let default-cell-margin = (x: twips(0.19cm), y: 0pt)

/// Word 的单元格边距从线的内沿量，Typst 的 `inset` 从线的中线量：每边加上挨着那条线的一半。
/// `margin` 收一个长度，或 `(x:, y:)`（也认 `left`／`right`／`top`／`bottom`／`rest`，左右取一个值、上下取一个值）；
/// `top` 等四边收挨着的线宽，`none` 为无线。
/// -> dictionary
#let cell-inset(margin, top: none, bottom: none, left: none, right: none) = {
  // 单值从元素上读回来是相对长度（0% + 12pt），与长度同样对待
  let side(keys) = if type(margin) in (length, relative) { margin } else {
    let hit = keys.find(k => k in margin)
    if hit == none { margin.at("rest", default: 0pt) } else { margin.at(hit) }
  }
  let half(v) = if v == none { 0pt } else { v / 2 }
  let mx = side(("x", "left", "right"))
  let my = side(("y", "top", "bottom"))
  (left: mx + half(left), right: mx + half(right), top: my + half(top), bottom: my + half(bottom))
}

/// 列宽全是定值：Word 不自动调整这种表，排不下就比版心宽。写进 columns 的长度 Typst 存成 relative（ratio 为 0）。
/// -> bool
#let fixed-columns(columns) = type(columns) == array and columns.len() > 0 and columns.all(c => (
  type(c) == length or (type(c) == relative and c.ratio == 0%)
))

/// 比版心宽的定宽表照 Word 居中（`w:jc="center"`），两边各探出一半：给出每边探出多少，排得下是 0pt。
/// 带 auto／fr 列的表按「根据窗口自动调整」在版心里折行，不探出——先用 `fixed-columns` 判。
/// -> length
#let overhang(width, text-width) = {
  let over = width - text-width
  if over > 0.05pt { over / 2 } else { 0pt }
}

/// 单元格里段落的样式：Word 只在 `adjust-line-height-in-table`（`w:adjustLineHeightInTable`）为真时让格子里的
/// 行贴文档网格，否则一律不贴，不管段落自己怎么设。必须在 context 中调用。
/// -> dictionary
#let cell-style(style) = if option-of("adjust-line-height-in-table") == true { style } else { style + (snap-to-grid: false) }

/// 格子里的字：不贴网格时 Word 一行多高看这一行实际用到的字体，纯西文（连纯数字）按西文字体的单倍行高、
/// 字距取半份，混着汉字的按中文。格子里没分段的字不成 par，正文那条按段判的规则管不到，所以逐格包上；
/// 贴网格时原样返回。`style` 是 `cell-style` 给的那条。必须在 context 中调用。
/// -> content
#let cell-body(style, layout, body) = latin-block(style, layout, body)
