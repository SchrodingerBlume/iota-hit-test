// Word 存盘的单位。Typst 的 pt 是 1/72 英寸，等于 Word 界面上的「磅」、LaTeX 的 bp；
// hithesis 源码里写 bp 的地方，这里一律写 pt。

// Word 的内部长度单位，一缇是 1/20 磅。行距与段间距的取整在这个单位上做
#let twip = 0.05pt

// 把一个长度存成缇——Word 存盘时就是这么干的，页面设置、缩进、间距全按整缇落地。
//
//   磅    整到百分位再乘 20 取整
//   厘米  整到百分位再乘 567 取整。Word 用 567 缇一厘米，不是精确的 566.929：
//         3.8cm → 2154.6 → 2155 缇 ＝ 107.75pt（写 3.8cm 让 Typst 精确换算得
//         107.7165，差 0.034——排版走的是缇，不是厘米）；3cm → 1701；2.3cm → 1304；
//         0.19cm → 107.73 → 108（表格的单元格边距）。三个页边距与范例 .docx 的
//         pgMar 分毫不差
//   其余  直接落缇取整（毫米、英寸那些）
//
// Typst 的 length 不记它是用什么单位写的，只能从值反推：磅数落在百分位上的当磅，
// 厘米数落在百分位上的当厘米，两个都不是就直接落缇。
//
// floor: true 往下截到整缇而不是四舍五入——Word 算「几行」乘出来的数是截的：网格行距
// 391 缇，0.8 行是 312.8，存成 312。
//
// em 报错：页面设置与段落对话框里没有「相对于字号」这一档，写了只能是手滑
#let twips(value, floor: false) = {
  if type(value) != length {
    panic("twips: expected absolute length (pt or cm), found " + repr(value))
  }
  if value.em != 0 {
    panic("twips: expected absolute length (pt or cm), found " + repr(value) + " (em is relative)")
  }
  if floor { return calc.floor(value / twip + 0.0001) * twip }
  let near(a, b) = calc.abs(a - b) < 1e-6
  let pt = value.pt()
  let cm = value.cm()
  let n = if near(pt, calc.round(pt, digits: 2)) {
    calc.round(pt, digits: 2) * 20
  } else if near(cm, calc.round(cm, digits: 2)) {
    calc.round(cm, digits: 2) * 567
  } else {
    pt * 20
  }
  calc.round(n) * twip
}

// docx 里图的尺寸记成 EMU（English Metric Unit），1pt ＝ 12700 EMU。
// 报告首页的校名题字写着 wp:extent cx="2131060" cy="400685"。
#let emu = 1pt / 12700

// *run 的字符间距*（w:rPr 的 w:spacing）折成长度。
//
// *一个单位是 1/10 磅，不是 OOXML 说的 1/20。* 按 ECMA-376 §17.3.2.35 它是
// ST_SignedTwipsMeasure，40 该是 2pt；可*两台 Word 都排成 4.00pt*——用户在
// macOS 上导出的报告 PDF，以及学校自己发的 硕士学位中期报告模板.pdf
// （Producer 是 Microsoft® Word 用于 Microsoft 365，Windows 排的）都是：校名
// 18pt 步进量出 22.07 / 21.94 ＝ 18 ＋ 4.00，标题 22pt 26.02 ＝ 22 ＋ 4.00。
// 另一处 w:val="12" 同样翻倍，量出 1.20pt。两个值都正好是缇值的两倍。
//
// 排出来的才算数，所以这里按 1/10 磅折。
#let run-spacing(units) = units / 10 * 1pt

// docGrid 的 w:charSpace 折成字距增量。单位是 1/4096 磅：范例的封面（节1）
// 与 hithesis 的正文都写着 charSpace=1861，1861/4096 = 0.4543pt。
// 这个增量与字号无关，见 src/layout/resolve.typ 的规则八。
#let char-space(units) = units / 4096 * 1pt
