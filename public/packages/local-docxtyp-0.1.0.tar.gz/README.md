# docxtyp

docxtyp 提供基于 Word 版式模型的 Typst 排版组件，供外部转换器和文档模板使用。
当前实现包括页面设置、文档网格、字体度量、段落、公式和表格的换算；各项支持范围以接口和测试为准。
学校或单位模板负责文档结构、具体样式与数学符号规范。

Typst 已有的概念直接使用原生名称，例如 `font`、`size`、`weight`、`style`、`lang`、`region`。
DOCX 解包、OOXML 源字段、主题和样式继承、修订/MCE/字段选择由外部转换器负责。

完整说明见 [`docs/manual.typ`](docs/manual.typ)。该手册由 docxtyp 自身排版，API 参考使用
[tidy](https://typst.app/universe/package/tidy/) 从源码的 `///` 注释生成。
从旧 banshi/字体角色接口迁移时，先看 [`docs/migration.md`](docs/migration.md)。
模块审查进度、复现与已知限制见 [`docs/audit.md`](docs/audit.md)。

## 安装

开发时可把仓库链接到 Typst 的本地包目录：

```sh
ln -s "$(pwd)" ~/Library/Application\ Support/typst/packages/local/docxtyp/0.1.0
```

```typ
#import "@local/docxtyp:0.1.0" as docxtyp
#import docxtyp.layout as layout
#import docxtyp.fonts: zihao
```

## 文档入口

先准备页面设置、原生字体描述和样式，再安装文档规则：

```typ
#import "@local/docxtyp:0.1.0" as docxtyp

#let page = docxtyp.layout.page-setup(
  paper: "a4",                       // Typst 的纸张名，或 (width:, height:)
  margin: (top: 2.54cm, bottom: 2.54cm, left: 3.18cm, right: 3.18cm),
  line-pitch: 20pt,
  char-pitch: 12pt,
  size: 12pt,
  grid: none,                        // 文档网格：无网格；"lines" 只指定行网格、"lines-and-chars" 行和字符
  header: (shown: false),
  footer: (shown: false),
)

#let defaults = (font: "Arial", size: 12pt)

#show: docxtyp.document.with(page, defaults: defaults)
```

`document` 按固定顺序安装文本、模板、段落、节和字体基线规则。模板自己的标题、题注与参考文献
规则通过 `rules:` 传入；新节使用 `docxtyp.layout.section`。
`defaults` 对应已解析的文档默认字符/段落属性（OOXML `docDefaults`），可以完全省略。
不要求 `body`、`Normal` 或其他样式名。命名样式继承由外部转换器解析，模板样式表留在消费模板。
引擎不接收模板字体表，也不保存 `fontset-state`。实际字体和目标度量写入相应样式或文本片段；
未指定字体时继承原生环境。数学、代码字体及学校角色默认值由调用方设置。

`document(lang: auto)` 继承外层 `text.lang`，地区、断字和悬挂标点沿用 Typst 原生设置。
例如德语文档可在入口前写 `#set text(lang: "de", region: "de", hyphenate: true)`；
局部文字也可以用 `text(lang: …)` 指定语言。源 DOCX 的语言和断字设置应由转换器解析后传入。
数学符号保留原生写法；国标字形等约定由消费模板安装，不由本包统一替换。

## 模块

命名优先复用职责相同的 Typst 概念，其次采用 Word 界面用词；后端辅助概念另行注明。
手册按“入门—Word/OOXML 参考—引擎与模板作者”组织，当前简称和待审命名见
[`docs/terminology.md`](docs/terminology.md)。术语对应不表示 Word 的全部对应行为已经实现。

| 模块 | 对应概念 |
|---|---|
| `layout` | Word 的节、页面设置、页眉页脚和文档网格 |
| `fonts` | 原生字体、显式目标度量、字号与边界补偿 |
| `paragraph` | 有效格式范围、缩进、段距、行距、列表和空段；显式片段行盒与单段度量选择策略 |
| `numbering` | 已解析的编号布局属性及列表／级别范围覆盖；不读取源编号定义 |
| `table` | 表格的映射值：默认单元格边距、边距从线内沿量、定宽超宽表的探出（表格样式与规则归模板） |
| `units` | twip、EMU 与绝对长度量化；源字段换算在外部工具中 |
| `runs` | 文本范围判定、字素比例和特殊空白的显式适配；不解释字体角色或 Word 字体槽 |
| `content` | content 的文本提取、折行、标签和 metadata 查询 |
| `errors` | Typst 风格的候选值与错误消息格式 |

根入口另导出 `document(...)`、`par(...)`、`options(...)` 和 `settings(...)`。
`options` 只接收列表适配策略；文档兼容设置与默认制表间距归 `settings`，编号后缀与位置归 `numbering.format`。

## 有效格式与段落

样式直接接收 `weight`、`style`、`lang`、`region`、`baseline` 等原生文字属性。
`kerning` 接收已解析的原生布尔开关，省略时继承；Word 的 `w:kern` 字号阈值由外部转换器先解析。
`paragraph.format(format)[…]` 在内容范围内应用已解析的字符/段落格式，省略属性回退到 `defaults`，退出后恢复。
节只改变页面属性；格式跨节继承。模板的 `base/preset/local` 合并与局部样式状态在 iota-hit 中维护。

`par` 应用对齐、缩进、段距和分页属性，`paragraph.rules` 是自建容器的低层入口。例如：

```typ
#docxtyp.par([靠右的段落],
  (font: "Arial", size: 12pt, weight: 650, align: right,
   left-indent: 12pt, above: none, below: 6pt, breakable: false),
  page-setup: docxtyp.paragraph.no-docgrid,
)
```

`pagebreak-before: true` 使用弱分页，`sticky` 和 `breakable` 交给原生块；未指定的对齐、
两端对齐及首行/悬挂缩进继承当前环境。`new-styles` 与文档级样式共用递归合并规则。
低层 `styles.rules` 安装文字和段落规则；左侧留白、分页及块属性由调用方的容器应用。

局部列表悬挂开关 `paragraph.enum-hanging`、`paragraph.list-hanging` 可独立使用，
无需先设置文档列表选项；显式布尔值只作用于该类列表，`auto` 继承外层，退出作用域后恢复。

## 字体与显式目标度量

`font` 接受原生 `text.font` 字符串、数组和字体描述。`songti`、`heiti`、`serif` 等角色、
替代预设和角色相关的补偿由 iota 等消费模板解析；docxtyp 不内置这些角色。

需要 Word 行高或锁定替代字体的目标行盒时，显式提供度量：

```typ
#let font = docxtyp.fonts.profile("Calibri", metrics: (single: 1.2207, ascent: 0.9537))
#let styles = (body: (font: font, size: 12pt, line-spacing: 1.25))
```

`single` 是目标单倍行高与字号的比例，`ascent` 是上升部比例。没有目标度量时，优先使用原生排版。
固定行盒不保证不同字形的字宽和断行相同；Word 精确度量需对目标字体和文档条件验证。

外部转换器应将解析结果转换为 Typst 参数后交给包。例如：

```typ
#text(font: ("Arial", "SimSun"), size: 12pt,
  weight: 700, style: "italic", lang: "de", region: "CH")[ABC]
```

`runs.adjust-spaces(body, rules: …)` 接收 en-space、thin-space、窄 NBSP 的显式宽度增量与断行选择，
保留原始字符，使用原生间距和断行控制做局部适配。校准数据及支持范围见
[`docs/space-layout.md`](docs/space-layout.md)。

## 仓库中的外部转换工具

`tools/` 保留独立的 DOCX 提取器、OOXML 适配原型与 Word 对照，入口见
[`tools/ooxml/README.md`](tools/ooxml/README.md)。这些内容排除于 Typst 包发布文件，包运行时也不依赖它们。
原始 XML、源字段名、继承/修订和有效属性修正保存在转换器一侧。

可运行的[小型文档端到端示例](tools/ooxml/docs/document-example.md)提供确定性 DOCX 样本、
外部解析和独立 Typst 生成，包含标题、正文、一级编号列表及定宽表格。
运行 `python3 tests/check-document-example.py` 可验证整条管线；原始样本采用直接格式。

[样式继承示例](tools/ooxml/docs/document-styles-example.md)进一步接入文档默认值、主题字体、
段落/字符样式和编号字体。使用 `sample --styled` 生成，`convert --metrics …` 可显式指定目标行盒度量；
回归入口为 `python3 tests/check-document-styles.py`。

## 验证

```sh
bash tests/run.sh
typst compile --root . docs/manual.typ docs/manual.pdf
```

回归测试覆盖版心、基线、文档网格、混排行、标点、纯西文行、对齐、缩进、分页、样式合并、公式、空段与字体替换。
`tests/check-package-boundary.py` 按打包清单复制独立运行文件，验证原生参数可用且没有 OOXML 适配导出/依赖。
外部工具另运行 `bash tools/check-ooxml.sh`；两组检查分别报告。
