// docxtyp 提供基于 Word 版式模型的排版组件，接收外部转换器或模板准备的 Typst 参数。
#import "src/document.typ": document
#import "src/layout.typ"
#import "src/fonts.typ"
#import "src/paragraph.typ"
#import "src/paragraph/render.typ": par
#import "src/table.typ"
#import "src/units.typ"
#import "src/runs.typ"
#import "src/content.typ"
#import "src/errors.typ"
#import "src/options.typ": options
#import "src/settings.typ": settings
#import "src/numbering.typ"
