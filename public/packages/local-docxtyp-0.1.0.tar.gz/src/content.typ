// 对 content 做不参与排版的结构查询与文本转换。
#import "./runs.typ": has-cj

// 普通手动换行会伴随一个 space 元素。折叠时，汉字之间不留空格，西文之间保留一个；
// `justify: true` 的换行是目录中的显式断行，不在此处理。
#let _edge-transparent(c) = {
  if c == none { return true }
  if type(c) == str { return c == "" }
  if type(c) != content { return false }
  if c.func() == metadata { return true }
  if c.has("text") and type(c.text) == str { return c.text == "" }
  if c.has("children") { return c.children.all(_edge-transparent) }
  if c.has("child") { return _edge-transparent(c.child) }
  false
}
#let _edge(c, last) = {
  if c == none { return "" }
  if type(c) == str { return if c == "" { "" } else if last { c.clusters().last() } else { c.clusters().first() } }
  if type(c) != content { return "" }
  if c.func() == [ ].func() { return " " }
  if c.has("text") and type(c.text) == str { return _edge(c.text, last) }
  if c.has("children") {
    let ch = if last { c.children.rev() } else { c.children }
    for child in ch {
      if not _edge-transparent(child) { return _edge(child, last) }
    }
    return ""
  }
  if c.has("child") { return _edge(c.child, last) }
  if c.has("body") { return _edge(c.body, last) }
  ""
}
/// 内容的首字或末字（`last: true` 取末字）：跳过边缘 metadata 和空文本，保留完整字素。
/// 实际空格与无法读取文本的可见元素仍作为边界；读不到字时是空串。
/// -> str
#let edge(c, last) = _edge(c, last)
#let _is-space(c) = type(c) == content and c.func() == [ ].func()
#let _is-fold(c) = (
  type(c) == content and c.func() == linebreak and not c.at("justify", default: false)
)
/// 折叠普通手动换行，并处理换行旁的空格元素。
/// -> content | array
#let fold-linebreaks(c) = {
  if type(c) == array {
    let out = ()
    let i = 0
    while i < c.len() {
      let x = c.at(i)
      if not _is-fold(x) { out.push(fold-linebreaks(x)); i += 1; continue }
      // 空格与透明节点可能交错；只清理空格，metadata 的顺序和内容必须保留。
      let markers = ()
      while out.len() > 0 and (_is-space(out.last()) or _edge-transparent(out.last())) {
        let tail = out.pop()
        if not _is-space(tail) { markers.push(tail) }
      }
      let before = _edge(if out.len() > 0 { out.last() } else { none }, true)
      out += markers.rev()
      i += 1
      while i < c.len() and (_is-space(c.at(i)) or _edge-transparent(c.at(i)) or _is-fold(c.at(i))) {
        let next = c.at(i)
        if _edge-transparent(next) { out.push(next) }
        i += 1
      }
      let after = _edge(if i < c.len() { c.at(i) } else { none }, false)
      if before != "" and after != "" and not has-cj(before) and not has-cj(after) { out.push([ ]) }
    }
    return out
  }
  if type(c) != content { return c }
  if c.has("children") { return fold-linebreaks(c.children).join() }
  c
}

/// 提取内容的字面文本；不进入无法可靠还原为文本的元素。
/// -> str
#let plain-text(c) = {
  if c == none { return "" }
  if type(c) == str { return c }
  if type(c) != content { return "" }
  if c.func() == [ ].func() { return " " }
  if c.func() == smartquote { return if c.double { "”" } else { "’" } }
  if c.has("text") {
    let t = c.text
    return if type(t) == str { t } else { plain-text(t) }
  }
  if c.has("child") { return plain-text(c.child) }
  if c.has("children") {
    let parts = fold-linebreaks(c.children).map(plain-text)
    return if parts.len() == 0 { "" } else { parts.join("") }
  }
  if c.has("body") { return plain-text(c.body) }
  ""
}


/// 返回内容树中的第一个标签。用于在重建题注等元素时保留原标签。
/// -> label | none
#let label-of(c) = {
  if type(c) != content { return none }
  let l = c.at("label", default: none)
  if l != none { return l }
  if c.has("children") {
    for k in c.children {
      let r = label-of(k)
      if r != none { return r }
    }
  }
  if c.has("body") { return label-of(c.body) }
  if c.has("child") { return label-of(c.child) }
  none
}

/// 查找内容树中首个包含 `key` 的 metadata，返回空数组或单元素数组。
/// -> array
#let metadata-of(c, key) = {
  if type(c) != content { return () }
  if c.func() == metadata {
    let v = c.value
    return if type(v) == dictionary and key in v { (v.at(key),) } else { () }
  }
  if c.has("children") {
    for x in c.children {
      let r = metadata-of(x, key)
      if r.len() != 0 { return r }
    }
  }
  if c.has("body") { return metadata-of(c.body, key) }
  if c.has("child") { return metadata-of(c.child, key) }
  ()
}

/// 判断内容是否只含空白或 metadata。
/// -> bool
#let blank(c) = {
  if c == none { return true }
  if type(c) != content { return false }
  if c.func() == metadata or _is-space(c) { return true }
  if c.has("text") { return if type(c.text) == str { c.text.trim() == "" } else { blank(c.text) } }
  if c.has("children") { return c.children.all(blank) }
  if c.has("body") { return blank(c.body) }
  if c.has("child") { return blank(c.child) }
  false
}

// 只清理不产生几何尺寸的文本尾项；不能使用 blank，因为空盒也可能占据版面。
#let _tail-blank(c) = {
  if type(c) != content { return false }
  if c.func() == metadata or _is-space(c) { return true }
  if c.has("text") and type(c.text) == str { return c.text.trim() == "" }
  if c.has("children") { return c.children.all(_tail-blank) }
  if c.has("child") { return _tail-blank(c.child) }
  false
}

/// 删除内容序列末尾的空白与 metadata，包括其样式包装；有尺寸的间距和容器不删除。
/// 不重建有文字的样式包装；若没有变化则保留原 content 的源码位置。
/// -> content
#let trim-tail(c) = {
  if type(c) != content or not c.has("children") { return c }
  let ks = c.children
  while ks.len() > 0 {
    let last = ks.last()
    if not _tail-blank(last) { break }
    ks = ks.slice(0, -1)
  }
  if ks.len() == 0 { none } else if ks.len() == c.children.len() { c } else { ks.join() }
}
