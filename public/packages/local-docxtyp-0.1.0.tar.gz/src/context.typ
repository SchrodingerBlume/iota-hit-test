// Typst 安装上下文：原生行盒快照及借 text.features 传递的内部作用域协议。
// 标签值保持稳定；这些不是字体 OpenType 功能，也不是 Word / OOXML 属性。
#let native-context-state = state("docxtyp-native-format-context", none)
#let native-context() = (top-edge: text.top-edge, bottom-edge: text.bottom-edge, leading: par.leading)

#let latin-par-tag = "izlp"
#let latin-par-features(on) = ((latin-par-tag): if on { 1 } else { 0 })
#let body-scope-tag = "izbs"
#let body-scope(features) = features.at(body-scope-tag, default: 1)
#let body-scope-features(features) = ((body-scope-tag): body-scope(features))
#let body-scope-matches(scope) = scope == none or (
  text.features.at(latin-par-tag, default: 0) == 1 and body-scope(text.features) == scope
)
// 按原生内容类型标记数学上下文，不通过模板数学字体名猜测。
#let math-context-tag = "izme"
#let math-context-features(features) = if math-context-tag in features {
  ((math-context-tag): features.at(math-context-tag))
} else { (:) }
// 是否让正文西文片段采用自己的行盒；与所属正文范围分别记录。
#let latin-line-tag = "izle"
#let latin-line-features(on) = ((latin-line-tag): if on { 1 } else { 0 })

#let enum-hanging-tag = "izeh"
#let list-hanging-tag = "izlh"
#let numbering-bypass-tag = "iznb"
#let numbering-format-tag = "iznf"
#let numbering-indent-tag = "izni"
#let list-context-features(features) = features.pairs().filter(((key, _)) => key in (
  enum-hanging-tag, list-hanging-tag, numbering-bypass-tag, numbering-format-tag, numbering-indent-tag,
)).to-dict()
