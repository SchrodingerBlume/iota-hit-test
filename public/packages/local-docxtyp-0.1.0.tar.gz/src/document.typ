// 文档入口：文档默认字符/段落属性对应 docDefaults；不接收模板样式表。
#import "./paragraph/spacing.typ": families-of
#import "./layout/resolve.typ" as _layout
#import "./layout/state.typ": page-setup-state
#import "./layout/section.typ": section
#import "./fonts/resolve.typ" as _fonts
#import "./fonts/tracking.typ": tracking-rules
#import "./document/state.typ": defaults-state
#import "./context.typ": native-context-state, native-context
#import "./paragraph/context.typ": format
#import "./format.typ": check-format
#import "./paragraph/enum.typ": enum-rules
#import "./paragraph/list.typ": list-rules
#import "./options.typ" as _options
#import "./settings.typ" as _settings
#import "./numbering/format.typ" as _numbering
#import "./numbering/state.typ": format-state as numbering-state

// 字的规则。
/// 设置断行、样式中的实际字体与语言，以及 run 边界的字距补偿。
/// -> content
#let _text-rules(defaults, lang, mapped, doc) = {
  let family = families-of(defaults)
  set par(linebreaks: if par.linebreaks == auto { "simple" } else { par.linebreaks })
  set text(font: family, lang: lang)
  show: if mapped and _layout.engine-linebreaks == none { tracking-rules } else { it => it }
  doc
}

/// 文档入口。安装页面及文档默认字符/段落格式。defaults 是已解析的有效属性，
/// 对应 OOXML docDefaults 的 rPrDefault/pPrDefault；不接收源 XML 或模板样式分类。
///
/// - `page-setup`：`layout.page-setup` 的结果。
/// - `defaults`：默认格式记录，例如 (font: "Arial", size: 12pt, line-spacing: 1.25)。
///   可省略，不要求 body、Normal 或其他样式名。命名样式继承由转换器解析。
/// 字体与度量由有效属性明确提供；省略字体时继承当前原生文字环境。
/// 数学、代码字体及模板字体角色由调用方设置。
/// - `lang`：`auto` 继承外层 `text.lang`；地区、断字和悬挂标点沿用原生设置。
/// - `header`、`footer`：逐页求值的零参数函数，或 Word“奇偶页不同”的 `(odd: 函数, even: 函数)`；传 `none` 不排。
/// - `rules`：模板自己的 show 规则。标题、题注和参考文献规则应从这里安装。
/// - `options`：`options(...)` 返回的文档选项，或同样结构的字典；`auto` 与省略该键相同。
///   仅含 enum-hanging/list-hanging 适配策略。
/// - `settings`：文档兼容设置及默认制表间距，可使用 settings(...) 创建。
/// - `numbering`：编号布局的文档缺省；局部列表或级别用 numbering.format 覆盖，不是源编号定义。
///
/// ```typ
/// #show: docxtyp.document.with(
///   layout, defaults: (font: "Arial", size: 12pt),
///   header: () => [论文题目],
///   footer: () => context counter(page).display(),
///   rules: template-rules,
/// )
/// ```
/// -> content
#let document(
  page-setup,             // 解析后的节级页面设置
  defaults: (:),          // 已解析的文档默认字符/段落属性
  lang: auto,
  options: (:),           // options(...) 的结果
  settings: (:),          // 文档级有效设置
  numbering: (:),         // 编号布局缺省值；级别范围可以覆盖
  header: none,           // 页眉页脚：逐页调用的函数，none ＝ 不排。递给 section
  footer: none,
  rules: body => body,    // 调用方自己的 show 链
  body,
) = context {
  let layout = page-setup
  if type(options) != dictionary { panic("document.options: expected a dictionary, found " + repr(options)) }
  let options = _options.options(..options)
  if type(settings) != dictionary { panic("document.settings: expected a dictionary") }
  let settings = _settings.settings(..settings)
  let numbering = _numbering.check-format(numbering, name: "document.numbering")
  check-format(defaults, name: "document.defaults")
  let font = defaults.at("font", default: auto)
  page-setup-state.update(layout)
  defaults-state.update(defaults)
  native-context-state.update(native-context())
  let mapped = _fonts.target(font) != none or layout.docgrid.tracking != 0pt
  let enums = "enum-hanging" in options or numbering.len() > 0
  let lists = "list-hanging" in options
  if mapped { _fonts.boundary-probe.update(_fonts.probe-boundary()) }
  _options.options-overrides(options)
  _settings.settings-overrides(settings)
  numbering-state.update((format: _numbering.format-defaults + numbering, parent: none))
  let lang = if lang == auto { text.lang } else { lang }
  show: _text-rules.with(defaults, lang, mapped)
  show: rules
  show: if enums { enum-rules.with(_numbering: numbering.len() > 0, _text-indent: "text-indent" in numbering) } else { it => it }
  show: if lists { list-rules } else { it => it }
  section(layout, header: header, footer: footer, _state: false, _format: false,
    format(defaults, page-setup: layout, _scope: 1, _line-metrics: false, body))
}
