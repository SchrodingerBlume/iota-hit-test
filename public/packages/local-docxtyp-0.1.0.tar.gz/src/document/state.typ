// 文档的已解析 docDefaults；不含模板样式表、当前段落或 Typst 安装快照。
#let defaults-state = state("docxtyp-defaults", (:))
