// 块级公式的 Word 行高映射，由 document 安装；实际数学字体由调用方设置。

#import "paragraph/spacing.typ": spacing
#import "./layout/resolve.typ" as _layout
#import "./context.typ": body-scope-matches


// 块级公式的上方不另补空白：分式所在行的“上一行基线到公式基线”量得 26.93pt，
// 正好等于正文行深 7.275pt 加公式上升部 19.65pt，验证了 Word 按实际内容高度
// 计算这一侧。额外行距只补在公式下方。
// 按 Word 的算法给块级公式补行高：行距倍数乘公式自然高度，或贴网格时取整数个网格行，多出的部分
// 补在公式下方。style 是正文那一条；document 装在段的规则里。
#let line-height-rules(style, _scope: none, doc) = {
  show math.equation.where(block: true): it => context {
    if not body-scope-matches(_scope) { return it }
    let metrics = spacing(style, page-setup: _layout.current-page-setup())
    let nat = measure(text(top-edge: "ascender", bottom-edge: "descender", it)).height
    let want = if metrics.snap {
      let g = metrics.docgrid.line-pitch
      calc.ceil(nat / g) * g
    } else {
      metrics.line-height / metrics.single * nat
    }
    let extra = want - measure(it).height
    if extra <= 0pt { it } else { block(below: extra, it) }
  }
  doc
}
