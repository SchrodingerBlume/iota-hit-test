// 仅探测编译器在文本片段边界丢失的 tracking，不探测未使用的字体。
#let boundary-probe = state("docxtyp-boundary-loss", 1)
#let probe-boundary() = {
  let t = 4pt
  let one = measure(text(tracking: t, fill: black)[ax]).width
  let two = measure(text(tracking: t, fill: black)[a] + text(tracking: t, fill: rgb("#000001"))[x]).width
  calc.max(0, calc.min(1, (one - two) / t))
}
#let boundary-loss() = boundary-probe.get()
