// 原生字体描述及显式的目标度量；不解释模板字体角色。
#import "./probes.typ": boundary-probe, probe-boundary, boundary-loss
/// 将原生字体描述与可选的 Word 目标度量绑定；不传 metrics 时使用原生排版。
/// font/metrics 为主路径，latin/latin-metrics 为调用方选择的另一条路径；命名沿用现有
/// 西文行盒适配约定，不代表 OOXML 的 ascii/hAnsi/eastAsia/cs 四槽，也不自动按脚本路由。
#let profile(font, metrics: none, latin: auto, latin-metrics: auto, features: (:)) = {
  let check(value) = if value != none {
    if type(value) != dictionary or not ("single" in value and "ascent" in value) {
      panic("font metrics: expected (single:, ascent:) or none")
    }
    if type(value.single) not in (int, float) or type(value.ascent) not in (int, float) or value.single <= 0 or value.ascent < 0 {
      panic("font metrics: single must be positive and ascent nonnegative")
    }
  }
  check(metrics)
  if latin-metrics != auto { check(latin-metrics) }
  if type(features) != dictionary { panic("font profile: features must be a dictionary") }
  (docxtyp-font: true, font: font, metrics: metrics,
    latin: if latin == auto { font } else { latin },
    latin-metrics: if latin-metrics == auto { metrics } else { latin-metrics },
    features: features)
}
#let is-profile(value) = type(value) == dictionary and value.at("docxtyp-font", default: false) == true
#let family(value, latin: false) = if is-profile(value) {
  if latin { value.latin } else { value.font }
} else { value }
#let target(value, latin: false) = if is-profile(value) {
  if latin { value.latin-metrics } else { value.metrics }
} else { none }
#let style-font(style, fallback: auto) = style.at("font", default: fallback)
#let features(value) = if is-profile(value) { value.features } else { (:) }
