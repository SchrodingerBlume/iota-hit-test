/// 中文字号与绝对长度的换算。
#let zihao = (
  chuhao: 42pt, xiaochu: 36pt, yihao: 26pt, xiaoyi: 24pt, erhao: 22pt, xiaoer: 18pt,
  sanhao: 16pt, xiaosan: 15pt, sihao: 14pt, xiaosi: 12pt, wuhao: 10.5pt, xiaowu: 9pt,
  liuhao: 7.5pt, xiaoliu: 6.5pt, qihao: 5.5pt, bahao: 5pt,
)
