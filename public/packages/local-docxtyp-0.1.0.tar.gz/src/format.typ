// 已解析的字符/段落有效属性。键使用 Typst 原生名称及对应的 Word 段落功能。
#import "./errors.typ" as errors
// 属性分类供各安装器选择实际消费的子集；公开格式仍是一条扁平记录。
#let character-keys = ("font", "size", "weight", "style", "lang", "region", "baseline", "tracking", "kerning")
#let paragraph-keys = (
  "line-spacing", "above", "below", "first-line-indent", "hanging-indent", "left-indent",
  "align", "snap-to-grid", "justify", "pagebreak-before", "sticky", "breakable",
)
/// 当前引擎支持的有效字符/段落属性键；不是模板样式名称或源字段清单。
#let format-keys = character-keys + paragraph-keys
#let _line-spacing-ok(v) = v in ("single", "double") or type(v) in (int, float, length) or (
  type(v) == dictionary and v.keys().len() == 1 and (
    ("exactly" in v and type(v.exactly) == length) or ("at-least" in v and type(v.at-least) == length)
  )
)
#let _check-character(key, v, where) = {
  if key == "font" and v != auto and type(v) not in (str, array, dictionary) {
    panic(where + "expected a native font description or font profile")
  } else if key == "size" and (type(v) != length or v.em != 0) {
    panic(where + "expected absolute length such as zihao.xiaosi or 12pt, found " + repr(v))
  } else if key == "kerning" and type(v) != bool {
    panic(where + "expected true or false, found " + repr(v))
  } else if key in ("weight", "style", "lang", "region", "baseline", "tracking") {
    let _ = text(..((key): v), [])
  }
}
#let _check-paragraph(key, v, where) = {
  if key in ("snap-to-grid", "justify", "pagebreak-before", "sticky", "breakable") and type(v) != bool {
    panic(where + "expected true or false, found " + repr(v))
  } else if key == "line-spacing" and not _line-spacing-ok(v) {
    panic(where + "expected single, double, a number, a length, exactly or at-least, found " + repr(v))
  } else if key in ("above", "below") and not (v == none or type(v) == length or (
    type(v) == dictionary and v.keys() == ("lines",) and type(v.lines) in (int, float))) {
    panic(where + "expected none, length, or dictionary with numeric \"lines\", found " + repr(v))
  } else if key in ("first-line-indent", "hanging-indent", "left-indent") and not (v == none or type(v) == length or (
    type(v) == dictionary and v.keys() == ("chars",) and type(v.chars) in (int, float))) {
    panic(where + "expected none, length, or dictionary with numeric \"chars\", found " + repr(v))
  } else if key == "align" and type(v) != alignment {
    panic(where + "expected alignment (left, center, or right), found " + repr(v))
  }
}
/// 校验已解析的字符/段落格式记录，不接收模板样式名、子记录或预设。
#let check-format(entry, name: "format") = {
  if type(entry) != dictionary { panic(name + ": expected a dictionary, found " + repr(entry)) }
  for (key, v) in entry {
    if key == "bold" { panic(name + ".bold: use weight for native text weight") }
    if key not in format-keys { panic(name + ": unknown key " + repr(key) + "; " + errors.expected-one-of(format-keys, key)) }
    let where = name + "." + key + ": "
    if key in character-keys { _check-character(key, v, where) } else { _check-paragraph(key, v, where) }
  }
}
