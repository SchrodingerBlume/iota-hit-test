// 「几个字」的度量：chars（Word 段落对话框的「字符」单位：字号加字符网格增量）、half-width-space（半角空格）、
// resolve-chars（长度或 (chars: n)）、h-chars（正文里空几个字）。

#import "../paragraph/spacing.typ": no-docgrid
#import "./resolve.typ" as _layout
#import "./state.typ": page-setup-state

/// 返回 Word“n 字符”对应的长度。一个字符等于当前字号加字符网格增量，不一定是
/// `1em`。省略 `n` 时返回一个字符；`page-setup: auto` 读取当前节。
/// `n` 只接受一个位置数值，支持负数和分数；唯一具名参数为 `page-setup`。
/// `page-setup: none` 显式使用无网格；输入字典在当前节上合并，尚无当前节时独立解析。
///
/// 用于尺寸参数，如 `first-line-indent: chars(2)`。正文中插入空白应使用 `h-chars`。
/// -> length
#let chars(..n, page-setup: auto) = {
  let layout = page-setup
  if n.pos().len() > 1 or n.named().len() > 0 {
    panic("chars: expected at most one positional number and the named argument page-setup")
  }
  let count = n.pos().at(0, default: 1)
  if type(count) not in (int, float) {
    panic("chars: expected a number, found " + repr(count))
  }
  let l = if layout == none {
    no-docgrid
  } else if _layout.is-page-setup(layout) {
    layout
  } else {
    let s = page-setup-state.get()
    if s == none {
      if layout == auto { no-docgrid } else { _layout.page-setup(layout) }
    } else { _layout.merge-page-setup(s, layout) }
  }
  count * 1em + count * l.docgrid.tracking
}

// Word 文档网格中的半角空格占半个固定网格单元。整段那一份网格增量是模拟网格时补的（run 到这儿断了，
// 末字那份 tracking 丢掉）；断行引擎自己画网格时它已经在，再补就多出来——声明页签名行的「日」
// 因此曾在引擎档下被顶到下一行（四段各多 0.4543，行尾离版心右缘只剩 0.7）。
/// 插入 `n` 个半角空格的宽度：每个占半个字符跨度，模拟网格时整段再加一份网格增量。
/// -> content
#let half-width-space(n, layout) = h(
  n * layout.docgrid.char-pitch / 2 + (if _layout.emulated(layout) { layout.docgrid.tracking } else { 0pt }),
)

/// 将长度或只含数值键 `chars` 的字典转为长度；长度原样返回。
/// -> length
#let resolve-chars(value, layout) = {
  if type(value) == length { return value }
  if type(value) == dictionary and value.keys() == ("chars",) {
    let n = value.at("chars")
    if type(n) not in (int, float) {
      panic("resolve-chars: expected number for \"chars\", found " + repr(n))
    }
    return chars(n, page-setup: layout)
  }
  panic("resolve-chars: expected length or dictionary containing only \"chars\", found " + repr(value))
}

/// 在正文中插入 `n` 个 Word 字符宽度；负值退格。省略 `n` 时为一个字符。
///
/// ```typ
/// [图 1-1#h-chars()系统结构]
/// ```
///
/// 全角空格「　」也占一个字符，但 `h-chars` 不会把空白写入复制出来的文本。
/// -> content
#let h-chars(..n, page-setup: auto) = context h(chars(..n, page-setup: page-setup))
