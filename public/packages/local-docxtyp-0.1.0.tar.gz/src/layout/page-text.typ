// 当前支持的页眉页脚定高文字块；不是任意多段落的 Word 故事排版器。
#import "../paragraph/spacing.typ": families-of, spacing
#import "../paragraph/latin.typ": latin-line-rules
#import "../paragraph/border.typ" as borders
#import "../runs/regex.typ": latin-any-run
#import "../context.typ": latin-par-features
#import "../format.typ": character-keys
#import "../fonts/resolve.typ" as fonts

#let check-content(value, name) = {
  if value == none or type(value) == function { return }
  if type(value) != dictionary or value.keys().sorted() != ("even", "odd") or not value.values().all(v => type(v) == function) {
    panic(name + ": expected none, a function, or (odd: function, even: function) for Word's \"different odd and even pages\", found " + repr(value))
  }
}

// 安装时固定所继承的字号，保证放置高度与文字使用同一份有效格式。
#let measure-record(record, docgrid) = {
  let format = (font: text.font, size: text.size) + record.format
  if format.font == auto { format.font = text.font }
  let metrics = spacing(format, docgrid: docgrid, char-grid: false)
  (format: format, metrics: metrics, height: metrics.line-height + borders.height(record.border))
}

// 奇偶选择沿用既有印码语义；与页面几何、段落边框计算分开。
#let _odd() = calc.odd(counter(page).get().first())
#let _content(value) = if type(value) == dictionary {
  (if _odd() { value.odd } else { value.even })()
} else { value() }

#let render(record, measured, value, side, width, docgrid) = {
  let format = measured.format
  let metrics = measured.metrics
  let latin = spacing(format, docgrid: docgrid, char-grid: false, latin: true)
  set text(
    font: families-of(format), size: metrics.size,
    top-edge: metrics.top-edge, bottom-edge: -metrics.bottom-edge,
    ..format.pairs().filter(((key, _)) => key in character-keys and key not in ("font", "size")).to-dict(),
    features: fonts.features(format.at("font", default: auto)) + latin-par-features(false),
  )
  set par(leading: 0pt, spacing: 0pt, justify: format.at("justify", default: false),
    first-line-indent: 0pt, hanging-indent: 0pt)
  show par: it => it
  show: latin-line-rules.with(format, docgrid: docgrid, char-grid: false)
  // 页码这样的纯数字／标点行也使用西文行盒；贴纵向网格时保留网格行盒。
  show latin-any-run: set text(..(if metrics.snap { (:) } else {
    (top-edge: latin.top-edge, bottom-edge: -latin.bottom-edge)
  }))
  context {
    let content = _content(value)
    if content != none {
      block(height: measured.height, width: 100%, align(side + format.at("align", default: start), {
        content
        let border = record.border
        if borders.is-pair(border) { border = if _odd() { border.odd } else { border.even } }
        borders.draw(border, width)
      }))
    }
  }
}
