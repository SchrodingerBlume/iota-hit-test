// 节级页面几何与故事放置。文字块排版及段落边框由各自模块负责。
#import "./page-text.typ" as page-text

#let page-rules(layout, header: none, footer: none, doc) = {
  page-text.check-content(header, "header")
  page-text.check-content(footer, "footer")
  let head = page-text.measure-record(layout.header, layout.docgrid)
  let foot = page-text.measure-record(layout.footer, layout.docgrid)
  // 页眉距边界量到块顶，页脚距边界量到块底；页眉过高时向下扩展天头。
  let head-ascent = layout.margin.top - layout.header.from-edge - head.height
  let margin-top = if header == none { layout.margin.top } else {
    calc.max(layout.margin.top, layout.margin.top - head-ascent)
  }
  let margin = layout.margin + (top: margin-top)
  let head-ascent = head-ascent + (margin-top - layout.margin.top)
  let foot-descent = layout.margin.bottom - layout.footer.from-edge - foot.height
  set page(
    width: layout.paper-width, height: layout.paper-height, margin: margin,
    header-ascent: head-ascent, footer-descent: foot-descent,
    header: if header == none { none } else {
      page-text.render(layout.header, head, header, top, layout.text-width, layout.docgrid)
    },
    footer: if footer == none { none } else {
      page-text.render(layout.footer, foot, footer, bottom, layout.text-width, layout.docgrid)
    },
  )
  doc
}
