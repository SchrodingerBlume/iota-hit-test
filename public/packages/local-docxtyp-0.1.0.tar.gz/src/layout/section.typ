// 节级设置可以在局部 show 作用域中重设；会叠加补偿的 show 规则只在文档级安装一次。

#import "./resolve.typ" as _layout
#import "./rules.typ": page-rules
#import "../paragraph/state.typ": current-format
#import "../paragraph/context.typ": format
#import "../context.typ": latin-line-tag

/// 应用一个 Word“节”的页面设置，并重装该节的页眉、页脚、正文行盒与字符网格。
/// `layout` 必须是 `page-setup` 或 `merge-page-setup` 的结果。
/// 本入口对应节级页面属性，不选择段落样式；当前有效段落格式随内容范围继承。
/// `header` / `footer` 收逐页求值的零参数函数，或 Word
/// “奇偶页不同”的 `(odd: 函数, even: 函数)`（按印码的奇偶挑）；`none` 不排。
///
/// `section` 是 show rule，按 `layout.section-start` 决定分页，不重置页码。
/// 若页码制式变化，另设 `page(numbering:)` 并更新页码计数器。
/// 当前页面设置在本作用域内生效，退出后恢复。`continuous` 不额外发出显式分页，
/// 但原生 `set page` 重新安装页面设置仍可能换页，不等价于 Word 的同页连续分节。
/// 局部字符/段落属性通过 paragraph.format 应用；节不接收模板样式表。
/// 数学和代码字体由调用方使用原生规则指定。
///
/// ```typ
/// #show: section.with(
///   layout,
///   header: () => [附录],
///   footer: () => context counter(page).display("I"),
/// )
/// ```
/// -> content
#let section(page-setup, header: none, footer: none, _state: true, _format: true, body) = context {
  let layout = page-setup
  let effective = current-format()
  // 文档入口和拥有恢复链的消费模板自行管理状态；普通 section 管理自己的局部作用域。
  if _state {
    _layout.page-setup-state.update(previous => layout + (docxtyp-section-parent: previous))
  }
  // continuous 不另发显式分页；page-rules 中的原生 set page 仍遵循 Typst 分页行为。
  if layout.section-start != "continuous" {
    pagebreak(weak: true, to: (new-page: none, odd-page: "odd", even-page: "even").at(layout.section-start))
  }
  show: page-rules.with(layout, header: header, footer: footer)
  show: _layout.linebreaks-sets.with(layout)
  if _format {
    format(effective, page-setup: layout, _line-metrics: text.features.at(latin-line-tag, default: 0) == 1, body)
  } else { body }
  if _state { _layout.page-setup-state.update(current => current.docxtyp-section-parent) }
}
