// 页面状态查询与安装器分开，避免循环导入；状态名称供现有查询使用。
/// 当前节的页面设置。`document` 与 `section` 写入，show rule 在 context 中读取；
/// 初值为 `none`。
/// -> state
#let page-setup-state = state("docxtyp-layout", none)

// 第一页的页眉在文档级那次 update 之前就排了，读到的 state 还是 none，此时回退到安装时的那份。
// 选择规则使用的页面设置：`current` 为真时读取当前节，否则返回安装规则时传入的 `layout`。
// 状态尚未写入时回退到 `layout`。必须在 context 中调用。
// -> dictionary
#let layout-of(layout, current) = {
  if not current { return layout }
  let s = page-setup-state.get()
  if s == none { layout } else { s }
}
