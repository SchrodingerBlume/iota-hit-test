#import "./format.typ": check-format
#import "./state.typ": format-state
#import "../paragraph/enum.typ": enum-rules
#import "../context.typ": enum-hanging-tag, numbering-format-tag, numbering-indent-tag

/// 在完整列表或嵌套级别范围内覆盖有效编号布局，退出后恢复。
/// 不解析源编号定义、不重置编号计数器；可独立使用，无需 document。
/// 空字典或全 auto 不改变规则安装；未写的属性继承外层，文档初值来自 document(numbering:)。
/// 原生 enum 的显式 body-indent 优先于后缀设置；项目符号 list 不受影响。
/// 省略 text-indent 时悬挂模式保留原生共享标签列；显式给出则固定文本／续行左缘，
/// tab 首行逐项选择文本缩进或其后的制表位，须设置 enum(number-align:left)。
/// space 后缀可以通过 space-advance 接收外部解析／观测的目标增量；未提供时用原生空格，
/// 不据此保证 Word 一致性。它不改变编号字形或字号，也不自动选择某个 Word 字体槽。
/// -> content
#let format(value, body) = {
  let checked = check-format(value)
  if checked.len() == 0 { return body }
  // 先发出函数式入栈更新，不在更新前读取父值；深层嵌套不依赖逐级求值的快照。
  format-state.update(old => (format: old.format + checked, parent: old))
  context {
    set text(features: text.features + ((numbering-format-tag): 1))
    set text(features: text.features + ((numbering-indent-tag): 1)) if "text-indent" in checked
    show: if enum-hanging-tag in text.features { it => it } else { enum-rules }
    body
  }
  format-state.update(old => old.parent)
}
