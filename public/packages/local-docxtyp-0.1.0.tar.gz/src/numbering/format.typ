// 编号布局的有效属性；源 abstractNum/num/lvlOverride 在转换器中解析。
#import "../errors.typ" as errors
#let format-defaults = (follow-number-with: auto, numbering-tab-stop: auto, text-indent: auto, space-advance: auto)
/// 当前引擎接收的有效编号布局键；不是源编号定义的完整属性集合。
/// -> array
#let format-keys = format-defaults.keys()

/// 校验并规范化编号布局记录。auto 与省略相同，继承外层值。
/// follow-number-with 接收 tab/space/nothing；numbering-tab-stop 是相对当前段落左缘的
/// 绝对位置，可为零或负值。tab 未指定位置或已越过位置时跳到下一个默认制表位。
/// text-indent 为显式文本缩进位置，悬挂模式下固定续行左缘；须设 enum(number-align:left)，
/// tab 首行另按每项编号计算。省略时沿用原生共享列。
/// space-advance 是编号 space 后缀的显式目标增量，非负绝对长度；它不是 Word UI 控件或
/// 普通空格的字体宽度。只在 follow-number-with:space 生效，auto 继承或沿用原生空格。
/// -> dictionary
#let check-format(value, name: "numbering") = {
  if type(value) != dictionary { panic(name + ": expected a dictionary") }
  for (key, v) in value {
    if key not in format-keys { panic(name + ": unknown key " + repr(key) + "; " + errors.expected-one-of(format-keys, key)) }
    if v == auto { continue }
    if key == "follow-number-with" and v not in ("tab", "space", "nothing") {
      panic(name + "." + key + ": " + errors.expected-one-of((auto, "tab", "space", "nothing"), v))
    }
    if key in ("numbering-tab-stop", "text-indent") and (type(v) != length or v.em != 0) {
      panic(name + "." + key + ": expected an absolute length or auto")
    }
    if key == "space-advance" {
      if type(v) != length or v.em != 0 { panic(name + "." + key + ": expected an absolute length or auto") }
      if v < 0pt { panic(name + "." + key + ": expected a nonnegative absolute length or auto") }
    }
  }
  value.pairs().filter(((_, v)) => v != auto).to-dict()
}
