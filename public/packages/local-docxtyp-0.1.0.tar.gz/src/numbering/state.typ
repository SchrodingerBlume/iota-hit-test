#import "./format.typ": format-defaults
#let format-state = state("docxtyp-numbering-format", (format: format-defaults, parent: none))
#let current-format() = format-state.get().format
