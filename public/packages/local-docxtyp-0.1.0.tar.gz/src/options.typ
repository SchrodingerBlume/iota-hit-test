// 列表适配策略；与文档 settings、编号级别的有效布局属性分开。
#import "./errors.typ" as _errors

#let option-defaults = (
  enum-hanging: auto,
  list-hanging: auto,
)

#let options-state = state("docxtyp-options", option-defaults)

/// 创建供 `document(options:)` 使用的选项字典。只接受具名参数；`auto` 与省略该键相同，
/// 不覆盖当前值或模板默认值。`document` 直接收到字典时也执行相同校验和规范化。
///
/// - `enum-hanging`、`list-hanging`：控制编号列表与项目符号列表是否使用悬挂缩进。
///
/// 文档兼容设置与默认制表间距使用 settings；编号后缀与制表位置使用 numbering.format。
/// 这两个列表策略不是 Word“文件 → 选项”的复选框。
///
/// ```typ
/// #let opts = options(enum-hanging: false)
/// ```
/// -> dictionary
#let options(..args) = {
  if args.pos().len() > 0 { panic("options: expected named arguments only") }
  for (key, v) in args.named() {
    if key not in option-defaults {
      panic(
        "unknown option: " + key + " (" + _errors.one-of(
          option-defaults.keys().map(k => repr(k)),
        ) + ")",
      )
    }
    if v == auto { continue }
    if type(v) != bool {
      panic(key + ": expected auto, true, or false, found " + repr(v))
    }
  }
  args.named().pairs().filter(((_, v)) => v != auto).to-dict()
}

// 将显式选项写入文档状态。
#let options-overrides(value) = {
  let checked = options(..value)
  options-state.update(old => old + checked)
}

// 读取当前文档选项；调用方必须处于 context 中。
#let option-of(key) = {
  let all = options-state.get()
  if key not in all { panic("unknown option: " + key) }
  all.at(key)
}
