// 换算层算出来的行高在这里落到 Typst 的三个 set 上。

#import "../paragraph/latin.typ" as western
#import "../paragraph/spacing.typ": spacing
#import "./state.typ": format-of
#import "./rules.typ" as style-rules
#import "../context.typ": latin-par-tag, body-scope-matches
#import "../layout/resolve.typ" as _layout

// 行盒采用目标 Word 字体的度量，不随当前机器加载的替代字体变化。
#let body-rules(layout, style, current: true, _scope: 1, doc) = {
  // 正文的西文段那条不在这儿：document 把它装在最里层（style-rules.latin-runs）
  show: style-rules.shows.with(style, layout: layout, current: current, latin-runs: false, _scope: _scope)

  show par: it => context {
    if text.features.at(latin-par-tag, default: 0) != 1 { return it }
    if not body-scope-matches(_scope) { return it }
    if par.leading != 0pt {
      panic(
        "set par(leading: " + repr(par.leading) + ") does not set the line spacing "
          + "here: this formatter keeps leading at zero and puts the whole line box "
          + "into the text edges (Word's model), so your value is added on top of it. "
          + "The effective paragraph line spacing is currently "
          + repr(format-of(style, current).at("line-spacing", default: auto))
          + "; set line-spacing in document(defaults:) or paragraph.format",
      )
    }
    let layout = _layout.current-page-setup()
    let style = format-of(style, current)
    western.latin-auto(style, layout, it)
  }


  doc
}
