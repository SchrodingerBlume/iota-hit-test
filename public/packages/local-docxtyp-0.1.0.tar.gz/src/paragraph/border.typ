// 段落下边框：有效属性校验、几何计算与绘制，不读取页面或故事状态。
#import "../units.typ": twips
#import "../errors.typ" as errors

#let keys = ("style", "thickness", "from-text")
#let pair-keys = ("odd", "even")
#let styles = ("single", "thin-thick-small-gap", "thin-thick-medium-gap", "thin-thick-large-gap")
#let is-pair(value) = type(value) == dictionary and ("odd" in value or "even" in value)

#let normalize(value, name) = {
  if value == none { return none }
  if type(value) != dictionary {
    panic(name + ": expected none or dictionary with style, thickness, and from-text, found " + repr(value))
  }
  if is-pair(value) {
    for key in value.keys() {
      if key not in pair-keys { panic(name + ": unknown key " + repr(key) + "; expected odd and even only") }
    }
    for key in pair-keys {
      if key not in value { panic(name + ": missing " + key + " (different odd and even pages need both)") }
      if is-pair(value.at(key)) { panic(name + "." + key + ": expected a single border or none") }
    }
    return (odd: normalize(value.odd, name + ".odd"), even: normalize(value.even, name + ".even"))
  }
  for key in value.keys() {
    if key not in keys { panic(name + ": unknown key " + repr(key) + "; expected style, thickness, or from-text") }
  }
  for key in ("thickness", "from-text") {
    if key not in value { panic(name + ": missing " + key) }
    let v = value.at(key)
    if type(v) != length or v.em != 0 {
      panic(name + "." + key + ": expected absolute length (pt or cm), found " + repr(v))
    }
  }
  let style = value.at("style", default: "single")
  if style not in styles { panic(name + ".style: " + errors.expected-one-of(styles, style)) }
  (style: style, thickness: twips(value.thickness), from-text: twips(value.from-text))
}

// Mac Word 的既有实测条件：sz 6/12/18/24。小间距的间隙和细线均为 0.75pt；
// 中间距为宽度的一半、舍到 0.25pt；大间距的宽度指定间隙。
#let parts(border) = {
  let w = border.thickness
  if border.style == "thin-thick-small-gap" { (w, 0.75pt, 0.75pt) }
  else if border.style == "thin-thick-medium-gap" {
    let half = calc.floor(w / 0.25pt / 2 + 1e-6) * 0.25pt
    (w, half, half)
  } else if border.style == "thin-thick-large-gap" { (1.5pt, w, 0.75pt) }
  else { (w,) }
}

#let height(border) = if border == none { 0pt } else if is-pair(border) {
  calc.max(height(border.odd), height(border.even))
} else if border.thickness <= 0pt { 0pt } else {
  border.from-text + parts(border).sum()
}

// 保留既有 Word 对照中的两端伸出量；不在本轮改变校准值。
#let _overhang = 1.56pt
#let draw(border, width) = if height(border) > 0pt {
  v(border.from-text, weak: false)
  for (i, part) in parts(border).enumerate() {
    if calc.even(i) {
      box(width: width, height: part, place(left + top, dx: -_overhang,
        rect(width: width + 2 * _overhang, height: part, fill: black, stroke: none)))
    } else { v(part, weak: false) }
  }
}
