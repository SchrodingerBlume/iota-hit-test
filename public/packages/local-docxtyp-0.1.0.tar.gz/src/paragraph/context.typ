// 将已解析的 pPr/rPr 有效属性安装到一段内容范围，不处理命名样式或模板配置表。
#import "../format.typ": check-format
#import "../document/state.typ": defaults-state
#import "./state.typ": format-state
#import "../context.typ": native-context-state
#import "./rules.typ" as rules
#import "./body.typ": body-rules
#import "../fonts/resolve.typ" as fonts
#import "../layout/resolve.typ": current-page-setup
#import "./spacing.typ": families-of, indent
#import "../context.typ": body-scope, body-scope-tag, body-scope-matches
#import "../equation.typ": line-height-rules
#import "./render.typ": par as _paragraph
#import "./latin.typ": latin-line-rules

/// 在内容范围内应用已解析的字符、段落格式。省略的属性回退到 document(defaults:)。
/// 不读取 body、chapter 等模板名称，不解析源样式继承；退出后恢复外层格式。
/// 段落属性用于完整段落范围；局部文字的原生字形属性使用 text。
/// -> content
#let format(value, page-setup: auto, _scope: auto, _line-metrics: true, body) = context {
  check-format(value)
  let effective = defaults-state.get() + value
  if "size" not in effective { effective.size = text.size }
  let layout = if page-setup == auto { current-page-setup() } else { page-setup }
  let scope = if _scope == auto { body-scope(text.features) + 1 } else { _scope }
  let native = native-context-state.get()
  set text(top-edge: native.top-edge, bottom-edge: native.bottom-edge) if native != none
  set par(leading: native.leading) if native != none
  format-state.update(previous => (format: effective, parent: previous))
  set text(features: text.features + ((body-scope-tag): scope))
  let font = effective.at("font", default: auto)
  let mapped = fonts.target(font) != none or layout.docgrid.tracking != 0pt
  let split = layout.docgrid.tracking != 0pt or (fonts.is-profile(font) and (
    font.font != font.latin or font.metrics != font.latin-metrics
  ))
  show: rules.sets.with(effective, layout: layout, latin-par: true, font: families-of(effective),
    _scope: scope, _line-metrics: _line-metrics)
  let left = indent(effective, page-setup: layout).left
  let block-properties = effective.pairs().filter(((key, _)) => key in ("sticky", "breakable")).to-dict()
  let containers(body) = {
    show par: it => context {
      if not body-scope-matches(scope) { return it }
      _paragraph(it.body, effective, page-setup: layout,
        rules: latin-line-rules.with(effective, docgrid: layout.docgrid))
    }
    body
  }
  show: if left != 0pt or block-properties.len() > 0 or effective.at("pagebreak-before", default: false) {
    containers
  } else { it => it }
  show: if mapped {
    if split { body-rules.with(layout, effective, current: false, _scope: scope) } else {
      rules.shows.with(effective, layout: layout, latin-runs: false, _scope: scope)
    }
  } else { it => it }
  show: if mapped { line-height-rules.with(effective, _scope: scope) } else { it => it }
  show: if split { rules.latin-runs.with(effective, layout: layout, _scope: scope) } else { it => it }
  body
  format-state.update(current => current.parent)
}
