// 模拟 Word 里单独按一次回车留下的空段。

#import "./spacing.typ": spacing, no-docgrid
#import "../layout/resolve.typ" as _layout
#import "../layout/state.typ": page-setup-state
#import "./state.typ": current-format
#import "../errors.typ" as _errors

// 回车次数写成位置参数，好让 #enter() 与 #enter(3) 都能用。
#let _line-spacing-of(value) = if value != auto { value } else {
  current-format().at("line-spacing", default: 1)
}
// 回车敲出的空段继承上一段的段落属性：贴不贴格默认跟当前正文样式
#let _snap-of(value) = if value != auto { value } else {
  current-format().at("snap-to-grid", default: false)
}

// 空段高度由段落标记 ¶ 的实际字体和度量决定；源字体槽由转换器解析。
/// 计算一个空段的高度：按段落标记 ¶ 的原生字体或显式 profile 的单倍行高乘以行距，
/// 贴网格时向上取整到整数个网格行。`line-spacing` 为 `auto` 时跟随当前正文样式。
/// -> length
#let paragraph-mark-height(size, font: auto, line-spacing: auto, snap: false, page-setup: no-docgrid) = {
  let layout = page-setup
  spacing(
    (
      size: size,
      font: font,
      line-spacing: _line-spacing-of(line-spacing),
      snap-to-grid: snap,
    ),
    docgrid: layout.docgrid,
  ).baseline-gap
}

/// 插入一个或多个 Word 段落标记所形成的空段高度。
/// 位置参数是段落标记数；`weak: true` 时改用可折叠的垂直间距。
/// `snap` 与 `line-spacing` 为 `auto` 时跟随当前正文样式（Word 里回车敲出的空段继承上一段的段落属性）；
/// `page-setup` 为 `auto` 时取当前页面设置。
/// -> content
#let paragraph-mark(
  ..args,
  size: auto,
  font: auto,
  line-spacing: auto,
  spacing: 0pt,
  snap: auto,
  page-setup: auto,
  weak: false,
) = context {
  let layout = page-setup
  assert(
    args.pos().len() <= 1 and args.named().len() == 0,
    message: "unexpected argument",
  )
  let n = if args.pos().len() == 0 { 1 } else { args.pos().first() }
  assert(
    size == auto or (type(size) == length and size.em == 0),
    message: "size: expected absolute length such as zihao.xiaosi or 12pt, found " + repr(size),
  )
  let sz = if size == auto { text.size } else { size }
  let ls = _line-spacing-of(line-spacing)
  let lay = if layout != auto { layout } else if page-setup-state.get() == none { no-docgrid } else {
    _layout.current-page-setup()
  }
  let h = paragraph-mark-height(sz, font: font, line-spacing: ls, snap: _snap-of(snap), page-setup: lay)
  if weak {
    v(n * h, weak: true)
  } else {
    // 空块在 Typst 里不断 sticky 链（标题会越过它连着下一个标题一起换页）；Word 的空段是实段、断得开。
    // 放一个隐藏的零宽空格：不出字形、不进文字层，块就不算空
    for _ in range(n) { block(height: h, above: spacing, below: 0pt, hide(sym.zws)) }
  }
}
