// 启用 Word 编号列表规则时默认排成段，不悬挂；#enum-hanging 单次改回悬挂。
#import "../layout/chars.typ" as chars
#import "../content.typ": plain-text
#import "../options.typ": option-of
#import "../settings.typ": setting-of
#import "../numbering/state.typ": current-format
#import "../context.typ": enum-hanging-tag, numbering-bypass-tag, numbering-format-tag, numbering-indent-tag

// 列表开关随文字样式作用域传递，避免深层列表逐轮读取局部 state 栈。
// 与正文行盒相同，使用内部 feature 标签；不作为字体特性或公开配置。
#let _switch(key, default, tag) = {
  let now() = {
    let local = text.features.at(tag, default: none)
    if local != none { return local == 1 }
    let doc = option-of(key)
    if doc == auto { default } else { doc }
  }
  (
    once: (rules, ..args, body) => {
      let v = args.pos().at(0, default: true)
      if args.pos().len() > 1 or args.named().len() > 0 or v not in (auto, true, false) {
        panic(key + ": expected auto, true, or false, then the body, found " + repr(args.pos()))
      }
      if v == auto { block(body) } else {
        context {
          let installed = tag in text.features
          set text(features: text.features + ((tag): if v { 1 } else { 0 }))
          if installed { block(body) } else { rules(block(body)) }
        }
      }
    },
    install: (rules, doc) => context {
      let value = now()
      set text(features: text.features + ((tag): if value { 1 } else { 0 }))
      rules(doc)
    },
    now: now,
  )
}

#let _enum = _switch("enum-hanging", false, enum-hanging-tag)
#let _hanging = _enum.now

// _ref-gap）同一条判据。
#let _gap(num) = if plain-text(num).ends-with(regex("[）。．、）】」]")) { [] } else { " " }

#let _number-gap(num, format, first, body-indent, step, text-indent: auto) = {
  if body-indent != 0.5em { return h(body-indent) }
  let suffix = format.follow-number-with
  if suffix == "space" {
    return if format.space-advance == auto { [ ] } else { h(format.space-advance) }
  }
  if suffix == "nothing" { return [] }
  if suffix != "tab" { return _gap(num) }
  let first = if type(first) == dictionary { first.amount } else { first }
  let x = first.to-absolute() + measure(num).width
  let tab = format.numbering-tab-stop
  if text-indent != auto {
    let stops = (text-indent, tab).filter(stop => stop != auto and stop > x)
    if stops.len() > 0 { return h(stops.sorted().first() - x) }
  }
  h((if tab != auto and x < tab { tab } else { step * (calc.floor(x / step) + 1) }) - x)
}

// 与 Typst 0.15 的 numbering 计数符一致；非 full 模式按同类列表深度选择计数符，
// 保留第一个前缀和最后的后缀。函数编号在非 full 模式只接收当前编号。
#let _counting-symbol = regex("[1aAiIαΑ一壹あいアイא가ㄱ*١۱१১ক①⓵]")
#let _labeler(pattern, full) = {
  if full { return (..ns) => numbering(pattern, ..ns.pos()) }
  if type(pattern) == function { return (..ns) => numbering(pattern, ns.pos().last()) }
  let pieces = pattern.matches(_counting-symbol)
  let prefix = pattern.slice(0, pieces.first().start)
  let suffix = pattern.slice(pieces.last().end)
  (..ns) => {
    let values = ns.pos()
    let piece = pieces.at(calc.min(values.len() - 1, pieces.len() - 1))
    numbering(prefix + piece.text + suffix, values.last())
  }
}

// 原生 enum 维护父路径、倒序及显式编号。标记位置只写入该项已确定的编号；
// 不通过 state 递归计算父路径，八层列表也无需逐层收敛。
#let _item-label = state("docxtyp-enum-item-label", (depth: 0, label: []))
// Typst 会抑制原生 list body 首段的缩进（即使 all: true）。用无文字、零高的空段
// 和零间距先结束该首段，让实际文字按普通段落的首行/悬挂设置排版。
#let _paragraph-start() = {
  par(leading: 0pt, spacing: 0pt, text(size: 0pt, top-edge: 0pt, bottom-edge: 0pt, h(0pt)))
  v(0pt, weak: false)
}
#let _enum-rules(doc) = {
  show enum: it => context {
    if text.features.at(numbering-bypass-tag, default: 0) == 1 { return it }
    let hanging-layout = _hanging()
    if hanging-layout and text.features.at(numbering-format-tag, default: 0) == 0 { return it }
    let labeler = _labeler(it.numbering, it.full)
    let fields = it.fields().pairs().filter(((key, _)) => key not in ("children", "label")).to-dict()
    if hanging-layout {
      // 让原生 enum 排标签列和续行。把后缀／制表空当计入标签宽度，避免从标签 state
      // 反推 par.hanging-indent 后又改变该 state 的布局位置，深层嵌套也不产生反馈。
      if it.body-indent != 0.5em { return it }
      let format = current-format()
      let step = setting-of("default-tab-stop")
      if text.features.at(numbering-indent-tag, default: 0) == 1 {
        if fields.at("number-align", default: auto) not in (auto, left, start) {
          panic("numbering.text-indent: only left-aligned labels are supported")
        }
        // 固定原生文本列；零宽标签仅绘制编号并传入已确定的原生计数值。
        // 每项正文用首行内联留白处理越过制表位，续行仍由固定列负责；不反算 par.hanging-indent。
        let indent = if format.text-indent == auto { 0pt } else { format.text-indent }
        fields += (full: true, body-indent: indent - it.indent, numbering: (..ns) => {
          let num = labeler(..ns.pos())
          _item-label.update((depth: ns.pos().len() - 1, label: num))
          box(width: 0pt, align(left, num))
        })
        let items = it.children.map(item => enum.item(item.at("number", default: auto), context {
          set text(features: text.features + ((numbering-bypass-tag): 0))
          let num = _item-label.get().label
          let gap = _number-gap(num, format, it.indent, it.body-indent, step, text-indent: indent)
          let gap-width = if (format.follow-number-with == "space" and format.space-advance == auto) or gap == " " {
            measure(box(text(" "))).width
          } else { measure(gap).width }
          h(it.indent + measure(num).width + gap-width - indent) + item.body
        }))
        return {
          set text(features: text.features + ((numbering-bypass-tag): 1))
          enum(..fields, ..items)
        }
      }
      fields += (full: true, body-indent: 0pt, numbering: (..ns) => context {
        let num = labeler(..ns.pos())
        let raw-gap = _number-gap(num, format, it.indent, it.body-indent, step)
        let gap = if (format.follow-number-with == "space" and format.space-advance == auto) or raw-gap == " " {
          h(measure(box(text(" "))).width)
        } else { raw-gap }
        num + gap
      })
      let items = it.children.map(item => enum.item(item.at("number", default: auto), context {
        set text(features: text.features + ((numbering-bypass-tag): 0))
        item.body
      }))
      return {
        set text(features: text.features + ((numbering-bypass-tag): 1))
        enum(..fields, ..items)
      }
    }
    fields += (numbering: (..ns) => _item-label.update((depth: ns.pos().len() - 1, label: labeler(..ns.pos()))),
      full: true, indent: 0pt, body-indent: 0pt, spacing: 0pt)
    let first-line = par.first-line-indent
    let hanging = par.hanging-indent
    let given = it.indent != 0pt
    let items = it.children.map(item => enum.item(item.at("number", default: auto), context {
      set text(features: text.features + ((enum-hanging-tag): 0, (numbering-bypass-tag): 0))
      set par(first-line-indent: first-line, hanging-indent: hanging)
      let label = _item-label.get()
      let depth = label.depth
      let num = label.label
      let format = current-format()
      let gap = _number-gap(num, format, if given { it.indent } else { par.first-line-indent },
        it.body-indent, setting-of("default-tab-stop"))
      block(
        inset: (left: if not given and depth > 0 { chars.chars(2) } else { 0pt }),
        ..(if it.spacing != auto { (above: it.spacing, below: it.spacing) } else { (:) }),
        {
          set par(first-line-indent: (amount: it.indent, all: true)) if given
          _paragraph-start()
          parbreak()
          num + gap + item.body
        },
      )
    }))
    // 只让重建的容器走原生布局；item 内恢复开关值，复用已安装的规则。
    set text(features: text.features + ((numbering-bypass-tag): 1))
    enum(..fields, ..items)
  }
  doc
}

#let enum-rules(doc, _numbering: false, _text-indent: false) = context {
  set text(features: text.features + ((numbering-format-tag): 1)) if _numbering
  set text(features: text.features + ((numbering-indent-tag): 1)) if _text-indent
  (_enum.install)(_enum-rules, doc)
}

/// 局部切换编号列表的续行是否悬挂：`#enum-hanging[…]`、`#enum-hanging(false)[…]`。
/// 显式开关按需安装编号列表规则，无需先设置文档选项；`auto` 继承外层，离开作用域后恢复。
/// -> content
#let enum-hanging(..args, body) = (_enum.once)(enum-rules, ..args, body)
