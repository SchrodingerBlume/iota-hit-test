// 一个西文单词长到一行都放不下时插零宽断点；语言与自动断字交给原生 text 设置。
#let long-word-min = 22

// Typst 0.15 的分组深度上限为 256；预留其他嵌套后，每段最多插入 249 个断点。
#let _long-word-pieces = 250

#let long-word-chunks(cs) = {
  let k = calc.max(1, calc.ceil(cs.len() / _long-word-pieces))
  if k == 1 { return cs }
  range(0, cs.len(), step: k).map(i => cs.slice(i, calc.min(i + k, cs.len())).join())
}
