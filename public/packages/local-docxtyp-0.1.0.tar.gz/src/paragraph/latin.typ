// 纯西文行和段使用西文字体的单倍行高度量。

#import "./spacing.typ": spacing, zero-docgrid, latin-tracking
#import "../content.typ": plain-text
#import "../runs.typ": has-cjk
#import "../runs/regex.typ": latin-run
#import "../context.typ": latin-line-features
#import "./spacing.typ": spacing, latin-tracking, families-of

#let _primary-metric-symbols = regex("[\u{00D7}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}]")
#let _visible-ascii = regex("[!-~]")
#let _latin-letter = regex("\p{Latin}")
#let _ambiguous-punctuation = regex("[\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}]")

/// 单段 auto 路径是否采用 profile 的 latin 度量。非空文本不含 has-cjk 范围，且不含
/// ×、箭头及几何符号（U+2190–21FF、U+25A0–25FF）时返回 true。
/// 这是行盒策略建议，Arabic/Hebrew 等也可能返回 true，不检测 Latin 脚本或逐字字体槽。
/// par 的 auto 路径按该建议使用整段的主/latin 字体与度量；正文流兼容启发式另行处理。
/// -> bool
#let use-latin-metrics(s) = s.trim() != "" and not has-cjk(s) and not s.contains(_primary-metric-symbols)

// 正文流保留已有 ASCII 触发策略：要求可见 ASCII，排除 CJK；有歧义标点时还要求 Latin。
// 例如 Пример / Пример1、é / e+组合重音可能走不同分支。这不是纯 Latin 文本判定。
#let _use-latin-paragraph-metrics(s) = s.contains(_visible-ascii) and not has-cjk(s) and (
  s.contains(_latin-letter) or not s.contains(_ambiguous-punctuation)
)

// Word 行高取该行实际字体度量的最大值；两份摘要在相同段落设置下分别量得
// 纯西文 17.2500pt、含汉字 19.4531pt。
/// 逐片段给西文换行高：不贴网格时西文片段按西文字体的单倍行高，含汉字的行仍按中文。
/// `char-grid: false` 用于不吃字符网格增量的地方（页眉页脚）。
/// -> content
#let latin-line-rules(style, docgrid: zero-docgrid, char-grid: true, doc) = {
  let metrics = spacing(style, docgrid: docgrid, char-grid: char-grid)
  if metrics.snap { return doc }
  let l = spacing(style, docgrid: docgrid, latin: true)
  show smartquote: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  // 字符网格下由 paragraph/rules 的 latin-runs 连行高一起切：这里再切一刀就丢字距，只打标记
  if metrics.snap-h {
    set text(features: text.features + latin-line-features(true))
    doc
  } else {
    show latin-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
    doc
  }
}

/// 整段换成西文行高，不改字距；供纯西文的标题与题注使用。
/// -> content
#let latin-box(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  let l = spacing(style, docgrid: layout.docgrid, latin: true)
  set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 纯西文段整段使用西文字体行高；混排段只替换其中的西文片段。
#let latin-par(style, layout, doc) = {
  let metrics = spacing(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  let l = spacing(style, docgrid: layout.docgrid, latin: true)
  set text(tracking: latin-tracking(style, l))
  show regex("[\u{2018}\u{2019}\u{201C}\u{201D}\u{2014}\u{2026}\u{00B7}]"): set text(font: families-of(style, latin: true))
  latin-box(style, layout, doc)
}

#let _latin-by-text(style, layout, s, doc) = if _use-latin-paragraph-metrics(s) {
  latin-par(style, layout, doc)
} else {
  latin-line-rules(style, docgrid: layout.docgrid, doc)
}

#let latin-auto(style, layout, it) = _latin-by-text(style, layout, plain-text(it.body), it)

/// 不成 par 的一块字（格子里没分段的字）照正文逐段的规则换西文行高；块里分了段的各段自己判。
/// -> content
#let latin-block(style, layout, body) = {
  show par: it => latin-auto(style, layout, it)
  _latin-by-text(style, layout, plain-text(body), body)
}
