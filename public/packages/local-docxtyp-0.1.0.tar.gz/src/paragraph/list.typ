// 圆点列表（list）：默认照原生悬挂；list-hanging: false 排成段，与编号列表那一档同一个排法。
#import "../layout/chars.typ" as chars
#import "./enum.typ": _switch, _paragraph-start
#import "../context.typ": list-hanging-tag

#let _list = _switch("list-hanging", true, list-hanging-tag)

#let _marker(marker, depth) = {
  if type(marker) == array {
    if marker.len() == 0 { [] } else { marker.at(calc.rem(depth, marker.len())) }
  } else if type(marker) == function { marker(depth) } else { marker }
}

#let _item-marker = state("docxtyp-list-item-marker", (depth: 0, marker: []))
#let _list-rules(doc) = {
  show list: it => context {
    if (_list.now)() { return it }
    let fields = it.fields().pairs().filter(((key, _)) => key not in ("children", "label")).to-dict()
    fields += (marker: depth => _item-marker.update((depth: depth, marker: _marker(it.marker, depth))),
      indent: 0pt, body-indent: 0pt, spacing: 0pt)
    let first-line = par.first-line-indent
    let hanging = par.hanging-indent
    let given = it.indent != 0pt
    let items = it.children.map(item => list.item(context {
      set text(features: text.features + ((list-hanging-tag): 0))
      set par(first-line-indent: first-line, hanging-indent: hanging)
      let marker = _item-marker.get()
      let depth = marker.depth
      let dot = marker.marker
      block(
        inset: (left: if not given and depth > 0 { chars.chars(2) } else { 0pt }),
        ..(if it.spacing != auto { (above: it.spacing, below: it.spacing) } else { (:) }),
        {
          set par(first-line-indent: (amount: it.indent, all: true)) if given
          _paragraph-start()
          parbreak()
          dot + h(it.body-indent) + item.body
        },
      )
    }))
    set text(features: text.features + ((list-hanging-tag): 1))
    list(..fields, ..items)
  }
  doc
}

#let list-rules(doc) = (_list.install)(_list-rules, doc)

/// 局部切换项目符号列表的续行是否悬挂，用法同 `enum-hanging`。
/// 无需先设置文档列表选项；`auto` 继承外层，退出后恢复，且不改变编号列表的开关。
/// -> content
#let list-hanging(..args, body) = (_list.once)(list-rules, ..args, body)
