// 段落行盒的纯计算：输入字号、字体度量、行距和网格，不读取 state 或原生文字环境。
// 0.082pt 为既有中易／Times 目标度量与 Word 观测回归中的上升部补偿；固定值首行
// 按盒高 0.8 计算。沿用 compute.typ 及坐标回归的校准条件，不作为所有字体的原生属性。
#let _ascent-correction = 0.082pt
#let _exact-first-ratio = 0.8

#let _absolute(len, size) = len.abs + len.em * size
#let _max(a, b, size) = if _absolute(a, size) >= _absolute(b, size) { a } else { b }
#let _multiple-baseline-gap(k, coef, size, docgrid, snap) = {
  if not snap { return k * coef * 1em }
  let len = k * docgrid.line-pitch
  let floor = calc.ceil(coef * size / docgrid.line-pitch) * docgrid.line-pitch
  calc.max(len, floor)
}

#let _baseline-gap-endpoint(value, coef, size, docgrid, snap) = {
  if value == "single" {
    return (mode: "multiple", gap: _multiple-baseline-gap(1.0, coef, size, docgrid, snap))
  }
  if value == "double" {
    return (mode: "multiple", gap: _multiple-baseline-gap(2.0, coef, size, docgrid, snap))
  }
  if type(value) in (int, float) {
    return (mode: "multiple", gap: _multiple-baseline-gap(float(value), coef, size, docgrid, snap))
  }
  if type(value) == length { return (mode: "length", gap: value) }
  if type(value) == dictionary {
    if "exactly" in value { return (mode: "exactly", gap: value.at("exactly")) }
    if "at-least" in value {
      let given = value.at("at-least")
      let floor = if snap { docgrid.line-pitch } else { coef * 1em }
      if _absolute(given, size) >= _absolute(floor, size) { return (mode: "at-least", gap: given) }
      return (mode: "at-least", gap: floor)
    }
  }
  panic("expected number, length, or dictionary with \"exactly\" or \"at-least\", found " + repr(value))
}

#let _ascent-of(mode, baseline-gap, coef, size, snap, asc-coef) = {
  if mode == "exactly" { return _exact-first-ratio * baseline-gap }
  let ascent = asc-coef * 1em + _ascent-correction
  if not snap { return ascent }
  let center = (_absolute(baseline-gap, size) - coef * size) / 2
  ascent + center
}

#let line-box(size, metrics, line-spacing, docgrid, snap, native) = {
  let coef = metrics.single
  let (mode, gap: baseline-gap) = _baseline-gap-endpoint(line-spacing, coef, size, docgrid, snap)
  let ascent = _ascent-of(mode, baseline-gap, coef, size, snap, metrics.ascent)
  let ascent = if native and not snap and mode != "exactly" { ascent - _ascent-correction } else { ascent }
  // 固定值和裸长度直接指定行盒，不再与自然行高取最大值。既有 Word 小一 24pt、
  // exact 19pt 样本只占 19pt；倍数行距则保留自然行高下限。
  let natural = coef * 1em
  let box = if mode in ("exactly", "length") { baseline-gap } else { _max(baseline-gap, natural, size) }
  let ascent = if mode == "length" and _absolute(box, size) < _absolute(ascent, size) { box } else { ascent }
  let depth = box - ascent
  (
    size: size,
    single: coef * size,
    line-height: _absolute(box, size),
    baseline-gap: _absolute(baseline-gap, size),
    ascent: _absolute(ascent, size),
    depth: _absolute(depth, size),
    top-edge: ascent,
    bottom-edge: depth,
  )
}
