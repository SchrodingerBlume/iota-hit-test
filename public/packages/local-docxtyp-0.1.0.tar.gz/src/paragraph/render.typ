
#import "../paragraph/spacing.typ": indent, amount
#import "../fonts/size.typ": zihao
#import "./rules.typ" as style-rules
#import "../content.typ": plain-text
#import "../fonts/resolve.typ" as fonts
#import "../layout/resolve.typ" as _layout
#import "./latin.typ": use-latin-metrics
#import "../settings.typ": settings-state
#let _par = par

// Typst 会压缩的那几个全角开标点（typst-layout 的 shaping.rs 按码表判，不看 lang）；Word 段首不压，
// 前面垫一个零宽空格挡住。
/// 段前段后落到块上。Word 默认两段之间取前段段后与后段段前的较大者——块的 above／below，Typst 本来就
/// 合并取大；`html-paragraph-auto-spacing: false` 时两者相加：段后放进块里（inset），块间只剩段前。
/// 段、标题、图表凡按 Word 段距排的块都用它。必须在 context 中调用。
/// -> dictionary
#let block-spacing(above, below) = if settings-state.get().at("html-paragraph-auto-spacing", default: true) == false {
  (above: above, below: 0pt, inset: (bottom: below))
} else {
  (above: above, below: below, inset: (bottom: 0pt))
}

#let _open-puncts = ("（", "〔", "［", "｛", "〈", "《", "「", "『", "【")

#let _needs-zws(body) = {
  let s = plain-text(body)
  if s == none { return false }
  let cs = s.clusters()
  cs.len() > 0 and cs.first() in _open-puncts
}

// 封面、内封、声明页排的都是 Word 段，Word 段里没有行间公式这一档。
/// 把块级公式改排为行内：Word 段落中没有行间公式。
/// -> content
#let inline-math(body) = {
  show math.equation.where(block: true): it => math.equation(block: false, numbering: none, it.body)
  body
}

// leading 是 Typst 段内附加行间距；默认沿用行盒设置，不作为 Word“行距”的同义参数。
/// 按一条已解析样式排一个 Word 段落。实际字体、字号、行盒、字距、首行/悬挂缩进、
/// 对齐、段前段后和西文行高都由样式决定。
///
/// `page-setup: auto` 读取当前节；`metrics: auto` 或 `none` 使用给定字体的度量。
/// 显式 `metrics: (single:, ascent:)` 覆盖本段的目标度量，保留原字体和 features。
/// `above` 可临时覆盖段前；`at-page-start: true` 在页首用不可折叠间距保留段前。
/// `latin` 选择 profile 的 latin 字体/度量路径；`auto` 使用 paragraph.use-latin-metrics 的行盒策略。
/// 该判定不等同于 Word 完整字体槽或复杂文种选择。标题与题注应通过段落接口安装行盒。
/// `align` 接受 Typst 对齐值；`justify` 独立控制两端对齐。缺失时继承当前设置。
/// `left-indent` 缩小整段可用宽度；首行与悬挂缩进相对这条左缘计算。
/// `pagebreak-before: true` 先应用弱分页并保留段前；`sticky`、`breakable` 传给段落的
/// 外层 `block`。未指定后两项时继承原生块设置。
///
/// ```typ
/// #show heading.where(level: 1): it => par(
///   it.body, styles.heading-1,
///   at-page-start: true,
/// )
/// ```
/// -> content
#let par(
  body,
  format,
  page-setup: auto,
  metrics: auto,
  above: auto,
  at-page-start: false,
  leading: auto,
  latin: auto,
  rules: none,
) = {
  let style = format
  let layout = page-setup
  if layout == auto or metrics == auto {
    return context par(
      body, style,
      page-setup: if layout == auto { _layout.current-page-setup() } else { layout },
      metrics: if metrics == auto { none } else { metrics },
      above: above, at-page-start: at-page-start, leading: leading, latin: latin, rules: rules,
    )
  }
  if metrics != none {
    return context {
      let value = style.at("font", default: auto)
      let override = fonts.profile(fonts.family(value), metrics: metrics,
        latin: fonts.family(value, latin: true), latin-metrics: metrics, features: fonts.features(value))
      par(body, style + (font: override), page-setup: layout, metrics: none,
        above: above, at-page-start: at-page-start, leading: leading, latin: latin, rules: rules)
    }
  }
  // 藏在 context 后面的字读不到，那就按有汉字算——行里的西文 run 自会换西文行盒
  let latin = if latin != auto { latin } else {
    let words = plain-text(body)
    use-latin-metrics(words)
  }
  if type(at-page-start) != bool {
    panic("at-page-start: expected true or false, found " + repr(at-page-start))
  }
  let ind = indent(style, page-setup: layout)
  let before = amount(if above == auto { style.at("above", default: none) } else { above }, layout.docgrid)
  let break-before = style.at("pagebreak-before", default: false)
  if break-before { pagebreak(weak: true) }
  let at-page-start = at-page-start or break-before
  // `block.above` 在页首没有前项，会消失；调用方确认段落位于页首时改发不可折叠间距。
  if at-page-start and before != 0pt {
    v(before, weak: false)
  }
  let after = amount(style.at("below", default: none), layout.docgrid)
  context {
  let sp = block-spacing(if at-page-start { 0pt } else { before }, after)
  block(
    above: sp.above,
    below: sp.below,
    width: 100%,
    inset: (left: ind.at("left", default: 0pt), bottom: sp.inset.bottom),
    ..style.pairs().filter(((key, _)) => key in ("sticky", "breakable")).to-dict(),
    {
      show: style-rules.rules.with(style, page-setup: layout, set-font: true, latin: latin, rules: rules)
      show: inline-math
      _par(
        ..(if leading != auto { (leading: leading) } else { (:) }),
        (if style.at("align", default: align.alignment) != center and _needs-zws(body) { sym.zws }) + body,
      )
    },
  )
  }
}
