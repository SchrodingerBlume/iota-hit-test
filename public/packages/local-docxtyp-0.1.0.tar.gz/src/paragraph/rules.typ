// 样式落到 Typst 上：原生设置及显式度量的字距映射。

#import "../paragraph/latin.typ" as western
#import "../paragraph/spacing.typ": families-of, indent, spacing, tracking-of, amount, no-docgrid, latin-tracking, set-tracking
#import "../paragraph/hyphenate.typ" as hyphenate
#import "../layout/state.typ": layout-of
#import "./state.typ": format-of
#import "../runs/regex.typ": latin-ink-run, latin-mixed, cj-char, alnum-char
#import "../context.typ": latin-par-features, latin-line-tag, latin-line-features, list-context-features
#import "../context.typ": body-scope-tag, body-scope-features, body-scope-matches
#import "../context.typ": math-context-tag, math-context-features
#import "../format.typ": character-keys
#import "../fonts/resolve.typ" as fonts
#import "../layout/state.typ": page-setup-state

// 将 Word 段落属性换算后映射到 Typst 的 text 与 par set rule。

#let _text-sets(style, doc) = {
  // 只安装显式给出的属性，缺失值继承当前原生环境。
  set text(..style.pairs().filter(((key, _)) => key in character-keys and key not in ("font", "size", "tracking")).to-dict())
  doc
}

#let _par-sets(style, layout, doc) = {
  set align(style.align) if "align" in style
  set par(justify: style.justify) if "justify" in style
  if "first-line-indent" in style or "hanging-indent" in style {
    let ind = indent(style, docgrid: layout.docgrid)
    set par(first-line-indent: (amount: ind.first-line, all: true), hanging-indent: ind.hanging)
    doc
  } else { doc }
}

#let _native-sets(style, font, layout, scope, line-metrics, latin-par, doc) = {
  set text(
    size: style.at("size", default: text.size),
    tracking: style.at("tracking", default: text.tracking),
    features: text.features + fonts.features(style.at("font", default: auto)) + latin-par-features(latin-par)
      + if scope == auto { (:) } else { ((body-scope-tag): scope) + latin-line-features(line-metrics) },
    ..(if font != none { (font: font) } else { (:) }),
  )
  set par(spacing: calc.max(amount(style.at("above", default: none), layout.docgrid),
    amount(style.at("below", default: none), layout.docgrid))) if ("above" in style or "below" in style)
  _par-sets(style, layout, _text-sets(style, doc))
}

// 纯西文段直接使用半份字符网格间距，不安装中西文边界补偿。

// Word 按字符所占网格单元分配间距：全宽字符一份，半宽西文字符半份。

// latin：这一段全是西文——行盒按西文字体、字距半份（Word 半宽字占半格）。
#let _raw-edges(computed, doc) = {
  show raw.where(block: false): set text(
    top-edge: computed.top-edge.abs + computed.top-edge.em * computed.size,
    bottom-edge: -(computed.bottom-edge.abs + computed.bottom-edge.em * computed.size),
  )
  doc
}
#let _body-raw-edges(style, computed, layout, latin, scope, doc) = {
  show raw.where(block: false): it => context {
    if not body-scope-matches(scope) { return it }
    let actual = computed
    if scope == 1 {
      let current = format-of(style, true)
      let l = layout-of(layout, true)
      if current != style or l.docgrid != layout.docgrid {
        actual = spacing(current, docgrid: l.docgrid, latin: latin)
      }
    }
    _raw-edges(actual, it)
  }
  doc
}

#let sets(style, layout: no-docgrid, font: none, latin-par: false, latin: false, _scope: auto, _line-metrics: false, doc) = {
  let value = style.at("font", default: auto)
  if fonts.target(value, latin: latin) == none and not layout.docgrid.grid and "line-spacing" not in style {
    return _native-sets(style, font, layout, _scope, _line-metrics, latin-par, doc)
  }
  let computed = spacing(style, docgrid: layout.docgrid, latin: latin)
  set text(
    size: computed.size,
    top-edge: computed.top-edge,
    bottom-edge: -computed.bottom-edge,
    costs: (widow: 0%, orphan: 0%),
    tracking: if "tracking" not in style and not computed.snap-h { text.tracking } else {
      set-tracking(style, computed, latin: latin)
    },
    ..(if font != none { (font: font) } else { (:) }),
    features: fonts.features(value) + latin-par-features(latin-par)
      + latin-line-features(_line-metrics)
      + list-context-features(text.features) + math-context-features(text.features)
      + if _scope == auto { body-scope-features(text.features) } else { ((body-scope-tag): _scope) },
  )
  show: if _scope == auto { _raw-edges.with(computed) } else {
    _body-raw-edges.with(style, computed, layout, latin, _scope)
  }
  set par(
    leading: 0pt,
    spacing: calc.max(computed.above, computed.below),
  )
  _par-sets(style, layout, _text-sets(style, doc))
}

// 一个西文段里长到一行放不下的词：Word 在词内按字符断行，这里插零宽空格造断点。
#let _long-words(t, avail) = {
  let long(w) = w.clusters().len() >= hyphenate.long-word-min and measure(text(w)).width > avail
  let words = t.split(" ")
  if avail == 0pt or not words.any(long) { return t }
  words.map(w => if long(w) { hyphenate.long-word-chunks(w.clusters()).join("\u{200B}") } else { w }).join(" ")
}

// 字符网格下的西文段：字距半份（Word 半宽字占半格）、不贴网格时换西文行高、长词词内断。Typst 在 run 边界丢
// 前一个字的字距，插 h 补又顶掉它自己的中西文间距，所以整段在这里切开，交界的空当全由这里发：挨着中日文字
// 两侧都是整份字距 ＋ 1/4 字（Word 实测，见 tests/check-boundary.py），别的交界只补丢掉的那份。
/// 西文段的规则（通常经 `shows` 装上；正文那一条由 `document` 装在最里层，赶在别的切 run 规则之前）。
/// -> content
#let latin-runs(style, layout: no-docgrid, current: false, latin: false, _scope: none, doc) = {
  show math.equation: it => context {
    set text(features: text.features + ((math-context-tag): 1))
    it
  }
  show latin-mixed: it => context {
    if not body-scope-matches(_scope) { return it }
    let l = layout-of(layout, current)
    let style = format-of(style, current)
    let computed = spacing(style, docgrid: l.docgrid)
    if not computed.snap-h { return it }
    let full = tracking-of(computed, tracking: style.at("tracking", default: 0pt))
    let half = latin-tracking(style, computed)
    let latin-line = spacing(style, docgrid: l.docgrid, latin: true)
    let in-math = text.features.at(math-context-tag, default: 0) == 1
    let own-line = (
      not in-math and (text.top-edge == computed.top-edge or text.top-edge == latin-line.top-edge)
    )
    if not own-line or text.tracking != set-tracking(style, computed, latin: latin) { return it }
    let s = it.text
    if latin {
      let t = _long-words(s, l.text-width)
      return if t == s { it } else { t }
    }
    let runs = s.matches(latin-ink-run)
    if runs.len() == 0 { return it }
    let edges = if computed.snap or text.features.at(latin-line-tag, default: 0) != 1 { (:) } else {
      (top-edge: latin-line.top-edge, bottom-edge: -latin-line.bottom-edge)
    }
    let loss = fonts.boundary-loss()
    let spaced = text.cjk-latin-spacing == auto
    let cj(c) = c.match(cj-char) != none
    let alnum(c) = c.match(alnum-char) != none and not cj(c)
    let out = ()
    let pos = 0
    for (i, r) in runs.enumerate() {
      let first = r.text.clusters().first()
      let last = r.text.clusters().last()
      if r.start > pos {
        let lead = s.slice(pos, r.start)
        let e = lead.clusters().last()
        out.push(lead)
        // 西文段以空格起头时 weak 会顶掉那个空格
        out.push(if first == " " { h(full * loss) } else {
          h(full * loss + if spaced and cj(e) and alnum(first) { 0.25em } else { 0pt }, weak: true)
        })
      }
      out.push(text(tracking: half, ..edges, _long-words(r.text, l.text-width)))
      let stop = if i + 1 < runs.len() { runs.at(i + 1).start } else { s.len() }
      if stop > r.end and last != " " {
        let e = s.slice(r.end, stop).clusters().first()
        out.push(h(half * loss + if spaced and alnum(last) and cj(e) { 0.25em + full - half } else { 0pt }, weak: true))
      }
      pos = r.end
    }
    if pos < s.len() { out.push(s.slice(pos)) }
    out.join()
  }
  doc
}
#let _latin-runs = latin-runs

/// 为 selector 正则匹配的文字片段安装给定格式的行盒；选择哪些片段由调用方决定。
/// latin 为 true 时取 profile 的 latin 度量，否则取主度量。仅设置上下边界，
/// 不改字体、字号、字距或基线，不解释语言、字体槽及模板角色；贴网格时也按所给格式计算。
/// page-setup:auto 读取当前节，可显式传入 paragraph.no-docgrid。
/// -> content
#let run-metrics(format, selector, page-setup: auto, latin: false, body) = context {
  if type(selector) != regex { panic("run-metrics: expected a regex selector, found " + repr(selector)) }
  let computed = spacing(format, page-setup: page-setup, latin: latin)
  show selector: set text(top-edge: computed.top-edge, bottom-edge: -computed.bottom-edge)
  body
}

// 显式度量的文本片段与代码字距；模板可传入额外规则。
#let shows(style, layout: no-docgrid, current: false, latin: false, latin-runs: true, rules: none, _scope: none, doc) = {
  let value = style.at("font", default: auto)
  show: if rules == none { it => it } else { rules }
  if fonts.target(value, latin: latin) == none and layout.docgrid.tracking == 0pt { return doc }
  let installed = spacing(style, docgrid: layout.docgrid, latin: latin)
  let raw-rules(body) = if installed.snap-h {
    show raw: it => context {
      if not body-scope-matches(_scope) { return it }
      let style = format-of(style, current)
      let computed = spacing(style, docgrid: layout-of(layout, current).docgrid)
      let full-tracking = tracking-of(computed, tracking: style.at("tracking", default: 0pt))
      if text.tracking != full-tracking { it } else {
        if not it.block { h(full-tracking * fonts.boundary-loss()) }
        set text(tracking: latin-tracking(style, computed))
        it
      }
    }
    body
  } else {
    body
  }
  show: raw-rules
  let wanted = latin-runs and (current or installed.snap-h)
  if wanted { _latin-runs(style, layout: layout, current: current, latin: latin, _scope: _scope, doc) } else { doc }
}

// 两半叠起来：set 在外、show 在内。
/// 把一条样式落成 set 与 show 规则：字号、行盒、字距、缩进、对齐，以及西文片段的
/// 行高与字距补偿。文字的 `weight`、`style`、`lang`、`region`、`baseline` 直接传给 Typst；
/// `font` 接受原生 `text.font` 描述，显式值直接设置字体；`none` 不设置字体。
/// 默认 `font: auto` 时，仅在 `set-font: true` 下从样式解析字体；样式缺少 font 时继承 text.font，
/// 否则继承外层字体；带目标度量的 profile 放在样式的 `font` 中。
/// `latin: true` 选择该段的 latin 字体/度量路径；段落范围处理使用 paragraph.format。
/// 未指定的对齐、两端对齐和首行/悬挂缩进继承当前环境。`left-indent` 由外层段落容器
/// 使用 `paragraph.indent(...).left` 应用；本规则不额外包裹左侧留白。
/// -> content
#let rules(
  format,
  page-setup: no-docgrid,
  set-font: false,
  font: auto,
  latin: false,
  rules: none,
  body,
) = {
  let style = format
  let layout = page-setup
  let apply(font) = {
    show: sets.with(style, layout: layout, font: font, latin: latin)
    show: shows.with(style, layout: layout, latin: latin, rules: rules)
    body
  }
  if font != auto {
    return apply(font)
  }
  if set-font {
    context apply(families-of(style, latin: latin))
  } else {
    apply(none)
  }
}

// Word 的样式窗格：一条 = 字体对话框 + 段落对话框。
