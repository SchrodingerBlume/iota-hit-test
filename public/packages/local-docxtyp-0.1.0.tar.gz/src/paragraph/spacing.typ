// Word「段落」对话框「缩进和间距」那张卡的折算：一条样式（字号、行距、贴不贴网格……）在（indent）、字距（tracking-of）。

#import "../fonts/size.typ": zihao
#import "./metrics.typ": line-box
#import "../fonts/resolve.typ" as fonts
#import "../layout/state.typ": page-setup-state
#import "../units.typ": twips

/// 没有文档网格时的网格记录：跨度与字距增量均为 0。
/// -> dictionary
#let zero-docgrid = (
  line-pitch: 0pt, char-pitch: 0pt, tracking: 0pt,
  grid: false, line-unit: 0pt,
)

/// 没有文档网格的最简页面设置，供独立部件与测试使用。
/// -> dictionary
#let no-docgrid = (
  docgrid: zero-docgrid,
  size: 12pt,
  cells: 0,
  text-width: 0pt,
)

// 折成长度以后往下截到整缇，Word 存盘时就是这么干的。
/// 将段前、段后或图表空当折成长度。绝对长度原样返回；`(lines: n)` 乘当前网格行
/// 跨度，再按 Word 的方式向下截到整缇。没有文档网格时不要使用 `(lines:)`。
/// -> length
#let amount(value, docgrid) = {
  if value == none { return 0pt }
  if type(value) == length { return value }
  if type(value) == dictionary and "lines" in value {
    return twips(value.at("lines") * docgrid.line-unit, floor: true)
  }
  panic("expected length or dictionary with \"lines\", found " + repr(value))
}

#let _docgrid-of(layout) = if layout == none { zero-docgrid } else if layout == auto {
  let s = page-setup-state.get()
  if s == none { panic("no page setup in effect: pass page-setup: or docgrid:, or write the document-level show first") }
  s.docgrid
} else { layout.docgrid }

/// 将样式中的首行缩进、悬挂缩进和左缩进解析为长度。`(chars: n)` 按该样式字号加
/// 字符网格增量计算，不按文档基准字号计算。`page-setup: auto` 读取当前节；`none` 表示无网格。
/// -> dictionary
#let indent(style, page-setup: auto, docgrid: none) = {
  let layout = page-setup
  let docgrid = if docgrid != none { docgrid } else { _docgrid-of(layout) }
  let pick(v) = {
    if type(v) == length { return v }
    if type(v) == dictionary and "chars" in v {
      let n = v.at("chars")
      return n * 1em + n * docgrid.tracking
    }
    panic("expected length or dictionary with \"chars\", found " + repr(v))
  }
  let left = style.at("left-indent", default: none)
  let left = if left == none { 0pt } else { pick(left) }
  let first-line = style.at("first-line-indent", default: none)
  if first-line != none { return (first-line: pick(first-line), hanging: 0pt, left: left) }
  let hanging = style.at("hanging-indent", default: none)
  if hanging != none { return (first-line: 0pt, hanging: pick(hanging), left: left) }
  (first-line: 0pt, hanging: 0pt, left: left)
}

// snap-to-grid 就是 Word 段落对话框上「如果定义了文档网格，则对齐到网格」那一个勾，只管纵向。
#let _snap-of(style) = {
  let v = style.at("snap-to-grid", default: false)
  if type(v) != bool {
    panic(
      "snap-to-grid: expected a boolean (Word's \"snap to grid\" checkbox, vertical "
        + "only), found " + repr(v) + "; the character grid comes from the layout "
        + "(char-pitch), so delete the \"horizontal\" key",
    )
  }
  v
}

/// 计算发给 `text(tracking:)` 的字距：横向贴网格时加上字符网格增量，再加样式自身的字符间距。
/// -> length
#let tracking-of(metrics, tracking: 0pt) = {
  (if metrics.snap-h { metrics.docgrid.tracking } else { 0pt }) + tracking
}

/// 从样式的原生字体描述或显式 profile 取得字体；latin 选择 profile 的西文描述。
/// 缺少 font 或显式 auto 时继承当前 text.font，不读取模板字体表。
#let families-of(style, latin: false) = {
  let value = fonts.family(style.at("font", default: auto), latin: latin)
  if value == auto { text.font } else { value }
}

/// 将一条 Word 段落样式解析为 Typst 行盒度量。结果包含字号、单倍行高、基线间距、
/// `top-edge`、`bottom-edge`、段前段后、是否贴纵向网格以及横向网格增量。
///
/// `style` 至少应含 `size`；`line-spacing` 可写倍数、`"single"`、`"double"`、
/// `(exactly: 18pt)` 或 `(at-least: 18pt)`。`page-setup: auto` 读取当前节，显式 `docgrid`
/// 则直接计算；`metrics: auto` 从格式中的 profile 取度量，否则由原生字体边界估计。模板通常把样式交给
/// `par` 或文档规则；原生估计不是 Word 精确度量认证。
/// -> dictionary
#let spacing(style, page-setup: auto, docgrid: none, metrics: auto, char-grid: true, latin: false) = {
  let layout = page-setup
  let docgrid = if docgrid != none { docgrid } else { _docgrid-of(layout) }
  let size = style.at("size", default: zihao.xiaosi)
  let value = style.at("font", default: auto)
  let metrics = if metrics != auto and metrics != none { metrics } else { fonts.target(value, latin: latin) }
  let native = metrics == none
  let metrics = if not native { metrics } else {
    let family = families-of(style, latin: latin)
    let edge(top, bottom) = measure(text(font: family, size: size, top-edge: top, bottom-edge: bottom)[Hg]).height
    let a = edge("ascender", "baseline")
    let d = edge("baseline", "descender")
    (single: (a + d) / size, ascent: a / size)
  }
  let snap = _snap-of(style) and docgrid.grid and docgrid.line-pitch != 0pt
  let snap-h = char-grid and docgrid.tracking != 0pt and docgrid.at("linebreaks", default: none) == none

  let line-spacing = style.at("line-spacing", default: 1)
  if line-spacing == auto {
    panic("line-spacing: auto reached resolve unresolved; call resolve-toc-line-spacing first")
  }
  let box = line-box(size, metrics, line-spacing, docgrid, snap, native)
  (
    ..box,
    above: amount(style.at("above", default: none), docgrid),
    below: amount(style.at("below", default: none), docgrid),
    snap: snap,
    snap-h: snap-h,
    docgrid: docgrid,
    native: native,
  )
}

// Word 行高取该行实际字体度量的最大值，因此纯西文行与含汉字行可能采用不同单倍行高。
// 两份摘要的段落设置相同，Word PDF 中纯西文行为 17.2500pt，含汉字行为
// 19.4531pt；这两个观测值分别对应 Times 1.15 与中易 1.296875 的单倍行高。


// Word 按字符所占网格单元分配间距：全宽字符一份，半宽西文字符半份。
#let latin-tracking(style, computed) = (
  (if computed.snap-h { computed.docgrid.tracking / 2 } else { 0pt })
    + style.at("tracking", default: 0pt) / 2
)

// 这一档 set 给正文的字距：全是西文的段是半份，别的是整份。
#let set-tracking(style, computed, latin: false) = if latin {
  latin-tracking(style, computed)
} else {
  tracking-of(computed, tracking: style.at("tracking", default: 0pt))
}
