// 当前已解析的有效格式栈；文档默认属性和 Typst 安装快照由各自模块持有。
#import "../document/state.typ" as _document
#let format-state = state("docxtyp-effective-format", none)
#let current-format() = {
  let value = format-state.get()
  if value == none { _document.defaults-state.get() } else { value.format }
}
#let format-of(value, current) = if current { current-format() } else { value }
