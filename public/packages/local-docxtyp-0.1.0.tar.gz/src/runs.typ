// 文本范围与字素统计；不解释语言、字体槽或模板字体角色。
#import "./runs/spaces.typ": adjust-spaces

#let _han = regex("\\p{Han}")
/// 判断字符串是否含汉字（Unicode 脚本 `Han`）。
/// -> bool
#let has-han(value) = value.contains(_han)

// 范围正则按码点匹配，整串扫描一次，不将字素拆成单码点转换或反复编译正则。
#let _cj-range = (
  "\u{3000}-\u{30FF}\u{31F0}-\u{31FF}\u{3400}-\u{4DBF}\u{4E00}-\u{9FFF}"
    + "\u{F900}-\u{FAFF}\u{FF00}-\u{FFEF}\u{20000}-\u{2FA1F}"
)
#let _hangul-range = "\u{1100}-\u{11FF}\u{3130}-\u{318F}\u{AC00}-\u{D7AF}"
#let _cj = regex("[" + _cj-range + "]")
#let _cjk = regex("[" + _cj-range + _hangul-range + "]")
#let _latin = regex("\p{Latin}")

/// 检查项目使用的 CJ 码点范围（常用及扩展汉字、假名、标点、全角／半角形式）。
/// 用于内容接缝等操作；不是完整 Unicode 脚本检测，也不选择字体或推断语言。
/// -> bool
#let has-cj(s) = s.contains(_cj)

/// 检查 has-cj 的范围再加谚文。它不是 Word 字体槽分类或 Unicode East_Asian_Width；
/// 例如全角拉丁字母也在范围内。具体范围见实现，不保证覆盖所有 Unicode 扩展区。
/// -> bool
#let has-cjk(s) = s.contains(_cjk)

// 比例按字素统计；组合附加符不单独计数，预组合和分解形式的拉丁字母等价。
/// 字符串中 `has-cjk` 范围的字素在“东亚字符 ＋ 拉丁字母”里的占比。
/// 拉丁字母按 Unicode 脚本 `Latin` 判定；东亚范围优先，每个字素最多计一次，其他字符不进入分母。
/// 这是模板提示用的字符比例，不设置或推断 `text.lang`。
/// -> float
#let cjk-ratio(s) = {
  let cjk = 0
  let latin = 0
  for ch in s.clusters() {
    if has-cjk(ch) { cjk += 1 } else if ch.contains(_latin) { latin += 1 }
  }
  if cjk + latin == 0 { 0.0 } else { cjk / (cjk + latin) }
}
