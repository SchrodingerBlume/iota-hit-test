// 文本切分与字符匹配正则；Typst 规则作用域协议见 ../context.typ。

// 行盒用的 Latin 触发片段，至少含一个拉丁字母，周围匹配当前有限字符范围；不是完整脚本分段。
// 用于西文行高（没有字符网格时）与断字。字符网格下的字距不走它，
// 走 `latin-mixed`（paragraph/rules.typ 的 latin-runs），那边连数字一起切。
// -> regex
#let latin-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "\p{Latin}"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 字符网格下的西文由 latin-runs 一条规则整段处理：Typst 在 run 边界丢前一个字的字距（typst/typst#5353），
// 插 h 补又会顶掉它自己的中西文间距，所以含字母或数字的整段文字交给它一次切开、交界的空当由它发。
// 私用区（模板的记号）、U+2060 与引号（regex 跨过 smartquote 会把它还原成直引号）不跨过。
// 匹配的上下文可含其他脚本，不作为纯 Latin 判定或通用字体路由。
// -> regex
#let latin-mixed = regex("[^\p{Co}\u{2060}\"'\n]*[0-9\p{Latin}][^\p{Co}\u{2060}\"'\n]*")
// Typst 的中西文间距只加在中日文字（不含标点）与字母、数字之间，交界两侧照这个判。
// -> regex
#let cj-char = regex("^[\p{Han}\p{Hiragana}\p{Katakana}]$")
// -> regex
#let alnum-char = regex("^[\p{L}\p{N}]$")

// 同 latin-run 的字符集，额外包含纯数字，用于西文网格字距；
// latin-runs 按它切西文段（Word 里数字与字母一样是半宽字，字距取半份）。
// -> regex
#let latin-ink-run = regex(
  "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  + "[0-9\p{Latin}]"
  + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
)

// 同一个字符集，不要求有字母也不要求有数字：页眉页脚里「- 3 -」这种行也按西文行盒。
// 引号不在字符集里（U+0022、U+0027）：regex show 跨过 smartquote 会把它还原成直引号。
// -> regex
#let latin-any-run = regex("[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]+")
