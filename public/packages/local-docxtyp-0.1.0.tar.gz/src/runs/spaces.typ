// 特殊空白的显式宽度增量和断行适配；保留原字符，不测量或替换为固定字宽。
#let _supported = ("\u{2002}", "\u{2009}", "\u{202F}")

/// 在给定内容内调整 en-space、thin-space、窄 NBSP 的宽度和断行机会。
///
/// `rules` 按原字符索引字典；每条须显式给出布尔 `breakable`，可给出长度 `adjust`（默认 0pt）。
/// adjust 为有符号增量，支持 pt/em 等长度，不接受相对版心的百分比或 fr。
/// breakable=true 在该空白及其修正后提供断行机会；false 将空白与两侧内容连接。
/// 不内置 Word 字宽或字体规则；调用方按字体、字号和源上下文提供经验证的数据。
/// 原字符继续参与原生塑形；仅添加原生水平间距及不可见的断行控制，不改变字体、字号或 kerning。
/// 可在布局前从返回内容提取原始文本；渲染结果可能包含辅助的不可见控制字符。
/// -> content
#let adjust-spaces(body, rules: (:)) = {
  if type(rules) != dictionary { panic("runs.adjust-spaces: rules must be a dictionary") }
  if rules.len() == 0 { return [#body] }
  let normalized = (:)
  for (char, rule) in rules {
    if char not in _supported { panic("runs.adjust-spaces: unsupported space " + repr(char)) }
    if type(rule) != dictionary { panic("runs.adjust-spaces: each rule must be a dictionary") }
    for key in rule.keys() {
      if key not in ("adjust", "breakable") { panic("runs.adjust-spaces: unknown rule key " + repr(key)) }
    }
    let amount = rule.at("adjust", default: 0pt)
    if type(amount) != length { panic("runs.adjust-spaces: adjust must be a length") }
    let breakable = rule.at("breakable", default: none)
    if type(breakable) != bool { panic("runs.adjust-spaces: breakable must be explicit true or false") }
    normalized.insert(char, (adjust: amount, breakable: breakable))
  }
  let pattern = regex("[" + normalized.keys().join("") + "]")
  // 控制字符不应以首选字体的 cap-height 抬高原行盒，尤其是使用 covers 的混合字体。
  let joiner = text(top-edge: 0pt, bottom-edge: 0pt, baseline: 0pt, "\u{2060}")
  let opportunity = text(top-edge: 0pt, bottom-edge: 0pt, baseline: 0pt, "\u{200B}")
  show pattern: it => {
    let rule = normalized.at(it.text)
    // 让修正跟随原空白，断行只能发生在整个适配之后；零增量时仍按要求处理断行。
    (if not rule.breakable { joiner } else { [] }) + it + joiner + h(rule.adjust) + (
      if rule.breakable { opportunity } else { joiner })
  }
  [#body]
}
