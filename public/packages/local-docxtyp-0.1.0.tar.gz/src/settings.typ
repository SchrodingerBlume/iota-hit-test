// 文档级有效设置；不接收编号级别属性或模板策略。
#import "./errors.typ" as errors
#let setting-defaults = (
  html-paragraph-auto-spacing: true,
  adjust-line-height-in-table: false,
  default-tab-stop: 21pt,
)
#let settings-state = state("docxtyp-settings", setting-defaults)

/// 创建 document(settings:) 的文档设置。auto 或省略不覆盖当前值。
/// html-paragraph-auto-spacing 控制相邻段距合并／相加；adjust-line-height-in-table
/// 控制单元格是否遵循段落的纵向网格设置；default-tab-stop 为正的绝对长度。
/// 未指定默认制表间距时使用本实现缺省 21pt，不代表所有 Word 文档的缺省值。
/// -> dictionary
#let settings(..args) = {
  if args.pos().len() > 0 { panic("settings: expected named arguments only") }
  for (key, value) in args.named() {
    if key not in setting-defaults {
      panic("unknown setting: " + key + "; " + errors.expected-one-of(setting-defaults.keys(), key))
    }
    if value == auto { continue }
    if key == "default-tab-stop" {
      if type(value) != length or value.em != 0 { panic(key + ": expected an absolute length or auto") }
      if value <= 0pt { panic(key + ": expected a positive absolute length or auto") }
    } else if type(value) != bool { panic(key + ": expected auto, true, or false") }
  }
  args.named().pairs().filter(((_, value)) => value != auto).to-dict()
}
#let settings-overrides(value) = settings-state.update(old => old + settings(..value))
#let setting-of(key) = settings-state.get().at(key)
