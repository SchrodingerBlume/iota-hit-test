// 内容最小宽度约束下的列宽适配；不解析 OOXML，不读取字体或排版状态。

#let _length(value, where) = {
  if type(value) != length or value.em != 0 or value < 0pt or value.pt() >= calc.inf {
    panic(where + ": expected a finite nonnegative absolute length")
  }
  value
}

#let _vector(value, count, where, default: 0pt) = {
  if value == auto { return range(count).map(_ => default) }
  if type(value) != array or value.len() != count {
    panic(where + ": expected one length per column")
  }
  value.enumerate().map(((i, v)) => _length(v, where + "[" + str(i) + "]"))
}

#let _raise-span(values, preferred, x, colspan, required) = {
  let end = x + colspan
  let deficit = required - values.slice(x, end).sum()
  if deficit <= 0pt { return values }
  let weights = preferred.slice(x, end)
  let total = weights.sum()
  for i in range(x, end) {
    let share = if total == 0pt { 1 / colspan } else { preferred.at(i) / total }
    values.at(i) += deficit * share
  }
  values
}

/// 根据内容最小宽度适配原生表格列宽。`preferred` 是绝对长度数组；`width: auto`
/// 使用其总宽。`minimum` 是不能突破的列下限，`protected` 是尽量保持的列下限：
/// 空间紧张时先缩其他列，再在保护要求之间分配剩余空间。
///
/// `spans` 接受 `(x:, colspan:, minimum:, protected:)`，用于合并单元格约束。
/// 超出目标宽度的硬下限保留，并在 `overflow` 中报告。合并约束按初始列宽比例分摊；
/// 这是确定性的近似分配，不实现 Word 的完整自动适应算法。
///
/// 返回 `columns`、实际 `width`、`minimum-width`、相对目标的 `overflow`。
/// 字体测量、单元格边距以及源文档属性的解释由调用方完成。
/// -> dictionary
#let fit-columns(preferred, width: auto, minimum: auto, protected: auto, spans: ()) = {
  if type(preferred) != array or preferred.len() == 0 {
    panic("fit-columns: expected a nonempty array of preferred column widths")
  }
  let count = preferred.len()
  let preferred = _vector(preferred, count, "fit-columns.preferred")
  if preferred.sum() == 0pt { panic("fit-columns.preferred: total width must be positive") }
  let target = if width == auto { preferred.sum() } else { _length(width, "fit-columns.width") }
  let minimum = _vector(minimum, count, "fit-columns.minimum")
  let protection = _vector(protected, count, "fit-columns.protected")
  if type(spans) != array { panic("fit-columns.spans: expected an array") }
  for span in spans {
    if type(span) != dictionary or "x" not in span or "colspan" not in span {
      panic("fit-columns.spans: expected (x:, colspan:, minimum:, protected:)")
    }
    if span.keys().any(k => k not in ("x", "colspan", "minimum", "protected")) {
      panic("fit-columns.spans: unknown constraint key")
    }
    if type(span.x) != int or type(span.colspan) != int or span.x < 0 or span.colspan < 1 or span.x + span.colspan > count {
      panic("fit-columns.spans: cell range is outside the column grid")
    }
    let value = _length(span.at("minimum", default: 0pt), "fit-columns.spans.minimum")
    let _ = _length(span.at("protected", default: 0pt), "fit-columns.spans.protected")
    minimum = _raise-span(minimum, preferred, span.x, span.colspan, value)
  }
  protection = protection.zip(minimum).map(((p, m)) => calc.max(p, m))
  for span in spans {
    protection = _raise-span(protection, preferred, span.x, span.colspan, span.at("protected", default: 0pt))
  }
  let min-total = minimum.sum()
  let lower = minimum
  if min-total < target {
    let extra = protection.sum() - min-total
    let factor = if extra == 0pt { 1 } else { calc.min(1, (target - min-total) / extra) }
    lower = minimum.zip(protection).map(((m, p)) => m + factor * (p - m))
  }
  let columns = preferred.zip(lower).map(((p, m)) => calc.max(p, m))
  if min-total >= target {
    columns = minimum
  } else if columns.sum() > target + 0.0001pt {
    let capacity = columns.zip(lower).map(((v, m)) => v - m)
    let total = capacity.sum()
    let excess = columns.sum() - target
    columns = columns.zip(capacity).map(((v, c)) => v - excess * (c / total))
  } else if columns.sum() < target - 0.0001pt {
    let extra = target - columns.sum()
    columns = columns.zip(preferred).map(((v, p)) => v + extra * (p / preferred.sum()))
  }
  let overflow = columns.sum() - target
  (columns: columns, width: columns.sum(), minimum-width: min-total,
    overflow: if overflow > 0.0001pt { overflow } else { 0pt })
}
