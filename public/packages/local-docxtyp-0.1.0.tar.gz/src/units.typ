// Typst 的 pt 与 Word 界面中的磅相同，均为 1/72 英寸。

/// 一个缇（twip），即 1/20 磅。
/// -> length
#let twip = 0.05pt

/// 按 Word 的存储规则将绝对长度量化为整缇。
///
/// 厘米按 567 twips/cm 换算；以磅输入的数按 20 twips/pt 换算。`floor: true`
/// 用于 Word 会截断而非四舍五入的“行数”计算。
/// -> length
#let twips(value, floor: false) = {
  if type(value) != length {
    panic("twips: expected absolute length (pt or cm), found " + repr(value))
  }
  if value.em != 0 {
    panic("twips: expected absolute length (pt or cm), found " + repr(value) + " (em is relative)")
  }
  if floor { return calc.floor(value / twip + 0.0001) * twip }
  let near(a, b) = calc.abs(a - b) < 1e-6
  let pt = value.pt()
  let cm = value.cm()
  let n = if near(pt, calc.round(pt, digits: 2)) {
    calc.round(pt, digits: 2) * 20
  } else if near(cm, calc.round(cm, digits: 2)) {
    calc.round(cm, digits: 2) * 567
  } else {
    pt * 20
  }
  calc.round(n) * twip
}

/// 一个 English Metric Unit（EMU）。OOXML 使用 EMU 记录绘图尺寸。
/// -> length
#let emu = 1pt / 12700
