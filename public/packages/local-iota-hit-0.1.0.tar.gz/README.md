# iota-hit

iota-hit 是 hithesis 的姊妹项目，为哈尔滨工业大学学位论文与阶段报告提供 Typst 模板。版式依据学校规范、范例和 Word 表单实现。

项目仍处于 `0.1.0` 阶段。提交前请以所在院系当年的要求和实际打印结果为准。

## 支持范围

- 本科、硕士、博士；
- 学位论文、本科毕业设计、研究生实践成果；
- 终稿、开题报告、中期报告；
- 哈尔滨本部与深圳校区的阶段报告；
- 中文论文和英文论文；
- 理工类与人文社科类的章节编号。

## 环境与安装

模板要求 Typst 不低于 `0.15.0`（回归基线在 `0.15.1` 上生成），并依赖本地包 `banshi:0.1.0` 和 `omni-gb7714:0.1.0`。Windows 字体组合与标定样张最接近。

本仓库尚未发布到 Typst Universe。请把三个仓库复制或链接到 Typst 的本地包目录。macOS 的目录结构如下：

```text
~/Library/Application Support/typst/packages/local/
  banshi/0.1.0/
  iota-hit/0.1.0/
  omni-gb7714/0.1.0/
```

之后即可导入：

```typst
#import "@local/iota-hit:0.1.0": *
```

仓库中的模板使用相对路径导入，适合直接在源码树内调试。

## 快速开始

```typst
#import "@local/iota-hit:0.1.0": *

#show: iota-hit.with(
  degree-level: "doctor",
  title: [论文题目#en[English Title]],
  author: [张三#en[San Zhang]],
  supervisor: [李四 教授],
  date: "2026-06",
)

#show: frontmatter
#cover()
#titlepage()
#abstract(keywords: ([关键词一#en[keyword one]], [关键词二#en[keyword two]]))[
  中文摘要。
  #en[English abstract.]
]
#table-of-contents()

#show: mainmatter
= 绪论#en[Introduction]

正文。

#bibliography(read("refs.bib"), full: true)
#conclusion[结论。]
#acknowledgement[致谢。]
#declarations()
```

```sh
typst compile main.typ
```

建议从与自己的文档类型最接近的文件开始改：

- `template/example.typ`：完整学位论文；
- `template/proposal-example.typ`：本部研究生开题报告；
- `template/shenzhen-bachelor-proposal-example.typ`：深圳本科开题报告；
- `template/shenzhen-bachelor-interim-example.typ`：深圳本科中期报告；
- 文件名带 `-en` 的版本：英文报告。

## 选择文档类型

文档类型由几个独立参数组成：

| 参数 | 常用值 | 默认值 | 含义 |
|---|---|---|---|
| `degree-level` | `"bachelor"`、`"master"`、`"doctor"` | `"doctor"` | 学位层次 |
| `degree-type` | `"academic"`、`"professional"` | `auto` | 学术或专业学位；本科忽略 |
| `form` | `"dissertation"`、`"practice"` | `"dissertation"` | 学位论文或实践成果 |
| `stage` | `"final"`、`"proposal"`、`"interim"` | `"final"` | 终稿、开题或中期 |
| `campus` | `"harbin"`、`"shenzhen"` | `"harbin"` | 校区 |
| `category` | `"stem"`、`"hass"` | `"stem"` | 理工或人文社科 |
| `lang` | `"zh"`、`"en"` | `"zh"` | 文档主语言 |

`form: "design"` 是本科毕业设计的兼容写法，等同于 `"practice"`；`"thesis"` 是 `"dissertation"` 的别名。

研究生实践成果必须配专业学位：

```typst
#show: iota-hit.with(
  degree-level: "master",
  degree-type: "professional",
  form: "practice",
  practice-type: [产品设计报告],
)
```

阶段与成果形式相互独立。例如，实践成果也可以有开题报告：

```typst
#show: iota-hit.with(
  degree-level: "master",
  form: "practice",
  stage: "proposal",
)
```

## 组织文档

用 `frontmatter`、`mainmatter` 和 `backmatter` 切换页面设置与页码：

```typst
#show: frontmatter
#cover()
#titlepage()
#abstract[摘要正文]
#table-of-contents()

#show: mainmatter
= 第一章

#show: backmatter
#conclusion[结论正文]
```

`backmatter` 默认沿用正文的页码和页眉。附录使用 `#show: appendix`，模板会同步调整标题、图号、表号和公式号。

## 元信息

常用元信息直接写在 `iota-hit.with(...)` 中：

```typst
#show: iota-hit.with(
  title: [中文题目#en[English Title]],
  subtitle: [副题目],
  author: [作者],
  student-id: [学号],
  supervisor: [导师#en[Prof. Supervisor]],
  co-supervisor: [副导师],
  industry-supervisor: [行业导师],
  speciality: [学科或专业#en[Speciality]],
  affiliation: [所在单位#en[School of …]],
  degree-applied: [工学博士#en[Doctor of Engineering]],
  defense-date: "2026-06",
  date: "2026-06",
)
```

双语只有一种写法：英文那半写在 `#en[...]` 里，标题、题注、元信息、摘要、关键词都一样；英文档反过来用 `#zh[...]`。没写 `#en` 的字段，英文内封印同一份内容。日期字符串接受 `YYYY`、`YYYY-MM` 或 `YYYY-MM-DD`，两种语言各自排；若需完全自定义显示文字，请传内容，例如 `[二〇二六年六月#en[June 2026]]`。

长内容（摘要）里 `#en[...]` 可以拆开写：段落跟着中文走——两个 `#en` 之间中文分了段，英文也分段，否则接成同一段；接缝两侧都是中日文字才不留空格。只扫最外层，嵌在列表、引用块里的 `#en` 不认。

## 标题与目录

原生标题语法可以直接使用：

```typst
= 绪论#en[Introduction]
== 研究背景#en[Background]
=== 国内外研究现状#en[Related work]
```

也可以调用 `chapter`、`section`、`subsection` 和 `subsubsection`。函数形式适合临时关闭编号或控制章前换页：

```typst
#chapter(numbering: none)[结论]
#chapter(openright: false)[补充说明]
```

博士论文默认生成中英文目录，本科和硕士默认只生成中文目录。英文标题由 `#en[...]` 提供；目录、索引页的标题同理：`table-of-contents(title: [目录#en[Contents]])`。

## 图、表与题注

普通图表沿用 Typst 的 `figure`：

```typst
#figure(
  image("figure.png", width: 70%),
  caption: [系统结构#en[System architecture]],
) <fig:system>

如@fig:system 所示。
```

博士论文默认使用双语题注；本硕默认只排中文。三线表直接放进 `figure`：

```typst
#figure(
  table(
    columns: 3,
    table.header([参数], [数值], [单位]),
    [$p$], [1.0], [MPa],
  ),
  caption: [试验参数],
) <tab:params>
```

续表或续图要拆成多个 `figure`，后续部分的题注写 `#continued()`。组图使用 `subs(...)`，完整示例见 `examples/captions.typ`。

## 公式与符号说明

公式按章编号，并使用全角括号：

```typst
$ E = m c^2 $ <eq:energy>

#eqdenote[
  / $E$: 能量，J；
  / $m$: 质量，kg；
  / $c$: 真空光速，m/s。
]
```

`increment` 表示有限增量符号 `∆`（U+2206），用于区分希腊字母 `Δ`。

### 定理环境

与 hithesis 相同的十三个环境：`theorem`、`lemma`、`definition`、`proposition`、`corollary`、`axiom`、`assumption`、`example`、`remark`、`problem`、`conjecture`、`fact`、`exercise`，以及不编号的 `proof`。头用黑体（英文加粗），头后空一个字，正文段不另加上下间距；编号与公式一样按章（开题、中期报告只数序号），各环境各自计数；附录里「附」字与图表一样挂在名前（附推论1.1）；空格同题注，前一截末字是西文才空（定理1.1 勾股、Theorem 1.1）。

```typst
#theorem(note: [勾股])[
  直角三角形两直角边的平方和等于斜边的平方。
] <thm:gougu>
#proof[略。]

由@thm:gougu 可知……  // 定理1.1
```

`note` 是 LaTeX 定理环境的可选参数，跟在编号后面。引用时 `@thm:gougu[]` 只印编号，`@thm:gougu[定理]` 换叫法；证明不能引用。词条在 `theorem` 桶里，可用 `overrides: (theorem-remark: [注])` 改字面。

可调的四处，写法同别处：

```typst
#show: iota-hit.with(
  theorem-numbering-by-chapter: false,      // 只数序号；默认终稿按章、开题中期不按
  theorem-body-indent: (chars: 2),          // 头后空多少，同 heading-body-indent
  styles: (
    theorem: (
      head: (asian-font: "kaishu", bold: true),   // 头只收字体那几个键
      body: (above: (lines: 1), below: 6pt),      // 定理段的段落样式，默认跟 body、上下 0
    ),
  ),
)
```

完整示例见 `examples/theorems.typ`。

## 符号表与缩略语

```typst
#list-of-symbols[
  / $p$: 气膜压力，Pa
  / $h$: 气膜厚度，m
]

#list-of-abbreviations(
  FEM: (
    long: "有限元方法",
    long-en: "Finite Element Method",
  ),
)
```

正文中写 `@FEM`。首次出现时模板展开全称，后续只显示缩写。`nomenclature(...)` 可把符号和缩略语合并到一页。

## 参考文献与成果

参考文献由 `omni-gb7714` 排版：

```typst
#bibliography(read("refs.bib"), full: true)
```

它的选项通过 `gb7714` 原样传递：

```typst
#show: iota-hit.with(
  gb7714: (style: "author-date", cite-form: "super"),
)
```

攻读学位期间取得的成果使用独立的 `.bib` 文件：

```typst
#achievements(read("achievements.bib"))
```

分组示例见 `template/example.typ`。

## 其他前后置页面

这些页面按需调用：

| 函数 | 用途 |
|---|---|
| `list-of-figures()` | 插图索引 |
| `list-of-tables()` | 表格索引 |
| `list-of-equations()` | 公式索引 |
| `declarations()` | 原创性声明与使用授权 |
| `defense()` | 博士论文评阅、答辩名单与决议 |
| `achievements(...)` | 攻读学位期间取得的成果 |
| `resume[...]` | 个人简历 |
| `index()` | 索引页；正文用 `idx[...]` 登记词条 |

同一页面通常只能生成一次；互斥的页面组合会在编译时给出错误。页面的局部参数以编辑器补全和 `lib.typ` 的悬停文档为准。

## 公开 API 索引

| 名称 | 用途 |
|---|---|
| `iota-hit` | 文档级 show 规则 |
| `frontmatter`、`mainmatter`、`backmatter`、`appendix` | 切换文档分区 |
| `clear-page` | 结束当前页，并按需补齐右页 |
| `new-layout`、`restore-layout` | 临时替换和恢复页面设置 |
| `layout-of`、`current-layout`、`msword-layout` | 查询或构造页面设置 |
| `new-styles`、`restore-styles` | 临时替换和恢复样式 |
| `cover`、`titlepage`、`abstract` | 封面、题名页和摘要 |
| `table-of-contents`、`list-of-figures`、`list-of-tables`、`list-of-equations` | 目录和各类索引 |
| `list-of-symbols`、`list-of-abbreviations`、`nomenclature` | 符号表和缩略语表 |
| `chapter`、`section`、`subsection`、`subsubsection` | 各级标题 |
| `en`、`zh`、`tocbreak` | 标出另一种语言的那一半，和目录专用换行 |
| `subs`、`subfigure`、`continued` | 分图、组图和续排 |
| `lovelace`、`algorithmic` | 伪代码 |
| `eqdenote`、`increment` | 公式符号说明和有限增量符号 |
| `theorem`、`lemma`、`definition`、`proposition`、`corollary`、`axiom`、`assumption`、`example`、`remark`、`problem`、`conjecture`、`fact`、`exercise`、`proof` | 定理环境 |
| `bibliography`、`idx`、`index` | 参考文献和索引 |
| `conclusion`、`acknowledgement`、`achievements`、`declarations`、`defense`、`resume` | 后置页面 |
| `presets`、`zihao`、`songti`、`heiti`、`kaishu`、`fangsong` | 字体方案、字号和中文字体角色 |
| `enter`、`ccwd`、`enum-hanging`、`list-hanging` | 段落间距、字符宽度和列表悬挂 |
| `today` | 当前日期 |

## 字体、样式与页面

选择字体预设，或在预设上替换单个角色：

```typst
#show: iota-hit.with(
  fontset: presets.windows + (kaishu: "TW-MOE-Std-Kai"),
)
```

正文中请使用 `songti[...]`、`heiti[...]`、`kaishu[...]` 和 `fangsong[...]`，不要写死字体家族。字号使用 `zihao.xiaosi`、`zihao.wuhao` 等常量。

局部覆盖采用字典：

```typst
#show: iota-hit.with(
  styles: (
    body: (size: zihao.xiaosi),
    chapter: (align: left),
  ),
  layout: (margin: (top: 3cm)),
)
```

需要临时换节时，再使用 `new-layout` / `restore-layout` 或 `new-styles` / `restore-styles`。字段错误会中止编译，避免悄悄生成错误版式。

## 常见问题

### 字体找不到或断行不同

先确认 `fontset` 对应的字体已安装。模板把字体选择与 Word 度量参数分开，因此换字体通常不会改变基线，但字宽、断行和字形仍可能变化。最终稿应在固定的 Typst 版本和字体环境中编译。

### 封面或内封出现红色提示

题目、单位或导师信息过长，页面无法按标定版式容纳。优先核对文字是否应换行或缩短。`warning: false` 只能隐藏提示，不会解决溢出。

### 自定义词条

```typst
#show: iota-hit.with(
  overrides: (titlepage-author-bachelor: [作者]),
)
```

键名必须是模板已经定义的词条；拼写错误会报错。

### 与其他包一起使用

模板会安装标题、图表、引用、代码块和文本等 show 规则。若第三方包也修改这些元素，规则顺序会影响结果。通常先设置 `iota-hit`，再安装需要接管具体元素的规则。代码高亮示例见 `examples/code-listings.typ`。

## 已知限制

- 不处理彩色封面、书脊、装订线和纸张等印装项目；
- 不支持通过可伸缩行距把最后一行强制贴到版心底部；
- 中西文间距和西文半格字距仍受 Typst 排版能力限制；
- CJK 标点压缩采用 Typst 的固定规则，无法完全复现 Word 的按需压缩；
- 题注末行的特殊对齐尚未接入。

## 源码结构

```text
lib.typ              公开 API
src/iota-hit.typ     文档级入口与 show 规则
src/axes.typ         文档类型与变体解析
src/info.typ         元信息默认值和状态
src/layout/          页面、分节、页眉页脚
src/styles/          样式预设与查询
src/heading/         标题与编号
src/figure/          图、表、题注、续排
src/math/            公式、符号说明与定理环境
src/pages/           封面及前后置页面
src/references/      引用、缩略语、索引
src/terms/           中英文词条与日期
template/            可直接改写的模板
examples/            单项功能示例
tests/               PDF 回归测试
```

依赖方向保持为 `pages → 领域模块 → banshi`。`lib.typ` 只导出公开名字，不放实现。

## 开发与验证

```sh
bash tests/run.sh
```

测试会编译样张，并用 PDF 的坐标、字体、文本和链接信息与标定值比对。测试脚本还会读取本地 `banshi:0.1.0` 的 Word 模型，因此两者需要一起安装。

修改版式常数时，请在相邻注释中记录来源和单位，并补一条能直接失败的检查。不要把调试过程、已删除方案或整段测试报告留在实现文件中；Git 历史和测试代码更适合保存这些信息。

## 依据

实现主要参考学校发布的本科毕业论文规范及范例、研究生学位论文写作指南、研究生实践成果写作指南、阶段报告与声明页 Word 表单，并与姊妹项目 hithesis 的测量记录交叉核对。

模板常数优先取自原始 DOCX 属性；无法直接读取时，才用 Word 导出的 PDF 标定坐标。具体数值由测试固定，不在手册中重复抄写。
