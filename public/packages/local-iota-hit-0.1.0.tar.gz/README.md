# iota-hit

iota-hit 是 hithesis 的姊妹项目，为哈尔滨工业大学学位论文与阶段报告提供 Typst 模板。版式依据学校规范、范例和 Word 表单实现。

项目仍处于 `0.1.0` 阶段。提交前请以所在院系当年的要求和实际打印结果为准。

## 支持范围

- 本科、硕士、博士，以及博士后研究报告；
- 学位论文、本科毕业设计、研究生实践成果；
- 终稿、开题报告、中期报告；
- 哈尔滨本部与深圳校区的阶段报告；
- 中文论文和英文论文；
- 理工类与人文社科类的章节编号。

## 环境与安装

模板要求 Typst 不低于 `0.15.0`（回归基线在 `0.15.1` 上生成），并依赖本地包 `banshi:0.1.0` 和 `omni-gb7714:0.1.0`。Windows 字体组合与标定样张最接近。

本仓库尚未发布到 Typst Universe。请把三个仓库复制或链接到 Typst 的本地包目录。macOS 的目录结构如下：

```text
~/Library/Application Support/typst/packages/local/
  banshi/0.1.0/
  iota-hit/0.1.0/
  omni-gb7714/0.1.0/
```

之后即可导入：

```typst
#import "@local/iota-hit:0.1.0": *
```

仓库中的模板使用相对路径导入，适合直接在源码树内调试。

## 快速开始

```typst
#import "@local/iota-hit:0.1.0": *

#show: iota-hit.with(
  degree-level: "doctor",
  title: [论文题目#en[English Title]],
  author: [张三#en[San Zhang]],
  supervisor: [李四 教授],
  date: "2026-06",
)

#show: frontmatter
#cover()
#titlepage()
#abstract(keywords: ([关键词一#en[keyword one]], [关键词二#en[keyword two]]))[
  中文摘要。
  #en[English abstract.]
]
#table-of-contents()

#show: mainmatter
= 绪论#en[Introduction]

正文。

#bibliography(read("refs.bib"), full: true)
#conclusions[结论。]
#acknowledgements[致谢。]
#declarations()
```

```sh
typst compile main.typ
```

建议从与自己的文档类型最接近的文件开始改：

- `template/example.typ`：完整学位论文；
- `template/postdoc-example.typ`：博士后研究工作报告（封皮、内封到永久通讯地址，照学校的两份 Word 模板）；
- `template/proposal-example.typ`：本部研究生开题报告；
- `template/shenzhen-bachelor-proposal-example.typ`：深圳本科开题报告；
- `template/shenzhen-bachelor-interim-example.typ`：深圳本科中期报告；
- 文件名带 `-en` 的版本：英文报告。

## 选择文档类型

文档类型由几个独立参数组成：

| 参数 | 常用值 | 默认值 | 含义 |
|---|---|---|---|
| `degree-level` | `"bachelor"`、`"master"`、`"doctor"` | `"doctor"` | 学位层次 |
| `degree-type` | `"academic"`、`"professional"` | `auto` | 学术或专业学位；本科忽略 |
| `form` | `"dissertation"`、`"practice"` | `"dissertation"` | 学位论文或实践成果 |
| `stage` | `"final"`、`"proposal"`、`"interim"` | `"final"` | 终稿、开题或中期 |
| `campus` | `"harbin"`、`"shenzhen"` | `"harbin"` | 校区 |
| `category` | `"stem"`、`"hass"` | `"stem"` | 理工或人文社科 |
| `lang` | `"zh"`、`"en"` | `"zh"` | 文档主语言 |

`form: "design"` 是本科毕业设计的兼容写法，等同于 `"practice"`；`"thesis"` 是 `"dissertation"` 的别名。

研究生实践成果必须配专业学位：

```typst
#show: iota-hit.with(
  degree-level: "master",
  degree-type: "professional",
  form: "practice",
  practice-type: [产品设计报告],
)
```

阶段与成果形式相互独立。例如，实践成果也可以有开题报告：

```typst
#show: iota-hit.with(
  degree-level: "master",
  form: "practice",
  stage: "proposal",
)
```

## 组织文档

用 `frontmatter`、`mainmatter` 和 `backmatter` 切换页面设置与页码：

```typst
#show: frontmatter
#cover()
#titlepage()
#abstract[摘要正文]
#table-of-contents()

#show: mainmatter
= 第一章

#show: backmatter
#conclusions[结论正文]
```

`backmatter` 默认沿用正文的页码和页眉。附录使用 `#show: appendix`，模板会同步调整标题、图号、表号和公式号。

## 元信息

常用元信息直接写在 `iota-hit.with(...)` 中：

```typst
#show: iota-hit.with(
  title: [中文题目#en[English Title]],
  subtitle: [副题目],
  author: [作者],
  student-id: [学号],
  supervisor: [导师#en[Prof. Supervisor]],
  associate-supervisor: [副导师],
  industry-supervisor: [行业导师],
  speciality: [学科或专业#en[Speciality]],
  affiliation: [所在单位#en[School of …]],
  degree-applied: [工学博士#en[Doctor of Engineering]],
  defense-date: "2026-06",
  date: "2026-06",
)
```

双语只有一种写法：没标记的内容是文档语言，`#en[...]` 里的是英文、`#zh[...]` 里的是中文——标题、题注、元信息、摘要、关键词都一样。中文档写 `[中文#en[English]]`，英文档写 `[English#zh[中文]]`；标了文档语言自己（中文档里写 `#zh`）不报错，和没标记的一样拼在一起。只给了一种语言的字段，另一种语言的页面印同一份内容。日期字符串接受 `YYYY`、`YYYY-MM` 或 `YYYY-MM-DD`，两种语言各自排；若需完全自定义显示文字，请传内容，例如 `[二〇二六年六月#en[June 2026]]`。

长内容（摘要）里的标记可以拆开写：段落跟着没标记的那一侧走——两个标记之间它分了段，标记那侧也分段，否则接成同一段；同一侧相邻两截之间，两侧都是中日文字才不留空格。只扫最外层，嵌在列表、引用块里的标记不认。

## 标题与目录

原生标题语法可以直接使用：

```typst
= 绪论#en[Introduction]
== 研究背景#en[Background]
=== 国内外研究现状#en[Related work]
```

也可以调用 `chapter`、`section`、`subsection` 和 `subsubsection`。函数形式适合临时关闭编号或控制章前换页：

```typst
#chapter(numbering: none)[结论]
#chapter(openright: false)[补充说明]
```

四个函数与 `=`…`====` 同级同义，名字按终稿取。标题只到款：终稿里 `=`…`====` 是章、节、条、款，再往下是项「（1）」，写 `+` 列表——写第五级当场报错。开题、中期报告没有章（深圳本科的走终稿版式，有章）：`=` 是节「1」、`==` 条、`===` 款；也可以照 hithesis 的老写法从 `==` 起头：全文有 `=` 就 `=` 是节，一个 `=` 都没有就 `==` 是节（附录里的也算）；混着写时 `=` 之前那些 `==` 排成条、印「0.1」。用 `=` 起头的一份正文，改 `stage:` 就能在报告与终稿之间切换。

博士论文默认生成中英文目录，本科和硕士默认只生成中文目录。英文标题由 `#en[...]` 提供；目录、索引页的标题同理：`table-of-contents(title: [目录#en[Contents]])`。

## 图、表与题注

普通图表沿用 Typst 的 `figure`：

```typst
#figure(
  image("figure.png", width: 70%),
  caption: [系统结构#en[System architecture]],
) <fig:system>

如@fig:system 所示。
```

博士论文默认使用双语题注；本硕默认只排中文。三线表直接放进 `figure`：

```typst
#figure(
  table(
    columns: 3,
    table.header([参数], [数值], [单位]),
    [$p$], [1.0], [MPa],
  ),
  caption: [试验参数],
) <tab:params>
```

续表或续图要拆成多个 `figure`，后续部分的题注写 `#continued()`。组图使用 `subs(...)`，完整示例见 `examples/captions.typ`。

图注、表注写在 `figure` 的正身里、图或表之后，排在写的位置——表：表题 → 表 → 注；图：图 → 注 → 图题（指南 2.13「有图注或其他说明时应置于图题之上」）；分图的注写在分图正身里。注与所在的图、表同宽、左起、不缩进，字号行距跟题注；引导词默认「注：」。

```typst
#figure(
  caption: [试验参数],
  table(columns: 3, table.header([参数], [数值], [单位]), [$p$], [1.0], [MPa])
    + note[压力按标准状态折算。],
)
#figure(
  caption: [系统结构],
  image("figure.png", width: 8cm) + note(lead: none, width: 80%)[不印引导词，块宽是版心的 80%。],
)
```

`note(lead: auto, width: auto)`：`lead: none` 不印引导词；`width` 收 `80%`／`10cm`，只管这一条，文档级写 `iota-hit(note-width: …)`。样式在 `styles: (figure: (note: (…)))`，词条 `overrides: (caption-note: [注])`。完整示例见 `examples/notes.typ`。

## 公式与符号说明

公式按章编号，并使用全角括号：

```typst
$ E = m c^2 $ <eq:energy>

#eqdenote[
  / $E$: 能量，J；
  / $m$: 质量，kg；
  / $c$: 真空光速，m/s。
]
```

`increment` 表示有限增量符号 `∆`（U+2206），用于区分希腊字母 `Δ`。

### 定理环境

与 hithesis 相同的十三个环境：`theorem`、`lemma`、`definition`、`proposition`、`corollary`、`axiom`、`assumption`、`example`、`remark`、`problem`、`conjecture`、`fact`、`exercise`，以及不编号的 `proof`。头用黑体（英文加粗），头后空一个字，正文段不另加上下间距；编号与公式一样按章（开题、中期报告只数序号），各环境各自计数；附录里「附」字与图表一样挂在名前（附推论1.1）；空格同题注，前一截末字是西文才空（定理1.1 勾股、Theorem 1.1）。

```typst
#theorem(note: [勾股])[
  直角三角形两直角边的平方和等于斜边的平方。
] <thm:gougu>
#proof[略。]

由@thm:gougu 可知……  // 定理1.1
```

`note` 是 LaTeX 定理环境的可选参数，跟在编号后面。引用时 `@thm:gougu[]` 只印编号，`@thm:gougu[定理]` 换叫法；证明不能引用。词条在 `theorem` 桶里，可用 `overrides: (theorem-remark: [注])` 改字面。

可调的四处，写法同别处：

```typst
#show: iota-hit.with(
  theorem-numbering-by-top-level-heading: false,  // 只数序号；默认终稿按章、开题中期不按
  theorem-body-indent: (chars: 2),                // 头后空多少，同 heading-body-indent
  styles: (
    theorem: (
      head: (asian-font: "kaishu", bold: true),   // 头只收字体那几个键
      body: (above: (lines: 1), below: 6pt),      // 定理段的段落样式，默认跟 body、上下 0
    ),
  ),
)
```

完整示例见 `examples/theorems.typ`。

## 符号表与缩略语

```typst
#list-of-symbols[
  / $p$: 气膜压力，Pa
  / $h$: 气膜厚度，m
]

#list-of-abbreviations(
  FEM: (
    long: "有限元方法",
    long-en: "Finite Element Method",
  ),
)
```

正文中写 `@FEM`。首次出现时模板展开全称，后续只显示缩写。`nomenclature(...)` 可把符号和缩略语合并到一页。

## 参考文献与成果

参考文献由 `omni-gb7714` 排版：

```typst
#bibliography(read("refs.bib"), full: true)
```

它的选项通过 `gb7714` 原样传递：

```typst
#show: iota-hit.with(
  gb7714: (style: "author-date", cite-form: "super"),
)
```

攻读学位期间取得的成果使用独立的 `.bib` 文件：

```typst
#achievements(read("achievements.bib"))
```

分组示例见 `template/example.typ`。

博后报告（`degree-level: "postdoc"`）有两章成果。`period: "doctoral"` 印「博士生期间的研究成果」，组名照博士学位论文；不写 `period` 印「博士后期间的研究成果」，分六组照模板。「发表的其它论文」要写键，其余论文都归「发表的相关论文」。模板六组之外的条目照样归类：获奖并进项目组，组名带「及获奖情况」；标准与其他形式的成果各成一组，排在最后。换成别的学位时，博士生期间那一章默认不排，`other-papers` 里的键并回论文组：

```typst
#achievements(read("phd.bib"), period: "doctoral")
#achievements(read("postdoc.bib"), other-papers: [@wang2025 @li2025])
```

博后模板没有原创性声明和答辩页：`#declarations()`、`#defense()` 与在报告里一样默认不排。写 `shown: true` 可以强排，字换成「博士后研究报告」「合作导师」。

## 其他前后置页面

这些页面按需调用：

| 函数 | 用途 |
|---|---|
| `list-of-figures()` | 插图索引 |
| `list-of-tables()` | 表格索引 |
| `list-of-equations()` | 公式索引 |
| `declarations()` | 原创性声明与使用授权 |
| `defense()` | 博士论文评阅、答辩名单与决议 |
| `achievements(...)` | 攻读学位期间取得的成果 |
| `resume[...]` | 个人简历（博后报告印「博士后个人简历」） |
| `permanent-address(...)` | 博后报告的永久通讯地址：`address`、`email`、`phone` 三行 |
| `index()` | 索引页；正文用 `idx[...]` 登记词条 |

同一页面通常只能生成一次；互斥的页面组合会在编译时给出错误。页面的局部参数以编辑器补全和 `lib.typ` 的悬停文档为准。

## 公开 API 索引

| 名称 | 用途 |
|---|---|
| `iota-hit` | 文档级 show 规则 |
| `frontmatter`、`mainmatter`、`backmatter`、`appendix` | 切换文档分区 |
| `clear-page` | 结束当前页，并按需补齐右页 |
| `new-layout`、`restore-layout` | 临时替换和恢复页面设置 |
| `layout-of`、`current-layout`、`msword-layout` | 查询或构造页面设置 |
| `new-styles`、`restore-styles` | 临时替换和恢复样式 |
| `cover`、`titlepage`、`abstract` | 封面、题名页和摘要 |
| `table-of-contents`、`list-of-figures`、`list-of-tables`、`list-of-equations` | 目录和各类索引 |
| `list-of-symbols`、`list-of-abbreviations`、`nomenclature` | 符号表和缩略语表 |
| `chapter`、`section`、`subsection`、`subsubsection` | 各级标题 |
| `en`、`zh`、`tocbreak` | 标出另一种语言的那一半，和目录专用换行 |
| `subs`、`subfigure`、`continued`、`note` | 分图、组图、续排和图注表注 |
| `lovelace`、`algorithmic` | 伪代码 |
| `eqdenote`、`increment` | 公式符号说明和有限增量符号 |
| `theorem`、`lemma`、`definition`、`proposition`、`corollary`、`axiom`、`assumption`、`example`、`remark`、`problem`、`conjecture`、`fact`、`exercise`、`proof` | 定理环境 |
| `bibliography`、`idx`、`index` | 参考文献和索引 |
| `conclusions`、`acknowledgements`、`achievements`、`declarations`、`defense`、`resume`、`permanent-address` | 后置页面 |
| `presets`、`zihao`、`songti`、`heiti`、`kaishu`、`fangsong`、`serif`、`sans` | 字体方案、字号和字体角色 |
| `enter`、`ccwd`、`enum-hanging`、`list-hanging` | 段落间距、字符宽度和列表悬挂 |
| `today` | 当前日期 |

## 开关写在哪儿

- 只有一页自己用的开关，是那一页函数的参数，比如 `table-of-contents(depth: 2)`、`achievements(period: "doctoral")`。
- 好几处都要读的开关，是 `iota-hit` 的具名参数，全文生效，比如 `openright`、`two-hanzi`、`heading-body-indent`。其中有些还能在某一页或某个元素上就地改，就地写的压过全文的：

  ```typst
  #show: iota-hit.with(heading-body-indent: (chars: 1))
  #table-of-contents(heading-body-indent: 3em)   // 只这一页
  ```

  哪条能写在哪儿，以编辑器补全为准；写错位置（比如把开关塞进 `overrides:`）会报错并指出该写在哪儿。
- 都不写（或写 `auto`）时，按学位、门类、阶段、语言取模板的默认值。
- 规范或模板定死的格式（页眉页脚的内容与样式等）不开参数。

## 字体、样式与页面

选择字体预设，或在预设上替换单个角色：

```typst
#show: iota-hit.with(
  fontset: presets.windows + (kaishu: "TW-MOE-Std-Kai"),
)
```

正文中请使用 `songti[...]`、`heiti[...]`、`kaishu[...]` 和 `fangsong[...]`，不要写死字体家族；`serif[...]`、`sans[...]` 是西文那两个角色，整段按西文字体排——中文段里手打的弯引号（’90s）本来归中文字体按全宽排，套上它才走西文。字号使用 `zihao.xiaosi`、`zihao.wuhao` 等常量。

局部覆盖采用字典：

```typst
#show: iota-hit.with(
  styles: (
    body: (size: zihao.xiaosi),
    heading-1: (align: left),
  ),
  layout: (margin: (top: 3cm)),
)
```

标题样式按级叫 `heading-1`…`heading-4`，与目录的 `toc-1`…`toc-4` 同一条线；开题、中期报告没有章，表里只有 `heading-1`…`heading-3`（节、条、款）。摘要、目录、参考文献这类不编号的章级标题是 `term-heading`。

模板提供了口子的东西，写原生设置会当场报错并指明该走哪个口子——写了要么被模板压住不生效，要么只生效一半（比如 `#set par(first-line-indent: …)` 管得到正文，管不到定理段）。拦的是文档级的 `set text` 字号、字体、字距、字重、语言，`set par` 首行缩进、悬挂、两端对齐、段距，`set block` 段前段后，`set align`，`set figure(gap:)`、`set figure.caption(position:)`，`set table` 边距与线，`set outline.entry(fill:)`，`set page` 纸张、边距、页码、页眉页脚；标题、题注、目录条目上的 `show …: set text(…)`／`set align(…)`／`set block(…)`；以及原生 `#outline()`（用 `table-of-contents()`、`list-of-figures()` 等）。局部块 `#[#set …]` 与 `#text(…)[…]` 是 Typst 做局部调整的正路，不受影响；模板没提供的（如 `#set text(fill: …)`、`#set text(hyphenate: …)`）照常生效。

需要临时换节时，再使用 `new-layout` / `restore-layout` 或 `new-styles` / `restore-styles`。字段错误会中止编译，避免悄悄生成错误版式。

## 常见问题

### 字体找不到或断行不同

先确认 `fontset` 对应的字体已安装。模板把字体选择与 Word 度量参数分开，因此换字体通常不会改变基线，但字宽、断行和字形仍可能变化。最终稿应在固定的 Typst 版本和字体环境中编译。

### 封面或内封出现红色提示

题目、单位或导师信息过长，页面无法按标定版式容纳。优先核对文字是否应换行或缩短。`warning: false` 只能隐藏提示，不会解决溢出。

### 自定义词条

```typst
#show: iota-hit.with(
  overrides: (titlepage-author-bachelor: [作者]),
)
```

键名必须是模板已经定义的词条；拼写错误会报错。

### 与其他包一起使用

模板会安装标题、图表、引用、代码块和文本等 show 规则。若第三方包也修改这些元素，规则顺序会影响结果。通常先设置 `iota-hit`，再安装需要接管具体元素的规则。代码高亮示例见 `examples/code-listings.typ`。

## 已知限制

- 不处理彩色封面、书脊、装订线和纸张等印装项目；
- 不支持通过可伸缩行距把最后一行强制贴到版心底部；
- 中西文间距和西文半格字距仍受 Typst 排版能力限制；
- CJK 标点压缩采用 Typst 的固定规则，无法完全复现 Word 的按需压缩；
- 题注末行的特殊对齐尚未接入。

## 源码结构

```text
lib.typ              公开 API
src/iota-hit.typ     文档级入口与 show 规则
src/axes.typ         文档类型与变体解析
src/info.typ         元信息默认值和状态
src/layout/          页面、分节、页眉页脚
src/styles/          样式预设与查询
src/heading/         标题与编号
src/figure/          图、表、题注、续排
src/math/            公式、符号说明与定理环境
src/pages/           封面及前后置页面
src/references/      引用、缩略语、索引
src/terms/           中英文词条与日期
src/vendor/quan/     quan 0.3.0 的副本（universe 还是 0.2.2，上了就删）
template/            可直接改写的模板
examples/            单项功能示例
tests/               PDF 回归测试
```

依赖方向保持为 `pages → 领域模块 → banshi`。`lib.typ` 只导出公开名字，不放实现。

## 开发与验证

```sh
bash tests/run.sh
```

测试会编译样张，并用 PDF 的坐标、字体、文本和链接信息与标定值比对。测试脚本还会读取本地 `banshi:0.1.0` 的 Word 模型，因此两者需要一起安装。

修改版式常数时，请在相邻注释中记录来源和单位，并补一条能直接失败的检查。不要把调试过程、已删除方案或整段测试报告留在实现文件中；Git 历史和测试代码更适合保存这些信息。

## 依据

实现主要参考学校发布的本科毕业论文规范及范例、研究生学位论文写作指南、研究生实践成果写作指南、阶段报告与声明页 Word 表单，并与姊妹项目 hithesis 的测量记录交叉核对。

模板常数优先取自原始 DOCX 属性；无法直接读取时，才用 Word 导出的 PDF 标定坐标。具体数值由测试固定，不在手册中重复抄写。
