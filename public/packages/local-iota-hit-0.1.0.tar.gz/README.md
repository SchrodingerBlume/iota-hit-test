# iota-hit

iota-hit 是 hithesis 的姊妹项目，为哈尔滨工业大学学位论文与阶段报告提供 Typst 模板。版式依据学校规范、范例和 Word 表单实现。

项目仍处于 `0.1.0` 阶段。提交前请以所在院系当年的要求和实际打印结果为准。

## 支持范围

- 本科、硕士、博士，以及博士后研究报告；
- 学位论文、本科毕业设计、研究生实践成果；
- 终稿、开题报告、中期报告；
- 哈尔滨本部与深圳校区的阶段报告；
- 中文论文和英文论文；
- 理工类与人文社科类的章节编号。

## 环境与安装

模板要求 Typst 不低于 `0.15.0`（回归基线在 `0.15.1` 上生成），并依赖本地包 `docxtyp:0.1.0` 和 `omni-gb7714:0.1.0`。Windows 字体组合与标定样张最接近。

本仓库尚未发布到 Typst Universe。请把三个仓库复制或链接到 Typst 的本地包目录。macOS 的目录结构如下：

```text
~/Library/Application Support/typst/packages/local/
  docxtyp/0.1.0/
  iota-hit/0.1.0/
  omni-gb7714/0.1.0/
```

之后即可导入：

```typst
#import "@local/iota-hit:0.1.0": *
```

仓库中的模板使用相对路径导入，适合直接在源码树内调试。

## 快速开始

```typst
#import "@local/iota-hit:0.1.0": *

#show: iota-hit.with(
  degree-level: "doctor",
  title: [论文题目#en[English Title]],
  author: [张三#en[San Zhang]],
  supervisor: [李四 教授],
  date: (final: "2026-06", final-defense: "2026-06-12"),
)

#show: frontmatter
#cover()
#titlepage()
#abstract(keywords: ([关键词一#en[keyword one]], [关键词二#en[keyword two]]))[
  中文摘要。
  #en[English abstract.]
]
#table-of-contents()

#show: mainmatter
= 绪论#en[Introduction]

正文。

#bibliography(read("refs.bib"), full: true)
#conclusions[结论。]
#acknowledgments[致谢。]
#declarations()
```

```sh
typst compile main.typ
```

建议从与自己的文档类型最接近的文件开始改：

- `template/example.typ`：完整学位论文；
- `template/postdoc-example.typ`：博士后研究工作报告（封皮、内封到永久通讯地址，照学校的两份 Word 模板）；
- `template/proposal-example.typ`：本部研究生开题报告；
- `template/shenzhen-bachelor-proposal-example.typ`：深圳本科开题报告；
- `template/shenzhen-bachelor-interim-example.typ`：深圳本科中期报告；
- 文件名带 `-en` 的版本：英文报告。

## 选择文档类型

文档类型由几个独立参数组成：

| 参数 | 常用值 | 默认值 | 含义 |
|---|---|---|---|
| `degree-level` | `"bachelor"`、`"master"`、`"doctor"` | `"doctor"` | 学位层次 |
| `degree-type` | `"academic"`、`"professional"` | `auto` | 学术或专业学位；本科忽略 |
| `form` | `"dissertation"`、`"practice"` | `"dissertation"` | 学位论文或实践成果 |
| `stage` | `"final"`、`"proposal"`、`"interim"` | `"final"` | 终稿、开题或中期 |
| `campus` | `"harbin"`、`"shenzhen"` | `"harbin"` | 校区 |
| `category` | `"stem"`、`"hass"` | `"stem"` | 理工或人文社科 |
| `lang` | `"zh"`、`"en"` | `"zh"` | 文档主语言 |

`form: "design"` 是本科毕业设计的兼容写法，等同于 `"practice"`；`"thesis"` 是 `"dissertation"` 的别名。

`campus: "weihai"` 目前映射到 `"harbin"`：论文格式与本部一致；报告暂沿用哈尔滨版，待核查威海报告原件。

研究生实践成果必须配专业学位：

```typst
#show: iota-hit.with(
  degree-level: "master",
  degree-type: "professional",
  form: "practice",
  practice-type: [产品设计报告],
)
```

阶段与成果形式相互独立。例如，实践成果也可以有开题报告：

```typst
#show: iota-hit.with(
  degree-level: "master",
  form: "practice",
  stage: "proposal",
)
```

深圳博士开题使用 `campus: "shenzhen"`、`degree-level: "doctor"`、`stage: "proposal"`。
封面按深圳博士样本排版，底部年月与信息栏共用 `date.proposal`；ISO 日期分别排成完整日期和中文年月。
正文四边距 2.5cm、固定行距 21pt，节／条／款标题为黑体小三／四号／小四。
完整提纲见 [`template/shenzhen-doctor-proposal-example.typ`](template/shenzhen-doctor-proposal-example.typ)。

深圳博士中期使用相同的校区、学位配置，阶段改为 `stage: "interim"`。
`cover()` 生成原表的六行封面，入学时间取 `date.period` 的开始日期。正文使用普通标题，宋体小四、1.5倍行距。常规五项保留原表三页（第1、2项／第3、4项／第5项）的栏高与垂直居中；超高或增减栏目时，按实际高度重新分配页面，同页栏目可借用空白，必要时允许三个以上短栏共页。超过整页的栏目续排并重复普通续页标题，原生标题和计数不重复。图表、公式和引用继续使用原生写法。规则和测试见 [栏目分页](docs/interim-pagination.md)。
完整示例见 [`template/shenzhen-doctor-interim-example.typ`](template/shenzhen-doctor-interim-example.typ)。

### 报告说明页

在封面后、目录和正文前调用 `instructions()`：

```typst
#cover()
#instructions()
#table-of-contents()
#show: mainmatter
```

组件按校区、学位、阶段、成果形式及语言选择原件说明，不生成正文标题或图表编号，也不排页眉页码；长说明可跨页。终稿和博后默认不排。需要省略说明时写 `instructions(shown: false)`。

已有英文原件时使用英文说明；缺少对应英文原件时回落同一变体的中文原文。本部硕士实践成果使用新版中文说明，避免套用旧英文论文版。可用 `title:`、`body:` 替换标题或全文，`layout:` 调整页面；词条覆盖使用 `instructions-title`、`instructions-body`，就地可省略桶名。

各变体的原件来源、整理范围和语言回落见 [报告说明页](docs/report-instructions.md)。

## 组织文档

用 `frontmatter`、`mainmatter` 和 `backmatter` 切换页面设置与页码：

```typst
#show: frontmatter
#cover()
#titlepage()
#abstract[摘要正文]
#table-of-contents()

#show: mainmatter
= 第一章

#show: backmatter
#conclusions[结论正文]
```

`backmatter` 默认沿用正文的页码和页眉。附录使用 `#show: appendix`，模板会同步调整标题、图号、表号和公式号。

## 元信息

常用元信息直接写在 `iota-hit.with(...)` 中：

```typst
#show: iota-hit.with(
  title: [中文题目#en[English Title]],
  subtitle: [副题目],
  author: [作者],
  student-id: [学号],
  clc: [TH133.31],
  udc: [621.822.5],
  supervisor: [导师#en[Prof. Supervisor]],
  associate-supervisor: [副导师],
  industry-supervisor: [行业导师],
  specialty: [学科或专业#en[Speciality]],
  affiliation: [所在单位#en[School of …]],
  degree-applied: [工学博士#en[Doctor of Engineering]],
  date: (
    proposal: "2024-09-20",
    interim: "2025-09-15",
    final: "2026-06",
    final-defense: "2026-06-12",
    period: (start: "2024-07-01", end: "2026-06-30"),
  ),
)
```

学号以 `student-id` 为正名，也接受 `student-number` 别名。两个名字同时赋值时报重复错误；内部统一保存为 `student-id`。词条覆盖中的 `student-number` 也按同样规则处理，例如 `cover-student-number` 等价于 `cover-student-id`，校区、学位和语言后缀照常使用。

标识符以美式拼写为正名：`specialty` 接受英式别名 `speciality`，`acknowledgments()` 接受 `acknowledgements()`。相关词条键和词条桶同样接受两种拼法，内部只保存美式名字；同一处同时赋值两个拼法时报重复错误。页面上的 `Speciality`、`Acknowledgements` 等学校原文保持原样。

中图分类号以 `clc` 为正名，也接受与英文栏目 `Classified Index` 对应的 `classified-index` 别名；参数、部件和词条覆盖采用相同规则，同时赋值时报重复错误。`udc` 仍独立表示国际十进分类号。

双语只有一种写法：没标记的内容是文档语言，`#en[...]` 里的是英文、`#zh[...]` 里的是中文——标题、题注、元信息、摘要、关键词都一样。中文档写 `[中文#en[English]]`，英文档写 `[English#zh[中文]]`；标了文档语言自己（中文档里写 `#zh`）不报错，和没标记的一样拼在一起。只给了一种语言的字段，另一种语言的页面印同一份内容。日期字典中每个日期接受 `YYYY`、`YYYY-MM` 或 `YYYY-MM-DD` 字符串，两种语言各自排；若需完全自定义显示文字，请传内容，例如 `final-defense: [二〇二六年六月#en[June 2026]]`。

长内容（摘要）里的标记可以拆开写：段落跟着没标记的那一侧走——两个标记之间它分了段，标记那侧也分段，否则接成同一段；同一侧相邻两截之间，两侧都是中日文字才不留空格。只扫最外层，嵌在列表、引用块里的标记不认。

### 日期

`date` 统一收字典，只需填写实际使用的项。同一个主文件切换阶段时，页面按当前配置读取：

| 键 | 使用位置 |
|---|---|
| `proposal` | 开题报告首页，包括英文表单的 `Defense Date` |
| `interim` | 中期报告首页 |
| `final` | 学位论文封面提交日期；博后封皮的报告提交日期及封皮、内封落款 |
| `final-defense` | 学位论文中英文内封的最终答辩日期 |
| `period` | 当前就读／研究阶段的起止日期；深圳博士中期的入学时间取开始日期，博后内封取两端日期，封皮取两端年月 |

`period` 可以写单个 ISO 日期或内容值，等价于只给 `start`：`period: "2023-03"` 等价于 `period: (start: "2023-03")`。需要结束日期时写 `(start: ..., end: ...)`；`period: none` 留空两端。中期封面按用户填写的精度显示，不截断日期，自定义内容如 `[202303]` 原样显示。旧键 `postdoc-period` 保留为 `period` 的别名，两个名字同时填写时报重复错误。

`proposal` 接受别名 `opening`，`interim` 接受 `mid-term`、`midterm`，`final-defense` 接受英式拼法 `final-defence`。正名和别名同时写时报重复错误。不同事件之间不自动回落；各日期值缺失或为 `auto` 时显示对应占位符，为 `none` 或空内容时留空。已填写的日期无论在哪个配置下都校验。

`cover(date: …)` 的就地覆盖也使用同一字典，只影响该封面。自定义内容保持原样，不会被自动解析或截取年月；博后起止若需要同时生成日和月两种精度，应使用 ISO 日期字符串。声明页的手写签字日期继续留空。

## 标题与目录

原生标题语法可以直接使用：

```typst
= 绪论#en[Introduction]
== 研究背景#en[Background]
=== 国内外研究现状#en[Related work]
```

也可以调用 `chapter`、`section`、`subsection` 和 `subsubsection`。函数形式适合临时关闭编号或控制章前换页：

```typst
#chapter(numbering: none)[结论]
#chapter(openright: false)[补充说明]
```

四个函数与 `=`…`====` 同级同义，名字按终稿取。作者可以继续使用更深的原生标题，同一份正文切换变体时自动调整编号和格式：

| 相对层级 | 终稿及深圳本科报告 | 无章的开题／中期报告 |
|---|---|---|
| 1 | 章 | 节 |
| 2 | 节 | 条 |
| 3 | 条 | 款 |
| 4 | 款 | 项 |
| 5 及以下 | 项 | 沿用项的格式 |

理工类终稿与无章报告的项使用「（1）」，切换上级后重新计数，黑体小四、段前段后零行，题序前及题序与题文之间各空四个半角字符。人文社科类终稿的项按指南示例排成不自动编号的文字，作者自行写“首先”等衔接语；`@label` 引用这类标题时显示题名。更深层级沿用项的格式并保留独立标题、标签和目录层级，不默认加圈码。段落型列举仍可写 `+` 列表。

深圳博士中期是表格式报告，标题字体按该原件使用宋体小四，顶层题序为「1．」；层级和计数仍按上表自动映射。

无章报告也可以照 hithesis 的老写法从 `==` 起头：全文有 `=` 就 `=` 是节，一个 `=` 都没有就 `==` 是节（附录里的也算）；混着写时 `=` 之前那些 `==` 排成条、印「0.1」。默认目录仍只收三级，`table-of-contents(depth: …)` 可以显式收录更深的标题。规范核查与映射依据见 [`docs/heading-levels.md`](docs/heading-levels.md)。

博士论文默认生成中英文目录，本科和硕士默认只生成中文目录。英文标题由 `#en[...]` 提供；目录、索引页的标题同理：`table-of-contents(title: [目录#en[Contents]])`。

## 图、表与题注

普通图表沿用 Typst 的 `figure`：

```typst
#figure(
  image("figure.png", width: 70%),
  caption: [系统结构#en[System architecture]],
) <fig:system>

如@fig:system 所示。
```

博士论文默认使用双语题注；本硕默认只排中文。三线表直接放进 `figure`：

```typst
#figure(
  table(
    columns: 3,
    table.header([参数], [数值], [单位]),
    [$p$], [1.0], [MPa],
  ),
  caption: [试验参数],
) <tab:params>
```

续表或续图要拆成多个 `figure`，后续部分的题注写 `#continued()`。组图使用 `subs(...)`，完整示例见 `examples/captions.typ`。

图注、表注写在 `figure` 的正身里、图或表之后，排在写的位置——表：表题 → 表 → 注；图：图 → 注 → 图题（指南 2.13「有图注或其他说明时应置于图题之上」）；分图的注写在分图正身里。注与所在的图、表同宽、左起、不缩进，字号行距跟题注；引导词默认「注：」。

```typst
#figure(
  caption: [试验参数],
  table(columns: 3, table.header([参数], [数值], [单位]), [$p$], [1.0], [MPa])
    + note[压力按标准状态折算。],
)
#figure(
  caption: [系统结构],
  image("figure.png", width: 8cm) + note(lead: none, width: 80%)[不印引导词，块宽是版心的 80%。],
)
```

`note(lead: auto, width: auto)`：`lead: none` 不印引导词；`width` 收 `80%`／`10cm`，只管这一条，文档级写 `iota-hit(note-width: …)`。样式在 `styles: (figure: (note: (…)))`，词条 `overrides: (caption-note: [注])`。完整示例见 `examples/notes.typ`。

## 公式与符号说明

公式按章编号，并使用全角括号：

```typst
$ E = m c^2 $ <eq:energy>

#eqdenote[
  / $E$: 能量，J；
  / $m$: 质量，kg；
  / $c$: 真空光速，m/s。
]
```

`increment` 表示有限增量符号 `∆`（U+2206），用于区分希腊字母 `Δ`。

### 定理环境

与 hithesis 相同的十三个环境：`theorem`、`lemma`、`definition`、`proposition`、`corollary`、`axiom`、`assumption`、`example`、`remark`、`problem`、`conjecture`、`fact`、`exercise`，以及不编号的 `proof`。头用黑体（英文加粗），头后空一个字，正文段不另加上下间距；编号与公式一样按章（开题、中期报告只数序号），各环境各自计数；附录里「附」字与图表一样挂在名前（附推论1.1）；空格同题注，前一截末字是西文才空（定理1.1 勾股、Theorem 1.1）。

```typst
#theorem(note: [勾股])[
  直角三角形两直角边的平方和等于斜边的平方。
] <thm:gougu>
#proof[略。]

由@thm:gougu 可知……  // 定理1.1
```

`note` 是 LaTeX 定理环境的可选参数，跟在编号后面。引用时 `@thm:gougu[]` 只印编号，`@thm:gougu[定理]` 换叫法；证明不能引用。词条在 `theorem` 桶里，可用 `overrides: (theorem-remark: [注])` 改字面。

可调的四处，写法同别处：

```typst
#show: iota-hit.with(
  theorem-numbering-by-top-level-heading: false,  // 只数序号；默认终稿按章、开题中期不按
  theorem-body-indent: (chars: 2),                // 头后空多少，同 heading-body-indent
  styles: (
    theorem: (
      head: (asian-font: "kaishu", weight: "bold"),   // 头只收字体那几个键
      body: (above: (lines: 1), below: 6pt),      // 定理段的段落样式，默认跟 body、上下 0
    ),
  ),
)
```

完整示例见 `examples/theorems.typ`。

## 符号表与缩略语

```typst
#list-of-symbols[
  / $p$: 气膜压力，Pa
  / $h$: 气膜厚度，m
]

#list-of-abbreviations(
  FEM: (
    long: "有限元方法",
    long-en: "Finite Element Method",
  ),
)
```

正文中写 `@FEM`。首次出现时模板展开全称，后续只显示缩写。`nomenclature(...)` 可把符号和缩略语合并到一页。

## 参考文献与成果

参考文献由 `omni-gb7714` 排版：

```typst
#bibliography(read("refs.bib"), full: true)
```

它的选项通过 `gb7714` 原样传递：

```typst
#show: iota-hit.with(
  gb7714: (style: "author-date", cite-form: "super"),
)
```

攻读学位期间取得的成果使用独立的 `.bib` 文件：

```typst
#achievements(read("achievements.bib"))
```

分组示例见 `template/example.typ`。

`period` 表示这批成果所属的时期，接受 `"bachelor"`、`"master"`、`"doctor"`、`"postdoc"`；不写或写 `auto` 表示当前文档所属时期。各学位默认只排自己时期的成果，博后报告另外支持博士期间那一章。不适用的时期不生成标题、目录条目或空白页；排版始终跟当前文档走。

博后报告（`degree-level: "postdoc"`）有两章成果。`period: "doctor"` 印「博士生期间的研究成果」，组名照博士学位论文；不写 `period` 或写 `"postdoc"` 印「博士后期间的研究成果」，分六组照模板。「发表的其它论文」要写键，其余论文都归「发表的相关论文」。模板六组之外的条目照样归类：获奖并进项目组，组名带「及获奖情况」；标准与其他形式的成果各成一组，排在最后：

```typst
#achievements(read("phd.bib"), period: "doctor")
#achievements(read("postdoc.bib"), other-papers: [@wang2025 @li2025])
```

同一时期同时有显式调用与 `auto` 调用时，显式的优先，`auto` 不排，与调用先后无关。例如上面的主文件切换为博士论文时，显式的博士成果成为博士论文自己的成果页，后面的默认成果让开；切到本科或硕士时，博士时期不排，默认成果按当前学位排。显式重复指定同一时期，或重复使用 `auto`，都会报错。多批数据若需要固定归属，可各自明确写 `period`。

成果页默认只在终稿中排；`shown: true` 可以在开题／中期中强排当前配置支持的成果章，不能新增该配置没有的时期章节。非博后档的 `other-papers` 条目并回论文组。

博后模板没有原创性声明和答辩页：`#declarations()`、`#defense()` 默认不排。写 `shown: true` 可以强排，字换成「博士后研究报告」「合作导师」。

## 深圳博士中期评议

`defense()` 根据当前配置选择版式；深圳博士中期默认生成导师意见和检查组评议两部分，终稿仍生成评阅、答辩名单与决议。中期评议保留原表意见栏高度、判断与签字行位置；成员表使用宋体小四，表头及竖排标签为五号，外框随表格结束。长意见和长名单可续页。中期正文继续使用原生标题，评议部分放在正文之后：

```typst
#defense(
  supervisor: (
    opinion: [导师意见……],
    completion: "on-time",
    date: "2025-04-11",
    signature: none,
  ),
  resolution: [综合评价、主要问题及改进建议……],
  result: "pass",
  chair: (name: [张三], title: [教授/博导], discipline: [力学]),
  members: (
    (name: [李四], title: [副教授/博导], discipline: [机械]),
  ),
)
```

导师的 `completion` 接受 `"on-time"`（能按期完成）、`"delay"`（需要延期）、`"dismissal"`（建议退学）。检查组的 `result` 接受 `"pass"`（合格，继续攻读）、`"revise"`（不合格，限期改正）、`"dismissal"`（二次不合格，作退学处理）。两者独立填写，默认 `none`，整组不勾，不接受 `auto`。

组长列入成员表第一行，`members` 填其余成员；人员记录的 `title` 是职称／博导资格，不是论文题目。导师、组长、成员记录的 `signature` 接受内容块或 `none`，例如 `signature: [#image("signatures/name.png", height: 8mm)]`，默认留空，不自动拿姓名充当签名。导师签字日期默认留空；`chair.date` 默认 `auto`，取 `date.interim`，显式 `none` 留空。ISO 日期按所填精度显示，内容值原样排版。

正文、长意见和成员名单都可以跨页；名单续页重复表头。`shown: false` 隐藏整个评议部分。

## 其他前后置页面

这些页面按需调用：

| 函数 | 用途 |
|---|---|
| `list-of-figures()` | 插图索引 |
| `list-of-tables()` | 表格索引 |
| `list-of-equations()` | 公式索引 |
| `declarations()` | 原创性声明与使用授权 |
| `defense()` | 论文评阅、答辩名单与决议；深圳博士中期的导师意见及检查组评议 |
| `instructions()` | 开题／中期报告说明，按当前变体选取原件要求 |
| `achievements(...)` | 攻读学位期间取得的成果 |
| `resume[...]` | 个人简历（博后报告印「博士后个人简历」） |
| `permanent-address(...)` | 博后报告的永久通讯地址：`address`、`email`、`phone` 三行 |
| `index()` | 索引页；正文用 `idx[...]` 登记词条 |

同一页面通常只能生成一次；互斥的页面组合会在编译时给出错误。页面的局部参数以编辑器补全和 `lib.typ` 的悬停文档为准。

## 公开 API 索引

| 名称 | 用途 |
|---|---|
| `iota-hit` | 文档级 show 规则 |
| `frontmatter`、`mainmatter`、`backmatter`、`appendix` | 切换文档分区 |
| `clear-page` | 结束当前页，并按需补齐右页 |
| `new-layout`、`restore-layout` | 临时替换和恢复页面设置 |
| `layout-of`、`current-layout`、`msword-layout` | 查询或构造页面设置 |
| `new-styles`、`restore-styles` | 临时替换和恢复样式 |
| `cover`、`titlepage`、`abstract` | 封面、题名页和摘要 |
| `table-of-contents`、`list-of-figures`、`list-of-tables`、`list-of-equations` | 目录和各类索引 |
| `list-of-symbols`、`list-of-abbreviations`、`nomenclature` | 符号表和缩略语表 |
| `chapter`、`section`、`subsection`、`subsubsection` | 各级标题 |
| `en`、`zh`、`tocbreak` | 标出另一种语言的那一半，和目录专用换行 |
| `subs`、`subfigure`、`continued`、`note` | 分图、组图、续排和图注表注 |
| `lovelace`、`algorithmic` | 伪代码 |
| `eqdenote`、`increment` | 公式符号说明和有限增量符号 |
| `theorem`、`lemma`、`definition`、`proposition`、`corollary`、`axiom`、`assumption`、`example`、`remark`、`problem`、`conjecture`、`fact`、`exercise`、`proof` | 定理环境 |
| `bibliography`、`idx`、`index` | 参考文献和索引 |
| `conclusions`、`acknowledgments`、`achievements`、`declarations`、`defense`、`resume`、`permanent-address` | 后置页面 |
| `presets`、`zihao`、`songti`、`heiti`、`kaishu`、`fangsong`、`serif`、`sans` | 字体方案、字号和字体角色 |
| `enter`、`ccwd`、`enum-hanging`、`list-hanging` | 段落间距、字符宽度和列表悬挂 |
| `today` | 当前日期 |

## 开关写在哪儿

- 只有一页自己用的开关，是那一页函数的参数，比如 `table-of-contents(depth: 2)`、`achievements(period: "doctor")`。
- 好几处都要读的开关，是 `iota-hit` 的具名参数，全文生效，比如 `openright`、`two-hanzi`、`heading-body-indent`。其中有些还能在某一页或某个元素上就地改，就地写的压过全文的：

  ```typst
  #show: iota-hit.with(heading-body-indent: (chars: 1))
  #table-of-contents(heading-body-indent: 3em)   // 只这一页
  ```

  哪条能写在哪儿，以编辑器补全为准；写错位置（比如把开关塞进 `overrides:`）会报错并指出该写在哪儿。
- 都不写（或写 `auto`）时，按学位、门类、阶段、语言取模板的默认值。
- 规范或模板定死的格式（页眉页脚的内容与样式等）不开参数。

## 字体、样式与页面

选择字体预设，或在预设上替换单个角色：

字体角色与替代预设由 iota 的 `src/fonts/` 定义，再转换成 docxtyp 接受的原生字体描述和显式目标度量。
底层不再内置宋体、黑体等角色。完整适配示例见 `docs/font-layout.typ`。
迁移边界、验证范围及性能测量见 `docs/font-migration.md`。

```typst
#show: iota-hit.with(
  fontset: presets.windows + (kaishu: "TW-MOE-Std-Kai"),
)
```

正文中请使用 `songti[...]`、`heiti[...]`、`kaishu[...]` 和 `fangsong[...]`，不要写死字体家族；`serif[...]`、`sans[...]` 是西文那两个角色，整段按西文字体排——中文段里手打的弯引号（’90s）本来归中文字体按全宽排，套上它才走西文。字号使用 `zihao.xiaosi`、`zihao.wuhao` 等常量。

局部覆盖采用字典：

```typst
#show: iota-hit.with(
  styles: (
    body: (size: zihao.xiaosi),
    heading-1: (align: left),
  ),
  layout: (margin: (top: 3cm)),
)
```

标题样式按级叫 `heading-1`…`heading-4`，与目录的 `toc-1`…`toc-4` 同一条线；开题、中期报告没有章，表里只有 `heading-1`…`heading-3`（节、条、款）。摘要、目录、参考文献这类不编号的章级标题是 `term-heading`。

模板提供了口子的东西，写原生设置会当场报错并指明该走哪个口子——写了要么被模板压住不生效，要么只生效一半（比如 `#set par(first-line-indent: …)` 管得到正文，管不到定理段）。拦的是文档级的 `set text` 字号、字体、字距、字重、语言，`set par` 首行缩进、悬挂、两端对齐、段距，`set block` 段前段后，`set align`，`set figure(gap:)`、`set figure.caption(position:)`，`set table` 边距与线，`set outline.entry(fill:)`，`set page` 纸张、边距、页码、页眉页脚；标题、题注、目录条目上的 `show …: set text(…)`／`set align(…)`／`set block(…)`；以及原生 `#outline()`（用 `table-of-contents()`、`list-of-figures()` 等）。局部块 `#[#set …]` 与 `#text(…)[…]` 是 Typst 做局部调整的正路，不受影响；模板没提供的（如 `#set text(fill: …)`、`#set text(hyphenate: …)`）照常生效。

需要临时换节时，再使用 `new-layout` / `restore-layout` 或 `new-styles` / `restore-styles`。字段错误会中止编译，避免悄悄生成错误版式。

## 常见问题

### 字体找不到或断行不同

先确认 `fontset` 对应的字体已安装。模板把字体选择与 Word 度量参数分开，因此换字体通常不会改变基线，但字宽、断行和字形仍可能变化。最终稿应在固定的 Typst 版本和字体环境中编译。

### 封面或内封出现红色提示

题目、单位或导师信息过长，页面无法按标定版式容纳。优先核对文字是否应换行或缩短。`warning: false` 只能隐藏提示，不会解决溢出。

### 自定义词条

```typst
#show: iota-hit.with(
  overrides: (titlepage-author-bachelor: [作者]),
)
```

键名必须是模板已经定义的词条；拼写错误会报错。

所有词条使用同一套覆盖规则：

1. 当前页面的局部 `overrides` 优先于文档级 `overrides`，文档级覆盖优先于内置默认。
2. 每一层只考虑条件匹配的规则。裸键匹配所有配置；`-bachelor`、`-proposal`、`-shenzhen` 等后缀限定适用范围。
3. 同一层中，更具体的规则优先：每个肯定条件计 2，`-not-bachelor` 这样的否定条件计 1。同等具体度的匹配规则冲突时会报错，不按字典顺序任选一条。
4. 当前层没有匹配规则时，再查下一层。用户规则不会被更具体的内置变体压过。

因此，`cover-author: [作者]` 会覆盖各档内置的作者标签；
`cover-author-bachelor: [本科作者]` 只对本科生效，也能覆盖内置的深圳本科标签。
二者写在同一个 `overrides` 中时，本科取 `[本科作者]`，其余配置取 `[作者]`。
局部 `cover(overrides: (author: [本页作者]))` 则优先于这两条文档级规则。

文档级词条要带桶名前缀，例如 `cover-author`；在 `cover(overrides: …)` 中可以省略 `cover-`。
条件后缀的顺序不影响含义，同一条规则重复赋值会报错。每条规则对同一轴最多写一个条件，
例如 `-bachelor-master`、`-bachelor-bachelor`、`-bachelor-not-bachelor` 都会被拒绝。

默认词条间的引用仍按页面本来的取词关系传递：修改源桶会影响引用它的词条，
页面自己定义的独立分支保持自己的来源；显式覆盖该页面的词条时，按上述优先级取值。

封面完整文种使用 `cover-document-type`，报告首页的「题目：」等字段标签使用 `cover-title`，研究题目使用 `iota-hit.with(title: …)` 或 `cover(title: …)`。例如：

```typst
#show: iota-hit.with(
  title: [某某技术的研究#en[Research on a Technology]],
  overrides: (
    cover-document-type: [自定义完整文种],
    cover-title: [课题：],
  ),
)
```

文种覆盖值就是最终印出的文字，不会再拼接学位、阶段或「报告」。默认文种仍按文档配置生成；英文文种可单独用 `cover-document-type-en` 覆盖。`cover-title` 只用于有题目字段标签的报告封面。只改一张封面时也可写 `cover(overrides: (document-type: […], title: […]))`。

例如，本部本科综合设计（论文）开题报告可以复用本科开题版式，只替换这张封面的完整文种：

```typst
#show: iota-hit.with(degree-level: "bachelor", stage: "proposal")

#cover(
  overrides: (
    document-type: [本科综合设计（论文）开题报告],
  ),
)
```

### 与其他包一起使用

模板会安装标题、图表、引用、代码块和文本等 show 规则。若第三方包也修改这些元素，规则顺序会影响结果。通常先设置 `iota-hit`，再安装需要接管具体元素的规则。代码高亮示例见 `examples/code-listings.typ`。

模板默认关闭自动断字和悬挂标点，并安装国标数学字形规则；这些是 iota 的排版策略，不是 docxtyp 的全局默认。
自动断字使用原生 `text(hyphenate:)`：中文档未标注语言的西文按英语断词，显式指定的其他语言仍按自己的规则处理。

## 已知限制

- 不处理彩色封面、书脊、装订线和纸张等印装项目；
- 不支持通过可伸缩行距把最后一行强制贴到版心底部；
- 中西文间距和西文半格字距仍受 Typst 排版能力限制；
- CJK 标点压缩采用 Typst 的固定规则，无法完全复现 Word 的按需压缩；
- 题注末行的特殊对齐尚未接入。

## 源码结构

```text
lib.typ              公开 API
src/iota-hit.typ     文档级入口与 show 规则
src/axes.typ         文档类型与变体解析
src/info.typ         元信息默认值和状态
src/layout/          页面、分节、页眉页脚
src/styles/          样式预设与查询
src/heading/         标题与编号
src/figure/          图、表、题注、续排
src/math/            公式、符号说明与定理环境
src/pages/           封面及前后置页面
src/references/      引用、缩略语、索引
src/terms/           中英文词条与日期
src/vendor/quan/     quan 0.3.0 的副本（universe 还是 0.2.2，上了就删）
template/            可直接改写的模板
examples/            单项功能示例
tests/               PDF 回归测试
```

依赖方向保持为 `pages → 领域模块 → docxtyp`。`lib.typ` 只导出公开名字，不放实现。

## 开发与验证

```sh
bash tests/run.sh
```

测试会编译样张，并用 PDF 的坐标、字体、文本和链接信息与标定值比对。测试脚本还会读取本地 `docxtyp:0.1.0` 的 Word 模型，因此两者需要一起安装。

修改版式常数时，请在相邻注释中记录来源和单位，并补一条能直接失败的检查。不要把调试过程、已删除方案或整段测试报告留在实现文件中；Git 历史和测试代码更适合保存这些信息。

## 依据

实现主要参考学校发布的本科毕业论文规范及范例、研究生学位论文写作指南、研究生实践成果写作指南、阶段报告与声明页 Word 表单，并与姊妹项目 hithesis 的测量记录交叉核对。

模板常数优先取自原始 DOCX 属性；无法直接读取时，才用 Word 导出的 PDF 标定坐标。具体数值由测试固定，不在手册中重复抄写。
