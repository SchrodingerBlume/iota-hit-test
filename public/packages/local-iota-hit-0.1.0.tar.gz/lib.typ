// iota-hit —— hithesis 的 Typst 复刻。
//
// 正文与四级标题的纵向版面：版心、行距、首行基线落点、首行缩进、段前段后、
// 换页判据与孤行寡行；题注、目录、封面与各前置后置页都接在同一套换算上。
//
// 这个文件只有公开面：每个名字从 src/api.typ 或它所在的模块 re-export 一次，配一句
// 文档（编辑器悬停能看到）。实现在 src/，目录怎么分见 README「源码怎么分」。
// 加东西进来要想清楚：一旦导出就是承诺。

// ── 整篇 ──────────────────────────────────────────────────────────

/// 整篇文档的样式：`#show: iota-hit.with(degree-level: "master", title: [……])`。
/// 六根轴（校区、学位、交什么、阶段、学科门类、文档语言）、元信息、三态开关、
/// 样式表与页面设置都在这一个签名里。
#import "./src/api.typ": iota-hit

/// 前言段（默认态，罗马页码）→ 正文段（阿拉伯页码、页眉）→ 后置段的切换：
/// `#show: mainmatter`。后置与正文同一套页码页眉，通常不必写。
#import "./src/layout/matter.typ": frontmatter, mainmatter, backmatter

/// 段里再开一节（照 geometry 的 \newgeometry / \restoregeometry）：`#show: new-layout.with((margin: (top: 3cm)))`
/// 从这儿起换一份版面，自动翻页；`#show: restore-layout` 回到这一段的，没开过新节就什么都不发。
#import "./src/layout/matter.typ": new-layout, restore-layout

/// 附录：`#show: appendix`。章号换成「附录A」，里面的图表公式跟着变成「图 A-1」。
#import "./src/layout/matter.typ": appendix

/// 清到下一页（右手页起时补空白页），与部件的 openright 同一支。
#import "./src/layout/matter.typ": clear-page

/// 六档字体方案那张表：`fontset: presets.windows`，改一个角色写
/// `presets.founder + (kaishu: "TW-MOE-Std-Kai")`。
#import "./src/fonts/presets.typ": presets

/// 中文字号：`zihao.xiaosi`（12pt）、`zihao.wuhao`（10.5pt）……字号只有这一种写法。
#import "./src/fonts/presets.typ": zihao

/// Word 的页面设置折成 Typst 的 page：整份自己拼时用；局部改写直接给
/// `iota-hit(layout: (…))` 一个字典即可。
#import "./src/layout/resolve.typ": msword-layout

/// 某个部件页函数实际用的那份折好的版面（`docgrid.tracking` / `char-pitch` / `line-pitch`、
/// 版心……），要在 `context` 里调：`layout-of("achievements")`；`local:` 是这一页就地写的
/// `layout:`。`current-layout()` 是当前生效的那一层（文档＋段），不传部件名时用它。
/// 站内预览（iota4web）靠这两个读字符网格，改名或改返回形状要连带告知。
#import "./src/layout/resolve.typ": layout-of, current-layout

/// 局部样式：`#[ #show: styles.with((figure: (table: (line-spacing: 1.5)))) … ]`，
/// 字典形状与 `iota-hit(styles:)` 一模一样。
#import "./src/api.typ": styles

// ── 前置页 ────────────────────────────────────────────────────────

/// 封面。论文一档是封面，开题／中期一档是表单首页，同一个名字按 stage 派。
/// 参数 auto 一律取 `iota-hit(...)` 里写的元信息。
#import "./src/api.typ": cover

/// 中文内封与英文内封（硕博）。
#import "./src/api.typ": titlepage

/// 摘要：`#abstract(en: [English body.])[中文正文。]`，关键词从元信息取。
#import "./src/api.typ": abstract

/// 目录。博士中英两份、硕本只中文；英文档只出英文——`lang:` 可压。
#import "./src/api.typ": table-of-contents

/// 图表与公式索引。规范没有这一项，给它是因为原生 outline 排不出我们的章壳。
#import "./src/api.typ": list-of-figures, list-of-tables, list-of-equations

/// 物理量名称及符号表（可略，写了才有）；`nomenclature` 是符号与缩略语的合并页，
/// 与两张单页互斥。
#import "./src/pages/nomenclature.typ": list-of-symbols, nomenclature

/// 缩略语表：在这里声明条目并印表，正文里写 `@SCNA`。
#import "./src/pages/abbreviations.typ": list-of-abbreviations

// ── 正文 ──────────────────────────────────────────────────────────

/// 四级标题。`chapter[绪论]` 另起一页；不编号的写 `numbering: none`；这一章自己的文档网格
/// 写 `chapter(layout: (char-pitch: 12.65pt))`，到下一个一级标题为止。
#import "./src/heading/heading.typ": chapter, section, subsection, subsubsection

/// 给标题挂英文名（英文目录、英文书签用）：`#chapter[绪论 #en[Introduction]]`。
#import "./src/terms/lang.typ": en

/// 目录条目里强制换行的记号。
#import "./src/heading/heading.typ": tocbreak

/// 续表标注，写在表题里：`caption: [参数表 #continued]`。
#import "./src/figure/continued.typ": continued

/// 空回车段：模拟 Word 里单独按一次回车留下的空行，高度按 ¶ 的字号算。
#import "./src/paragraph/enter.typ": enter

/// 空出几个汉字的宽度：`#ccwd()`，退格 `#ccwd(-2)`。
#import "./src/api.typ": ccwd

/// 编号列表／圆点列表单次改悬挂或不悬挂。
#import "./src/paragraph/enum.typ": enum-hanging
#import "./src/paragraph/list.typ": list-hanging

/// 组图：写在图题里是分图题，写在正身里是组图排布，同一个名。
#import "./src/figure/kinds/image.typ": subs

/// 分图题，写在分图之下那一档。
#import "./src/figure/caption.typ": subfigure

/// 伪代码：`#figure(lovelace[…], caption: …)`；`algorithmic` 是行号版。
#import "./src/figure/kinds/algorithm.typ": lovelace, algorithmic

/// 公式底下的符号注释「式中 x——…」。
#import "./src/math/eqdenote.typ": eqdenote

/// 有限增量 ∆（U+2206），不是希腊字母的 Δ。
#import "./src/math/rules.typ": increment

/// 四个中文字族的入口：写 `songti[…]` 而不是家族名，换字体档自动跟上。
#import "./src/fonts/resolve.typ": songti, heiti, kaishu, fangsong

/// 编译那天的日期，跟 `text.lang` 走。
#import "./src/terms/date.typ": today

/// 索引项：正文里 `#idx[词]` 标，后置 `#index()` 印一页。
#import "./src/references/index.typ": idx

// ── 参考文献 ──────────────────────────────────────────────────────

/// 参考文献表就是 omni-gb7714 自己那个 `bibliography`，不套壳——章壳由 `iota-hit` 发。
#import "@local/omni-gb7714:0.1.0": bibliography

// ── 后置页 ────────────────────────────────────────────────────────

/// 结论、致谢：`#conclusion[…]`、`#acknowledgement[…]`。
#import "./src/pages/conclusion.typ": conclusion
#import "./src/pages/acknowledgement.typ": acknowledgement

/// 攻读学位期间取得创新性成果：一份专用 .bib，按类型分组，条目由 omni 排。
#import "./src/pages/achievements.typ": achievements

/// 原创性声明与使用授权。
#import "./src/pages/declarations.typ": declarations

/// 学位论文评阅人、答辩委员会名单及答辩决议（博士）。
#import "./src/pages/defense.typ": defense

/// 个人简历（除全日制硕士生外均增列，排最末）。
#import "./src/pages/resume.typ": resume

/// 索引页。
#import "./src/pages/index.typ": index
