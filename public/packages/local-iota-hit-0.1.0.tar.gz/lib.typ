
#import "@local/banshi:0.1.0" as banshi
/// 配置并排版哈尔滨工业大学学位论文。
#import "./src/iota-hit.typ": iota-hit
/// 切换文档分区，并应用相应的页码、页眉和页面设置。
#import "./src/layout/matter.typ": frontmatter, mainmatter, backmatter
/// 临时替换页面设置，或恢复当前分区的设置。
#import "./src/layout/matter.typ": new-layout, restore-layout
/// 进入附录并重置章号及浮动体编号。
#import "./src/layout/matter.typ": appendix
/// 结束当前页；双面排版时可补齐右页。
#import "./src/layout/matter.typ": clear-page
/// 提供模板内置的字体方案。
#import banshi.fonts: presets
/// 提供中文字号常量。
#import banshi.fonts: zihao
/// 以 Word 式参数配置整页版式。
#import banshi.layout: page-setup as msword-layout
/// 读取当前分区的页面设置。
///
/// 这两个函数依赖排版上下文，须在 `context` 中调用。
#import "./src/layout/parts.typ": layout-of, current-layout
/// 临时替换样式，或恢复文档级样式。
#import banshi.styles: new-styles, restore-styles
/// 排版封面；开题和中期报告使用报告首页。
#import "./src/pages/front.typ": cover
/// 排版中英文题名页。
#import "./src/pages/front.typ": titlepage
/// 排版中英文摘要。
#import "./src/pages/front.typ": abstract
/// 排版目录；中文博士论文默认同时排英文目录。
#import "./src/pages/front.typ": table-of-contents
/// 排版插图、表格和公式索引。
#import "./src/pages/front.typ": list-of-figures, list-of-tables, list-of-equations
/// 排版符号表，或合并排版符号和缩略语。
#import "./src/pages/nomenclature.typ": list-of-symbols, nomenclature
/// 声明并排版缩略语表。
#import "./src/pages/abbreviations.typ": list-of-abbreviations
/// 排版带模板样式和编号的各级标题。
#import "./src/heading/heading.typ": chapter, section, subsection, subsubsection
/// 标出内容里英文的那一半：标题、题注、元信息、摘要、关键词都用它。
#import "./src/terms/lang.typ": en
/// 英文档里标出中文的那一半。
#import "./src/terms/lang.typ": zh
/// 在目录条目中换行，不改变正文标题和页眉。
#import "./src/heading/heading.typ": tocbreak
/// 续排上一个图、表或代码块，不占用新编号。
#import "./src/figure/continued.typ": continued
/// 图注、表注：写在 figure 正身里图或表之后，排在写的位置，宽跟图表走。
#import "./src/figure/note.typ": figure-note
/// 插入以段落标记字号计量的空行。
#import banshi.paragraph: paragraph-mark as enter
/// 返回指定数量的中文字符宽度。
#import banshi.layout: h-chars as ccwd
/// 临时切换编号列表的悬挂方式。
#import banshi.paragraph: enum-hanging
/// 临时切换项目列表的悬挂方式。
#import banshi.paragraph: list-hanging
/// 组合多个分图，或在题注中组合多个分图题。
#import "./src/figure/kinds/image.typ": subs
/// 创建可单独引用的分图。
#import "./src/figure/kinds/image.typ": subfigure
/// 创建 Lovelace 或 algorithmic 语法的伪代码。
#import "./src/figure/kinds/algorithm.typ": lovelace, algorithmic
/// 排版公式后的符号说明。
#import "./src/math/eqdenote.typ": eqdenote
/// 有限增量符号 ∆（U+2206）。
#import "./src/math/equation.typ": increment
/// 定理类环境：编号跟公式一样按章，头黑体（英文加粗），头后空一字。
#import "./src/math/theorem.typ": theorem, lemma, definition, proposition, corollary, axiom, assumption, example, remark, problem, conjecture, fact, exercise
/// 证明：不编号。
#import "./src/math/theorem.typ": proof
/// 使用当前字体方案中的宋体、黑体、楷体和仿宋。
#import banshi.fonts: songti, heiti, kaishu, fangsong
/// 使用当前字体方案中的西文衬线、无衬线角色：整段按西文字体排，弯引号也归西文。
#import banshi.fonts: serif, sans
/// 按文档语言和指定精度排版当前日期。
#import "./src/terms/date.typ": today
/// 登记索引词并原样排版正文内容。
#import "./src/references/index.typ": idx
/// 按学校要求排版参考文献。
#import "@local/omni-gb7714:0.1.0": bibliography
/// 排版结论页。
#import "./src/pages/conclusion.typ": conclusion
/// 排版致谢页。
#import "./src/pages/acknowledgement.typ": acknowledgement
/// 排版攻读学位期间取得的成果。
#import "./src/pages/achievements.typ": achievements
/// 排版原创性声明和使用授权。
#import "./src/pages/declarations.typ": declarations
/// 排版论文评阅、答辩名单和答辩决议。
#import "./src/pages/defense.typ": defense
/// 排版个人简历。
#import "./src/pages/resume.typ": resume
/// 排版按拼音分组的索引页。
#import "./src/pages/index.typ": index
