// 公开面的实现：iota-hit() 本体（show 规则链）与前置页面的公开包装。
// lib.typ 只 re-export 这里的名字并配文档；用户看到的签名就是这里的签名。
//
// ── 前置页面的公开包装 ──────────────────────────────────────────
//
// 这一层只做一件事：*把 info 里的元信息填给部件*。部件本身仍然只认显式
// 参数——那是对拍件直接调的那一档，一行不用改；用户调的是这里的同名函数，
// 题目姓名只写一遍。
//
// 用户在调用处写的参数照样压过 info：两份字典相加，后者赢。
//
// *为什么不把 state 读进部件里。* 部件要在函数体一开头就用到题目
// （封面那个求解器要量题目的高），读 state 就得把整个函数体圈进 context，
// 而部件里还发着 set page——虽然实测 context 里发 set page 是好使的，但那样
// 每个部件都得改一遍，且对拍件也跟着进 context。放在外面一层最省。

#import "./info.typ": final-only-wanted, info-get, value-of
#import "./errors.typ": once
#import "./terms/lookup.typ": term-table, variant-of
#import "./layout/matter.typ": frontmatter-openright, cover-exit-odd, cover-exit, clear-page, frontmatter, mainmatter, backmatter, appendix
#import "./settings/resolve.typ": resolve-openright
#import "./layout/resolve.typ": layout-for, msword-layout
#import "./terms/lang.typ": normalize as normalize-lang, doc-lang
#import "./pages/cover.typ" as _cover
#import "./pages/titlepage.typ" as _titlepage
#import "./pages/abstract.typ" as _abstract
#import "./pages/outline.typ" as _toc
#import "./pages/report/cover.typ" as _report
#import "./pages/report/shenzhen/cover.typ" as _report-shenzhen
#import "./layout/presets.typ": report-toc-headerless as _toc-headerless
#import "./axes.typ": campus-for

// *目录页排不排页眉，逐份不同*，见 src/layout/presets.typ 的
// report-toc-headerless。
//
// *走 set page，不走版面的差额*：页眉页脚是一节的 set 发的（见
// src/layout/section.typ），部件那一层的版面差额改不到它。裹在一个块里，只管
// 目录这几页——目录本来就另起一页，后面的部件也各自另起
#let _toc-headerless-page(info, body) = {
  let bare = info.stage in _toc-headerless
    .at(campus-for(info.campus, info.degree-level), default: (:))
    .at(info.degree-level, default: ())
  // *set 要与 body 同在一个块里*：写成 if bare { set … } 的话那条 set 只管
  // 那个空块，body 在块外照旧带页眉（实测目录页的页眉一个字没少）
  if bare {
    set page(header: none)
    body
  } else { body }
}

// 中文封面。
// *参数逐个列出来，不用 ..args。* 先前是个沉没参数，转发的其实就是下面这几个
// ——列得出来，不是无限集；而沉没参数把 LSP 的补全吃掉了，用户得翻源码才知道能写
// 什么。auto 一律表示「取 #info 存的那一份」。
// 报告那两档的首页与论文封面毫不相干，走 src/pages/report/cover.typ；
// *用户 API 不变*——第一页就是第一页，不该为报告另发明一个函数名
#import "./axes.typ": report-stages as _report-stages


// 页面的版面：文档＋段那一份（layout-state）并上部件差额，再并用户在这一页写的
// 局部字典；整份就整份替换。梯子的五层见 src/layout/resolve.typ 的 layout-for。
// 这一层本来就在 context 里，读得到 state；封面内封在 context 外面发 set page，
// 所以由这儿填好再传下去。

#let cover(
  // 印在封面上的*题目*。auto 取 info 的 title。
  // 目录、参考文献那些部件的 title 是「这一块印的标题」，封面印的标题就是论文
  // 题目——同一句话，不是两种含义
  title: auto,
  title-en: auto,
  title-en-xiaoer: auto,
  // 副题目。auto 取 info 的 subtitle / subtitle-en；那边的默认是 none ＝ 没有
  subtitle: auto,
  subtitle-en: auto,
  author: auto,
  institution: auto,
  date: auto,
  degree-level: auto,
  degree-type: auto,
  // 交上去的是哪一种东西，见 src/axes.typ 的 form。practice 那一档换标签
  // 与学位类别那一行，括号里填的是实践成果类型
  form: auto,
  practice-type: auto,
  // 排不下时发不发提示，见 src/pages/report/cover.typ
  warning: auto,
  // 排成范例那一页的样子——每个元素下面跟着「↑」与一行说明。*对拍用*
  annotated: auto,
  label: auto,
  layout: auto,
  // 只改这一页的词条
  overrides: (:),
) = context {
  once("cover")
  let i = info-get()
  if i.stage in _report-stages {
    // *深圳本科那两份是另一页*（两行小初华文新魏 ＋ 一张两列的表），
    // 与本部本科、与深圳研究生都不共构，所以在这儿分岔——那一支不 import
    // 这一支、这一支也不 import 那一支，页面按档挑是这一层的事。
    // 研究生那两份与本部同构，只是几个数不同，留在 _report 的表里
    if campus-for(i.campus, i.degree-level) == "shenzhen" and i.degree-level == "bachelor" {
      return _report-shenzhen.cover(
        stage: i.stage, info: i, overrides: overrides, layout: layout,
        lang: doc-lang.get(),
        ..(if title != auto { (title: title) } else { (:) }),
        ..(if warning != auto { (warning: warning) } else { (:) }),
      )
    }
    return _report.cover(
      stage: i.stage, info: i, overrides: overrides,
      ..(if title != auto { (title: title) } else { (:) }),
      // 排不下时纸角那条红字：与终稿封面同一个开关，写了才往下传
      ..(if warning != auto { (warning: warning) } else { (:) }),
      // *报告首页的版面在那一头解*：这一页有没有自己的一节要看校区与阶段
      // （深圳开题的首页自成一节，见 src/layout/presets.typ 的 report-cover-layouts），
      // 而校区那一档是在那一头按学位定的。用户这一页写的原样递过去，
      // 那边并在差额之上。报告首页整支都在 context 里，读得到 state
      layout: layout,
    )
  }
  let pick(v, k) = if v != auto { (k, v) } else { (k, i.at(k)) }
  // *带 -en 的那几条没写就回落*到不带后缀的那一条（默认表里它们是 auto，
  // 见 src/info.typ）——英文单语的文档不必把同一个学院名写两遍
  let pick-en(v, k, base) = if v != auto { (k, v) } else {
    (k, value-of(i, base, lang: "en"))
  }
  // *封面之后那一跳是封面自己的出口*，不是内封的：hithesis 的三次
  // \__hit_cover_break: 头一次就在封面之后。先前只有 titlepage() 记这条旗子，
  // 只排封面不排内封的文档（博士、cover 后直接目录）就静默不跳，目录落在第 2 页。
  // 这儿先按 titlepage 那个切页点记下，titlepage() 若跟着来会再记一次（同值）；
  // 跳本身仍由后面第一个前置部件补，理由见 src/layout/matter.typ 的 cover-exit
  cover-exit-odd.update(resolve-openright(
    "titlepage", degree-level: i.degree-level, matter: frontmatter-openright.get(),
  ))
  _cover.cover(
    terms: term-table("zh", "cover", overrides: overrides),
    variant: variant-of(i),
    ..(
      (
        pick(title, "title"), pick-en(title-en, "title-en", "title"),
        pick(title-en-xiaoer, "title-en-xiaoer"),
        pick(subtitle, "subtitle"), pick(subtitle-en, "subtitle-en"),
        pick(author, "author"),
        pick(institution, "institution"), pick(date, "date"),
        pick(degree-level, "degree-level"), pick(degree-type, "degree-type"),
        pick(form, "form"), pick(practice-type, "practice-type"),
      ).to-dict()
    ),
    ..(
      ((("warning", warning), ("annotated", annotated), ("label", label),
        ("layout", layout-for("cover", layout))).filter(((k, v)) => v != auto)).to-dict()
    ),
  )
}

// 内封（扉页）。中文一页；硕士与博士后面还跟一页英文内封。
//
// *英文内封不单独开一个函数。* 它不是用户要不要排的选择，是学位定的：
// hithesis（hit-thesis.cls:7340）写的是
//
//     \bool_lazy_or:nnF { postdoc } { bachelor } { … \hit@titlepage@en … }
//
// ——「既不是博士后、也不是本科」才排，即硕士与博士。所以这里按学位自动跟上，
// 用户写一次 titlepage() 就够。
//
// lang 说*排哪几份*，与 abstract / toc 同义：
//
//   auto        模板决定——按学位：研究生中英两页，本科只有中文那一页
//   "zh"        只排中文内封
//   "en"        只排英文内封
//
// *内封不跟文档语言走。* 英文版论文照旧要中文内封（规范没给英文版的
// 内封另立一档，我们也没有那份范例），所以 auto 只看学位。哪天有了英文版
// 的规定，改的是这一处，别处不动。
//
// en 收英文那一页的覆盖字典（比如 degree-attribute），不再兼任开关——
// 「排不排」由 lang 说了算，两件事分开。
//
// 位置参数（..args）只发给中文那一页——两页收的键不是一套（中文收 label /
// secrecy / school-code，英文收 degree-attribute），一份参数发两处会撞。
// 参数逐个列出来，理由同 cover：沉没参数把补全吃掉了。
// auto 一律表示「取 #info 存的那一份」。
#let titlepage(
  // 印在内封上的题目。中文页取 title，英文页取 title-en
  title: auto,
  title-en: auto,
  title-en-xiaoer: auto,
  // 副题目。「格式同封面」，中文页排在题目下面、英文页用冒号接上
  subtitle: auto,
  subtitle-en: auto,
  // 「Dissertation for the … Degree」那一行，只英文页有
  degree-attribute: auto,
  degree-level: auto,
  form: auto,
  secrecy: auto,
  classified-index: auto,
  udc: auto,
  // 字段表，(标签, 内容) 的有序表。*先前整个没透下去*——部件本身收它，
  // 而从 lib.typ 拿到的这个包装层不收，用户*加不了行*（副导师、行业导师这类
  // 规范里「无……不列此项」的行正要靠它）
  fields: auto,
  school-code: auto,
  // 排不下时发不发提示，见 src/styles/parts.typ 的 overflow-note
  warning: auto,
  // 排成范例那一页的样子，*对拍用*
  annotated: auto,
  label: auto,
  layout: auto,
  // 排中文页还是英文页。auto 按学位：本科只中文，研究生两页都排
  lang: auto,
  // 英文页专有的其余取值，原样透给它
  en: (:),
  openright: auto,
  overrides: (:),
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("titlepage")
  let i = info-get()
  // 内封从右手页起。四层让位：这次调用的参数 → frontmatter 段的显式值 →
  // 总闸 → 按学位的默认表（博士 true，本硕 false，见 src/settings/defaults.typ）。
  // 博士那一档跟的是 hithesis 的 \__hit_cover_break:。
  let odd = resolve-openright(
    "titlepage",
    degree-level: i.degree-level,
    local: openright,
    matter: frontmatter-openright.get(),
  )
  // 写了就用、没写就取 info 那一份；没有对应 info 键的（annotated 这些）写了才传，
  // 让内层的默认值说话
  let pick(v, k) = if v != auto { (k, v) } else { (k, i.at(k)) }
  // *带 -en 的那几条没写就回落*到不带后缀的那一条（默认表里它们是 auto，
  // 见 src/info.typ）——英文单语的文档不必把同一个学院名写两遍
  let pick-en(v, k, base) = if v != auto { (k, v) } else {
    (k, value-of(i, base, lang: "en"))
  }
  let only(..kv) = kv.pos().filter(((k, v)) => v != auto).to-dict()
  // *英文页专有的取值单独一份。* 中文页没有 title-en 这些参数，混进去会撞上
  // 「unexpected argument」。见 src/pages/titlepage.typ 的 en-only-keys。
  let en = en + only(
    ("title-en", title-en), ("title-en-xiaoer", title-en-xiaoer),
    ("subtitle-en", subtitle-en),
    ("degree-attribute", degree-attribute),
  )
  let named = only(
    ("title", title), ("subtitle", subtitle),
    ("form", form), ("secrecy", secrecy),
    // *这两个先前漏在这儿*：签名收着，转发时没带上，用户写了*静默失效*
    // （实测填了国内图书分类号与 UDC，页面上一个字都没有）
    ("classified-index", classified-index), ("udc", udc),
    ("fields", fields),
    ("school-code", school-code),
  ) + only(("warning", warning), ("annotated", annotated), ("label", label)) + (layout: layout-for("titlepage", layout))

  let want = if lang == auto {
    if i.degree-level in ("master", "doctor") { ("zh", "en") } else { ("zh",) }
  } else {
    (normalize-lang(lang),)
  }

  if "zh" in want {
  clear-page(to: if odd { "odd" } else { none })
  _titlepage.titlepage(..((
    terms: term-table("zh", "titlepage", overrides: overrides),
    info: i,
    degree-level: i.degree-level,
    title: i.title,
    subtitle: i.subtitle,
    secrecy: i.secrecy,
    form: i.form,
    classified-index: i.classified-index,
    udc: i.udc,
    school-code: i.school-code,
  ) + named))
  }

  if "en" in want {
    // 英文内封同样
    clear-page(to: if odd { "odd" } else { none })
    _titlepage.titlepage-en(..((
      terms: term-table("en", "titlepage", overrides: overrides),
      info: i,
      degree-level: i.degree-level,
      // *走 value-of 不直接读*——title-en 的默认是 auto（＝没写），
      // 回落到 title 那一条，见 src/info.typ
      title-en: value-of(i, "title", lang: "en"),
      title-en-xiaoer: i.title-en-xiaoer,
      subtitle-en: i.subtitle-en,
      form: i.form,
      classified-index: i.classified-index,
      udc: i.udc,
    ) + only(("warning", warning), ("annotated", annotated)) + (layout: layout-for("titlepage", layout)) + en))
  }
  // *收尾那一跳不在这儿发*，只把取值记下来，由后面第一个前置部件补上
  // ——理由见 src/layout/matter.typ 的 cover-exit。hithesis 是三次
  // \__hit_cover_break:（封面之后、中文内封之后、英文内封之后），末一次正是
  // 这一跳，它把摘要顶到右手页。
  cover-exit-odd.update(odd)
}

// 摘要。中英两份一次给全。
//
// *正文走位置参数，收尾随内容块*——摘要正文动辄十几行，写成具名参数会
// 被两行短短的关键词夹在中间，读起来找不到头。这也是 Typst 里内容型参数的
// 常规写法（#figure(…)[…]），neu-typst-latest-cap-able 的 neu-thesis-abstract
// 同款。
//
// *形状与 #chapter(en: […])[…] 同款*：正文槽恒为中文，en: 恒为英文。
// 早先摊平成四个参数（keywords / keywords-en / zh / en）配对全靠书写顺序，
// 那是因为关键词还在这一层；关键词进 info 之后只剩两份正文，具名一个就够了。
//
// 关键词从 info 取（zh 取 keywords，en 取 keywords-en）——它是著录用的元数据，
// 跟题目、作者同级，见 src/info.typ。
//
// lang 说*排哪几份*，与 titlepage / toc 同义：
//
//   auto        给了 en: 就两份都排，没给只排中文
//   "zh"/"en"   只排那一份。*只排一份而又没写 en: 时，正文槽就是那一份*
//               ——#abstract(lang: "en")[English body.] 照旧管用
//
// *不查「英文那份有没有写」。* 规范要求两页都有，但漏没漏是用户的事——
// 用户怎么写就怎么排。摘要正文也*不*跨语言回落：标题回落是因为印出来的
// 东西不能没有内容，而少一页摘要就是少一页，拿中文正文冒充英文摘要才是错的。
#let abstract(
  content,
  // 英文摘要正文
  en: none,
  // 这一页印的标题。auto 取词条。中英两页各一份——它们是两个部分，各印各的
  title: auto,
  title-en: auto,
  // 排哪几份，见上
  lang: auto,
  // 只改这一页的词条
  overrides: (:),
  // 只改这一页要不要从右手页起
  openright: auto,
  // 英文那一页的版面。auto 就用部件自己的默认（与正文同一套）
  layout: auto,
  // 关键词上面放什么：auto 隔一行（规范）、none 不空、长度、内容（v(1fr) 挤到页底）。
  // 中英两页同一个值，见 src/pages/abstract.typ
  keywords-above: auto,
  // 关键词折行时后面的行要不要悬挂到第一个词下面。auto ＝ 不写 ＝ 顶格（指南「顶格书写」，
  // 范例没有折行的样子）；true 按 hithesis 的排法悬挂。中英两页同一个值
  keywords-hanging: auto,
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("abstract")
  // 封面序列的出口那一跳，第一个来的人补上，见 src/layout/matter.typ。
  // 放在包装层而不是部件里边：部件是照排版规矩画页面的，谁先谁后是装配的事。
  cover-exit()
  context {
    let i = info-get()
    let bodies = if lang != auto and en == none {
      // 只排一份、又没写 en:，正文槽就是那一份
      ((normalize-lang(lang), content),)
    } else {
      (("zh", content), ("en", en)).filter(((l, b)) => b != none)
    }
    if lang != auto {
      bodies = bodies.filter(((l, b)) => l == normalize-lang(lang))
    }
    for (l, body) in bodies {
      _abstract.abstract(
        lang: l,
        // 只有一篇时英文目录里就叫 Abstract，两篇才带 (In Chinese) / (In English)
        single: bodies.len() == 1,
        title: if l == "en" { title-en } else { title },
        keywords: if l == "en" { i.keywords-en } else { i.keywords },
        overrides: overrides,
        openright: openright,
        layout: layout-for("abstract", layout),
        keywords-above: keywords-above,
        keywords-hanging: keywords-hanging,
        body,
      )
    }
  }
}

// 目录。lang: auto 时模板自己决定出哪几份——中文档按学位（博士中英两份，
// 硕本只有中文那份），英文档只出英文那一份。见 src/pages/outline.typ
// *参数逐条写出来，不用 ..args 一兜。* 兜起来 LSP 就补全不出来——编辑器
// 只认声明出来的签名，sink 里的名字它看不见。封面与内封当初也是这么改的。
//
// *默认值一律写 auto，不在这一层复述*：真正的默认住在 src/pages/outline.typ
// 那一份签名里，写了才往下传，没写就让它自己定。抄一遍默认就是抄一份会烂的表。
//
// degree-level 与 doc-lang 不在这一层露面：它们是从 info 与文档语言*推出来*的，
// 由这里填好再往下传，用户写不着。
#let _set(..pairs) = {
  let out = (:)
  for (k, v) in pairs.named() {
    if v != auto { out.insert(k, v) }
  }
  out
}

#let table-of-contents(
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  // 目录自己进不进目录。auto ＝ 不进，见 src/pages/outline.typ
  outlined: auto,
  // 收到第几级。auto ＝ 不写 ＝ 到条级（1.2.1）
  depth: auto,
  levels: auto,
  overrides: (:),
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  // 英文目录里读着是中文的条目后面的红字。auto ＝ 发，false 关这一页的；单条写
  // #en(warning: false)。见 src/pages/outline.typ 的 _en-warn
  warning: auto,
) = {
  // 同 abstract，见那里的说明
  cover-exit()
  context {
    let i = info-get()
    _toc-headerless-page(i, _toc.toc(
      degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
      title: title, title-en: title-en, two-hanzi: two-hanzi, openright: openright,
      overrides: overrides, heading-body-indent: heading-body-indent,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
      lang: lang, once: true, outlined: outlined, warning: warning,
      .._set(
        depth: depth, levels: levels,
        fill: fill, layout: layout-for("toc", layout),
      ),
    ))
  }
}

// 图表索引。语言判定与 toc 一字不差，所以学位与文档语言也在这一层填好。
// *两个只差交给谁排*，签名同一份，摊开写在这里
#let _list-of(which) = (
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  overrides: (:),
  levels: auto,
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  // 英文那一份里读着是中文的题注后面的红字，同 table-of-contents
  warning: auto,
) => context {
  let i = info-get()
  which(
    degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
    campus: campus-for(i.campus, i.degree-level),
    title: title, title-en: title-en, two-hanzi: two-hanzi, openright: openright,
    overrides: overrides, heading-body-indent: heading-body-indent,
    outline-entry-right-margin: outline-entry-right-margin,
    outline-entry-number-align: outline-entry-number-align,
    outlined: outlined, lang: lang, once: true, warning: warning,
    .._set(levels: levels, fill: fill), layout: layout-for("toc", layout),
  )
}

#let list-of-figures = _list-of(_toc.lof)
#let list-of-tables = _list-of(_toc.lot)

// 公式清单：条目是名、编号加公式本身。签名比图表清单多一个 form（公式按行内还是
// 行间形态排，见 src/pages/outline.typ）——只有它有这一项，所以单独一份包装
#let list-of-equations(
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  overrides: (:),
  levels: auto,
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  form: auto,
) = context {
  let i = info-get()
  _toc.loe(
    degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
    campus: campus-for(i.campus, i.degree-level),
    title: title, title-en: title-en, two-hanzi: two-hanzi, openright: openright,
    overrides: overrides, heading-body-indent: heading-body-indent,
    outline-entry-right-margin: outline-entry-right-margin,
    outline-entry-number-align: outline-entry-number-align,
    outlined: outlined, lang: lang, once: true, form: form,
    .._set(levels: levels, fill: fill), layout: layout-for("toc", layout),
  )
}

// ── iota-hit() ────────────────────────────────────────────────────
// ── 内部件 ────────────────────────────────────────────────────────
// 整包挂在模块名下。别名带下划线，是因为 iota-hit() 的参数就叫 layout / styles / info /
// terms / settings——裸名会被参数遮住。公开面在 lib.typ 逐个 re-export，这里不导出什么。
#import "./axes.typ": report-stages as _report-stages
#import "./axes.typ": final-body as _final-body
#import "./layout/chars.typ" as chars
#import "./paragraph/linebox.typ" as linebox
#import "./layout/state.typ": layout-state, section-layout-state, matter-layout-state
#import "./fonts/resolve.typ" as _fonts
#import "./fonts/fake.typ" as _synth
#import "./styles/body.typ" as _body
#import "./heading/rules.typ" as _heading
#import "./heading/heading.typ" as _heading-mod
#import "./layout/resolve.typ" as _layout
#import "./fonts/quotes.typ" as _quotes
#import "./math/rules.typ" as _math
#import "./fonts/hant.typ" as _hant
#import "./fonts/tracking.typ" as _tracking
#import "./terms/lang.typ" as _lang
#import "./figure/caption.typ" as _captions
#import "./figure/kinds.typ": algorithm-kind as _algorithm-kind
#import "./figure/kinds/raw.typ" as _listing
// 缩略语：接 glossy 的那一层。主 show 把它的规则装在最内层，见那个文件
#import "./references/abbreviations.typ" as _abbreviations

// ── 公开面 ────────────────────────────────────────────────────────
// 用户拿得到的就是下面这些。加东西进来要想清楚：一旦导出就是承诺。

// 版面：整份自己拼时用。局部改写不必经它——给 iota-hit(layout:) 一个字典就并到
// 本档默认上，字段表见 src/layout/resolve.typ；用户写 3.8cm，折缇是包里的事
// 中文字号：写 zihao.wuhao（10.5pt）。*字号只有这一种写法*——styles: (body: (size: zihao.xiaosi))、
// enter(size: zihao.erhao)、layout: (base-size: zihao.xiaosi)、set text(size: zihao.wuhao) 都是它；
// 先前包自己的口子还收字符串档名 "xiaosi"，同一个字号两种写法，删了
#import "./fonts/presets.typ": zihao, presets

// 排版时会用到的几个函数
#import "./paragraph/enter.typ": enter          // 空回车段
#import "./paragraph/enum.typ" as _enum
#import "./paragraph/enum.typ": enum-hanging    // 编号列表单次改悬挂／不悬挂
#import "./paragraph/list.typ" as _list
#import "./paragraph/list.typ": list-hanging    // 圆点列表单次改悬挂／不悬挂
#import "./paragraph/enter.typ": enter-height as _enter-height
// 空出一个汉字的宽度：写 #ccwd()，退格写 #ccwd(-2)。
//
// *给的是空当，不是那个数。* 用户十有八九要的是「这里空一个字」，先前得写
// #context h(ccwd())、退格得写 #context h(-ccwd(2))——套两层才排得出一个空当。
// 现在 h 与 context 都收进来了。
//
// *要那个长度的场合写 (chars: n)*，见 src/layout/chars.typ 的 resolve-chars：参数值
// 里调不了 ccwd()（那要上下文），凡是「空几个字」的取值都收这种写法，
// 例如 caption-body-indent: (chars: 0.5)。
#let ccwd(..n, layout: auto) = context h(chars.ccwd(..n, layout: layout))

#import "./terms/date.typ": today           // 编译那天，跟 text.lang 走
#import "./math/rules.typ": increment       // 有限增量 ∆ U+2206，不是希腊的 Δ
#import "./terms/lang.typ": en                // 给标题挂英文名
#import "./heading/heading.typ": tocbreak          // 目录条目里强制换行的记号
#import "./figure/kinds/image.typ": subs               // 分图题（写在图题里）与组图排布（写在正身里），同一个名
#import "./figure/caption.typ": subfigure  // 分图题，写在分图之下那一档
// 参考文献。*条目表就是 omni 自己那个 bibliography，我们不套壳*——套了
// LSP 就补不出它那七十多个参数。章壳走 gb7714(title:) 发进去，见那个文件
#import "./pages/references.typ": _omni, references-title as _references-title
#import "./references/bibliography.typ": gb7714-for as _gb7714-for
#import "@local/omni-gb7714:0.1.0": bibliography
#import "./math/eqdenote.typ": eqdenote  // 公式底下的符号注释「式中 x——…」
#import "./figure/continued.typ": continued         // 续表标注，写在表题里
#import "./figure/kinds/algorithm.typ": lovelace, algorithmic  // 伪代码，#figure(lovelace[…], caption: …)
#import "./heading/numbering.typ": nonumber-rules as _nonumber-rules
#import "./fonts/case.typ" as _case
#import "./errors.typ" as _once
// 只该印一次的页：公开名上套一层计数，页面模块自己不计——对拍件要在一篇里排
// 几份变体，直接调页面模块那一份。见 src/errors.typ

#import "./heading/heading.typ": chapter, section, subsection, subsubsection

// 中文字族入口。写 songti(...) 而不是写家族名，换字体档自动跟上
#import "./fonts/resolve.typ": songti, heiti, kaishu, fangsong
// 六档字体方案那张表。
//
// *表叫 presets，参数叫 fontset*：表里装的是现成的几套，挑出来的那一套就是
// 这篇文档的 fontset——用户自己手写一份角色字典同样是 fontset，只是不是 preset。
//
// 「以某一档为底、改其中一两个角色」用 Typst 自己的字典合并就够了，不另造机制：
//
//     fontset: presets.founder + (kaishu: "TW-MOE-Std-Kai")
//
// 见 src/fonts/presets.typ
#import "./fonts/underline.typ" as _underline
#import "./fonts/super-sub.typ" as _super-sub

// 元信息与文档流
#import "./info.typ" as _info
#import "./settings/resolve.typ" as _settings
// *整模块导入，不平铺。* term-of 与 terms-overrides 是内部件，平铺进来
// 就会跟着 lib.typ 的 * 漏进用户作用域；而且 iota-hit 有个同名参数会遮蔽
// terms-overrides。挂在 _terms 下两件事一起解决。
#import "./terms/lookup.typ" as _terms
#import "./axes.typ" as _axes
#import "./errors.typ" as _errors
// 一节的 set（版心、页眉页脚、正文的字与段），文档级发一次，各段再发一次
#import "./layout/section.typ" as _section
// 附录。阶段开关，与 matter 同形：#show: appendix。章号换成「附录A」/「附录1」，
// 里面的图表公式跟着变成「图 A-1」，见 src/layout/matter.typ

// 样式表的机制：局部字典并到默认表（src/styles/presets.typ）上、键名验错、记进 state
#import "./styles/sheet.typ" as sheet
#import "./paragraph/linebox.typ" as linebox
// 局部样式：#[ #show: styles.with((figure: (table: (line-spacing: 1.5)))) … ]，字典形状与
// iota-hit(styles:) 一模一样，见 src/styles/sheet.typ 的 scoped
#let styles(local, body) = sheet.scoped(local, body)
#import "./styles/presets.typ" as _config-styles
#import "./layout/presets.typ" as _config-layout
#import "./settings/defaults.typ" as _config-settings
#import "./info.typ": info-defaults as _info-defaults

// 正文层次的四份编号预设。*不导出*——层次编号是规范定死的（两份指南各一张
// 「表2 层次代号及说明」），auto 按 lang 与 category 把官方那四种情形全覆盖了；
// 用户改了会被 src/heading/rules.typ 的哨兵拦下并指到那两个参数上。
// 取值与出处见 src/heading/numbering.typ
#import "./heading/numbering.typ" as _numbering

// 开题报告与中期报告那两档。*它们不是论文的一个变体*，是另发的表单：
// 版面、页眉页脚、页码三样全不一样，见 src/layout/presets.typ。

#let iota-hit(
  // 页面设置（Word 的「节」：页边距、文档网格、页眉页脚），见 src/layout/resolve.typ。
  //
  //   auto        按档：终稿一份，开题与中期按学位与阶段各一份（本科四边 2.3cm、
  //               无网格；硕博上左右 2.5cm、下边距各份各写、开着行网格），
  //               表在 src/layout/presets.typ
  //   局部字典    并到本档默认上：layout: (margin: (top: 3cm), header: (shown: false))
  //   整份        msword-layout(...) 就是整份替换
  //
  // 段与页还能再并：frontmatter / mainmatter / backmatter(layout:) 与各页函数的 layout:
  layout: auto,
  // 样式表（Word 的样式窗格：一条 = 字体对话框 + 段落对话框）。局部字典逐条并到
  // 默认表上，键是 body / chapter / section / subsection / subsubsection / caption /
  // toc-1 / toc-2 / toc-3 / toc-4：
  //
  //     styles: (body: (size: "wuhao"), chapter: (align: left))
  //
  // 每条能写什么、默认值与出处见 src/styles/presets.typ；不认识的键当场报错。
  // 页眉页脚的样式不在这里，住 layout.header.style / layout.footer.style。
  styles: (:),
  // 字体方案。*auto ＝ 不写 ＝ 模板决定*，默认档名只有 src/fonts/presets.typ 一份
  // （先前这里写死 "windows"，与那边的 default-preset 是同一个默认的两份抄本）
  fontset: auto,
  // 中文加粗、中文强调怎么合成，都是三态。auto 各问各的：伪粗问「这个字体有没有
  // 真粗面」，伪斜问「楷体在不在」——伪粗是真粗的替代品，伪斜是「换楷体」的第三
  // 顺位。取值与理由见 src/settings/defaults.typ 的 base 桶
  fake-bold: auto,
  fake-italic: auto,
  // *学科门类*，不是学位类别（那个是 degree-type）。学校的《学位论文写作指南》
  // 出成两份：（理工类）与（人文社科类）——两份逐条对过，*只有正文层次的编号
  // 不同*（第一章／一、／（一）／1.），字号行距段距一个数都不差。
  //
  //     #show: iota-hit.with(category: "hass")    人文社科类，"hss" 是同一档的别名
  //
  // auto ＝ 不写 ＝ "stem"。档名照学校自己的文件名（g-stem.docx / g-hss.docx），
  // 正名取含艺术的 hass，见 src/axes.typ
  category: auto,
  // 页码的样式。*auto ＝ 按 form 挑*：论文与实践成果排阿拉伯数字，开题与
  // 中期*不排页码*——两份表单的 default 页脚是空的（even 那一份里躺着一个
  // PAGE 域，可文档既没有 w:evenAndOddHeaders 也没有 w:titlePg，那个域不生效）。
  // 整篇论文由 #show: frontmatter 与 #show: mainmatter 两处切换，见 src/flow。
  page-numbering: auto,
  // 文档语言，收 "zh" / "en" / auto。*一篇一个值，中途改不了*——
  // 它定的是整篇的结构（标题取哪一份、词条走哪一层、目录出几份、页眉排哪一份、
  // 编号用哪一套），这些跨页的东西不该因为某一段切了语言就抖。见 src/terms/lang.typ
  //
  // *默认是 "zh" 而不是 auto*，这一处是 auto 约定的例外。auto 的意思是
  // 「跟 #show: iota-hit *之前*那句 #set text(lang: …) 走」，可 Typst 的
  // text.lang *默认就是 "en"*（实测 #context text.lang 给 en）——写 auto
  // 而外面什么都没设，读出来是英文。「不写＝中文」与「auto＝不写」两条只能留
  // 一条，留的是前者：绝大多数人写的是中文论文，不该先学一个开关。
  //
  // 所以三种写法：
  //
  //     #show: iota-hit                                  中文
  //     #show: iota-hit.with(lang: "en")                 英文
  //     #set text(lang: "en"); #show: iota-hit.with(lang: auto)   英文
  lang: "zh",
  // 英文标题的大小写：auto（＝本档默认，现在是 none）、none 原样、"sentence" 句式、
  // "title" 题式；也收字典按槽分——(term: 学校字样, heading: 章节名, caption: 题注
  // 英文名, rest: 兜底)，如 (term: none, rest: "title")。名与义照 omni 的
  // titles-text-case；花括号 {…} 里的不动（跟 .bib 一个方案，开没开都剥掉括号，
  // {{ }} 印字面）；词里有非首字母大写或数字的自动不动。见 src/fonts/case.typ
  title-case: auto,
  // 居中的两字标题中间空不空一个字（「摘  要」「绪  论」，固定一个字）：auto ＝ 空、
  // true / false。页函数与 #chapter() 的 two-hanzi: 就地压过它。见 src/heading/heading.typ
  two-hanzi: auto,
  // 参考文献那一层的配置，*原样透给 omni-gb7714*。
  //
  // *不在这儿列它的选项。* 那边有五十多个（style / version / cite-form /
  // note / cite-merge / 各种 punct-style……），抄一遍就是抄一份会烂的表：它加了
  // 我们不知道，它改了我们不跟。所以收一个字典整份摊过去——用户读它的文档，
  // 写什么我们传什么。
  //
  //     #show: iota-hit.with(gb7714: (style: "author-date", cite-form: "super"))
  //
  // 我们只按范例定了两条默认（文献表编号与类型标识用全角），压在 omni 的默认
  // 之上、用户这一份之下，见 src/pages/references.typ 的 gb7714-defaults。
  //
  // *omni 由我们装，用户不必再写 #show: gb7714*——装两遍是白装。
  // 条目怎么排见 src/pages/references.typ 的 bibliography。
  gb7714: (:),
  // ── 论文的元信息 ──────────────────────────────────────────────
  //
  // *与排版设定同住一个签名。* 先前它们分在 #info() 与 iota-hit()
  // 两处，而分界线不是自明的——degree-level 在那边、lang 在这边，两个都决定词条
  // 取哪一档。合成一处之后「写在哪」这个问题就不存在了，补全也一次给全。
  //
  // *一律 auto ＝ 不写 ＝ 取默认*。默认值住在 src/info.typ 的
  // info-defaults，那是唯一一份，这里不抄。写了才盖过去。
  //
  // title 就是*这篇文档*的标题，与原生的 document(title:) 同义；
  // 封面内封印的就是它。各部件的 title 是「那一块印的标题」，见 #toc(title:)。
  degree-level: auto,
  degree-type: auto,
  form: auto,
  // 哪一份材料：auto ＝ final（那份成果本身）／"proposal" 开题／"interim" 中期。
  // 与 form 正交，见 src/axes.typ
  stage: auto,
  // 校区：auto ＝ "harbin"（本部）／"shenzhen"。*眼下只有报告那两档按它分*
  // ——深圳的开题与中期是另发的一套表单（封面字段、落款、页眉、版面、题序间距
  // 逐条不同）；终稿的规范是全校一套。见 src/axes.typ 的 campus
  campus: auto,
  title: auto,
  title-en: auto,
  title-en-xiaoer: auto,
  // 副题目。「题目内容层次很多、难以简化时」才有，写了才排，见 src/info.typ
  subtitle: auto,
  subtitle-en: auto,
  author: auto,
  institution: auto,
  date: auto,
  student-id: auto,
  supervisor: auto,
  supervisor-en: auto,
  // 副导师、行业导师。*没写就没这一行*——指南那张表的括注写的就是
  // 「无副导师的研究生不列此项」，见 src/info.typ
  co-supervisor: auto,
  co-supervisor-en: auto,
  industry-supervisor: auto,
  industry-supervisor-en: auto,
  degree-applied: auto,
  degree-applied-en: auto,
  speciality: auto,
  // 实践成果类型（调研报告、产品设计报告……），只有 form: "practice" 用得上，
  // 见 src/info.typ
  practice-type: auto,
  speciality-en: auto,
  affiliation: auto,
  affiliation-en: auto,
  defense-date: auto,
  defense-date-en: auto,
  author-en: auto,
  institution-en: auto,
  keywords: auto,
  keywords-en: auto,
  secrecy: auto,
  classified-index: auto,
  udc: auto,
  school-code: auto,
  // 覆盖本地化词条，一层扁平字典：(titlepage-author-bachelor: [作者])
  // 只给要改的那几条，别的照旧。键名写错会报错，见 src/terms/lookup.typ
  overrides: (:),
  // 一级标题要不要另起一页——Word 里就是「标题 1」样式上那个「段前分页」的勾。
  // *按级不按名*：论文的一级是章，报告的一级是节（报告没有章），名字里因此写 1
  // 不写 chapter，与 toc-1～toc-4 同一套。auto ＝ 论文要（写作指南 3.2 的章是一级
  // 分界，范例里每一章都另起页）、报告不要（一节一页会把五千字排成五页）；
  // 关掉也给对拍件与短样张用
  heading-1-pagebreak: auto,
  // 右翻页的总闸，三态：false 一段都不跳 / true 三段都跳 / auto 各段用默认表。
  // 单段用 frontmatter / mainmatter / backmatter 的同名参数覆盖，单章单部件用
  // #chapter(openright:) 这些覆盖。见 src/settings/defaults.typ
  openright: auto,
  // 题注排不排双语，三态。auto 按学位：博士双语（中文在上、英文在下），
  // 本硕只中文。见 src/settings/defaults.typ
  caption-bilingual: auto,
  // 题注编号按不按章。三态：true「图1-1」并在章标题处重置 / false 全文连续
  // 「图1」不重置 / auto 查默认表（现在一律 true）。见 src/settings/defaults.typ
  //
  // *只有这条路。* 用户自己写 #set figure(numbering: "1") 盖不过我们——
  // 实测仍排「图1-1」，因为 show figure: set figure(numbering:) 里的 set 更内层。
  caption-numbering-by-chapter: auto,
  // 公式编号按不按章。三态，auto ＝ 按章（指南 2.11 明写）。*与题注那一条
  // 分开*——公式与图表是两个部件，共用一个开关就表达不了「图表按章、公式连续」。
  equation-numbering-by-chapter: auto,
  // 公式编号的括号用不用全角。三态，auto ＝ 半角（跟范例；指南的叙述写全角，
  // 两者矛盾，取印出来的那一个）。见 src/settings/defaults.typ
  equation-numbering-fullwidth: auto,
  // 缩略语要不要顺带登记进索引。默认不登记，见 src/settings/defaults.typ
  abbreviation-indexed: auto,
  // 编号列表的续行悬不悬挂。三态，auto ＝ 不悬挂（Word 范例的「（1）……」是普通
  // 段落）；单次覆盖 #enum-hanging[…]。见 src/settings/defaults.typ
  enum-hanging: auto,
  // 圆点列表的续行悬不悬挂。三态，auto ＝ 悬挂（指南没规定，照原生）；false 排成段，
  // 与编号列表同一个排法；单次覆盖 #list-hanging(false)[…]。见 src/paragraph/list.typ
  list-hanging: auto,
  // 缩略语：条目在印表的那一处声明（#list-of-abbreviations(条目) 或
  // #nomenclature(abbreviations: 条目)[…]），正文里写 @SCNA。这两条是正文里每个缩写怎么
  // 排的文档级开关：首次展开的括号逗号全角还是半角（auto 按用处语言）、缩写链不链到表
  // （auto ＝ 链）。见 src/references/abbreviations.typ
  abbreviation-fullwidth: auto,
  abbreviation-links: auto,
  // 分图号的写法与分隔，见 src/settings/defaults.typ
  subcaption-numbering: auto,
  subcaption-separator: auto,
  // *分图题*排不排双语。三态，auto ＝ 不排——规范说分图题「可以只用中文
  // 书写」，双语那句点的是图题与表题。与 caption-bilingual 分开，见
  // src/settings/defaults.typ
  subcaption-bilingual: auto,
  // 图题与连排分图题之间插什么。auto ＝ 什么都不插（范例就是紧挨着的）；收长度
  // 就空这么高，收内容就原样插进去（enter(1) ＝ 空一行）。见 src/settings/defaults.typ
  subcaption-gap: auto,
  // 题注里编号与题名之间空多少。收长度，与 Typst 的 enum(body-indent:) 同名同义。
  // auto ＝ 一个汉字宽（指南写「空 2 个半角字符」，两份范例印出来也是这个）。
  // 见 src/settings/defaults.typ
  caption-body-indent: auto,
  // 标题里题序与标题之间空多少。收长度，auto ＝ 一个汉字宽（指南 3.2「题序顶格
  // 书写，与标题间空 2 个半角字符」）。见 src/settings/defaults.typ
  heading-body-indent: auto,
  // 伪代码的样子，一个字典，键都收 auto：frame（"tabular" 默认 / "ruled" / "boxed"，
  // PlutoThesis 记的哈工大三个门派）、keyword-case（"upper" 默认 / "lower" / "title"）、
  // indent-guide（"bar" 默认 / "hook" / none）。见 src/settings/defaults.typ 与 src/figure/kinds/algorithm.typ
  algorithm-style: auto,
  // 代码清单（进了 figure 的代码块）的样子，与 algorithm-style 同型：frame（"tabular" 默认 /
  // "ruled" / "boxed" / none）、line-numbering（"1" 默认 / "1:" / "①" / 函数 / none）。
  // 见 src/settings/defaults.typ 与 src/figure/kinds/raw.typ
  raw-style: auto,
  // 破折号排中文字体（"cjk"，「——」中间断一截）还是西文字体（"latin"，连成一条）。
  // 三态，auto 按分支跟各自的原件：深圳的报告西文、其余中文。见 src/settings/defaults.typ
  em-dash: auto,
  // 附录的章号用字母还是数字。三态，auto 按学位——本科数字、硕博字母。
  // 就地压过写 #show: appendix.with(appendix-numbering: …)
  appendix-numbering: auto,
  // 目录条目正文右边留多宽——留出来是为了让长条目提前折行（指南 3.6）。
  // auto ＝ hithesis 的 4em。三份目录（目录、插图索引、表格索引）共用
  outline-entry-right-margin: auto,
  // 目录条目的编号怎么摆：auto / none 不取列、left 靠左取列、right 靠右取列。
  // 收 alignment，与 enum(number-align:) 同型。见 src/settings/defaults.typ
  outline-entry-number-align: auto,
  doc,
) = context {
  // *整个函数体包在 context 里*，为的是在自己那句 set text 之前读到
  // 外层的 text.lang——lang: auto 那一档要的正是「#show 之前设的那个值」。
  // 元信息写进 state，各页从里面取。*只把写了的传下去*——auto 那些留给
  // info-defaults，别拿一串 auto 把默认表盖掉
  // 门类。auto ＝ 不写 ＝ 理工类；别名（hss）在轴那一层折成正名，往下一律只见正名。
  // *要在写进 info 之前折*——各页从 info 取的得是正名
  // 两根轴同一个路子：auto ＝ 不写 ＝ 默认档；别名在轴那一层折成正名（hss → hass、
  // design → practice），*要在写进 info 之前折*——各页从 info 取的得是正名
  let resolve-axis(axis, value, fallback) = {
    let v = _axes.normalize(((axis): if value == auto { fallback } else { value })).at(axis)
    if v not in _axes.axes.at(axis) {
      panic(_errors.expected-one-of(_axes.axes.at(axis), v) + " (axis: " + axis + ")")
    }
    v
  }
  let category = resolve-axis("category", category, "stem")
  let form = resolve-axis("form", form, "dissertation")
  let stage = resolve-axis("stage", stage, "final")
  let campus = resolve-axis("campus", campus, "harbin")
  // 报告那两档的三样默认，全在这一处分：版面、页码、页眉页脚。*学位耦合与
  // 文种耦合都只住在默认表里*，写了就照写的
  let is-report = stage in _report-stages
  // 学位没写就按 info 的默认，与写进 info 的是同一个值
  let this-degree = if degree-level == auto { _info-defaults.degree-level } else { degree-level }
  // *正文照不照终稿排*，见 src/axes.typ 的 final-body：深圳本科那两份
  // 只有首页是表单，正文与终稿同构。首页、页眉、页脚仍走 is-report 那一支
  let report-body = is-report and not _final-body(campus, this-degree, stage)
  // 设定表按阶段分档的那几条（图表按不按章编号、题注双不双语、正文与标题的
  // 字与行距）跟着正文走
  let body-stage = if report-body { stage } else { "final" }
  // *参考文献编不编号*：本部那三份表单的「说　明」页把它列成正文内容的一条
  // （第 9／10 条），与「1．课题来源」并排——是编号的节；深圳那四份的目录里它与
  // 各章并排、不带号，正文里也是光三个字——照终稿排
  let numbered-references = report-body and campus != "shenzhen"
  // *版面按档挑，报告那一套还要再按学位与阶段挑一次*（本科那两份四边 2.3cm、
  // 无页眉页码、网格整个不启用；硕博三份上左右 2.5cm、下边距各份各写、开着行
  // 网格，见 src/layout/presets.typ）。用户的局部字典并在那一份上，整份就整份替换。
  let layout = _layout.resolve-local(
    _layout.fold(_layout.default-inputs(
      degree-level: this-degree, stage: stage, campus: campus,
    )),
    layout,
  )
  let page-numbering = if page-numbering != auto {
    page-numbering
  } else if report-body { none } else { "1" }
  _info.info(..(
    ("degree-level", degree-level),
    ("degree-type", degree-type),
    ("category", category),
    // 交上去的是哪一种东西，见 src/axes.typ 的 form
    ("form", form),
    ("stage", stage),
    ("campus", campus),
    ("title", title),
    ("title-en", title-en),
    ("title-en-xiaoer", title-en-xiaoer),
    ("subtitle", subtitle),
    ("subtitle-en", subtitle-en),
    ("author", author),
    ("institution", institution),
    ("date", date),
    ("student-id", student-id),
    ("supervisor", supervisor),
    ("supervisor-en", supervisor-en),
    ("co-supervisor", co-supervisor),
    ("co-supervisor-en", co-supervisor-en),
    ("industry-supervisor", industry-supervisor),
    ("industry-supervisor-en", industry-supervisor-en),
    ("degree-applied", degree-applied),
    ("degree-applied-en", degree-applied-en),
    ("speciality", speciality),
    ("practice-type", practice-type),
    ("speciality-en", speciality-en),
    ("affiliation", affiliation),
    ("affiliation-en", affiliation-en),
    ("defense-date", defense-date),
    ("defense-date-en", defense-date-en),
    ("author-en", author-en),
    ("institution-en", institution-en),
    ("keywords", keywords),
    ("keywords-en", keywords-en),
    ("secrecy", secrecy),
    ("classified-index", classified-index),
    ("udc", udc),
    ("school-code", school-code),
  ).filter(((k, v)) => v != auto).to-dict())
  // 破折号那一档要在字体表解出来之前定：它是字体表里的一条 covers
  let em-dash = _settings.resolve-em-dash(
    local: em-dash, campus: campus, degree-level: this-degree, stage: stage,
  )
  let f = _fonts.resolve(value: fontset, em-dash: em-dash)
  // *语言的基线先算*：文档级的词条覆盖要用它（光键名的那一档落在文档主语言上，
  // 见 src/terms/lookup.typ 抬头），报告那两档的标题段前段后也按它分。auto 读外层设的
  let doc-lang = _lang.normalize(if lang == auto { text.lang } else { lang })
  // 样式表：局部并到默认，写进 state（目录三级从那儿取）
  // 各档与论文不一样的那几个样式值：*按语言取桶、档位写在键名上*（报告也是
  // 一档——stage 那根轴的 -not-final），表在 src/styles/presets.typ 的 variant-styles，
  // 查法在 src/styles/sheet.typ 的 variant-style。写 auto 的那几格是「这一档没有
  // 自己的数」，照终稿那一套排；*所以这儿不必判是不是报告*
  let variant-style(name) = sheet.variant-style(
    name, lang: doc-lang, degree-level: this-degree, stage: stage, campus: campus,
  )
  // 正文行距。*正文照终稿排的那一档（深圳本科报告）只换行距*——它的标题走
  // 终稿那一套，可正文段写的是 1.25 倍、不贴行网格（那两份的 docGrid 一个没有
  // w:type、一个的正文段自己关了贴网格，量出来都是 19.44）
  let body-line-spacing = variant-style("body-line-spacing")
  // *英文档的报告标题，西文那一槽加粗*，加粗到第几级按学位分（中文桶与
  // 终稿都是 0，一级都不加）。*正文照终稿排的那一档（深圳本科）也吃这一条*
  // ——它的标题走终稿那一套，可英文版原件里章与节仍是 Times Bold
  let bold-upto = variant-style("heading-bold")
  let bold(level) = if level <= bold-upto { (latin-bold: true) } else { (:) }
  // *首行缩进只有一格与众不同*（深圳本科英文版三个字），auto ＝ 不覆盖
  let body-indent = {
    let v = variant-style("body-indent")
    if v == auto { (:) } else { (first-line-indent: v) }
  }
  // 行距同理：auto ＝ 这一档没有自己的数
  let body-spacing = if body-line-spacing == auto { (:) } else {
    (line-spacing: body-line-spacing)
  }
  // 章标题那一格：报告的行距与字距与终稿不同，见 variant-styles 的 chapter
  let chapter = variant-style("chapter")
  // 图表那一把伞（image / table / caption）：报告那几档与终稿不同（英文版装图段
  // 1.5 倍、四个空当各是各的数；深圳本科中文版图表与正文贴着排），见 variant-styles
  let figure-style = variant-style("figure")
  let styles = sheet.resolve-styles(styles, preset: if is-report and not report-body {
    (
      body: (snap-to-docgrid: false) + body-spacing + body-indent,
      figure: figure-style,
      chapter: bold(1) + chapter, section: bold(2),
      subsection: bold(3), subsubsection: bold(4),
    )
  } else if not report-body { (:) } else {
    // 节与条的段前段后按文档语言分两档（中文 0.5 行、英文 6 磅），出处与探针
    // 见 src/styles/presets.typ 的 variant-styles；款项两版都是 0，不分
    let gap = variant-style("heading-spacing")
    // *只加粗西文那一槽*：英文档的标题在原件里是 Times Bold，可*黑体
    // 不该被伪粗*——黑体没有粗体面，整段加粗会让夹在英文标题里的汉字走描边合成。
    // 见 src/styles/rules.typ 的 latin-bold
    (
      body: body-spacing + body-indent,
      figure: figure-style,
      chapter: bold(1) + chapter,
      section: (above: gap, below: gap) + bold(2),
      subsection: (above: gap, below: gap) + bold(3),
      subsubsection: bold(4),
    )
  })
  sheet.styles-state.update(styles)
  let body = styles.body
  let family = f.at(body.at("font-zh", default: "songti"))
  let body-metrics = linebox.metrics(body, layout: layout)
  _fonts.current.update(f)
  // 真粗体探一次，存起来。理由见 src/fonts/resolve.typ 的 probes
  _fonts.probes.update(_fonts.probe-all(f.families))
  _fonts.boundary-probe.update(_fonts.probe-boundary())
  // 把版面记进 state，好让 chars.ccwd() 这种给用户用的函数不必手动传 layout
  layout-state.update(layout)
  section-layout-state.update(layout)
  matter-layout-state.update(layout)
  // *overrides 只装词条。* 设定一律走具名参数——设定统共十来条，每条都在
  // 这个签名里列着，签名本身就是文档；再开一条字典的路，同一件事就有两种拼法，
  // 而且「两边都写了谁赢」还得再解释一遍。写错了当场报错并指路，见
  // src/settings/resolve.typ 的 not-a-term。
  if overrides != (:) { _terms.terms-overrides(overrides, lang: doc-lang) }
  // 具名参数压在 overrides 上：写了具名的以具名为准。
  //
  // *只写真的给了的那些*——具名参数一律默认 auto（＝不写＝模板决定），
  // 照单全写会把 overrides 里刚设好的值用一串 auto 盖回去（实测文档级
  // overrides: (heading-body-indent: 2em) 一点不生效）。
  _settings.settings-overrides(
    (
      openright: openright,
      fake-bold: fake-bold,
      fake-italic: fake-italic,
      caption-bilingual: caption-bilingual,
      em-dash: em-dash,
      algorithm-style: algorithm-style,
      raw-style: raw-style,
      equation-numbering-fullwidth: equation-numbering-fullwidth,
      abbreviation-indexed: abbreviation-indexed,
      enum-hanging: enum-hanging,
      list-hanging: list-hanging,
      subcaption-numbering: subcaption-numbering,
      subcaption-separator: subcaption-separator,
      subcaption-bilingual: subcaption-bilingual,
      subcaption-gap: subcaption-gap,
      caption-body-indent: caption-body-indent,
      // *深圳研究生那两份的题序与标题间空 1 个半角*（说明页的层次表写着），
      // 用户没写才用——它是这一档的默认值，不是硬规矩，见 src/settings/defaults.typ
      // 的 report-heading-body-indent
      heading-body-indent: if heading-body-indent != auto { heading-body-indent } else {
        let chars = _config-settings.report-heading-body-indent
          .at(campus, default: (:))
          .at(this-degree, default: none)
        if is-report and chars != none { (chars: chars) } else { auto }
      },
      appendix-numbering: appendix-numbering,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
    )
      .pairs()
      .filter(((k, v)) => v != auto)
      .to-dict(),
  )
  set page(numbering: page-numbering)
  // *章节的引用不带 supplement，直接显示编号。*
  //
  // Typst 的 ref 一律排「supplement + 编号」，也就是「名在前」。图、表、附录
  // 正好是这个语序（指南 [197][214]：「见图1-1」「如表1-1所示」），章却不是
  // ——「第1章」是名字*包着*号，给 supplement: [第] 只会得到「第 1」；
  // 节更是连名都不要，指南自己写的是「具体编排方法见3.2」。
  //
  // 而 hit-numbering 排出来的本来就是完整的「第 1 章」「1.1」，编号自己已经
  // 把语序解决了，supplement 只会多出一个「小节」——Typst 中文档的默认值。
  //
  // 图表那边*需要* supplement（图 / 表），等做题注时在那儿设。
  set heading(supplement: none)

  // 语言的基线在上面算过了（词条覆盖要用），这里记进 state
  _lang.doc-lang.update(doc-lang)
  _case.check-title-case(title-case)
  _case.title-case-state.update(if title-case == auto { none } else { title-case })
  _heading-mod.check-two-hanzi(two-hanzi)
  _heading-mod.two-hanzi-state.update(two-hanzi)
  // 编号按文档语言与门类挑，见 src/heading/numbering.typ。
  //
  // *不开公开参数。* 层次编号是规范定死的（两份指南各一张「表2 层次代号及
  // 说明」），四份预设把官方的四种情形全覆盖了（中文理工 / 英文 / 人文社科 /
  // 人文社科的英文目录），auto 按 lang 与 category 自己挑——再开一个口子只会让人
  // 排出不合格的东西。要换写法就换 category 或 lang。
  let numbering = _numbering.resolve-numbering(
    auto, lang: doc-lang, category: category, stage: stage,
  )
  // *region 一律 cn，不跟 doc-lang 走。* 它是给*汉字标点*用的旋钮
  // （实测 tw 会关掉相邻标点压缩那一步，见 README「按需的标点压缩」），
  // 判据是「这段字是不是中文」而不是「这篇论文是哪一版」——英文版论文里
  // 照样有中文摘要，那一页的标点压缩不能因为文档语言换了就变。
  // *断字默认关。* 原生默认是 auto——「两端对齐就断字」，而正文正是两端
  // 对齐的，不压住就成了默认断字，与范例相反（两份 .docx 的 settings.xml 里都没有
  // w:autoHyphenation，Word 默认关）。用户在 #show: iota-hit 之后写
  // #set text(hyphenate: true) 就能压回来——那一句在内层，赢。
  set text(hyphenate: false)
  // *断行按贪心，照 Word。* Word 逐行首次适配；Typst 原生的 auto 在两端对齐时走整段最优
  // （Knuth–Plass），会为了后面的行把前面的行断得早或晚。四份深圳本科报告对拍：K-P 与
  // Word 的断点分歧 32／4／3／0 处，贪心 16／3／3／0，且 K-P 的分歧全是「我们靠压空格、整段
  // 权衡多塞了字」、贪心剩下的全是 Word 压缩标点与网格增量挤进去的字——那是另一条
  // 规则，Typst 的 simple 不压缩求合，见 README「断行」。
  //
  // *开关是原生的 par.linebreaks，我们不另设一条。* 判据认 auto：用户在 #show 之前
  // 写了 #set par(linebreaks: "optimized")，这里读到的就不是 auto，照他的；写在 #show
  // 之后的那一句在内层，本来就赢
  set par(linebreaks: if par.linebreaks == auto { "simple" } else { par.linebreaks })
  set text(font: family, lang: doc-lang, region: "cn")
  // 脚注正文小五。*两份指南都没规定脚注的字号*——人文社科版只写了标记
  // （（十五）：「在正文的右上标和页下以 ①②③……来表示」），理工版通篇没有
  // 「脚注」二字，四份书写范例里也一个脚注实例都没有。
  //
  // *没出处也得给个数*：原生那一档是 0.85em，正文小四时折出 10.2pt——
  // 那不是任何一个中文字号，Word 里敲不出来。取小五跟 hithesis
  // （\renewcommand\footnotesize{…\xiaowu[1.5]}，hithesisbook.cls:596），
  // 它是这一处唯一的参照。*不给配置项*：规范没定的东西不在包里立一档，
  // 用户要改就写原生那一句——show footnote.entry: set text(size: 10pt)，
  // 在内层，赢。
  //
  // 标记不在这儿设：①②③ 由 omni-gb7714 装（它的 note-numbering-style
  // 默认就是 circled，而 omni 是我们替用户装的），我们再设一遍是两处争。
  // 钉住它的是 tests/check-footnote.py
  show footnote.entry: set text(size: zihao.xiaowu)
  // 代码里的汉字：仿宋 → 楷体 → 宋体，见 src/fonts/resolve.typ 的 mono-table。
  // *raw 没有 font 参数*，只能由 show 规则给下面的 text 设
  show raw: set text(font: f.mono)
  // *代码的字号与行盒*，见 src/fonts/resolve.typ 的 mono-text：字号照 MatchLowercase 按 x 高
  // 缩、取到半磅格（先压掉 Typst 自己那句 0.8em，让 text.size 读到的是周围的字号）；行盒是
  // 等宽字体自己的单倍行高。先前代码块吃的是正文那套行盒（中易 1.296875 × 1.25），codly /
  // zebraw 里一行 26.2pt、2.7 倍字号，Word 里没人这么排代码。行内代码同一套，不撑行
  //
  // *写成 show-set，不写成 show 规则*：codly / zebraw 这些代码包自己的 show raw 在用户文档里、
  // 更内层，raw 到不了我们的规则；show-set 的值它们的输出照样吃到。三项都按 em 写，字号
  // 是相对周围的倍数（在这儿的 context 里按正文字号算一次，让正文里的代码正好落在半磅格上；
  // 题注、标题里的行内代码跟着那里的字号缩），行盒是等宽字体自己的单倍行高
  show raw: set text(.._fonts.mono-text-em(styles.body.size, f.serif, f.mono))
  // *代码块整宽*：Word 里代码就是一个段落，占满版心；Typst 的 raw 块只有内容那么宽，装进
  // figure 就被居中了（figure 居中它的 body），代码居中怎么看都不对。
  //
  // *裹一层整宽的块，不 set block(width:)*：set 会在渲染这段 raw 的整个过程里生效，codly /
  // zebraw 内部那些块（clip 的、place 填色的）也一并被撑成整宽，它们的定位就散了（实测
  // 代码正文整个不见、只剩行号）。裹一层只作用在它们*排完的成品*上，不碰内部；它们本来
  // 就 100%，裹不裹一个样
  show raw.where(block: true): it => block(width: 100%, it)
  // 楷体是繁体档时才发转字规则，别的档一条都不发
  show: _hant.hant-rules.with(f)
  show: _quotes.quote-rules.with(latin-font: f.serif)
  show: _quotes.unit-rules
  show: _math.math-rules.with(font: f.math, cjk: f.families.songti)
  // 引擎自己画字符网格时补偿那几条不装：没有模拟出来的字距就没有可丢的，装上只多几处
  // run 边界（见 src/layout/resolve.typ 的「断行引擎」）。按文档级的输入定：页级退回原版
  // 的封面内封上强调、链接那几处就不补了——那两页本来也没有
  show: if _layout.engine-linebreaks == none { _tracking.tracking-rules } else { it => it }
  // *上下标钉到 Word 的数*：西文 0.65 × 字号取到半磅、抬升＝字号差，汉字 0.5 / 0.5——
  // 量法、数与为什么不重造元素都在 src/fonts/super-sub.typ。下划线拆段时要知道
  // 上标抬了多少，也从那里取
  show: _super-sub.super-sub-rules
  // 下划线按 Word 画：一个 run 一条通线、上标的线留在正文线上、下标的线跟下标走，
  // 线心 0.135em、粗 0.05em——量法与数见 src/fonts/underline.typ
  show: _underline.underline-rules
  // 伪粗：中易宋体没有粗体面，不合成的话 #strong 完全哑掉。见 src/fonts/fake.typ
  show: _synth.rules
  show: _heading.heading-rules.with(
    styles,
    font-table: f,
    body-font: family,
    numbering: numbering,
    // *报告的节不另起页*：它没有「章」这一级——第一级是节，节前跳页会把
    // 一份五千字的报告排成一节一页。写 true 仍能强制跳（openright 那几层随之生效）
    heading-1-pagebreak: if heading-1-pagebreak != auto { heading-1-pagebreak } else {
      not report-body
    },
    // 报告的四级整体上移一格，见 src/heading/rules.typ 的 report-levels
    levels: if report-body { _heading.report-levels } else { _heading.levels },
  )
  // 顺序要紧：一节的 set（_section.section-sets，里面是 set page 与正文的 set text /
  // set par）摆在最内层，好让它发的规则最后定义。Typst 里同一选择器上后定义的
  // show 规则压过先定义的，而 set page 的页眉页脚是在正文的样式里排的——正文那条
  // 给西文 run 换行盒的规则会漏进页眉，用正文的行距倍数给「第 1 章」里的 1 发
  // 行深，页眉行被撑高 1.27。page-rules 在 styled 里按页眉自己的取值重发一份，
  // 摆在内层才压得住。
  // 题注与三线表。摆在正文规则之前——它自己会用正文的行高定图表的上下间距
  // 解好的那个值*也写进 state*：插图与表格索引在文档中途读它，编号才与题注
  // 一致。见 src/settings/resolve.typ 的 caption-by-chapter
  _settings.caption-by-chapter.update(
    _settings.resolve-caption-numbering-by-chapter(
      local: caption-numbering-by-chapter, stage: body-stage,
      campus: campus, degree-level: this-degree,
    ),
  )
  _settings.equation-by-chapter.update(
    _settings.resolve-equation-numbering-by-chapter(
      local: equation-numbering-by-chapter, stage: body-stage,
    ),
  )
  // 代码清单的框与行号（进了 figure 的代码块），见 src/figure/kinds/raw.typ；要挂在 caption-rules
  // 之外这一层：figure 那条规则在里面记 state，这条 show raw 读它
  let figure-spacing = {
      let cap = linebox.metrics(styles.figure.caption, layout: layout)
      let sides = ("above", "gap", "below")
      // 装图段自己的行盒：把三段空当那三个键剥掉再 resolve（它们不是段属性）
      let m = linebox.metrics(
        styles.figure.image.pairs().filter(((k, v)) => k not in sides).to-dict(),
        layout: layout,
      )
      // auto 就是样式表里写的那一档（(lines: 1)，见 src/styles/presets.typ）；上面那三段
      // 空当与标题的 heading-spacing 走同一个解 linebox.amount——「几行」乘 line-unit，别处
      // 另算一遍就是两套数
      let amount(v) = linebox.amount(
        if v == auto { _config-styles.default-styles.figure.image.above } else { v },
        layout.docgrid,
      )
      let of(which, gap-auto) = {
        let st = styles.figure.at(which)
        (
          above: amount(st.at("above", default: auto)),
          gap: if st.at("gap", default: auto) == auto { gap-auto } else { linebox.amount(st.gap, layout.docgrid) },
          below: amount(st.at("below", default: auto)),
        )
      }
      // 网格开着时装图那一行占整数个网格行、图在里面居中，多倍行距多出来的那一截
      // 已经在余量里，gap 就是 0；关着才是 (倍数 − 1) × 自然行高，见 src/figure/caption.typ
      let snapped = layout.docgrid.grid and layout.docgrid.line-pitch != 0pt
      (
        image: of("image", (if snapped { 0pt } else { m.box - m.natural }) + cap.above),
        table: of("table", cap.below),
      )
    }
  show: _listing.listing-rules
  show: _captions.caption-rules.with(
    style: styles.figure.caption,
    // 只给图表上下空一行那条 show-set 用：show-set 的值给不了 context，按文档级算，
    // 见 src/figure/caption.typ 抬头
    body-metrics: body-metrics,
    by-chapter: _settings.resolve-caption-numbering-by-chapter(
      local: caption-numbering-by-chapter, stage: body-stage,
      campus: campus, degree-level: this-degree,
    ),
    // 公式的引用也由 caption-rules 里那条 show ref 排，理由见那里
    equation-by-chapter: _settings.resolve-equation-numbering-by-chapter(
      local: equation-numbering-by-chapter, stage: body-stage,
    ),
    // 图块表块的三段空当，解成数：(image: (above:, gap:, below:), table: (…))。
    // 写了数的照数（长度或 (lines: n)）；auto 各有各的解法，见 src/styles/presets.typ
    // 的 _figure：
    //
    //   above / below   *空一行*——一个真空段的高：¶ 走 ascii 槽的字体（Times），
    //                   行距跟正文，网格开着就贴成整行。与模板里 #enter() 发的那一行
    //                   同一个算法（src/paragraph/enter.typ 的 enter-height）
    //   gap（image）    *Word 自己加的那一截*：图坐在一条文字基线上，图底下带着
    //                   装图段多倍行距比自然行高多出来的那一份（box − natural），再加
    //                   图题那一段的段前（四份原件都是 0，式子写全）
    //   gap（table）    题注那一段的段后（表题在表上，四份原件都是 0）——表不是段落，
    //                   表那一头没有「下一段的段前」
    spacing: figure-spacing,
  )
  // 打上 <-> 就不编号，见 src/heading/numbering.typ 的 nonumber-rules。*摆在题注规则之后*——同一属性上
  // 后定义的 show 规则压过先定义的，摆在前面会被题注那条 set figure(numbering:)
  // 盖掉（实测打了 <-> 的图照样排出「图1-2」）
  // 公式自动编号，按章排「(1-1)」、序号右端对齐（指南 2.11）。不想编号的打 <->
  //
  // *必须排在 heading-rules 之后*：那一条把标题换成了 block，先定义的规则
  // 就再也看不到 heading 元素——实测这条里的计数器重置一次没发，第二章的公式接着
  // 第一章数成了「(2-3)」。caption-rules 的图表重置能发，正是因为它也在后面。
  //
  // 而它又必须排在 nonumber-rules 之前：那一条要用 numbering: none 盖掉这里设的。
  // *三线表格里的字号*：表格那一档样式的（五号），写成 show-set——用户就地 #[ #show table: set
  // text(size: zihao.xiaowu) … ] 在内层、压得过，重建格子时读的是样式链上的值（src/figure/
  // caption.typ 的 show table）。字体不 set，跟正文（范例格里就是宋体）
  show table: set text(size: styles.figure.table.size)
  // 伪代码与代码清单的题注与本体之间：表格型、线条型紧贴（线条型题注在两条线之间，中间那条
  // 细线是本体的上边，隔开就断了；表格型题注与顶线之间的空当由题注自己的行盒出，与三线表
  // 同）；框图型题注在框外下方、与图一样，走图那一份 gap；清单不画框的也走图那一份。
  // *写成 show-set*：gap 是 figure 造好时填进字段的，show 规则里的 set 到不了（实测），而
  // show-set 给不了 context，框哪一档按参数在这儿解（resolve-*-style 的 from）
  show figure.where(kind: _algorithm-kind): set figure(gap: if (
    _settings.resolve-algorithm-style(from: algorithm-style).frame == "boxed"
  ) { figure-spacing.image.gap } else { 0pt })
  show figure.where(kind: raw): set figure(gap: if (
    _settings.resolve-raw-style(from: raw-style).frame in ("boxed", none)
  ) { figure-spacing.image.gap } else { 0pt })
  show: _math.equation-rules.with(
    // 公式的行盒按 Word 算：倍数 × 这一行的自然行高，多出来的落在基线下方。
    // 倍数与网格都从正文那一份行盒里取——按当前这一节的版面现算，见
    // src/math/rules.typ 的 _linebox-rules
    body-style: body,
    by-chapter: _settings.resolve-equation-numbering-by-chapter(
      local: equation-numbering-by-chapter, stage: body-stage,
    ),
    supplement: _terms.term-of(doc-lang, "caption", "equation"),
  )

  // 参考文献。*摆在这儿*——先前要用户自己在 #show: iota-hit 之后写
  // #show: gb7714，那个位置就是这里：比我们的规则更内层，引用先过它的手，
  // 不是文献键的它原样交回（实测两条 show ref 嵌套时内层 return it 外层照样
  // 接手），再落到我们那条上。
  // *我们的默认压在它的默认之下，用户的又压在我们之上*——范例量出来的那
  // 几条当默认，别的一概听 omni 的，见 references.typ。方括号半角还是全角*按
  // 学科门类*：理工全角、人文半角，两份范例整篇数出来的
  // 章标题按文档语言生成，塞在两层之间：见 references.typ 的 references-title
  show: _omni.gb7714.with(
    .._gb7714-for(category)
      + (title: if numbered-references { none } else { _references-title(doc-lang) })
      + gb7714,
  )
  // *本部报告的参考文献是一个编号的节*，不是不编号的章：三份表单「说　明」
  // 页把它列成正文内容的第 9 条（博士开题第 10 条），与「1．课题来源」「2．国内外
  // 研究现状」并排。*深圳那几份不是*——它们的目录里「参考文献」与各章并排、
  // 不带号，正文里也是光三个字，所以那一档照终稿排（见上面 numbered-references）。omni 把 title 塞进自己那个 heading(numbering: none) 里，那是章的
  // 形状——所以报告这一档不把标题交给它，改成我们自己发一条一级标题，编号、进目录、
  // 接着数都照常。
  //
  // *要摆在 omni 那条之后*——后写的更内层、先跑：我们先给原件添上一条标题，
  // 再交给 omni 把条目表排出来。摆在前面的话 omni 那条先把 bibliography 元素换成了
  // 它自己的一块内容，我们这条就再也匹配不到（实测标题一个字都不出）。
  let report-bibliography(doc) = {
    // *要写 std.bibliography*：这个文件里的 bibliography 是 omni 那个壳
    // （上面 import 进来的），壳不是元素函数，当不了选择器
    show std.bibliography: it => {
      // *编号串要显式写在元素上*：show 规则里现造的标题拿不到外面那句
      // set heading(numbering:)（实测排出来光「参考文献」三个字，没有号）。
      // 传的就是本档那一份闭包，与哨兵比的也是它，不会撞上「用户改了编号」那条
      heading(level: 1, numbering: numbering, _references-title(doc-lang))
      it
    }
    doc
  }
  show: if numbered-references { report-bibliography } else { doc => doc }
  show: _nonumber-rules
  // 正文那一档的 show 规则（西文 run 的字距、纯西文行的行盒），只装这一次；
  // 它的 set text / set par 在下面那节的 set 里
  show: _body.body-rules.with(layout, body)
  // 编号列表排成段、不悬挂（Word 范例那样），见 src/paragraph/enum.typ
  show: _enum.enum-rules.with(doc-lang)
  // 圆点列表默认照原生悬挂，list-hanging: false 也排成段，见 src/paragraph/list.typ
  show: _list.list-rules
  // 一节的 set：版心、页眉页脚、正文的字与段。这是文档级那一次；三个 matter 用
  // 段级并好的版面再发一次，见 src/layout/section.typ
  _section.section-sets(
    layout,
    styles: styles,
    font-table: f,
    stage: stage,
    // 缩略语那条 show ref 罩在最内层：它认不得的键原样交回，再落到上面 omni 与
    // 题注那两条上。没有条目它什么都不装，见 src/references/abbreviations.typ 的 rules
    // 视觉矫正：换中文字体，汉字仍落在中易那一档的高度。*全篇只这一条*，只发给
    // 汉字 run，按实际字体查量——见 src/fonts/resolve.typ 的 baseline-rules。
    // *罩在最内层*：它按正则切汉字段，得在引用、缩略语那些「记号 → 字面」的
    // 改写都做完之后再切，否则记号旁边的空白被它先切走，「@a 与 @b」排出来
    // 「与」后面多一个空格（实测「式 (1-1)与 式 (1-2)」）。
    _abbreviations.rules(_fonts.baseline-rules({
      // 缩略语的两个文档级开关，发在正文之前；条目由印表的页声明
      _abbreviations.configure(fullwidth: abbreviation-fullwidth, links: abbreviation-links)
      doc
    })),
  )
}
