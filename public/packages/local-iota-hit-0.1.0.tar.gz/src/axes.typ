// 版式的*轴*。
//
// 同一份规范里，一个东西的说法常常按*某一档*换：内封那一格本科印
// 「指导教师」、研究生印「导师」；封面那行字硕士印「硕士学位论文」、博士印
// 「博士学位论文」。这些「按什么分档」就是轴，档就是轴上的取值。
//
// *一个词条名 + 零到多个档位后缀。* 键名说的是*字段身份*
// （supervisor），后缀说的是*这一档怎么印*（-bachelor）。查表由
// src/terms/lookup.typ 的 term-for 做。
//
// *光键名是默认档。* 内封上「导师」「学科」「所在单位」这几格硕博同字，
// 写成光键名，本科那一档另写 -bachelor 压在上面。先前这里还有个 graduate
// 「上位档」，让 -master 找不到时退到 -graduate 再退到光键名——那是给一个只有
// 自己用的概念留了一层机制。硕博共用的写法本来就是「不写后缀」。
//
// 代价是光键名在同一张表里有两种意思：defense-date 是所有档共用，institution
// 是研究生这一档、本科另有一条。所以*成对相邻写、光键名在前*，扫一眼就
// 知道下面有没有跟一条 -bachelor；写歪了还有 tests/check-terms.py 逐档对字。
//
// *只放眼下真有词条按它分档的轴。* 校区那一根*现在真有词条了*（深圳的
// 开题与中期表单：封面字段叫「院（系）」「学 科 /专 业」、落款是「深圳校区教务部 制」、
// 页眉印「哈尔滨工业大学（深圳）中期报告」），所以进来了；威海手上没有文件，
// 不填空档。博士后同理：按 hithesis 那边看，
// 博士后内封几乎不与研究生共用字段（「流动站名称」「合作导师」「专业名称」
// 「分类号」），是另写一份行表加一套自己的词条，不是在这根轴上多一档就能了事的。
//
// *这张表也是各处校参数的唯一出处。* 先前 src/axes.typ 另存了一份
// 一模一样的 degrees，封面与内封拿它校 degree-level 参数，而 term-for 拿这里挑后缀——
// 同一份档表两处各读各的，哪天加一档只改一处，就会出现「词条挑得出来、参数校验
// 却把它拦下」这种静默不一致。收成一处之后，调用处写 axes.degree-level：容器复数，
// 取出来的那一档单数。
#import "@local/banshi:0.1.0" as banshi
#import banshi.errors as _errors

#let axes = (
  degree-level: ("bachelor", "master", "doctor"),
  // 学位类别。照 hithesis 的 student-type（hit-thesis.cls:403），但名字改了
  // ——学术／专业是*学位*的属性，不是学生的。封面那行「（学术学位论文）」
  // 就是按它分的档，词条见 src/terms/built-in.typ 的 cover 桶
  degree-type: ("academic", "professional"),
  // *学科门类*，不是学位类别（那个是上面的 degree-type）。学校把《学位论文
  // 写作指南》出成两份：（理工类）适用于理工、经济学、管理学门类，（人文社科类）
  // 适用于哲学、法学、文学门类——两份逐条对过，*版面那一层一字不差*（字号、
  // 行距、段前段后、页眉、图表、公式、参考文献、成果、简历），落到版式上的差别只有
  // *正文层次的编号*（见 src/heading/numbering.typ）。
  //
  // *但不止编号不同。* 人文社科那份还多一节「（十五）正文页下脚注」（①②③），
  // 理工那份一个「脚注」都没有；目录清单的措辞也不同，「索引」那份没有这一条。
  // 先前这里写成「其余一字不差」，是错的。脚注那一条两档共用（标记由 omni 装、
  // 正文小五），见 README「脚注」——所以它没在这根轴上分档。
  //
  // *档名照学校自己的文件名*：那两份的文件名就是 g-stem.docx / g-hss.docx。
  // 正名取 hass（Humanities, *Arts*, and Social Sciences，MIT 的 SHASS 与
  // HASS Requirement 用的就是这个缩写）——学校那句适用范围只点了哲学、法学、文学
  // 三个门类，艺术学两边都没提，而哈工大有艺术类专业，用含艺术的那个缩写才兜得住。
  // hss 收作别名，见下面的 normalize。
  category: ("stem", "hass"),
  // *交上去的是哪一种东西*：写出来的论文，还是做出来的成果。学校把它出成
  // *两份指南*——《研究生学位论文写作指南》与《研究生实践成果写作指南》
  // （理工／人文社科各一本）。两份逐行对过，*版面那一层一字不差*，差的
  // 全是措辞与三处字段：通篇「学位论文」→「实践成果」；封面那行（学术学位论文／
  // 专业学位论文）→（专业学位□□……□）；内封「学科或类别」→「类别」；原创性
  // 声明多一行「行业导师签名：」；多一个「成果类型」字段。
  //
  // *本科的「毕业设计」是同一根轴上的同一档。* 本科内封第一行那两个框
  // 「☐毕业论文 ☐毕业设计」问的就是这个问题；它不改任何字（指南通篇写「本科
  // 毕业论文（设计）」，括号把两者一并覆盖了），只改勾哪个框。*正名取
  // practice 不取 design*：在实践成果那份的成果类型表里，「产品设计报告」
  // 「方案设计报告」本来就是实践成果的*子类*——设计 ⊂ 实践成果，拿子类
  // 当正名会别扭。design 收作别名，见下面的 aliases：本科写 practice、研究生
  // 写 design 都认，往下一律只见 practice。
  //
  // *词名取 form*：交上去的东西的*形态*——一篇论文，还是一件成果。
  // 先前叫 kind，与 Typst 自己的 figure(kind:) 撞名：图表那一头的 kind（image／
  // table）在题注、样式表里到处都是，同一个词两处意思，读的人分不清。英文版指南
  // 里没有一个统摄「论文／实践成果」两者的词（只有 Thesis (Design)、「学位论文或者
  // 规定的实践成果」），所以 form 是我们自己的词。
  //
  form: ("dissertation", "practice"),
  // *哪一份材料*：final 是那份成果本身，proposal 与 interim 是开题与中期
  // 两份表单。
  //
  // *它与 form 正交，这一点是官方表单自己写明的*——硕博开题与中期的封面上
  // 印着「（学位论文/实践成果）选择其一，另一项删除」，也就是说「实践成果的开题
  // 报告」是个成立的组合。先前把这两件事塞在一根轴上，正是被这一行推翻的。
  //
  // *两根轴上的组合全都成立，不必校验。* 五份官方表单（本科开题·中期、硕士
  // 开题·中期、博士开题）逐行对过，*措辞上*是同一张模板加两个词槽——标题是
  // ｛文种｝＋｛阶段｝＋报告，日期那一格是｛阶段｝＋报告日期。手上没有的
  // 「博士中期」不是缺一档，是由这三份定死的那一格。
  //
  // *版面上原件不是。* 硕博三份的字段格缩进与行距、前后空段的个数没有一处
  // 三份全同——那是同一次改版（实践成果进来）三份三种改法，已经统一，见
  // src/pages/report/cover.typ。*只有标题字号照各份的设计留着*
  // （_graduate-title-size）。词条这一层照旧只有两个词槽——变的是排版，不是字。
  stage: ("final", "proposal", "interim"),
  // *校区*。深圳的开题与中期是另发的一套表单，不是本部那套的参数化变体：
  // 封面字段（院（系）／学 科 /专 业）、落款（深圳校区教务部 制／无）、页眉
  // （本部明写「报告不要设置页眉」，深圳两份都有页眉且带边框线）、版面（开题
  // 上 1.92 左右 1.8 下 2cm）、题序与标题间距（空 1 个半角字符，本部是 2 个）
  // 逐条都不同。hithesis 也是按这根轴分的（\g__hit_shenzhen_bool）。
  //
  // *威海不填*：手上没有那边的文件，填进来就是一张对不上任何词条的空档。
  // 眼下只有报告那两档按它分——终稿的规范是全校一套。
  campus: ("harbin", "shenzhen"),
)

// *深圳三档都有自己的表单*：研究生那一套（开题与中期，硕士与博士同一份，
// 查实过）与本科那两份（本科毕业设计开题报告_模板.docx、本科毕业论文（设计）
// 中期报告-模板.dotx）。本科那两份*正文照终稿排*，只有首页是表单，
// 见 src/layout/presets.typ 的 _shenzhen-bachelor-proposal。
//
// 一处说清，三处照它走：版面（banshi/src/layout/resolve.typ 的 default-inputs）、
// 首页的段落序列（src/pages/report/cover.typ 的 _graduate-form）、词条（那一页
// 递进查表的 variant）。*info.campus 本身不改*——用户填的是他在哪个校区，
// 不是「按谁的格式排」。
#let _campus-forms = (shenzhen: ("bachelor", "master", "doctor"))

#let campus-for(campus, degree-level) = if degree-level in _campus-forms.at(
  campus, default: (),
) { campus } else { "harbin" }

// 档名的别名。写 hss 与写 hass 是同一档——学校的文件名是 g-hss.docx，
// 用户照文件名写也该认；归一化只在这一处做，往下一律只见正名
#let aliases = (
  category: (hss: "hass"),
  // 本科那一档学校叫「毕业设计」，硕博叫「实践成果」——同一根轴上的同一个档，
  // 两个说法都认。字面差异不住这儿，住词条表（form-bachelor-practice）。
  //
  // *正名取 dissertation，thesis 是它的别名*：thesis 在这个包里指*整个项目*
  // ——开题、中期、终稿这一整套东西（阶段只分 report 与 final，见 src/axes.typ
  // 的 final-body），拿它再指「学位论文（对着实践成果）」，同一个词两个意思，
  // 读的人分不清。
  // Dissertation 也正是官方英文表单印的那个词（内封的 form-dissertation）。
  // *practical-results 也认*：《学位法》英译（chinalawtranslate）把实践成果译作
  // practical results，照它写也该认；正名仍取 practice——值同时是词条键的后缀，
  // 带连字符的值会让 not-bachelor-practical-results 这种键分不出段
  form: (design: "practice", practical-results: "practice", thesis: "dissertation"),
  // 报告那两档口语里就叫「开题」「中期」，学校的文件名也是《…开题报告》
  // 《…中期报告》——照着写都认。正名取 proposal / interim：与 final 一样是那份
  // *材料*的名（thesis proposal / interim report），opening 说的是「开题」
  // 这个动作，mid-term 说的是「学期中间」这个时点。
  //
  // *连字符那两种写法都收*：mid-term 与 midterm 是同一个词，用户记不得
  // 我们挑了哪一种，而这一条不值得让人去翻源码
  stage: (opening: "proposal", mid-term: "interim", midterm: "interim"),
  // *威海眼下当本部*。那边的表单手上一份都没有，而它确实是一个校区——
  // 写 campus: "weihai" 不该报错，也不该排出一份没人验过的版式，所以*暂且
  // 归到本部*：本部那五份是学校发的、全校通行的一套。
  //
  // *这一条与上面几条不是一回事*：hss 与 hass 说的是同一档，weihai 与
  // harbin 不是——它是「还没有自己的一档」。威海的文件到手那天，把这一行删掉、
  // 往 campus 那根轴加一档、再往 report-layouts 与 _graduate-form 里加表即可。
  campus: (weihai: "harbin"),
)

// 把一份组合里的别名折成正名。*进 variant-candidates 之前调*
#let normalize(variant) = {
  let out = (:)
  for (axis, value) in variant {
    let by-axis = aliases.at(axis, default: (:))
    out.insert(axis, by-axis.at(value, default: value))
  }
  out
}

// 一份*组合*（轴 → 档）能拼出哪些后缀串，以及每一串有多专。
//
// *段的顺序照 axes 的顺序，不照调用方写参数的顺序。* 不然
// (degree-level: …, campus: …) 与 (campus: …, degree-level: …) 会去找两个不同的键。
//
// 一根轴在键名里有三种写法：正档 -doctor（就是这一档）、反档 -not-bachelor（这根轴上
// *除这一档之外的任何档*）、不出现。多轴时候选是一张网而不是一条链
// （-doctor-shenzhen / -doctor / -shenzhen / 光键名），谁压过谁排不成一列，所以全列
// 出来交给 term-for 挑。
//
// *反档是给「硕博共用、本科另写」这种形状的。* 内封那一格「类别」只限硕博的
// 实践成果，先前写成光 -practice，与本科毕业设计（form 同样是 practice，design 是它的
// 别名）撞上：-practice 与 -bachelor 一样专，term-for 判歧义。写成 -not-bachelor-practice
// 就说清了：本科不取这条。每根轴都可以写 not-，一根轴一段（not-bachelor-not-master
// 就是 doctor，不收）。
//
// *专度：正档记 2、反档记 1、不出现记 0，按轴累加。* 反档比正档松（说的是一个
// 范围），所以 -master 压过 -not-bachelor；两根轴的反档加正档（3）压过一根轴的正档
// （2）——写了两根轴总比只写一根说得细。
//
// *反档在键名里叫 not-，在代码与注释里叫它自己的名。* 键名是机器挑的，反档得写成
// 「除这一档之外」才算得出专度；代码里说的是那一档本身，有现成的词就用现成的词：
// -not-bachelor 那一档是*研究生*（graduate——学校自己的叫法，「研究生学位论文书写
// 范例」），-not-final 那一档是*报告*（report，report-stages / is-report / report-body）。
// 两处是同一档的两个写法，不是两个概念，见 src/axes.typ 的 final-body 与
// src/pages/report/cover.typ 的 _graduate-sheet。
#let variant-candidates(variant) = {
  let variant = normalize(variant)
  for axis in variant.keys() {
    if axis not in axes {
      panic("unknown axis: " + axis)
    }
  }
  let out = ((segments: (), specificity: 0),)
  for (axis, values) in axes {
    if axis not in variant { continue }
    let value = variant.at(axis)
    if value not in values {
      panic(_errors.expected-one-of(values, value) + " (axis: " + axis + ")")
    }
    let next = ()
    for base in out {
      next.push((segments: base.segments + (value,), specificity: base.specificity + 2))
      for other in values.filter(v => v != value) {
        next.push((segments: base.segments + ("not-" + other,), specificity: base.specificity + 1))
      }
      next.push(base)
    }
    out = next
  }
  out
}

// 学位类别的*默认档*：不写（auto）时按 form 定，本科根本没有这一档。
//
// *学位耦合只住在这一处。* 实践成果只有专业学位才交——《实践成果写作指南》
// 1.1 的适用范围写着「适用于工学、理学、经济学和管理学门类中的*各专业学位
// 类别*」，封面那一行印的也是「（专业学位□□……□）」，没有学术学位那一档的字样。
//
// 显式写 academic 又写 practice 是自相矛盾的一对，*当场报错不静默改*
// ——静默改成专业学位是替用户改了他论文的属性，静默照排「（学术学位论文）」
// 则印出一份规范里不存在的封面。
//
// *住在轴这一层，不住某一页。* 论文封面与报告首页都要问同一个问题
// （前者印「（学术学位论文）」，后者那一格印「学科」还是「专业学位类别」），
// 一处写一遍就会有两处默认表。
#let degree-type-for(degree-level, degree-type, form) = {
  if degree-level == "bachelor" { return none }
  if degree-type == auto {
    return if form == "practice" { "professional" } else { "academic" }
  }
  if form == "practice" and degree-type == "academic" {
    panic(
      "degree-type: \"academic\" has no meaning with form: \"practice\" "
        + "(a practice outcome is submitted for a professional degree only; "
        + "write degree-type: \"professional\", or drop it and let auto pick)",
    )
  }
  degree-type
}

// ── stage 那根轴 ────────────────────────────────────────────────
// final 是终稿本身，proposal 与 interim 是开题与中期那两份表单。
#let report-stages = ("proposal", "interim")

// *正文照终稿排的那几档。*
//
// 深圳校区本科那两份报告（本科毕业设计开题报告_模板.docx、本科毕业论文（设计）
// 中期报告-模板.dotx）*只有首页是表单，正文与终稿同构*——判据在文件里：
//
//   版面    开题那份正文节的 w:pgMar 2154/1701/1701/1701 与 docGrid 391/1861
//           与终稿逐个数相同（版面那一层已经照它排，见 src/layout/presets.typ 的
//           _shenzhen-bachelor-proposal）
//   样式    章 小二黑体居中、节 小三、条 四号，与终稿同；中期那份连样式名都还是
//           本科毕业论文模板的（「一级节标题2.3」「非章节标题-摘要结论参考文献」）
//   跳页    两份的章都另起一页（中期在 heading 1 的样式里写着 pageBreakBefore，
//           开题写在各章那一段上——导出来的 PDF 第 5–9 页各自起一章）
//   页码    目录罗马、正文阿拉伯重新起（导出来的 PDF 上是 I 与「- 1 -」）
//   图表    按章编号（中期范例里印的是「图2-4 涡室的截面形状」）
//
// *只有编号那一条仍照报告*：这两份的章印的是「1」不是「第1章」，与本部
// 三份报告一致（见 src/heading/numbering.typ 的 hit-numbering-report）。
//
// 首页、页眉、页脚仍按报告那一档走（那三样是表单自己的），所以这一支只管正文。
#let final-body(campus, degree-level, stage) = (
  stage in report-stages and campus == "shenzhen" and degree-level == "bachelor"
)
