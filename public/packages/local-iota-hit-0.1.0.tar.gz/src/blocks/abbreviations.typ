// 缩略语：首次出现展开、之后只出缩写。
//
// 研究生规范 2.8（名词术语）：「文中第一次出现的缩写词应该用括号注明英文原词」。hithesis 手册
// 3.14.14 把它排成三种（中文版首次）：
//
//   long + long-en   体细胞拷贝数变异（Somatic copy number alteration，SCNA）
//   只有 long        树结构折筷过程（TSSBP）
//   只有 long-en     SVM（Support Vector Machine）   ← 缩写在前，正是规范那句的字面
//
// 英文版首次是「Somatic copy number alteration (SCNA)」，括号逗号半角带空格
// （hit-thesis.cls 的 \__hit_abbr_punct_pick:）；只有中文全称的条目在英文版里排
// 「树结构折筷过程 (TSSBP)」。复数只给缩写加 s，全称只在它是西文时才加（hithesis
// 手册 15.1 的注：「树结构折筷过程s 显然不对」）；中文版的复数首次是「体细胞拷贝数
// 变异（Somatic copy number alteration，SCNAs）」，英文全称不变——它的
// examples/demo/thesis.pdf 印的就是这样。
//
// *机制不是我们写的。* 「首次」要靠计数器与 show ref 拦 @键，复数、强制全称、
// 显示覆盖、重置各是一条路——Universe 上做这件事的包七个，只有 glossy 留了首次样式
// 的钩子（其余全把半角「long (short)」写死在源码里，i-am-acro 连括号里的语言标签都
// 写死），所以接它：@preview/glossy:0.9.2 钉版本，一行不改。这一层只做四件事——
// 条目翻译、组字、装规则、重置——每一件都走它的公开 API。
//
// *组字收回到我们这边*，理由是语言：glossy 的 format-term 只能返回字符串、读
// 不了 context；而首次展开要按*用的那一处*的语言组字（中文论文的英文摘要里得
// 出英文那一套，见 src/engine/lang.typ 的 part-lang）。所以 format-term 只交出「模式、键、
// 当前短形」三样拼成一个带分隔符的串，真正的组字在它后面那个能读 context 的
// show-term 钩子里做——glossy 只判「这次全称还是缩写、单数还是复数」。
//
// *条目从页面函数进来，规则却罩全文。* @SCNA 是个 ref 元素，要把它变成字，
// 那条 show ref 必须罩住每一处能写 @ 的地方——由 iota-hit 的主 show 无条件装
// （rules），用户一个 show 都不写；条目由 #abbreviations(…) 写进 state，规则在
// context 里读 final()。摘要写在声明*之前*也照样展开：final() 是整篇最终的
// 表，Typst 多排几轮直到稳定；glossy 自己查条目也是 __gloss_entries.final()
// （gloss.typ:103），本来就是晚绑定的。
//
// 用户面上只有 @：@SCNA / @SCNA:pl / @SCNA:long / @SCNA:short（不消耗首次）/
// @SCNA:both / @SCNA:cap / @SCNA[覆盖文字]，与引文 @key、图表 @fig 同一个动作。
// 标题、图题、页眉里写 @SCNA:short 或直接写字——目录与页眉会把标题体再排一遍。
#import "@preview/glossy:0.9.2" as _glossy
#import "../engine/lang.typ": effective-lang
#import "../engine/errors.typ" as _errors
#import "../engine/constants.typ": has-han
#import "../engine/settings.typ" as _settings
#import "./index.typ" as _index

// 条目表：由印表的页（#list-of-abbreviations(条目)、#nomenclature(abbreviations:)）写进来，
// 见 declare；两个开关由 iota-hit 写进来，见 configure
#let entries = state("iota-hit-abbreviations", (:))
// 两个开关加一条「表排过没有」。
//
// *「表排过没有」住在这儿，不另立状态、更不在正文里 query。* 正文里的缩写要
// 链到表，而表可能根本没排（form: none 那一档），链到不存在的标签是导出期
// 的硬错，所以得判一下。先前判法是每一处用法 query(标签) 一次，后来换成
// 一面在排表时立起的状态旗——两种都是*排版期*的 introspection，与索引标记
// （in-dexter 每个标记都记自己的页与坐标）绕成一个圈：两个以上缩写用法再加任意一个
// 索引标记就超过 Typst 的五轮上限，实测 warning: document did not converge，
// 索引条目印重。而「这一次调用排不排表」在*调用那一刻*就知道（form 参数），
// 所以由页函数在 declare 时写进来，render 读的还是它本来就要读的这一份 config，
// 一次 introspection 都不多。
#let config = state(
  "iota-hit-abbreviations-config",
  (fullwidth: auto, links: auto, indexed: auto, printed: false),
)

// 条目认的字段。键就是缩写；不带后缀的是中文，与 title / title-en 一个规矩
#let _fields = ("long", "long-en", "short", "plural", "long-plural", "indexed")

#let _bad(key, what) = panic("abbreviations: entry " + repr(key) + ": " + what)

// 把用户写的条目归一：裸字符串归边；字典验字段；short 默认就是键，plural 默认加 s；
// long-plural 留 auto，到组字时按语言与是否西文再定
#let normalize(value) = {
  if type(value) != dictionary {
    panic("abbreviations: expected dictionary, found " + str(type(value)))
  }
  let out = (:)
  for (key, given) in value {
    if key.contains(":") {
      _bad(key, "key must not contain \":\" (that is the modifier separator, as in @SCNA:pl)")
    }
    let e = if type(given) == str {
      if has-han(given) { (long: given) } else { (long-en: given) }
    } else if type(given) == dictionary {
      given
    } else {
      _bad(key, "expected string or dictionary, found " + str(type(given)))
    }
    for (field, v) in e {
      if field not in _fields {
        _bad(key, "unknown field " + repr(field) + "; expected " + _errors.one-of(_fields.map(repr)))
      }
      // indexed 是三态布尔，别的字段都是字面
      if field != "indexed" and v != auto and type(v) != str {
        _bad(key, "field " + repr(field) + ": expected string or auto, found " + str(type(v)))
      }
    }
    // auto ＝ 不写
    let pick(field) = {
      let v = e.at(field, default: auto)
      if v == auto { none } else { v }
    }
    let long = pick("long")
    let long-en = pick("long-en")
    if long == none and long-en == none {
      _bad(key, "needs long or long-en")
    }
    let short = if pick("short") == none { key } else { pick("short") }
    let plural = if pick("plural") == none { short + "s" } else { pick("plural") }
    let indexed = e.at("indexed", default: auto)
    if indexed not in (auto, true, false) {
      _bad(key, "field \"indexed\": expected boolean or auto, found " + repr(indexed))
    }
    out.insert(key, (
      short: short, plural: plural, long: long, long-en: long-en,
      long-plural: e.at("long-plural", default: auto),
      // 这一条进不进索引。auto ＝ 跟着调用级与文档级走，见 src/config/settings.typ
      indexed: indexed,
    ))
  }
  out
}

#let _tristate(name, value) = {
  if value not in (auto, true, false) {
    panic("abbreviations: " + name + ": expected boolean or auto, found " + repr(value))
  }
}

// #abbreviations(…) 调：条目进表，两个开关进配置。*不发内容*
// 文档级的两个开关（iota-hit 的 abbreviation-fullwidth / abbreviation-links）。auto ＝
// 不表态，不动已有的值
#let configure(fullwidth: auto, links: auto, indexed: auto) = {
  _tristate("fullwidth", fullwidth)
  _tristate("links", links)
  _tristate("indexed", indexed)
  config.update(c => (
    fullwidth: if fullwidth == auto { c.fullwidth } else { fullwidth },
    links: if links == auto { c.links } else { links },
    indexed: if indexed == auto { c.at("indexed", default: auto) } else { indexed },
    printed: c.at("printed", default: false),
  ))
}

// 声明条目。收一份字典（yaml("abbreviations.yaml") 读出来就是），或一个字典数组（几个
// yaml 与手写的混着给）；印表的页调它，见 src/pages/abbreviations.typ
#let declare(value, fullwidth: auto, links: auto, indexed: auto, printed: false) = {
  _tristate("fullwidth", fullwidth)
  _tristate("links", links)
  _tristate("indexed", indexed)
  // 收一份字典，或一个字典数组（几个 yaml 与手写的混着给）：按数组顺序合，同一个键
  // 出现两次当场报错、点出在第几份——不做「后写的盖前面的」，那是 Typst 字典加法
  // 的静默覆盖，写成数组交给这里合就是为了拦住它
  let pieces = if type(value) == array { value } else { (value,) }
  let normalized = (:)
  let seen = (:)
  for (i, piece) in pieces.enumerate() {
    for (k, e) in normalize(piece) {
      if k in seen {
        panic(
          "abbreviations: " + repr(k) + " is declared twice (in piece "
            + str(seen.at(k) + 1) + " and piece " + str(i + 1) + " of the array)",
        )
      }
      seen.insert(k, i)
      normalized.insert(k, e)
    }
  }
  entries.update(e => e + normalized)
  // auto ＝ 不表态：先声明（page: false）后印表是两次调用，后一次的默认值
  // 不该把前一次写明的开关清掉
  config.update(c => (
    fullwidth: if fullwidth == auto { c.fullwidth } else { fullwidth },
    links: if links == auto { c.links } else { links },
    indexed: if indexed == auto { c.at("indexed", default: auto) } else { indexed },
    // 排过一次就是排过——先声明后印表那一档，前一次调用的 false 不该盖掉后一次
    printed: c.at("printed", default: false) or printed,
  ))
}

// 正文里的缩写链到的那个标签：*挂在表的开头，不挂在表里的行上*。
//
// *规矩：链接指向的标签，必须在*头一轮*排版里就已经存在。* 先前一行一个标签
// （iota-hit-abbreviation:FEM，挂在缩写那一格上），而行是 glossy 按「这个词用过没有」
// 筛出来的——那一步读 counter(词).final()，*头一轮返回初值 0*，于是头一轮一行都没有、
// 标签不存在，正文里那个 link 悬空；第二轮起才有。摘要末尾正好卡在分页处时，这一轮
// 与后面几轮的文档不一样，五轮之内来回翻：warning: document did not converge，关键词
// 那一页没页眉、页码印成阿拉伯 1。
//
// *判据是「头一轮在不在」，与标签挂在哪儿、外面套没套 context 无关*——实测：
//
//   锚点直接发（现在这样）                     收敛
//   锚点包进 context，值恒真                    收敛
//   锚点的门是 counter.final() == 0（头一轮成立）收敛
//   锚点的门是 counter.final() > 0（头一轮不成立）*不收敛*，与行标签那一版一模一样
//
// 所以标签由印表的页在章标题之后、表之前*无条件*发一个（anchor），链接落在表的
// 开头；表通常就一页，差的只是行内的几行。*要在章标题之后发*：章标题自己跳页，
// 发在它前面标签就落在上一页的页尾。对拍件 tests/demo-abbreviations-converge.typ。
// *我们自己发*，不用 glossy 的回链——它那份标签的名字带私有前缀，theme 契约只
// 把它当内容递来
#let table-label = label("iota-hit-abbreviations")

// 表排过了：由印表的页（list-of-abbreviations、nomenclature）在自己的位置发。正文里的
// 缩写据 config.final() 的这一位决定链不链，见 render
#let mark-printed() = config.update(c => c + (printed: true))

// 链接指到的那个标签，印表的页在章标题之后发，见 table-label
#let anchor() = [#metadata(none)#table-label]

// format-term 交出来的串：模式、键、当前短形。键放在 glossy 的 long 位——它要
// 一个非空的 long 才肯走 both / long 模式，而键正好稳定（复数时它连 long 也会
// 复数化，所以 longplural 也填键，见 rules）
#let _sep = "\u{1}"
#let _machine(mode, short, long) = mode + _sep + long + _sep + short

// 全称的复数：写了照写；没写，西文加 s、中文不动
#let _long-plural(e, picked) = {
  if e.long-plural != auto { e.long-plural } else if has-han(picked) { picked } else { picked + "s" }
}

// 组字。mode 是 glossy 判好的 both / long / short；lang 是用的那一处的语言
#let compose(mode, e, short, plural, lang, fullwidth) = {
  if mode == "short" { return short }
  let (open, close, comma) = if fullwidth { ("（", "）", "，") } else { (" (", ")", ", ") }
  if lang == "en" {
    // 英文：全称取英文，没有就中文；复数只加在西文全称上
    let picked = if e.long-en != none { e.long-en } else { e.long }
    let full = if plural { _long-plural(e, picked) } else { picked }
    if mode == "long" { return full }
    return full + open + short + close
  }
  // 中文：三种词条三种排法，见文件头
  if mode == "long" {
    return if e.long != none { e.long } else if plural { _long-plural(e, e.long-en) } else { e.long-en }
  }
  if e.long != none and e.long-en != none {
    e.long + open + e.long-en + comma + short + close
  } else if e.long != none {
    e.long + open + short + close
  } else {
    short + open + e.long-en + close
  }
}

// show-term 钩子：能读 context 的那一个。glossy 递来的是 _machine 拼的串
// （term-links 关着，不是 link）；不是我们拼的（@SCNA[覆盖文字]那一档）原样交回
#let render(body) = context {
  if type(body) != str { return body }
  let parts = body.split(_sep)
  if parts.len() != 3 { return body }
  let (mode, key, short) = parts
  // :cap 是 glossy 在串上做的——大写了模式那个词的首字母，搬到组好的字上
  let cap = mode != lower(mode)
  let e = entries.final().at(key)
  let lang = effective-lang()
  let c = config.final()
  let fullwidth = if c.fullwidth == auto { lang == "zh" } else { c.fullwidth }
  let out = compose(lower(mode), e, short, short != e.short, lang, fullwidth)
  if cap { out = upper(out.first()) + out.slice(out.first().len()) }
  // 顺带登记进索引：中英两条各进一段，登记的是这一处的页。默认不登记，见
  // src/config/settings.typ 的 abbreviation-indexed
  let marks = if _settings.resolve-abbreviation-indexed(
    entry: e.at("indexed", default: auto), local: c.at("indexed", default: auto),
  ) {
    (if e.long != none { _index.mark(e.long) } else { none },
     if e.long-en != none { _index.mark(e.long-en) } else { none }).join()
  }
  let links = if c.links == auto { true } else { c.links }
  // 表没排就不链——链到不存在的标签是硬错，见 config
  (if links and c.at("printed", default: false) { link(table-label, out) } else { out }) + marks
}

// 罩全文的那条规则。*iota-hit 的主 show 装*，摆在最内层：glossy 认不得的键
// （文献、图表）原样交回，再落到外层 omni 与题注那两条 show ref 上。
// 没有条目就什么都不装——一个 context 都不多套
#let rules(body) = context {
  let all = entries.final()
  if all.len() == 0 { return body }
  let g = (:)
  for (key, e) in all {
    g.insert(key, (short: e.short, plural: e.plural, long: key, longplural: key))
  }
  show: _glossy.init-glossary.with(
    g, format-term: _machine, show-term: render, term-links: false,
  )
  body
}

// 把「用过」全清掉：之后每个缩写再次首次展开。摘要一进门调一次、正文一进门调
// 一次——hithesis 只在英文摘要之后清（\glsresetall，hit-thesis.cls:8401），理由
// 它手册写了：「读者未必先读摘要，规范说的“文中第一次出现”指的也是正文」；
// 我们连每篇摘要开头也清——中文摘要用过的词到英文摘要里不该只剩个缩写。
// 做法就是 glossy 公开的 :reset 模式，ref(label("SCNA:reset")) 是 @SCNA:reset 的
// 函数写法；没有条目就一条都不发
#let reset() = context {
  for key in entries.final().keys() { ref(label(key + ":reset")) }
}
