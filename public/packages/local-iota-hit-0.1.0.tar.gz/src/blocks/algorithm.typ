// 伪代码。用法与图表一个形状，body 由哪个包排就叫哪个包的名：
//
//     #figure(lovelace[                      // algorithm2e 那一路：一行一个列表项
//       - INPUT: 训练样本 $(d_i, d_j)_q$     //   `-` 不编号（输入、输出）
//       + for $t = 1$ to $T$ do              //   `+` 编号，嵌套就是缩进
//         + $lambda_n^(t+1) <- …$
//       + return $lambda^T$
//     ], caption: [参数更新]) <alg:update>
//
//     #figure(algorithmic({                  // algorithmicx 那一路：DSL
//       import algorithmic: *
//       Procedure("Search", ("A", "x"), { While($l <= r$, { … }) ; Return[mid] })
//     }), caption: [二分查找])
//
// *行都由 lovelace 排*（缩进、行号、块的竖线）：algorithmic 只当 DSL 用——它的 AST 展开
// 成「一行内容 ＋ 缩进级」的表，再喂给 lovelace 的 pseudocode——两路排出来的竖线、钩、
// 行号一模一样（各排各的时候 algorithmic 的竖线是整列的 grid.vline、没有钩）。框
// （algorithm-style.frame 三档）、题注、编号、引用、按章重置、双语、#continued()、关键字，
// 都在 figure 那一层。包的选项一个都不透出来——三个门派都带行号、框由设定定、
// 输入输出是行不是参数。
//
// *挑了这两个不挑别的*：lovelace 与 algorithmic 是两种范式各一个（列表／DSL），正好对上
// LaTeX 的 algorithm2e 与 algorithmicx；algo 的写法是 #i\ #d\ 手动缩进、自带灰底标题栏、
// 行号不开口；algol-code 与 lovelace 同范式、2026-09 才发 0.1.0。
//
// *关键字是语义单位，不是字母。* algorithm2e 的 \For 印成 for 还是 FOR 由样式定；
// 这里按 src/config/terms.typ 的 algorithm 桶*整词、不分大小写*认（用户敲 for / For /
// FOR 都认），印出来的词从桶里取、大小写按 algorithm-style.keyword-case 统一。中文的实验室
// overrides: (algorithm-for: [对于]) 换词，中文不受大小写设定影响。误伤是所有关键字
// 表方案共有的：一行叙述里的 the input 也会被粗——躲进公式或 #text 就不认了；只在
// 伪代码里生效，正文不受影响。algorithmic 自己也粗关键字（strong("for")），我们这条
// 罩在它上面，印出来的样子仍按设定。
//
// *kind 由 body 定，用户不写。* Typst 只认 table / raw / 其余一律 image，所以 body 末尾
// 埋一个记号（src/engine/marks.typ 的 algorithm-mark），show figure 看见就把这张
// figure 重造成 kind "algorithm"，见 src/blocks/captions.typ。
//
// *续排的行号接着数。* 同一个算法拆两张，第二张从 1 数等于说这是另一个算法；与分图号
// 续着数同一个道理。记号里带这一段的行数，沿 #continued() 链把前几段的行数加起来当
// 偏移，交给包的编号函数。两个包都收编号函数，行数我们自己数（lovelace 数 `+` 项，
// algorithmic 用它自己的 ast-to-content-list 展开）。
#import "@preview/lovelace:0.3.1": pseudocode, pseudocode-list, indent as _indent
#import "@preview/algorithmic:1.0.7" as _algorithmic
#import "@preview/quan:0.2.2": quan as _quan
#import "../engine/marks.typ": algorithm-mark, find-algorithm
#import "../engine/settings.typ" as _settings
#import "../engine/terms.typ": term-table
#import "../engine/styles.typ" as _styles
#import "../engine/layout.typ" as _layout
#import "../engine/part.typ"
#import "../engine/lang.typ": doc-lang
#import "./captions.typ": _table-style, _cell-style, _continued-step, _continued-head, _word, _continued-mark, _continued-gap
#import "../engine/marks.typ": find-continued

// 块左侧那条缩进引导线：半条细线粗，黑；"hook" 那一档到块尾收一个小钩（半个字长，
// 我们自己画，见 _hook），none 不画。见 src/config/settings.typ 的 algorithm-style
// *要在 context 里调*（线宽读当前表格样式）
#let _guide(kind) = if kind == none { none } else { _table-style().stroke.header / 2 + black }

// 缩进一级两个字，与正文首行缩进同数；行号列一个半字、与正文隔半个字（行号排法见
// _number）
#let _INDENT = 2em
#let _NUMBER-COLUMN = 1.5em
#let _NUMBER-GAP = 0.5em

// ── 关键字 ─────────────────────────────────────────────────────
#let _table(lang) = term-table(lang, "algorithm")

// 一个关键字印成什么：桶里的词，再按设定统一大小写。title 只动首字母
#let _render(word, case) = {
  if case == "upper" { upper(word) }
  else if case == "lower" { lower(word) }
  else if case == "title" {
    let t = part.plain(word)
    if t == "" { word } else { upper(t.slice(0, 1)) + t.slice(1) }
  }
  else { panic("algorithm-style.keyword-case: expected \"upper\", \"lower\" or \"title\", found " + repr(case)) }
}

// 关键字那条规则：整词、不分大小写，只认桶里有的词。要在 context 里调
#let _keyword-rules(lang, case, body) = {
  let table = _table(lang)
  let pattern = "(?i)\\b(" + table.keys().join("|") + ")\\b"
  // show 规则的处理函数在 context 外跑，设定要在这儿读好带进去
  show regex(pattern): it => {
    let key = lower(it.text)
    if key in table { strong(_render(table.at(key), case)) } else { it }
  }
  body
}

// ── 续排的行号偏移 ──────────────────────────────────────────────
// 这一张在 #continued() 链上前面各段的行数之和。要在 context 里调，在 body 里调：
// 包着 body 的那张 figure 就是「在我之前最后起排的」algorithm
#let _line-offset() = {
  let sel = figure.where(kind: "algorithm")
  let mine = query(sel.before(here(), inclusive: true))
  if mine.len() == 0 { return 0 }
  let cur = mine.last()
  let n = 0
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    cur = _continued-step(sel, cur)
    if cur == none { break }
    let m = find-algorithm(cur.body)
    if m != none { n += m.lines }
  }
  n
}

// ── 表格型的表头 ───────────────────────────────────────────────
// 表格型的顶线、输入输出那几行、细线，连同跨页时续页右上角的「算法N-N（续算法）」，
// 都挂在 lovelace 的 title 里——那一格是 grid.header，每页重排一次，context 按页重算
// （三线表的续表行同一个办法，见 captions.typ 的 _continued-row）：
//
//   起排页  顶线 ／ 输入输出 ／ 细线
//   续页    「算法N-N（续算法）」／ 顶线
//
// 标注在顶线*之上*、表外，与续表同（先前画在框里，错的）。底线仍是外框的下边，
// 页底与末尾各一条
// *线要整宽*：title 那一格只有 grid 那么宽——grid 在行号列的垫（gutter）与横向内边距 x
// 里面，格里的块也就那么宽；负的 pad 在格里不起作用（先前那版没编译过就下了结论，
// 未证实）。线用 place 画：不占位，往左挪回框的边，长度就是版心宽（伪代码的 figure 与
// 版心同宽）
#let _tabular-title(head, s, x, width, gutter) = context {
  let sel = figure.where(kind: "algorithm")
  let mine = query(sel.before(here(), inclusive: true))
  let f = if mine.len() == 0 { none } else { mine.last() }
  let first = f == none or f.location().page() == here().page()
  // 线从行号列的左缘画起；不编行号（line-numbering: none）时没有那一列，从内边距的左缘起——
  // 先前不分，三条线里顶线与细线探到版心左边 21pt 外，底线（外框的下边）却在版心里（实测）
  let dx = -(gutter + x)
  let rule(where, stroke) = place(where + left, dx: dx, line(length: width, stroke: stroke))
  block(width: 100%, above: 0pt, below: 0pt, {
    if first {
      rule(top, s.top)
      if head != none {
        block(width: 100%, above: 0pt, below: 0pt, inset: (bottom: s.header / 2), head)
        rule(bottom, s.header)
      }
    } else {
      let lang = doc-lang.get()
      let name = _word(lang, "algorithm")
      let mark = _continued-mark(lang, name)
      // 靠右：lovelace 给那一格写死了 align: left，包一层 align 压不过；装进一个正好
      // 顶到内边距右缘的盒子里，拿 h(1fr) 推（盒子定宽，不指望格子有多宽）
      // 号取 #continued() 链的头：手工续排的那张自己的计数已被题注退回去，直接 display
      // 拿到的是退了一格的数（实测「算法1-1（续算法）」那张的续页印成 1-2）
      // 没写 #continued 的就是它自己——_continued-head 收 none 会去接前一张，那是别人的号
      let chain = find-continued(f.caption.body)
      let src = if chain == none { f } else { _continued-head(sel, chain) }
      let src = if src == none { f } else { src }
      let num = numbering(f.numbering, ..counter(sel).at(src.location()))
      block(width: 100%, above: 0pt, below: 0pt, box(width: width - gutter - 2 * x,
        h(1fr) + name + (if lang == "en" { " " }) + num + _continued-gap(mark) + mark + sym.zws))
      rule(bottom, s.top)
    }
  })
}

// ── 排行 ───────────────────────────────────────────────────────
// 两路都先展开成*平表*：一行一条 (body, level, numbered)，lovelace 的列表按嵌套展开，
// algorithmic 的 AST 用它自己的 ast-to-content-list 展开；再由同一个 _render 折回 lovelace
// 的 indent(…) 嵌套交给 pseudocode 排。行号与钩都在这一步挂到行里。

// 一段内容里*这一级*的项与其余的字：`#for` 拼出来的行、`#let` 存的一段、`#enum(…)`
// 造的列表，在 body 里都是套了一层的元素，得拆开——先前只看最外面一层，`#for` 出来的
// 那层 sequence 不是项、被整段扔掉，一个算法印出来是空的、还不报错（实测）
#let _CONTAINERS = ([].func(), enum, list)
#let _parts(body) = {
  let own = ()
  let items = ()
  for c in if body.has("children") { body.children } else { (body,) } {
    if c.func() in (enum.item, list.item) { items.push(c) }
    else if c.func() in _CONTAINERS { let (o, i) = _parts(c); own += o; items += i }
    else { own.push(c) }
  }
  (own, items)
}

// 这一级的项，不要别的字
#let _items(body) = _parts(body).at(1)

// 列表 → 平表：`+` 项编号、`-` 项不编号；项 body 里嵌的项是下一级
#let _flatten(items, level) = {
  let out = ()
  for c in items {
    if c.func() not in (enum.item, list.item) { continue }
    let (own, kids) = _parts(c.body)
    out.push((body: own.join(), level: level, numbered: c.func() == enum.item))
    out += _flatten(kids, level + 1)
  }
  out
}

// *行号排在行里，不排在 lovelace 的行号列里。* lovelace 把行号放在 grid 的另一格里
// 竖直居中，格子之间不对基线：一行里带下标、分数，格子长高，行号就与正文错开
// （实测带 (d_i, d_j)_q 的那一行错 0.8）。algorithm2e 的办法是 \llap——行号是这一行
// 自己的一部分、往左伸到边距里，天然对基线。这里照做：每行开头挂一个零宽的盒子，
// 里面的行号往左挪到行号列，整段左边垫出行号列的宽；lovelace 的行号关掉。
//
// *行号那段小字的两条边取字体自然的（ascender / descender），不用这一档的行盒*：这一档
// 贴网格时行盒是「em 系数 ＋ 绝对量」，小字的 em 那一半缩了、绝对那一半不缩，盒子上短
// 下长，与正文对齐基线后这一行被撑高 2.1（实测）；自然的边比正文的盒子矮，撑不高
// 这一行。号在列里靠右，用 h(1fr)，不用 align（进了盒子会变成块）。
//
// *列宽按这一段最宽的那个号来*，一个半字只是下限：先前写死四个字，line-numbering: "一"
// 排到「一百一十一」（五个字）就在盒子里折成两行、还探到版心左边 21pt 外（实测 x 64.20
// 对版心的 85.05）。号不是单调变宽的（一百一十八五个字、一百二十四个字），逐个量。
//
// *"①" 交给 quan 画*：中易宋体只有 ①–⑩，⑪ 起 Typst 回落到别的字体、字形大小宽度都变；
// quan 在字体覆盖之内用 Unicode 圈码、之外画圈，任何数都齐（脚注编号那一头 omni 也是
// 这么用它的，见 src/config/references.typ）。别的记法照 Typst 的 numbering，也收函数
#let _number-text(pattern, n) = text(
  size: 0.8em, top-edge: "ascender", bottom-edge: "descender", number-width: "tabular",
  if pattern == "①" { _quan(n) } else { numbering(pattern, n) },
)
#let _number(n, level, pattern, col) = box(width: 0pt, move(
  dx: -(level * _INDENT + _NUMBER-GAP + col),
  box(width: col, h(1fr) + _number-text(pattern, n)),
))

// 行号列的宽：不编号就没有这一列。*要在这一档的字里量*（_frame 里 show 之后的 context）
#let _column(pattern, from, to) = {
  if pattern == none { return 0pt }
  let w = _NUMBER-COLUMN.to-absolute()
  for n in range(from + 1, to + 1) { w = calc.max(w, measure(_number-text(pattern, n)).width) }
  w
}

// *钩自己画，不让 lovelace 画。* lovelace 的钩是那个跨行格子的下边线，Typst 给拆到两页
// 的格子每一片都画下边，页底就凭空多一个钩。改成挂在*块末行的行里*：一个 place 的
// 短横线，从引导线那一处往右伸半个字，页断在块中间就只断竖线。引导线在这一级正文
// 起点往左一个列距（lovelace 的列距是 indentation / 2）处；末行比块深几级就再往左几级
#let _hook(depth-below) = place(bottom + left,
  dx: -(_INDENT / 2 + depth-below * _INDENT),
  line(length: 0.5em, stroke: _guide("hook")),
)

// 平表 → lovelace 的 pseudocode 的 children：按级折成 indent(…) 嵌套；每行挂行号（编号的
// 行按文档顺序数，从 offset ＋ 1 起）、行尾的 1fr、收钩那一档的钩
#let _render(flat, offset, m, st, lang, col) = {
  let pattern = st.line-numbering
  // 这一行结掉几个块：下一行比它浅几级，就结几级（最后一行结掉所有）
  let ends(i) = {
    let next = if i + 1 < flat.len() { flat.at(i + 1).level } else { 0 }
    calc.max(0, flat.at(i).level - next)
  }
  // 一摞数组，第 k 层装第 k 级的行；进一级就压一层，退一级就把那一层折成 indent(…)
  // 挂到上一层末尾
  let stack = ((),)
  let k = offset
  for (i, line) in flat.enumerate() {
    while stack.len() - 1 > line.level {
      let top = stack.pop()
      stack.last().push(_indent(..top))
    }
    while stack.len() - 1 < line.level { stack.push(()) }
    let head = if line.numbered and pattern != none { k += 1; _number(k, line.level, pattern, col) } else { none }
    // *行尾不垫 fr*：包自己排的行里也有 fr（algorithmic 的 LineComment 靠它把注释推到右缘），
    // 两份 fr 平分空白，注释就停在半路上（实测）。标注要多宽由它自己的盒子定，见 _tabular-title
    let hooks = if st.indent-guide == "hook" { range(ends(i)).map(_hook).join() } else { none }
    // *关键字只在行的正文里认*，行号不进那条规则——字母编号（line-numbering: "a"）排到
    // 「do」「if」那几个号时会被当成关键字粗掉、改大小写
    stack.last().push(head + _keyword-rules(lang, st.keyword-case, line.body) + hooks)
  }
  while stack.len() > 1 {
    let top = stack.pop()
    stack.last().push(_indent(..top))
  }
  stack.first()
}

// lovelace 的选项：行号自己排（见 _number）、钩自己画（见 _hook）；行距不另发（line-gap
// 0），行盒由 _frame 那一档的样式给；缩进两个字；引导线按 indent-guide
#let _lovelace-options(st, title: none) = (
  line-numbering: none,
  line-gap: 0pt,
  indentation: _INDENT,
  hooks: 0pt,
  stroke: _guide(st.indent-guide),
  // 表格型的表头（顶线、输入输出、细线，跨页时续页顶上的标注）住在这里，见 _tabular-title
  title: title,
  title-inset: 0pt,
)

// 一段行：平表排成 pseudocode。行号列那一截垫在外面（_frame），这里不垫——表格型的
// 输入输出住在正文的 title 格里，那一格已经在垫里面，垫两遍就比正文深一级
#let _lines(flat, st, m, lang, col, offset: 0, title: none) = pseudocode(
  .._lovelace-options(st, title: title), .._render(flat, offset, m, st, lang, col),
)

// ── 框 ─────────────────────────────────────────────────────────
// 要在 context 里调，收两张平表：head 是不编号的那几行（输入、输出，可为空），rest 是
// 正文。行号列的宽、那一列的垫、行号偏移都在这儿算一次，head 与 rest 用同一份——摊在
// 两头算过一版，表格型的输入输出垫了两遍。关键字规则在行这一级挂（_render），这里不挂
//
// 字与行盒与三线表的格子同一套：题注那一档的字（五号）、贴网格（一行一个网格行，
// 不贴网格的档 1.25 倍），理由见 captions.typ 里 cell-style 那一段。
// 线宽与内边距也是三线表的（table-strokes / table-inset-x，用户定的，不跟 algorithm2e
// 的 0.8 / 0.4），三个门派差的只是线画在哪（algorithm2e 自己编出来量过：boxed 一圈框、
// 题注在下；algoruled 粗／题注／细／正文／粗；plainruled 上下两条、题注在下——表格型的
// 题注*我们放上面*、输入输出下面加一条细线，跟三线表，用户定的）：
//
//   tabular  粗线 ／ 输入输出 ／ 细线 ／ 正文 ／ 粗线（题注在表外上方，由 figure 排）
//   ruled    细线 ／ 输入输出 正文 ／ 粗线（题注上面那条粗线由题注自己画，见
//            captions.typ 的 _caption-line——题注在两条线之间）
//   boxed    一圈细线的框（题注在框外下方，由 figure 排）
#let _frame(head, rest) = {
  let st = _settings.resolve-algorithm-style()
  let style = st.frame
  let lang = doc-lang.get()
  let layout = _layout.current-layout()
  let grid = layout.docgrid.grid
  // 字与行盒是三线表格子那一档（styles.figure.table：五号、单倍贴格；字号取表格样式的，
  // 不读样式链——伪代码的字不经 show table），线宽与内边距也从它取
  let ts = _table-style()
  let cell = _cell-style(ts, ts.size)
  let s = ts.stroke
  let x = ts.inset.x
  // 块与块之间不发段距（这一档样式的 par.spacing 会落在相邻的 block 之间，细线下面
  // 凭空多一行）；内边距与三线表同：挨着线的那一边垫半条线
  let piece = block.with(width: 100%, above: 0pt, below: 0pt)
  // 这一档的行盒度量，给行号那段小字定两条边用
  let m = part.resolve(cell, layout: layout)
  show: part.rules.with(cell, layout: layout, set-font: true)
  set align(left)
  // 行号列的宽要量这一档的字，得量在 show 之后——在外面量到的是正文那一档
  context {
  let off = _line-offset()
  let col = _column(st.line-numbering, off, off + rest.filter(l => l.numbered).len())
  // 行号列 ＋ 半个字的间距；不编号就没有这一列
  let gutter = if col == 0pt { 0pt } else { col + _NUMBER-GAP }
  let top = if head.len() == 0 { none } else { _lines(head, st, m, lang, col) }
  // 表格型：顶线、输入输出、细线与续页标注都在 lovelace 的 title（每页重排）里，见
  // _tabular-title（横向内边距那一层它自己垫）。那一格已经在 gutter 的垫里面，输入输出
  // 这一截*不再垫第二遍*
  let title = if style == "tabular" {
    _tabular-title(if top == none { none } else { piece(top) }, s, x, layout.text-width, gutter)
  } else { none }
  // *横向内边距垫在内容上，不垫在外框上*：垫在外框上，中间那条细线就比上下两条短
  // 两个内边距（实测）。三条线都是整宽的
  let top = if top == none { none } else { piece(inset: (x: x), pad(left: gutter, top)) }
  let main = piece(inset: (x: x), pad(left: gutter,
    _lines(rest, st, m, lang, col, offset: off, title: title)))
  // 光一条线：零高的块画上边
  let rule(stroke) = piece(height: 0pt, stroke: (top: stroke))
  if style == "tabular" {
    // 底线是外框的下边：拆页时 Typst 给每一片各画一条——页底收底线，与三线表跨页每片
    // 完整同；顶线在 title 里、每页一条
    piece(stroke: (bottom: s.bottom), inset: (top: s.header / 2, bottom: s.bottom / 2), main)
  } else if style == "ruled" {
    // 线*不是*块的边，是前后各一条独立的线：拆页时页底与续页都不画线、不标注，
    // 行号接着数就是了（用户定的）
    rule(s.header)
    piece(inset: (top: s.header / 2, bottom: s.bottom / 2), {
      top
      main
    })
    rule(s.bottom)
  } else {
    // 框图型也拆（默认三档都拆），按续图的排法——题注跟头一页、续页末尾「算法N-N（续算法）」
    // （captions.typ 的 _split），拆开的每一片 Typst 各画一圈框。拆不拆读 figure 上那条
    // set block(breakable:)（在这儿就是样式链上的值，不另传），用户写 false 整块挪到下一页
    piece(stroke: s.header, inset: (y: s.header / 2), {
      top
      main
    })
  }
  }
}

// 把 body 拆成两截：*开头*那几个不编号的项（输入、输出）与其余。表格型把前一截摆在
// 细线上面（三线表的表头），另两档也照 algorithm2e：\KwIn \KwOut 不编号、在正文前
#let _split(body) = {
  let items = _items(body)
  let n = 0
  for c in items { if c.func() == list.item { n += 1 } else { break } }
  (items.slice(0, n), items.slice(n))
}

// 公开的那个。记号要在 context *外面*——find 钻不进 context 元素，见 captions.typ 里
// 三线表那一处的同一条注释。记号里的行数是编号的行数，续排接着它数
#let lovelace(body) = {
  let (head, rest) = _split(body)
  let head = _flatten(head, 0)
  let rest = _flatten(rest, 0)
  context _frame(head, rest)
  algorithm-mark(rest.filter(l => l.numbered).len())
}

// ── algorithmic ────────────────────────────────────────────────
// 与 #import "@preview/algorithmic" 里的 algorithm(..bits) 同一个写法，bits 是它的 DSL
// （Procedure / If / While / Assign / Return …，用户自己 import 那个包拿名字，见抬头）。
// 只借它的 AST：ast-to-content-list 展开成 (line-content, line-indent) 的平表，缩进以
// 「单位」计、一级两个单位；折成我们的平表（每行都编号）交给同一个 _render。它没有
// 输入输出那一截：Line[*Input:* …] 就是普通的一行
#let algorithmic(..bits) = {
  let flat = bits.pos().map(b => _algorithmic.ast-to-content-list(0, b)).flatten()
    .map(l => (body: l.line-content, level: calc.quo(l.line-indent, 2), numbered: true))
  context _frame((), flat)
  algorithm-mark(flat.len())
}
