// 题注（图题、表题）与三线表。
//
// 依据是写作指南 2.12 插表 / 2.13 插图（*不是 3.3*，那一节是封面内封）。
// 研究生那一档另见「研究生学位论文写作指南」的（十一）（十二）。
//
// 规范给了什么：
//
//   图序表序*按章编排*，图1-1 / 表6-1；序与名之间空 *2 个半角字符*；
//   名中不用标点、名后不加标点；*宋体 5 号字*；*表题在表上、图题在
//   图下*；图注置于图题之上；正文里必须先有提示（「见图1-1」「如表1-1所示」）；
//   表*不加左右边线*、建议*三线表*；插表上下与正文*空一行*。
//
// 按学位分档：本科、硕士只用中文；*博士中英两种文字，居中，中文在上*。
// 见 src/config/settings.typ 的 caption-bilingual-auto。
//
// *行距是我们定的，规范一个字没提。* 取 1.25，与正文同一档（指南 3.2 那张
// 表里唯一给了行距的条目就是「正文 宋体小4号字，多倍行距值1.25，段前0行，
// 段后0行」）。博士范例的双语两行反推不出一致的值——去掉那份 PDF 的缩放后，
// 图题那一跳 14.08、表题 15.51，解出来分别是 1.09 倍与 1.20 倍，*范例自己
// 就矛盾*；唯一自洽的是表题里*纯西文那一跳* 15.03，与 1.25 倍算出的 15.09
// 差 0.06。所以按 1.25 走，不去凑那两个数。
//
// *题与图/表之间取 0，待校。* 范例里图题紧跟着图，但图片下沿量不到，
// 没有干净的实测。哪天有能量的样本再定。
//
// 双语那两行*不设间距*，让行盒模型自己算：上行（中文五号 1.25 倍）的行深
// 加下行（西文五号 1.25 倍）的上升部 = 6.355 + 9.874 = 16.23。两行拆成两个
// 紧挨的块而不是一段里软换行——Word 的段内行距与块间距是同一个公式
// （上块深 + 下块升 + max(段后,段前)），拆开只是为了让英文那一行换成西文行盒。

#import "../engine/part.typ"
#import "../engine/layout.typ" as _layout
#import "./chapter.typ" as _chapter
#import "../engine/styles.typ"
#import "../engine/marks.typ": find-en, find-subs, find-subs-gap, find-continued, find-algorithm, trim-tail, title-of, in-listing
#import "../engine/case.typ": english-title
#import "../engine/lang.typ": doc-lang
#import "../engine/terms.typ": term-table, term-for, term-apply, info-variant
#import "../engine/info.typ": info-get
#import "../config/axes.typ": campus-for
#import "../engine/settings.typ": (
  resolve-caption-bilingual, resolve-subcaption-bilingual, resolve-subcaption-gap,
  resolve-algorithm-style, resolve-raw-style, setting-of,
)
#import "../engine/constants.typ": msword-cm
#import "../config/fonts.typ": zihao
#import "../config/settings.typ": caption-separator-auto
// 题注那一档的取值，值住在 src/config/styles.typ
#import "../config/styles.typ": default-styles

// 三线表的数据行：*行高就是文档网格的行距，行盒在行里垂直居中*。
//
// 实测本科范例第 12 页那张表（trace 读三条线，stext 读基线）：
//
//   顶线 327.35–328.85（1.5）  表头下 386.12–387.12（1.0）  底线 521.40–522.90（1.5）
//   数据基线 400.62 … 515.65，七行六步共 115.03，一步 19.17
//   行高 = (521.40 − 387.12) / 7 = 19.18
//   首基线距行顶 = 400.62 − 387.12 = 13.50
//
// 那一节（第 4～6 章，拷贝进来的 FLUENT）的 docGrid 是 linePitch=383，也就是
// 19.15 磅——步进与行高都是它。而 13.50 由模型算得出来：五号行盒 1.296875 × 10.5
// = 13.617 在 19.15 的行里居中，上留 (19.15 − 13.617) / 2 = 2.77，基线 = 2.77 +
// 上升部 10.66 = 13.43，与量到的 13.50 差 0.07。
//
// 所以两个内边距都是 (网格行距 − 行盒高) / 2，*一个常数都不用存*。终稿默认
// 的跨度是 391 缇 ＝ 19.55（见 src/config/layout.typ），表在正文里排出来的行高就是
// 19.55、首基线距行顶 13.63——范例那张表落在 383 的节里才是 19.15，规则不变。
//
// *先前这里存过 13.98 / 19.24*，还写着一段「为什么不是上下对称」——那是
// 当初把行高当成了 15.84（行盒加两个 1.11）才得出的结论；行高取网格的 19.15
// 之后，对称居中恰好就是对的。
//
// 横向那一份是读出来的：范例的表没写 tblCellMar，用的是 styles.xml 里
// docDefaults 那一份——上下 0、左右各 0.19 厘米（「表格属性 → 单元格边距」上
// 就是这么显示的，存进 docx 是 108 缇）。
// *数住样式表*（src/config/styles.typ 的 _table，Word 那张「表格」卡），这里只留默认值的
// 别名给别处 import；排的时候读当前那一份（_table-style），局部 #show: styles.with(…) 改得动
#let table-inset-x = default-styles.figure.table.inset.x


// 续排那一页「表N-N（续表）」那一行的上下位置，*与单元格同一条规则算出来*：
// 单倍行盒在网格行里居中。
//
// 实测本科范例第 14 页（trace 读线，stext 读基线）：
//
//   标注基线 121.28（五号、右对齐）   顶线 127.05–128.55，中心 127.80
//   版心顶 107.75 → 标注基线 13.53      标注基线 → 顶线中心 6.52
//
// 模型算：
//
//   上 = (19.15 − 13.617) / 2 + 上升部 10.66 = 13.43   （差 0.10）
//   下 = 行深 2.96 + 下半格 2.77 + 半条顶线 0.75 = 6.48（差 0.04）
//
// docx 那一段写着 w:jc="right"、sz=21、*没有 w:spacing*——单倍，与表内
// 单元格一样。博士范例第 16 页量到 13.55 / 6.45，两份对得上。
//
// 先前这里存的是 13.53 / 6.52 两个实测数。
// 三线表的三条线。*读自范例的 docx，不是从 PDF 上量的*。
//
// 指南只说「不加左右边线」「建议采用国际通行的三线表」，一个数都没给。范例里
// 那张表的 tblPr 是全框 sz=4，三条线由*单元格级*的 w:tcBorders 逐格盖掉：
//
//   表头行  top=single sz=12   bottom=single sz=8   left/right=nil
//   数据首行 top=single sz=8    其余 nil
//   末行    bottom=single sz=12  其余 nil
//   中间各行 四边全 nil
//
// w:sz 的单位是八分之一磅，sz=12 / 8 就是 Word「边框和底纹」里那个宽度下拉框上的
// *1½ 磅*与*1 磅*——写界面上的数，换算是我们内部的事。
// （更早那组 1 / 0.5 / 1 是按出版界通行值拍的，后来量了 PDF，现在是读出来的。）
#let table-strokes = default-styles.figure.table.stroke

// 当前生效的表格那一档样式（文档级并过局部的），inset 折成 (x:, y:) 字典。*要在 context 里调*。
// 单元格里的段落属性（字号、行距、贴格、缩进）从这一份取，字号由 show table: set text(size:)
// 那条 show-set 给、用户就地 set 的压过它，所以排格子时字号读样式链、不读这里
#let _table-style() = {
  let ts = styles.styles-state.get().figure.table
  let inset = ts.inset
  let inset = if type(inset) == length { (x: inset, y: inset) } else {
    (x: inset.at("x", default: 0pt), y: inset.at("y", default: 0pt))
  }
  ts + (inset: inset)
}
// 格子那一档的段落样式：表格那一档去掉不是段属性的键，字号按样式链上当前的
#let _cell-style(ts, size) = {
  let st = ts
  for k in ("above", "gap", "below", "inset", "stroke") { let _ = st.remove(k, default: none) }
  st + (size: size)
}

// 「图」「表」两种题注的编号计数器

// 伪代码的 figure 是重造的（见 caption-rules 里那条 show figure），用户写的那个 kind 还是
// image 的*原件*仍然在：可查、记数、进 outline（实测被换掉的元素照样在 query 里，图的
// 计数器也被它步进了一格——原件后面那张图印成「图1-3」、插图索引里多一条「图1-2 算法」）。
// 所以凡是按 kind 查图的地方都要把原件剔掉，计数器由重造那条规则退回去
#let _original(f) = f.kind == image and find-algorithm(f.body) != none

// 标签指向的元素换成真正排出来的那一张：用户的标签留在原件上，紧跟在它之后的第一张
// algorithm 就是替它排的那一张。别的元素原样交回。*要在 context 里调*
#let _resolve(el) = {
  if el == none or el.func() != figure { return el }
  if el.kind != image or find-algorithm(el.body) == none { return el }
  let after = query(figure.where(kind: "algorithm").after(el.location(), inclusive: true))
  if after.len() == 0 { el } else { after.first() }
}

// 三种第一方的 kind：图、表、伪代码。伪代码的 kind 是字符串——Typst 的 figure(kind:)
// 收元素函数或字符串，不是元素的只能是字符串；全词，与 image / table 一路
#let algorithm-kind = "algorithm"
#let _kinds = (
  (kind: image, term: "image"), (kind: table, term: "table"),
  (kind: algorithm-kind, term: "algorithm"),
  // 代码清单：kind 是 Typst 自己的 raw，名走词条（中文「代码」、英文 Listing），
  // overrides: (caption-raw: …) 换词，题注、引用、续排标注一起变
  (kind: raw, term: "raw"),
)


// 图、表、公式的引用*自己重建*，为的是两件事。
//
// *一、章号要在对象位置上取。* 我们的按章编号写成闭包，里面
// counter(heading).get()——而 Typst 渲染引用时是在*引用点*调那个闭包的。
// 实测第一章里的公式在第二章引用，三类全错：对象印「(1-1)」「图1-1」「表1-1」，
// 引用却印「式 (2-1)」「图 2-1」「表 2-1」。裸 Typst 一样复现，是这个写法本身的坑。
// 分图那一支本来就是按落点取的（counter(heading).at(e.loc)），漏的是普通那几类。
//
// *二、名与号之间那个空格。* Typst 的 ref 会插一个 U+0020（实测步进 3.000），
// 而指南三类都没有空格：「见式（1-1）」「见图1-1」「如表1-1所示」「见表1」。
// 但两种情形要留：*英文名*（Fig. 1-1，西文本来就该空）与*半角括号*
// （「式 (1-1)」，半角「(」几乎没有左边距，贴上去挤）。全角括号自带边距，不留。
//
// *认不出的原样交回。* 文献引用的 it.element 是 none，第一道就放行——
// omni-gb7714 也装 show ref，它同样把不是文献键的交回（实测两条规则嵌套时，
// 内层 return it 之后外层照样接手），所以两边不冲突。
#let _ref-number(el, fig-by-chapter, eq-by-chapter) = {
  let loc = el.location()
  // *括号单列一栏，不从编号串里切。* 按章那一档拼不出整串交给 numbering()
  // ——章号可能是字母（附录），而 numbering() 只吃整数，见 src/blocks/chapter.typ。
  // 先前这里拿 pat 的首尾字符当括号，图表那一档的 pat 是 "1-1"，于是把 1 当成
  // 了括号，排出「图11-11」。
  let (cnt, chap, open, close) = if el.func() == figure {
    (counter(figure.where(kind: el.kind)), fig-by-chapter, "", "")
  } else if el.func() == math.equation {
    // 括号两档，与 src/blocks/math.typ 那一处同源
    (
      counter(math.equation),
      eq-by-chapter,
      ..(if setting-of("equation-numbering-fullwidth") == true {
        ("（", "）")
      } else { ("(", ")") }),
    )
  } else {
    return none
  }
  let n = cnt.at(loc)
  if chap {
    // 公式那一档的「附」在括号里（（附1-1）），图表那一档在名上（见 _ref-supplement）
    _chapter.chapter-numbered(
      loc, n, open: open, close: close,
      prefix: if el.func() == math.equation {
        _chapter.appendix-prefix(loc, doc-lang.get(), by-chapter: chap)
      },
    )
  } else {
    numbering(open + "1" + close, ..n)
  }
}

// 一处引多个时*名只印一遍*：「由公式（4-1）、（4-2）求得」，范例第 4 章印的
// 就是这个。
//
// *做法学 omni-gb7714*（它把 [1][2][3] 并成 [1-3] 用的是同一套）：show ref
// 不直接排，先吐出*记号包着的标签*；再用一条 show regex 把*相邻的几个
// 记号*整段抓住，交给组处理器一次排完。
//
// *妙在记号是纯文本*——regex 看得见「两个引用之间夹了什么」，而那一层
// show par 拿不到（返回重建的内容就再触发自己，报 maximum grouping depth
// exceeded；metadata 记号也挡不住，重新分组发生在规则看到记号之前）。
//
// 记号取私用区的三字组，与 omni 同一个理由：正文里撞不上，而且三个字连着更不会
// 被别的规则误伤。我们的 latin-run 只收到 U+024F，私用区落在外面，不会被切。
#let _RM = "\u{E7A1}\u{E3D2}\u{EB09}"

// 载荷里「标签」与「用户自己给的名」之间的隔子。名（@a[公式]）得跟着标签一起
// 传到组处理器手里，不然一组里只有头一个能定名。*记号是纯文本，带不了内容*，
// 所以只带得动纯文本的名——不是纯文本的（@a[*图*]）就不并组，原样单排，
// 见 _plain-ref 里那道 _text-only。
#let _RS = "\u{E4B6}\u{EA25}\u{ED73}"

// 这一段内容是不是*纯文本*（只有文字与空格）。不是就带不过记号，
// 那一档退回单排——宁可不并组，也不能把用户写的格式悄悄丢掉。
#let _space-func = [ ].func()
#let _text-only(c) = {
  if type(c) == str { return true }
  if type(c) != content { return false }
  if c.func() == text or c.func() == _space-func { return true }
  if c.has("children") { return c.children.all(_text-only) }
  false
}

// 相邻的判据：*中间只许夹分隔标点与空白*。「@a@b」「@a、@b」「@a, @b」都算，
// 「@a 与 @b」不算——那中间是实词，并起来会把话说坏。
// 题注里那个字（图／表、Fig. / Figure / Table）*按档取*——深圳的英文档写
// 全称 Figure，见 src/config/terms.typ 的 caption 桶。*档从 info 取*：题注
// 这一路本来就都在 context 里，不必再从 iota-hit 一层层递进来；校区先过
// campus-for（那边没发过这一档表单的学位归本部），与页眉、封面同一个办法
#let _word(lang, key) = term-for(term-table(lang, "caption"), key, info-variant())

// *用户在这一张图表上显式写的 supplement*（figure(image(…), supplement: [照片])）：
// 写了就照它印——题注、引用、清单三处同一条。没写返回 auto。
//
// *怎么知道写没写。* 图表的 supplement 出厂就是 auto，Typst 实现元素时按 kind 与
// text.lang 填上它自己的字样（image: 图 / Figure，table: 表 / Table），fields() 里读到
// 的就是这个*填好的值*，与用户显式写的分不出来；而我们那句 show-set 填进去的词
// （Fig.）在 fields() 里看不见，只在 it.supplement 里有。所以判据是「fields() 里的值
// 不是 Typst 自己那两个字样」——那两个字样按语言列在下面，是 Typst 的 l10n 表，不是
// 我们的词（我们的在 src/config/terms.typ）。代价：英文档里显式写 [Figure] 会被当成
// 没写、印成 Fig.；要全篇改字样走 overrides，README 写着。supplement: none（只要号）
// 照 Typst 的意思：名空着。
#let _typst-supplements = (
  image: (zh: "图", en: "Figure"), table: (zh: "表", en: "Table"), raw: (zh: "代码", en: "Listing"),
)
#let _given-supplement(fields, kind, lang) = {
  let k = _kinds.find(k => k.kind == kind)
  if k == none { return auto }
  let v = fields.at("supplement", default: auto)
  if v == auto { return auto }
  if v == none { return [] }
  // 伪代码那一档 Typst 没有自己的字样，fields() 里填的就是我们那句 set 给的词——与它
  // 相同就是没写
  if k.term not in _typst-supplements { return if part.plain(v) == part.plain(_word(lang, k.term)) { auto } else { v } }
  let dflt = _typst-supplements.at(k.term).at(lang, default: _typst-supplements.at(k.term).zh)
  if part.plain(v) == dflt { auto } else { v }
}
// 续排的标注：「（续」加这一种东西的名（图／表／算法／照片…），词条是函数，
// 见 src/config/terms.typ 的 continued
#let _continued-mark(lang, name) = {
  let i = info-get()
  term-apply(
    term-table(lang, "caption"), "continued",
    (degree-level: i.degree-level, campus: campus-for(i.campus, i.degree-level)),
    name,
  )
}

#let _RSEP = "[ \u{00A0}\t]*[、，,；;]?[ \u{00A0}\t]*"

// *名。* 从词条取，不从元素上读——图表的 supplement 是用
// show figure.where(kind:): set figure(supplement:) 设的，那是 show 规则里的 set，
// 换个上下文读 el.supplement 拿到的是 Typst 自己的默认值。中文档恰好也是「图」「表」
// 所以看不出来，英文档当场露馅：该印 Fig. 印成了 Figure。
#let _ref-supplement(el, by-chapter) = {
  let lang = doc-lang.get()
  // 引「附表1-1」时名也得带「附」——号在被引对象那一处求，「附」也一样
  // （公式那一档的「附」在括号里，不在名上，见 _ref-number）
  let prefix = if el.func() == math.equation { none } else {
    _chapter.appendix-prefix(el.location(), lang, by-chapter: by-chapter)
  }
  if el.func() == math.equation { return _word(lang, "equation") }
  let k = _kinds.find(k => k.kind == el.kind)
  // *自造的 kind 用它自己的名*（figure(kind: "algo", supplement: [算法])）：那一档
  // Typst 逼着用户写 supplement，而我们那句 set figure(supplement:) 只落在图与表上，
  // 所以这儿读到的就是用户写的，不是出厂默认——图表那两档才读不得，见 _word；
  // 图表上显式写的 supplement 另有判法，见 _given-supplement
  let given = _given-supplement(el.fields(), el.kind, lang)
  prefix + (if k == none { el.supplement } else if given != auto { given } else { _word(lang, k.term) })
}

// *名与号之间空不空。* Typst 的 ref 会插一个 U+0020（实测步进 3.000），
// 而指南三类都没有空格：「见式（1-1）」「见图1-1」「如表1-1所示」「见表1」。
// 但两种情形要留：*英文名*（Fig. 1-1，西文本来就该空）与*半角括号*
// （「式 (1-1)」，半角「(」几乎没有左边距，贴上去挤）。全角括号自带边距，*不论
// 名是中是英都不留*——「Equation（1-1）」再空一格就是两份边距。
#let _ref-gap(sup, num) = {
  let n = part.plain(num)
  if n.starts-with("（") { [] }
  else if not part.has-cjk(part.plain(sup)) or n.starts-with("(") { sym.space.nobreak }
  else { [] }
}

// 号与*续排标注*之间空不空，判据与 _ref-gap 同源：全角括号自带边距，不空
// （「表1-1（续表）」，范例就是这个样子）；半角括号几乎没有左边距，贴上去成了
// 「Fig. 1-2(Continued)」，要空一个。空的是不折行的空格——号与标注是一体的
#let _continued-gap(mark) = if part.plain(mark).starts-with("（") { [] } else {
  sym.space.nobreak
}

// 认不出的原样交回。文献引用的 it.element 是 none，第一道就放行——omni-gb7714
// 也装 show ref，它同样把不是文献键的交回（实测两条规则嵌套时，内层 return it
// 之后外层照样接手），所以两边不冲突。
#let _plain-ref(it, fig-by-chapter, eq-by-chapter) = {
  let el = _resolve(it.element)
  if el == none { return it }
  if _ref-number(el, fig-by-chapter, eq-by-chapter) == none { return it }
  let given = it.fields().at("supplement", default: auto)
  // supplement: none 是「只要号」，那一份没有名可并，直接排
  if given == none { return link(el.location(), _ref-number(el, fig-by-chapter, eq-by-chapter)) }
  // 用户给的名不是纯文本就带不过记号，退回单排——宁可不并组，也不能把格式丢掉
  if given != auto and not _text-only(given) {
    let num = _ref-number(el, fig-by-chapter, eq-by-chapter)
    return link(el.location(), given + _ref-gap(given, num) + num)
  }
  // 吐记号，交给下面那条组规则排。单个也走它——组正则的重复部分是 *，一个也匹配
  _RM + str(it.target) + (if given == auto { "" } else { _RS + part.plain(given) }) + _RM
}

// 把一组记号排成「名 号、号、号」。分隔符*原样保留用户写的那个*——中文写
// 顿号、英文写逗号，各随各的习惯，我们不替他选。
// 并组的判据是*同一类*，不是「名的文字相同」。
//
// 「@eq:a、@fig:a、@tbl:a」这一串挨着，三个不同类——一并省掉就成了
// 「式 (1-1)、1-1、1-1」。而按文字比又太紧：用户在头一个上写了 @a[公式]，
// 后面几个没写，文字不同就并不起来，排出「公式 (1-1)、式 (1-2)」，难看。
//
// 所以：*类相同就并*，名取组内*头一个*的；后面某一个又显式写了别的名，
// 就从那里另起一组。
#let _ref-class(el) = if el.func() == math.equation { "equation" } else {
  repr(el.at("kind", default: none))
}

#let _ref-group(text, fig-by-chapter, eq-by-chapter) = {
  // 「_RM k1 _RM s1 _RM k2 _RM」拆开是 ("", k1, s1, k2, "")：奇数位是载荷，
  // 偶数位（首尾除外）是用户写在两个引用之间的那一段
  let parts = text.split(_RM)
  let loads = ()
  let seps = ()
  for (i, p) in parts.enumerate() {
    if calc.odd(i) { loads.push(p) } else if i > 0 and i < parts.len() - 1 { seps.push(p) }
  }
  let out = ()
  let cls = none          // 当前这一组的类
  let name = none         // 当前这一组的名（纯文本，用来判后面有没有换名）
  let custom = false      // 本组的名是不是引用上显式写的（是就管住整组）
  for (i, load) in loads.enumerate() {
    let bits = load.split(_RS)
    let key = bits.first()
    let given = if bits.len() > 1 { bits.at(1) } else { none }
    let found = query(label(key))
    if found.len() == 0 { return text }
    let el = _resolve(found.first())
    let num = _ref-number(el, fig-by-chapter, eq-by-chapter)
    if num == none { return text }
    if i > 0 { out.push(seps.at(i - 1)) }
    let k = _ref-class(el)
    // 另起一组：类换了；或者这一个在引用上显式写了个跟本组不一样的名；或者本组的名
    // 不是引用上写的、而这一个对象自己的名跟它不一样——图表上显式写的 supplement
    // （figure(…, supplement: [照片])）算对象自己的名，「见图1-1、照片1-2」不能并成
    // 「图1-1、1-2」。引用上写了名的组管住整组（头一个写「公式」，后面的都跟着）
    let own = _ref-supplement(el, fig-by-chapter)
    if k != cls or (given != none and given != name) or (given == none and not custom and part.plain(own) != name) {
      cls = k
      custom = given != none
      let sup = if given != none { given } else { own }
      name = part.plain(sup)
      out.push(link(el.location(), if sup == none { num } else {
        sup + _ref-gap(sup, num) + num
      }))
    } else {
      out.push(link(el.location(), num))
    }
  }
  out.join()
}




// 序与名之间的 2 个半角字符。
//
// 半角字在 Word 的字符网格里吃半格：字身宽的一半加网格增量的一半。两个就是
// 一个全角字的宽度。实测本科范例「表6-1」到表名是 11.28，差的 0.33 是字形的
// 左右边距，不是间距本身。
// 编号与题名之间。auto *按文档语言*取：中文一个字、英文四分之一个
// （Times 的一个空格，原件敲的就是一个），取值与出处见 src/config/settings.typ
// 的 caption-body-indent-auto。*跟文档语言不跟这一行的语言*——中文档里
// 双语题注的英文行照样空一个字，与标题那一档同一条，见 heading-body-indent。
// *要在 context 里调*
#let _separator(layout) = {
  // *原生那一格就是这一处*：figure.caption(separator:) 说的正是「题序与题名
  // 之间」。用户写了就照写（收内容，写 h(2em) 也行、写 [：] 也行），没写才用本档
  // 的默认——*默认是 auto，所以「写没写过」测得出来*。
  if figure.caption.separator != auto { return figure.caption.separator }
  h(part.ccwd(
    caption-separator-auto.at(doc-lang.get(), default: caption-separator-auto.zh),
    layout: layout,
  ))
}

// 半角标点之后那一个半角空当（分图号、连排的分隔符）。半个汉字宽，跟着当前字号走。
// *不给配置口子*：它由「半角补、全角不补」那条判据自动定，给了就能配出
// 「(a)　　静压」这种自相矛盾的组合。
#let _half-gap(layout) = h(part.ccwd(0.5, layout: layout))

// 一行题注。lang 决定取哪一层词条与哪一套编号写法。
//
// *名与序之间那一跳还没校准。* 本科范例「图」到「1」步进 13.75，我们
// 15.91，多 2.16。两边都在汉字接拉丁那一处补了东西——Word 补的是网格增量，
// Typst 还另加一份 cjk-latin-spacing。这是 README「汉字接拉丁」记的那一类固有
// 差，留到题注对拍那一轮统一处理。
// 文档顺序里排在 loc *之前*的那一张。*要在 context 里调*
//
// *要跳过最后一个*：before() 是闭区间，loc 上那一个自己也在里面。在题注里调
// 时最后一个是本图（题注排在图*里面*），从图自己的位置调时最后一个就是它。
// 实测不跳的话链上一步就原地打转，走满上限——分图号排成了「（bm）」。
#let _prev-figure(sel, loc) = {
  let before = query(sel.before(loc)).filter(f => not _original(f))
  if before.len() >= 2 { before.at(-2) } else { none }
}

// 「这一条续的是哪一张」。写了 #continued(<fig:one>) 就按标签找，没写就接紧挨着
// 的前一张——拆图拆表都是把相邻的一张拆成两半。*要在 context 里调*
//
// *认「自己」用位置，不用序号。* 题注排在图*里面*，所以「在我之前」的
// 最后一个必是我自己，倒数第二个才是前一张。先前拿序号剔自己，链上第二段起就认错
// 人——续排要*退计数器*，退过之后号在链上重复（实测第三段的分图号排成
// 「（c）」而不是「（e）」，因为它接到了第一张而不是第二张）。
#let _continued-source(sel, mark) = {
  if mark != none and mark.target != none {
    return _resolve(query(mark.target).first())
  }
  _prev-figure(sel, here())
}

// 链上再往回走一步。cur 自己也是续排时，接的那一张还在更前面。
// *要在 context 里调*
#let _continued-step(sel, cur) = {
  let cap = cur.at("caption", default: none)
  if cap == none { return none }
  let mark = find-continued(cap.body)
  if mark == none { return none }
  if mark.target != none {
    _resolve(query(mark.target).first())
  } else {
    _prev-figure(sel, cur.location())
  }
}

// 这条链的*头一段*——号取的是它的号。
//
// 一张图拆成三段时，第二段接第一段、第三段接第二段，而三段*共用第一段那个
// 号*。只回退一步的话，第三段会去取第二段所在位置的计数器值——那是原始的步进值，
// 没算第二段自己退的那一格，排出来成了「图1-2（续图）」（实测）。
// *要在 context 里调*
#let _continued-head(sel, mark) = {
  let cur = _continued-source(sel, mark)
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    let prev = _continued-step(sel, cur)
    if prev == none { break }
    cur = prev
  }
  cur
}

// 续排页上分图号从第几个接着数。
//
// 范例第 11 页那一页是*带分图题的续图*：上一页排 (a)(b)，这一页排的是
// (c)(d)——同一张图一条号，不从头再来。所以要把*前面各部分*的分图数加起来。
//
// 沿着 #continued() 这条链一路往回走：一张图可能拆成三段四段，每一段都接着上一段。
// *要在 context 里调*
#let _subs-offset(sel, src) = {
  let n = 0
  let cur = src
  // 一张图拆不了多少段，给个上限防呆
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    let body = cur.at("caption", default: none)
    if body == none { break }
    let items = find-subs(body.body)
    if items != none { n += items.len() }
    cur = _continued-step(sel, cur)
  }
  n
}

// term：图与表是词条键（"image" / "table"，名按语言从词条表取）；*自造的 kind 直接
// 传它自己的 supplement*（内容），名就照用户写的印
// first：双语两行里的头一行（线条型伪代码只在头一行上面画顶线）
#let _caption-line(it, lang, term, layout, style, continued: false, by-chapter: true, first: true, source: none, width: auto) = {
  // 附录里名前多一个「附」（附表1-1），判据与理由见 src/blocks/chapter.typ
  let supplement = (
    context _chapter.appendix-prefix(here(), lang, by-chapter: by-chapter)
  ) + (if type(term) == str { _word(lang, term) } else { term })
  // *不编号的图表只剩题名。* 打了 <-> 的那一档 numbering 是 none，
  // 「图」「表」这个名是跟着序号走的（指南：题由*序*与*名*组成），
  // 没有序就不该单挂一个名。
  let numbered = it.numbering != none
  // 编号本身两档共用——同一个计数器，只是前面挂的名不同
  // 续排那一条*不占新号*：Typst 已经替这个 figure 记了一次数，所以显示时
  // 退一格，并把计数器也退回去——否则后面那个真的表会跳号
  let num = if not numbered {
    none
  } else if continued {
    // *续排那一条不占新号*——Typst 已经替这个 figure 记过一次数，退回去，
    // 否则后面那张真图跳号（实测续图之后直接排到「图1-3」）。指南 2.13.2 说的是
    // 「总图题只出现在该页，下页标『图序（续图）』字样」，接的仍是同一个号。
    //
    // 接的是哪一张：写了 #continued(<fig:one>) 就按标签找，没写就接*紧挨着
    // 的前一张*——拆图就是把相邻的一张拆成两半。章号与序号都按*被接的那张*
    // 所在的位置取，不能调 it.numbering 那个闭包：它读的是*排它的那个位置*
    // 的章号，续排页可能已经翻到下一章去了。与表那一条同一套办法，见 _continued-row
    //
    // *自动拆页的续页*（source 给了）是另一回事：那不是一个新 figure，Typst 没替它记数，
    // 不退；号就取传进来的那一张（拆页的这一张自己，或它手工续排的链头），见 _split
    context {
      let sel = figure.where(kind: it.kind)
      // 退计数器的那一句要单独发：写进求 src 的块里会与 figure 元素连成一个 sequence（实测）
      if source == none { it.counter.update(v => v - 1) }
      let src = if source != none { source } else { _continued-head(sel, find-continued(it.body)) }
      if src != none {
        let seq = counter(sel).at(src.location())
        if by-chapter {
          _chapter.chapter-numbered(src.location(), seq)
        } else {
          numbering("1", ..seq)
        }
      }
    }
  } else {
    context it.counter.display(it.numbering)
  }
  let body = if lang == "en" {
    // 英文档里没写 #en 的回落到中文，与标题同一条规则，见 src/engine/marks.typ
    let e = find-en(it.body)
    // 英文名过一遍大小写（花括号也在这儿剥），见 src/engine/case.typ；分图题的
    // 英文行不走这里（_sub-piece 的 body 不在 context 里），先不管
    if e != none { english-title(e, slot: "caption") } else { trim-tail(it.body) }
  } else {
    trim-tail(it.body)
  }
  // 纯西文那一行换西文行盒：与目录里「Abstract」那一条同一个处理，
  // 靠 latin-run 逐 run 换罩不住整行，得把基准本身换掉。
  //
  // *按行上真有什么字判，不按「这是英文题」判。* Word 的行高取该行上
  // *实际用到的*字体里最高的那个，所以在英文题里敲汉字，Word 会把整行按
  // 中易的行盒撑高；先前这里写 lang == "en"，行盒是声明出来的，敲了汉字也纹丝
  // 不动（实测中→英 16.230、英→分图题 15.885 一模一样）。判据与目录那一条
  // 统一成 has-cjk：中易 1.296875 > 西文 1.15、上升部 1.008 > 0.93261，
  // 「行上有汉字就按中易」正是 Word 那条取最大值的规则。
  let latin = lang == "en" and not part.has-cjk(part.plain(body))
  // 线条型伪代码／清单的题注夹在两条线之间，*当三线表的表头行排*：行盒是格子那一档
  // （贴网格、网格开着时单倍，与 caption-rules 的 cell-style 同一份）——Word 贴网格的模型是
  // 一行占一个网格行、文字在格里居中（src/engine/styles.typ 的 _ascent-of）。先前用题注样式
  // 的行盒，倍数多出来的那一截全落在基线之下，字贴着上面那条粗线（实测粗线心→字形顶
  // 2.8、字形底→细线心 9.2）。网格不启用的那几档（报告）没有格可居中，与 Word 的格子一样
  // 多出来的落在下面。西文题注也按格子排：格里的西文行照样占一个网格行（见 cell-style 抬头）
  let ruled = (
    (it.kind == algorithm-kind and resolve-algorithm-style().frame == "ruled")
      or (it.kind == raw and resolve-raw-style().frame == "ruled")
  )
  // 线条型的题注行按表格那一档排（它是表头行）：行距与贴格从表格样式取，字号是题注的
  let ts = _table-style()
  let st = if ruled {
    _cell-style(ts, style.size)
  } else if not latin {
    style
  } else {
    // 纯西文段：西文吃半格增量，直接 set，见 src/engine/styles.typ 的 pure-latin
    style + (font-zh: "latin", font: "serif", snap-to-docgrid: false)
  }
  // *题注在上的粘住下面那一块*（sticky）：表、表格型与线条型伪代码可拆页，Typst 会把
  // 题注留在页底、正文整个挪到下一页（实测题注孤零零在页底、页顶从第一行起）。粘住
  // 之后要断只能断在正文里
  // 线条型：下边垫细线的那一半（三线表格子挨着线那一边的 cell-inset），上边那一半是顶线
  // 那个零高块的高
  block(above: 0pt, below: 0pt, width: 100%, sticky: figure.caption.position == top,
    inset: (bottom: if ruled { ts.stroke.header / 2 } else { 0pt }), {
    show: part.rules.with(st, layout: layout, set-font: true)
    // 题注那一档的西文断字，默认关。见 src/config/settings.typ 的 hyphenate
    show: styles.hyphenate-rules
    // *续表右对齐，续图居中。* 指南两句话分开写的：2.12「表右上角注明编号，
    // 编号后加『（续表）』」——本科范例第 16 页量下来 x 438.17..509.95，右缘顶着
    // 版心右边线 510.24；2.13.2 只说「下页标『图序（续图）』字样」，*没说右上
    // 角*——同一份范例第 11 页那条「图1-1（续图）」量下来 x 260.85..333.84，中线
    // 297.35 正是版心中线，就排在图题的位置上。
    //
    // （表那一条实际不走这里，它由 show table 注进表里；这里留着是因为图与表
    // 共用这个函数，判据写清楚比写死一个 center 好。）
    // 线条型伪代码的题注在两条线之间、*居左*（algorithm2e 的 ruled / algoruled 就是
    // 左对齐的「Algorithm 1: …」）；表格型在表外上方、框图型在框外下方，与表题图题一样居中
    let ruled-algorithm = ruled
    // 自动拆页的自造 kind 也按这两句分：题注在上的续页标注靠右，在下的居中（见 _split）
    set align(if continued and (term == "table" or figure.caption.position == top) { right } else if ruled-algorithm { left } else { center })
    // 关掉正文那条收窄段落宽度的规则：题注居中，不吃字符网格的行末余量
    show par: p => p
    // *Fig. 与 Table 后面那个空格是我们补的。* 范例里它们后面空几格自己
    // 都不一致（博士范例 p14「Table6-1 Data」一个、p15「Table6-1  Data」两个，
    // 图题两处都是「Fig.1-1」不空），指南对英文题一个字没写。统一补一个。
    // 续排那一条只有编号加「（续表）」，*不带题名*——范例与指南都是这样。
    //
    // *末尾要跟一个零宽空格。* 它以全角右括号收尾，而 Typst 会把行末的
    // 全角收尾标点*悬挂*到版心之外——实测右缘冲出 5.99，同一行改成不以
    // 标点收尾就正好落在 510.23。悬挂排中文正文是对的，这里不是：Word 那边
    // 范例第 16 页量到 509.95，在版心里。
    //
    // 试过 box(…)、align(right, box(…))、末尾加 h(0pt) 三种，都还是 +5.99——
    // 悬挂是在文本层做的，包起来拦不住。跟一个零宽空格让标点不再是行末那个
    // 字符，才落回 510.23。
    let head = if numbered {
      supplement + (if lang == "en" { " " }) + num + _separator(layout)
    } else { [] }
    // 线条型伪代码：题注上面那条粗线在这里画——题注在两条线之间，本体只画细线与底线
    // （src/blocks/algorithm.typ 的 _frame）。线宽与三线表的顶线同
    if ruled-algorithm {
      // 顶线只在双语两行的头一行上面画；这个零高块粘住下面的题注文字（不粘的话页底
      // 会剩一条光线，题注到了下一页——实测）
      if first {
        block(width: 100%, above: 0pt, below: 0pt, sticky: true, stroke: (top: ts.stroke.top), height: ts.stroke.top / 2)
      }
      // 题注与本体同一个横向内边距，左缘与输入输出那几行对齐
      h(ts.inset.x)
    }
    if continued {
      // 续排的标注：「（续」加这一种东西的名——图「（续图）」、表「（续表）」（指南 2.12 /
      // 2.13.2 的原话），自造的 kind 与显式写了名的图表照样套（「（续算法）」）；接哪一张
      // 的办法（同 kind 的前一张，或 #continued(<label>) 指名）也不分 kind
      let mark = _continued-mark(lang, if type(term) == str { _word(lang, term) } else { term })
      let line = {
        if numbered { supplement + (if lang == "en" { " " }) + num + _continued-gap(mark) }
        mark
        sym.zws
      }
      // *题注在上的续排标注，右缘落在正文右缘*（width 给了正文的宽）：与续表落在表右上角
      // 一个样子；正文比版心窄时不悬在空白外头。正文整体居中，右缘在 (版心宽 ＋ 正文宽) / 2；
      // 标注在整宽的块里靠右、末尾垫一段 (版心宽 − 正文宽) / 2 的空当，就推到那儿。*不装进
      // 与正文等宽的盒子里*：标注比正文还宽的会在盒子里折行（实测，里面再包一层 box 也折）；
      // 这样排的宽度是整个版心，不折。*正文比标注还窄的（几行短代码）整条居中*，不去对右缘
      // （对了也是往左探出一截，看着像歪的）。量标注的宽要在这个块里的 context 里量：块上
      // 已经 set 过题注的字号，外面那层的字号是哨兵
      if width == auto { line } else {
        context {
          if measure(line).width >= width { align(center, line) } else {
            align(right, line + h((layout.text-width - width) / 2))
          }
        }
      }
    } else {
      // *一行就居中，换行就把编号单独占一格、题名自己两端对齐。*
      //
      // 范例里*一条换行的题注都没有*（本科范例第 14 页那条「表6-1  1 号试样
      // 渗透率测试数据(温度：T=16 ℃，高度：H=5.31 mm)」看着像两行，实际是同一行
      // y 321.60 被抽取器拆成两段，x 130.80–464.36，居中）。指南也只说「居中书写」。
      // 所以这一档*是我们定的*：编号是标签，不是题名的一部分。
      //
      // *用两列 grid，不用 hanging-indent。* 悬挂缩进的做法是把编号留在段落
      // 里，于是它*参与右侧那段的排版*——两端对齐会去拉编号与题名之间那段
      // 空，量出来的缩进也就对不上首行了（实测差 0.57，且随题名长度变）。分成
      // 两格之后，编号那一格是死的，题名那一格自己两端对齐，各行天然对齐，
      // 一个 measure 都不用。
      //
      // *判据仍要量*：内容的自然宽度超过块宽才算换行。一行排得下的题注得
      // 居中，而 grid 是左对齐的整幅块。
      context {
        let whole = head + body
        if measure(whole).width <= layout.text-width {
          whole
        } else {
          grid(columns: (auto, 1fr), align: left, head, par(justify: true, body))
        }
      }
    }
  })
}

// 分图的引用表：标签名 → (落点, 第几个分图)。*文字不在这里排*——图号要按
// by-chapter 算，而那个值*刻意不进 settings-state*（理由见 engine/settings.typ
// 那一段），只有 caption-rules 拿得到。这里只记事实，「图1-1（a）」由 caption-rules
// 里那条 show ref 排。
#let subs-refs = state("iota-subfigure-refs", (:))

// 分图自成一档 kind，好与插图、表分开。计数器就是 Typst 给这一档记的那个，
// 每张母图从头数——重置由 caption-rules 里那条 show figure 发。
#let subfigure-kind = "iota-subfigure"

// Typst 的 layout 函数。各处的参数都叫 layout（那是版面字典），把内建的这个
// 先留个别名，否则在函数体里够不着它。
#let _region = layout

// ── 分图题：两档共用的三件 ────────────────────────────────────────────
//
// 分图题有两种排法（本科指南 2.13.1 的「或」）：排在*分图之下*（subfigure）
// 与排在*图题之下连排*（subs）。选哪一种由*素材*决定——每张分图是独立
// 元素就用前者，一整张图、分图号已经画在图里就只能用后者。
//
// *但排出来必须是同一个样子。* 编号写法、行首处理、两端对齐、双语判据全在
// 这三个函数里，两条路都调它们，格式没有第二个出处。

// 连排时两条分图题之间的分隔：分隔符本身，加*半角标点后那一个半角空当*。
// 与分图号后面那个空当同一条判据——半角补、全角不补（全角标点自带边距）。
// 本科范例印的是「(a) 气体静压轴承; (b) …」，分号后面确实空着一格。
#let _sub-separator(sep, layout) = context {
  sep
  if not part.has-cjk(part.plain(sep)) { _half-gap(layout) }
}

// 一条分图题拆成*编号*与*题名*两截。换行时编号要单独占一格，所以不能
// 先拼起来（见 _sub-block）。
#let _sub-piece(index, body, lang, layout) = (
  head: context {
    let num = numbering(setting-of("subcaption-numbering"), index)
    num
    // *半角编号后空一格，全角不空。* 本科范例印的是「(a) 气体静压轴承」
    // ——右括号之后量到 5.77，而那一页的整字身是 11.1，正好半个字身加字距。
    // 全角那一档不补：「（）」自带边距，补了就是两份。同一条判据也管着引用里
    // 「图1-1 (a)」那个空当，见 caption-rules 的 show ref。
    if not part.has-cjk(part.plain(num)) { _half-gap(layout) }
  },
  // *英文那一行与图题那一行同一个处理*：过一遍大小写、花括号在那儿剥
  // （见 src/engine/case.typ）。先前这一处直接排原文，「{DNA}」的花括号印了出来、
  // title-case 也管不到分图题——图题那一层写着「英文名过一遍大小写」，分图题没有
  // 理由另走一套。要在 context 里调（读开关），measure 那两处钻得进去
  body: {
    let b = title-of(body, lang)
    if lang == "en" { context english-title(b, slot: "caption") } else { b }
  },
)

// 这一组分图题排哪几行。
//
// *要给英文就得全给*，缺一条就整组不排英文行。分图题「可以只用中文书写」
// （指南 2.13.1），双语这一档一处出处都没有，所以宁可不排也不替用户编。
//
// 先前是「缺的那条回落中文」，与图题那一层*自相矛盾*——那边写着「没写 #en
// 就只排中文，不拿中文冒充英文」。而且回落还排出参差：实测 (a) 两行 (b) 一行，
// 把母图题顶下去了。另外两种排法也不成立：编号后面空着、或跳过缺的那条，读着都
// 像排漏了。一行是一行，只能整行要么有要么没有。
#let _sub-langs(bodies) = {
  // *分图题自己一个开关*，不跟图题那一档：规范说分图题「可以只用中文书写」，
  // 双语那句点的是图题与表题，所以默认不排，见 src/config/settings.typ
  let bilingual = resolve-subcaption-bilingual()
  if bilingual and bodies.len() > 0 and bodies.all(b => find-en(b) != none) {
    ("zh", "en")
  } else {
    // *单语那一档跟文档语言*：英文档排的是英文那一行，与图题那一层一致
    // （_caption-line 收的 lang 就是文档语言）。先前一律写死 "zh"，英文档的分图题
    // 虽然*排*出来是对的（题里本来就只有英文，title-of 回落到正文槽），却因此
    // 被当成中文那一行，大小写与花括号都不处理
    (doc-lang.get(),)
  }
}

// 排一组分图题。lines 是已经拼好的每一行。
//
// *行首那个零宽空格是为了居中。* 默认的分图号「（a）」以全角左括号起头，
// Typst 会把行首的全角开括号压掉半个字身，整行的居中就算在压缩后的宽度上——实测
// 题的中线比分图中线偏左 2.49 与 2.61（正是半个五号字身 5.25 的一半）。换成半角
// "(a)" 或裸字母就正好（+0.14 / +0.02），可见压缩是唯一的原因。跟一个零宽空格让
// 括号不再是行首那个字符即可，与 _caption-line 末尾那一个是同一招。
//
// *写满换行时两端对齐、末行居中*：justify 加 align(center) 在 Typst 里正是
// 这个效果，与 hithesis 的 subcapcenterlast 一致。
//
// *双语两行各自居中*，跟图题表题那两行一个样——那是范例上量得到的，没有理由
// 让分图题另走一套。
//
// width 是唯一按位置分的：连排那一行在图题之下，本来就是整幅宽；分图题属于它那张
// 分图，跟着格子走。这不是格式分叉，是位置本身。
// hanging 给了就是「换行时把它悬挂出去」，与图题表题那一条同一个处理（见
// _caption-line）：一行排得下照旧居中，排不下才左对齐、缩到题名首字之下。
// 连排那一档不给——它一行里串着几条题，编号是*穿插*的，没有唯一的那一个
// 可挂。这不是格式分叉，是结构本身，跟块宽那一条同理。
//
// *每一行各自成块*，不是一个段落里用 linebreak 断开：悬挂缩进是按段落算的，
// 两行在同一段里会把英文行的「（a）」也缩进去。各自成块之后基线步进不变——两行
// 都是中易，上块行深 6.355 + 下块上升部 10.666 = 17.021，与段内断行一样。
#let _sub-block(rows, layout, style, width: auto, hang: false) = block(
  above: 0pt, below: 0pt, width: width,
  {
    show: part.rules.with(style + (justify: true), layout: layout, set-font: true)
    show: styles.hyphenate-rules
    set align(center)
    show par: p => p
    for row in rows {
      block(above: 0pt, below: 0pt, if not hang {
        sym.zws + row.head + row.body
      } else {
        _region(size => context {
          let whole = sym.zws + row.head + row.body
          if measure(whole).width <= size.width {
            whole
          } else {
            grid(
              columns: (auto, 1fr), align: left,
              // *两头都要零宽空格。* 编号单独入格之后，「（a）」的左括号是
              // 格里的行首、右括号是行末，Typst 两头都压：左括号压掉半个字身害得
              // 整格左移，右括号压掉半个字身害得它与题名之间少了半格（实测同一条
              // 题不换行时「）」步进 10.50，换行进了格子只剩 5.25）。
              sym.zws + row.head + sym.zws,
              par(justify: true, row.body),
            )
          }
        })
      })
    }
  },
)

// 分图题排在*分图之下*那一档——本科指南 2.13.1 给的两种写法里的另一种
// （连排那一种见下面的 _subs-line 与 src/engine/marks.typ 的 subs）：
//
//   #figure(
//     grid(columns: 2, column-gutter: 1cm,
//       [#subfigure(image("a.png"), caption: [静压]) <sub:static>],
//       [#subfigure(image("b.png"), caption: [动压]) <sub:dynamic>],
//     ),
//     caption: [气体润滑轴承的分类],
//   )
//
// *它返回一个真的 figure 元素*，kind 自成一档。这么做只为一件事：标签能
// *挂在外面*，跟 #figure(…) <fig:x> 一个写法——Typst 的 <label> 只在标记
// 语言里挂得上，所以格子要写成内容块 […]，但标签的位置与别处一致了。
// 先前它返回一个普通的块，标签只能写进题里（caption: [静压 <sub:static>]），
// 与整个 Typst 生态不一致。那个写法*仍然收*，见 caption-rules 的 show ref。
//
// 换来的好处不止写法：编号、引用、题注位置全走 Typst 自己的那一套，我们只在
// 题注那条规则里加一档分支。计数器每张母图从头数，由 caption-rules 那条重置。
//
// *题居中于分图*，这一条*是我们定的*：范例那一档是左对齐段落加手打
// 空格凑的，两格还凑得不一样——博士范例第 11 页那张量下来，分图中线 196.21 与
// 423.56、分图题中线 176.72 与 393.02，差 19.5 与 30.5；左缘也对不上，差 +35.7
// 与 +12.3。既不是居中也不是左对齐，就是排版的人拿空格比划的，没有规矩可依。
// 居中也是他明显想做而没做准的那件事。figure 自己就把题居中在body 上，白得。
//
// *分图与分图题之间取 0*，与图题表题同一个处理（set figure(gap: 0pt)）。
// 范例那张量到分图底缘到分图题基线 15.27 / 15.51（两格一致，这个数是准的），
// 我们排出来是一个上升部 10.67，差 4.6——与母图题那一处的差是同一笔账（图底到
// 图题基线范例 21.03、我们 10.67），一并留到题注对拍那一轮，见文件头的「待校」。
#let subfigure(body, caption: none) = figure(
  body,
  caption: caption,
  kind: subfigure-kind,
  // 分图题只有编号与题名，没有「图」这个名——那是跟着母图的序号走的
  supplement: none,
  // *numbering 这里不给。* 显式写下的字段任何 set 规则都盖不动——先前给了
  // 个 "1" 占位，caption-rules 那条按 subcaption-numbering 设的 set 就永远不生效，
  // 分图题排出来是「1静压」。不写则由那条 set 供给，计数器照样步进。
  // 分图不进图清单
  outlined: false,
)

// 同一张母图下的所有分图。
//
// *双语判据以母图为单位*，所以每一条分图题都得看得见兄弟。分图计数器
// *每张母图重置*（见 caption-rules 那条 show figure），于是「序号回到 1」
// 就是分组的界——往前收到最近一个 1，往后收到下一个 1 为止。
//
// 只用序号与文档顺序，*不比较坐标*：并排的两张分图坐标几乎相同，按位置分组
// 会挑错人。也不依赖「题注排在正文之后」这类假设。
#let _sub-siblings() = {
  let sel = figure.where(kind: subfigure-kind)
  let index-of(f) = counter(sel).at(f.location()).first()
  let group = ()
  for f in query(sel.before(here())).rev() {
    group.push(f)
    if index-of(f) == 1 { break }
  }
  group = group.rev()
  for f in query(sel.after(here())) {
    if index-of(f) == 1 { break }
    group.push(f)
  }
  group
}

// 分图题那一档：只有编号与题名，没有「图」那个名——名是跟着母图的序号走的。
#let _sub-caption(it, layout, style) = context {
  let index = it.counter.get().first()
  // 题里写标签那一档（caption: [静压 <sub:static>]）也收：与连排一致
  let l = part.label-of(it.body)
  if l != none {
    let loc = here()
    subs-refs.update(m => m + ((str(l)): (loc: loc, index: index)))
  }
  let bodies = _sub-siblings()
    .map(f => f.at("caption", default: none))
    .filter(c => c != none)
    .map(c => c.body)
  _sub-block(
    _sub-langs(bodies).map(lang => _sub-piece(index, it.body, lang, layout)),
    layout, style, hang: true,
  )
}

// 分图题连排的那一行（双语时两行），排在图题之下。
//
// 本科指南 2.13.1 原话：「分图号用（a）、（b）等表示，*在图题之下连续排列，
// 用『；』间隔*」；本科范例真印的是半角——居中一行
// 「(a) 气体静压轴承; (b) 气体动压轴承; (c) 气体动静压轴承; (d) 气体压膜轴承」。
// 写法与分隔都可配，见 src/config/settings.typ
//
// *硕博没有这一条*：研究生规范只说「分图题置于分图之下或图题之下，可以只用
// 中文书写，分图号用 a)、b) 等表示」，既没说连排也没说分隔符。没有规定就跟着本科
// 那份走，不另立一套。
//
// *一律不撑开、不对齐*：范例那一行是普通的居中文本，编号落在哪儿全看前面的
// 题名多长。要编号成列对齐的是范例的*另一种写法*（分图题排在分图之下、左对
// 齐、中间手打空格），靠的是分图自己的列位置，跟连排不是一回事——见 examples/。
//
// 编号、行首、对齐、双语判据都在 _sub-piece / _sub-langs / _sub-block 里，与分图
// 之下那一档*共用*——两种排法是分工，不是两种口味，排出来必须一个样。
#let _subs-line(items, layout, style, start: 0) = context {
  // *引用登记。* 用户写在项里的标签（#subs([静压 <fig:static>], …)，或是
  // 挂在 #en[…] 后面的 <1>）捞出来，连同排好的引用文字与落点记进一张表，
  // 由 caption-rules 里那条 show ref 取用。
  //
  // *不另挂一份标签。* 先前的做法是埋一个带同名标签的记号，结果与用户那个
  // 撞车——写成 [动压 <fig:dyn>] 时标签本来就跟着题名排在版面上，再挂一份就是
  // 「label occurs multiple times」（双语回落还会让同一个标签排两遍）。改成记
  // *落点*（here()），引用直接 link 到位置，标签有几份都不碍事。
  //
  let entries = items
    .enumerate()
    .map(((i, body)) => {
      let l = part.label-of(body)
      if l == none { none } else { (str(l), (loc: here(), index: start + i + 1)) }
    })
    .filter(e => e != none)
  let anchors = if entries.len() == 0 { none } else {
    subs-refs.update(m => m + entries.to-dict())
  }
  let langs = _sub-langs(items)
  anchors
  // 连排那一行整条是一格：编号穿插在题名之间，没有唯一的那一个可挂
  _sub-block(
    langs.map(lang => (
      head: [],
      body: items
        .enumerate()
        .map(((i, body)) => {
          let p = _sub-piece(start + i + 1, body, lang, layout)
          p.head + p.body
        })
        .join(_sub-separator(setting-of("subcaption-separator"), layout)),
    )),
    layout, style, width: 100%,
  )
}

// Typst 自己的默认值。*用来分辨「用户显式写的」与「没写」*——fields()
// 两者都给得出来，只有拿默认值比对能分开。见 show table 那一段。
// Typst 没被碰过时 inset 的样子。stroke 那一档比不了相等，判结构，见 show table
#let _typst-default-inset = 0% + 5pt

// 重造过的表自带这个记号，见下面 show table 那一段的说明
#let _built-mark = metadata((iota-table-built: true))

#let _built(c) = {
  if type(c) != content { return false }
  if c.func() == metadata {
    return type(c.value) == dictionary and "iota-table-built" in c.value
  }
  if c.has("children") {
    for k in c.children { if _built(k) { return true } }
  }
  if c.has("body") { return _built(c.body) }
  false
}

// 注入到表头里的那一格：起始页什么也不排，续排的页上排「表N-N（续表）」。
//
// 找「这是哪个表」的办法与页眉找「这是哪一章」同一套：查出全部表，取起始页
// 不晚于本页的最后一个。用 <= 而不是 <——本页起的表也算。
#let _continued-row(metrics, top-rule, by-chapter) = context {
  let page-now = here().page()
  // *这一行属于哪张表：按文档顺序取「在我之前最后起排的」那一张。*
  //
  // 注进去的这一行看不见外面的 figure，只能自己找。先前按页码判，两个方向各
  // 错一次：收「≤ 本页」时，续排页上又起了新表就取到新表、判成起始页，标注丢
  // 掉；收「< 本页」时，跨页表*之后*的任何一张表都会取到那张跨页表，白多
  // 一条标注。页码分不开同页的先后，位置分得开——这一行在自己那张表里面，
  // 所以在它之前起排的最后一个 figure 必是自家的。
  let me = here().position()
  let owners = query(figure.where(kind: table)).filter(g => {
    let at = g.location().position()
    at.page < me.page or (at.page == me.page and at.y <= me.y)
  })
  if owners.len() == 0 { return }
  let f = owners.last()
  // 起始页不排——那一页有正经的表题。手工拆表的后半是例外：它本页起排，
  // 而题里写着 #continued()，那正是「这一张是上一张的续」的意思
  let mark = find-continued(f.caption.body)
  if f.location().page() == page-now and mark == none { return }
  if f.numbering == none { return }
  let lang = doc-lang.get()
  // 接的是哪一张表的号。
  //
  // *跨页接排*：f 就是那张表本身，直接取它的号。
  //
  // *手工拆表*：f 是后半那个 figure，Typst 已经替它记过一次数，于是
  //   一、号要取*它接的那一张*——写了 #continued(<tab:one>) 就按标签找，
  //       没写就接紧挨着的前一张（拆表就是把相邻的一张拆成两半）；
  //   二、计数器要退回去，否则后面那个真表跳号（指南 2.12：续表不占新号）。
  let src = if mark == none {
    f
  } else if mark.target != none {
    query(mark.target).first()
  } else {
    let before = query(figure.where(kind: table)).filter(
      g => g.location().position().page < f.location().position().page
        or (g.location().position().page == f.location().position().page
            and g.location().position().y < f.location().position().y),
    )
    if before.len() == 0 { return }
    before.last()
  }
  // *只在那张表*起排*的那一页退。* 这一行住在表头里，表头每页重排一次，
  // 这个 context 就每页跑一次（文件里别处也记着「实测重复出来的表头里 context 会
  // 按页重算」）——不加这一条，手工拆开的后半张表跨几页就退几格：实测续表占两页时
  // 它后面那张表印成「表1-1」与第一张*重号*（不报错、不告警），表再长
  // （60 行起）直接 error: number must be at least zero 加 did not converge。
  if mark != none and f.location().page() == page-now {
    counter(figure.where(kind: table)).update(v => v - 1)
  }
  // *章号要按「被接的那张表」所在的位置取。* figure 的编号闭包里写的是
  // counter(heading).get()——读的是*排它的那个位置*的章号。正常题注就在
  // 图表旁边，没差；续排标注可能排到下一章去（长表跨章），那时 get() 读到的是
  // 下一章的号，排出来就成了「表6-1（续表）」。所以这里不调那个闭包，自己按
  // src 的位置取章号与序号。
  let seq = counter(figure.where(kind: table)).at(src.location())
  let num = if by-chapter {
    _chapter.chapter-numbered(src.location(), seq)
  } else {
    numbering("1", ..seq)
  }
  // *上面那点空当由行盒自己出。* 这一格的内边距是清零的（起始页那一格是空的，
  // 留着会白占一行高），先前用 v(半个行间) 补出来；格里改成贴网格之后，行盒本身就是
  // 一个网格行、字面在里面居中，那半个行间已经在盒子里，再补就多一份。
  //
  // *标注不参与列宽计算。* 它注在一格 colspan 满行的单元格里，照直排的话
  // 内容宽度会挤进列宽——而 Typst 把多出来的宽度*全给最后一列*，于是表被
  // 单侧撑开，各列的文字虽然各自居中，整张表看着就歪了（实测两列小表：第一列
  // 21.3、第二列 47.8）。
  //
  // *标注不参与列宽计算。* 主表的列宽由数据定，续表那一行不该把它撑开
  // ——同一张表在起始页和续排页会宽窄不一，看着就不是一张表了。
  //
  // 所以套一个零宽盒子（外层宽 0 不给列提最低要求），里面按实测宽度定宽，再自己
  // 挪到位。内层必须定宽：外层可用宽度是 0，不定宽文字会被压得逐字换行（实测
  // 「表」「1-1」「（续」「表）」各占一行）。
  //
  // *放得下贴右缘，放不下居中*。
  //
  // *Typst 的对齐按盒子里*内容*的宽度算，不是按声明的 0*——所以整表
  // 那条 align: center 已经把内容摆在格子中央了（内容心 ＝ 格心）。于是：
  //
  //   w > 格宽   dx = 0              已经居中，两边各溢出一半，比一头长出去好看
  //   w ≤ 格宽   dx = (格宽 − w)/2   往右推半个空当，右缘落到表的右缘上
  //                                 （指南 2.12「表右上角注明编号」）
  //
  // 合起来就是 max(0, (格宽 − w)/2)。
  //
  // 试过两条别的路：塞进一格 colspan 让它照直占宽，Typst 把多出来的宽度全给最后
  // 一列，表被单侧撑开（两列小表 21.3 / 47.8）；改成每列各摊一份 w/n 撑得是匀了，
  // 可主表并没有这回事，同一张表两页宽窄不同。width: 100% 更不行——自动列里那种
  // 百分比按整个版心算，第一列被撑到 90.45。
  // 这张表显式写了名（figure(table, supplement: [清单])）就照它，标注用光的「（续）」，
  // 与题注那一支同一条（见 _given-supplement）
  let given = _given-supplement(src.fields(), table, doc-lang.get())
  let mark-text = {
    let name = if given != auto { given } else { _word(lang, "table") }
    let mark = _continued-mark(lang, name)
    name + (if lang == "en" { " " }) + num + _continued-gap(mark)
    mark
    sym.zws
  }
  context {
    let w = measure(mark-text).width
    layout(size => box(width: 0pt, move(
      dx: calc.max(0pt, (size.width - w) / 2),
      box(width: w, mark-text),
    )))
  }
  // 下面那半条线（Typst 把线画在格边界正中，Word 的线整条在表里）由这一格的
  // 内边距垫，见 show table 里的 mark-cell——先前这儿 v(半条线)，与内边距是同一份，
  // 两处都留就多一半
}

// 「用户自己写过 show figure.caption: set text(size: …) 吗」那个哨兵。
//
// *题注的字号是规范定死的*（五号，两份指南的图题表题那几节），所以挡住
// 原生那条路——可*挡住就必须出声*，静默不生效是最难查的一种。
//
// 难在分不出「用户设过」：text.size 没有 auto 那样的哨兵，用户写 12pt 时读回来
// 的 12 与正文的 12 一模一样（实测），比值比不出来。所以*自己往样式链上
// 插一个没人会写的字号*：文档级先把题注设成它，用户那条 show 规则定义在我们
// 之后（#show: iota-hit 把整份文档裹在里面）会把它盖掉——读回来不是它，就说明
// 有人设过。与 figure.numbering 那个闭包哨兵同一个路子。
//
// *印不出来*：下面那条 show figure.caption 把题注整个重排，字号从
// styles.figure.caption 现取。
#let _size-sentinel = 0.31415pt

// 接到题注上。用法：show: caption-rules.with(body-metrics: …, spacing: …)
//
// *版面不在装规则时捕获。* 题注的行盒、三线表的行高与内边距、题注换不换行的
// 版心宽，都在各条 show 规则自己的 context 里按当前这一节的版面现算（layout.current-layout）
// ——段级改了行跨度、版心，题注与表跟着换。只有一处例外：图块表块的三段空当那
// 几条是 show figure: set block(above:, below:) 与 set figure(gap:)，show-set 的值给
// 不了 context——试过把它写进 show figure 的闭包里再 set，那会压过后定义的分图那条
// set block(0pt)（实测），所以它们按 iota-hit 传进来的文档级那一份，见下面 spacing。
// 图、表、伪代码的题注（分图题那一档不走这里，见 _sub-caption）。it 是题注元素——
// show figure.caption 里的 it，或从 figure 元素上取的 f.caption（query 出来的 figure
// 上题注的 kind / counter / numbering / supplement 都已补齐，实测）。
//
// source 与 pieces 只有*自动拆页*的图用（见 _split）：source 是这一页要标「（续图）」时
// 取号的那张 figure，pieces 是落在这一页上的分图是第几到第几
// 题注排出来在上在下的记号（metadata 可定位）：续排的那张按它接的那张取，见 caption-rules 里
// 那条 show figure。先前记在 state 里、按 figure 的落点读——读到的是它*前一张*的（show 规则
// 里发在 it 之前的更新，落点反而在 it 之后，实测）；记号在题注里，落点必在 figure 之后
#let _position-mark(pos) = metadata((iota-caption-position: pos))
// 正文有多宽（自造 kind 与 raw），发在 figure 前面，给题注在上的续排标注定右缘（见 _caption）。
// 量的时候给版心宽：写着 width: 100% 的（codly、zebraw 这些代码包都是）才解得出，不给量到 0
// （实测）；比版心宽的钉到版心宽
#let _width-mark(body, layout) = metadata((
  iota-body-width: calc.min(measure(body, width: layout.text-width).width, layout.text-width),
))
#let _position-of(f) = {
  let m = query(selector(metadata).after(f.location())).find(m => (
    type(m.value) == dictionary and "iota-caption-position" in m.value
  ))
  if m == none { none } else { m.value.iota-caption-position }
}

#let _caption(it, layout, style, by-chapter, source: none, pieces: none) = {
  _position-mark(figure.caption.position)
  // *号与名之间那一格走原生的 separator*（见 _separator）：先前我们不读它、
  // 写了一声不响什么都不发生，所以当场拦下；现在读了，拦截撤掉。默认仍是指南
  // 定死的那一档——号与名之间空 2 个半角字符（本科指南 2.12/2.13，两份范例印
  // 出来也是），见 src/config/settings.typ 的 caption-separator-auto。
  let kind = it.kind
  let lang = doc-lang.get()
  // 自造的 kind 传它自己的 supplement，见 _caption-line 抬头；图表上显式写的也照它
  // （题注元素的 fields() 里带着图表的 supplement，判法见 _given-supplement）
  let given = _given-supplement(it.fields(), kind, lang)
  let k = _kinds.find(k => k.kind == kind)
  let term = if given != auto { given } else if k != none { k.term } else { it.supplement }
  let manual = find-continued(it.body) != none
  let continued = manual or source != none
  if continued and kind == table {
    // *续表那一条不由题注排*——它在表的右上角，是表的一部分，由 show table
    // 注进表里（见 _continued-row）。搁在题注里的话块宽是版心，右对齐就贴到版心
    // 边上（实测 441.10…510.23，而表自己只到 332.20），而指南 2.12 说的是「表右
    // 上角注明编号」。
  } else if continued {
    // *续图由题注排*，排在图题的位置、居中——图不像表，它没有「表格」这个
    // 容器可以往里注，指南也只说「下页标『图序（续图）』字样」。范例第 11 页量到
    // 中线 297.35，正是版心中线。
    //
    // *题注在上的（自造 kind、raw）标注靠右到正文右缘*：正文的宽由 figure 那条规则量好、
    // 记在 figure 前面的记号里（_width-mark），这里取「我之前最后一个」——题注在上、排在
    // 正文之前，最后一个记号就是自家的。*不在这儿量*：题注规则的样式链上字号是哨兵
    // （_size-sentinel），measure 按它量，一段代码量出来 1.6pt（实测）
    let width = if figure.caption.position != top { auto } else {
      let m = query(selector(metadata).before(here())).rev().find(m => (
        type(m.value) == dictionary and "iota-body-width" in m.value
      ))
      if m == none { auto } else { m.value.iota-body-width }
    }
    _caption-line(it, lang, term, layout, style, continued: true, by-chapter: by-chapter, source: source, width: width)
  } else if lang == "en" {
    // 英文档只出英文那一份
    _caption-line(it, "en", term, layout, style, continued: continued)
  } else {
    _caption-line(it, "zh", term, layout, style, continued: continued)
    // 双语：中文在上、英文在下。*没写 #en 就只排中文*——不拿中文
    // 冒充英文题。开关见 src/config/settings.typ
    //
    // 续排那一条不排双语：它只是个「接着上一页」的标注，不是题
    let bilingual = resolve-caption-bilingual(
      degree-level: info-get().degree-level, stage: info-get().stage,
    )
    if not continued and bilingual and find-en(it.body) != none {
      _caption-line(it, "en", term, layout, style, first: false)
    }
  }
  // 分图题连排在图题之下
  // *续图上照排分图题，而且接着数。* 范例第 11 页那一页正是带分图题的续图
  // ——上一页排 (a)(b)，这一页排 (c)(d)，同一张图一条号。先前这里挡着 continued，
  // 于是续图上根本写不了 #subs。
  //
  // 续表不排：表没有分图这一说。
  let subs = find-subs(it.body)
  if subs != none and not (continued and kind == table) {
    let start = if not manual { 0 } else {
      let sel = figure.where(kind: image)
      let src = _continued-source(sel, find-continued(it.body))
      if src == none { 0 } else { _subs-offset(sel, src) }
    }
    // *自动拆页的图只排落在这一页上的分图题*（pieces 给了这一页的分图是第几到第几）：
    // 范例第 11 页正是这样——上一页 (a)(b)，续图那一页 (c)(d)，号接着数。见 _split
    let (subs, start) = if pieces == none { (subs, start) } else {
      (subs.slice(pieces.from, pieces.to), start + pieces.from)
    }
    // 图题与分图题之间由用户插点什么（默认什么都不插，范例就是紧挨着的）：
    // 就地 #subs(gap: …) 压过文档级 subcaption-gap，见 src/config/settings.typ
    if subs.len() > 0 {
      resolve-subcaption-gap(local: find-subs-gap(it.body))
      _subs-line(subs, layout, style, start: start)
    }
  }
}

// ── 自动拆页的图与框图型伪代码 ─────────────────────────────────────
//
// 图默认整块不拆（Typst 的 figure 就是这样），*但拆得开*：指南 2.13.2 先说「插图与其
// 图题为一个整体，不得拆开排写于两页」，接着写「有分图时，分图过多在一页内安排不下时，
// 可转到下页，总图题只出现在该页，下页标『图序（续图）』字样」——总图题跟着头一页，
// 后面每一页末尾一条「图1-1（续图）」。用户写 show figure.where(kind: image): set
// block(breakable: true) 就走这一条；框图型伪代码当图处理，algorithm-style.breakable:
// true 同一个排法（「算法1-1（续算法）」）。表不走这里，续表注在表右上角（_continued-row）。
//
// *排法*：正文与题注装进一个单列 grid，题注放 grid.footer（每页重排一次、里面的
// context 按页重算，与表头那一格同一个实测结论）——头一页排整条题注，续页排续图
// 标注；figure 自己那一条题注不要了（这里不调 it，figure 元素照样在、照样记数、照样
// 引用，只是版面由我们出）。题注排在 footer 里而不是判「这是末页」：footer 每页等高，
// 末页判不判都不改版面，判了反而要靠题注落在哪一页，而那又取决于 footer 高不高——
// 一个循环。
//
// *分图题跟着分图走*：body 里每一张 image 前面埋一个记号（metadata 可定位、不占位），
// 这一页有哪几张就排哪几条分图题、号接着数（范例第 11 页正是上一页 (a)(b)、续图页
// (c)(d)）。记号数与 #subs 的条数对不上（图里另有图例、一张分图两张图）就退成整条
// 分图题跟总图题排在头一页。分图题写在分图之下那一档（#subfigure）天然跟着分图，不用管。
//
// *不重造 figure*：show figure 里再造一个同 kind 的 figure，原来那个仍然可查、仍然记数
// （实测两张图印成 Figure 2 / Figure 4）。这里返回的是一个块，不是 figure。
//
// 浮动的（placement 给了）不拆——浮动块本来就不能断页，原样交回
#let _piece = metadata((iota-piece: true))
#let _split(it, layout, style, by-chapter, gap, size, position) = {
  let sel = figure.where(kind: it.kind)
  // figure 元素自己就在手上（show 规则的 it 带位置，题注的 kind / counter / numbering 已补齐），
  // 不去 query 找「我之前最后一张」
  let f = it
  // 续页的标注：手工续排的那张取它接的链头，与题注那一条同一个办法；*没写 #continued 的
  // 就是它自己*——_continued-head 收 none 时按「接紧挨着的前一张」找，拿到的是前一张
  // （实测 algorithmic 那张的续页印成了前一张的号）
  let mark-of(pieces) = {
    let chain = find-continued(f.caption.body)
    let src = if chain == none { f } else { _continued-head(sel, chain) }
    _caption(
      f.caption, layout, style, by-chapter, source: if src == none { f } else { src },
      pieces: pieces,
    )
  }
  // *题注在上*：续表那一套——题注排在头一页上方（这里不调 it，题注得自己发；粘住下面的
  // 正文，与 _caption-line 里题注在上那一档同），往 grid.header 里注一格，续页右上角
  // 「名N-N（续名）」（指南 2.12「表右上角注明编号，编号后加（续表）」的样子，自造的
  // kind 套同一条）；起排页那一格空着、零高
  if position == top {
    let head = grid.cell(inset: 0pt, { set text(size: size); context {
      if here().page() != f.location().page() { mark-of((from: 0, to: 0)) }
    } })
    return block(width: 100%, breakable: true, {
      set text(size: size)
      context _caption(f.caption, layout, style, by-chapter)
      v(gap)
      // 裹一层零间距的块：不裹的话正文那一块自己的 above（raw 的块距）落在题注与正文之间，
      // 比 figure 自己排的多出一截（实测 39.6 对 20.0）；figure 里正文也是裹在块里的
      //
      // grid 整版心宽；续页标注的右缘落在正文右缘（与续表落在表右上角同）那一步在
      // _caption-line 里做——它读 figure 前面的 _width-mark，靠右之后垫一段空当推过去。
      // *不把 grid 收成正文那么宽*：标注比正文宽的（几行短代码）在窄格子里会折行（实测）
      block(above: 0pt, below: 0pt, width: 100%,
        grid(columns: 1fr, align: center, grid.header(repeat: true, head), it.body))
    })
  }
  // 字号按正文那一档，与 show figure.caption 那条同（理由见那里）
  let tail = grid.cell(inset: (top: gap, rest: 0pt), { set text(size: size); context {
    let start = f.location().page()
    // 这一页上落了哪几张分图：记号按文档序数，截到下一张同 kind 的 figure 为止
    let subs = find-subs(f.caption.body)
    let pieces = if subs == none { none } else {
      let mine = query(selector(metadata.where(value: _piece.value)).after(f.location()))
      let nxt = query(sel.after(f.location(), inclusive: false))
      let mine = if nxt.len() == 0 { mine } else {
        let stop = nxt.first().location().position()
        mine.filter(m => {
          let at = m.location().position()
          at.page < stop.page or (at.page == stop.page and at.y < stop.y)
        })
      }
      if mine.len() != subs.len() { none } else {
        let here-page = here().page()
        let on = mine.enumerate().filter(((i, m)) => m.location().page() == here-page).map(((i, m)) => i)
        if on.len() == 0 { (from: 0, to: 0) } else { (from: on.first(), to: on.last() + 1) }
      }
    }
    if here().page() == start {
      _caption(f.caption, layout, style, by-chapter, pieces: pieces)
    } else {
      // 分图对不上页时（pieces 为 none）整条分图题已经跟总图题排在头一页，续页给空区间
      mark-of(if pieces == none { (from: 0, to: 0) } else { pieces })
    }
  } })
  block(width: 100%, breakable: true, {
    show image: img => _piece + img
    grid(columns: 1fr, align: center, it.body, grid.footer(repeat: true, tail))
  })
}

#let caption-rules(
  body-metrics: none,
  // 题注那一档。iota-hit 从样式表（styles.figure.caption）传进来，见 src/config/styles.typ
  style: default-styles.figure.caption,
  // 编号按不按章。true 排「图1-1」并在章标题处重置计数器，false 全文连续
  // 排「图1」不重置。由 iota-hit 解出来传进来，见 src/config/settings.typ
  by-chapter: true,
  // 公式那一档按不按章。*这里只有 show ref 用得着*——全项目只能有一条
  // show ref 生效（同一选择器后定义的赢），而那一条在这儿，所以公式的引用也得
  // 由它排，编号串与按不按章都要送进来。往后若再多一类要重建，这条规则就该
  // 单独搬出去成一个部件。
  equation-by-chapter: true,
  // 表头占几行。三线表的第二条线画在它下面
  header-rows: 1,
  // 图块表块的三段空当，已经解成数：(image: (above:, gap:, below:), table: (同),
  // 都是数)。由 iota-hit 按 styles.figure 算好传进来（auto 的解法
  // 在那儿），见 src/config/styles.typ 的 _figure
  spacing: (
    image: (above: 0pt, gap: 0pt, below: 0pt),
    table: (above: 0pt, gap: 0pt, below: 0pt),
    line: 0pt,
  ),
  doc,
) = {
  // 自动拆页（见 _split）。*定义在所有 show figure 之前*：Typst 后定义的规则先跑，这一条
  // 返回的不是 figure，排在它前面跑的规则才轮得到（编号的守门、网格取整那条 show image）
  //
  // *按题注在上在下分两路，不按 kind*：题注在下的（图、框图型伪代码、用户自造的 kind）走
  // 续图那一套——题注跟头一页、续页末尾「名N-N（续名）」；题注在上的（自造 kind 与 raw 写了
  // set figure.caption(position: top) 的）走续表那一套——题注照排在头一页上方、续页右上角
  // 「名N-N（续名）」。表自己有表头可注（_continued-row）、表格型伪代码的标注在 lovelace 的
  // title 里、线条型不标注（用户定的），这三档不走这里
  show figure: it => context {
    let split = if it.kind == table {
      false
    } else if it.kind == algorithm-kind {
      resolve-algorithm-style().frame == "boxed" and block.breakable
    } else if it.kind == raw and resolve-raw-style().frame == "ruled" {
      // 代码清单线条型：不画线不标注、接着排（与伪代码线条型同，用户定的）
      false
    } else { block.breakable }
    if not split or it.placement != none { return it }
    _split(it, _layout.current-layout(), style, by-chapter, it.gap, body-metrics.size, figure.caption.position)
  }
  // *续排的那张题注在上在下跟着它接的那张*，自己写了才用自己的（与 supplement 同一条：自己
  // 当下给了就用自己的，没给就用前面的）。「自己写了」＝ 写在题注元素上：caption:
  // figure.caption(position: top)[…]，fields() 里才有 position；set 出来的值（不管文档级还是
  // 就地套一层）与出厂默认分不开，一律当没写——文档级的 set 接的那张也吃到了，跟它就是跟
  // set。图与表的位置锁死、伪代码按框定，都不走这条。接的那张排在哪，读它题注里的记号
  // （_position-of）。*定义在拆页那条之后*：后定义的先跑，拆页那条按题注位置分两路，要读到
  // 这里 set 过的值
  show figure: it => context {
    let cap = it.at("caption", default: none)
    let mark = if cap == none or it.kind in (image, table, algorithm-kind) { none } else if (
      it.kind == raw and resolve-raw-style().frame != none
    ) { none } else {
      find-continued(cap.body)
    }
    let inherited = if mark == none or "position" in cap.fields() { none } else {
      let src = _continued-source(figure.where(kind: it.kind), mark)
      if src == none { none } else { _position-of(src) }
    }
    // 正文的宽顺手记下（自造 kind 与 raw；图表与伪代码用不着）
    let width = if it.kind in (image, table, algorithm-kind) { none } else {
      _width-mark(it.body, _layout.current-layout())
    }
    if inherited == none { width + it } else {
      set figure.caption(position: inherited)
      width + it
    }
  }

  // *单元格是单倍行距，不是题注那一档的 1.25。* 六张三线表（本科范例三张、
  // 博士范例三张）的单元格段落一个 w:line 都没写，也就是单倍。
  //
  // *而且对齐到文档网格：格里*每一行*都占一个网格行。* 那六张表的单元格
  // 段落也一个 snapToGrid 都没写——Word 的默认就是对齐，所以格内折行与整行同待遇。
  // 逐条量过（本科范例表6-1，那一节的网格是 383 ＝ 19.15）：数据行之间 19.08–19.20，
  // 表头那一格自己折的三行（「流量修正值」／「M (m³/s)」／「×10⁻⁴」）也是 19.08、
  // 19.20，与数据行一模一样。
  //
  // *西文行不例外。* 那三行里第二行「M (m³/s) lgΔP lg M」通篇没有汉字，照样
  // 是一个网格行。中文档里「纯西文段走自然行高」那一条（src/blocks/body.typ 的
  // show par）不适用于格里——那一条的出处（英文摘要、英文题注、英文版表格）在范例里
  // 每一处都写着 snapToGrid=0 或非单倍行距，是段落上的显式设定，不是 Word 按脚本判的。
  // 自造探针核实过：拿范例 d-stem.docx 本身追加一页（同一节、同一份 Normal），Word
  // 导出实测正文汉字 19.44/19.68、正文纯西文 19.44/19.68、格内汉字 19.68、格内纯西文
  // 19.68、混排 19.68——都是一个网格行。
  //
  // *范例里 19.15 那个数不跟*：它是那一节的 w:docGrid linePitch=383，两份范例
  // 各十一节里只有放这张表的那一节是 383，其余 391（19.55）。要跟的是「每行一个
  // 网格行」这条规矩，落到我们的网格上就是 19.55。
  //
  // *行距按网格开关分两档。* 贴网格那一档设*单倍*——范例那几格的
  // pPr 里一个 w:line 都没写，走 Normal 的单倍，再由网格撑成一个网格行；倍数
  // 在贴网格时乘的是*网格行*（写 1.25 排出来是 24.44，不是 19.55）。
  //
  // *网格不启用的那一档就差在这儿*：深圳本科那两份报告的 docGrid 没有
  // w:type、单元格还显式写着 <w:snapToGrid w:val="0"/>，没有网格行可贴，行盒
  // 只能按行距算——原件那几格写的正是 <w:spacing w:line="300"/> ＝ 1.25 倍，
  // 与题注那一档同数，所以跟着 style 走（用户改 styles.figure.caption 也一并跟上）。
  // 写死单倍的话那一档会塌成 13.62。
  //
  // *以上是标定的记录；数现在住在 styles.figure.table（src/config/styles.typ 的 _table）*：
  // 单倍贴格是那一档的默认，网格不启用的那几档在 variant-styles 里写 1.25。排格子时读
  // 当前那一份（_table-style），文档级 iota-hit(styles:) 与局部 #show: styles.with(…) 都改得动
  // *纵向内边距只有线的那一半，而且只在挨着线的那一边。* 贴网格之后行盒自己就是
  // 一个网格行、自然行盒在里面居中（见 src/engine/styles.typ 的 _ascent-of），垫的活儿
  // 都在行盒里；剩下的是 *Word 的线占自己的厚度*：格子的内容框从线的内沿起排，
  // Typst 把线画在格子边界的正中——所以挨着线的那一边各垫半条线，不挨线的边是 0。
  // 三条线各自算：顶线垫在首行的上边、表头线垫在表头行的下边与首个数据行的上边、
  // 底线垫在末行的下边；顶线与底线探出表外的那一半由 pad 补（见下面 built）。
  //
  // 两份 Word 排的表都对得上：
  //
  //   本科范例 p15（贴网格 383 ＝ 19.15，线 1.5 / 1 / 1.5）：表题基线 → 顶线心 7.22
  //   ＝ 五号 1.25 倍的行深 6.44 ＋ 0.75；三行的表头 58.80 ＝ 0.75 ＋ 3 × 19.15 ＋ 0.5；
  //   末行基线 → 底线心 6.44 ＝ 格内居中的下半 5.80 ＋ 0.75（p16）
  //   深圳本科中期表 2-1（不贴网格，三条都 1.5）：表头线心 → 首行基线 12.96
  //   ＝ 0.75 ＋ 上升部 12.1；末行基线 → 底线心 8.16 ＝ 行深 7.35 ＋ 0.75
  //
  // 先前上边 +半条、下边 −半条，行高不变、线心落在内容框顶上：一张表比 Word 矮
  // 「三条线之和」（2.5～3pt），后面的标题跟着高。
  //
  // *用户写的 inset 也当 Word 的边距收*（元素上的 table(inset:)、或 show table: set
  // table(inset:)）：他抄的是表格属性对话框上的数，从线内沿量，挨线的半条线照补。先前
  // 原样用，比 Word 少半条线
  // 边距收长度或字典；fields() 里用户写的 (x: 1cm) 已被 Typst 摊成 left / right / top / bottom
  // （实测），这几种拼法都认。*左右一份、上下一份*：Word 的边距就这两栏
  let cell-inset(margin, strokes, off, header-rows, last) = {
    let side(keys) = if type(margin) == length { margin } else {
      let hit = keys.find(k => k in margin)
      if hit == none { margin.at("rest", default: 0pt) } else { margin.at(hit) }
    }
    let mx = side(("x", "left", "right"))
    let my = side(("y", "top", "bottom"))
    (x, y) => (
      x: mx,
      top: my + (if y == off { strokes.top / 2 }
        else if header-rows > 0 and y == off + header-rows { strokes.header / 2 }
        else { 0pt }),
      bottom: my + (if off <= y and y < off + header-rows { strokes.header / 2 }
        else if y == last { strokes.bottom / 2 }
        else { 0pt }),
    )
  }

  // 表题在表上，图题在下（Typst 默认就是下）
  show figure.where(kind: table): set figure.caption(position: top)

  // *伪代码：body 是 algorithm[…] 造的，把这张 figure 重造成 kind "algorithm"。*
  // Typst 的 figure 只按 body 认三种 kind（table、raw、其余一律 image），第四种它
  // 没留钩子，用户又不该写 kind——#figure(algorithm[…]) 该与 #figure(table(…)) 一个
  // 形状。所以认 body 末尾那个记号（src/engine/marks.typ 的 algorithm-mark），重造：
  // 字段原样搬，*标签不搬*——被 show 规则换掉的元素仍在文档里（query 查得到、
  // 标签还在它身上），再挂一次就是「label occurs multiple times」。于是 @alg:x 找到的
  // 是那张 kind 还是 image 的原件，引用、续排接的那一张都要换成重造的那一张：
  // 紧跟在原件之后的第一张 algorithm 就是它，见 _resolve。这是全项目第二处重造用户
  // 的元素，第一处是三线表（下面 show table）。重造出来的 kind 已是 algorithm，不再命中。
  //
  // *题注在上在下按 algorithm-style.frame 定*：tabular / ruled 在上，boxed 在框外下方——
  // 与图同。就在这里 set，重造的那张 figure 在这个 set 之下实现。
  // 显式写的 supplement（figure(algorithm[…], supplement: [过程])）原样搬，没写的
  // 给词条的「算法」——Typst 造自造 kind 的 figure 时就要 supplement，下面那句
  // show-set 够不到这里造的这一张（实测报 please specify the figure's supplement）
  show figure: it => {
    if it.kind != image or find-algorithm(it.body) == none { return it }
    context {
      let st = resolve-algorithm-style()
      set figure.caption(position: if st.frame == "boxed" { bottom } else { top })
      let f = it.fields()
      let given = _given-supplement(f, image, doc-lang.get())
      // 原件已经把图的计数器步进了一格，退回去（理由见 _original）
      counter(figure.where(kind: image)).update(v => v - 1)
      let rebuilt = figure(
        it.body,
        kind: algorithm-kind,
        caption: if f.at("caption", default: none) == none { none } else { it.caption.body },
        placement: f.at("placement", default: none),
        outlined: f.at("outlined", default: true),
        supplement: if given != auto { given } else { _word(doc-lang.get(), "algorithm") },
      )
      rebuilt
    }
  }
  // *跨不跨页走原生的 show figure.where(kind: "algorithm"): set block(breakable:)*，与表、
  // 代码同一条：默认拆（三档都拆，用户定的），用户那句 show-set 在内层、压得过这条。先前
  // 住在 algorithm-style 里，理由是「默认值随框变、show-set 给不了 context」——三档都拆之后
  // 这个理由没了，一个口子也就省了
  show figure.where(kind: algorithm-kind): set block(breakable: true)
  // 代码同理：Word 里代码就是段落，段落自然可拆
  show figure.where(kind: raw): set block(breakable: true)
  // 伪代码与代码清单的题注与本体之间那份 gap 在 lib.typ 里 show-set（表格型、线条型 0，
  // 框图型走图那一份）——*写在 show 规则里的 set figure(gap:) 不生效*：gap 是 figure 造好
  // 时就填进字段的（实测里面 set 成 20pt 一动不动），只有 show-set 到得了，而 show-set
  // 的值给不了 context，框哪一档只能在入口按参数解
  // ── 代码清单（进了 figure 的代码块）────────────────────────────
  // 题注位置随框定（与伪代码同）、题注与本体之间的 gap 也同；本体（框、行号）由
  // src/blocks/listing.typ 排，那条 show raw 挂在 lib.typ（listing-rules）。「在不在清单里」
  // 由这条规则记进 state（src/engine/marks.typ 的 in-listing），raw 在 figure 里面，读到的
  // 就是这张的
  show figure.where(kind: raw): it => context {
    let frame = resolve-raw-style().frame
    in-listing.update(true)
    if frame == none { it } else {
      set figure.caption(position: if frame == "boxed" { bottom } else { top })
      it
    }
    in-listing.update(false)
  }

  // 字号那个哨兵，见 _size-sentinel。*要定义在下面那条 show figure.caption
  // 之前*——那样它在样式链上比处理函数外一层，处理函数才读得到
  show figure.caption: set text(size: _size-sentinel)

  // *表可以跨页，图不行。* 指南 2.13.2：「插图与其图题为一个整体，不得
  // 拆开排写于两页」；2.12：「一般情况下插表不能拆开两页编排，*如某表在
  // 一页内安排不下时，才可转页*」。Typst 的 figure 默认整块不可断——实测长表
  // 不但不跨页，还会整个溢出版心（底线落在 773.9，版心底是 756.84）。
  show figure.where(kind: table): set block(breakable: true)

  // 题与图/表之间。*这一截是 Word 自己加的，不是谁手敲的*——图在 Word 里是
  // 坐在一条文字基线上的*内联对象*，图底就是那一行的基线，所以图下面自动
  // 带着那一段的*行深*（行距倍数 × 自然行高 − 上升部），再加它自己的段后。
  //
  //   终稿那一档   装图段跟 Normal（小四宋体 1.25 倍）  行深 7.275，段后 0
  //   深圳本科中文报告  同上                            行深 7.275，段后 0
  //   深圳本科英文报告  Figure 样式（12pt Times 1.5 倍） 行深 9.463，段后 3
  //
  // 值由 iota-hit 按 styles.figure.image 算好传进来（见 src/config/styles.typ 的
  // _figure 与 variant-styles 的 figure），*模板里不必再手写一个 gap*；单张图
  // 要不一样，原生 #figure(gap: …) 压得过这条 set。*自造的 kind 跟图*——
  // 算法、代码块在 Word 里同样是段落里的东西，与图同一个待遇；只有表另算。
  //
  // *先前这儿写死 0*，理由是「规范没规定这一项」——规范确实没写，可 Word 排
  // 出来那一截是有出处的，就是上面这个式子。
  //
  // *网格开着时这一截是 0*：那时装图的那一行占整数个网格行、图在里面居中（见下面
  // 那条 show），多倍行距多出来的那一截已经在取整的余量里，再加就重了——探针实测
  // 图底到图题基线只有题注自己的上升部加余量的一半（2026-09-15，两种网格各五档图高）。
  // 由 iota-hit 解 auto 时按网格开没开给 0 或 (倍数 − 1) × 自然行高
  set figure(gap: spacing.image.gap)
  // *表那一头是另一件事*：表题在*上*，这一段空当是题注那一段的*段后*
  // ——中英四份原件的表题段后都是 0（英文那份的 -tab 样式明写着 w:after="0"），
  // 表就紧贴在题注下面。装图段那一份（多倍行距多出来的一截）与它无关
  show figure.where(kind: table): set figure(gap: spacing.table.gap)

  // *网格开着时，装图的那一段占整数个网格行，图在这几行里垂直居中。*
  //
  // 拿探针 docx 量的（图高 20…110 十档，docGrid linesAndChars linePitch=391，
  // 正文 1.25 倍）：基准行基线 → 图题基线的步进正好是*一个网格行*（19.44／
  // 19.68 交替，均值 19.56 ＝ 391 缇）；而「图下方余量 − 图上方余量」十档*恒等于
  // 8.2*——余量本身随图高从 7.3 变到 19.1，两头的差却不动，只有把图*居中*摆
  // 在那几行里才会这样。
  //
  // *行数就是 ⌈图高 ÷ 网格行距⌉*，图高之外*什么都不加*。先前写的是「加那一行自己的
  // 整个行高」（¶ 那一行，小四 1.25 倍 19.45），2026-09-15 两种网格（论文 391、报告 312）
  // 各排六档图高重量：40 / 52 / 64 / 70 / 77.65 / 85 / 100 在 391 上占 3 / 3 / 4 / 4 / — /
  // 5 行、在 312 上占 3 / 4 / 5 / 5 / 5 / 6 / 7 行，逐档都是 ⌈图高 ÷ 行距⌉；加整行的话
  // 52 在 391 上成 4 行、64 在 312 上成 6 行，加 ¶ 在基线下那一截（6.56）也会把 77.65
  // 在 312 上推成 6 行（Word 5 行，77.65 ÷ 15.6 ＝ 4.98）。图在这几行里居中：图上方余量
  // 与下方余量逐档相等（图底到图题基线 ＝ 余量 ＋ 题注自己的上升部，多倍行距那一截
  // 不另加，见上面 gap 那一条）。
  //
  // *表不吃这一条*——表在 Word 里不是段落里的内联对象。
  show figure: it => context {
    let g = _layout.current-layout().docgrid
    if not g.grid or g.line-pitch == 0pt or it.kind == table { return it }
    show image: img => context {
      let h = measure(img).height
      let rows = calc.max(1, calc.ceil(h / g.line-pitch))
      block(height: rows * g.line-pitch, align(horizon, img))
    }
    it
  }

  // 图表上下与正文*空一行*——指南 2.12 明写「插表的上下与文中文字间需空一
  // 行编排」；2.13 图那边只说「留一定位置」，但本科范例量下来分图题到下一段正文
  // 39.28 ≈ 2 × 19.55，也是空了一行。
  //
  // *范例的表上方只有 0.2 行，不跟。* 两份范例的表题段落都写着
  // beforeLines=20（0.2 行 ＝ 3.83），实测正文末行 299.60 → 表题 321.60 ＝ 22.00，
  // 与模型「行深 7.275 + 上升部 10.66 + 段前 3.83 ＝ 21.77」对得上。但那是排版的
  // 人手敲的直接格式，styles.xml 里没有题注样式，而指南明写空一行——判据次序见
  // src/config/styles.typ 的题注那一档（default-styles.figure.caption）那一段。
  //
  // *页首不发。* Typst 的块间距在页首本来就丢——实测把它设成 0 与默认排出来
  // 逐点相同，不用另外处理。
  // *图与表各一对数*（iota-hit 按 styles.figure.image / .table 解好传进来，auto
  // ＝ 空一行）：原件里这两头本来就不同——英文中期那份表题之上 2.4、表之下 0、
  // 图之上 0、图题之下 3。*自造的 kind 跟图*，表那条压过它（同一属性上后定义
  // 的赢）。单个图表要不一样走原生：#block(above: …, below: …, figure(…))——块间距
  // 折叠取大者，裹一层就把这一张的两头换掉了（实测 40pt / 2pt 逐点对上，别的图不动）。
  //
  // *摆在分图那条之前*——分图的 0 要压过这两条，见下面
  show figure: set block(above: spacing.image.above, below: spacing.image.below)
  show figure.where(kind: table): set block(above: spacing.table.above, below: spacing.table.below)

  // 编号「1-1」：章号从 counter(heading) 取。
  //
  // *是 set，不是 show figure: set。* 先前写成后者，为的是拿到 context；
  // 闭包里自己写一句 context 就够了，而摆在 show 规则里有两处坏处：一是用户写
  // #set figure(numbering: "1") 盖不过我们（show 里的 set 更内层），二是我们
  // *读不到*用户写了什么——样式链上还是原生默认的 "1"，与用户写的一模一样。
  //
  // 挪到文档级之后这一份就成了*哨兵*：样式链上的值不再是 "1" 而是这个闭包，
  // 用户一改就比得出来（闭包在 Typst 里比得了身份，实测同一个闭包 == 为真、
  // 另一个长得一样的为假）。下面那条 show heading 的重置也改成认这个哨兵。
  let by-chapter-numbering = (..n) => context {
    _chapter.chapter-numbered(here(), n.pos())
  }
  set figure(numbering: if by-chapter { by-chapter-numbering } else { "1" })

  // *图表编号按章重置。* 指南 2.12 / 2.13：「图序按章编排，如第 1 章第一个
  // 插图的图号为『图1-1』」。连续编号那一档不重置——重置了第 2 章的图会变回
  // 「图1」跟第 1 章撞号，所以这两件事必须绑在一起。
  //
  // *绑法是认哨兵，不是认开关。* 判据取当前生效的 figure.numbering 是不是
  // 我们那个闭包：用户写 #set figure(numbering: …) 换掉编号时，重置跟着停，
  // 两半一起让开，不会留下「编号连续但每章从头数」那种半吊子。
  //
  // *全文出现过的每一种 kind 都重置*，不只图与表：自造的 kind（算法）与 Typst 自带的
  // raw（代码）各有各的计数器，先前只重置图表那两个，第二章的算法印成「算法2-2」。
  // 哪几种 kind 从全文的 figure 里数出来（分图那一种也在里面，重置它无害）
  show heading.where(level: 1): it => context {
    if figure.numbering == by-chapter-numbering {
      for k in query(figure).map(f => f.kind).dedup() {
        counter(figure.where(kind: k)).update(0)
      }
    }
    it
  }
  // *这条 set 会盖掉「打上 <-> 就不编号」，所以 nonumber-rules 必须排在
  // caption-rules 之后*——Typst 里同一属性上后定义的 show 规则压过先定义的。
  // 顺序写在 lib.typ 那一处，实测顺序反了打了 <-> 的图照样排出「图1-2」。

  // *原生的 set figure(supplement:) 我们不读，也拦不住。* 题注、引用、清单三处
  // 的字样默认从词条表取（见 _word），用户写 set figure(supplement: [插图]) 一声不响
  // 不生效——本该拦下，可*拦不出来*：在 show figure 里读 it.supplement 或
  // figure.supplement，拿到的都是 *Typst 自己的出厂默认*（英文档下是 [Figure]、
  // 中文档下是 [图]），我们那句 set 在这一层看不见，用户写没写分不出来。试过把守门
  // 定义在那句 set 之前（后跑）也一样。所以只在 README 里写明：改字样走
  // overrides: (caption-image: […])。哪天上游能读到最终值，这条就补上。
  // *单张图表上显式写的 figure(supplement:) 认*，判法见 _given-supplement。
  //
  // *自造的 kind 不在此列*：figure(kind: "algo", supplement: [算法]) 那一档 Typst 逼着
  // 用户写 supplement，而下面那句 set 只落在图与表上，读到的就是用户写的——题注与
  // 引用都照它印（先前一律印「图」，错的）。清单只有图表公式三张，自造的不进

  // supplement 跟文档语言：中文档「图」「表」，英文档 Fig. / Table。
  // 它同时管引用——@fig:x 排的就是 supplement + 编号
  for k in _kinds {
    show figure.where(kind: k.kind): set figure(
      supplement: _word(doc-lang.get(), k.term),
    )
  }

  // 分图号*每张母图从头数*。重置发在母图之前，分图在母图*里面*，
  // 次序天然对。分图自己进来时不重置——那会把自己刚数的那一下抹掉。
  show figure: it => context {
    // *顺带把「用户改了编号」拦下来。* 图表编号按章是指南 2.12 / 2.13 写死
    // 的，改成别的排出来就不合格；而它由两半合成（编号串 + 逐章重置），用户只
    // 盖得住前一半，剩下的是「编号连续但每章从头数」这种半吊子。所以不放行，
    // 当场报错指到我们的开关上——那条开关是给对拍件与短样张用的知情逃生口。
    //
    // *判据认哨兵。* 上面那句 set 把样式链上的值换成了我们的闭包；none 要
    // 放过，那是打了 <-> 的图（见 src/engine/marks.typ），不是用户在改编号。
    if by-chapter and figure.numbering != none and (
      figure.numbering != by-chapter-numbering
    ) and it.kind != subfigure-kind {
      panic(
        "figure numbering has no effect (the template numbers figures by "
          + "chapter; write iota-hit(caption-numbering-by-chapter: false) "
          + "for continuous numbering)",
      )
    }
    // *题注在上在下是规范定死的*：指南 2.12「表的名称置于表的上方」、
    // 2.13.1「图题置于图的下方」。原生那句 set figure.caption(position:) 压得过
    // 我们（实测把表题拧到了表下面），所以当场拦下——这一条没有商量余地。
    // *只管图与表*：自造的 kind 与 raw 规范没提，在上在下随用户
    let want = if it.kind == table { top } else { bottom }
    if it.kind in (table, image) and figure.caption.position != want {
      panic(
        "figure.caption position is fixed by the guidelines (table captions go "
          + "above the table, figure captions below the figure); remove the "
          + "set figure.caption(position: ...)",
      )
    }
    // 图默认不拆页（Typst 的 figure 本来就是整块）；用户 show figure: set block(breakable:
    // true) 之后按指南 2.13.2 的续图排——那一条在 _split，定义在最前面、最后才轮到它
    // 续图*不重置*：它是同一张图的后半，分图号接着上一页数（范例第 11 页
    // 排的是 (c)(d) 而不是从 (a) 重来）
    let cap = it.at("caption", default: none)
    let continued = cap != none and find-continued(cap.body) != none
    if it.kind != subfigure-kind and not continued {
      counter(figure.where(kind: subfigure-kind)).update(0)
    }
    it
  }

  // 分图号的写法跟 subcaption-numbering 走。写成闭包是因为 setting-of 要
  // 上下文，而 numbering 那个函数是排的时候才调的，那会儿有。
  show figure.where(kind: subfigure-kind): set figure(
    numbering: (..n) => context numbering(setting-of("subcaption-numbering"), ..n.pos()),
  )

  // *下面这些只管真正的图与表。* 分图是嵌在母图里的另一档 kind，
  // 上下空一行、按章编号、题在下方这些都不该落到它头上。
  show figure.where(kind: subfigure-kind): set block(above: 0pt, below: 0pt)

  // *分图的引用。* @sub:static 排成「图1-1（a）」，点得动，落到那张分图
  // （或分图题那一行）。分图不是 figure，Typst 自己的 ref 认不得它。
  //
  // 落点与序号由 subfigure / _subs-line 记在 subs-refs 里，*文字在这里排*：
  // 图号要按 by-chapter 算，而那个值只有这里拿得到（理由见 engine/settings.typ）。
  // 算法与上面 set figure(numbering:) 那一处是同一套，只是取值改成按落点取。
  //
  // 图号与分图号之间那个不断行的半角空格*只在半角那一档补*：本科范例正文引
  // 的是「图1-1 (a)」（run 拆出来是「图」+「1-1 (a)」），hithesis 的 \p@subfigure
  // 定成 \thefigure~ 也是这个；全角那一档不补，「（」自带边距，补了排出来是
  // 「图1-1 （a）」。*指南对怎么引用分图一个字没写*，这是范例上量的。
  //
  // 数的是*插图*那个计数器：指南说的是「图中若有分图」，表没有这一说。
  // 不是分图的引用原样放行，交给 Typst。
  show ref: it => context {
    // 两条路都收：标签挂在 subfigure 外面（那是个真 figure，Typst 认得，
    // 序号从它自己的计数器上取），或写在题里（连排那一档只能这么写，
    // 落点与序号由 _subs-line / 分图题那条规则记在 subs-refs 里）
    let found = query(it.target)
    let native = if found.len() == 0 { none } else {
      let f = found.first()
      if f.func() == figure and f.at("kind", default: none) == subfigure-kind {
        (
          loc: f.location(),
          index: counter(figure.where(kind: subfigure-kind)).at(f.location()).first(),
        )
      }
    }
    let e = if native != none { native } else {
      subs-refs.final().at(str(it.target), default: none)
    }
    if e == none {
      _plain-ref(it, by-chapter, equation-by-chapter)
    } else {
      let n = counter(figure.where(kind: image)).at(e.loc)
      // 母图的名同样带「附」（附图1-1（a）），见 src/blocks/chapter.typ
      let parent = (
        _chapter.appendix-prefix(e.loc, doc-lang.get(), by-chapter: by-chapter)
      ) + _word(doc-lang.get(), "image") + (
        if not by-chapter {
          numbering("1", ..n)
        } else {
          _chapter.chapter-numbered(e.loc, n)
        }
      )
      let num = numbering(setting-of("subcaption-numbering"), e.index)
      let gap = if part.has-cjk(part.plain(num)) { [] } else { sym.space.nobreak }
      link(e.loc, parent + gap + num)
    }
  }

  // *把相邻的几个记号并成一组*，名只印一遍。学 omni-gb7714 那条
  // show regex(_M + "(?s:.+?)" + _M + "(…_M…_M)*")。重复部分是 *，所以*单个
  // 引用也走这里*——不必另写一支。
  show regex(
    _RM + "(?s:.+?)" + _RM + "(?:" + _RSEP + _RM + "(?s:.+?)" + _RM + ")*",
  ): m => context _ref-group(m.text, by-chapter, equation-by-chapter)

  // 分图题走另一档，*不能用 figure.caption.where(kind:) 选*——实测那个选择器
  // 匹配不上，分图题会掉进下面通用那一支排成「图1  静压」。只能在这里分派。
  show figure.caption: it => context {
    // *挡住原生那条路，并且出声*：题注由下面那个两列 grid 排（编号一列、
    // 题名一列，好让折行悬挂对齐），外面套的 set text 够不着里面，写了会一声
    // 不响什么都不发生。判据见 _size-sentinel
    if text.size != _size-sentinel {
      panic(
        "figure captions ignore `show figure.caption: set text(...)` (the "
          + "template lays the caption out itself; write "
          + "iota-hit(styles: (figure: (caption: (size: ...)))) to change it)",
      )
    }
    let layout = _layout.current-layout()
    // *哨兵到此为止*：这一格里还要发别的内容（比如 subcaption-gap 写的
    // enter(1)），它们按 text.size 算高——哨兵漏进去，那个空段就成了 0.36 高
    // （实测 0.40，该是 13.8）。
    //
    // *往下按正文那一档的字号*，不按题注自己的：这一处原本读到的就是外面
    // 正文的字号（哨兵没插进来之前），enter(1) 因此是一个正文行（小四 13.8）。
    // 按题注的五号算是 12.10，那是另一件事，不趁这次改
    set text(size: body-metrics.size)
    if it.kind == subfigure-kind {
      _sub-caption(it, layout, style)
    } else {
      _caption(it, layout, style, by-chapter)
    }
  }

  // 三线表，外加*续排那一页自动补上「（续表）」*。
  //
  // 顶线与表头线走 stroke 闭包；*底线是追加在末尾的 table.hline*——那个闭包只对
  // 真实存在的格子调用（y 取 0..行数−1），拿不到总行数，实测让它对 y == 行数
  // 返回线宽什么也不画；不带 y 的 hline 落在它所在的位置，摆在最后一格之后就是
  // 表底，长表跨页也只出现在末页。*先前是在表外面包一个 block 画下边*：块在流里
  // 取版心宽，表比版心宽（深圳本科英文中期原件那张表列宽加起来 15.11cm，版心
  // 15.0cm）时底线就比顶线短一截。表头下那条画成*表头行的下边*而不是首个数据行的
  // 上边：跨页时 Typst 重复 table.header，重复出来的那份 y 仍是 0，画上边线跟
  // 得上；而首个数据行留在前一页，画它的上边线在续页就没了（实测续页只有顶线
  // 与底线，缺那条 0.5）。
  //
  // *比版心宽的表居中*，照 Word：表单里那张表 w:jc="center"，排出来两边各探出
  // 1.5（83.52–511.68 对版心 85.05–510.23）；Typst 把超宽的块顶在左边、全探到右边。
  // 用负的左右 pad 把容器撑到表那么宽，表就落在正中。列宽有 auto／fr 的表撑不
  // 过版心，量出来不比版心宽，这一支不走。
  //
  // *「（续表）」这一行是往 table.header 里注入的。* 指南 2.12 要求转页时
  // 「表右上角注明编号，编号后加『（续表）』，并重复表头」——重复表头 Typst 自己
  // 会做，那一行标注它没有钩子。办法是插一格跨列、右对齐、无边线的内容，里面
  // 放一个 context：*实测重复出来的表头里 context 会按页重算*（同一个探针
  // 在第 1/2/3 页分别报 1/2/3），所以它能自己判断「这一页不是表的起始页」。
  //
  // *这是全项目唯一一处重造用户的元素。* 别处的 show 规则都只设属性。
  // 重造要防递归：新建的 table 会再次命中这条规则，而内层写一条 identity 的
  // show 规则*拦不住*（实测 maximum show rule depth exceeded）。改成让它
  // *自识别*——注入的那一格里埋一个 metadata，再进来看见就原样放行。
  //
  // *用户显式写的 stroke / inset 要留住。* 重建把它们一并丢弃过——实测
  // 写了 inset 也毫无效果。fields() 分不出「用户写的」与「没写」，只能拿 Typst
  // 的默认值比对：没人会去显式写一个与默认一模一样的值。
  //
  // *stroke 不能用相等比。* 实测默认那一个与 1pt + black *既不 ==
  // 也不 repr 相同*，虽然打印出来一模一样。能分的是结构：没被碰过的 stroke，
  // thickness 与 paint 都是 auto；用户写 0.4pt 的那个 thickness 就是 0.4pt。
  show table: it => context {
    if _built(it) { return it }
    let layout = _layout.current-layout()
    // 格里的字号读样式链：lib.typ 那句 show table: set text(size:) 给的默认（表格样式的
    // 五号），用户就地 show table: set text(size: …) 压过它。字体同理，这里不 set
    let ts = _table-style()
    let cell = _cell-style(ts, text.size)
    let strokes = ts.stroke
    let m = part.resolve(cell, layout: layout)
    let f = it.fields()
    let kids = f.remove("children")
    // fields() 给的是「显式值或 Typst 默认值」，不含 set 规则的值——实测重建后
    // inset 回到 5pt（Typst 的默认）而不是我们 set 的 1.11，..f 展开时会盖过
    // 下面的 set。所以这两项先摘出来，判过是不是默认再决定用谁的。
    let raw-stroke = f.remove("stroke", default: none)
    let raw-inset = f.remove("inset", default: none)
    let raw-align = f.remove("align", default: auto)
    let stroke-untouched = (
      type(raw-stroke) == stroke
        and raw-stroke.thickness == auto
        and raw-stroke.paint == auto
    )
    // 边距三处来源：元素上写的、show table: set table(inset:) 写的（读样式链）、表格样式
    // 里的，前面的压后面的，都当 Word 的边距
    let inset-untouched = raw-inset == _typst-default-inset
    let margin = if not inset-untouched { raw-inset }
      else if table.inset != _typst-default-inset { table.inset }
      else { ts.inset }
    // *不写 columns 的表列数是 1。* 那个字段*总是在*，没写时是空数组
    // ——default: 1 永远走不到，空数组的 len() 是 0，注入格 colspan: 0 当场报
    // 「number must be positive」，而 #table([甲], [乙]) 在 Typst 原生是合法的单列表
    let cols = f.at("columns", default: 1)
    let n = if type(cols) == int { calc.max(cols, 1) } else if type(cols) == array {
      calc.max(cols.len(), 1)
    } else { 1 }
    let has-header = kids.any(k => k.func() == table.header)
    // 注入的那一格。*记号要在 context 外面*——_built 走的是 children /
    // body，钻不进 context 元素里，塞进去就自识别不出来，当场无限递归。
    // *内边距要清零*：起始页那一格是空的，留着内边距会让它照样占一行高
    // ——实测同一份长表从 2 页涨到 4 页，起始页表头上方还多出一道空隙。
    // 续排页要的那点间距由内容自己发（见 _continued-row 的 v()）。
    // *下边垫顶线的那一半*：顶线画在这一格与首行的边界正中，Word 里线整条在表里、
    // 标注段落的底就是线的上沿（本科范例 p16：标注基线 → 顶线心 6.52 ＝ 网格行里
    // 居中的下半 5.80 ＋ 0.75）。起始页这一格是空的，垫的这半条就是顶线探出表外的那一半
    let mark-cell = table.cell(
      colspan: n, stroke: none, inset: (bottom: strokes.top / 2, rest: 0pt),
      _built-mark + _continued-row(
        m, strokes.top, by-chapter,
      ),
    )
    // *没写 table.header 的表也注入一个*，里面只装那一格。两个理由：
    //
    // 一、指南 2.12 说转页时「表右上角注明编号，编号后加『（续表）』，并重复表
    // 头」——前半句*不以有没有表头为条件*，没有表头的长表转页照样要标。
    //
    // 二、这是*递归的出口*。重建出来的表靠注入格里的 _built-mark 自识别，
    // 先前没有表头就什么都不注入，重建出来的表再次命中这条规则——*一张不带
    // table.header 的表根本编译不了*（maximum show rule depth exceeded）。
    let kids = if not has-header {
      (table.header(mark-cell), ..kids)
    } else {
      kids.map(k => if k.func() != table.header { k } else {
        // *repeat 与 level 要一起搬过去。* 只搬 children 的话
        // table.header(repeat: false) 被静默丢掉——实测 60 行的长表跨三页，
        // 写了 repeat: false 表头照样每页重复。别处（figure.caption.separator、
        // figure.numbering）遇到没法兑现的写法是当场 panic，这一处不该一声不响
        table.header(
          mark-cell, ..k.fields().children,
          repeat: k.at("repeat", default: true),
          level: k.at("level", default: 1),
        )
      })
    }
    // 注入那一行占了 y == 0，三条线的位置整体后移一格
    let off = 1
    // *注入那一行也得给个高*，不然它跟着吃用户写的 rows:——`rows: 100pt`
    // 的表在表头之上凭空多出 100pt（实测题注基线到顶线 106.35，该是 6.35；
    // `rows: 30pt` 那份是 36.36）。
    //
    // track 的写法是「给的不够就重复最后一个」（实测 rows: (0pt, 30pt) 排五行
    // 得 0/30/30/30/30），所以在前面补*一格*就正好，后面几行照旧。
    //
    // *补的那一格写 auto，不写 0pt。* 它两页上的高本来就该不同：首页那一格是空的，
    // auto 给的就是 0（`rows: 100pt` 那个毛病不会回来，实测题注到表头 21.5）；续页
    // 标注一印，auto 给的是标注的自然高。先前写死 0pt，续页那一页整个错位——标注
    // 与表头只差 0.7（该差 21.0，字叠在一起）、顶线被顶到版心顶 107.75（该在 128.05），
    // 与页眉那条双线（97.72／100.72）之间只剩 7pt，看着就是表框贴着页眉。
    //
    // *没写 rows 时 fields() 交回的是空数组，不是 auto*（实测；写了
    // rows: 30pt 交回的也已经是数组 (30pt,)）。空的就别动——那一档整张表本来就是
    // 每行按内容自然高，注入的那一格也一样，补不补一个 auto 都一样
    let f = {
      let rs = f.at("rows", default: ())
      if type(rs) != array or rs.len() == 0 { f } else { f + (rows: (auto, ..rs)) }
    }
    // 表头线只有*真有表头*时才画：注入的那一格不是表头，它下面没有线
    let header-rows = if has-header { header-rows } else { 0 }
    // *末行是第几行*：底线那半条垫在它的下边。行数 ＝ 各格占的格位（colspan × rowspan）
    // 之和除以列数——表排得满时正好整除；线、注入的那一格不算
    let slots(k) = if k.func() == table.cell {
      k.at("colspan", default: 1) * k.at("rowspan", default: 1)
    } else if k.func() == table.header {
      k.fields().children.filter(c => c != mark-cell).map(slots).sum(default: 0)
    } else if k.func() in (table.hline, table.vline) { 0 } else { 1 }
    let last = off + calc.ceil(kids.map(slots).sum(default: 0) / n) - 1
    let inset = cell-inset(margin, strokes, off, header-rows, last)
    // 底线只在*我们自己画三线*时才补。用户给了 stroke 就整表听他的，
    // 再补一条会在表底多出一根线
    let kids = if stroke-untouched { kids + (table.hline(stroke: strokes.bottom),) } else { kids }
    let built = {
      // *字号、行盒与内边距都要在这里设。* 重建出来的表是新元素，外面那两条
      // show table: set … 规则罩不到它——实测重建后字号回到正文的 12、内边距回到
      // Typst 默认的 5pt，行步进涨到 29.45，长表页数翻倍。
      //
      // *罩的是 part.rules 而不是只设字号*：行高得按模型的行盒来，只设字号
      // 的话走 Typst 自己的字体度量（实测五号内容盒 9.07，模型是 13.617），
      // 上面按 m.box 算出来的居中内边距就白算了。
      show: part.rules.with(cell, layout: layout)
      set table(
        // *单元格内容居中。* 范例那几张表的数据格段落都写着
        // <w:jc w:val="center"/>——同一格里「供气压力」起笔 93.30、「Ps (MPa)」
        // 95.05，两行不齐正是居中的痕迹。Typst 默认靠左，续表标注把列撑宽之后
        // 尤其显眼（文字缩在左边，表框却伸到右边）。用户自己写了 align 就听他的。
        align: if raw-align == auto { center } else { raw-align },
        inset: inset,
        stroke: if not stroke-untouched { raw-stroke } else { (x, y) => (
          top: if y == off { strokes.top } else { none },
          bottom: if off <= y and y < header-rows + off { strokes.header } else { none },
        ) },
      )
      table(..f, ..kids)
    }
    // *底线探出表外的那一半*：Typst 把线画在表的下边界正中，Word 的线整条都在表里，
    // 底线的下沿才是下一段的起点（顶线的那一半垫在注入的那一格里，见 mark-cell）。
    // 只在我们自己画三线时垫；用户给了 stroke 就不知道线多粗
    let built = if stroke-untouched { pad(bottom: strokes.bottom / 2, built) } else { built }
    // 比版心宽就居中（见抬头）；量的是重建出来的整张表
    let over = measure(built).width - layout.text-width
    if over > 0.05pt { pad(x: -over / 2, built) } else { built }
  }

  doc
}
