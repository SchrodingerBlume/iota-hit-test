// 组名段：成果页「一、发表的学术论文」那一种，合并页 nomenclature 的小标题（left 档）
// 也用它。照 Word 范例排——宋体小四加粗、顶格、段前段后 5 磅、1.25 倍行距、不贴网格
// （docx pPr：spacing before=100 after=100 line=300 auto，snapToGrid=0，run 带 <w:b/>）。
//
// *不写 #strong，也不写样式里的 bold: true。* strong 走正文那条 tracking-pad
// （src/engine/tracking.typ），段首会多垫一份字距——实测组名落在 85.50，范例 85.03；
// 样式里的 bold 那条路（styles.shows 的描边包装）紧挨着 omni 的条目表时会把条目末尾
// 的汉字多画一遍。这里照 styles 那一层的做法自己发：字重加粗，宋体没有粗体面就描边，
// 判据与 #strong 同一个（synth.wants-bold-for）。
#import "./paragraph.typ": paragraph
#import "../engine/synth.typ" as _synth

#let group-heading(body, layout) = paragraph(
  context {
    let b = text(weight: "bold", body)
    if _synth.wants-bold-for("songti") { _synth.fake-bold(b) } else { b }
  },
  (
    snap-to-docgrid: false, line-spacing: 1.25,
    first-line-indent: (chars: 0), above: 5pt, below: 5pt,
  ),
  layout: layout,
)
