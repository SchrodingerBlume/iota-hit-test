// 封面上那一小把楷体字怎么排。
//
// *楷体在这个包里有两类用处，回落的路子不一样。*
//
//   用户写的 #kaishu[…]、正文里的强调  —— *无限集*，只能靠字体
//   封面上的校名与校区         —— *有限集*，可以直接画轮廓
//
// 有限集这一档非画不可，不是「没字体时的退路」：webapp 那一档的楷体是台湾教育部
// 标准楷书，*只有繁体字形*，于是 is-hant-only 触发转字，封面校名排成了
// 「哈爾濱工業大學」——实测如此，那在封面上是错的。轮廓取的是中易楷体 SimKai，
// 与全套标定同源，简体、字形正确。
//
// 三层回落：
//
//   楷体这条路通       —— 家族在、且不是只有繁体的那一款  → 真楷体
//   不通，字全在收录里 —— 见 kaishu-outline-chars          → SimKai 轮廓
//   不通，字超出收录   —— 家族在（webapp 的教育部楷体）    → 用它，认了转繁
//                        家族也不在                        → 伪斜宋体
#import "../engine/fonts.typ"
#import "./kaishu-outline.typ": kaishu-outline, kaishu-outline-chars
#import "../engine/content.typ": plain

// 探针：一个家族能不能排汉字。
//
// *关掉回落再量*——缺字时 Typst 会静默换字体，量出来照样有宽度，问不出
// 「这个家族在不在」。关掉之后缺字宽度是 0（实测装了的 KaiTi / SimSun 出 200pt，
// 没装的 TW-MOE-Std-Kai 出 0pt）。
//
// *代价*：家族真的不存在时 Typst 会打一条 unknown font family 的警告，
// 这个探测会把它提前引出来——今天只有排到那一处才出现，往后每篇都会出现一次。
#let _family-usable(family) = {
  measure(text(font: family, fallback: false, size: 100pt)[一二]).width > 0pt
}

// 楷体这条路通不通。要在 context 里调
#let usable() = {
  let family = fonts.current.get().families.kaishu
  not fonts.is-hant-only(family) and _family-usable(family)
}

// 封面上的一段楷体字。要在 context 里调
#let cover-kaishu(body) = {
  if usable() { return body }
  let s = plain(body)
  if s.clusters().all(c => c in kaishu-outline-chars) {
    // *把字体换成宋体再画*。轮廓自己带一层透明真文本（保证 PDF 可复制可
    // 搜索），而那一层会继承外面的楷体——webapp 那一档的楷体只有繁体字形，
    // 转字规则照样把它转了，于是画面是简体、复制出来是繁体（实测）。
    // 那一层是透明的，用什么字体不影响观感，换成宋体就不再触发转字。
    return {
      set text(font: fonts.current.get().families.songti)
      kaishu-outline(body)
    }
  }
  // 超出收录：webapp 那一档还有教育部楷体可用，认了转繁；再没有就伪斜宋体
  let family = fonts.current.get().families.kaishu
  if _family-usable(family) { body } else { text(style: "oblique", body) }
}
