// 代码清单：进了 figure 的代码块。
//
//     #figure(```python
//     x = 1
//     ```, caption: [赋值]) <code:one>
//
// kind 是 Typst 自己认的 raw，题注印「代码1-1」（词是 Typst 给的）。框与行号按 raw-style
// （src/config/settings.typ）：三档框与伪代码同一套线（三线表的 1.5 / 1.0），题注位置随框定
// （tabular / ruled 在上，boxed 在下）；行号在左边一列、小一号、右对齐，与伪代码同一个排法。
//
// *散在正文里的代码块不走这里*：Word 里那就是一个段落，没框没行号（字号与行盒在 lib.typ
// 的 show raw 里给）。
//
// *codly / zebraw 这类代码包接管了 body 的，框与行号都归它们*：它们的 show raw 在用户文档里、
// 更内层，这里的 show raw 到不了；题注位置仍随 frame 定。
//
// *续排的行号接着数*（与伪代码同一条）：沿 #continued() 链把前几张的行数加起来当偏移。
// 跨页：tabular 的顶线与续页右上角的标注由 captions.typ 的 _split 那一路出（题注在上的自造
// kind 都是那一套），底线是块的下边、Typst 给每一片各画一条；ruled 两条线是前后各一个零高块，
// 拆页时不画线不标注；boxed 是块的一圈边，每片各画，题注跟头一片、续片末尾标续（_split）。
#import "../engine/settings.typ" as _settings
#import "../engine/fonts.typ" as _fonts
#import "../engine/styles.typ" as _styles
#import "../engine/layout.typ" as _layout
#import "../engine/marks.typ": in-listing
#import "./captions.typ": _table-style, _continued-step
#import "./algorithm.typ": _number, _column, _NUMBER-GAP

// 这一张之前、#continued() 链上各张的行数之和。链头不是续排就停。要在 context 里调
#let _line-offset() = {
  let sel = figure.where(kind: raw)
  let mine = query(sel.before(here(), inclusive: true))
  if mine.len() == 0 { return 0 }
  let cur = mine.last()
  let n = 0
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    cur = _continued-step(sel, cur)
    if cur == none { break }
    // 接的那张的 body 是 raw 时按它的行数数；被代码包接管的 body 也还是 raw 元素
    let b = cur.body
    if type(b) == content and b.func() == raw { n += b.text.split("\n").len() }
  }
  n
}

// *一行太长折了行，续行悬挂到本行自己的缩进。* 缩进在代码里是语义（它标着块级），续行
// 顶格排会把块结构打断——`hhhh, iiii)` 顶着 def 那一列，看着像一条新语句，其实是上一行的
// 尾巴。通行做法都是悬挂：codly 的 smart-indent（它的默认）、LaTeX listings 的 breakindent、
// minted、编辑器的 wrap indent。*Word 那边没有出处*——指南对代码一个字没写，Word 里代码
// 就是普通段落、续行回左缘，可 Word 里也没人贴超长代码行，这一处是我们自己定的。
//
// 缩进宽度按这一行前导的空白算。
//
// *量出来的宽要补一份字距*：measure 一个现造的 raw 不吃字符网格那份 tracking（实测四个
// 空格量到 23.08，排出来是 24.87，差 4 × 0.4543 正好是四个字的增量），而行里的每个字都吃。
// 补的是*版面那一份*（docgrid.tracking），不是 text.tracking——后者在这一处已经被 raw 那条
// 规则减半了（读出来 0.2265），补它只补一半。网格没启用时它是 0，这一项自然消失。
// *用「前缀 ＋ 一个字」减「一个字」*：量单独一段空白会把行末那一份算进去（23.31 ≠ 4 × 5.771）。
// *要在 context 里调*
#let _hang(text-of-line) = {
  let n = 0
  for c in text-of-line.clusters() {
    if c == " " or c == "\t" { n += 1 } else { break }
  }
  if n == 0 { return 0pt }
  let prefix = text-of-line.clusters().slice(0, n).join()
  measure(raw(prefix + "x")).width - measure(raw("x")).width + n * _layout.current-layout().docgrid.tracking
}

// 一行一个块：块与块之间不发段距，行距就是等宽字体的行盒（lib.typ 的 show raw 给的）；
// 一行一块也让 Typst 能在行间断页。行号挂在行首、往左探出一列（_number，level 0）
#let _lines(it, st, offset) = {
  let numbered = st.line-numbering != none
  // *行距在这儿加，不在全篇那一条上*：代码贴进论文，那一段继承的是正文的行距（小四 1.25
  // 倍，Consolas 11 一行 16.10；Word 探针量到 16.08）。全篇那一条只给单倍——codly / zebraw
  // 量我们的行盒去定它们那些框，见 src/engine/fonts.typ 的 mono-text-em
  set text(.._fonts.mono-edges-em(
    _fonts.current.get().families.mono,
    _styles.styles-state.get().body.at("line-spacing", default: 1),
  ))
  // 行号列的宽按这一段最宽的号来（伪代码那头同一个 _column）：写死一个半字，行号一过
  // 三位、或者 line-numbering: "一" 排到「一百一十一」，号就探到版心左边去了。量在 set
  // 之后，量到的才是代码这一档的字
  let col = _column(st.line-numbering, offset, offset + it.lines.len())
  let rows = for (i, line) in it.lines.enumerate() {
    // *悬挂靠「整行左移 ＋ 首行拉回」，不走 par(hanging-indent:)*：那个属性只有直接发 par
    // 才吃得上（set 在块里、外层都不生效，与目录条目同一个坑），而显式发一个 par 会换掉行盒
    // ——实测行距从 16.10 掉到 15.80，还会吃到正文那一档的首行缩进。pad 把整行推开一个缩进，
    // 行首一个负的 h 把第一行拉回去：续行就停在缩进处，第一行照旧从代码列左缘起
    let hang = _hang(line.text)
    block(width: 100%, above: 0pt, below: 0pt, pad(left: hang, {
      h(-hang, weak: false)
      // 行号在拉回之后发，落点才是代码列左缘（它是个零宽的盒子，往左探出一列）
      if numbered { _number(offset + i + 1, 0, st.line-numbering, col) }
      line
    }))
  }
  pad(left: if numbered { col + _NUMBER-GAP } else { 0pt }, rows)
}

// 三档框。与 src/blocks/algorithm.typ 的 _frame 同一套线与内边距，少了输入输出那一段
#let listing(it) = context {
  let st = _settings.resolve-raw-style()
  // 线宽与内边距从表格那一档样式取（三线表的数）
  let ts = _table-style()
  let s = ts.stroke
  let x = ts.inset.x
  let piece = block.with(width: 100%, above: 0pt, below: 0pt)
  let main = piece(inset: (x: x), _lines(it, st, _line-offset()))
  let rule(stroke) = piece(height: 0pt, stroke: (top: stroke))
  set align(left)
  if st.frame == "tabular" {
    // 顶线与底线是块的边：拆页时 Typst 给每一片各画——页底收底线、续页从顶线起，与三线表
    // 跨页每片完整同；续页顶上的标注在 _split 注的那一格里，落在顶线之上
    piece(stroke: (top: s.top, bottom: s.bottom), inset: (top: s.top / 2, bottom: s.bottom / 2), main)
  } else if st.frame == "ruled" {
    // 题注上面那条粗线由题注自己画（captions.typ 的 _caption-line），这里是题注下面的细线
    // 与末尾的粗线，各是独立的零高块：拆页时页底与续页都不画线、不标注
    rule(s.header)
    piece(inset: (top: s.header / 2, bottom: s.bottom / 2), main)
    rule(s.bottom)
  } else if st.frame == "boxed" {
    piece(stroke: s.header, inset: (y: s.header / 2), main)
  } else {
    main
  }
}

// *这条 show raw 挂在 lib.typ 那一层、不挂在 figure 规则里面*：挂在里面就是最内层，codly /
// zebraw 在用户文档里的 show raw 反而到不了 body。挂在包那一层，它们的在内层、先跑、接管
// body（行号归它们）；没装代码包的才轮到我们
#let listing-rules(doc) = {
  show raw.where(block: true): it => context {
    // 散在正文里的那些没有框、没有行号（Word 里代码就是一个段落），但*折行照样悬挂*——
    // 缩进是块级的记号，进不进 figure 都一样。走同一支 _lines，只把行号关掉
    if in-listing.get() { listing(it) } else {
      _lines(it, _settings.resolve-raw-style() + (line-numbering: none), 0)
    }
  }
  doc
}

