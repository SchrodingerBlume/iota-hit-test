// 代码清单：进了 figure 的代码块。
//
//     #figure(```python
//     x = 1
//     ```, caption: [赋值]) <code:one>
//
// kind 是 Typst 自己认的 raw，题注印「代码1-1」（词是 Typst 给的）。框与行号按 raw-style
// （src/config/settings.typ）：三档框与伪代码同一套线（三线表的 1.5 / 1.0），题注位置随框定
// （tabular / ruled 在上，boxed 在下）；行号在左边一列、小一号、右对齐，与伪代码同一个排法。
//
// *散在正文里的代码块不走这里*：Word 里那就是一个段落，没框没行号（字号与行盒在 lib.typ
// 的 show raw 里给）。
//
// *codly / zebraw 这类代码包接管了 body 的，框与行号都归它们*：它们的 show raw 在用户文档里、
// 更内层，这里的 show raw 到不了；题注位置仍随 frame 定。
//
// *续排的行号接着数*（与伪代码同一条）：沿 #continued() 链把前几张的行数加起来当偏移。
// 跨页：tabular 的顶线与续页右上角的标注由 captions.typ 的 _split 那一路出（题注在上的自造
// kind 都是那一套），底线是块的下边、Typst 给每一片各画一条；ruled 两条线是前后各一个零高块，
// 拆页时不画线不标注；boxed 是块的一圈边，每片各画，题注跟头一片、续片末尾标续（_split）。
#import "../engine/settings.typ" as _settings
#import "../engine/layout.typ" as _layout
#import "../engine/marks.typ": in-listing
#import "./captions.typ": _table-style, _continued-step
#import "./algorithm.typ": _number, _NUMBER-COLUMN, _NUMBER-GAP

// 这一张之前、#continued() 链上各张的行数之和。链头不是续排就停。要在 context 里调
#let _line-offset() = {
  let sel = figure.where(kind: raw)
  let mine = query(sel.before(here(), inclusive: true))
  if mine.len() == 0 { return 0 }
  let cur = mine.last()
  let n = 0
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    cur = _continued-step(sel, cur)
    if cur == none { break }
    // 接的那张的 body 是 raw 时按它的行数数；被代码包接管的 body 也还是 raw 元素
    let b = cur.body
    if type(b) == content and b.func() == raw { n += b.text.split("\n").len() }
  }
  n
}

// 一行一个块：块与块之间不发段距，行距就是等宽字体的行盒（lib.typ 的 show raw 给的）；
// 一行一块也让 Typst 能在行间断页。行号挂在行首、往左探出一列（_number，level 0）
#let _lines(it, st, offset) = {
  let numbered = st.line-numbering != none
  let rows = for (i, line) in it.lines.enumerate() {
    block(width: 100%, above: 0pt, below: 0pt, {
      if numbered { _number(offset + i + 1, 0, st.line-numbering) }
      line
    })
  }
  pad(left: if numbered { _NUMBER-COLUMN + _NUMBER-GAP } else { 0pt }, rows)
}

// 三档框。与 src/blocks/algorithm.typ 的 _frame 同一套线与内边距，少了输入输出那一段
#let listing(it) = context {
  let st = _settings.resolve-raw-style()
  // 线宽与内边距从表格那一档样式取（三线表的数）
  let ts = _table-style()
  let s = ts.stroke
  let x = ts.inset.x
  let piece = block.with(width: 100%, above: 0pt, below: 0pt)
  let main = piece(inset: (x: x), _lines(it, st, _line-offset()))
  let rule(stroke) = piece(height: 0pt, stroke: (top: stroke))
  set align(left)
  if st.frame == "tabular" {
    // 顶线与底线是块的边：拆页时 Typst 给每一片各画——页底收底线、续页从顶线起，与三线表
    // 跨页每片完整同；续页顶上的标注在 _split 注的那一格里，落在顶线之上
    piece(stroke: (top: s.top, bottom: s.bottom), inset: (top: s.top / 2, bottom: s.bottom / 2), main)
  } else if st.frame == "ruled" {
    // 题注上面那条粗线由题注自己画（captions.typ 的 _caption-line），这里是题注下面的细线
    // 与末尾的粗线，各是独立的零高块：拆页时页底与续页都不画线、不标注
    rule(s.header)
    piece(inset: (top: s.header / 2, bottom: s.bottom / 2), main)
    rule(s.bottom)
  } else if st.frame == "boxed" {
    piece(stroke: s.header, inset: (y: s.header / 2), main)
  } else {
    main
  }
}

// *这条 show raw 挂在 lib.typ 那一层、不挂在 figure 规则里面*：挂在里面就是最内层，codly /
// zebraw 在用户文档里的 show raw 反而到不了 body。挂在包那一层，它们的在内层、先跑、接管
// body（行号归它们）；没装代码包的才轮到我们
#let listing-rules(doc) = {
  show raw.where(block: true): it => context {
    if in-listing.get() { listing(it) } else { it }
  }
  doc
}

