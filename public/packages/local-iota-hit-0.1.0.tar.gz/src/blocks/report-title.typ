// 报告那一档的*表单名*——「硕士学位开题报告」「Master's Thesis Proposal」
// 那一行字。
//
// *两处用同一支*：首页正中那一行（src/pages/report/cover.typ）与深圳那两份
// 的页眉（src/blocks/header.typ）。先前只有首页在拼，页眉要用就得把同一段逻辑
// 抄一遍——抄的是「哪一档用学位的名、哪一档用文种」这种会分叉的判断，抄了就会
// 各自漂。
//
// 这一支只*把料备齐*——学位的名、文种、阶段名——拼法由词条那一侧的模板
// 决定，谁用哪几样是它的事，见 src/config/terms.typ 的 report-title-*：
//
//   zh 硕博   ｛学位｝＋｛阶段｝              硕士学位 ＋ 开题报告
//   zh 本科   ｛文种｝＋｛阶段｝              本科毕业论文（设计）＋ 开题报告
//   zh 深圳   ｛文种｝＋｛阶段｝              硕士学位论文 ＋ 开题报告
//   en 开题   Thesis Proposal of ｛学位｝Candidates
//   en 中期   Interim Report for ｛文种｝
#import "../engine/terms.typ": term-for

// 阶段名（开题报告／中期报告 ／ Proposal Report／Interim Report）。取不到就是
// none，模板那一侧自然不用它。
//
// *中英两侧都有了*：中文那一侧另有一处在用——日期那一格拼成「开题报告
// 日期」；英文那一格是各写各的整句（Defense Date／The Date），*不拼*，
// 所以那一处的判据是语言，不是「取不取得到」，见 src/pages/report/cover.typ
#let stage-word(t, variant) = if "stage-" + variant.stage in t {
  term-for(t, "stage", variant)
} else { none }

// t 是*已经按这一页的语言取好的桶*——首页递 cover 桶、页眉递 header 桶，料都
// 从 t 里取：表单名的模板、阶段名、学位的名、文种，页眉那一桶各写着 from("cover")
// ／from("base")，所以两页各有自己的键、各自改得动（见 src/config/terms.typ 的
// base 桶抬头）。variant 是这一页递的那几根轴。回来的是拼好的内容
#let report-title(t, lang, info, variant) = {
  let degree-level = term-for(t, "degree", variant)
  let document-type = term-for(t, "document-type", variant)
  term-for(t, "report-title", variant)(
    degree-level, document-type, stage-word(t, variant),
  )
}
