// 组图：几张分图怎么摆。
//
// 同一个名字两个位置，靠上下文分：写在图题里的 #subs([静压], [动压]) 是分图题
// （连排在图题之下，见 src/engine/marks.typ）；写在图的正身里的
// #subs(image("a.png"), image("b.png")) 是排布。判法看位置参数——里面有 image / stack
// 这类版面元素就是排布，全是文字就是分图题。
//
//     #figure(
//       subs(image("a.png"), stack(image("b.png"), image("c.png")), columns: auto, width: 90%),
//       caption: [气体润滑轴承的分类 #subs([静压 <fig:s>], [动压], [动静压])],
//     ) <fig:1-1>
//
// *模型*：一行里的图等高、各保宽高比、撑到给定的宽。任何一个节点的宽都是高的一次
// 函数 w(h) = a·h + b——叶子 w = r·h；横排（ltr）孩子同高、宽相加；竖叠（ttb）孩子同宽、
// 高相加，反解回来还是一次的；套多少层都只是一次函数的复合。最外层令 w(h) = W 一步
// 解出 h，再自顶向下把尺寸发下去。不二分、不迭代。
//
// *行与列直接收原生的 stack*：stack(dir: ltr | ttb, …) 的 dir 与 children 就是树，随便嵌。
// rtl / btt 与 ltr / ttb 同一套几何，只把孩子倒过来；横排里套横排、竖叠里套竖叠拍平成
// 一层；一个孩子的 stack 透明；空的当场报错。stack(spacing:) 写了照写的，没写用 gutter。
// columns: 2 / (3, 2) 是「切成几行、每行各自撑满」的糖。
//
// *写了什么守什么*：图自己写了 width / height 的算钉死，按写的排，不缩不放，解的时候
// 从 W 里扣掉它的宽；不是 image 的叶子（rect、cetz、文字块）按 measure 的自然尺寸钉死，
// 要它跟着缩就自己裹一层 box(width: …)。一行全钉死了就没有自由量，按自然总宽居中。
//
// *不放大*：解出来的行高不超过这一行里任何一张没钉的图的自然高——两张小图本来装得下，
// 不该被拉到版心那么宽（范例的分图都是自然尺寸）。装不下才缩。整体比版心还高（一竖溜
// 三张竖图）就整体等比缩到装下——图不能跨页；columns 切出来的多行不在此列，那是各自
// 的块，续图机制接得住（每行一个块，行间 v(gutter)，见 captions.typ 的 _split）。
//
// *分图题在哪跟着它写在哪儿*：写在图题里就是「图题之下」连排（现在的 #subs 那一档），
// 写在这里的 captions: 就是「分图之下」（每格换成 #subfigure，题各自居中在自己那张分图
// 下，标签写在条目里）。指南 2.13.1 那句「分图题置于分图之下或图题之下」只有这两处，
// 一个字写在哪儿就排在哪儿，不设开关。
//
// *叠在图上的编号* numbering，照原生 figure(numbering:) 的三态再加一档：
//   none        不叠（默认）——分图号通常已经画在图里
//   "(a)"       编号串，交 numbering() 排；默认样子五号 sans 黑字、左上角、离角半个字
//   (fill: white, alignment: bottom + right, dx: -4pt, dy: -4pt)
//               字典，只写要改的：fill / stroke 是 text 的，alignment / dx / dy 是 place 的；
//               编号串跟 subcaption-numbering。同时换格式的走函数
//   n => …      函数收序号；返回 place 元素就原样贴上（位置样式全听它的），返回别的按
//               默认位置贴
//   数组        逐图一项，每项上面四态混着写
#import "../engine/part.typ"
#import "../engine/layout.typ" as _layout
#import "../engine/fonts.typ"
#import "../engine/styles.typ" as _styles
#import "../engine/settings.typ": setting-of
#import "../engine/marks.typ": subs as _subs-mark
#import "../config/fonts.typ": zihao
#import "./captions.typ": subfigure, subs-rows

// 这一堆位置参数是版面还是文字：有一个版面元素就是排布
#let _layout-ish(c) = (
  type(c) == array
    or (type(c) == content and (
      c.func() in (image, stack, grid, box, block, rect, circle, polygon, path, curve)
        or (c.has("children") and c.children.any(_layout-ish))
        or (c.has("body") and _layout-ish(c.body))
    ))
)

// ── 树 ────────────────────────────────────────────────────────────
//
// 节点三种：leaf（一张图或一块钉死的东西）、row（ltr）、col（ttb）。每个节点带两条一次
// 函数：宽是高的 (a, b)，高是宽的 (c, d)。钉死的两条都是常数。要在 context 里建——量自然尺寸。
#let _build(c, gutter) = {
  if type(c) == array { return _build(stack(dir: ttb, ..c), gutter) }
  if type(c) == content and c.func() == stack {
    let dir = c.at("dir", default: ttb)
    let kids = c.children.filter(k => not (type(k) == content and k.func() == [ ].func()))
    if kids.len() == 0 { panic("subs: empty stack") }
    let spacing = c.at("spacing", default: none)
    let g = if spacing == none { gutter } else { spacing }
    let horizontal = dir in (ltr, rtl)
    let kids = if dir in (rtl, btt) { kids.rev() } else { kids }
    let nodes = kids.map(k => _build(k, gutter))
    // 同向的套一层拍平：几何等价，间距按外层的
    let nodes = nodes.map(n => if n.kind == (if horizontal { "row" } else { "col" }) { n.children } else { (n,) }).flatten()
    if nodes.len() == 1 { return nodes.first() }
    let gaps = (nodes.len() - 1) * g
    return if horizontal {
      // 同高 h：w = Σ(aᵢh + bᵢ) + gaps
      let a = nodes.map(n => n.a).sum()
      let b = nodes.map(n => n.b).sum() + gaps
      // 钉死的孩子高不跟 h 走，行的实际高是 max(h, 它们的高)
      let fixed-h = nodes.filter(n => n.a == 0).map(n => n.d).fold(0pt, calc.max)
      // 不放大的上限：这一行里没钉的孩子各自的自然高，取最小
      let cap = nodes.filter(n => n.a != 0).map(n => n.cap).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "row", children: nodes, gap: g, a: a, b: b,
        c: if a == 0 { 0 } else { 1 / a }, d: if a == 0 { fixed-h } else { -b / a },
        cap: cap, cap-w: if cap == none { none } else { a * cap + b })
    } else {
      // 同宽 w：h = Σ(cᵢw + dᵢ) + gaps
      let c0 = nodes.map(n => n.c).sum()
      let d0 = nodes.map(n => n.d).sum() + gaps
      let fixed-w = nodes.filter(n => n.c == 0).map(n => n.b).fold(0pt, calc.max)
      // 竖叠的「不放大」上限换算到高：每个孩子的自然宽 → 最窄的那个定了格宽，格高随之
      let cap-w = nodes.filter(n => n.c != 0).map(n => n.cap-w).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "col", children: nodes, gap: g,
        a: if c0 == 0 { 0 } else { 1 / c0 }, b: if c0 == 0 { fixed-w } else { -d0 / c0 },
        c: c0, d: d0,
        cap: if cap-w == none { none } else { c0 * cap-w + d0 },
        cap-w: cap-w)
    }
  }
  // 叶子
  let is-image = type(c) == content and c.func() == image
  let pinned = not is-image or c.at("width", default: auto) != auto or c.at("height", default: auto) != auto
  if pinned {
    let nat = measure(c)
    return (kind: "leaf", body: c, image: is-image, pinned: true, a: 0, b: nat.width, c: 0, d: nat.height, cap: nat.height, cap-w: nat.width)
  }
  // *宽高比不能直接量图的高*：figure 里那条「装图的行占整数个网格行」的 show image
  // （captions.typ）把图裹进一个 rows × 行距 的块，measure 出来的高是取整过的，比按它算
  // 一行里三张图各差 3%、等高就不等了。宽不受那个块影响：量一张定高 100pt 的图，宽 ÷ 100
  // 就是真的宽高比；自然宽另量一次（同样只取宽）
  let nat-w = measure(c).width
  let r = measure(image(c.source, height: 100pt)).width / 100pt
  if nat-w == 0pt or r == 0 {
    return (kind: "leaf", body: c, image: true, pinned: true, a: 0, b: nat-w, c: 0, d: nat-w, cap: nat-w, cap-w: nat-w)
  }
  (kind: "leaf", body: c, image: true, pinned: false, a: r, b: 0pt, c: 1 / r, d: 0pt, cap: nat-w / r, cap-w: nat-w)
}

// 把尺寸发下去：给节点一个高（行）或宽（列），返回 (w, h, 渲染好的内容)
#let _place-number(k, w, h, spec, default-font, default-size) = {
  if spec == none { return none }
  let pattern = if type(spec) == str { spec } else { setting-of("subcaption-numbering") }
  let d = if type(spec) == dictionary { spec } else { (:) }
  let label = text(
    font: default-font, size: default-size,
    ..(if "fill" in d { (fill: d.fill) } else { (:) }),
    ..(if "stroke" in d { (stroke: d.stroke) } else { (:) }),
    numbering(if "numbering" in d { d.numbering } else { pattern }, k),
  )
  let body = if type(spec) == function { spec(k) } else { label }
  if type(body) == content and body.func() == place { return body }
  // 离角半个字——编号自己那一档的字（五号），不是周围正文的
  place(
    d.at("alignment", default: top + left),
    dx: d.at("dx", default: 0.5 * default-size), dy: d.at("dy", default: 0.5 * default-size),
    body,
  )
}

#let _render(node, w, h, ctx) = {
  if node.kind == "leaf" {
    let (w, h) = if node.pinned { (node.b, node.d) } else { (w, h) }
    let k = ctx.index.at(0)
    ctx.index.at(0) += 1
    // 重发 image 而不是 scale：宽写进元素，别的字段（alt、fit、format…）原样带过去
    let body = if node.pinned { node.body } else {
      let f = node.body.fields()
      let _ = f.remove("source")
      let _ = f.remove("width", default: none)
      let _ = f.remove("height", default: none)
      image(node.body.source, ..f, width: w)
    }
    // 编号叠在*图*上（盒子只裹图，分图题在盒子外面——bottom + right 才是图的右下角）
    let spec = if type(ctx.numbering) == array { ctx.numbering.at(k - 1, default: none) } else { ctx.numbering }
    let num = _place-number(k, w, h, spec, ctx.font, ctx.size)
    let body = if num == none { body } else { box(width: w, { body; num }) }
    // 写了 captions: 的就是「分图之下」那一档：每格一个真 figure，题各自居中在它下面
    let body = if ctx.captions.len() >= k {
      subfigure(body, caption: ctx.captions.at(k - 1))
    } else { body }
    (w: w, h: h, body: body, ctx: ctx)
  } else if node.kind == "row" {
    let cells = ()
    let ws = ()
    for n in node.children {
      let r = _render(n, if n.a == 0 { n.b } else { n.a * h + n.b }, h, ctx)
      ctx = r.ctx
      cells.push(r.body); ws.push(r.w)
    }
    let hh = calc.max(h, ..node.children.map(n => if n.a == 0 { n.d } else { 0pt }))
    (w: ws.sum() + (ws.len() - 1) * node.gap, h: hh,
      body: grid(columns: ws, column-gutter: node.gap, align: center + horizon, ..cells), ctx: ctx)
  } else {
    let cells = ()
    let hs = ()
    for n in node.children {
      let r = _render(n, w, if n.c == 0 { n.d } else { n.c * w + n.d }, ctx)
      ctx = r.ctx
      cells.push(r.body); hs.push(r.h)
    }
    (w: w, h: hs.sum() + (hs.len() - 1) * node.gap,
      body: grid(columns: 1, row-gutter: node.gap, align: center, ..cells), ctx: ctx)
  }
}

// 一行：解 h，不放大，渲染，居中
#let _row(node, W, ctx) = {
  let h = if node.a == 0 { node.d } else { (W - node.b) / node.a }
  let h = if node.cap == none { h } else { calc.min(h, node.cap) }
  let r = _render(node, node.a * h + node.b, h, ctx)
  (body: align(center, r.body), h: r.h, ctx: r.ctx)
}

#let _subs-layout(items, columns: auto, width: 90%, gutter: auto, captions: (), numbering: none) = {
  let items = items.filter(k => not (type(k) == content and k.func() == [ ].func()))
  if items.len() == 0 { panic("subs: nothing to lay out") }
  if type(captions) != array { panic("subs: captions: expected array, found " + str(type(captions))) }
  // 切行：auto 一行，整数每行几个，数组逐行几个
  let rows = if columns == auto { (items,) } else if type(columns) == int {
    range(0, items.len(), step: columns).map(i => items.slice(i, calc.min(i + columns, items.len())))
  } else if type(columns) == array {
    let out = (); let i = 0
    for n in columns { out.push(items.slice(i, calc.min(i + n, items.len()))); i += n }
    if i < items.len() { out.push(items.slice(i)) }
    out
  } else { panic("subs: columns: expected auto, integer, or array, found " + repr(columns)) }
  layout(size => context {
    // 当前生效的版面；没进过 iota-hit 的文档从本档默认起
    let lay = _layout.current-layout()
    let g = if gutter == auto { part.ccwd(1) } else { part.resolve-chars(gutter, lay) }
    let g = g.to-absolute()
    let W = if type(width) == ratio { size.width * width } else { width.to-absolute() }
    let fam = fonts.current.get().families
    let ctx = (index: (1,), captions: captions, numbering: numbering,
      font: _styles.font("sans", fam), size: zihao.wuhao)
    let out = ()
    for row in rows {
      let node = _build(stack(dir: ltr, ..row), g)
      let node = if node.kind != "row" { (kind: "row", children: (node,), gap: g, a: node.a, b: node.b, c: node.c, d: node.d, cap: node.cap) } else { node }
      let r = _row(node, W, ctx)
      ctx = r.ctx
      out.push(r)
    }
    // 整体比版心还高就整体缩：图不能跨页。只管单行（多行各自成块，续图机制接得住）
    if out.len() == 1 and out.first().h > lay.text-height - 3 * lay.docgrid.line-pitch {
      let k = (lay.text-height - 3 * lay.docgrid.line-pitch) / out.first().h
      let node = _build(stack(dir: ltr, ..rows.first()), g)
      let node = if node.kind != "row" { (kind: "row", children: (node,), gap: g, a: node.a, b: node.b, c: node.c, d: node.d, cap: node.cap) } else { node }
      let ctx = (index: (1,), captions: captions, numbering: numbering,
        font: _styles.font("sans", fam), size: zihao.wuhao)
      let h = if node.a == 0 { node.d } else { (W - node.b) / node.a }
      let h = if node.cap == none { h } else { calc.min(h, node.cap) }
      let r = _render(node, node.a * h * k + node.b, h * k, ctx)
      out = ((body: align(center, r.body), h: r.h, ctx: r.ctx),)
    }
    // 网格开着时一行占整数个网格行、行在里面居中——与单张图那条规则同一个模型
    // （captions.typ 的 show image），只是按行不按张：里面的图那条规则见到记号就不碰
    let snapped = lay.docgrid.grid and lay.docgrid.line-pitch != 0pt
    let row-block(r) = if snapped {
      // 量排出来的（分图之下那一档每格还挂着题，比解出来的行高高）
      let h = measure(block(width: size.width, r.body)).height
      let rows = calc.max(1, calc.ceil(h / lay.docgrid.line-pitch))
      block(width: 100%, height: rows * lay.docgrid.line-pitch, above: 0pt, below: 0pt, align(horizon, r.body))
    } else { block(width: 100%, above: 0pt, below: 0pt, r.body) }
    subs-rows.update(true)
    out.map(row-block).join(v(g))
    subs-rows.update(false)
  })
}

// 公开的那一个：看位置参数决定走哪一支
#let subs(gap: auto, columns: auto, width: 90%, gutter: auto, captions: (), numbering: none, ..items) = {
  if items.pos().any(_layout-ish) {
    _subs-layout(items.pos(), columns: columns, width: width, gutter: gutter, captions: captions, numbering: numbering)
  } else {
    _subs-mark(gap: gap, ..items)
  }
}
