// 下划线按 Word 画。
//
// *三件事，都是自己造 docx 在 Word 上量的*（中易宋体 + Times New Roman，24 / 48pt，
// 见 src/config/fonts.typ 的 underline-offset）：
//
//   一 一个 run 一条线：「汉字 Latin 汉字」整段是一条通线，不按字体分段、中间没有缝。
//     Typst 是按 shaping run 各画各的，run 边界上那个字形丢掉的字距（0.4543）没线，
//     每条线两头各延 tracking/2 把缝填上。
//   二 上标的线*不跟上标走*：留在正文那条线上，粗细也是正文的（24pt 上上标段线心
//     +3.24、粗 1.20，与两旁正文相同）。
//   三 下标的线也留在正文那条线上。自己量的 macOS Word 里汉字下标是这样（24pt 上
//     线心 +3.48，与两旁正文相同）；西文下标那段量到低 0.03em、细一档（+3.96、粗
//     0.72），按用户在 Word 里看到的「上下标的线与正文一样高」，两种都归正文线，
//     不给西文下标另立一档。
//
// *Typst 的 offset 是相对每个字形自己的基线的*（实测上标那段的线跟着抬到
// −3.82，下标那段掉到 +3.34），且 offset / stroke 在 underline 元素上一次定死，
// 里面再 set 不认。所以整段先按 super / sub 拆开，各成一个 underline 元素：上标的
// 那个装在 super 里面，offset 里把抬起的那 0.35em 补回去；下标的那个装在 sub 里面，
// offset 里把沉下去的那 0.08em 扣掉；粗细都是正文的。*em 一律按正文字号解*
// ——装进 super / sub 里的 underline 元素，它的 offset 仍按外面的字号折算（实测写
// 0.746em 得 8.95 ＝ 0.746 × 12，不是 × 7.8）。
//
// *只拆一层。* 上标套在 strong 里面这种（#underline[a#strong[b#super[2]]]）拆不到，
// 那段线仍随上标抬起——少见，认了。
//
// *不递归*：只接用户写的 underline（evade 还是默认的 true），自己发出去的一律
// evade: false——Word 的线不绕开撇捺，正好也拿它当记号。
//
// 字距补偿（src/engine/tracking.typ 的 tracking-pad）在整段外面发一次，不给拆出来的
// 每一段各发——否则段与段之间多出 0.4543 的缝。
#import "../config/fonts.typ": underline-offset, underline-stroke
#import "../engine/tracking.typ": tracking-pad
#import "../engine/fonts.typ": boundary-loss

// 上标抬、下标沉的量，与 lib.typ 里 set super / set sub 的那两个数一致
#let _super-raise = 0.35em
#let _sub-sink = 0.08em

#let _line(body, offset: underline-offset, stroke: underline-stroke) = context underline(
  offset: offset, stroke: stroke, evade: false, extent: text.tracking / 2 * boundary-loss(), body,
)

// 上下标：线要落回正文那条线，把抬起／沉下的量在 offset 里补回来。*underline 套在
// super 外面就行*——offset 是相对每个字形自己的基线算的，上标的字形基线抬了 0.35em，
// offset 加 0.35em 正好落回去；不必重造 super 元素（重造会被同一条 show 规则再接一遍）。
#let _super-line(s) = _line(s, offset: underline-offset + _super-raise)
#let _sub-line(s) = _line(s, offset: underline-offset - _sub-sink)

#let _piece(c) = {
  if c.func() == super { _super-line(c) }
  else if c.func() == sub { _sub-line(c) }
  else if c.func() == ref or c.func() == cite {
    // *引用*：拆的时候它还是 ref，omni 之后才把它排成上标（本包默认顺序编码制、
    // 上标，见 lib.typ 的 gb7714）。所以不给它套线，等它排出 super / sub 再接——那两条
    // 规则只罩这一个引用。引用要是排成了行内形式（cite-form 不是上标），这一段就
    // 没有线，看得见，不算静默。
    show super: _super-line
    show sub: _sub-line
    c
  } else { _line(c) }
}

#let underline-rules(doc) = {
  show underline.where(evade: true): it => {
    let kids = if it.body.has("children") { it.body.children } else { (it.body,) }
    // 相邻的普通段并成一段，别让每个字自成一条线
    let out = ()
    let run = ()
    for c in kids {
      if c.func() in (super, sub, ref, cite) {
        if run.len() > 0 { out.push(_line(run.join())); run = () }
        out.push(_piece(c))
      } else { run.push(c) }
    }
    if run.len() > 0 { out.push(_line(run.join())) }
    tracking-pad(out.join(), probe: it.body)
  }
  doc
}
