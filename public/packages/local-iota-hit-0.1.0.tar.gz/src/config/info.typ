// 论文元信息的默认表：题目、姓名、学位、日期这些的取值。*只放值*——state 与
// 读写函数（info、info-get、value-of、date-fields）住在 src/engine/info.typ。

#import "./terms.typ": term-defaults

// 认得的键。写错键名是*静默失效*（存进去没人读），所以要挡住。
#let info-defaults = (
  // 学位层次：bachelor / master / doctor。*默认博士*：三档里它的页最全（双语题注、
  // 英文内封、双份索引……），不写就拿到全套；本硕写一行就少排
  degree-level: "doctor",
  // 学位类别：auto 按学位判（本科不发，研究生发学术学位）
  degree-type: auto,
  // *学科门类*：stem / hass，见 src/config/axes.typ。它*不印在任何页上*，
  // 住这儿是因为 degree-level 也是一根轴、也住这儿——各页要按门类分档时从同一处取。
  // 眼下只有正文层次的编号按它分，见 src/config/numbering.typ
  category: "stem",
  // *交上去的是哪一种东西*：dissertation 写出来的论文，practice 做出来的成果。
  // 见 src/config/axes.typ 的 form——本科的「毕业设计」与硕博的「实践成果」是
  // 同一档，本科写 design 也认（别名），往下只见 practice。
  //
  // 两档的分量差得很远，都在词条表里：本科只改内封第一行勾哪个框（指南通篇写
  // 「本科毕业论文（设计）」，一个字都不换）；硕博是换一份指南，封面、内封、
  // 页眉、原创性声明的字全跟着换。
  form: "dissertation",
  // 哪一份材料：final 那份成果本身 / proposal 开题报告 / interim 中期报告。
  // 与 form 正交，见 src/config/axes.typ
  stage: "final",
  // 校区。harbin（本部，默认）／shenzhen。深圳的开题与中期是另发的一套表单，
  // 见 src/config/axes.typ 的 campus
  campus: "harbin",
  title: [`title`],
  // *带 -en 的那几条一律 auto ＝ 没写*，取值时回落到不带后缀的那一条
  // （src/engine/info.typ 的 value-of）；显式写了就照写的来。
  //
  // *为什么不预置一份英文样例。* 双语的文档（论文）两边都得填，那是填表
  // 人的事；而*单语的文档*（英文版的开题与中期报告）整页只有一种语言，
  // 逼着他把同一个学院名写两遍毫无道理——「没写」就该拿他写过的那一条来用。
  // 预置样例反而更糟：忘了填时封面上印的是*别人论文里的那一句*，比印自己
  // 的中文题目更难发现。
  //
  // 先例是 defense-date-en（见下面），它一开始就是 auto。
  title-en: auto,
  // 英文题目的字号：auto 让算法判，塞得下就不缩
  title-en-xiaoer: auto,
  // 副题目。*没有就是 none*——「没有副题目」不是一个要写出来的值，也就
  // 没有 auto 那一档。「当题目内容层次很多，难以简化时，可采用主题目与副题目
  // 相结合的方法」（指南 2.1）。
  //
  // 中文另起一行、比主题目退 4 个半角字符、破折号起头，用小 2 号字；英文用
  // 冒号接在主题目*同一段*里（指南 3.3.1 末句）。内封「格式同封面」
  // （3.3.2 末句），所以封面与两页内封读的是同一对键。
  //
  // *字数不替用户数。* 主副题目字数之和「不应超过」35 个汉字（人文社科版
  // 是 40 个汉字或 80 个字符）——原话是「不应」不是「不得」，而且中英混排、
  // 数学符号在内，数出来的数不可信，数错了拦下一份能交的论文比不拦更糟
  subtitle: none,
  subtitle-en: none,
  author: [`author`],
  institution: term-defaults.zh.base.university,
  // *日期写 ISO*，yyyy / yyyy-mm / yyyy-mm-dd，写到哪一级就排到哪一级；
  // 中文档排「2022年6月」、英文档排「June, 2020」，同一个值两边同源。认不出
  // ISO 就原样排出，写 [二〇二二年六月] 照样能用。见 src/engine/date.typ
  date: [`date`],
  // 内封字段表填的那几项
  student-id: [`student-id`],
  supervisor: [`supervisor`],
  supervisor-en: auto,
  // 副导师与行业导师。*没有就是 none，整行不排*——指南 3.3.2 那张表的
  // 括注写的就是「无副导师的研究生不列此项」「无行业导师不列此项」。范例那位
  // 研究生两样都没有，所以默认也没有（别的字段默认是 □□□ 那种占位格子，
  // 这两个不是：占位格子说的是「这一行有、内容待填」）
  co-supervisor: none,
  co-supervisor-en: none,
  industry-supervisor: none,
  industry-supervisor-en: none,
  degree-applied: [□□博士],
  degree-applied-en: auto,
  speciality: [`speciality`],
  // 实践成果类型，只有 form: "practice" 用得上：封面那一行印「（专业学位
  // □□……□）」，□□……□ 就是它（调研报告、案例分析报告、产品设计报告、
  // 作品创作报告、方案设计报告、重大装备报告、仪器设备报告、硬件产品报告、
  // 软件产品报告、设计方案报告、技术标准报告、案例研究报告——《实践成果写作
  // 指南》表 2，按专业学位类别与*层次*分行：调研报告那五个是硕士层次的，
  // 重大装备报告那六个是博士层次的）。*不校验*——表 2 那句「表中未提及的
  // 专业学位类别，研究生可依据开展课题具体工作参考选用」说明它是参考不是定死。
  //
  // *默认是官方空白封页上那串占位方框*，与 author 的 □□□ 同款：忘了写
  // 就在封面上看得见，不会静默排成「（专业学位）」
  practice-type: [□□……□],
  speciality-en: auto,
  affiliation: [`affiliation`],
  affiliation-en: auto,
  defense-date: "2020-06",
  // *auto ＝ 从 defense-date 出英文*。手写一份别的仍然可以，口子留着
  defense-date-en: auto,
  author-en: auto,
  institution-en: auto,
  // 关键词。*它是著录用的元数据，不是摘要页的排版内容*——文献标引靠它，
  // 跟题目、作者同级；hithesis 也把 keywords 放在 cover 那个块里，与 title、
  // author 并排，而它的 abstract 文件里只有两段正文。
  //
  // 放这儿还顺手解决了摘要的形状：关键词一走，#abstract 只剩两份正文，
  // 于是能合成一次调用 #abstract(en: […])[中文]，与 #chapter(en: […])[…] 同款。
  keywords: (),
  keywords-en: (),
  // 内封表头那几格
  secrecy: [公开],
  classified-index: [××××],
  udc: [××××],
  school-code: [10213],
)
