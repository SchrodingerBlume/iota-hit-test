// 正文层次的编号。
//
// 两份《学位论文写作指南》各给了一张「表2  层次代号及说明」，逐格量过（新版
// g-stem.docx / g-hss.docx）：
//
//   层次   理工类            人文社科类     说明（两份一字不差）
//   章     第1章 □□…       第一章 □□…    章序及章名*居中*排
//   节     1.1 □□…         一、 □□…      题序*顶格*书写，与标题间空 2 个半角
//   条     1.1.1 □□…       （一）□□…     字符，阐述内容另起一段
//   款     1.1.1.1 □□…     1. □□…        （说明那一格是节到款的合并单元格）
//   项     （1）□□…        首先…其次…     题序空 4 个半角字符书写，内容*接排*
//
// *项不做*：它是接排的，题序与内容都空 4 个半角跑在同一段里，那是段落写法
// 不是标题，与 #chapter/#section 那一族不是一回事——理工那档的「（1）」同理。
//
// *版面那一层两份一字不差*（字号、行距、段前段后、页眉、图表、公式、参考文献、
// 成果、答辩决议、简历、书脊），落到版式上的差别只有编号这一处。
//
// *但不止编号不同*——人文社科那份还多一节「（十五）正文页下脚注」（①②③，理工
// 那份一个「脚注」都没有，包里还没做）；目录清单的措辞也不同（那份不含物理量表与索引）；
// 「索引」那份没有这一条，但那是「不排这一页」，不是换个字样。所以这一根轴只落在这个文件上，词条表一个字
// 都不动——axes 那张表自己的规矩就是「只放眼下真有词条按它分档的轴」，这一根是
// 例外中的例外：它分的不是词条，是编号。

// 「第1章」「1.1」「1.1.1」「1.1.1.1」。理工类那一份，也是默认
//
// *「第」「1」「章」之间不写空格。* 范例 docx 里那三段 run 直接相连，看着有空是 Word
// 「自动调整中文与西文的间距」加的 1/4 em（18pt 标题量到 4.75、9pt 页眉 2.25）；Typst 的
// cjk-latin-spacing 给的也是 1/4 em，写不写空格版面一样（四种写法探过，「1」落点相同）。
// 先前写着字面空格，PDF 里复制出来、书签里、检索时都是「第 1 章」，Word 是「第1章」
#let hit-numbering(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "第" + str(n.at(0)) + "章" } else { n.map(str).join(".") }
}

// *开题与中期报告那一套*：「1」「1.1」「1.1.1」——没有「第X章」这一级。
//
// 出处是三份表单（硕士开题、硕士中期、博士开题）「说　明」页里的「层次代号及
// 说明」表，三份逐格相同：
//
//   节  1 □□……□        题序顶格书写，阐述内容另起一段（节条款三行合并的一格）
//   条  1.1 □□……□
//   款  1.1.1 □□……□
//   项  （1）□□…□      题序空 4 个半角字符书写，内容空 4 个半角字符接排
//
// 与论文那张「表2」逐字对得上，*只少了「章」那一行*——所以报告的第一级就是
// 论文的节。项照旧不做（它是接排的段落写法，不是标题），与论文同。
//
// *不分语言与门类*：三份表单的说明页一字不差，英文版表单也是同一张
// （硕士开题英文版、中期英文版的正文规定与中文版逐条相同）；数字本来也不分中西。
#let hit-numbering-report(..nums) = nums.pos().map(str).join(".")

// 英文档那一套：「Chapter 1」「1.1」「1.2.1」。范例的英文目录正是这样排的，
// 与中文那套同一个计数器、两种写法。见 src/pages/toc.typ
#let hit-numbering-en(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "Chapter " + str(n.at(0)) } else { n.map(str).join(".") }
}

// 人文社科类那一份：「第一章」「一、」「（一）」「1.」。
//
// *章序用汉字数字*（「章序用一、二、三、四……」），节与条各自只印*本级*
// 的序号——不是「一、1.」这种累加，表里的示例就是光秃秃的「一、」「（一）」「1.」。
// 第五级不做，理由见文件头。
#let hit-numbering-hass(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "第" + numbering("一", last) + "章"
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}

// 英文里的章序数词。人文社科范例的英文目录印的是「Chapter One」「Chapter Three」
// ——Typst 的 numbering 没有英文数词这一档，只能自己给一张表。
//
// *到二十为止*，再多回落成数字：一篇论文二十章已经离谱，而表越长越可能
// 抄错；回落成「Chapter 21」也读得懂，不是坏字。
#let en-words = (
  "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
  "Eighteen", "Nineteen", "Twenty",
)

// 第 n 个的英文数词。*章与附录共用*——英文目录里印的是「Chapter One」
// 与「Appendix One」，同一个计数写法，见 src/pages/toc.typ
#let en-word(n) = if n >= 1 and n <= en-words.len() { en-words.at(n - 1) } else { str(n) }

// 附录章号那一位的四档。前三档是*原生 numbering() 认的编号串*，取的是这一串
// 的头一个（"A" → A B C、"1" → 1 2 3、"一" → 一 二 三）；"One" 那一档 numbering
// 不认识，是我们自己按 en-words 那张表数的，取名照样是头一个词——英文档的附录
// 印的就是「Appendix One」，与英文目录里那一条同一个写法
#let appendix-patterns = ("A", "1", "一", "One")

// 号那一位印出来是什么
#let appendix-mark(pat, n) = if pat == "One" { en-word(n) } else { numbering(pat, n) }

// *英文目录里*那一位印出来是什么：汉字数字那一档换成英文数词（附录一 →
// Appendix One），与「第一章 → Chapter One」同一个道理。字母与阿拉伯数字两种
// 文字通用，照印。见 src/pages/toc.typ
#let appendix-mark-en(pat, n) = if pat in ("一", "One") { en-word(n) } else {
  numbering(pat, n)
}

// 这一档的号是不是*数*。字母那一档（附录A）的图表与正文本来就分得开
// （表A-1 不会与正文的表1-1 撞），数那三档都会撞，图表公式得另加「附」
// ——判据只此一处，见 src/blocks/chapter.typ
#let appendix-numeric(pat) = pat != none and pat != "A"

// 人文社科类的*英文目录*那一份：「Chapter One」「一、」「（一）」「1.」。
//
// *只有章换成英文数词，节与条照旧是中文的顿号与括号*——《博士研究生学位论文
// 书写范例（人文社科类）》的英文目录逐条就是这样：
//
//     Chapter One  introduction            1
//     一、Problem introduction              1
//     （一）Research issue                  1
//     Chapter Three  realistic basis …     2
//
// 与理工那份（Chapter 1 / 1.1 / 1.2.1）的差别正好对应中文侧的差别，多的只有数词。
#let hit-numbering-hass-en(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "Chapter " + en-word(last)
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}

// 按文档语言、门类与*这一份是什么材料*挑一份。*写死了就照写的*——auto ≡ 不写
#let resolve-numbering(value, lang: "zh", category: "stem", stage: "final") = {
  if value != auto { return value }
  // *报告先分出去*：它的层次表自己写在表单的说明页上（见 hit-numbering-report），
  // 与论文那张表2 不是一回事，语言与门类都不进来
  if stage != "final" { return hit-numbering-report }
  if lang == "en" {
    return if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
  }
  if category == "hass" { return hit-numbering-hass }
  hit-numbering
}

// 英文目录那一份（中文档里博士要出的第二份目录）。同一张表，按门类挑
#let resolve-numbering-en(value, category: "stem", stage: "final") = {
  if value != auto { return value }
  // *报告先分出去*，与 resolve-numbering 同一条：报告的章印的是光「1」，
  // 不是「Chapter 1」——深圳本科英文版的目录里逐条量的就是这样（「1  Main
  // Research Contents…」），与它自己的正文标题一致
  if stage != "final" { return hit-numbering-report }
  if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
}
