// iota 对通用底层的适配：字体角色和模板目标版式留在本仓库。
#import "@local/docxtyp:0.1.0" as d
#import "./fonts.typ"
#import "./styles/engine.typ" as styles
#import "./styles/state.typ": styles-state
#import "./styles/engine.typ": native-format
#import "./paragraph.typ"
#import "./layout/engine.typ" as layout
#import "./fonts/resolve.typ": fontset-state, probes, probe-all, mono-text-em, baseline-rules, kaishu
#import "./fonts/style.typ": resolve-tree, typography as _typography
#import "./fonts/fake.typ": rules as _fake-rules
#import "./fonts/options.typ" as _font-options
#import "./fonts/hant.typ": hant-rules
#import "./fonts/quotes.typ": quote-rules
#import "./fonts/super-sub.typ": super-sub-rules
#import "./fonts/underline.typ": underline-rules
#import d.fonts: tracking-pad
#import d: document as _core-document, options as _core-options
#import d: settings as _core-settings
#import "./layout/engine.typ": resolve as _resolve-layout
#let units = d.units
#let content = d.content
#let errors = d.errors
#let runs = d.runs
#let table = d.table
#let numbering = d.numbering
#let _setting-keys = ("html-paragraph-auto-spacing", "adjust-line-height-in-table", "default-tab-stop")
#let _numbering-keys = d.numbering.format-keys
#let options(..args) = {
  if args.pos().len() > 0 { panic("options: expected named arguments only") }
  let values = _font-options.checked(args.named())
  let core = _core-options(..values.pairs().filter(((k, _)) => k not in (_font-options.keys + _setting-keys + _numbering-keys)).to-dict())
  let settings = _core-settings(..values.pairs().filter(((k, _)) => k in _setting-keys).to-dict())
  let numbered = d.numbering.check-format(values.pairs().filter(((k, _)) => k in _numbering-keys).to-dict())
  core + settings + numbered + values.pairs().filter(((k, v)) => k in _font-options.keys and v != auto).to-dict()
}
#let document(lay, sheet, f, rules: it => it, ..args) = context {
  let values = args.named().at("options", default: (:))
  if type(values) != dictionary { panic("document.options: expected a dictionary, found " + repr(values)) }
  let values = options(..values)
  _font-options.apply(values)
  let core-options = (enum-hanging: false, list-hanging: true) + _core-options(
    ..values.pairs().filter(((k, _)) => k not in (_font-options.keys + _setting-keys + _numbering-keys)).to-dict())
  let settings = values.pairs().filter(((k, _)) => k in _setting-keys).to-dict()
  let numbered = values.pairs().filter(((k, _)) => k in _numbering-keys).to-dict()
  let extra-settings = args.named().at("settings", default: (:))
  if type(extra-settings) != dictionary { panic("document.settings: expected a dictionary") }
  let forwarded = args.named() + (options: core-options,
    settings: settings + _core-settings(..extra-settings),
    numbering: numbered + d.numbering.check-format(args.named().at("numbering", default: (:))))
  fontset-state.update(f)
  probes.update(probe-all(f.families))
  let resolved = resolve-tree(sheet, f)
  styles-state.update(resolved)
  let typography(doc) = {
    show math.equation: set text(font: f.math)
    show raw: set text(font: f.mono)
    show raw: set text(..mono-text-em(sheet.body.size, f.families.mono, f.metrics.mono))
    show raw.where(block: true): it => block(width: 100%, it)
    show: hant-rules.with(f)
    show: quote-rules.with(latin-font: f.serif)
    show: super-sub-rules
    show: underline-rules
    show: _fake-rules
    show: _typography.with(resolved.body)
    show emph: it => tracking-pad(kaishu(it.body, italic: true), probe: it.body)
    rules(baseline-rules(doc))
  }
  _core-document(_resolve-layout(lay, f), defaults: native-format(resolved.body),
    rules: typography, ..forwarded, ..args.pos())
}
