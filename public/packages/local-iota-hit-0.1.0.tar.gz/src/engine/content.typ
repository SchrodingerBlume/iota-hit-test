// 内容里的字面文字，以及「这一段有没有汉字」。
//
// *住在这里而不是 part.typ*：src/engine/tracking.typ 也要用（强调那个补丁只对汉字
// 强调该发，见那里），而 part.typ 是*它的*下游——import 反过来会成环。
// part.typ 把这两个再导出一次，写 part.has-cjk 的地方一个字不用改。

// 这一段有没有汉字。收中日韩统一表意文字、中文标点、全角形式三块——
// 只要有一个，行盒就得按中易算。
#let has-cjk(s) = s.clusters().any(ch => {
  let n = str.to-unicode(ch)
  // 换行会把表达式拆断，整串包在括号里
  (
    (0x4E00 <= n and n <= 0x9FFF)
      or (0x3000 <= n and n <= 0x303F)
      or (0xFF00 <= n and n <= 0xFFEF)
  )
})

// 标题里手动换的行折掉。
//
// *markup 里的「\ 」是两个元素*：linebreak 之后还跟着一个 space（实测
// `[研究\ 与实现]` ＝ sequence([研究], linebreak(), [ ], [与实现])，写成行末的「\」
// 加换行也一样）。只把 linebreak 折掉，那个空格就留在了字里——先前目录、页眉、书签、
// plain() 读出来的都是「研究 与实现」，中间多一个空格；范例的目录条目是直接接上的。
// 汉字之间的换行折掉不留空格，西文之间折成一个空格（「Design of the Thing\ and」
// 本来就该有空格）：看换行两边紧挨着的字，任一边是汉字就不留。
//
// *只折 justify: false 的*：#tocbreak() 换出来的那一种带 justify: true，目录要它换行，
// 见 src/engine/marks.typ 的 replace-tocbreak。
// 收内容或内容数组（sequence 的 children），返回同类型；不进 styled / 别的元素的里面。
#let _edge(c, last) = {
  // 元素两头的那个字（用来判两边是不是汉字）；空串＝看不出来
  if c == none { return "" }
  if type(c) == str { return if c == "" { "" } else if last { c.clusters().last() } else { c.clusters().first() } }
  if type(c) != content { return "" }
  if c.func() == [ ].func() { return " " }
  if c.has("text") and type(c.text) == str { return _edge(c.text, last) }
  if c.has("children") {
    let ch = c.children
    return if ch.len() == 0 { "" } else { _edge(if last { ch.last() } else { ch.first() }, last) }
  }
  if c.has("child") { return _edge(c.child, last) }
  if c.has("body") { return _edge(c.body, last) }
  ""
}
#let _is-space(c) = type(c) == content and c.func() == [ ].func()
#let _is-fold(c) = (
  type(c) == content and c.func() == linebreak and not c.at("justify", default: false)
)
#let fold-linebreaks(c) = {
  if type(c) == array {
    let out = ()
    let i = 0
    while i < c.len() {
      let x = c.at(i)
      if not _is-fold(x) { out.push(fold-linebreaks(x)); i += 1; continue }
      // 折掉换行；两侧的 space 也吃掉，再按两边的字决定补不补一个空格
      while out.len() > 0 and _is-space(out.last()) { let _ = out.pop() }
      i += 1
      while i < c.len() and _is-space(c.at(i)) { i += 1 }
      let before = _edge(if out.len() > 0 { out.last() } else { none }, true)
      let after = _edge(if i < c.len() { c.at(i) } else { none }, false)
      if before != "" and after != "" and not has-cjk(before) and not has-cjk(after) { out.push([ ]) }
    }
    return out
  }
  if type(c) != content { return c }
  if c.has("children") { return fold-linebreaks(c.children).join() }
  c
}

#let plain(c) = {
  if c == none { return "" }
  if type(c) == str { return c }
  if type(c) != content { return "" }
  // *markup 里的空格自成一个元素*（[a b].children ＝ text, space, text），
  // 它一个字段都没有，落到最后那一行就成了空串——「School (Department)」读出来
  // 是「School(Department)」，报告首页那一格照着排，空格就没了。空格是字面文字
  // 的一部分，读出来就得有
  if c.func() == [ ].func() { return " " }
  // *智能引号也是字面文字。* 它是个 smartquote 元素，没有 text 字段，
  // 先前落到最后那一行成了空串——「Bachelor's Thesis」读出来是「Bachelors
  // Thesis」，封面照它折行就把撇号折没了，书签与英文标题的大小写也一样丢。
  // 方向由排版时的上下文定（见 src/blocks/quotes.typ），这里取闭合那一个：
  // 撇号就是它，成对的引号读出来是左右哪一个不影响谁在用这个函数
  if c.func() == smartquote { return if c.double { "”" } else { "’" } }
  // *text 这一格不一定是字符串*——有的元素把内容放在同名的字段里
  // （实测走到过一个 text 是内容的元素，has-cjk 拿到内容序列当场炸）。
  if c.has("text") {
    let t = c.text
    return if type(t) == str { t } else { plain(t) }
  }
  // *空的 children 要单独接住*：Typst 里 ().join("") 给的是 none，不是 ""，
  // 上一层再 join 一次就把整串变成了内容序列，has-cjk 当场炸（element sequence
  // has no method `clusters`）。
  // *styled 元素（set 过的一段内容）要往 child 里走。* 词条页标题的正文槽就是
  // 一个 styled(child: [Contents])——页眉拿它判「这一行是不是纯西文」，不进去就读到
  // 空串，纯西文的页眉抬不上去。
  if c.has("child") { return plain(c.child) }
  if c.has("children") {
    // 手动换行折掉再读，见 fold-linebreaks
    let parts = fold-linebreaks(c.children).map(plain)
    return if parts.len() == 0 { "" } else { parts.join("") }
  }
  if c.has("body") { return plain(c.body) }
  ""
}


// 这一段排出来是不是*纯西文段*——整段换西文行盒的判据（src/engine/styles.typ 的
// latin-auto）。「有 ASCII 可见字符、没有汉字」之外还有一条：
//
// *弯引号、破折号、省略号、间隔号跟着段里的字母走。* 这几个码位 Word 叫 ambiguous，
// 归哪副字看 run 上的 w:hint——中文输入法打出来的一律 eastAsia，排的是中文字（字体表
// 里也归中易，见 src/config/fonts.typ 的 covers），行盒随之是汉字那一份。深圳中期
// 原件 24 个省略号 23 个带 eastAsia，「2. ……」那样的段落量得 19.5（宋体 1.25 倍），
// 先前按「有 ASCII、没汉字」把它当成纯西文段排成 17.25，第四章从那一行起整页往上
// 错 0.9。Typst 里没有 hint 可读，就按段里*有没有拉丁字母*判：一句英文里夹的「…」
// 是英文的（Times、西文行盒），一段光是数字、标点加省略号的是中文的。只有 ASCII
// 的段（英文表单里那几行「.......」、一行年份）照旧是西文段——ASCII 在 Word 里不看
// hint，总归 ascii 那副字。
#let latin-only(s) = (
  s.match(regex("[!-~]")) != none
    and not has-cjk(s)
    and (
      s.match(regex("\p{Latin}")) != none
        or s.match(regex("[\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}]")) == none
    )
)

// 这一段*读起来是不是中文的*——汉字占比过半就算。
//
// *与 has-cjk 是两个问题。* 那一支答「有没有汉字」，用来决定行盒按哪一档算
// （有一个就得按中易）；这一支答「这句话是哪国话」，用来判「英文目录里这一条是不是
// 忘了给英文名」。混用会两头出错：
//
//   Research on 汉字 Recognition   有汉字，但*是英文标题*——按 has-cjk 判会误报
//   基于 CNN 的方法                有拉丁字母，但*是中文标题*——按「有没有拉丁
//                                  字母」判会漏报
//
// *只数汉字与拉丁字母，空白与标点不计入分母*——「第 1 章：绪论」里的空格、
// 冒号既不说明它是中文也不说明它是英文，算进去只会稀释判据。
//
// *阈值取「过半」*，不开成选项：它有个说得出口的含义——这一条读起来是中文的。
#let cjk-ratio(s) = {
  let cs = s.clusters()
  let cjk = cs.filter(has-cjk).len()
  let latin = cs.filter(ch => {
    let n = str.to-unicode(ch)
    (0x41 <= n and n <= 0x5A) or (0x61 <= n and n <= 0x7A)
  }).len()
  if cjk + latin == 0 { 0.0 } else { cjk / (cjk + latin) }
}
