// 报错文案。*照 Typst 原生的写法*，实测抓下来的几条：
//
//   expected integer, float, length, angle, ratio, fraction, or decimal, found string
//   expected "ascender", "cap-height", "x-height", "baseline", "bounds", or length
//   expected length, found content
//   dictionary does not contain key "b" and no default value was specified
//   array index out of bounds (index: 5, len: 2)
//   unknown variable: nope
//   unexpected argument: nope
//   duplicate key: a
//   label `<nope>` does not exist in the document
//   file not found (searched at /……/nope.png)
//
// 归纳出四条：*全小写开头、句末不加句点*；枚举写「a, b, or c」，*两项时
// 不加逗号*；字符串值用 repr 引起来，auto / none / 类型名不引；附带的细节放进
// 括号，写成「key: value」。
//
// *一处与原生不同，是有意的。* 原生的 found 报的是*类型*
// （found string），因为它那几处是类型对不上；我们这几处类型是对的、*值*
// 不在集合里（degree-level 收到 "phd"），报类型等于什么也没说。所以 found 报值。
// 形状不动，信息才落得下来。
//
// *提示只能写进句子里。* 原生的 hint: 那一行是编译器自己发的，用户代码里
// panic / assert 发不出来；所以「要原样排就写成内容」这类话跟在括号里。

// 「a」「a or b」「a, b, or c」。items 是*已经成品*的字符串——auto 与
// none 不引号，字符串值引，两种混在一张表里的时候由调用方自己决定。
#let one-of(items) = {
  if items.len() < 2 { return items.join("") }
  if items.len() == 2 { return items.join(" or ") }
  items.join(", ", last: ", or ")
}

// 值域不对：expected "bachelor", "master", or "doctor", found "phd"
#let expected-one-of(allowed, found) = (
  "expected " + one-of(allowed.map(repr)) + ", found " + repr(found)
)
