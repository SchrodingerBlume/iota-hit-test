// 字体解析与探针。预设、角色表与标定常数*只放值*，住在 src/config/fonts.typ；
// 这里是拿它们干活的机制：resolve、probe-all、baseline-rules 与四个中文字族的入口。

#import "./errors.typ" as _errors
#import "./constants.typ": cjk-run, role-features, role-tags, latin-run as _latin-run, latin-slot-run
#import "./settings.typ" as _settings
#import "../config/fonts.typ": (
  presets, default-preset, hant-only, zh-roles, en-roles, roles,
  ink-anchor, ink-anchor-hant, baseline-reference, fake-roles, fake-bold-coef, fake-italic-angle,
  mono-metrics, ascent-const, exact-first-ratio,
)

// ── 代码的字号与行盒 ──────────────────────────────────────────────
//
// 字号照 fontspec 的 [Scale=MatchLowercase]：把等宽字体缩到 x 高与周围的西文字一样，再取到
// Word 的半磅格（Word 的字号框收半磅）。正文字号无论多少都成立，小四对 Consolas 是 11、
// 对 Menlo 是 10。
//
// *量「x」的墨迹（top-edge: "bounds"），不读 x-height 那个度量。* 多数字体两者一模一样
// （Times 0.4473、Consolas 0.4902、Menlo 0.5469 逐个对上 OS/2 的 sxHeight），可*有的字体
// 压根没写这一格*：Typst 自带的 DejaVu Sans Mono（webapp、typst 两档的等宽）读 x-height、
// cap-height、ascender 拿到的是同一个 0.7598，照它缩，代码成了 7pt——实测那两档「u」的墨高
// 3.92，只有 Consolas 那档 5.49 的七成。墨迹是画出来的，没有读不到这一说。
//
// 量的是*实际排上的那副字*：没装那副等宽字体的机器上量到的是回落字体的，字号跟着它缩。
// *要在 context 里调*
#let x-height(family) = (
  measure(text(font: family, size: 100pt, top-edge: "bounds", bottom-edge: "baseline")[x]).height / 100pt
)
#let mono-size(size, serif, mono) = calc.round((size * x-height(serif) / x-height(mono)) / 0.5pt) * 0.5pt

// 等宽字体的单倍行高与上升部（每 em）：表里有的取 Word 量的数（src/config/fonts.typ 的
// mono-metrics），没有的按 Typst 读得到的上升部与下降部之和算——差的只是行间隙，多数等宽
// 字体是 0。收家族名或一串（mono-table 那一串），按头一个查。*要在 context 里调*
#let mono-line(mono) = {
  let family = if type(mono) == array { mono.first() } else { mono }
  let known = mono-metrics.at(str(family), default: none)
  if known != none { return known }
  let edge(top, bottom) = measure(text(font: mono, size: 100pt, top-edge: top, bottom-edge: bottom)[x]).height / 100pt
  (natural: edge("ascender", "descender"), ascent: edge("ascender", "baseline"))
}

// 代码那一档的 text 设定：字号照 mono-size，行盒是等宽字体自己的单倍行高（Word 的「单倍
// 行距」），上升部落在 ascent × 字号 ＋ ascent-const 上、余下的是行深——与正文行盒同一个
// 模型（src/engine/styles.typ 的 _ascent-of），只是系数换成等宽字体的。行内代码同一套：
// 它的行盒比正文的矮（11pt Consolas 单倍 12.9，小四中易 1.25 倍 19.45），Word 那条「行高取
// 各 run 最高的」下不撑行，Typst 也一样。*要在 context 里调*
#let mono-text(size, serif, mono) = {
  let s = mono-size(size, serif, mono)
  let m = mono-line(mono)
  let ascent = m.ascent * s + ascent-const
  (size: s, top-edge: ascent, bottom-edge: -(m.natural * s - ascent))
}

// 同一件事写成 em，给 show raw: set text 用（show-set 到得了代码包重排的输出，show 规则到
// 不了）。字号的倍数按 body 那一档算：正文里的代码正好落在半磅格上，别处的行内代码按周围
// 字号等比缩。*除掉 Typst 给 raw 的那 0.8*：它那句 set 在外层先折，我们这句 em 是在它折过
// 之后算的。上升部那 0.082pt 是绝对量，照 _ascent-of 那条不随字号缩。
//
// *行距跟正文那一档的行距设定*（line-spacing：倍数、"single" / "double"、(exactly: 长度)），
// 不是单倍：Word 里把代码贴进论文，那一段继承的就是正文的行距——小四正文 1.25 倍，Consolas
// 11 一行 1.25 × 1.1709 × 11 ＝ 16.1，与英文摘要（1.25 × 1.15 × 12）同一个模型；硕博本部
// 报告固定值 21 磅，代码也是 21。倍数多出来的落在基线之下（不贴网格那一支，见 styles.typ
// 的 _ascent-of）；固定值基线在盒顶下 0.8 倍盒高（exact-first-ratio）。先前按单倍排，太矮
// 行盒的两条边，em 按*这个 text 自己*的字号解（字号由 mono-text-em 的 size 折过了）。
// 行距那一档的写法与正文同：倍数、"single" / "double"、(exactly: 长度)
#let mono-edges-em(mono, line-spacing) = {
  let m = mono-line(mono)
  let ls = if line-spacing == "single" { 1.0 } else if line-spacing == "double" { 2.0 } else { line-spacing }
  if type(ls) == dictionary and "exactly" in ls {
    let box = ls.at("exactly")
    (top-edge: exact-first-ratio * box, bottom-edge: -(1 - exact-first-ratio) * box)
  } else {
    let ls = if type(ls) in (int, float) { float(ls) } else { 1.0 }
    (
      top-edge: m.ascent * 1em + ascent-const,
      bottom-edge: -(ls * m.natural - m.ascent) * 1em + ascent-const,
    )
  }
}

// *全篇那一条给单倍*，1.25 那一份由我们自己排代码行时再加（src/blocks/listing.typ 的
// _lines）。codly / zebraw 这类包量我们的行盒去定它们自己那些框的高、再各加一份自己的
// 行距：给它们 1.25 的盒子，一行就成了 21.6（我们自己排是 16.1），右上角那块语言标签也
// 跟着涨——它的高正是量出来的行盒加内边距。给单倍它们才排得对
#let mono-text-em(body, serif, mono, line-spacing: 1) = {
  let k = mono-size(body, serif, mono) / body / 0.8
  (size: k * 1em, ..mono-edges-em(mono, line-spacing))
}

// 这副楷体是不是只有繁体字形，查 src/config/fonts.typ 的 hant-only
#let is-hant-only(family) = lower(str(family)) in hant-only

// 西文那一份的字体表。两条 covers 是整个包的不变量，由这里统一加，
// 不交给用户写——漏了的话「“」「”」「—」「…」会全被西文字体接走。
// universal-hit-thesis 的 宋体: ("Times New Roman", "SimSun") 就没写，
// 它的中文引号是 Times 的窄字形。
//
// 前一条单挑短横线 U+2013：它是西文的数字范围号（pp. 12–34、400–700 nm），
// "latin-in-cjk" 没收它，中易那一份会把它排成全宽，看着像破折号。
//
// *破折号 U+2014 按 em-dash 定*："cjk" 留给中易（先前唯一的做法），"latin" 与短横线
// 一道交给西文字体——Times 的杠两头出头、「——」连成一条，中易宋体的中间断一截。
// Word 按 run 的 hint 两样都排，各分支跟各自原件，见 src/config/settings.typ 的
// em-dash-auto。引号、省略号、间隔号不动，仍归中易。
#let latin-entries(family, em-dash: "cjk") = (
  (name: family, covers: regex(if em-dash == "latin" { "[\u{2013}\u{2014}]" } else { "\u{2013}" })),
  (name: family, covers: "latin-in-cjk"),
)

// 这些字在中文里是*全宽*的，但 Typst 的 "latin-in-cjk" 会把它们收走，
// 排成西文的半宽。所以在西文那两条之前先把它们抢给中易。
//
// 实测：范例封面里的「↑」Word 排 SimSun 12.0（全宽），我们排 Times 6.0；
// 「□」Word 排 SimSun 18.0，我们排 Times 10.872。
//
// 眼下收两段一个字：箭头 U+2190–U+21FF、几何图形 U+25A0–U+25FF，加上乘号
// U+00D7。这是*按需扩充的清单*，不是按 East_Asian_Width=Ambiguous 一刀切
// ——那一刀会把 ÷ ° § ‰ 也划过来。往后碰到别的全宽符号再往这里加。
//
// *乘号这一条 Word 自己两头不一致*，收进来是取了内封那一头：
//
//   内封「国内图书分类号：××××」 run 写着 w:hint="eastAsia" → 宋体全宽
//   正文「×10⁻⁴」                run 没有 rFonts、无 hint    → Times 半宽
//
// Word 靠逐 run 的 hint 分，Typst 没有这一层，只能一刀切。取全宽那一头，代价
// 是正文里写字面的「×」会排成全宽——公式里写 $times$ 走数学字体，不受影响。
// （hithesis 取的是另一头：把乘除号声明进 xeCJK 的半角标点类，见
// src/utils/hit-format.dtx。）
#let cjk-first = regex("[\u{00D7}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}]")

// *汉字先由本角色的中文字体认领，再轮到西文。* Typst 的 "latin-in-cjk" 只把
// 中文标点（“”‘’—…·–）让出去，*汉字本身不在它的排除之列*——西文家族是 Times
// 时看不出来，因为 Times 没有汉字，自然落到后面的中文字体上；可 serif 换成
// 一副中文字体（fontset: presets.windows + (serif: "STXingkai")），整行汉字就
// 全排成行楷了（实测 Kaiti SC 当 serif，「汉字 Latin 123 混排。」整行楷体）。
// 所以每张字体表在西文条目*前面*加一条只管汉字的本角色条目。对 Times 那几档
// 这一条不改任何字形的归属：汉字本来就落在它身上。
#let cjk-scripts = regex(
  "[\p{Han}\p{Hiragana}\p{Katakana}\p{Hangul}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}]"
)
#let cjk-claim(family) = if type(family) == array {
  family.map(f => (name: f, covers: cjk-scripts))
} else { ((name: family, covers: cjk-scripts),) }

// 一个中文角色排汉字时依次试哪几个家族。
//
// *楷体_GB2312、隶书、新魏三个角色有回落链，别的角色只有自己。* 楷体_GB2312 与隶书
// 在垂直度量上与中易那一族同源（见 src/config/fonts.typ 的 zh-roles 那一段），缺了
// 回落到楷体只换字形，行高与落点一点不动；再多兜一层宋体。新魏与隶书同一个办法。
// 只有繁体字形的楷体不进链（webapp 那一档的教育部标准楷书），理由见 mono-table。
//
// *凡是把角色落成 text.font 的地方都走这一个口*：resolve 的表、styles.typ 的
// font()、下面的 _use。先前那三条链只写进了 resolve 的表，而落字体的两处各自从
// 原始角色表重拼、只拼本角色一个名字——缺字体时 Typst 落到系统全局兜底，实测本机
// 把报告首页的校名排成 SIL-Hei-Med-Jian，既不是楷体也不是宋体。
#let role-chain(r, role) = {
  let own = r.at(role)
  let head = if type(own) == array { own } else { (own,) }
  let kai = if is-hant-only(r.kaishu) { () } else { (r.kaishu,) }
  let tail = if role == "kaishu-gb2312" { (r.kaishu,) }
    else if role in ("lishu", "xinwei") { kai + (r.songti,) }
    else { () }
  head + tail.filter(f => f != none)
}

// 西文那三个角色（serif / sans / mono）的字体表。
//
// *末尾必须挂宋体。* Word 的每个 run 都有*两槽*——「西文字体」与
// 「中文字体」；英文题那一行的 run 是 ascii="Times New Roman" eastAsia="宋体"，
// 里头写汉字，Word 排的就是宋体。先前这三个角色只填了西文那一槽，汉字落进
// Typst 的系统兜底：实测 #en[… 气体 …] 在本机排成了 Klee（一款楷体），
// 既不是宋体也不跟字体档走。
//
// 三条的次序：全宽符号（「↑」「□」「×」）先由宋体抢走，再是西文家族本身，
// 最后宋体接住西文字体没有的一切——汉字与中文标点都在这一档。
#let latin-table(r, role) = (
  (name: r.songti, covers: cjk-first), ..cjk-claim(r.songti), r.at(role), r.songti,
)

// 代码那一档的字体表。
//
// *汉字要有归宿。* 先前 mono 这个角色根本没人用（全项目一处 set raw 都没有），
// 代码里的中文落到 Typst 的全局兜底上——实测排出来是 LiSu（隶书），随手抓的。
//
// *顺序是仿宋 → 楷体 → 宋体。* 仿宋在中文排版里就是「引文、代码、注记」这类
// 与正文拉开一点距离的字，字面比楷体规整、比宋体轻；楷体是它不在时最接近的一档；
// 宋体兜底，那是任何一档预设都有的。缺哪一档 Typst 自己跳过，不必我们探。
//
// *不加「全宽符号抢回中易」那一格*，与 latin-table 相反：那一格是把「×」「←」
// 从西文字体抢回中易的，在*正文*里对；代码里它们该由等宽字体出，等宽才对得齐。
//
// *西文那一截走角色表里的 mono*，改它就生效。五档预设一律给
// 各平台自己的等宽，所以*默认排出来与不接这条链时相同*
// ——先前这里写死了那个家族名，角色就成了死配置，用户改 mono 一点反应没有。
//
// *只有繁体字形的楷体不进这条链。* webapp 那一档的楷体是教育部标准楷书
// （TW-MOE-Std-Kai），它*只有繁体字形*——落到它头上，代码里的简体字要么缺字、
// 要么排成繁体。#kaishu[] 那一路是配 zhconv 转字才用得上它（见 is-hant-only 与
// src/engine/hant.typ）；代码不转字，也不该转。所以这里把它跳过，直接退到宋体。
#let mono-table(r) = (
  // *mono 收一个家族，也收一串。* 想把代码的中西文一并换成自己那一套，
  // 又不动 fangsong——仿宋就是仿宋，正文里 #fangsong[] 还要用它——就写成串：
  //
  //     fontset: presets.windows + (mono: ("Latin Modern Mono", "FZFangSong-Z02"))
  //
  // 串里的排在最前，中西文都由它们说了算；后面那几格照旧兜底，缺字才落下去。
  ..(if type(r.mono) == array { r.mono } else { (r.mono,) }),
  r.fangsong,
  ..(if is-hant-only(r.kaishu) { () } else { (r.kaishu,) }),
  r.songti,
)


// 传错东西时把话说清楚。写错角色名是*静默失效*（不报错也不生效），
// 所以这道校验是必须的。
#let _check(value) = {
  if type(value) == str {
    assert(
      value in presets,
      message: _errors.expected-one-of(presets.keys(), value),
    )
    return presets.at(value)
  }
  if type(value) != dictionary {
    panic("expected string or dictionary, found " + str(type(value))
      + " (a preset name, or a table of font roles)")
  }
  let stray = value.keys().filter(k => k not in roles)
  if stray.len() > 0 {
    panic("unexpected font role: " + stray.join(", "))
  }
  value
}

// 档名或角色字典 → 字体表。字典是在默认档上逐个覆盖，没写的不动。
//
// *auto ＝ 不写 ＝ 默认档*，与包里别处的三态同义——先前 auto 会一路撞进
// _check 报「expected string or dictionary, found auto」，而默认档名同时被 lib.typ
// 抄了一份。收下 auto 之后那份抄本就没了
// em-dash：破折号排哪一副字，"cjk" / "latin"，由 iota-hit 按分支解好传进来
// （src/engine/settings.typ 的 resolve-em-dash）；值随表一起存进 current，
// 中途换角色的那几个入口（_use）从表里读
#let resolve(value: auto, em-dash: "cjk") = {
  let value = if value == auto { default-preset } else { value }
  let r = presets.at(default-preset) + _check(value)
  let latin = latin-entries(r.serif, em-dash: em-dash)
  // 全宽符号先抢给中易，再排西文那两条，最后才是中文家族本身
  // *全宽符号那一格一律给宋体，不给本角色的家族。* 「□」「↑」是无字符集
  // 归属的字，Word 按 w:hint="eastAsia" 判给 eastAsia 槽，而全文的 eastAsia 默认
  // 是宋体——黑体标题里的「□」在 Word 里也是宋体的。先前这里写 cjk（本角色的
  // 家族），于是黑体行的「□」跟着变黑体。
  let table(role) = {
    let chain = role-chain(r, role)
    ((name: r.songti, covers: cjk-first), ..cjk-claim(chain), ..latin, ..chain)
  }
  // 黑体那一份的西文也走 serif。hithesis 里换成无衬线是 heading/font-en=sans
  // 那个兼容桥（原 arialtitle 选项）在管，默认关着，所以这里跟着 serif。
  (
    songti: table("songti"),
    heiti: table("heiti"),
    kaishu: table("kaishu"),
    kaishu-gb2312: table("kaishu-gb2312"),
    fangsong: table("fangsong"),
    lishu: table("lishu"),
    xinwei: table("xinwei"),
    serif: latin-table(r, "serif"),
    sans: latin-table(r, "sans"),
    mono: mono-table(r),
    math: r.math,
    latin: latin,
    // 破折号那一档，供 _use 重建字体表时用
    em-dash: em-dash,
    // 原始的角色表，需要按家族名判断时查它（比如楷体是不是只有繁体字形）
    families: r,
  )
}

// ── 探针：问字体两个问题 ────────────────────────────────────────────
//
// Typst 自己*从不合成*粗体与斜体：要的那一面没有就静默换成最近的一面
// （文档原话：weight 取「closest in weight」，style 取 normal）。所以「这个字体
// 有没有真粗」问不出来——除非自己量。
//
// 办法是把字重推到 701 再量*墨迹*（top-edge / bottom-edge 取 "bounds"）：
// 动了就是换到了另一面，没动就是回落到了同一面。做法与 cutix 同源。
//
// *要在 context 里调*
#let _PROBE-SIZE = 100pt
#let _EPS = 0.01
#let _cjk-probe = ("一", "二")

// *只问这一个家族，且关掉回落*。带着整串字体去问是问不出来的：要的字重
// 这个家族没有，Typst 会跨家族回落到*别人的*粗体面，墨迹一动就被判成
// 「有真粗」（实测宋体就是这么误判的）。
#let _ink(body, family, weight, style: "normal") = {
  let m = measure(text(
    font: (family,), fallback: false, size: _PROBE-SIZE, weight: weight, style: style,
    top-edge: "bounds", bottom-edge: "bounds", body,
  ))
  (m.width.pt(), m.height.pt())
}

// 这个家族有没有真粗体
#let has-real-bold(family) = _cjk-probe.any(c => {
  let a = _ink(c, family, "regular")
  let b = _ink(c, family, 701)
  calc.abs(a.at(0) - b.at(0)) > _EPS or calc.abs(a.at(1) - b.at(1)) > _EPS
})

// 这个家族有没有真斜体面。同一个办法：把 style 推到 italic 再量墨迹——Typst 也不合成
// 斜体，没有斜体面就静默用常规面，墨迹不动
#let has-real-italic(family) = _cjk-probe.any(c => {
  let a = _ink(c, family, "regular")
  let b = _ink(c, family, "regular", style: "italic")
  calc.abs(a.at(0) - b.at(0)) > _EPS or calc.abs(a.at(1) - b.at(1)) > _EPS
})

// 这个家族排不排得出汉字。
//
// *关掉回落再量*——缺字时 Typst 会静默换字体，量出来照样有宽度，问不出
// 「这个家族在不在」。关掉之后缺字宽度是 0（实测装了的 KaiTi / SimSun 出 200pt，
// 没装的 TW-MOE-Std-Kai 出 0pt）。
//
// *代价*：家族真的不存在时 Typst 会打一条 unknown font family 的警告，
// 这个探测会把它提前引出来——今天只有排到那一处才出现，往后每篇都会出现一次。
#let family-usable(family) = {
  measure(text(font: family, fallback: false, size: _PROBE-SIZE)[一二]).width > 0pt
}

// 小于这个就当没有。中易那四档自己探出来与基准*完全相等*，本该得 0；
// 可基准若写成四舍五入的 0.36133，差出来的 1.9e-6 em 也不是 0，那两条规则照发，
// 中西文的基线就差了个微米——量基线的那一步当场把一行看成两行（实测
// check-mixed 报「步进 -0.000040」）。基准取精确值之后这一步用不上了，
// 留着是给用户自己指定的家族兜底：0.001em 在 12pt 下是 0.012pt，肉眼与打印
// 都不存在，不值得为它多发两条 show 规则。
#let _baseline-eps = 0.001

// 锚字的墨迹中心离基线多高，折成 em。要在 context 里调
#let ink-center(family) = {
  // 只有繁体字形的那几副（教育部标准楷书）没有「国」，量它得用繁体那一个，见 ink-anchor-hant
  let anchor = if is-hant-only(family) { ink-anchor-hant } else { ink-anchor }
  let edge(top, bottom) = measure(text(
    font: (family,), fallback: false, size: _PROBE-SIZE,
    top-edge: top, bottom-edge: bottom, anchor,
  )).height
  (edge("bounds", "baseline") - edge("baseline", "bounds")) / 2 / _PROBE-SIZE
}

// 探测的结果：角色名 → 有没有真粗体。
//
// *在入口探一次，别到处现探*。探针是 measure，会*继承所在上下文*——
// 描边、字体列表、回落开关都继承。先前放在每个 #strong 当场做，于是同一个家族
// 在正文里探出「有真粗」、在别处探出「没有」，正文的粗体被在真粗面上又描了一圈
// （实测 webapp 档下 NotoSerifCJKsc-Bold 上还有一层 stroke_text）。
//
// 由 iota-hit 在函数体里写一次（那里是 context），排版时零成本查表。
#let probes = state("iota-hit-font-probes", (:))


// *run 边界丢多少字距，开机量一次。* Typst 把文本切成不同样式的 run 分别整形，
// 一个 run 末尾那个字的 tracking 不发（typst/typst#5353，2024-11 报的，维护者确认
// 「样式不同就切成不同的 shaping run，就会这样」，至今 open）。本包在五处补这份丢掉
// 的字距：西文 run 前、行内代码前、行内标记两侧、下划线两端、目录编号后。
//
// *不写死「丢一份」，量出来。* 量「ax」一体排与拆成两个 run 排的宽度差，除以
// 字距，得到丢的份数：现在的 Typst 是 1，上游哪天修了就是 0——五处补偿一起归零，
// 一行不用改，也不会在新版本上把字距补成双份。拆 run 靠两截不同的填色，与上游那条
// issue 里维护者给的复现同一个法子。两次 measure，与上面探真粗体的一个量级。
#let probe-boundary() = {
  let t = 4pt
  let one = measure(text(tracking: t, fill: black)[ax]).width
  let two = measure(text(tracking: t, fill: black)[a] + text(tracking: t, fill: rgb("#000001"))[x]).width
  calc.max(0, calc.min(1, (one - two) / t))
}

// 份数自己一份 state，不挤进 probes 那张按角色分的表——那张表的值是每个角色一条
// 记录（usable / bold / baseline），谁遍历它都按记录读，塞一个数进去就炸
// （tests/demo-ink.typ 先前就是这么红的）。入口与 probes 一起写，见 lib.typ
#let boundary-probe = state("iota-hit-boundary-loss", 1)

// 补偿量要乘的份数；探针还没写进来的地方（第一页页眉）按现在的 Typst 算
#let boundary-loss() = boundary-probe.get()

// 这一档中文角色*缺粗体面*：家族在这台机器上，而且没有真粗面。要在 context 里调，
// 查的是入口探好的那张表（probe-all），不当场探——当场探会继承上下文（描边、字体列表、
// 回落开关），同一个家族在不同地方答案不一样。
//
// *两个条件都要。* 家族不在时这一档的字由 Typst 的回落排，回落到哪一家我们无从知道，
// 那一家多半有真粗面。两路都问这一句：伪粗那一路（src/engine/synth.typ 的
// wants-bold-for）缺才描边；latin-bold 那一路（src/engine/styles.typ 的 shows）缺才敢
// 整段 set weight——汉字落空、只有西文换上真粗面。
#let lacks-bold(role) = {
  let p = probes.get().at(role, default: (usable: false, bold: false))
  p.usable and not p.bold
}
// 同一句话问斜体：#emph 那一路缺才敢整段 set style italic（楷体落空、Times 换上真斜体面），
// 见 src/engine/fonts.typ 的 kaishu
#let lacks-italic(role) = {
  let p = probes.get().at(role, default: (usable: false, italic: false))
  p.usable and not p.italic
}

// 把当前字体表探一遍。要在 context 里调。
//
// *只探吃伪粗的那几个角色*，不是四个中文角色都探。探针关着回落，家族没装
// 就会引出一条 unknown font family 的警告（见 family-usable）——探不吃伪粗的角色
// 是白探一次、白报一条：实测 fandol 那一档本机没装 FandolFang，整篇编译多出
// 一条「unknown font family: fandolfang」，而仿宋从来不吃伪粗。
// fake-roles 往后扩了，这里自动跟上。
#let probe-all(table) = {
  let out = (:)
  for role in zh-roles {
    let family = table.at(role)
    // *家族在不在，要先问一遍。* 不在的时候两次探针都量到 0，两个字重
    // 「一样」，has-real-bold 于是答「没有真粗」——可这一档的字根本不由它排，
    // Typst 早回落到别家去了，而那一家多半有真粗面，描上去就是双重加粗。
    // 实测：fontset 里写一个不存在的家族（No Such Song），探针答「没有真粗」，
    // 正文的加粗落在回落的 SIL-Hei-Med-Jian 上、仍被描了一圈。
    //
    // 这条路不难走到：默认的 fontset "windows" 在没装中易的机器上、模板写的
    // "fandol" 在没装 Fandol 的机器上，都是整档家族缺席。
    let usable = family-usable(family)
    out.insert(role, (
      usable: usable,
      // 家族不在就不必再探，省下的 measure 与 unknown font family 都是白花的。
      // *七个角色都探*，不只吃伪粗那四个：latin-bold 那一路要问「这一档中文字整段
      // set weight 会不会真的变粗」，见上面的 lacks-bold
      bold: if usable { has-real-bold(family) } else { false },
      italic: if usable { has-real-italic(family) } else { false },
      // *视觉矫正量*：把这一档的字挪到 Windows 同角色那一档的高度。
      // 负数是上移。家族不在时给 0——回落到哪一家我们不知道，按名义家族算出来
      // 的矫正量落在别人头上只会更歪。
      baseline: if usable {
        let d = ink-center(family) - baseline-reference.at(role)
        if calc.abs(d) < _baseline-eps { 0pt } else { d * 1em }
      } else { 0pt },
    ))
  }
  out
}


// 已解析的字体表。styles.typ 的 latin-par 与用户的扩展读它，不用把字体一路传下去。
// 做法学自 new-neu-thesis 与 ElegantBook 的 current。
#let current = state("iota-hit-fonts", resolve())

// *视觉矫正：全篇一条规则，只发给汉字 run，按当前实际用的字体查矫正量。*
//
// 要治的病：各家中文字把字画在基线之上多高各不相同，12pt 正文里 Songti SC 比中易
// 低 0.8pt。矫正量按角色探好（probe-all），差额发成 text.baseline——它只是绘制
// 偏移，不进行高。
//
// *为什么是一条、为什么只发给汉字。* 先前是每个部件各挂一份，对整段
// set text(baseline:)，再把西文 run 复位。两个毛病，都是泄露：
//
//   一、text.baseline *逐层累加*——box 自己也是行内项，也吃一份。实测同一段
//      字裸着挪 1 份、套一层 box 挪 2 份、套两层挪 3 份。凡是装在 box 里的都翻倍：
//      续表题注「表1-1（续表）」整行偏 1.456，英文目录条目的行盒被撑高（步进
//      17.250 → 20.578），页眉横线（它是 box）跟着掉 0.624。
//   二、复位够不着的都被拽走——页码「- 1 -」两头的连字符与空格（复位要求段里至少
//      一个字母），以及矫正量为 0 的部件（英文目录，一条规则都不发，外层那份漏
//      进来）。
//
// 只发给汉字 run（cjk-run），box、几何、西文根本不在匹配范围里；每个汉字 run 也
// 只被套一次。
//
// *为什么按字体查、不按部件的角色传。* 规则层层套着挂时，同一属性上外层赢
// （见 src/engine/styles.typ）——章标题（黑体）会拿到正文宋体那一份（实测 18pt 挪
// 1.2479，黑体自己该是 0.3040）。全篇只挂一条就没有嵌套；它读 text.font 的第一项
// （部件层 apply 写进去的家族）反推角色，拿到的必然是这段字自己的那一档。
//
// *同一家族顶两个角色时取排前面的那个。* webapp / typst 两档的宋体与仿宋都是
// Noto Serif CJK SC，按角色顺序先撞上 songti；两档的基准差 0.0195em（12pt 上
// 0.23pt），仿宋那点字（声明页一类）会按宋体的量挪。认了——比起漏一路，这点差
// 小两个量级，而且那副字本来就不是仿宋。
//
// *排在 current 之后*：它要读当前的字体表反推角色。
//
// *矫正量为 0 就什么都不做*，Windows 档与不做这件事时字节相同。
#let baseline-rules(doc) = {
  // *画汉字的是 text.font 里那个不带 covers 的中文家族。* 部件层的 font()
  // （src/engine/styles.typ）排的是「宋体（只管 □ 那类符号，带 covers）→ 西文 →
  // 本角色的家族」，角色家族在*最后*；正文那一份由 iota-hit 在最外层设，宋体
  // 在*最前*。位置不定，带不带 covers 才是定的：带 covers 的只管它圈出来的那
  // 几个字，汉字落不到它头上。先前取首项，标题、黑体行一律被认成宋体。
  // 给出 text.font 里第一个「不带 covers、且在字体表里是某个中文角色」的项对应的
  // 角色。西文那几项有的也不带 covers，光凭「不带 covers」会停在它们头上。
  //
  // *查的是 families，不是 current 顶层那几格。* 顶层 current.heiti 存的是整条
  // 回落链（首项还是那份带 covers 的宋体），families.heiti 才是裸的「Heiti SC」
  // ——src/engine/styles.typ 取角色家族用的也是 families。
  let role-of(f, families) = {
    let xs = if type(f) == array { f } else { (f,) }
    for x in xs {
      let name = if type(x) == dictionary {
        if "covers" in x { continue }
        x.at("name", default: none)
      } else { x }
      if name == none { continue }
      for role in zh-roles {
        let fam = families.at(role, default: none)
        if type(fam) == str and lower(fam) == lower(name) { return role }
      }
    }
    none
  }
  // 先认 text.features 里的角色标签（施加角色的地方都会写，见 constants.typ 的
  // role-tags）；没有标签的（用户自己 set 的字体）再按 text.font 反推。
  // features 是折叠属性，各层的标签都在；值为 1 的那个才是最里层写的（见
  // constants.typ 的 role-features）。数组形式的 features 没有值，一律不认。
  let tagged(fs) = {
    if type(fs) != dictionary { return none }
    for (role, tag) in role-tags { if fs.at(tag, default: 0) == 1 { return role } }
    none
  }
  show cjk-run: it => context {
    let role = tagged(text.features)
    if role == none { role = role-of(text.font, current.get().families) }
    let shift = if role == none { 0pt } else {
      probes.get().at(role, default: (baseline: 0pt)).baseline
    }
    if shift == 0pt { it } else {
      // *夹在汉字里的数字跟着汉字走，不单独归零。* 试过把数字挑出来归零：
      // show regex 每切一处就丢一份字距（src/engine/tracking.typ 记的原生行为），
      // 实测「共12页」共→1 从 15.4543 掉到 15.0000、2→页 从 9.4543 掉到 9.0000；
      // 两侧补 weak 间距更糟——Typst 给汉字与西文之间的 3pt 自动间距被那段 h() 顶
      // 掉，共→1 成了 12.9086。字符网格是这个包的脊梁，横向一份都不能丢。
      //
      // 代价：12pt 上数字的墨迹比 Windows 那一档高或低一份矫正量（Songti SC 0.83），
      // 但它与同一行的汉字仍共一条基线，Word 也是这么排的。没有汉字的段（页码、
      // 纯西文行）整个匹配不上，字母与数字都一份不吃。
      set text(baseline: shift)
      it
    }
  }
  doc
}

// ── 四个中文字族的入口 ──────────────────────────────────────────────
//
// *为什么要入口。* 模板内部凡是要某种字形的地方，都该按*角色*引用，
// 不写家族名——用楷体的地方写 kaishu，换字体档时自动全线跟上。这四个函数
// 就是那个引用方式，也给用户用。
//
// *latin 这个参数。* 一个中文字族排出来总要配一份西文：宋体配衬线，
// 黑体有时要配无衬线。取值是角色表里那三个西文角色，不是家族名——
// 一旦允许直接写家族名，这四个函数就成了绕过角色表的后门。
//
// 默认 serif。hithesis 里把标题西文换成无衬线是 heading/font-en = sans 那个
// 兼容桥（原 arialtitle 选项）在管，*默认关着*，所以这边也默认 serif。
// （modern-nju-thesis 的黑体默认配 Arial，与 hithesis 不同，我们跟 hithesis。）

#let _use(role, latin, body) = context {
  assert(
    latin in en-roles,
    message: _errors.expected-one-of(en-roles, latin)
      + " (to name a family directly, set the font on text instead)",
  )
  let cur = current.get()
  let f = cur.families
  let chain = role-chain(f, role)
  // 全宽符号那一格给宋体，理由同上面 table() 那一处
  set text(
    font: (
      (name: f.songti, covers: cjk-first),
      ..cjk-claim(chain),
      ..latin-entries(f.at(latin), em-dash: cur.at("em-dash", default: "cjk")),
      ..chain,
    ),
    // 角色写进 text，给视觉矫正认，见 src/engine/constants.typ 的 role-tags
    features: role-features(role),
  )
  // 视觉矫正*不在这儿发*：全篇只挂一条（lib.typ → baseline-rules），按 text.font
  // 反推角色——上面这个 set 把角色家族写进了 text.font，它就够得着。先前这儿自己
  // 发一份 set text(baseline:)，是整块生效的：包在里面的 box、几何跟着挪不说，
  // set page 的页眉页脚在正文样式里排，正文若整页套在 #heiti[…] 里，页脚的
  // 「- 1 -」和页眉横线也跟着掉一份（实测 0.624）。
  body
}

#let songti(latin: "serif", body) = _use("songti", latin, body)
#let heiti(latin: "serif", body) = _use("heiti", latin, body)
// 楷体这一个另有一档回落：*没有楷体时用伪斜的宋体*。
//
// 汉字没有斜体，强调历来是换字体——首选楷体（指南与 hithesis 都是），楷体也没有
// 才退到斜切。开关是 base 桶的 fake-italic，三态见 src/config/settings.typ：
//
//   auto   楷体在就用楷体，不在才斜切
//   true   一律斜切宋体，有楷体也不用（就想要斜的那档用户）
//   false  从不斜切：没楷体时排正体宋体，强调看不出来
//
// *只看楷体在不在，不看它是不是只有繁体*：教育部标准楷书虽然只有繁体字形，
// 配着转字规则仍是能用的一档（webapp 的现状），而用户手写的 #kaishu[…] 是*无
// 限集*，画不了轮廓，有它总比伪斜好。封面那一小把字是有限集，另走轮廓，见
// src/blocks/kaishu.typ
//
// *斜切只切汉字，西文再切回来。* 汉字没有斜体字面才要合成，西文有——回退这
// 一档里的西文该与*有楷体那一档一模一样*，因为西文根本不受「楷体在不在」影
// 响。先前整块一起切，于是 #emph[中文 Italic] 里的西文变成*真斜之上再切一
// 刀*：PDF 内容流里那个字形已经是 TimesNewRomanPS-ItalicMT，外面还套着一条
// c/d = +0.3327 ＝ tan(18.4°) 的切变矩阵。#kaishu[中文 English] 同理，那里的西文
// 本该是正体衬线，也被切成了假斜体。
//
// 办法与 src/engine/synth.typ 的伪粗同源：那边*整段描边、西文的 run 再把描边撤掉*，
// 这边整块斜切、西文的 run 再反向切回来。用的是同一条 latin-run，不另开正则
// （两个包各自重切同一段文本会互相吃掉字距，理由见 src/engine/synth.typ 开头）。
//
// *反向那一刀必须套 box*——实测不套的话西文会被拆到下一行（三段对照：
// skew[中A] 两个字都带 +0.3327 且同一行；skew[中 skew⁻¹[A]] 抵消了但断成两行；
// box(skew[中 box(skew⁻¹[A])]) 抵消且同一行）。外面那层 box 本来就有。
// italic：夹的西文要不要斜（#emph 那一路要，#kaishu[] 不要）。*走字体表那一层*：整段
// set style italic，中西两槽各自挑面——Typst 从不合成斜体（见 synth.typ 抬头），楷体没有
// 斜体面就静默用常规面，Times 换上真斜体面；数字、希腊字母、上下标一并斜，与 Word 的
// <w:i/>（run 级，不按字符脚本分档）同构。先前靠 show latin-run 包一层 italic，那条正则
// 要求有一个拉丁字母，#emph[2026]、#emph[αβγ] 连斜体都没有——与 src/engine/styles.typ
// 里 latin-bold 那一路同一个坑、同一个修法。门也同一条：这一档中文字有真斜体面（或家族
// 不在）就退回 show 规则，选择器换成字体表分槽的补集 latin-slot-run
#let kaishu(latin: "serif", italic: false, body) = context {
  let gate = _settings.setting-of("fake-italic")
  let family = current.get().families.kaishu
  let slant(role, body) = if not italic { body } else if lacks-italic(role) {
    set text(style: "italic")
    body
  } else {
    show latin-slot-run: set text(style: "italic")
    body
  }
  if gate != true and family-usable(family) {
    _use("kaishu", latin, slant("kaishu", body))
  } else if gate == false {
    _use("songti", latin, slant("songti", body))
  } else {
    // 没楷体：整块斜切，西文槽的 run 再反向切回来（它们有真斜体面，由 slant 给）——用的是
    // 字体表分槽的补集，纯数字、希腊字母也切回来；先前用 latin-run，#emph[2026] 被切了一刀
    box(skew(ax: fake-italic-angle, reflow: false, {
      show latin-slot-run: r => box(skew(ax: -fake-italic-angle, reflow: false, r))
      _use("songti", latin, slant("songti", body))
    }))
  }
}
#let fangsong(latin: "serif", body) = _use("fangsong", latin, body)
