// 论文元信息的机制：state、写入时的校验与读取。默认表（info-defaults）在
// src/config/info.typ，这里 import 来查。
//
// *一处填，各页读。* 封面、中文内封、英文内封印的是同一个题目、同一个
// 姓名；先前每个部件各自收参数，用户就得把题目抄三遍，改一处忘两处。
// 这里存进 state，各页从里面取——与 neu-typst-latest-cap-able 的 info-setup
// 同一个路子。
//
// *部件本身仍收显式参数。* 存进 state 的只是*默认值*：包装层把它们
// 填给部件，用户在调用处写的参数照样压过去。对拍件因此一行不用改——它们直接
// 调部件，根本不经过 state。

#import "../config/info.typ": info-defaults
#import "./date.typ" as _date

#let info-state = state("iota-hit-info", none)

// 哪几个字段是日期。*在写进来的时候就校*——报错指着用户那一行
// info(date: …)，比等到排封面时才炸在部件里好找。
#let date-fields = ("date", "defense-date", "defense-date-en")

// 行表里*一个字段的值*：按语言挑 info 的哪一份，日期走解析。
//
// *语言与字段身份是两回事*，所以在这一层统一贴——行表里不必逐行写
// author-en。写 -en 那一份的人少，没写就回落到原值：答辩日期只存一个 ISO，
// 中英各自排，不必存两遍。
//
// *只有日期字段走解析*。别的字段收到字符串是照排的——用户写
// author: "张三" 天经地义，不该被当成一个写坏了的日期。默认不把 lang 递给
// _date.render：日期跟 text.lang 走，各页自己设了语言。date-lang 给了才递——深圳
// 报告首页要拿 plain() 看这一格里有没有汉字来选行的度量，而跟 text.lang 走的日期是
// 个 context 块，plain() 看不进去；那一页自己设的 text.lang 就是它传进来的 lang。
//
// *内封与报告首页共用这一支*（src/pages/titlepage.typ 与 report/cover.typ
// 的行表）。先前报告那一页自己写了个简化版、少了 -en 那一步，于是*英文
// 报告封面的六格印的是中文值*——学院、导师、学科都是，只有题目单独特判过。
#let value-of(info, name, lang: "zh", date-lang: auto) = {
  let suffix = if lang == "en" { "-en" } else { "" }
  let v = info.at(name + suffix, default: auto)
  if v == auto { v = info.at(name) }
  if name in date-fields { _date.render(v, lang: date-lang) } else { v }
}

#let info(..fields) = {
  if fields.pos().len() != 0 {
    panic("unexpected argument")
  }
  for key in fields.named().keys() {
    if key not in info-defaults {
      panic("unexpected argument: " + key)
    }
  }
  for (key, value) in fields.named() {
    if key in date-fields and type(value) == str and _date.parse(value) == none {
      panic(
        "expected an ISO date such as \"2026\", \"2026-06\", or \"2026-06-05\", found "
          + repr(value) + " (write content like [" + value
          + "] to print it as given)",
      )
    }
  }
  info-state.update(old => {
    (if old == none { info-defaults } else { old }) + fields.named()
  })
}

// 取当前的元信息。要在 context 里调。
#let info-get() = {
  let v = info-state.get()
  if v == none { info-defaults } else { v }
}
