// 往标题正文里塞的*记号*，以及「不编号」那个标签。
//
// *一种机制几个用户。* Typst 的 heading 不收自定义字段，想给某一个标题
// 附加信息（这一章的英文名、这一章要不要右翻页），办法是往它的*正文*里
// 塞一个 metadata——不显示、不占位、也不造 text run 边界（实测 18pt 加 1pt
// 字距的居中标题，塞与不塞逐字步进都是 19.0、左右缘都是 162.500 / 237.500），
// 而 show 规则拿到 it.body 就能挖出来。
//
// 三个记号：
//
//   en         这一章的英文名。*开放给用户*
//   zh         这一章的中文名。*内部件*——#chapter 与 term-chapter 替
//              用户塞。有了它，两份名字对称，取哪一份只看语言
//   subs       这个图的分图题。*开放给用户*，写在 caption 里
//   continued  这是上一个表的续表。*开放给用户*，同样写在 caption 里
//   openright  这一章要不要从右手页起。*内部件*——用户走
//              #chapter(openright: …)，那个函数替他塞
//
// 还有一个不走 metadata 的：*标签 <-> 表示不编号*，见文件末尾的
// nonumber-rules。它拿 label 当开关，是 Typst 生态里的既成写法
// （show ….where(label: …) 就是给这种用法留的）。

// 给标题挂英文名。
//
// *要写在 label 前面：*
//
//     = 绪论 #en[Introduction] <chap:intro>
//
// Typst 里标题行一旦出现 label，label *之后*的内容就不算标题正文了。
// 实测三种写法的 heading.body：
//
//     = 甲 #en[A] <a>     body = sequence([甲], [ ], metadata(…))   ✓
//     = 乙 <b> #en[B]     body = [乙]                              英文名没了
//     = 丙 <c>#en[C]      body = [丙]                              英文名没了
//
// label 那一侧不受影响——三种写法查出来 label 都贴在 heading 上（不是贴在
// metadata 上），\@ref 也都正常。所以只要守住「先 en 后 label」这一条即可，
// 而这本来就是 Typst 写 label 的惯例。
//
// 写反了不报错，只是英文目录里少一条。
//
// *= 那条路只挂名字，不换正文槽。* 英文档里「哪一份上台」由 #chapter 的
// 函数式写法管（它把两份都存成记号，正文槽按语言取），markup 标题的正文槽是
// 一段裸文字，show 规则换不掉它又不丢 label——所以 = 绪论 #en[Introduction]
// 在英文档里印的仍是「绪论」。要按语言切标题就用 #chapter，见 src/blocks/heading.typ
//
// warning：英文目录、图表清单里这一条读着是中文时发不发那句红字（见 src/pages/toc.typ
// 的 _en-warn）。auto ＝ 不表态，跟那一页的 warning:；false 就地关这一条——#en(warning:
// false)[] 空着也不再报「没写英文名」；true 就地开。写在记号里，读的人 find-en-warning
#let en(body, warning: auto) = {
  if warning not in (auto, true, false) {
    panic("#en(warning:): expected auto, true, or false, found " + repr(warning))
  }
  metadata(if warning == auto { (iota-en: body) } else { (iota-en: body, iota-en-warning: warning) })
}

// 中文名。内部件，由 #chapter 与 term-chapter 塞——markup 标题没有这一个，
// 取中文时回落到正文槽本身。
#let zh(body) = metadata((iota-zh: body))

// 分图题的记号。写在图题里，排出来是图题下面连排的一行：
//
//     #figure(subs(image(…), image(…)), caption: [气体润滑轴承的分类 #subs([静压], [动压])])
//     →  图1-1  气体润滑轴承的分类
//        （a）静压；（b）动压
//
// 本科指南 2.13.1：「分图题置于分图之下*或图题之下*，分图号用（a）、（b）
// 等表示，在图题之下连续排列，用『；』间隔」。这里是「图题之下连排」那一档的记号；
// 「分图之下」那一档写在正身的 captions: 里（每格一个 #subfigure）。*公开的 subs 在
// src/blocks/subs.typ*：同一个名，写在正身里是排布、写在图题里才落到这个记号。
//
// 分图号的写法与分隔符都可配，见 src/config/settings.typ——本科范例印的是半角
// 的「(a) 静压; (b) 动压」，研究生规范写的又是「a)」。默认跟本科指南的全角。
//
// *gap 是就地压过 subcaption-gap 那一条设定*：图题与这一行之间插什么。
// auto ＝ 不表态，往上找文档级；写 none 就是「这一张不要那段空当」。名字用 Typst
// 的词（figure(gap:)、repeat(gap:) 都是「同一件东西两截之间」），与元素参数照
// #chapter(numbering:) 的办法——设定用带前缀的全名，元素上用它自己的词
#let subs(gap: auto, ..items) = metadata((iota-subs: items.pos(), iota-subs-gap: gap))

// 这是上一个表的续表。写在题里，那一条就排成「表6-1（续表）」*右对齐、
// 不带题名*，而且不占新号。
//
// 指南 2.12：「如某表在一页内安排不下时，才可转页，以续表形式接排。表右上角
// 注明编号，编号后加『（续表）』，并重复表头。」本科范例第 16 页那一行量下来
// 是 x 438.17..509.95——右缘顶着版心右边线 510.24，确实是右上角。
//
// *要用户自己把表拆成两个 #figure。* Typst 那边表跨页时会自动重复
// table.header，但没有「只在续页出现」的钩子，「（续表）」这一行自动化不了。
// Word 里的做法本来也是手工拆。
// *接哪一张表可以指名*：#continued(<tab:one>)。不写就接*前一张*表，
// 那是绝大多数情形——拆表就是把紧挨着的一张拆成两半。指名是给「中间还夹了
// 别的表」那种场合留的口子。
#let continued(..args) = metadata((
  iota-continued: (target: args.pos().at(0, default: none)),
))

// 从一段内容里挖出某个记号。一路往下找，头一个算数——一个标题不该有第二个。
//
// *返回的是数组，不是值本身。* 记号的值可能就是 false（openright 那一个），
// 拿 none 当「没找到」会与它撞。空数组表示没找到，单元素数组表示找到了。
#let _find(c, key) = {
  if type(c) != content { return () }
  if c.func() == metadata {
    let v = c.value
    return if type(v) == dictionary and key in v { (v.at(key),) } else { () }
  }
  if c.has("children") {
    for x in c.children {
      let r = _find(x, key)
      if r.len() != 0 { return r }
    }
  }
  if c.has("body") { return _find(c.body, key) }
  // styled 元素（set 过的一段）：记号可能在它的 child 里，同 src/engine/content.typ 的 plain
  if c.has("child") { return _find(c.child, key) }
  ()
}

#let _space = [ ].func()

// 这份记号里是不是什么都没有。*#en[] 与没写 #en 是一回事*——作者敲了壳子
// 忘了填，两种都该走回落那条路。分不开的代价实测过：英文目录里那一条正身是
// *整个空白*的（「Chapter 1 …………… 1」），连警告都够不着——两句警告挂在汉字
// 占比上，而空串的占比是 0。图表题注同理：双语题注会多排一行空的英文名。
//
// 空的形态不止一种：#en[] 是空序列，#en[ ] 削到底只剩一个空格，#en[#label] 这
// 类只剩 metadata。递归下去逐个判，全空才算空。
#let _blank(c) = {
  if c == none { return true }
  if type(c) != content { return false }
  if c.func() == metadata or c.func() == _space { return true }
  if c.has("text") { return c.text.trim() == "" }
  if c.has("children") { return c.children.all(_blank) }
  if c.has("body") { return _blank(c.body) }
  false
}

// 挖两份名字，挖不到*或挖出来是空的*都给 none。
#let find-en(c) = {
  let r = _find(c, "iota-en")
  if r.len() == 0 or _blank(r.first()) { none } else { r.first() }
}

// 这一条就地的 warning（auto ＝ 没写）
#let find-en-warning(c) = {
  let r = _find(c, "iota-en-warning")
  if r.len() == 0 { auto } else { r.first() }
}

#let find-zh(c) = {
  let r = _find(c, "iota-zh")
  if r.len() == 0 or _blank(r.first()) { none } else { r.first() }
}

#let find-subs(c) = {
  let r = _find(c, "iota-subs")
  if r.len() == 0 { none } else { r.first() }
}

// 那一条 #subs 就地写的 gap。没写（或压根没有 #subs）给 auto ＝ 不表态
#let find-subs-gap(c) = {
  let r = _find(c, "iota-subs-gap")
  if r.len() == 0 { auto } else { r.first() }
}

// 找到就给那个记号的整份取值（里面有 target），没有就 none。
// *不再给布尔*——调用方要拿 target，判在不在写 != none 一样短。
// 伪代码的 body 是 lovelace[…] / algorithmic(…) 造的：Typst 的 figure 只按 table / raw /
// 其余一律 image 认 kind，第四种得我们自己认——body 末尾埋这个记号，show figure 看见就
// 把那张 figure 重造成 kind "algorithm"，见 src/blocks/captions.typ。记号里带这一段的
// 行数，续排的下一段接着这个数往下编行号。找到给 (lines: n)，没有给 none
#let algorithm-mark(lines) = metadata((iota-algorithm: (lines: lines)))

// 「这个 raw 在代码清单（kind raw 的 figure）里面」：figure 那条规则（src/blocks/captions.typ）
// 在 it 前后各发一次更新，lib.typ 里那条 show raw 读它决定排不排框与行号
#let in-listing = state("iota-in-listing", false)
#let find-algorithm(c) = {
  let r = _find(c, "iota-algorithm")
  if r.len() == 0 { none } else { r.first() }
}

#let find-continued(c) = {
  let hits = _find(c, "iota-continued")
  if hits.len() == 0 { none } else { hits.first() }
}

// 这一章要不要从右手页起。*三态*：true / false / none（没写，跟随文档级）。
//
// 内部件。用户写的是 #chapter(openright: …) 与部件的同名参数，由那些函数塞进来；
// src/blocks/heading-rules.typ 的章标题规则读它，读到什么就照什么切页——所以单处能盖过文档级，
// 两个方向都能盖。
#let openright-mark(value) = metadata((iota-openright: value))

// 「这是 #chapter() / #section() 那一支发的标题」的记号。英文档里换正文槽的那条
// show 规则（src/blocks/heading-rules.typ）靠它认：markup 写法只换有编号的，词条页
// （numbering 为 none、整页回退中文的声明页）不换，而 #chapter(numbering: none, en: …)
// 得换——三者只凭 numbering 分不开
#let leveled-mark() = metadata((iota-leveled: true))

// 这一条标题就地给的 spread（true / false）；没给就不挂，读的人按全局开关。
// 见 src/engine/spread.typ
#let spread-mark(value) = metadata((iota-spread: value))

#let find-spread(c) = {
  let r = _find(c, "iota-spread")
  if r.len() == 0 { auto } else { r.first() }
}

#let find-leveled(c) = {
  let r = _find(c, "iota-leveled")
  if r.len() == 0 { none } else { r.first() }
}

// 目录条目里*必须在这儿折*的记号。标题里的换行本身在目录里是被折掉的
// （声明页那条两行的词条，见 src/pages/toc.typ），所以「只在目录里换行」得另起
// 一个记号：写在标题里不显示、不占位（metadata），目录取条目时换成 linebreak。
// 与 #en 同一套做法。「不许在这儿折」不用记号，写 ~（不断行空格）原生就认。
#let tocbreak() = metadata((iota-tocbreak: true))

// 把内容里的 tocbreak 记号换成换行。只走 sequence 一层层下去；记号夹在 strong、
// link 这类元素*里面*不认（重建那些元素会丢样式），写在标题正文里就够了。
// 换出来的 linebreak 带 justify: true——目录折标题换行的那条规则只折 justify: false
// 的（作者敲的 \ 都是这一种），这一种就留下了；目录不两端对齐，justify 本身没有作用。
#let replace-tocbreak(c) = {
  if type(c) != content { return c }
  if c.func() == metadata {
    let v = c.value
    return if type(v) == dictionary and "iota-tocbreak" in v { linebreak(justify: true) } else { c }
  }
  if c.has("children") {
    // 没有记号可换就原样交回，理由同 trim-tail
    let kids = c.children.map(replace-tocbreak)
    return if kids == c.children { c } else { kids.join() }
  }
  c
}

#let find-openright(c) = {
  let r = _find(c, "iota-openright")
  if r.len() == 0 { none } else { r.first() }
}

// 把内容末尾的空白与 metadata 裁掉。
//
// *给目录条目用。*「= 绪论 #en[…]」里那个字面空格会跟进 heading.body，
// 排到目录里就落在标题与点线之间——实测点线前多出一个空格。右端不受影响
// （点线是填到制表位的），但点的相位偏了，Word 那边没有这个空格。
//
// *字面空格是 space 元素，不是 text。*实测 [ ].func() 给的是 space，
// 它没有 text 字段——按 has("text") 判会漏掉，那正是这个空格躲过第一版
// 裁剪的原因。所以拿 [ ].func() 当样本比对。

#let trim-tail(c) = {
  if type(c) != content or not c.has("children") { return c }
  let ks = c.children
  while ks.len() > 0 {
    let last = ks.last()
    let blank = (
      last.func() == metadata
        or last.func() == _space
        or (last.has("text") and last.text.trim() == "")
    )
    if not blank { break }
    ks = ks.slice(0, -1)
  }
  // *没削掉东西就原样交回*：重拼一遍等于重发，span（源码位置）跟着换人，
  // tinymist 从预览跳回源码时会落进本文件。同一条道理见 src/engine/case.typ
  if ks.len() == 0 { none } else if ks.len() == c.children.len() { c } else { ks.join() }
}

// 取某一语言那一份标题。
//
// *取不到就回落到有的那一份*——印出来的东西不能没有内容。标题、页眉、
// 目录条目三处都照这一条，不分「唯一的那份目录」与「附加的那份目录」：
// 英文档里英文目录是唯一一份，某章没写 #en 就整条不出的话，这一章会从目录里
// 消失；而分情况判「唯一 / 附加」要跨部件看别处出不出，讲不清也测不住。
//
// 代价是中文档的英文目录里会冒出中文标题。那正说明用户没给英文名，
// 露出来比悄悄藏起来容易发现。
#let title-of(body, lang) = {
  let mine = if lang == "en" { find-en(body) } else { find-zh(body) }
  if mine != none { return mine }
  // markup 标题（= 绪论 #en[…]）没有中文记号，正文槽本身就是中文那一份
  let plain = trim-tail(body)
  if plain != none { return plain }
  if lang == "en" { find-zh(body) } else { find-en(body) }
}

// 「不编号」的糖：给任何东西打上 <-> 就不编号。
//
//     = 说明 <->
//     #figure(image("a.png"), caption: [示意]) <->
//     $ a = b $ <->
//
// 三种元素各一条规则。*拿 label 当开关*是 Typst 生态里的既成写法
// ——show ….where(label: …) 正是给这种用法留的。
//
// *打十次也不报错*：Typst 只在 @ref 指向重复标签时才报，而没人会去引用
// 一个「不编号」的记号。代价是它占掉了 label 位——「既不编号又要被引用」做不到，
// 而那个组合本来就不成立（引用要靠编号）。
//
// *不编号的也不进目录、不进图表索引。* 无论标题、图、表——目录与索引列的
// 是「编了号的东西」，不编号的条目在那里没有可指的序。Typst 原生的 numbering: none
// 不带 outlined: false（不编号的标题照样进目录），所以这里两条一起设。
// 公式没有 outlined 这一项。
//
// 别的不改：不编号的章仍然切页，字距行距照旧。「不编号 + 拉开字距 + 挂英文名
// + *进目录*」那一整套（摘要、结论那种）走的是 src/blocks/heading.typ 的
// term-chapter——那几章是规范定的固定部分，进目录是它们的规矩，不经这里。
#let nonumber-rules(doc) = {
  show heading.where(label: <->): set heading(numbering: none, outlined: false)
  show figure.where(label: <->): set figure(numbering: none, outlined: false)
  show math.equation.where(label: <->): set math.equation(numbering: none)
  doc
}
