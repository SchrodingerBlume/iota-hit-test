// 只该印一次的页：第二次调用当场报错，不静默多印一份。
//
// 用计数器不用 state：step 是独立元素、落在读它的 context 之前，第 n 次调用稳稳读到
// n（同 src/flow/matter.typ 的 cover-exit-count；state 读一次写一次会来回跳）。
// 报错要多排一轮才出现（计数器是 introspection），编译照样停。
//
// key 给目录、图表清单这类按语言各出一份的页：同一种语言印两次才算重复。
#let _count(name, key) = counter("iota-hit-once:" + name + (if key == none { "" } else { ":" + key }))

// *对拍件把这道门关掉。* 页面模块自己发 once（公开面直接导出它们，套一层
// 包装 LSP 就没了，见 lib.typ），所以「在一篇里排几份变体」不能再靠绕开公开名。
// 不是公开面：lib.typ 不导出，只有 tests/ 的对拍件 import 得到
#let _repeatable = state("iota-hit-once-repeatable", false)
#let allow-repeats() = _repeatable.update(true)

#let once(name, key: none, hint: "") = {
  let c = _count(name, key)
  c.step()
  context {
    if c.get().first() > 1 and not _repeatable.get() {
      panic(
        "#" + name + "() appears more than once"
          + (if key != none { " for lang " + repr(key) } else { "" })
          + "; each page is printed once" + hint,
      )
    }
  }
}

// 两个页互斥：other 在文档里*任何位置*出现过就报错（final，不看先后）。
#let never-with(name, other, hint) = context {
  if _count(other, none).final().first() > 0 {
    panic("#" + name + "() cannot be used together with #" + other + "(): " + hint)
  }
}
