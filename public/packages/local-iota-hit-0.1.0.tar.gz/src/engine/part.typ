// 部件的公共助手。
//
// 「几个字」的度量（ccwd、halfspace、resolve-chars）、当前生效的版面（layout-state）、
// 内容里的标签（label-of），以及从 src/engine/styles.typ 与 src/engine/content.typ
// 再导出的那几样——写 part.rules / part.has-cjk 的地方一个字不用改。

// 这两个挪去了 src/engine/content.typ（tracking.typ 也要用），从这里再导出一次
#import "./content.typ": cjk-ratio, has-cjk, latin-only, plain
// 样式的机制（rules、font、no-docgrid）挪去了 src/engine/styles.typ，从这里再导出一次
#import "./styles.typ"
#import "./styles.typ": font, no-docgrid, rules

// 当前生效的版面住在 src/engine/layout.typ（那边要在它上面并五层梯子），
// 这里再导出一次，写 part.layout-state 的地方一个字不用改。
#import "./layout.typ" as _layout
#import "./layout.typ": layout-state

// 把内容里的字面文字抽出来。用来判一行是不是纯西文——那种行的行盒该按
// 西文的 1.15 算，而不是中易的 1.296875。

// *按量出来的宽度折行*，交回一串纯文本的行。要在 context 里调。
//
// 表单上那几处「填进去的字长了要折行」都用它：深圳本科封面题目那一格、硕博六格
// 的值。*自己折不交给 Typst*，因为折出来的每一行还要各自补白到线的右端／
// 在格子里居中，Typst 折完之后我们看不见断在哪儿。
//
// *断在空格处*（西文），一个词长到整行都装不下才逐字断——与 Word 同。
// 汉字之间没有空格，逐字断正是它该有的样子。
//
// *每一行都 trim。* 行末留着那个空格，居中时它会算进行宽，整行往左偏半个
// 空格（英文档下深圳本科封面的校名折行后偏了 4.05，正是半个小初空格）。
//
// *居中的行也要自己折*：Typst 自然折行时把行末那个空格算进行宽，整行因此
// 偏半个空格——同一段文字改用显式 linebreak 排，两行的中线才落在一处（实测
// 24pt 下偏 3.00，正是半个空格；英文档下深圳本科封面的小初校名偏 4.05）。
//
// room 给的是这一行能用的宽，size 是量的时候用的字号（那几处的字号与当前生效的
// 不同，量错就折错）。first 只在第一行与后面几行宽度不同时给。measure-as 是
// 「按什么样子量」——封面的校名压着 90% 的字宽还带字距，照原样量就折早了。
#let wrap-lines(body, room, size: auto, first: auto, measure-as: auto) = {
  let text-of = if type(body) == str { body } else { plain(body) }
  if text-of == none { return () }
  let text-of = text-of.trim()
  if text-of == "" { return () }
  let sized(t) = if measure-as != auto {
    (measure-as)(t)
  } else if size == auto { text(t) } else { text(size: size, t) }
  let fits(t, w) = measure(sized(t)).width <= w
  let first-room = if first == auto { room } else { first }
  let lines = ()
  let cur = ""
  let now = first-room
  for word in text-of.split(" ") {
    let next = if cur == "" { word } else { cur + " " + word }
    if fits(next, now) {
      cur = next
      continue
    }
    if cur != "" {
      lines.push(cur)
      cur = ""
      now = room
    }
    // 这一个词自己就装不下：逐字断
    let rest = word
    while not fits(rest, now) and rest.clusters().len() > 1 {
      let take = ""
      for c in rest.clusters() {
        if not fits(take + c, now) { break }
        take += c
      }
      if take == "" { break }
      lines.push(take)
      now = room
      rest = rest.slice(take.len())
    }
    cur = rest
  }
  if cur != "" { lines.push(cur) }
  lines.map(l => l.trim())
}

// 内容里挂着的*第一个*标签。
//
// 分图题要靠它：用户写 #subs([静压 <fig:static>], …) 时，那个标签挂在会被
// title-of 摘掉的元素上（写成 #en[Aerostatic]<1> 的话就挂在 #en 那个 metadata
// 上），不把它捞出来重新安置，标签根本进不了文档，@fig:static 报的是
// 「label does not exist in the document」。
#let label-of(c) = {
  if type(c) != content { return none }
  let l = c.at("label", default: none)
  if l != none { return l }
  if c.has("children") {
    for k in c.children {
      let r = label-of(k)
      if r != none { return r }
    }
  }
  if c.has("body") { return label-of(c.body) }
  none
}


// 一个汉字占多宽——ctex 的 \ccwd。
//
// *是一格的宽度，不是字号。* Word 的网格里一个全宽字占「字号 + 字距增量」，
// 12pt 下就是 12.4543。凡是按「几个字」度量的东西都该走它：题注与标题里编号与
// 题名之间的空当、目录里那一处。
// hithesis 那边同样用它排目录（\l@subsubsection {3}{3\ccwd}{3.1em}）。
//
// *「几个字」在值位置一律写 (chars: n)*，与段前段后的 (lines: n) 同族——
// 单位跟着 Word 的对话框：缩进那一栏给「字符」，段前段后那一栏给「行」，两边都
// 另给「磅」（我们这边就是直接写长度）。裸数字不收：Typst 原生只在真正的「个数
// 档位」上收裸数字（columns(2)、weight: 700），「相对于某个量」用 em 与 %，而
// 一格 ≠ 1em（12.4543 对 12），em 表达不了它，所以这个写法自造，但形状跟着 Word。
//
// *跟着当前字号走，不钉在基准字号上。* 返回的是个复合长度
// n × (1em + 字距增量)——1em 由 Typst 在*用到的地方*折算成那一处的字号，
// 所以 12pt 的正文里问出 12.4543，18pt 的标题里问出 18.4543。
// 先前这里写的是 n × layout.docgrid.char-pitch，而 char-pitch = *基准*字号 + 字距，
// 钉死在 12pt 上：18pt 的环境里问一个字多宽，答出来还是 12.4543，缩进两字
// 就缩短了 12。ctex 的 \ccwd 同样是随当前字体走的。
//
// 字距增量这一截是*网格的*性质，与字号无关（见 src/engine/layout.typ 的规则八），
// 所以它是绝对量，不跟着 1em 缩放。
//
// 个数省得掉：ccwd() 就是一个字宽，ccwd(2) 是两个。写成收集参数是因为
// Typst 只给具名参数默认值，而这一个该跟 enter(1) 一样按位置写。
// layout 收整份（折好的）或局部字典；省略或局部时从 layout-state 取，那两档
// 要在 context 里调用。没进过 iota-hit 的文档没有网格，一个字宽就是一个字号。
#let ccwd(..n, layout: auto) = {
  let l = if _layout.is-folded(layout) {
    layout
  } else {
    let s = layout-state.get()
    if s == none and layout == auto { no-docgrid } else {
      _layout.resolve-local(if s == none { _layout.standalone-layout(none) } else { s }, layout)
    }
  }
  let count = n.pos().at(0, default: 1)
  count * 1em + count * l.docgrid.tracking
}

// n 个半角空格的宽度。Word 那几处「敲出来的空当」照这个发。
//
// *一个半角空格占半个网格格。* 空格是无字符集归属的字，Word 的
// w:hint="eastAsia" 把它判给中文那一槽，于是按半宽走，而横向字符网格把半宽字
// 排到半格上。实测本科范例第 18 页签名行 18 个空格摊出 112.10（一个 6.228），
// 而 char-pitch ÷ 2 = 6.227。
//
// *再补一份 run 边界丢掉的字距。* 网格靠 tracking 加在每个字*后面*，
// 一个 run 的末字后面没有下一个字，那一份就丢了——签名行「作者签名：」的「：」、
// 内封第一行「毕业设计」的「计」都卡在这里。实测四段空格的签名行累计丢 1.82，
// 内封那一行三段丢 1.36。目录里编号那一段补的是同一份，见 src/pages/toc.typ。
//
// *发的是宽度不是空格字符*——Word 自己的 PDF 里也没有空格字形，是把后面
// 那个 run 直接摆到位置上的（mutool 看到的就是断开的几段）。
// *它与 ccwd 不是一回事，别合并。* ccwd 跟*当前字号*走（ctex 的 \ccwd
// 就是这个），量的是「排版上空几个字」；halfspace 跟*网格格子*走、钉在基准
// 字号，量的是「Word 里真敲了几个半角空格」——网格的格子是死的，一个半角空格在
// 哪一档字号的 run 里都占半格。五号上就差得出来：ccwd(0.5) = 5.477，halfspace(1)
// = 6.68。排版空当（编号与题名、题序与标题、目录）一律走 ccwd。
// *它发的是 h()，不是空格字形*——所以*下划线盖不住它*。报告首页那六格
// 的线覆盖的是一串真空格（Word 里就是带 w:u 的空格），只能另发一支
// （src/pages/report/cover.typ 的 _sp）；那一页也没有字符网格，半角跟的是本段
// 字号而不是半个格。两支看着像，用处不同，别合。
#let halfspace(n, layout) = h(n * layout.docgrid.char-pitch / 2 + layout.docgrid.tracking)

// 「几个字」或一个长度，折成长度。目录、题注这类地方收的就是这两种写法。
//
// *(chars: n) 就是 ccwd(n) 的免 context 写法*——参数值里调不了 ccwd()
// （那要上下文），所以让用户写个数，我们在拿得到 layout 的地方折。凡是「空几个
// 字」的取值都该走这里，不要另造算术。
#let resolve-chars(value, layout) = {
  if type(value) == length { return value }
  if type(value) == dictionary and "chars" in value {
    let n = value.at("chars")
    if type(n) not in (int, float) {
      panic("expected number for \"chars\", found " + str(type(n)))
    }
    return ccwd(n, layout: layout)
  }
  panic("expected length or dictionary with \"chars\", found " + repr(value))
}

// 算行盒。网格三个参数从 layout 里取，别处一律走这个口。
#let resolve(style, layout: no-docgrid) = styles.resolve(style, docgrid: layout.docgrid)

