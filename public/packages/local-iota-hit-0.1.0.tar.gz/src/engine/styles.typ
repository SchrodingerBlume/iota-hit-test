// 样式的机制：resolve 把一条样式在网格下折成绝对量，rules 把它落到 Typst 上。
//
// resolve 对照 hithesis 的 src/utils/hit-format.dtx「换算」一节。
// 换算这一层是纯函数，不碰排版，好拿 hithesis 的回归值逐条对拍。

#import "../config/fonts.typ": zihao
#import "./content.typ": has-cjk, latin-only, plain
#import "./constants.typ": floor-to-twip, latin-run, latin-run-lead, latin-run-led, latin-slot-run, role-features, latin-par-features
#import "../config/fonts.typ": (
  ascent-const, ascent-coefs, ascent-default, exact-first-ratio, ink-height,
  natural-coefs, natural-default, en-roles, zh-roles,
)
#import "../config/styles.typ": default-styles, toc-line-spacing-auto, variant-styles
#import "./terms.typ": term-for
#import "./errors.typ" as _errors
#import "./fonts.typ"
#import "./synth.typ" as _synth
#import "./tracking.typ": tracking-pad
// 当前生效的版面：shows 那一半 layout: auto 时在 context 里读它。定义单独成文件，
// 理由见那边
#import "./layout-state.typ": layout-state

// 每个纵向的量都记成一个*复合长度*：em 系数 × 字号 + 绝对量。
//
// 两截分开记不是为了好看，是为了让行盒在*任何*字号上都精确。上升部是
// 1.008 × 字号 + 0.082pt，那个常数项不随字号缩放；整个量先在正文字号上折成
// 一个数、再按比例套给别的字号的话，常数项会跟着被缩放一次，行内混进大字时
// 就差那么一点。两截原样写进 top-edge / bottom-edge 即可。
//
// *直接用 Typst 的 length，不自己造记录。* length 本身就有 abs 与 em
// 两个字段（typst-library/src/layout/length.rs 的 Fields 一节），加减乘也是
// 原生的：
//
//     let a = 1.25em + 0.082pt      a.abs = 0.082pt   a.em = 1.25
//     a + 0.5em - 1pt               2 * a
//
// 这里先前自造了 (em:, abs:) 字典加六个算术函数，是在重造这个类型。
//
// 只有一处 Typst 给不了：*按指定字号折算*。to-absolute() 折的是当前
// 生效的字号，而我们要按这一档 style 自己的字号折——所以留下 _absolute。
// 没有文档网格时的三个量。resolve 的默认参数，也给下面的 no-docgrid 用。
#let zero-docgrid = (
  line-pitch: 0pt, char-pitch: 0pt, tracking: 0pt,
  // 没网格就没网格：贴不了，「一行」也无从谈起（(lines: n) 折出 0）
  grid: false, line-unit: 0pt,
)

// 没有网格的场合（独立小部件、enter 之类）用它，省得各处拼一个假 layout。
#let no-docgrid = (
  docgrid: zero-docgrid,
  base-size: 12pt,
  cells: 0,
  text-width: 0pt,
)

#let _absolute(len, size) = len.abs + len.em * size
// 在这个字号上谁大取谁。复合长度比不了大小，得先各自折成绝对量。
#let _max(a, b, size) = if _absolute(a, size) >= _absolute(b, size) { a } else { b }

// 倍数写法。对齐到网格时是网格行距的倍数，一行装不下就往上取整到整数个格；
// 关掉时是自然行高的倍数，与网格无关。
//
// 不贴网格那一支是纯 em：行距与字号成正比，换个字号照样对。
// 贴网格那一支是纯绝对量：格子是死的，跟字号无关。
#let _multiple-baseline-gap(k, coef, size, docgrid, snap) = {
  if not snap { return k * coef * 1em }
  let len = k * docgrid.line-pitch
  let floor = calc.ceil(coef * size / docgrid.line-pitch) * docgrid.line-pitch
  calc.max(len, floor)
}

// 一个行距端点折成基线距。倍数没有单位，光看写下来的字不知道有多长，
// 所以要等字号、自然行高、网格行距都齐了才折。
//
//   "single" / "double"   Word 下拉框里的词，折成 1 与 2
//   1.25                  倍数
//   (exactly: 25pt)       Word 的固定值，网格与字号都不介入，比字号小也照给
//   (at-least: 10pt)      Word 的最小值
//   (white: 3mm)          视觉白，模板的扩展，换基线距要加一个字面高
//   19pt                  就是这么长，不设下限
//
// 返回 (mode, gap)：mode 只有 "exactly" 那一档会改基线落点。
#let _baseline-gap-endpoint(value, coef, size, docgrid, snap) = {
  if value == "single" {
    return (mode: "multiple", gap: _multiple-baseline-gap(1.0, coef, size, docgrid, snap))
  }
  if value == "double" {
    return (mode: "multiple", gap: _multiple-baseline-gap(2.0, coef, size, docgrid, snap))
  }
  if type(value) in (int, float) {
    return (mode: "multiple", gap: _multiple-baseline-gap(float(value), coef, size, docgrid, snap))
  }
  if type(value) == length {
    return (mode: "length", gap: value)
  }
  if type(value) == dictionary {
    if "exactly" in value {
      return (mode: "exactly", gap: value.at("exactly"))
    }
    if "at-least" in value {
      // 网格开看网格行距，网格关看自然行高
      let given = value.at("at-least")
      let floor = if snap { docgrid.line-pitch } else { coef * 1em }
      if given >= _absolute(floor, size) {
        return (mode: "at-least", gap: given)
      }
      return (mode: "at-least", gap: floor)
    }
    if "white" in value {
      // 基线距 = 视觉白 + 0.9050 × 字号
      return (mode: "white", gap: ink-height * 1em + value.at("white"))
    }
  }
  panic("expected number, length, or dictionary with \"at-least\" or \"white\", " + "found " + repr(value))
}

// 基线在行盒里的位置。
// 对齐到网格时行盒居中，基线在盒顶下方「行盒高减自然行高的一半，再加上升部」；
// 关掉时顶对齐，倍数多出来的量全落在基线之下，基线就在上升部处。
// 固定值是另一套，基线在盒顶下方 0.8 倍盒高，与网格开关无关。
//
// 居中多出来的那一段归进绝对量而不是 em 系数：它是这一段所在的网格的性质，
// 不是这个字号的性质。行内混进别的字号时，Word 那边也是按该 run 的上升部
// 算，不按网格重新居中。
//
// *「整份居中」这一条有一处反例，记在这儿省得再查一遍。* 居中现在是拿
// 整份（行盒高 − 自然行高）算的，靶子是本科范例内封那张真表格（四号 1.5 倍、
// 贴 19.75 的网格，见 tests/check-titlepage.py 的七条基线），改成「只居中取整
// 多出来的那一截」会让七行整体上移 5.1、全红。可*正文故事里的段落不是
// 这样*：深圳硕士开题的节标题（小三 1.35 倍、贴 19.55 的网格）逐条量下来，
// 一级→二级 40.08、二级→正文 33.12 两处同时对上的只有「倍数多出来的那一截
// 落在基线下」那一解，整份居中要差 3.5。两处都是实测，一条公式盖不住，
// 所以没有动这里。哪天要统一，得先弄清 Word 在表格里与在正文里贴网格是不是
// 两套算法。
#let _ascent-of(mode, baseline-gap, coef, size, snap, asc-coef) = {
  if mode == "exactly" { return exact-first-ratio * baseline-gap }
  let ascent = asc-coef * 1em + ascent-const
  if not snap { return ascent }
  let center = (_absolute(baseline-gap, size) - coef * size) / 2
  ascent + center
}

// 段前段后的量。「行」这个单位恒指网格行距，与该段自己的行距无关，也与这一段
// 对不对齐网格无关。折成长度以后要往下截到整缇，Word 存盘时就是这么干的。
//
// *只收「行」，不收「字」。* 单位跟着 Word 的对话框走：段前段后那一栏只给
// 「行」和「磅」两种，缩进那一栏才给「字符」。范例的 docx 里数得出来——
// firstLineChars 124 次、beforeLines / afterLines 11 / 9 次，
// beforeChars / afterChars *零次*（OOXML 里根本没有这两个属性）。
//
// 先前这里多收一个 (chars: n)，全项目一次没用过，而且是串了轴的——docgrid.char-pitch
// 是一格的*横向*宽度，拿它量*纵向*间距不对。已删。
#let _amount(value, docgrid) = {
  if value == none { return 0pt }
  if type(value) == length { return value }
  if type(value) == dictionary and "lines" in value {
    // *乘的是 line-unit 不是 line-pitch*：Word 的「一行」在网格启用时
    // 是一个网格行，不启用时是正文的一个字号，见 src/engine/layout.typ 的 fold
    return floor-to-twip(value.at("lines") * docgrid.line-unit)
  }
  panic("expected length or dictionary with \"lines\", found " + repr(value))
}

// 首行缩进与悬挂缩进。两个键名照 Typst 的 par.first-line-indent /
// par.hanging-indent。先前是一个 indent-special 键收一个 (first-line: n) 字典
// ——多包一层，键名也与 Typst 对不上。
//
// 收 (chars: n) 就是「几个字」，收长度就照长度。
//
// *「几个字」跟当前字号走，不钉在基准字号上。* 与 part.ccwd 同一个式子
// （n × 1em + n × 字距增量）——这边不能 import part（那边 import 了本文件），
// 所以把式子抄一遍，改一处要改两处。依据是范例的 docx：w:firstLineChars 折成
// w:firstLine 的比值*随本段字号变*，五号那几段每字 10.9500 / 10.9556
// （＝ 10.5 + 0.4543），继承小四的那些每字 12.4490～12.4563（＝ 12 + 0.4543）。
// 先前这里乘的是 docgrid.char-pitch，钉死在基准字号上，五号段落会多缩 3pt。
//
// *两个方向各出一个值，不折成带符号的一个数。* 折了就得在用的地方
// calc.max 拆回来，而带 em 的长度在 context 外比不了大小（eqdenote 那边踩过
// 一次，见 src/blocks/eqdenote.typ 的 to-absolute）。
#let _indent(style, docgrid) = {
  let pick(v) = {
    if type(v) == length { return v }
    if type(v) == dictionary and "chars" in v {
      let n = v.at("chars")
      return n * 1em + n * docgrid.tracking
    }
    panic("expected length or dictionary with \"chars\", found " + repr(v))
  }
  // *整段左缩进（w:ind left）单出一格。* Typst 的 par 没有这一档——它只有
  // first-line-indent 与 hanging-indent，整段推开要靠块的 inset。所以这里只算
  // 出长度，交给发块的那一层（src/blocks/paragraph.typ 的 paragraph）落到 inset 上。
  //
  // 用得上它的是报告首页的字段表：硕博那六格写着 w:ind left="1260"（63pt），
  // 整段（含折行）都从那里起排。
  let left = style.at("left-indent", default: none)
  let left = if left == none { 0pt } else { pick(left) }
  let first-line = style.at("first-line-indent", default: none)
  if first-line != none { return (first-line: pick(first-line), hanging: 0pt, left: left) }
  let hanging = style.at("hanging-indent", default: none)
  if hanging != none { return (first-line: 0pt, hanging: pick(hanging), left: left) }
  (first-line: 0pt, hanging: 0pt, left: left)
}

// snap-to-docgrid 就是 Word 段落对话框上「对齐到网格」那一个勾，*只管纵向*。
//
// 横向（字距增量）不由段落定，由*版面*定：这一节的文档网格写了 char-pitch，
// 正文故事里每一段都吃增量，勾没勾都一样。官方本科理工范例 PDF 量的：节标题
// 15pt 步进 15.48 = 15 + 0.4543，而 heading 2 样式写着 snapToGrid=0；题注五号
// 步进 10.94（第 12 页「表6-1」，1/300 英寸取整）= 10.5 + 0.4543，那一段也是
// snapToGrid=0；英文摘要段 snapToGrid=0，Times 逐字比字身宽多 0.21（半格）。
// 页眉页脚不在这个故事里，不吃——范例页眉「章→绪」空一字正好 9.000，没有增量。
//
// 先前这一键收 (vertical:, horizontal:) 两轴，横轴逐段手写，题注那一档漏写就
// 没吃到增量。写了字典当场报错，指路到这里。
#let _snap-of(style) = {
  let v = style.at("snap-to-docgrid", default: false)
  if type(v) != bool {
    panic(
      "snap-to-docgrid: expected a boolean (Word's \"snap to grid\" checkbox, vertical "
        + "only), found " + repr(v) + "; the character grid comes from the layout "
        + "(char-pitch), so delete the \"horizontal\" key",
    )
  }
  v
}

// 字距增量：发给 text(tracking:) 的那一段，取网格的字距增量本身。
//
// *不是「一格减字号」。* 那个式子只在基准字号上成立——封面的中文题目
// 是 22pt，一格 12.4543，减出来是 −9.5。Word 的模型是每个全宽字后面加一段
// 定长（w:charSpace/4096），与字号无关，见 src/engine/layout.typ 的规则八。
// 正文、各级标题、页眉三处 set text 都从这里取，标题另加自己的 tracking。
// 补偿那一头不从这里取——它读当前生效的 text.tracking，见 src/engine/tracking.typ。
#let tracking(metrics, tracking: 0pt) = {
  (if metrics.snap-h { metrics.docgrid.tracking } else { 0pt }) + tracking
}

// 字符网格的行末余量，也就是 hithesis 发给 \rightskip 的那一段。
//
// *眼下没有接。* 横轴的目标是用 tracking 调到与 Word 大体一致，
// 这一段是追精确的：接上去行末从 510.2258 挪到 509.7713，正好落在 Word 的
// 模型上；不接则偏差从行首往行尾线性累积到 0.4543pt（0.16mm），
// 与横轴上其余几处已有的偏差同级。接法见 src/blocks/body.typ 里注释掉的那两行。
// 两档来路完全不同：
//
//   贴网格   整数格除不尽的零头。一行放得下 n 个格，n 个字连着排占
//            n 个字号加 n−1 段字距胶，版心宽减掉它就是余量。范例版心宽
//            425.18、字距 12.4544，34 个字占 423.45，右边留 1.73 空着。
//   不贴网格 末字省掉的那一个字距增量。行末那个字不带增量，Word 把行拉到
//            425.18 − 0.4543 = 424.72。
//
// 不扣的话 TeX 与 Typst 都会把整行拉满版心，每个字缝多出来一点。
#let line-end-slack(metrics, text-width: 0pt, cells: 0) = {
  if not metrics.snap-h { return 0pt }
  let glue = metrics.docgrid.char-pitch - metrics.size
  if not metrics.snap { return glue }
  text-width - cells * metrics.size - (cells - 1) * glue
}

// 把一个元素的键值算成行盒。
//
// 网格行距为零说明没走过 msword-layout，那时候不存在网格，
// snap-to-docgrid 勾了也没有可对齐的东西，一律按关掉算。
// char-grid：这一处在不在字符网格上。正文故事里的段落都在（默认）；页眉页脚
// 记录不在，src/engine/layout.typ 的 page-rules 传 false。
#let resolve(style, docgrid: zero-docgrid, char-grid: true) = {
  let size = style.at("size", default: zihao.xiaosi)
  let font-zh = style.at("font-zh", default: "songti")
  // *latin-line-height 是 "cjk" 时，纯西文行按中文行高算*——英文目录、英文页眉
  // 那些就不再随内容是中是英而挪位。这一档住 layout 里、随 docgrid 一起传（见
  // src/engine/layout.typ 的 fold），每一处 resolve 都不必多传一个参数；auto 与
  // "latin" 都是照 Word 按西文算。"ascii"（空段）不在此列，见 src/config/fonts.typ。
  let font-zh = if font-zh == "latin" and docgrid.at("latin-line-height", default: auto) == "cjk" {
    "songti"
  } else { font-zh }
  let coef = natural-coefs.at(font-zh, default: natural-default)

  // *网格没启用就不贴*——先前只看 line-pitch 是不是 0，可原件那一节的
  // docGrid 数照写着、只是没有 w:type（深圳本科那两份报告），照贴就把表格的
  // 行排成了 19.55，而 Word 排出来是 19.44
  let snap = _snap-of(style) and docgrid.grid and docgrid.line-pitch != 0pt
  // 横向由版面定，见 _snap-of
  let snap-h = char-grid and docgrid.tracking != 0pt

  // auto 只有目录那四条有，且到这儿之前该由 resolve-toc-line-spacing 按学位填好；
  // 漏填不能静默当单倍排
  let line-spacing = style.at("line-spacing", default: 1)
  if line-spacing == auto {
    panic("line-spacing: auto reached resolve unresolved; call resolve-toc-line-spacing first")
  }
  let (mode, gap: baseline-gap) = _baseline-gap-endpoint(
    line-spacing,
    coef, size, docgrid, snap,
  )
  let ascent = _ascent-of(
    mode, baseline-gap, coef, size, snap,
    ascent-coefs.at(font-zh, default: ascent-default),
  )
  // 行盒高：*倍数那一档取行距与自然行高的较大者*。这一步照 hithesis 那根
  // 撑杆（\hit@format@strut:）来，是为页眉设的：页眉那一行的行距写着 0（倍数 0，
  // 不是固定值），光看它撑出来的盒子没有深度，页眉横线会整块上移 2pt。
  //
  // *固定值那一档不取大，那个数就是盒高*——Word 的「固定值」小于字高时
  // *让字挤出去*，不把行撑开。深圳本科报告首页 2026 年 9 月版新加的勾选行
  // 就是这一档：小一 24pt 的字写着 w:line="380" exact ＝ 19pt，Word 排出来那一行
  // 就占 19（下一行的基线量出 99.12 → 179.83，中间只隔着一个空段）；取大的话
  // 盒子成了 31.13，整页往下坠 12。
  //
  // *裸长度那一档也不取大*——上面写的就是「就是这么长，不设下限」，先前代码却跟着倍数
  // 一起取了大。深圳本科报告首页压缩行距时靠它把行盒压到自然行高以下（基线仍在上升部
  // 处，缩掉的全是基线以下那一截），见 src/pages/report/shenzhen/cover.typ 的 ls-of
  let natural = coef * 1em
  let box = if mode in ("exactly", "length") { baseline-gap } else {
    _max(baseline-gap, natural, size)
  }
  // *裸长度比上升部还矮时基线落到盒底*：盒顶不能低于基线（bottom-edge 写成正值 Typst
  // 当 0，盒会被撑回上升部那么高，写下的长度就不作数），所以上升部收成盒高、深度为 0。
  // 深圳本科报告首页压缩英文行时要用到：Times 的上升部 0.891em，字的墨迹只到 0.66em，
  // 行盒压到上升部以下字还碰不到上一行的线
  let ascent = if mode == "length" and _absolute(box, size) < _absolute(ascent, size) { box } else { ascent }
  let depth = box - ascent

  (
    size: size,
    natural: coef * size,
    box: _absolute(box, size),
    // 折在这个元素自己字号上的量，换算与对拍看这几个
    baseline-gap: _absolute(baseline-gap, size),
    ascent: _absolute(ascent, size),
    depth: _absolute(depth, size),
    // 跟着 run 的字号走的量，top-edge / bottom-edge 用这两个
    top-edge: ascent,
    bottom-edge: depth,
    above: _amount(style.at("above", default: none), docgrid),
    below: _amount(style.at("below", default: none), docgrid),
    indent: _indent(style, docgrid),
    snap: snap,
    snap-h: snap-h,
    docgrid: docgrid,
  )
}

// 纯西文行的行盒。
//
// *要解决的事。* Word 里一行的行高取这一行*实际用到*的各个字体的
// 最大值，所以同一个设置下，有汉字的行按中易的 1.296875 算，纯英文的行只有
// Times 参与，按 1.15 算。范例的两份摘要就是这样：段落设置相同，中文那份
// 量出 19.4531，英文那份 17.2500。
//
// Typst 的行盒本来就是取全行各 run 的最大值——*与 Word 同一条规则*。
// 只是我们把 top-edge / bottom-edge 写成了显式的量（为的是不问加载的是哪个
// 字体、一律按中易的标定排），一写死就对所有 run 一视同仁，纯西文行也拿到了
// 汉字那一份，比 Word 高 2.2pt，合 11%。
//
// 所以给西文 run 单发一份行盒，让 Typst 的 max 自己去挑：
//   纯西文行   全是西文 run  → 17.2500
//   混排行     max(西文, 汉字) → 19.4531
//   汉字行     全是汉字 run  → 19.4531
//
// 取值不另写公式，就是同一个 style 把 font-zh 换成 none 再算一遍——
// 换算层认这件事，1.15 那一支有 hithesis 的回归值撑着。
//
// *为什么要求段里至少有一个拉丁字母。* Typst 有个原生的 script 分段行为：
// 拉丁*字母*自成一个 shaping run，而 run 的最后一个字形拿不到 tracking；
// 数字和符号算 Common，留在汉字那个 run 里，所以不丢。实测（单一字体、
// 无 covers、无 show 规则、连 cjk-latin-spacing 都关掉，tracking 设 2pt，
// 汉字步进该是 14.000）：
//
//   汉→汉 14.000   汉→A 12.000   汉→a 12.000   汉→1 14.000   汉→% 14.000
//
// 所以规则若写成「西文+」，「共12页」里的 1 会被划成独立的 run，那 0.4543
// 的字距就丢了，15.4543 掉到 15.0000。写成「至少含一个字母」就把光是数字的
// 那种放过去，字距保住；而真正要救的纯西文行必然带字母，一个不漏。
//
// 顺带也救了页眉：「第 1 章」里的 1 不再自成 run，正文那条规则漏进页眉也不
// 起作用了。漏是躲不掉的——set page 的页眉是在正文的样式里排的，而内外两条
// 规则同时命中时同一属性上外层赢（实测：内层设 size 外层设 fill，两个都生效；
// 都设 fill 则外层赢），从页眉内部盖不住。
//
// *上游若修了怎么办。* CJK-Latin 这一带是 typst 公认的粗糙区
// （issue 7475 / 6539 / 2702 / 2703 / 2538）。根因见 PR 7521：
// add_cjk_latin_spacing 不是插入一个间距项，而是去改汉字字形的 x_advance
// 与 offset；作者说正经重构 shaper 这一套「架构改动大、回归风险高」。
// 哪天 run 边界不再吞 tracking 了，「至少含一个字母」这条限制就可以松掉，
// 改成「西文+」，光是数字的行也能拿到西文行盒；判据是 tests/check-pitch.py
// 里那条汉字接数字的断言在松掉之后还过不过（现在是 15.4543）。
//
// *对齐到网格时这条规则不发。* Word 贴网格时行盒就是整数个格，与这一行
// 用了哪些字体无关——按字体分高矮只是不贴格那一档的事。技术上也非发不可：
// Typst 是把各 run 的 top-edge 取一次最大、bottom-edge 再取一次最大，两份
// 行盒贴格后居中量不同，凑出来比任何一份都高。实测研究生那一档（单倍贴格）
// 行距从 19.5500 涨到 20.4312，一页少排两行。
//
// *范围为什么写码位。* 见 constants.typ 的 latin-run。
// 西文断字。
//
// *光开 hyphenate 没用，必须连 lang 一起给。* Typst 按 text.lang 选断字
// 规则表，中文没有那张表——实测同一个 electroencephalographically，lang=en 断成
// electroen-cephalographically，lang=zh 整词甩到下一行，设不设 hyphenate 都一样。
//
// 挂在 latin-run 上：那条正则本来就在挑「至少含一个拉丁字母」的 run（行盒那一档
// 也用它），西文断字要的正是同一批 run。汉字不受影响——它本来就随处可断。
//
// *lang 只在这条规则的作用域里改。* 文档语言由 src/engine/lang.typ 的 doc-lang
// 这个 state 管，入口写一次，之后没人再读 text.lang，所以这里改它不影响标题取哪
// 一份、词条走哪一层。
//
// *开关是原生的 text.hyphenate，我们不另设一条。* Typst 自己就有这个属性，
// 三种粒度实测都通：全篇 #set text(hyphenate: true)、按元素
// #show figure.caption: set text(hyphenate: true)（子图题也命中，还能再
// .where(kind: image) 分开图题表题）、按页把 #set 裹在那次调用外面（穿得进去，
// 连那两页的页眉页脚一起）。比我们先前那个只有 body / caption 两档的字典细得多。
//
// *判据只认 true。* 原生默认是 auto——「两端对齐就断字」，而正文正是两端
// 对齐的，照 auto 走就成了默认断字，与范例相反（两份 .docx 的 settings.xml 里
// 都没有 w:autoHyphenation，Word 默认关）。所以 auto 与 false 一样当不断。
#let hyphenate-rules(doc) = {
  show latin-run: it => context {
    // *set 而不是包一层*：包成 text(lang: "en", it) 也能排对，但那是*重发*
    // 一段文字，span（源码位置）跟着换成本文件——tinymist 从预览跳回源码时西文会落进
    // 包里。set 只改样式，元素连同 span 原样过。同一条道理见 latin-run-led 那一处
    if text.hyphenate == true { set text(lang: "en"); it } else { it }
  }
  doc
}

#let latin-line-rules(style, docgrid: zero-docgrid, doc) = {
  let metrics = resolve(style, docgrid: docgrid)
  if metrics.snap { return doc }
  // latin-line-height 是 "cjk"：西文 run 也走汉字那一份行盒，什么都不发
  if docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = resolve(style + (font-zh: "latin"), docgrid: docgrid)
  show latin-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  // *智能引号也要换成西文的行盒。* 它是 smartquote *元素*，不是文本，
  // latin-run 那条 regex 匹配不到——于是一整行纯西文里只要有一对引号，
  // 那一行就退回汉字的行盒，比别的行高 0.9（实测英文摘要里含引号的那两行
  // 比 Word 多 0.9 与 2.2）。挂在 smartquote 上正好补齐，而且与 src/blocks/quotes.typ
  // 里那条换字体的规则落在同一个元素上，不另造 run 边界。
  show smartquote: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}

// 一个西文单词长到一行都放不下时，Word 会*在单词内部按字符断行*把行填满
// （拿范例改一处英文题目、由 Word 导出实测）。Typst 不会——它把整个单词摆在
// 一行上排到版心外面，PDF 一裁那个词*整个看不见*。
//
// 所以给放不下的单词插零宽空格 U+200B 造断点，实测 Typst 认它，断出来同样
// 把行填满。二十二个字母起才看，且要 measure 量出来确实放不下：二号下一个
// 字母约 15.4pt，装满 425.2 的版心要 28 个；最长的常用英文单词也就二十个上下
// （internationalization 是 20），所以正常单词永远碰不到这条。
#let _long-word-min = 22

// 拆超长单词时最多拆成多少段。*256 是 Typst 的硬上限*——超长单词是靠在字母
// 之间插零宽空格拆开的（见下面 latin-run 那条规则），而*一个 run 里的断点
// 过多，Typst 当场停编译*：
//
//   error: maximum grouping depth exceeded
//     while calling `measure` at src/pages/cover.typ:322
//
// 实测边界干净利落：一个单词 255 个字母过，256 个不过，与字号、版心宽、是不是
// 在 measure 里都无关（封面那一处是量高度时先撞上的，直接排也一样炸）。
//
// *所以按段数封顶，不按字母数。* 长过头就每 k 个字母插一个断点，
// k = ⌈字母数 ÷ 250⌉：常见的超长单词（几十到二百来个字母）k 仍是 1，与先前
// 逐字母拆逐字节相同；只有 250 个字母以上的才变粗，代价是行末最多空出 k−1 个
// 字母的位置——比拦住整篇文档不让编译强得多。
#let _long-word-pieces = 250

// 把字母按 k 个一组并起来，好在组与组之间插断点。
#let _long-word-chunks(cs) = {
  let k = calc.max(1, calc.ceil(cs.len() / _long-word-pieces))
  if k == 1 { return cs }
  range(0, cs.len(), step: k).map(i => cs.slice(i, calc.min(i + k, cs.len())).join())
}

// 角色名 → 发给 text(font:) 的字体表。
//
// 内部一律写角色（songti / heiti / kaishu / fangsong / serif …），不写家族名，
// 换字体档自动跟上。
//
// *全宽符号先由宋体抢回来，两支都抢。* Typst 的 "latin-in-cjk" 会把「↑」
// 「□」收去排成西文半宽，而 Word 排的是中易全宽——它们是无字符集归属的字，
// Word 按 w:hint="eastAsia" 判给 eastAsia 那一槽，而全文的 eastAsia 默认是宋体。
//
// *抢的是宋体，不是当前角色的家族。* 先前中文那一支写的是
// families.at(role)，于是黑体行里的「□」跟着变黑体；西文那一支*整个没有
// 这一层*，「□」只能靠 Typst 的全局兜底，兜到哪算哪——英文内封那三个「□□□」
// 眼下落在宋体上是兜出来的，换一台机器上 Times 若带这个字形就变成西文半宽了。
// latin 收*这一档的西文走哪个角色*。默认 serif：论文范例里黑体行的西文就是
// Times（内封「Candidate：」「Date of Defence：」那几行逐行量过，SimHei 14 ＋
// TimesNewRomanPS-Bold），hithesis 也把「标题西文换无衬线」做成默认关着的选项。
// 写 sans 的地方*是原件自己把西文槽也写成了中文字体*——深圳本科封面题目那一格
// 的 w:rFonts 是 ascii/hAnsi/eastAsia 全黑体，黑体自带的西文就是无衬线的。
// em-dash：破折号排哪一副字，从 fonts.current 的表里读着传进来（fonts.resolve 存的）
#let font(role, families, latin: "serif", em-dash: "cjk") = {
  if role in en-roles {
    fonts.latin-table(families, role)
  } else {
    // 本角色排汉字依次试的家族，楷体_GB2312／隶书／新魏带回落链，见 fonts.role-chain
    let chain = fonts.role-chain(families, role)
    (
      (name: families.songti, covers: fonts.cjk-first),
      ..fonts.cjk-claim(chain),
      ..fonts.latin-entries(families.at(latin), em-dash: em-dash),
      ..chain,
    )
  }
}

// 把 style 落到 Typst 上。用法是 show: rules.with(style, layout: …)，
// 或者在一个块里直接调用。
//
// 正文、各级标题、页眉页脚、纯西文段、封面上的每一行——这些都是同一套机制的
// 不同取值：一段 Word 段落属性（字号、字体、行距倍数、贴不贴网格、段前段后、
// 缩进、字距）经换算层折成行盒，再落到 Typst 的 text / par 上。
//
// 这一层就是那个「落」的动作，各部件共用。放在这里的好处有三层：
//
// 一、网格三个参数（行距、一格的宽、字距增量）只在这里从 layout 里取一次。
//     以前每个部件各写一遍 grid-lead / grid-char / grid-space 三个参数，
//     加一个参数就得改七处，漏一处就是一个不报错的静默偏差。
//
// 二、*贴不贴网格是一个取值，不是一段特判。* 范例封面上只有中文题目那一段
//     贴行网格（它没写 snapToGrid，取默认的开），别的段都写着 0；而字符网格
//     全段都吃。这一差别现在就是 style 里的 snap-to-docgrid，与字号、行距同级，
//     由这个函数统一读，部件自己不写分支。
//
// 三、Word 的段落对话框上有什么，style 里就有什么，词汇一致，对着 docx 抄。
//
// *拆成 sets 与 shows 两半*，rules 只是把两半叠起来。拆开是为了正文那一档：
// set 规则能重发（内层压外层、不叠加），iota-hit 在文档级发一次，三个 matter 用
// 段级并好的版面再发一次，段级改的行跨度、版心就落到正文段落上；show 规则
// *绝不能重发*——latin-run 那条会在西文前补 h(tracking)，重发就补两次——
// 所以只在文档级装一次，用到版面的数改成在自己的 context 里从 layout-state 取
// （layout: auto）。部件层照旧写 rules，两半用同一份版面。

// 字体角色：style 的 font；没写就从 font-zh 推——font-zh 是「这一行的自然行高
// 按哪一档字体算」，"latin" 意思是这行没有汉字、按西文算，字体自然走 serif。
// 两者分开是必须的：英文题目那一行 font-zh 是 "latin"（西文行高），
// 字体却要 serif 这个角色，一个键担不了两件事。
#let _role-of(style) = style.at("font", default: {
  let zh = style.at("font-zh", default: "songti")
  if zh == "latin" { "serif" } else { zh }
})

// 纯西文段（font-zh: "latin"——这一段没有汉字）：西文吃半格，直接 set，不发
// latin-run 那条 show 规则里的边界补偿。那条规则给每个西文 run 前面补「前一个汉字在
// run 边界丢掉的字距」，可这一段前面没有汉字，补出来就是一段假缩进（实测目录里
// 「Abstract」的 A 落在 85.50，Word 85.03）。英文摘要、英文目录、英文内封、英文题注
// 都走这一支。
#let _pure-latin(style) = style.at("font-zh", default: "songti") == "latin"

// latin-bold 这一档的加粗走哪条路。要在 context 里调（查探针那张表）。
//
// *字体表那条*：整段 set weight，中西两槽各自挑面——这一档中文字没有真粗面才走得成，
// 详见下面 shows 里那段注释。*show 规则那条*：中文字有真粗面（或家族不在）的那几档，
// 只能逐段挑西文槽的字包一层 weight（latin-slot-run）。两条互斥。
#let _table-bold(style) = (
  style.at("latin-bold", default: false) and fonts.lacks-bold(_role-of(style))
)
#let _regex-bold(style) = (
  style.at("latin-bold", default: false) and not fonts.lacks-bold(_role-of(style))
)

// 西文的字距是汉字的一半——两截都是。
//
// *网格增量*：Word 按「占几格」发，全宽字占一格拿整份（charSpace/4096 =
// 0.4543），半宽的西文占半格拿半份 0.227，见 shows 里 latin-run 那条规则的注释。
//
// *样式的字符间距*（字体对话框「字符间距：加宽／紧缩 n 磅」）：Word 给汉字
// 发*两份*、给西文发*一份*。量官方本科理工范例 PDF 第 11 页的章标题
// 「第4章 基于FLUENT软件的轴承静态特性分析」（heading 1 样式紧缩 0.2 磅）：汉字
// 实排步进 18.04 = 18 + 0.4543 − 0.4，紧缩了对话框的两倍；F/L/U/E/N/T 的步进
// 10.008 / 10.998 / 12.996 就是 Times 18pt 的字身宽——半格 0.227 与一份 0.2
// 相抵。样式表里 tracking 存的是汉字实排的那两份（chapter −0.4pt），西文对半：
//
//   西文每字   字身宽 + 0.227 − 0.2 = 字身宽 + 0.027（范例 +0.004，差在 Word
//              1/300 英寸落笔）
//   汉字每字   字号 + 0.4543 − 0.4 = 字号 + 0.054
//
// 对拍：tests/check-heading.py 逐字量 FLUENT 的步进。
#let _latin-tracking(style, computed) = (
  (if computed.snap-h { computed.docgrid.tracking / 2 } else { 0pt })
    + style.at("tracking", default: 0pt) / 2
)

// 这一档 set 给正文的字距：纯西文段是半份，别的是整份。shows 里的守门拿它认
// 「还没被处理过的本档文本」
#let _set-tracking(style, computed) = if _pure-latin(style) {
  _latin-tracking(style, computed)
} else {
  tracking(computed, tracking: style.at("tracking", default: 0pt))
}

// shows 里的 context 取版面：current 关着就是装规则时那一份（部件层）；开着从
// layout-state 取当前这一节的（正文那一档）。state 还是 none 的地方——第一页的页眉
// 在文档级那次 update 之前就排了（实测页眉读到的是本页开头之前的值）——退回装规则
// 时那一份，与先前一字不差。*要在 context 里调*
#let _layout-of(layout, current) = {
  if not current { return layout }
  let s = layout-state.get()
  if s == none { layout } else { s }
}
// 整段换成西文的行盒——*只换盒，不碰字距*。
//
// 这一段没有汉字时，行高该按真正在排的那副字（Times）算，而不是按本档挂的中文
// 字体算。判据与换法与正文那一支同源，见 latin-par；*标题、题注走这一支*：
// 它们的字距是本级自己的 w:spacing，Word 对西文照样整份发，不折半。
//
// *而且字距一动就把加粗弄丢了。* part.rules 里那条 show latin-run-led 拿
// 「当前字距等不等于本档 set 的那一份」认「还没被处理过的本档文本」（见
// _set-tracking），latin-par 把字距换成西文那半份，守门就认不出来，于是英文档
// 标题的西文那一槽不再加粗——实测深圳研究生英文报告的章节标题掉成
// TimesNewRomanPSMT。只换盒不动字距，守门照旧认得。
#let latin-box(style, layout, doc) = {
  let metrics = resolve(style, docgrid: layout.docgrid)
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = resolve(style + (font-zh: "latin"), docgrid: layout.docgrid)
  set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
  doc
}


// 纯西文段：整段没有一个汉字的段落。Word 里一行的行高取这一行实际用到的字体的
// 最大值，整段都是 Times 的段落每一行都按 Times 算（范例英文摘要 17.25 对中文摘要
// 19.45）。这里把行盒、字体表、字距整段换成西文那一份，与 font-zh: "latin" 的样式
// （英文题目、英文内封）走同一支——整段直接 set，不逐 run 挑。
//
// *为什么不靠 latin-line-rules 逐 run 换。* 那一条按 latin-run 收拾纯西文的 run，
// 而 latin-run 要求至少含一个拉丁字母（理由见 constants.typ）。一段英文里夹的引号是
// smartquote 元素、两对引号之间的「, 」只有标点和空格——都不匹配，那一行就退回汉字
// 行盒把整行撑高，实测英文摘要含引号的两行比 Word 高 2 到 4pt。整段换就没有漏网的
// 碎片；先前另立的拉丁段落制度（latin-par，英文摘要手动接入）就是这么做的，现在由
// src/blocks/body.typ 的 show par 按「整段有没有汉字」自动挑，不用任何标记。
//
// *这里不设 lang。* text.lang 在本项目里是文档语言（哪一份标题上台、词条走哪一层，
// 见 src/engine/lang.typ），同一个字段两种含义会打架；断字由 hyphenate-rules 按
// text.hyphenate 单独管，行高走的是 font-zh: "latin"，都不经过 lang。
//
// 字体：中文语境里弯引号、破折号、省略号、间隔号归中易（见 src/engine/fonts.typ 的
// covers），英文段落里它们该是西文形。*不能整张字体表换掉*——par 这一层的
// set text(font:) 压得过 lib.typ 里 show raw 的 set（代码字在段落成形之前就已经排好，
// 实测代码里的引号掉到了 Times），所以只把这几个字符挑出来换：一条 regex 规则，
// 与 src/blocks/quotes.typ 里智能引号那条落在同一份字体上。字距直接 set 成半份；shows 里 latin-run 那条规则在这
// 一段里照常跑（它先于 par 那一层跑，读到的还是正文的整份字距），拆超长单词照做，
// 边界补偿它自己按「前面有没有汉字」判，这一段里没有汉字，一处都不补。
//
// *要在 context 里调*（读字体表）；调用方已判过整段没有汉字。
#let latin-par(style, layout, doc) = {
  let metrics = resolve(style, docgrid: layout.docgrid)
  // 贴行网格的段落照汉字行盒（西文行也落在格子上）；latin-line-height 是 "cjk" 时
  // 西文也走汉字那一份——两条与 latin-line-rules 同一个判据
  if metrics.snap { return doc }
  if layout.docgrid.at("latin-line-height", default: auto) == "cjk" { return doc }
  let l = resolve(style + (font-zh: "latin"), docgrid: layout.docgrid)
  let f = fonts.current.get()
  set text(tracking: _latin-tracking(style, l))
  show regex("[\u{2018}\u{2019}\u{201C}\u{201D}\u{2014}\u{2026}\u{00B7}]"): set text(font: font("serif", f.families))
  // 行盒那一半与标题、题注共用，见 latin-box
  latin-box(style, layout, doc)
}

// 一段字该拿哪一份行盒：*段里没有汉字就整段换西文的，有就只换西文那几个 run*。
// 在 show par 里调，要在 context 里（版面由调用方按当前这一节取）。
//
// *判据在段这一级，不在 run 这一级。* 题序那个「2.1.1」是数字，而 latin-run
// 那条 regex 认的是拉丁*字母*——数字与点号是 Common，留在汉字那个 run 里，
// 于是一行西文标题只要带着题序，整行就退回汉字行盒。实测英文报告：章标题两行之间
// 26.65（原件 25.92）、节→条 29.31（26.64）、条→正文 25.78（24.48）。正文早就是
// 段级判据了（src/blocks/body.typ），标题与题注跟着走同一条。
//
// *「真有西文才算」那一条判的是「有没有排字用的可见字符」*：报告首页那几格
// 填空格的段落 plain 只抽得出一个零宽空格，空段、只有方框（□，不在 ASCII 里）
// 占位的段都不是西文段。判据取「有 ASCII 可见字符」——先前写的是「有拉丁字母或
// 数字」，于是一段纯半角句点（英文表单里那几行「.......」）落在了外面，行盒退回
// 汉字那一份，段与段之间因此多 0.91。省略号那几个 ambiguous 码位怎么算，见
// content.typ 的 latin-only。
#let latin-auto(style, layout, it) = {
  if latin-only(plain(it.body)) {
    latin-par(style, layout, it)
  } else {
    latin-line-rules(style, docgrid: layout.docgrid, it)
  }
}

// 一条样式的 set 那一半：字与段。families 给了就一并设字体（已经解析好的家族表），
// none 不碰字体——正文那一档的字体是 iota-hit 在最外层设的。
// latin-par：这一档的段落参不参与正文那条「纯西文段换西文行盒」的 show par，
// 见 src/engine/constants.typ 的 latin-par-features。默认不参与
#let sets(style, layout: no-docgrid, families: none, latin-par: false, doc) = {
  let computed = resolve(style, docgrid: layout.docgrid)
  let bold = style.at("bold", default: false)
  set text(
    size: computed.size,
    // 行盒：两条边写成「em 系数 + 绝对量」的复合长度，leading 置零。
    // 行盒高与基线落点全由这两条边定，字体自己的度量完全被盖掉——
    // 换成苹方（自然行高 1.82，差四成）逐条基线不变。
    top-edge: computed.top-edge,
    bottom-edge: -computed.bottom-edge,
    // 范例的 Normal 写着 widowControl=0，全文没有一段覆盖它。
    // Typst 默认会拦孤行寡行，不放开的话该排 33 行的页面被压成 32 行。
    costs: (widow: 0%, orphan: 0%),
    // 字距增量与字号无关，见 src/engine/layout.typ 的规则八。全宽字一整份，
    // 纯西文段半份（见 _pure-latin）
    tracking: _set-tracking(style, computed),
    weight: if bold { "bold" } else { "regular" },
    ..(if families != none { (font: families) } else { (:) }),
    // 角色写进 text，给视觉矫正认，见 src/engine/constants.typ 的 role-tags；
    // 参不参与正文那条 show par 也写在这儿
    features: role-features(_role-of(style)) + latin-par-features(latin-par),
  )
  // *行内代码的行盒跟这一段的*，不跟 lib.typ 那条 show raw 给的等宽字体单倍行盒。那条
  // 是给代码块的（codly / zebraw 量它定框高），show-set 又钻得进任何地方——内封字段表
  // 的值格里只有一个占位符 `supervisor`（src/config/info.typ 的默认值），格子自己的行盒
  // 就成了 Consolas 单倍的 12.9，比标签那一格的 1.5 倍四号矮，值整个浮到标签上面（实测
  // 高 4.8）。正文里夹的行内代码本来就不撑行（行盒取各 run 最高的），改成同一个盒子
  // 不动任何东西。写成绝对量：em 在 raw 那个小一号的字号上解就又矮了一截
  show raw.where(block: false): set text(
    top-edge: computed.top-edge.abs + computed.top-edge.em * computed.size,
    bottom-edge: -(computed.bottom-edge.abs + computed.bottom-edge.em * computed.size),
  )
  set par(
    leading: 0pt,
    spacing: calc.max(computed.above, computed.below),
    justify: style.at("justify", default: false),
    // 两个方向各是各的，见上面的 _indent——带 em 的长度在
    // context 外比不了大小，所以不折成带符号的一个数再 calc.max 拆回来
    first-line-indent: (amount: computed.indent.first-line, all: true),
    hanging-indent: computed.indent.hanging,
  )
  // 视觉矫正（把这一档的字挪到 Windows 那一档的高度）*不在这儿发*：全篇只挂
  // 一条，在 lib.typ，按 text.font 反推角色——部件层各挂一份会层层累加、外层压
  // 内层，见 src/engine/fonts.typ 的 baseline-rules。这儿写进 text 的 font 就是
  // 它反推的依据。
  doc
}

// 一条样式的 show 那一半：伪粗、代码字的字距、西文 run 的字距与加粗。
//
// 部件层照旧：layout 给整份，规则里的数都按它算。正文那一档（iota-hit 在文档级
// 装一次）把 current 打开：规则里用到版面的数（字距的三份、西文行盒、版心宽）改在
// 每条规则自己的 context 里从 layout-state 取——段级改了字距、版心，正文里的西文
// 跟着换；layout 那时只管一件事：*装不装那两条 show 规则*。字符网格有没有
// （snap-h）决定要不要把西文 run 切出来，而一条 show regex 哪怕原样交回也会造 run
// 边界、动到字距（实测无网格的段落加一条 show latin-run: it => it，PDF 就不同），
// 所以不能一律装上再在里面判。段级只能改网格的数，不能开关网格——
// src/flow/matter.typ 在并版面时拦这一档。
#let shows(style, layout: no-docgrid, current: false, doc) = {
  // 装规则时的版面：只用来定装不装
  let installed = resolve(style, docgrid: layout.docgrid)
  let bold = style.at("bold", default: false)
  let role = _role-of(style)
  let pure-latin = _pure-latin(style)
  let latin-bold = style.at("latin-bold", default: false)
  // *加粗这一档也要能合成。* 封面、内封那些加粗走的是 sets 里那条
  // weight: "bold"，不是 #strong——src/engine/synth.typ 挂的 show strong 够不着它们。
  // 中易宋体没有粗体面，Typst 静默换成常规面，排出来与正文一模一样；这一处
  // 把 synth 那一份描边补上，判据与 #strong 那一路同一个（见 wants-bold-for）。
  //
  // *latin-bold 走字体表那一层*：整段 set weight，中西两槽各自挑面。Typst 从不
  // 合成粗体（见 src/engine/synth.typ 抬头），黑体没有粗体面就静默用常规面，汉字
  // 纹丝不动；Times 有真粗面，西文槽的字形连同数字、希腊字母、± % №、上下标、
  // box/link 隔出来的碎片一律跟着粗。与 Word 同构——那边也是 run 上一个 <w:b/>、
  // 两槽各自找面（博士范例内封「20 年 6 月」每个 run 都带 <w:b/>，学校发的 PDF 里
  // 2020 与 6 是 TimesNewRomanPS-BoldMT）。
  //
  // *为什么不继续用下面那条 show 规则*：它认的是 latin-run，中间那一位是
  // \p{Latin}，*一段字里没有拉丁字母就整段匹配不上*——纯数字、希腊字母、% ± №，
  // 以及被 #super / #sub / #box / #link 隔成独立片段的纯数字，全都留在常规面
  // （H#sub[2]O 里 H 粗、下标 2 细）。放宽那条正则要另抄一张「哪个码位排在哪一槽」
  // 的白名单，与字体表那张正本注定漂移；而且每放宽一次就多切一处 run 边界，每处
  // 边界丢一份网格增量（见 src/engine/constants.typ 的 cjk-run）。走字体表一条
  // show 规则都不加，版面一格不动。
  //
  // *门：这一档中文字不能有真粗体面*。Noto、Fandol 那几档有，整段 set weight 会把
  // 汉字也排成真粗，而原件那几行 run 上没有 <w:b/>——那几档走下面 bold-rules 那条
  // show 规则。家族不在也走那条，理由见 fonts.lacks-bold——与伪粗那一路共一句判据。
  //
  // *公式不用挡，也别去挡*：Typst 选数学字面不读 text.weight（0.15.1 实测整段
  // 加粗前后逐字节相同）。反过来写 show math.equation: set text(weight: "regular")
  // 才是改坏了——typst 档实测把 NewCMMath-Book 换成了 NewCMMath-Regular。
  show: it => context {
    if bold and _synth.wants-bold-for(role) { _synth.fake-bold(it) } else if _table-bold(style) {
      set text(weight: "bold")
      // *「× ↑ □」那几个全宽符号由宋体那条 covers 抢走*（见 fonts.cjk-first）。
      // 宋体有真粗面的档会把它们也排成真粗，而原件里它们是常规——挑回来。
      // 没粗面的档一条规则都不装，免得白造一处 run 边界
      if not fonts.lacks-bold("songti") {
        show fonts.cjk-first: set text(weight: "regular")
        it
      } else { it }
    } else { it }
  }
  // 西文那一段单发一条 show 规则，管两件事。
  //
  // *一、西文只吃半份字距增量。* Word 的网格按「占几格」发字距：全宽字
  // 占一格拿一整份（charSpace/4096 = 0.4543），半宽的西文占半格只拿 0.227。
  // 实测封面的英文题目，Word 的字形步进 R→E 13.230；不分宽窄一律发满是
  // 13.450，每个字形多 0.220——一行三十几个字形就多出 7.95，约合半个字符，
  // 满行时正好少放一个字母。
  //
  // *二、中文标题里夹的西文要加粗*（而中文本身、黑体，不加粗）。字体表
  // 的条目只有 name 与 covers 带不了字重，整行 set weight 又会把黑体合成加粗，
  // 只能靠 show 规则分出这一段。
  //
  // *两件事必须合在一条规则里。* show 规则只在它自己所在的块里生效：
  // 写成 if computed.snap-h { show … } 而把 doc 放在外面，那条规则等于没发（实测
  // 西文步进纹丝不动）。而两条 show 规则匹配同一段文本又会互相嵌套。
  //
  // 代价是这条规则造 run 边界、吃掉边界处那一段 tracking。纯西文的行整行
  // 就是一个 run，只有首尾两处；中西混排的行每段西文两处。加粗那一档套一层
  // tracking-pad 补回来（见 src/engine/tracking.typ）。比起每个字母都多 0.220，
  // 这个代价小得多。
  // 边界丢掉的那一段在*左侧*补。
  //
  // 前面那个汉字丢的是整份 tracking，补在这一段西文的左缘，位置与丢的地方
  // 重合，是等价的。
  //
  // *右侧不能补。* 右侧那一段间距会夹在西文与后面的字符之间，
  // 智能引号的开闭状态机看「前一个字符」，看到的成了间距而不是字母，
  // 于是把闭引号也判成开引号——实测 "the second chapter" 排出来是
  // 「“the second chapter“」，右引号方向错了，而且吞掉一个空格。
  // 只在左侧补则完全没有这个问题（逐层隔离验过：恒等函数、只在左侧补、
  // 函数里换字距都正常，只有右侧补会坏）。
  //
  // 代价是「西文接汉字」那一侧的半份 0.227 补不回来。比起排错引号，
  // 这个代价小得多。
  //
  // 下面两条规则里的数（字距的三份、西文行盒、版心宽）都在 context 里按当前版面
  // 现算，不用装规则时那一份——段级改了字距，正文里的西文跟着换。
  // *代码字按西文算。* Word 把 raw 里的字当西文：行内代码与代码块在带字符
  // 网格的段里每字只吃半格 0.227（连带样式字符间距的那一份），不是汉字的整份
  // 0.4543。sets 里 set 的整份字距会原样落到代码上——下面那条 latin-run 规则钻不进
  // raw 元素（regex 只匹配裸文本），实测 demo-mono 的代码行每字 0.4543，该是
  // 0.227。这儿按元素单发一条，取同一个 latin-tracking；块级 raw 同一条。
  //
  // *只在 snap-h 时发。* 没有字符网格的段（报告、typst 档）里 latin-tracking
  // 只剩样式那半份，而那里的代码本来就该按外面 set 的字距排；那儿连规则都不挂。
  //
  // *层层套着的 rules 里外层赢*，与下面 latin-run 那条一样：正文那一份挂在
  // 整篇上，章标题里的行内代码会被章那一份与正文那一份先后各处理一次，后处理的
  // 正文那一份 set 的字距贴着字——实测章标题里的 `abcd` 每字 +0.227，该是章的
  // 0.027。所以同样比「当前生效的 tracking 是不是本档 set 的那一份」：内层处理过
  // 的 raw 上字距已经换成半份，外层读到的对不上，放行。
  //
  // *进入 raw 的那处边界照 latin-run 的办法在左侧补一整份*：前面那个字丢的是
  // 外面那一档的整份 tracking。行内的才补，块级的自成一段，没有边界。不能写 weak
  // ——弱间距紧挨着前面的空格时是取代它，不是取较大者（实测「码 `abc`」的空格
  // 被吃掉，排成「码abc」）；代价是段首的行内代码前多 0.4543 的空，与 latin-run
  // 那条一样。
  //
  // *已知缺陷。* raw 里面 latin-run 那条 regex 照样切 run（引号、汉字两侧），
  // 切开处丢的是半份 0.227，而下面那条规则在 raw 里认不出本档（字距已经是半份），
  // 不补——`print("hi")` 两个引号处各窄 0.227。先前是各宽 0.227（补的是整份）。
  // *raw 里的汉字也按半份*：Word 把代码字当西文，没有靶子，PIN。
  let raw-rules(body) = if installed.snap-h {
    show raw: it => context {
      let computed = resolve(style, docgrid: _layout-of(layout, current).docgrid)
      let full-tracking = tracking(computed, tracking: style.at("tracking", default: 0pt))
      if text.tracking != full-tracking { it } else {
        if not it.block { h(full-tracking * fonts.boundary-loss()) }
        set text(tracking: _latin-tracking(style, computed))
        it
      }
    }
    body
  } else {
    body
  }
  show: raw-rules
  // *走不了字体表的那几档*：逐段挑出西文槽的字包一层 weight。选择器是 latin-slot-run
  // ——字体表分槽的补集，不是 latin-run（那条要求有一个拉丁字母垫底，纯数字、希腊字母、
  // 上下标里的碎片够不着）。*只包不 set*：包一层压得过下面那条规则 set 的字距，两条不
  // 打架（那条注释里「两件事必须合在一条规则里」讲的是 set）。*要先定义*：后定义的先
  // 执行，让下面那条先把「前导汉字＋西文」连着处理完，这条再包，前导字才不会被这条
  // 先切走、左侧补偿才发得出。
  //
  // 代价：汉字接「没有拉丁字母的片段」处多一道 run 边界，丢一份网格增量（补不了——
  // 补法会连 Typst 的 0.25em 中西文间距一起吃掉）。这几档本来就没有 Word 标定。
  let bold-rules(body) = context {
    if not _regex-bold(style) { return body }
    show latin-slot-run: r => context {
      if text.font.contains(lower(fonts.current.get().math)) { r } else { text(weight: "bold", r) }
    }
    body
  }
  show: bold-rules
  // 纯西文段的字距已经在 sets 里 set 好；这条规则对它仍要发——拆超长单词与加粗都在
  // 这里做，只有那段边界补偿不发，见 _pure-latin
  if installed.snap-h or latin-bold {
    show latin-run-led: it => context {
    let l = _layout-of(layout, current)
    let computed = resolve(style, docgrid: l.docgrid)
    let full-tracking = tracking(computed, tracking: style.at("tracking", default: 0pt))
    let set-tracking = _set-tracking(style, computed)
    let latin-tracking = _latin-tracking(style, computed)
    // 本档西文 run 的行盒，与 latin-line-rules 算的是同一份
    let latin-line = resolve(style + (font-zh: "latin"), docgrid: l.docgrid)
    // *只管本档自己的段落。* rules 是层层套着用的：正文那一份挂在
    // 整篇文档上，目录、摘要、封面各自再挂一份。同一属性上外层赢，于是
    // 部件里的西文 run 拿到的是*正文*那一份——连带下面那段左侧补偿
    // 也照发，而部件里的西文常常是整条的头一个 run，前面没有字可补，补出来
    // 就是一段假缩进（实测目录里的西文条目左缘落在 85.50，Word 85.03）。
    //
    // 判据取当前生效的 top-edge：行盒是 sets 写在 text 两条边上的，与本档的一份
    // 相同才是本档的段落。这是个样式查询，不进布局回路。src/blocks/body.typ 里
    // 那条 show par 用的是同一个判据。
    //
    // *西文行盒的那一份也算本档。* latin-line-rules（标题、题注、目录条目
    // 都挂）给同一段西文 run 换上西文的行盒，而它是内层、先落到 run 上，这儿读到
    // 的 top-edge 就成了西文那一份——只认汉字那一份的话整条规则被跳过，半份字距
    // 与加粗都发不出去：实测章标题「基于FLUENT软件」里 F 的步进 10.062 =
    // 10.008 + 0.4543 − 0.4，吃的是汉字的整份网格增量与整份紧缩（该是半份 0.227
    // 与一份 0.2，净 +0.027）；英文档的「Chapter 1 Introduction」同样每字 +0.055。
    // 两份都按本档的 style 算。
    //
    // *可西文那一份各档写的是同一个 em 式子*（0.08pt + 0.93em，正文与四级标题
    // 一样），只比它认不出是谁的段落：正文那一份挂在整篇上，章标题的西文 run 会被
    // 章那一份与正文那一份先后各处理一次，后处理的（外层）那一份 set 的字距贴着
    // 字，压掉内层——实测章标题的 F 步进 10.235 = 10.008 + 0.227，紧缩没了。所以
    // 再比*当前生效的 tracking 是不是本档 set 的那一份*：内层处理过的 run 上
    // 字距已经换成半份，外层读到的对不上本档的整份，放行；别档的段落整份也不同。
    // 纯西文段 set 的本来就是半份（_pure-latin），拿半份认——拿整份认的话英文题目
    // 整段被放行，超长单词不拆了（实测封面英文题目里的长词溢出版心）。
    // 这同样是样式查询，不进布局回路。
    //
    // *西文行盒那一份不认公式里的字。* 行内公式里正体的 Re、Im
    // （src/blocks/math.typ 用 op 排的）也是拉丁字母，行盒又被正文那条 show par 的
    // latin-line-rules 换成了西文那一份——认了西文行盒之后这条规则会钻进行内公式，
    // 补偿那一段 h() 把 op 与操作数之间的细空打断（实测 2.0 掉到 0.68，
    // tests/check-math.py 当场红）。公式里的字距没有 Word 的靶子（OMML 对象），
    // 一切照旧：行内公式先前就不在这条规则里（行盒是西文那一份），行间公式先前
    // 就在（行盒是汉字那一份，d、p 那些字母吃半份、前面补一整份），两边都不动。
    // 认公式：math-rules 给公式设的字体表里有数学字体，正文的表里没有
    // （text.font 报的家族名是小写的）。PIN。
    let in-math = text.font.contains(lower(fonts.current.get().math))
    // *公式里的字一律不碰*：这条规则把匹配到的字重新发成一段字符串，math 给
    // 变量的斜体样式（𝐸、𝑚、𝑐 那套码位）在重发时就丢了——实测行间公式 E = m c²
    // 与符号表里的 $E$ 排成了直立的 E（tests/check-nomenclature.py 当场红）。
    // 先前靠 own-line 只把行内公式挡在外面，行间公式与符号表的 $E$ 行盒是汉字那
    // 一份，挡不住。公式里的字距没有 Word 的靶子，不发也无妨。
    let own-line = (
      not in-math and (
        text.top-edge == computed.top-edge or text.top-edge == latin-line.top-edge
      )
    )
    // *前面有没有汉字，正则自己看。* 匹配的是 latin-run-led：西文 run 连它前面
    // 那一个不在西文字符集里的字（汉字、中文标点、弯引号）一起吞进来。有这个字，它
    // 在 run 边界上丢的整份字距要补；段首、智能引号元素之后的西文前面没有它，什么
    // 都不补——先前这里不分青红皂白补一整份，以西文起头的段落、目录条目、成果条目
    // 全都多出 0.4543 的假缩进（目录里的西文条目左缘 85.50，Word 85.03）。
    let lead = it.text.match(regex("^" + latin-run-lead))
    let latin-text = if lead == none { it.text } else { it.text.slice(lead.end) }
    if not own-line or text.tracking != set-tracking { it } else {
      // 放不下的超长单词就地拆开，见上面 _long-word-min 的注释。
      //
      // *拆开的那一段字距要照发一整份。* 零宽空格本身不吃 tracking
      // （实测发半份，每个字母就少 0.114，一行反而多塞进一个字母），所以
      // 拆开之后每个字母的步进与没拆时一样，都是「字宽 + 半份网格增量」。
      //
      // 这一段得*显式*写 text(tracking:)：插了零宽空格之后这段文本
      // 不再匹配 latin-run（那条规则的字符集里没有 U+200B），外面 set 的
      // 半份字距落不到它头上，会退回汉字那一档的整份 0.4543——实测每个
      // 字母多 0.454，32 个字母的行多出 7.3pt，正好吞掉最后一个字母。
      //
      // 拆词*必须在这条规则里做*，不能另发一条 show 规则：两条规则
      // 匹配同一段文本时，同一属性上外层赢，另发的那条改不动这里设的
      // tracking（实测步进纹丝不动）。
      // *没有超长单词就原样放行，不要重建。* 把 it.text 拆成词再拼回去
      // 会把*行首那个空格*弄丢——拼出来的内容里它成了一段独立的空白，
      // Typst 在段落开头会把它裁掉，实测「chapter" and」排成「chapter”and」。
      // 而超长单词是极罕见的，绝大多数 run 走不到重建那一支。
      let avail = l.text-width
      let words = latin-text.split(" ")
      let needs-break = avail != 0pt and words.any(w => (
        w.clusters().len() >= _long-word-min and measure(text(w)).width > avail
      ))
      let body = if not needs-break { latin-text } else {
        words.map(w => {
          if w.clusters().len() >= _long-word-min and measure(text(w)).width > avail {
            text(tracking: latin-tracking, _long-word-chunks(w.clusters()).join("\u{200B}"))
          } else { w }
        }).join(" ")
      }
      // *已知缺陷。* 这一段 weak 间距紧跟在*闭引号*后面时，会把
      // 引号与西文之间那个字面空格吃掉——「chapter" and」排成
      // 「chapter”and」。试过「run 以空格开头就不补」这个判据，能治引号
      // 那一档，却会把「汉字接西文」那一档（基于 CFD 方法，中间有空格）
      // 的补偿一并去掉，实测「于」的步进从 22.4543 掉到 22.0。
      // 两害相权，先保住字距，缺陷记在这里。
      // 前导的那个汉字自己排出来，两侧各补一整份：它前面那个字因为这里造的
      // 边界丢了整份，它自己在西文前面又丢一份。
      // 补多少份由开机探针定（fonts.typ 的 probe-boundary）：上游修了 run 边界丢字距
      // 的 bug，这里自动归零。
      //
      // *纯西文段（font-zh: "latin"）的前导字只排不补*：它的字距本来就是半份，
      // 没有整份可丢。但前导字*必须排出来*——封面英文题目「…BEARING：A CASE
      // STUDY」里的全角冒号就是它，先前这一支把它连同补偿一起省掉，冒号丢了
      // （tests/check-subtitle.py 当场红）。
      // *能不重发就不重发。* 返回字符串等于把这一段文字*重新发一遍*，它的
      // span（源码位置）就成了本文件这一行——tinymist 从预览跳回源码时，西文落进包里，
      // 汉字却好好的（没有一条规则重发汉字）。所以除了拆超长单词那一支，一律原样交回。
      //
      // *前导字那一支靠里层规则。* 补偿要落在「前导字之前」与「前导字与西文之间」
      // 两处，先前是把整段拆成 h + 前导字 + h + 西文串重拼，西文那一半就重发了。改成
      // 里层再挂一条只管西文那一段的规则：它自己发第二份补偿、自己 set 字距与加粗，
      // 前导字与西文都原样过。两条规则的选择器不同（latin-run 认不出前导那个汉字），
      // 不会互相递归；里层造出的 run 边界与先前拆开时那一处是同一个，补的数也一样。
      if not needs-break {
        let loss = if lead == none or pure-latin { 0 } else { fonts.boundary-loss() }
        show latin-run: r => {
          if loss != 0 { h(full-tracking * loss) }
          set text(tracking: latin-tracking)
          r
        }
        if loss != 0 { h(full-tracking * loss) }
        it
      } else {
        if lead != none {
          if pure-latin { lead.text } else {
            let loss = fonts.boundary-loss()
            h(full-tracking * loss); lead.text; h(full-tracking * loss)
          }
        }
        {
          set text(tracking: latin-tracking)
          body
        }
      }
    }
    }
    doc
  } else {
    doc
  }
}

// 两半叠起来：set 在外、show 在内，与先前一个函数里先 set 后 show 的嵌套一样。
//
// set-font 默认关：正文那一档的字体是 iota-hit 在最外层设的，部件不该盖掉它。
// 标题、封面这些自己指定字体的部件把它打开，字体从 style 的 font-zh 取角色。
#let rules(
  style,
  layout: no-docgrid,
  set-font: false,
  // 直接给字体表（已经解析好的家族名）。标题那一档的角色表是从外面传进来的，
  // 不走 fonts.current，用这个口子把它送进来。给了就不再查 fonts.current。
  families: auto,
  // 这一档参不参与正文那条「纯西文段换西文行盒」的 show par，见 sets
  latin-par: false,
  doc,
) = {
  let apply(families) = {
    show: sets.with(style, layout: layout, families: families, latin-par: latin-par)
    show: shows.with(style, layout: layout)
    doc
  }
  if families != auto {
    return apply(families)
  }
  if set-font {
    context apply(font(
      _role-of(style),
      fonts.current.get().families,
      latin: style.at("font-latin", default: "serif"),
      em-dash: fonts.current.get().at("em-dash", default: "cjk"),
    ))
  } else {
    apply(none)
  }
}

// ── 样式表 ────────────────────────────────────────────────────────
//
// Word 的样式窗格：一条 = 字体对话框 + 段落对话框。默认表住 src/config/styles.typ
// （只放值），iota-hit(styles:) 收的局部字典在这里逐条并到默认表上——用户写
// styles: (body: (size: "wuhao")) 只换字号，正文那一档别的键照旧。
//
// *键名不认识当场报错*，表级与条目级都验：写错的键静默失效就是排出一份
// 不合格的东西还不知道。条目级的词汇就是下面 style-keys 这一张，与 rules / resolve
// 读的键一一对应。
#let style-keys = (
  "font-zh", "font", "size", "bold", "latin-bold", "tracking", "line-spacing",
  "above", "below",
  "first-line-indent", "hanging-indent", "left-indent",
  "align", "snap-to-docgrid", "justify",
)

// 每个键的值域。键名对了、值不认识也要当场报错——先前 align: "center"（字符串，
// 不是 Typst 的 center）静默按左对齐排、font: "italic" 静默走 serif、
// tracking: 1（没单位）到排版时才炸出「cannot add length and integer」。
//
//   font-zh   这一行的自然行高按哪一档字体算：中文角色名，或 "latin"（这一行没有汉字）
//   font      字体角色：serif / sans / mono，或直接写中文角色名（标题、封面那些）
//   size      字号，长度（zihao.xiaosi 或 12pt）
//   tracking  Word 字体对话框的「字符间距」，磅——存汉字实排的值（对话框的两倍），
//             西文与代码拿一半，见 rules 里的 latin-tracking
//   line-spacing  Word 段落对话框的「行距」：single / double / 倍数 / 长度 /
//             (exactly:) (at-least:) (white:)，见 _baseline-gap-endpoint
//   above / below   (lines: n) 或长度，见 _amount
//   first-line-indent / hanging-indent / left-indent   (chars: n) 或长度，见 _indent
//   align     Typst 的 alignment（left / center / right），不收字符串
//   latin-bold  只加粗这一行里的*西文*，汉字不动。*中文字体不该被伪粗*
//             ——黑体没有粗体面，整行 set weight 会让它走描边合成；英文档的报告
//             标题（深圳那两份英文版的 heading 1/2/3 写着 <w:b/>）要的正是
//             「西文粗、黑体照旧」。机制见上面 shows 里那一段
//   bold / latin-bold / snap-to-docgrid / justify   布尔
#let _font-zh-values = (zh-roles + natural-coefs.keys()).dedup()
#let _font-values = en-roles + zh-roles

#let _line-spacing-ok(v) = (
  v in ("single", "double")
    or type(v) in (int, float)
    or type(v) == length
    or (type(v) == dictionary and v.keys().len() == 1 and (
      "exactly" in v or "at-least" in v or "white" in v
    ))
)

// 验一条样式。name 是报错里的路径（"styles.body"、"header.style"）。
// line-spacing-auto：这一条的行距收不收 auto——只有默认表里本来就写 auto 的那几条
// （toc-1～toc-4，按学位挑）收，别的条写 auto 没有解法，当场报错。
#let _figure-keys = ("image", "table", "caption")

// kind：正在验的是 figure 底下哪个子键（"image" / "table" / "caption"），顶层与别的
// 条目是 none；只有 image 与 table 有三段空当那三个键
#let validate-style(entry, name, line-spacing-auto: false, kind: none) = {
  if type(entry) != dictionary {
    panic(name + ": expected a dictionary, found " + repr(entry))
  }
  for (key, v) in entry {
    // *figure 是一把伞*，底下三个子键照 Typst 自己的树：image、table
    // （figure(kind:) 的两种）与 caption（figure.caption），值各是一份样式，递归验；
    // 别的条目上写这三个就是写错了地方。见 src/config/styles.typ 的 _figure
    if name.ends-with("figure") {
      if key not in _figure-keys {
        panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(_figure-keys, key))
      }
      validate-style(v, name + "." + key, kind: key)
      continue
    }
    // 三段空当只有图块表块有：above / below 收 auto（＝ 空一行），gap 是 Typst 的
    // figure(gap:)，同样收 auto（图按内联对象推、表按题注段后），见 lib.typ
    if kind in ("image", "table") and key in ("above", "gap", "below") {
      if not (v == auto or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))) {
        panic(name + "." + key + ": expected auto, a length, or a dictionary with \"lines\", found " + repr(v))
      }
      continue
    }
    // 表格那一档另有两个 Word 表格属性上的键：单元格边距（inset，收长度或 (x:, y:) 字典，
    // 当 Word 的边距、从线内沿量）、三条线（stroke，(top:, header:, bottom:) 三个磅数）
    if kind == "table" and key == "inset" {
      let ok(x) = type(x) == length
      if not (ok(v) or (type(v) == dictionary and v.keys().all(k => k in ("x", "y")) and v.values().all(ok))) {
        panic(name + ".inset: expected a length or a dictionary with \"x\" and \"y\" (Word's cell margins), found " + repr(v))
      }
      continue
    }
    if kind == "table" and key == "stroke" {
      if not (type(v) == dictionary and v.keys().all(k => k in ("top", "header", "bottom")) and v.values().all(x => type(x) == length)) {
        panic(name + ".stroke: expected a dictionary with \"top\", \"header\", \"bottom\" (the three rules, in pt), found " + repr(v))
      }
      continue
    }
    if key not in style-keys {
      panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(style-keys, key))
    }
    let where = name + "." + key + ": "
    if key == "font-zh" and v not in _font-zh-values {
      panic(where + _errors.expected-one-of(_font-zh-values, v))
    } else if key == "font" and v not in _font-values {
      panic(where + _errors.expected-one-of(_font-values, v))
    } else if key == "size" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length such as zihao.xiaosi or 12pt, found " + repr(v))
    } else if key in ("bold", "latin-bold", "snap-to-docgrid", "justify") and type(v) != bool {
      panic(where + "expected true or false, found " + repr(v))
    } else if key == "tracking" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length (Word's character spacing, in pt), found " + repr(v))
    } else if key == "line-spacing" and not (_line-spacing-ok(v) or (line-spacing-auto and v == auto)) {
      panic(
        where + "expected \"single\", \"double\", a number, a length, or a dictionary with "
          + "\"exactly\", \"at-least\", or \"white\""
          + (if line-spacing-auto { ", or auto (by degree-level and category)" } else { "" })
          + ", found " + repr(v),
      )
    } else if key in ("above", "below") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))
    ) {
      panic(where + "expected length or dictionary with \"lines\", found " + repr(v))
    } else if key in ("first-line-indent", "hanging-indent", "left-indent") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("chars",))
    ) {
      panic(where + "expected length or dictionary with \"chars\", found " + repr(v))
    } else if key == "align" and type(v) != alignment {
      panic(where + "expected alignment (left, center, or right), found " + repr(v))
    }
  }
}

// 当前生效的样式表。iota-hit 写进来，目录（toc-1/2/3/4）在 context 里从这儿取；
// 正文、标题、题注三处由 iota-hit 直接传，不必读它。
#let styles-state = state("iota-hit-styles", default-styles)

// 局部样式：#show: styles.with((figure: (table: (line-spacing: 1.5))))，从这里起到作用域
// 末尾按这张表排，字典形状与 iota-hit(styles:) 一模一样。*两路*：有原生对应的键折成原生
// show-set 套在 body 外（表格的字号 → show table: set text(size:)），没原生的（行距、贴格、
// 边距、三条线）改 styles-state、出作用域还原，排格子时在 context 里读。有原生的仍推荐
// 直接写原生（#[ #show table: set text(size: …) … ]），这里只是把 Word 那张卡的格名翻成原生。
//
// *眼下只接了 figure.table*：别的档的消费者读的是 iota-hit 传下去的那一份、不读 state，
// 写了当场报错，不静默
#let scoped(local, body) = {
  if type(local) != dictionary {
    panic("styles: expected a dictionary (the same shape as iota-hit(styles:)), found " + repr(local))
  }
  for (name, entry) in local {
    if name != "figure" or type(entry) != dictionary or entry.keys().any(k => k != "table") {
      panic(
        "#show: styles.with(...): only (figure: (table: ...)) can be changed locally for now; "
          + "change " + repr(name) + " at document level with iota-hit(styles: ...)",
      )
    }
    validate-style(entry, "styles." + name)
  }
  let t = local.at("figure", default: (:)).at("table", default: (:))
  let body = if "size" in t {
    show table: set text(size: t.size)
    body
  } else { body }
  context {
    let cur = styles-state.get()
    let merged = cur
    merged.insert("figure", cur.figure + (table: cur.figure.table + t))
    styles-state.update(merged)
    body
    styles-state.update(cur)
  }
}

// preset 是*这一档材料自带的那一层*（眼下只有报告的正文行距），摆在默认表
// 之上、用户写的之下——用户仍压得过它
#let resolve-styles(local, preset: (:)) = {
  if type(local) != dictionary {
    panic("styles: expected a dictionary, found " + repr(local))
  }
  // *figure 那一条要深并一层*：image / table / caption 是它底下的子键，浅并
  // 会整份换掉
  let join(base, entry) = {
    let out = base + entry
    for key in _figure-keys {
      if key in entry and key in base {
        out.insert(key, base.at(key) + entry.at(key))
      }
    }
    out
  }
  let merged = default-styles
  for (name, entry) in preset { merged.insert(name, join(merged.at(name), entry)) }
  for (name, entry) in local {
    if name not in default-styles {
      panic(
        "styles: unknown style \"" + name + "\"; "
          + _errors.expected-one-of(default-styles.keys(), name),
      )
    }
    validate-style(
      entry, "styles." + name,
      line-spacing-auto: default-styles.at(name).at("line-spacing", default: none) == auto,
    )
    merged.insert(name, join(merged.at(name), entry))
  }
  merged
}

// 按档取一条样式值，查 src/config/styles.typ 的 variant-styles：*先按语言取桶
// （不分语言的 base 桶先并进来），桶里的档位后缀交给 term-for 分辨*——词条用的
// 是同一个查法。档写成具名参数，*报告也是其中一档*（stage）：
//
//     variant-style("body-indent", lang: "en", degree-level: "bachelor",
//                   stage: "interim", campus: "shenzhen")
//
// 终稿那一档不必在调用处判——它自己会落到光键名上（多半是 auto ＝ 不覆盖）。
#let variant-style(name, lang: "zh", ..variant) = term-for(
  variant-styles.base + variant-styles.at(lang), name, variant.named(),
)

// 目录条目的行距按学位挑。局部（用户在 styles: (toc-1: (line-spacing: …)) 写的）
// 不是 auto 就照写的；auto 查 src/config/styles.typ 的 toc-line-spacing-auto——本科
// 1.25，研究生 1.2。与 src/engine/settings.typ 的 resolve-openright 同一个写法。
#let resolve-toc-line-spacing(
  local: auto, degree-level: "doctor", category: "stem",
  stage: "final", lang: "zh",
) = {
  if local != auto { return local }
  // *报告另有一档*，写在键名的 -not-final 上；写 auto 的那几格没有自己的数，
  // 落回下面终稿那一套
  let v = variant-style("toc-line-spacing", lang: lang, degree-level: degree-level, stage: stage)
  if v != auto { return v }
  let by-degree = toc-line-spacing-auto.at(category, default: toc-line-spacing-auto.stem)
  by-degree.at(degree-level, default: by-degree.bachelor)
}
