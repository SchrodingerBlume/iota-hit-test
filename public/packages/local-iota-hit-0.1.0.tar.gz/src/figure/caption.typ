// 题注（图题、表题）：题注那一行、双语，以及 figure / ref 的 show 规则链（caption-rules）。
// 名与号在 ../references/refs.typ（交叉引用共用）；分图题与组图在 kinds/image.typ；三线表
// 与那条 show table 在 kinds/table.typ；续排在 continued.typ；自动拆页在 split.typ；kind 表在 kinds.typ。
//
// 依据是写作指南 2.12 插表 / 2.13 插图（*不是 3.3*，那一节是封面内封）。
// 研究生那一档另见「研究生学位论文写作指南」的（十一）（十二）。
//
// 规范给了什么：
//
//   图序表序*按章编排*，图1-1 / 表6-1；序与名之间空 *2 个半角字符*；
//   名中不用标点、名后不加标点；*宋体 5 号字*；*表题在表上、图题在
//   图下*；图注置于图题之上；正文里必须先有提示（「见图1-1」「如表1-1所示」）；
//   表*不加左右边线*、建议*三线表*；插表上下与正文*空一行*。
//
// 按学位分档：本科、硕士只用中文；*博士中英两种文字，居中，中文在上*。
// 见 src/settings/defaults.typ 的 caption-bilingual-auto。
//
// *行距是我们定的，规范一个字没提。* 取 1.25，与正文同一档（指南 3.2 那张
// 表里唯一给了行距的条目就是「正文 宋体小4号字，多倍行距值1.25，段前0行，
// 段后0行」）。博士范例的双语两行反推不出一致的值——去掉那份 PDF 的缩放后，
// 图题那一跳 14.08、表题 15.51，解出来分别是 1.09 倍与 1.20 倍，*范例自己
// 就矛盾*；唯一自洽的是表题里*纯西文那一跳* 15.03，与 1.25 倍算出的 15.09
// 差 0.06。所以按 1.25 走，不去凑那两个数。
//
// *题与图/表之间取 0，待校。* 范例里图题紧跟着图，但图片下沿量不到，
// 没有干净的实测。哪天有能量的样本再定。
//
// 双语那两行*不设间距*，让行高模型自己算：上行（中文五号 1.25 倍）的行深
// 加下行（西文五号 1.25 倍）的上升部 = 6.355 + 9.874 = 16.23。两行拆成两个
// 紧挨的块而不是一段里软换行——Word 的段内行距与块间距是同一个公式
// （上块深 + 下块升 + max(段后,段前)），拆开只是为了让英文那一行换成西文行高。

#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing
#import banshi.paragraph as hyphenate
#import banshi.layout as chars
#import banshi.content: label-of, plain-text, trim-tail, metadata-of
#import banshi.runs: has-cjk
#import banshi.styles as style-rules
#import banshi.layout as _layout
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": find-en, title-of, doc-lang
#import "./kinds.typ": find-algorithm, in-listing
#import banshi.fonts: english-title
#import "../info.typ": info-get
#import "../settings/resolve.typ": resolve-caption-bilingual, resolve-subcaption-bilingual, resolve-subcaption-gap, resolve-algorithm-style, resolve-raw-style, setting-of
#import "../settings/defaults.typ": caption-separator-auto
// 题注那一档的取值，值住在 src/styles/presets.typ
#import "../styles/presets.typ": default-styles
#import "./kinds.typ" as kinds
#import "./continued.typ": find-continued, continued-source, continued-step, continued-head
#import "./kinds/image.typ": find-subs, find-subs-gap, subs-refs, subs-rows, subfigure-kind, subs-offset, sub-caption, subs-line
#import "../references/refs.typ" as refs
#import banshi.styles as _table

#let _separator(layout) = {
  // *原生那一格就是这一处*：figure.caption(separator:) 说的正是「题序与题名
  // 之间」。用户写了就照写（收内容，写 h(2em) 也行、写 [：] 也行），没写才用本档
  // 的默认——*默认是 auto，所以「写没写过」测得出来*。
  if figure.caption.separator != auto { return figure.caption.separator }
  h(chars.resolve-chars(
    caption-separator-auto.at(doc-lang.get(), default: caption-separator-auto.zh),
    layout,
  ))
}


// 一行题注。lang 决定取哪一层词条与哪一套编号写法。
//
// *名与序之间那一跳还没校准。* 本科范例「图」到「1」步进 13.75，我们
// 15.91，多 2.16。两边都在汉字接拉丁那一处补了东西——Word 补的是网格增量，
// Typst 还另加一份 cjk-latin-spacing。这是 README「汉字接拉丁」记的那一类固有
// 差，留到题注对拍那一轮统一处理。

// term：图与表是词条键（"image" / "table"，名按语言从词条表取）；*自造的 kind 直接
// 传它自己的 supplement*（内容），名就照用户写的印
// first：双语两行里的头一行（线条型伪代码只在头一行上面画顶线）
// 「章号-序号」那个编号闭包。*是哨兵*：caption-rules 用 set figure(numbering:) 装上它，
// 样式链上是不是它就说明用户有没有自己换过编号（闭包比得了身份，见 caption-rules 那一段）
#let _by-chapter-numbering = (..n) => context {
  _numbering.chapter-numbered(here(), n.pos())
}

#let _caption-line(it, lang, term, layout, style, continued: false, by-chapter: true, first: true, source: none, width: auto) = {
  // 附录里名前多一个「附」（附表1-1），判据与理由见 src/heading/numbering.typ
  //
  // *名与号在这儿就算成值，不发 context 元素。* 这一行下面要 measure 一遍来判「一行
  // 排不排得下」；量的内容里若还留着 context / here()，measure 只能拿「最近匹配的元素」
  // 去猜落点，猜的对象每轮迭代都在漂——实测 176 页的文档要跑满 5 轮，站内（fork 的
  // msword 断行）干脆不收敛：counter(heading) 五轮观察到 0、终值 3.3.3，附录两个 state 在
  // none / "A" 之间跳。这个函数的调用处都已在 context 里（show figure.caption 那条，
  // 拆页的头尾各自裹了一层），here() 就是题注自己的落点，与原生 display 读到的同一个
  let supplement = (
    _numbering.appendix-prefix(here(), lang, by-chapter: by-chapter)
  ) + (if type(term) == str { refs.word(lang, term) } else { term })
  // *不编号的图表只剩题名。* 打了 <-> 的那一档 numbering 是 none，
  // 「图」「表」这个名是跟着序号走的（指南：题由*序*与*名*组成），
  // 没有序就不该单挂一个名。
  let numbered = it.numbering != none
  // 编号本身两档共用——同一个计数器，只是前面挂的名不同
  // 续排那一条*不占新号*：Typst 已经替这个 figure 记了一次数，所以显示时
  // 退一格，并把计数器也退回去——否则后面那个真的表会跳号
  let num = if not numbered {
    none
  } else if continued {
    // *续排那一条不占新号*——Typst 已经替这个 figure 记过一次数，退回去，
    // 否则后面那张真图跳号（实测续图之后直接排到「图1-3」）。指南 2.13.2 说的是
    // 「总图题只出现在该页，下页标『图序（续图）』字样」，接的仍是同一个号。
    //
    // 接的是哪一张：写了 #continued(<fig:one>) 就按标签找，没写就接*紧挨着
    // 的前一张*——拆图就是把相邻的一张拆成两半。章号与序号都按*被接的那张*
    // 所在的位置取，不能调 it.numbering 那个闭包：它读的是*排它的那个位置*
    // 的章号，续排页可能已经翻到下一章去了。与表那一条同一套办法，见 _table.continued-row
    //
    // *自动拆页的续页*（source 给了）是另一回事：那不是一个新 figure，Typst 没替它记数，
    // 不退；号就取传进来的那一张（拆页的这一张自己，或它手工续排的链头），见 _split
    context {
      let sel = figure.where(kind: it.kind)
      // 退计数器的那一句要单独发：写进求 src 的块里会与 figure 元素连成一个 sequence（实测）
      if source == none { it.counter.update(v => v - 1) }
      let src = if source != none { source } else { continued-head(sel, find-continued(it.body)) }
      if src != none {
        let seq = counter(sel).at(src.location())
        if by-chapter {
          _numbering.chapter-numbered(src.location(), seq)
        } else {
          numbering("1", ..seq)
        }
      }
    }
  } else if it.numbering == _by-chapter-numbering {
    // 号按章：认的是哨兵闭包（见 caption-rules），不认 by-chapter 那个开关——报告
    // 那一档开关开着、样式链上却是 "1"（实测按开关走印成了「表1-1」）。同一个算法，
    // 只是就地算成字符串
    _numbering.chapter-numbered(here(), it.counter.get())
  } else {
    std.numbering(it.numbering, ..it.counter.get())
  }
  let body = if lang == "en" {
    // 英文档里没写 #en 的回落到中文，与标题同一条规则，见 src/terms/lang.typ 的 title-of
    let e = find-en(it.body)
    // 英文名过一遍大小写（花括号也在这儿剥），见 banshi/src/fonts/case.typ；分图题的
    // 英文行不走这里（_sub-piece 的 body 不在 context 里），先不管
    if e != none { english-title(e, slot: "caption") } else { trim-tail(it.body) }
  } else {
    trim-tail(it.body)
  }
  // 纯西文那一行换西文行高：与目录里「Abstract」那一条同一个处理，
  // 靠 latin-run 逐 run 换罩不住整行，得把基准本身换掉。
  //
  // *按行上真有什么字判，不按「这是英文题」判。* Word 的行高取该行上
  // *实际用到的*字体里最高的那个，所以在英文题里敲汉字，Word 会把整行按
  // 中易的行高撑高；先前这里写 lang == "en"，行高是声明出来的，敲了汉字也纹丝
  // 不动（实测中→英 16.230、英→分图题 15.885 一模一样）。判据与目录那一条
  // 统一成 has-cjk：中易 1.296875 > 西文 1.15、上升部 1.008 > 0.93261，
  // 「行上有汉字就按中易」正是 Word 那条取最大值的规则。
  let latin = lang == "en" and not has-cjk(plain-text(body))
  // 线条型伪代码／清单的题注夹在两条线之间，*当三线表的表头行排*：行高是格子那一档
  // （贴网格、网格开着时单倍，与 caption-rules 的 cell-style 同一份）——Word 贴网格的模型是
  // 一行占一个网格行、文字在格里居中（banshi/src/paragraph/spacing.typ 的 _ascent-of）。先前用题注样式
  // 的行高，倍数多出来的那一截全落在基线之下，字贴着上面那条粗线（实测粗线心→字形顶
  // 2.8、字形底→细线心 9.2）。网格不启用的那几档（报告）没有格可居中，与 Word 的格子一样
  // 多出来的落在下面。西文题注也按格子排：格里的西文行照样占一个网格行（见 cell-style 抬头）
  let ruled = (
    (it.kind == kinds.algorithm-kind and resolve-algorithm-style().frame == "ruled")
      or (it.kind == raw and resolve-raw-style().frame == "ruled")
  )
  // 线条型的题注行按表格那一档排（它是表头行）：行距与贴格从表格样式取，字号是题注的
  let ts = _table.table-style()
  let st = if ruled {
    _table.cell-style(ts, style.size)
  } else if not latin {
    style
  } else {
    // 纯西文段：西文吃半格增量，直接 set，见 banshi/src/paragraph/latin.typ 的 pure-latin
    style + (font-zh: "latin", font: "serif", snap-to-docgrid: false)
  }
  // *题注在上的粘住下面那一块*（sticky）：表、表格型与线条型伪代码可拆页，Typst 会把
  // 题注留在页底、正文整个挪到下一页（实测题注孤零零在页底、页顶从第一行起）。粘住
  // 之后要断只能断在正文里
  // 线条型：下边垫细线的那一半（三线表格子挨着线那一边的 cell-inset），上边那一半是顶线
  // 那个零高块的高
  block(above: 0pt, below: 0pt, width: 100%, sticky: figure.caption.position == top,
    inset: (bottom: if ruled { ts.stroke.header / 2 } else { 0pt }), {
    show: style-rules.rules.with(st, layout: layout, set-font: true)
    // 题注那一档的西文断字，默认关。见 src/settings/defaults.typ 的 hyphenate
    show: hyphenate.hyphenate-rules
    // *续表右对齐，续图居中。* 指南两句话分开写的：2.12「表右上角注明编号，
    // 编号后加『（续表）』」——本科范例第 16 页量下来 x 438.17..509.95，右缘顶着
    // 版心右边线 510.24；2.13.2 只说「下页标『图序（续图）』字样」，*没说右上
    // 角*——同一份范例第 11 页那条「图1-1（续图）」量下来 x 260.85..333.84，中线
    // 297.35 正是版心中线，就排在图题的位置上。
    //
    // （表那一条实际不走这里，它由 show table 注进表里；这里留着是因为图与表
    // 共用这个函数，判据写清楚比写死一个 center 好。）
    // 线条型伪代码的题注在两条线之间、*居左*（algorithm2e 的 ruled / algoruled 就是
    // 左对齐的「Algorithm 1: …」）；表格型在表外上方、框图型在框外下方，与表题图题一样居中
    let ruled-algorithm = ruled
    // 自动拆页的自造 kind 也按这两句分：题注在上的续页标注靠右，在下的居中（见 _split）
    set align(if continued and (term == "table" or figure.caption.position == top) { right } else if ruled-algorithm { left } else { center })
    // 关掉正文那条收窄段落宽度的规则：题注居中，不吃字符网格的行末余量
    show par: p => p
    // *Fig. 与 Table 后面那个空格是我们补的。* 范例里它们后面空几格自己
    // 都不一致（博士范例 p14「Table6-1 Data」一个、p15「Table6-1  Data」两个，
    // 图题两处都是「Fig.1-1」不空），指南对英文题一个字没写。统一补一个。
    // 续排那一条只有编号加「（续表）」，*不带题名*——范例与指南都是这样。
    //
    // *末尾要跟一个零宽空格。* 它以全角右括号收尾，而 Typst 会把行末的
    // 全角收尾标点*悬挂*到版心之外——实测右缘冲出 5.99，同一行改成不以
    // 标点收尾就正好落在 510.23。悬挂排中文正文是对的，这里不是：Word 那边
    // 范例第 16 页量到 509.95，在版心里。
    //
    // 试过 box(…)、align(right, box(…))、末尾加 h(0pt) 三种，都还是 +5.99——
    // 悬挂是在文本层做的，包起来拦不住。跟一个零宽空格让标点不再是行末那个
    // 字符，才落回 510.23。
    let head = if numbered {
      supplement + (if lang == "en" { " " }) + num + _separator(layout)
    } else { [] }
    // 线条型伪代码：题注上面那条粗线在这里画——题注在两条线之间，本体只画细线与底线
    // （src/figure/kinds/algorithm.typ 的 _frame）。线宽与三线表的顶线同
    if ruled-algorithm {
      // 顶线只在双语两行的头一行上面画；这个零高块粘住下面的题注文字（不粘的话页底
      // 会剩一条光线，题注到了下一页——实测）
      if first {
        block(width: 100%, above: 0pt, below: 0pt, sticky: true, stroke: (top: ts.stroke.top), height: ts.stroke.top / 2)
      }
      // 题注与本体同一个横向内边距，左缘与输入输出那几行对齐
      h(ts.inset.x)
    }
    if continued {
      // 续排的标注：「（续」加这一种东西的名——图「（续图）」、表「（续表）」（指南 2.12 /
      // 2.13.2 的原话），自造的 kind 与显式写了名的图表照样套（「（续算法）」）；接哪一张
      // 的办法（同 kind 的前一张，或 #continued(<label>) 指名）也不分 kind
      let mark = refs.continued-mark(lang, if type(term) == str { refs.word(lang, term) } else { term })
      let line = {
        if numbered { supplement + (if lang == "en" { " " }) + num + refs.continued-gap(mark) }
        mark
        sym.zws
      }
      // *题注在上的续排标注，右缘落在正文右缘*（width 给了正文的宽）：与续表落在表右上角
      // 一个样子；正文比版心窄时不悬在空白外头。正文整体居中，右缘在 (版心宽 ＋ 正文宽) / 2；
      // 标注在整宽的块里靠右、末尾垫一段 (版心宽 − 正文宽) / 2 的空当，就推到那儿。*不装进
      // 与正文等宽的盒子里*：标注比正文还宽的会在盒子里折行（实测，里面再包一层 box 也折）；
      // 这样排的宽度是整个版心，不折。*正文比标注还窄的（几行短代码）整条居中*，不去对右缘
      // （对了也是往左探出一截，看着像歪的）。量标注的宽要在这个块里的 context 里量：块上
      // 已经 set 过题注的字号，外面那层的字号是哨兵
      if width == auto { line } else {
        context {
          if measure(line).width >= width { align(center, line) } else {
            align(right, line + h((layout.text-width - width) / 2))
          }
        }
      }
    } else {
      // *一行就居中，换行就把编号单独占一格、题名自己两端对齐。*
      //
      // 范例里*一条换行的题注都没有*（本科范例第 14 页那条「表6-1  1 号试样
      // 渗透率测试数据(温度：T=16 ℃，高度：H=5.31 mm)」看着像两行，实际是同一行
      // y 321.60 被抽取器拆成两段，x 130.80–464.36，居中）。指南也只说「居中书写」。
      // 所以这一档*是我们定的*：编号是标签，不是题名的一部分。
      //
      // *用两列 grid，不用 hanging-indent。* 悬挂缩进的做法是把编号留在段落
      // 里，于是它*参与右侧那段的排版*——两端对齐会去拉编号与题名之间那段
      // 空，量出来的缩进也就对不上首行了（实测差 0.57，且随题名长度变）。分成
      // 两格之后，编号那一格是死的，题名那一格自己两端对齐，各行天然对齐，
      // 一个 measure 都不用。
      //
      // *判据仍要量*：内容的自然宽度超过块宽才算换行。一行排得下的题注得
      // 居中，而 grid 是左对齐的整幅块。
      context {
        let whole = head + body
        if measure(whole).width <= layout.text-width {
          whole
        } else {
          grid(columns: (auto, 1fr), align: left, head, par(justify: true, body))
        }
      }
    }
  })
}

#let _size-sentinel = 0.31415pt

// 接到题注上。用法：show: caption-rules.with(body-metrics: …, spacing: …)
//
// *版面不在装规则时捕获。* 题注的行高、三线表的行高与内边距、题注换不换行的
// 版心宽，都在各条 show 规则自己的 context 里按当前这一节的版面现算（layout.current-page-setup）
// ——段级改了行跨度、版心，题注与表跟着换。只有一处例外：图块表块的三段空当那
// 几条是 show figure: set block(above:, below:) 与 set figure(gap:)，show-set 的值给
// 不了 context——试过把它写进 show figure 的闭包里再 set，那会压过后定义的分图那条
// set block(0pt)（实测），所以它们按 iota-hit 传进来的文档级那一份，见下面 spacing。
// 图、表、伪代码的题注（分图题那一档不走这里，见 sub-caption）。it 是题注元素——
// show figure.caption 里的 it，或从 figure 元素上取的 f.caption（query 出来的 figure
// 上题注的 kind / counter / numbering / supplement 都已补齐，实测）。
//
// source 与 pieces 只有*自动拆页*的图用（见 _split）：source 是这一页要标「（续图）」时
// 取号的那张 figure，pieces 是落在这一页上的分图是第几到第几
// 题注排出来在上在下的记号（metadata 可定位）：续排的那张按它接的那张取，见 caption-rules 里
// 那条 show figure。先前记在 state 里、按 figure 的落点读——读到的是它*前一张*的（show 规则
// 里发在 it 之前的更新，落点反而在 it 之后，实测）；记号在题注里，落点必在 figure 之后
#let _position-mark(pos) = metadata((iota-caption-position: pos))
// 正文有多宽（自造 kind 与 raw），发在 figure 前面，给题注在上的续排标注定右缘（见 _caption）。
// 量的时候给版心宽：写着 width: 100% 的（codly、zebraw 这些代码包都是）才解得出，不给量到 0
// （实测）；比版心宽的钉到版心宽
#let width-mark(body, layout) = metadata((
  iota-body-width: calc.min(measure(body, width: layout.text-width).width, layout.text-width),
))
#let _position-of(f) = {
  let m = query(selector(metadata).after(f.location())).find(m => (
    type(m.value) == dictionary and "iota-caption-position" in m.value
  ))
  if m == none { none } else { m.value.iota-caption-position }
}

#let caption(it, layout, style, by-chapter, source: none, pieces: none) = {
  _position-mark(figure.caption.position)
  // *号与名之间那一格走原生的 separator*（见 _separator）：先前我们不读它、
  // 写了一声不响什么都不发生，所以当场拦下；现在读了，拦截撤掉。默认仍是指南
  // 定死的那一档——号与名之间空 2 个半角字符（本科指南 2.12/2.13，两份范例印
  // 出来也是），见 src/settings/defaults.typ 的 caption-separator-auto。
  let kind = it.kind
  let lang = doc-lang.get()
  // 自造的 kind 传它自己的 supplement，见 _caption-line 抬头；图表上显式写的也照它
  // （题注元素的 fields() 里带着图表的 supplement，判法见 refs.given-supplement）
  let given = refs.given-supplement(it.fields(), kind, lang)
  let k = kinds.kinds.find(k => k.kind == kind)
  let term = if given != auto { given } else if k != none { k.term } else { it.supplement }
  let manual = find-continued(it.body) != none
  let continued = manual or source != none
  if continued and kind == table {
    // *续表那一条不由题注排*——它在表的右上角，是表的一部分，由 show table
    // 注进表里（见 _table.continued-row）。搁在题注里的话块宽是版心，右对齐就贴到版心
    // 边上（实测 441.10…510.23，而表自己只到 332.20），而指南 2.12 说的是「表右
    // 上角注明编号」。
  } else if continued {
    // *续图由题注排*，排在图题的位置、居中——图不像表，它没有「表格」这个
    // 容器可以往里注，指南也只说「下页标『图序（续图）』字样」。范例第 11 页量到
    // 中线 297.35，正是版心中线。
    //
    // *题注在上的（自造 kind、raw）标注靠右到正文右缘*：正文的宽由 figure 那条规则量好、
    // 记在 figure 前面的记号里（width-mark），这里取「我之前最后一个」——题注在上、排在
    // 正文之前，最后一个记号就是自家的。*不在这儿量*：题注规则的样式链上字号是哨兵
    // （_size-sentinel），measure 按它量，一段代码量出来 1.6pt（实测）
    let width = if figure.caption.position != top { auto } else {
      let m = query(selector(metadata).before(here())).rev().find(m => (
        type(m.value) == dictionary and "iota-body-width" in m.value
      ))
      if m == none { auto } else { m.value.iota-body-width }
    }
    _caption-line(it, lang, term, layout, style, continued: true, by-chapter: by-chapter, source: source, width: width)
  } else if lang == "en" {
    // 英文档只出英文那一份
    _caption-line(it, "en", term, layout, style, continued: continued)
  } else {
    _caption-line(it, "zh", term, layout, style, continued: continued)
    // 双语：中文在上、英文在下。*没写 #en 就只排中文*——不拿中文
    // 冒充英文题。开关见 src/settings/defaults.typ
    //
    // 续排那一条不排双语：它只是个「接着上一页」的标注，不是题
    let bilingual = resolve-caption-bilingual(
      degree-level: info-get().degree-level, stage: info-get().stage,
    )
    if not continued and bilingual and find-en(it.body) != none {
      _caption-line(it, "en", term, layout, style, first: false)
    }
  }
  // 分图题连排在图题之下
  // *续图上照排分图题，而且接着数。* 范例第 11 页那一页正是带分图题的续图
  // ——上一页排 (a)(b)，这一页排 (c)(d)，同一张图一条号。先前这里挡着 continued，
  // 于是续图上根本写不了 #subs。
  //
  // 续表不排：表没有分图这一说。
  let subs = find-subs(it.body)
  if subs != none and not (continued and kind == table) {
    let start = if not manual { 0 } else {
      let sel = figure.where(kind: image)
      let src = continued-source(sel, find-continued(it.body))
      if src == none { 0 } else { subs-offset(sel, src) }
    }
    // *自动拆页的图只排落在这一页上的分图题*（pieces 给了这一页的分图是第几到第几）：
    // 范例第 11 页正是这样——上一页 (a)(b)，续图那一页 (c)(d)，号接着数。见 _split
    let (subs, start) = if pieces == none { (subs, start) } else {
      (subs.slice(pieces.from, pieces.to), start + pieces.from)
    }
    // 图题与分图题之间由用户插点什么（默认什么都不插，范例就是紧挨着的）：
    // 就地 #subs(gap: …) 压过文档级 subcaption-gap，见 src/settings/defaults.typ
    if subs.len() > 0 {
      resolve-subcaption-gap(local: find-subs-gap(it.body))
      subs-line(subs, layout, style, start: start)
    }
  }
}

#let caption-rules(
  body-metrics: none,
  // 题注那一档。iota-hit 从样式表（styles.figure.caption）传进来，见 src/styles/presets.typ
  style: default-styles.figure.caption,
  // 编号按不按章。true 排「图1-1」并在章标题处重置计数器，false 全文连续
  // 排「图1」不重置。由 iota-hit 解出来传进来，见 src/settings/defaults.typ
  by-chapter: true,
  // 公式那一档按不按章。*这里只有 show ref 用得着*——全项目只能有一条
  // show ref 生效（同一选择器后定义的赢），而那一条在这儿，所以公式的引用也得
  // 由它排，编号串与按不按章都要送进来。往后若再多一类要重建，这条规则就该
  // 单独搬出去成一个部件。
  equation-by-chapter: true,
  // 表头占几行。三线表的第二条线画在它下面
  header-rows: 1,
  // 图块表块的三段空当，已经解成数：(image: (above:, gap:, below:), table: (同),
  // 都是数)。由 iota-hit 按 styles.figure 算好传进来（auto 的解法
  // 在那儿），见 src/styles/presets.typ 的 _figure
  spacing: (
    image: (above: 0pt, gap: 0pt, below: 0pt),
    table: (above: 0pt, gap: 0pt, below: 0pt),
    line: 0pt,
  ),
  doc,
) = {
  // *续排的那张题注在上在下跟着它接的那张*，自己写了才用自己的（与 supplement 同一条：自己
  // 当下给了就用自己的，没给就用前面的）。「自己写了」＝ 写在题注元素上：caption:
  // figure.caption(position: top)[…]，fields() 里才有 position；set 出来的值（不管文档级还是
  // 就地套一层）与出厂默认分不开，一律当没写——文档级的 set 接的那张也吃到了，跟它就是跟
  // set。图与表的位置锁死、伪代码按框定，都不走这条。接的那张排在哪，读它题注里的记号
  // （_position-of）。*定义在拆页那条之后*：后定义的先跑，拆页那条按题注位置分两路，要读到
  // 这里 set 过的值
  show figure: it => context {
    let cap = it.at("caption", default: none)
    let mark = if cap == none or it.kind in (image, table, kinds.algorithm-kind) { none } else if (
      it.kind == raw and resolve-raw-style().frame != none
    ) { none } else {
      find-continued(cap.body)
    }
    let inherited = if mark == none or "position" in cap.fields() { none } else {
      let src = continued-source(figure.where(kind: it.kind), mark)
      if src == none { none } else { _position-of(src) }
    }
    // 正文的宽顺手记下（自造 kind 与 raw；图表与伪代码用不着）
    let width = if it.kind in (image, table, kinds.algorithm-kind) { none } else {
      width-mark(it.body, _layout.current-page-setup())
    }
    if inherited == none { width + it } else {
      set figure.caption(position: inherited)
      width + it
    }
  }

  // 表题在表上，图题在下（Typst 默认就是下）
  show figure.where(kind: table): set figure.caption(position: top)

  // *伪代码：body 是 algorithm[…] 造的，把这张 figure 重造成 kind "algorithm"。*
  // Typst 的 figure 只按 body 认三种 kind（table、raw、其余一律 image），第四种它
  // 没留钩子，用户又不该写 kind——#figure(algorithm[…]) 该与 #figure(table(…)) 一个
  // 形状。所以认 body 末尾那个记号（src/figure/kinds.typ 的 algorithm-mark），重造：
  // 字段原样搬，*标签不搬*——被 show 规则换掉的元素仍在文档里（query 查得到、
  // 标签还在它身上），再挂一次就是「label occurs multiple times」。于是 @alg:x 找到的
  // 是那张 kind 还是 image 的原件，引用、续排接的那一张都要换成重造的那一张：
  // 紧跟在原件之后的第一张 algorithm 就是它，见 kinds.resolve。这是全项目第二处重造用户
  // 的元素，第一处是三线表（下面 show table）。重造出来的 kind 已是 algorithm，不再命中。
  //
  // *题注在上在下按 algorithm-style.frame 定*：tabular / ruled 在上，boxed 在框外下方——
  // 与图同。就在这里 set，重造的那张 figure 在这个 set 之下实现。
  // 显式写的 supplement（figure(algorithm[…], supplement: [过程])）原样搬，没写的
  // 给词条的「算法」——Typst 造自造 kind 的 figure 时就要 supplement，下面那句
  // show-set 够不到这里造的这一张（实测报 please specify the figure's supplement）
  show figure: it => {
    if it.kind != image or find-algorithm(it.body) == none { return it }
    context {
      let st = resolve-algorithm-style()
      set figure.caption(position: if st.frame == "boxed" { bottom } else { top })
      let f = it.fields()
      let given = refs.given-supplement(f, image, doc-lang.get())
      // 原件已经把图的计数器步进了一格，退回去（理由见 kinds.original）
      counter(figure.where(kind: image)).update(v => v - 1)
      let rebuilt = figure(
        it.body,
        kind: kinds.algorithm-kind,
        caption: if f.at("caption", default: none) == none { none } else { it.caption.body },
        placement: f.at("placement", default: none),
        outlined: f.at("outlined", default: true),
        supplement: if given != auto { given } else { refs.word(doc-lang.get(), "algorithm") },
      )
      rebuilt
    }
  }
  // *跨不跨页走原生的 show figure.where(kind: "algorithm"): set block(breakable:)*，与表、
  // 代码同一条：默认拆（三档都拆，用户定的），用户那句 show-set 在内层、压得过这条。先前
  // 住在 algorithm-style 里，理由是「默认值随框变、show-set 给不了 context」——三档都拆之后
  // 这个理由没了，一个口子也就省了
  show figure.where(kind: kinds.algorithm-kind): set block(breakable: true)
  // 代码同理：Word 里代码就是段落，段落自然可拆
  show figure.where(kind: raw): set block(breakable: true)
  // 伪代码与代码清单的题注与本体之间那份 gap 在 lib.typ 里 show-set（表格型、线条型 0，
  // 框图型走图那一份）——*写在 show 规则里的 set figure(gap:) 不生效*：gap 是 figure 造好
  // 时就填进字段的（实测里面 set 成 20pt 一动不动），只有 show-set 到得了，而 show-set
  // 的值给不了 context，框哪一档只能在入口按参数解
  // ── 代码清单（进了 figure 的代码块）────────────────────────────
  // 题注位置随框定（与伪代码同）、题注与本体之间的 gap 也同；本体（框、行号）由
  // src/figure/kinds/raw.typ 排，那条 show raw 挂在 lib.typ（listing-rules）。「在不在清单里」
  // 由这条规则记进 state（src/figure/kinds.typ 的 in-listing），raw 在 figure 里面，读到的
  // 就是这张的
  show figure.where(kind: raw): it => context {
    let frame = resolve-raw-style().frame
    in-listing.update(true)
    if frame == none { it } else {
      set figure.caption(position: if frame == "boxed" { bottom } else { top })
      it
    }
    in-listing.update(false)
  }

  // 字号那个哨兵，见 _size-sentinel。*要定义在下面那条 show figure.caption
  // 之前*——那样它在样式链上比处理函数外一层，处理函数才读得到
  show figure.caption: set text(size: _size-sentinel)

  // *表可以跨页，图不行。* 指南 2.13.2：「插图与其图题为一个整体，不得
  // 拆开排写于两页」；2.12：「一般情况下插表不能拆开两页编排，*如某表在
  // 一页内安排不下时，才可转页*」。Typst 的 figure 默认整块不可断——实测长表
  // 不但不跨页，还会整个溢出版心（底线落在 773.9，版心底是 756.84）。
  show figure.where(kind: table): set block(breakable: true)

  // 题与图/表之间。*这一截是 Word 自己加的，不是谁手敲的*——图在 Word 里是
  // 坐在一条文字基线上的*内联对象*，图底就是那一行的基线，所以图下面自动
  // 带着那一段的*行深*（行距倍数 × 单倍行高 − 上升部），再加它自己的段后。
  //
  //   终稿那一档   装图段跟 Normal（小四宋体 1.25 倍）  行深 7.275，段后 0
  //   深圳本科中文报告  同上                            行深 7.275，段后 0
  //   深圳本科英文报告  Figure 样式（12pt Times 1.5 倍） 行深 9.463，段后 3
  //
  // 值由 iota-hit 按 styles.figure.image 算好传进来（见 src/styles/presets.typ 的
  // _figure 与 variant-styles 的 figure），*模板里不必再手写一个 gap*；单张图
  // 要不一样，原生 #figure(gap: …) 压得过这条 set。*自造的 kind 跟图*——
  // 算法、代码块在 Word 里同样是段落里的东西，与图同一个待遇；只有表另算。
  //
  // *先前这儿写死 0*，理由是「规范没规定这一项」——规范确实没写，可 Word 排
  // 出来那一截是有出处的，就是上面这个式子。
  //
  // *网格开着时这一截是 0*：那时装图的那一行占整数个网格行、图在里面居中（见下面
  // 那条 show），多倍行距多出来的那一截已经在取整的余量里，再加就重了——探针实测
  // 图底到图题基线只有题注自己的上升部加余量的一半（2026-09-15，两种网格各五档图高）。
  // 由 iota-hit 解 auto 时按网格开没开给 0 或 (倍数 − 1) × 单倍行高
  set figure(gap: spacing.image.gap)
  // *表那一头是另一件事*：表题在*上*，这一段空当是题注那一段的*段后*
  // ——中英四份原件的表题段后都是 0（英文那份的 -tab 样式明写着 w:after="0"），
  // 表就紧贴在题注下面。装图段那一份（多倍行距多出来的一截）与它无关
  show figure.where(kind: table): set figure(gap: spacing.table.gap)

  // *网格开着时，装图的那一段占整数个网格行，图在这几行里垂直居中。*
  //
  // 拿探针 docx 量的（图高 20…110 十档，docGrid linesAndChars linePitch=391，
  // 正文 1.25 倍）：基准行基线 → 图题基线的步进正好是*一个网格行*（19.44／
  // 19.68 交替，均值 19.56 ＝ 391 缇）；而「图下方余量 − 图上方余量」十档*恒等于
  // 8.2*——余量本身随图高从 7.3 变到 19.1，两头的差却不动，只有把图*居中*摆
  // 在那几行里才会这样。
  //
  // *行数就是 ⌈图高 ÷ 网格行距⌉*，图高之外*什么都不加*。先前写的是「加那一行自己的
  // 整个行高」（¶ 那一行，小四 1.25 倍 19.45），2026-09-15 两种网格（论文 391、报告 312）
  // 各排六档图高重量：40 / 52 / 64 / 70 / 77.65 / 85 / 100 在 391 上占 3 / 3 / 4 / 4 / — /
  // 5 行、在 312 上占 3 / 4 / 5 / 5 / 5 / 6 / 7 行，逐档都是 ⌈图高 ÷ 行距⌉；加整行的话
  // 52 在 391 上成 4 行、64 在 312 上成 6 行，加 ¶ 在基线下那一截（6.56）也会把 77.65
  // 在 312 上推成 6 行（Word 5 行，77.65 ÷ 15.6 ＝ 4.98）。图在这几行里居中：图上方余量
  // 与下方余量逐档相等（图底到图题基线 ＝ 余量 ＋ 题注自己的上升部，多倍行距那一截
  // 不另加，见上面 gap 那一条）。
  //
  // *表不吃这一条*——表在 Word 里不是段落里的内联对象。
  //
  // *组图（#subs 排的）按行取整，不按张*：Word 里一行几张图是一个段落，占的是这一行的
  // 整数个网格行；逐张各取整会把竖叠格里的两张撑开（实测 36.5 ＋ 40.7 两张各占 2、3 行，
  // 叠起来比旁边那张高 10）。取整由 src/figure/kinds/image.typ 对每一行做，这里见到它的记号就
  // 不碰里面的图
  show figure: it => context {
    let g = _layout.current-page-setup().docgrid
    if not g.grid or g.line-pitch == 0pt or it.kind == table { return it }
    show image: img => context {
      if subs-rows.get() { return img }
      let h = measure(img).height
      let rows = calc.max(1, calc.ceil(h / g.line-pitch))
      block(height: rows * g.line-pitch, align(horizon, img))
    }
    it
  }

  // 图表上下与正文*空一行*——指南 2.12 明写「插表的上下与文中文字间需空一
  // 行编排」；2.13 图那边只说「留一定位置」，但本科范例量下来分图题到下一段正文
  // 39.28 ≈ 2 × 19.55，也是空了一行。
  //
  // *范例的表上方只有 0.2 行，不跟。* 两份范例的表题段落都写着
  // beforeLines=20（0.2 行 ＝ 3.83），实测正文末行 299.60 → 表题 321.60 ＝ 22.00，
  // 与模型「行深 7.275 + 上升部 10.66 + 段前 3.83 ＝ 21.77」对得上。但那是排版的
  // 人手敲的直接格式，styles.xml 里没有题注样式，而指南明写空一行——判据次序见
  // src/styles/presets.typ 的题注那一档（default-styles.figure.caption）那一段。
  //
  // *页首不发。* Typst 的块间距在页首本来就丢——实测把它设成 0 与默认排出来
  // 逐点相同，不用另外处理。
  // *图与表各一对数*（iota-hit 按 styles.figure.image / .table 解好传进来，auto
  // ＝ 空一行）：原件里这两头本来就不同——英文中期那份表题之上 2.4、表之下 0、
  // 图之上 0、图题之下 3。*自造的 kind 跟图*，表那条压过它（同一属性上后定义
  // 的赢）。单个图表要不一样走原生：#block(above: …, below: …, figure(…))——块间距
  // 折叠取大者，裹一层就把这一张的两头换掉了（实测 40pt / 2pt 逐点对上，别的图不动）。
  //
  // *摆在分图那条之前*——分图的 0 要压过这两条，见下面
  show figure: set block(above: spacing.image.above, below: spacing.image.below)
  show figure.where(kind: table): set block(above: spacing.table.above, below: spacing.table.below)

  // 编号「1-1」：章号从 counter(heading) 取。
  //
  // *是 set，不是 show figure: set。* 先前写成后者，为的是拿到 context；
  // 闭包里自己写一句 context 就够了，而摆在 show 规则里有两处坏处：一是用户写
  // #set figure(numbering: "1") 盖不过我们（show 里的 set 更内层），二是我们
  // *读不到*用户写了什么——样式链上还是原生默认的 "1"，与用户写的一模一样。
  //
  // 挪到文档级之后这一份就成了*哨兵*：样式链上的值不再是 "1" 而是这个闭包，
  // 用户一改就比得出来（闭包在 Typst 里比得了身份，实测同一个闭包 == 为真、
  // 另一个长得一样的为假）。下面那条 show heading 的重置也改成认这个哨兵。
  // 闭包本体定义在模块级（_by-chapter-numbering）：题注排号那一处也要认它，见 _caption-line
  let by-chapter-numbering = _by-chapter-numbering
  set figure(numbering: if by-chapter { by-chapter-numbering } else { "1" })

  // *图表编号按章重置。* 指南 2.12 / 2.13：「图序按章编排，如第 1 章第一个
  // 插图的图号为『图1-1』」。连续编号那一档不重置——重置了第 2 章的图会变回
  // 「图1」跟第 1 章撞号，所以这两件事必须绑在一起。
  //
  // *绑法是认哨兵，不是认开关。* 判据取当前生效的 figure.numbering 是不是
  // 我们那个闭包：用户写 #set figure(numbering: …) 换掉编号时，重置跟着停，
  // 两半一起让开，不会留下「编号连续但每章从头数」那种半吊子。
  //
  // *全文出现过的每一种 kind 都重置*，不只图与表：自造的 kind（算法）与 Typst 自带的
  // raw（代码）各有各的计数器，先前只重置图表那两个，第二章的算法印成「算法2-2」。
  // 哪几种 kind 从全文的 figure 里数出来（分图那一种也在里面，重置它无害）
  show heading.where(level: 1): it => context {
    if figure.numbering == by-chapter-numbering {
      for k in query(figure).map(f => f.kind).dedup() {
        counter(figure.where(kind: k)).update(0)
      }
    }
    it
  }
  // *这条 set 会盖掉「打上 <-> 就不编号」，所以 nonumber-rules 必须排在
  // caption-rules 之后*——Typst 里同一属性上后定义的 show 规则压过先定义的。
  // 顺序写在 lib.typ 那一处，实测顺序反了打了 <-> 的图照样排出「图1-2」。

  // *原生的 set figure(supplement:) 我们不读，也拦不住。* 题注、引用、清单三处
  // 的字样默认从词条表取（见 refs.word），用户写 set figure(supplement: [插图]) 一声不响
  // 不生效——本该拦下，可*拦不出来*：在 show figure 里读 it.supplement 或
  // figure.supplement，拿到的都是 *Typst 自己的出厂默认*（英文档下是 [Figure]、
  // 中文档下是 [图]），我们那句 set 在这一层看不见，用户写没写分不出来。试过把守门
  // 定义在那句 set 之前（后跑）也一样。所以只在 README 里写明：改字样走
  // overrides: (caption-image: […])。哪天上游能读到最终值，这条就补上。
  // *单张图表上显式写的 figure(supplement:) 认*，判法见 refs.given-supplement。
  //
  // *自造的 kind 不在此列*：figure(kind: "algo", supplement: [算法]) 那一档 Typst 逼着
  // 用户写 supplement，而下面那句 set 只落在图与表上，读到的就是用户写的——题注与
  // 引用都照它印（先前一律印「图」，错的）。清单只有图表公式三张，自造的不进

  // supplement 跟文档语言：中文档「图」「表」，英文档 Fig. / Table。
  // 它同时管引用——@fig:x 排的就是 supplement + 编号
  for k in kinds.kinds {
    show figure.where(kind: k.kind): set figure(
      supplement: refs.word(doc-lang.get(), k.term),
    )
  }

  // 分图号*每张母图从头数*。重置发在母图之前，分图在母图*里面*，
  // 次序天然对。分图自己进来时不重置——那会把自己刚数的那一下抹掉。
  show figure: it => context {
    // *顺带把「用户改了编号」拦下来。* 图表编号按章是指南 2.12 / 2.13 写死
    // 的，改成别的排出来就不合格；而它由两半合成（编号串 + 逐章重置），用户只
    // 盖得住前一半，剩下的是「编号连续但每章从头数」这种半吊子。所以不放行，
    // 当场报错指到我们的开关上——那条开关是给对拍件与短样张用的知情逃生口。
    //
    // *判据认哨兵。* 上面那句 set 把样式链上的值换成了我们的闭包；none 要
    // 放过，那是打了 <-> 的图（见 src/heading/numbering.typ 的 nonumber-rules），不是用户在改编号。
    if by-chapter and figure.numbering != none and (
      figure.numbering != by-chapter-numbering
    ) and it.kind != subfigure-kind {
      panic(
        "figure numbering has no effect (the template numbers figures by "
          + "chapter; write iota-hit(caption-numbering-by-chapter: false) "
          + "for continuous numbering)",
      )
    }
    // *题注在上在下是规范定死的*：指南 2.12「表的名称置于表的上方」、
    // 2.13.1「图题置于图的下方」。原生那句 set figure.caption(position:) 压得过
    // 我们（实测把表题拧到了表下面），所以当场拦下——这一条没有商量余地。
    // *只管图与表*：自造的 kind 与 raw 规范没提，在上在下随用户
    let want = if it.kind == table { top } else { bottom }
    if it.kind in (table, image) and figure.caption.position != want {
      panic(
        "figure.caption position is fixed by the guidelines (table captions go "
          + "above the table, figure captions below the figure); remove the "
          + "set figure.caption(position: ...)",
      )
    }
    // 图默认不拆页（Typst 的 figure 本来就是整块）；用户 show figure: set block(breakable:
    // true) 之后按指南 2.13.2 的续图排——那一条在 _split，定义在最前面、最后才轮到它
    // 续图*不重置*：它是同一张图的后半，分图号接着上一页数（范例第 11 页
    // 排的是 (c)(d) 而不是从 (a) 重来）
    let cap = it.at("caption", default: none)
    let continued = cap != none and find-continued(cap.body) != none
    if it.kind != subfigure-kind and not continued {
      counter(figure.where(kind: subfigure-kind)).update(0)
    }
    it
  }

  // 分图号的写法跟 subcaption-numbering 走。写成闭包是因为 setting-of 要
  // 上下文，而 numbering 那个函数是排的时候才调的，那会儿有。
  show figure.where(kind: subfigure-kind): set figure(
    numbering: (..n) => context numbering(setting-of("subcaption-numbering"), ..n.pos()),
  )

  // *下面这些只管真正的图与表。* 分图是嵌在母图里的另一档 kind，
  // 上下空一行、按章编号、题在下方这些都不该落到它头上。
  show figure.where(kind: subfigure-kind): set block(above: 0pt, below: 0pt)

  // *分图的引用。* @sub:static 排成「图1-1（a）」，点得动，落到那张分图
  // （或分图题那一行）。分图不是 figure，Typst 自己的 ref 认不得它。
  //
  // 落点与序号由 subfigure / subs-line 记在 subs-refs 里，*文字在这里排*：
  // 图号要按 by-chapter 算，而那个值只有这里拿得到（理由见 settings/resolve.typ）。
  // 算法与上面 set figure(numbering:) 那一处是同一套，只是取值改成按落点取。
  //
  // 图号与分图号之间那个不断行的半角空格*只在半角那一档补*：本科范例正文引
  // 的是「图1-1 (a)」（run 拆出来是「图」+「1-1 (a)」），hithesis 的 \p@subfigure
  // 定成 \thefigure~ 也是这个；全角那一档不补，「（」自带边距，补了排出来是
  // 「图1-1 （a）」。*指南对怎么引用分图一个字没写*，这是范例上量的。
  //
  // 数的是*插图*那个计数器：指南说的是「图中若有分图」，表没有这一说。
  // 不是分图的引用原样放行，交给 Typst。
  show ref: it => context {
    // 两条路都收：标签挂在 subfigure 外面（那是个真 figure，Typst 认得，
    // 序号从它自己的计数器上取），或写在题里（连排那一档只能这么写，
    // 落点与序号由 subs-line / 分图题那条规则记在 subs-refs 里）
    let found = query(it.target)
    let native = if found.len() == 0 { none } else {
      let f = found.first()
      if f.func() == figure and f.at("kind", default: none) == subfigure-kind {
        (
          loc: f.location(),
          index: counter(figure.where(kind: subfigure-kind)).at(f.location()).first(),
        )
      }
    }
    let e = if native != none { native } else {
      subs-refs.final().at(str(it.target), default: none)
    }
    if e == none {
      refs.single(it, by-chapter, equation-by-chapter)
    } else {
      let n = counter(figure.where(kind: image)).at(e.loc)
      // 母图的名同样带「附」（附图1-1（a）），见 src/heading/numbering.typ
      let parent = (
        _numbering.appendix-prefix(e.loc, doc-lang.get(), by-chapter: by-chapter)
      ) + refs.word(doc-lang.get(), "image") + (
        if not by-chapter {
          numbering("1", ..n)
        } else {
          _numbering.chapter-numbered(e.loc, n)
        }
      )
      let num = numbering(setting-of("subcaption-numbering"), e.index)
      let gap = if has-cjk(plain-text(num)) { [] } else { sym.space.nobreak }
      link(e.loc, parent + gap + num)
    }
  }

  // *把相邻的几个记号并成一组*，名只印一遍。学 omni-gb7714 那条
  // show regex(_M + "(?s:.+?)" + _M + "(…_M…_M)*")。重复部分是 *，所以*单个
  // 引用也走这里*——不必另写一支。
  show regex(
    refs.MARK + "(?s:.+?)" + refs.MARK + "(?:" + refs.SEP-RE + refs.MARK + "(?s:.+?)" + refs.MARK + ")*",
  ): m => context refs.group(m.text, by-chapter, equation-by-chapter)

  // 分图题走另一档，*不能用 figure.caption.where(kind:) 选*——实测那个选择器
  // 匹配不上，分图题会掉进下面通用那一支排成「图1  静压」。只能在这里分派。
  show figure.caption: it => context {
    // *挡住原生那条路，并且出声*：题注由下面那个两列 grid 排（编号一列、
    // 题名一列，好让折行悬挂对齐），外面套的 set text 够不着里面，写了会一声
    // 不响什么都不发生。判据见 _size-sentinel
    if text.size != _size-sentinel {
      panic(
        "figure captions ignore `show figure.caption: set text(...)` (the "
          + "template lays the caption out itself; write "
          + "iota-hit(styles: (figure: (caption: (size: ...)))) to change it)",
      )
    }
    let layout = _layout.current-page-setup()
    // *哨兵到此为止*：这一格里还要发别的内容（比如 subcaption-gap 写的
    // enter(1)），它们按 text.size 算高——哨兵漏进去，那个空段就成了 0.36 高
    // （实测 0.40，该是 13.8）。
    //
    // *往下按正文那一档的字号*，不按题注自己的：这一处原本读到的就是外面
    // 正文的字号（哨兵没插进来之前），enter(1) 因此是一个正文行（小四 13.8）。
    // 按题注的五号算是 12.10，那是另一件事，不趁这次改
    set text(size: body-metrics.size)
    if it.kind == subfigure-kind {
      sub-caption(it, layout, style)
    } else {
      caption(it, layout, style, by-chapter)
    }
  }

  doc
}
