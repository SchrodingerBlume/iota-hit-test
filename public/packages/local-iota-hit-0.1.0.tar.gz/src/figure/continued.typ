// 续排：一张图表拆成几段接着排（手工 #continued，或自动拆页的续页），号接上一段、
// 计数器退回去、分图号接着数。记号写在题注里；接哪一张、沿链回到链头在这里算。
// 题注怎么排续排那一行在 ./caption.typ，续表行在 ./kinds/table.typ。
#import "@local/banshi:0.1.0" as banshi
#import banshi.content: metadata-of
#import "./kinds.typ" as kinds

// 这是上一个表的续表。写在题里，那一条就排成「表6-1（续表）」*右对齐、
// 不带题名*，而且不占新号。
//
// 指南 2.12：「如某表在一页内安排不下时，才可转页，以续表形式接排。表右上角
// 注明编号，编号后加『（续表）』，并重复表头。」本科范例第 16 页那一行量下来
// 是 x 438.17..509.95——右缘顶着版心右边线 510.24，确实是右上角。
//
// *要用户自己把表拆成两个 #figure。* Typst 那边表跨页时会自动重复
// table.header，但没有「只在续页出现」的钩子，「（续表）」这一行自动化不了。
// Word 里的做法本来也是手工拆。
// *接哪一张表可以指名*：#continued(<tab:one>)。不写就接*前一张*表，
// 那是绝大多数情形——拆表就是把紧挨着的一张拆成两半。指名是给「中间还夹了
// 别的表」那种场合留的口子。
#let continued(..args) = metadata((
  iota-continued: (target: args.pos().at(0, default: none)),
))

#let find-continued(c) = {
  let hits = metadata-of(c, "iota-continued")
  if hits.len() == 0 { none } else { hits.first() }
}

// 文档顺序里排在 loc *之前*的那一张。*要在 context 里调*
//
// *要跳过最后一个*：before() 是闭区间，loc 上那一个自己也在里面。在题注里调
// 时最后一个是本图（题注排在图*里面*），从图自己的位置调时最后一个就是它。
// 实测不跳的话链上一步就原地打转，走满上限——分图号排成了「（bm）」。
#let _prev-figure(sel, loc) = {
  let before = query(sel.before(loc)).filter(f => not kinds.original(f))
  if before.len() >= 2 { before.at(-2) } else { none }
}

// 「这一条续的是哪一张」。写了 #continued(<fig:one>) 就按标签找，没写就接紧挨着
// 的前一张——拆图拆表都是把相邻的一张拆成两半。*要在 context 里调*
//
// *认「自己」用位置，不用序号。* 题注排在图*里面*，所以「在我之前」的
// 最后一个必是我自己，倒数第二个才是前一张。先前拿序号剔自己，链上第二段起就认错
// 人——续排要*退计数器*，退过之后号在链上重复（实测第三段的分图号排成
// 「（c）」而不是「（e）」，因为它接到了第一张而不是第二张）。
#let continued-source(sel, mark) = {
  if mark != none and mark.target != none {
    return kinds.resolve(query(mark.target).first())
  }
  _prev-figure(sel, here())
}

// 链上再往回走一步。cur 自己也是续排时，接的那一张还在更前面。
// *要在 context 里调*
#let continued-step(sel, cur) = {
  let cap = cur.at("caption", default: none)
  if cap == none { return none }
  let mark = find-continued(cap.body)
  if mark == none { return none }
  if mark.target != none {
    kinds.resolve(query(mark.target).first())
  } else {
    _prev-figure(sel, cur.location())
  }
}

// 这条链的*头一段*——号取的是它的号。
//
// 一张图拆成三段时，第二段接第一段、第三段接第二段，而三段*共用第一段那个
// 号*。只回退一步的话，第三段会去取第二段所在位置的计数器值——那是原始的步进值，
// 没算第二段自己退的那一格，排出来成了「图1-2（续图）」（实测）。
// *要在 context 里调*
#let continued-head(sel, mark) = {
  let cur = continued-source(sel, mark)
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    let prev = continued-step(sel, cur)
    if prev == none { break }
    cur = prev
  }
  cur
}
