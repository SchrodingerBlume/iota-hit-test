#import "@local/banshi:0.1.0" as banshi
#import banshi.content: metadata-of
#let algorithm-mark(lines) = metadata((iota-algorithm: (lines: lines)))
#let in-listing = state("iota-in-listing", false)
#let find-algorithm(c) = {
  let r = metadata-of(c, "iota-algorithm")
  if r.len() == 0 { none } else { r.first() }
}
#let algorithm-kind = "algorithm"

#let kinds = (
  (kind: image, term: "image"), (kind: table, term: "table"),
  (kind: algorithm-kind, term: "algorithm"),
  (kind: raw, term: "raw"),
)
#let original(f) = f.kind == image and find-algorithm(f.body) != none
#let resolve(el) = {
  if el == none or el.func() != figure { return el }
  if el.kind != image or find-algorithm(el.body) == none { return el }
  let after = query(figure.where(kind: "algorithm").after(el.location(), inclusive: true))
  if after.len() == 0 { el } else { after.first() }
}
