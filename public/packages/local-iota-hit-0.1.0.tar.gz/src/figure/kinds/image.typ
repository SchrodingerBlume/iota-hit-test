// 图（kind image）这一种独有的东西：组图——几张分图怎么摆。题注本身在 ../caption.typ。
//
// 同一个名字两个位置，靠上下文分：写在图题里的 #subs([静压], [动压]) 是分图题
// （连排在图题之下，见 src/figure/kinds/image.typ 的 _subs-mark）；写在图的正身里的
// #subs(image("a.png"), image("b.png")) 是排布。判法看位置参数——里面有 image / stack
// 这类版面元素就是排布，全是文字就是分图题。
//
//     #figure(
//       subs(image("a.png"), stack(image("b.png"), image("c.png")), columns: auto, width: 90%),
//       caption: [气体润滑轴承的分类 #subs([静压 <fig:s>], [动压], [动静压])],
//     ) <fig:1-1>
//
// *模型*：一行里的图等高、各保宽高比、撑到给定的宽。任何一个节点的宽都是高的一次
// 函数 w(h) = a·h + b——叶子 w = r·h；横排（ltr）孩子同高、宽相加；竖叠（ttb）孩子同宽、
// 高相加，反解回来还是一次的；套多少层都只是一次函数的复合。最外层令 w(h) = W 一步
// 解出 h，再自顶向下把尺寸发下去。不二分、不迭代。
//
// *行与列直接收原生的 stack*：stack(dir: ltr | ttb, …) 的 dir 与 children 就是树，随便嵌。
// rtl / btt 与 ltr / ttb 同一套几何，只把孩子倒过来；横排里套横排、竖叠里套竖叠拍平成
// 一层；一个孩子的 stack 透明；空的当场报错。stack(spacing:) 写了照写的，没写用 gutter。
// columns: 2 / (3, 2) 是「切成几行、每行各自撑满」的糖。
//
// *写了什么守什么*：图自己写了 width / height 的算钉死，按写的排，不缩不放，解的时候
// 从 W 里扣掉它的宽；不是 image 的叶子（rect、cetz、文字块）按 measure 的自然尺寸钉死，
// 要它跟着缩就自己裹一层 box(width: …)。一行全钉死了就没有自由量，按自然总宽居中。
//
// *不放大*：解出来的行高不超过这一行里任何一张没钉的图的自然高——两张小图本来装得下，
// 不该被拉到版心那么宽（范例的分图都是自然尺寸）。装不下才缩。整体比版心还高（一竖溜
// 三张竖图）就整体等比缩到装下——图不能跨页；columns 切出来的多行不在此列，那是各自
// 的块，续图机制接得住（每行一个块，行间 v(gutter)，见 split.typ 的 split）。
//
// *分图题在哪跟着它写在哪儿*：写在图题里就是「图题之下」连排（现在的 #subs 那一档），
// 写在这里的 captions: 就是「分图之下」（每格换成 #subfigure，题各自居中在自己那张分图
// 下，标签写在条目里）。指南 2.13.1 那句「分图题置于分图之下或图题之下」只有这两处，
// 一个字写在哪儿就排在哪儿，不设开关。
//
// *叠在图上的编号* numbering，照原生 figure(numbering:) 的三态再加一档：
//   none        不叠（默认）——分图号通常已经画在图里
//   "(a)"       编号串，交 numbering() 排；默认样子五号 sans 黑字、左上角、离角半个字
//   (pattern: "a)", fill: white, alignment: bottom + right, dx: -4pt, dy: -4pt)
//               字典，只写要改的——都是快捷键，键名借原生的：pattern 是编号串（原生文档叫它
//               numbering pattern，datetime.display(pattern) 里就是参数名；没写跟
//               subcaption-numbering）；fill / stroke / font / size
//               是 text 的（font 写角色名 serif / sans / songti… 走字体表，写家族名原样交）；
//               alignment / dx / dy 是 place 的。再多的（描边圆底之类）走函数
//   n => …      函数收序号；返回 place 元素就原样贴上（位置样式全听它的），返回别的按
//               默认位置贴
//   数组        逐图一项，每项上面四态混着写
#import "../../layout/chars.typ" as chars
#import "../../layout/resolve.typ" as _layout
#import "../../fonts/resolve.typ" as fonts
#import "../../styles/rules.typ" as style-rules
#import "../../settings/resolve.typ": setting-of
#import "../../fonts/presets.typ": zihao, roles
#import "../../content.typ": metadata-of, label-of, plain-text
#import "../../msword.typ": has-cjk
#import "../../terms/lang.typ": doc-lang, find-en, title-of
#import "../../fonts/case.typ": english-title
#import "../continued.typ": continued-step
#import "../../paragraph/latin.typ" as western
#import "../../settings/resolve.typ": resolve-subcaption-bilingual

// ── 写在图题里的记号：分图题（挖的机制见 src/content.typ 的 metadata-of） ────────

// 分图题的记号。写在图题里，排出来是图题下面连排的一行：
//
//     #figure(subs(image(…), image(…)), caption: [气体润滑轴承的分类 #subs([静压], [动压])])
//     →  图1-1  气体润滑轴承的分类
//        （a）静压；（b）动压
//
// 本科指南 2.13.1：「分图题置于分图之下*或图题之下*，分图号用（a）、（b）
// 等表示，在图题之下连续排列，用『；』间隔」。这里是「图题之下连排」那一档的记号；
// 「分图之下」那一档写在正身的 captions: 里（每格一个 #subfigure）。*公开的 subs 在
// src/figure/kinds/image.typ*：同一个名，写在正身里是排布、写在图题里才落到这个记号。
//
// 分图号的写法与分隔符都可配，见 src/settings/defaults.typ——本科范例印的是半角
// 的「(a) 静压; (b) 动压」，研究生规范写的又是「a)」。默认跟本科指南的全角。
//
// *gap 是就地压过 subcaption-gap 那一条设定*：图题与这一行之间插什么。
// auto ＝ 不表态，往上找文档级；写 none 就是「这一张不要那段空当」。名字用 Typst
// 的词（figure(gap:)、repeat(gap:) 都是「同一件东西两截之间」），与元素参数照
// #chapter(numbering:) 的办法——设定用带前缀的全名，元素上用它自己的词
#let _subs-mark(gap: auto, ..items) = metadata((iota-subs: items.pos(), iota-subs-gap: gap))

#let find-subs(c) = {
  let r = metadata-of(c, "iota-subs")
  if r.len() == 0 { none } else { r.first() }
}

// 那一条 #subs 就地写的 gap。没写（或压根没有 #subs）给 auto ＝ 不表态
#let find-subs-gap(c) = {
  let r = metadata-of(c, "iota-subs-gap")
  if r.len() == 0 { auto } else { r.first() }
}

// 半角标点之后那一个半角空当（分图号、连排的分隔符）。半个汉字宽，跟着当前字号走。
// *不给配置口子*：它由「半角补、全角不补」那条判据自动定，给了就能配出
// 「(a)　　静压」这种自相矛盾的组合。
#let _half-gap(layout) = h(chars.ccwd(0.5, layout: layout))

// ── 分图题（写在分图之下、连排在图题之下两档）与续排页的分图号 ────────────
// 从 caption.typ 搬来：这些是图这一种 kind 独有的，题注那边只在 caption / caption-rules
// 里调 subs-offset、sub-caption、subs-line，与读 subs-refs / subs-rows / subfigure-kind

// 续排页上分图号从第几个接着数。
//
// 范例第 11 页那一页是*带分图题的续图*：上一页排 (a)(b)，这一页排的是
// (c)(d)——同一张图一条号，不从头再来。所以要把*前面各部分*的分图数加起来。
//
// 沿着 #continued() 这条链一路往回走：一张图可能拆成三段四段，每一段都接着上一段。
// *要在 context 里调*
#let subs-offset(sel, src) = {
  let n = 0
  let cur = src
  // 一张图拆不了多少段，给个上限防呆
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    let body = cur.at("caption", default: none)
    if body == none { break }
    let items = find-subs(body.body)
    if items != none { n += items.len() }
    cur = continued-step(sel, cur)
  }
  n
}

// 分图的引用表：标签名 → (落点, 第几个分图)。*文字不在这里排*——图号要按
// by-chapter 算，而那个值*刻意不进 settings-state*（理由见 settings/resolve.typ
// 那一段），只有 caption-rules 拿得到。这里只记事实，「图1-1（a）」由 caption-rules
// 里那条 show ref 排。
#let subs-refs = state("iota-subfigure-refs", (:))
// 「现在排的是 #subs 摆的组图」：那一段里的图不再逐张按网格行取整，见 caption-rules 里
// 那条 show image 与 src/figure/kinds/image.typ
#let subs-rows = state("iota-subs-rows", false)

// 分图自成一档 kind，好与插图、表分开。计数器就是 Typst 给这一档记的那个，
// 每张母图从头数——重置由 caption-rules 里那条 show figure 发。
#let subfigure-kind = "iota-subfigure"

// Typst 的 layout 函数。各处的参数都叫 layout（那是版面字典），把内建的这个
// 先留个别名，否则在函数体里够不着它。
#let _region = layout

// ── 分图题：两档共用的三件 ────────────────────────────────────────────
//
// 分图题有两种排法（本科指南 2.13.1 的「或」）：排在*分图之下*（subfigure）
// 与排在*图题之下连排*（subs）。选哪一种由*素材*决定——每张分图是独立
// 元素就用前者，一整张图、分图号已经画在图里就只能用后者。
//
// *但排出来必须是同一个样子。* 编号写法、行首处理、两端对齐、双语判据全在
// 这三个函数里，两条路都调它们，格式没有第二个出处。

// 连排时两条分图题之间的分隔：分隔符本身，加*半角标点后那一个半角空当*。
// 与分图号后面那个空当同一条判据——半角补、全角不补（全角标点自带边距）。
// 本科范例印的是「(a) 气体静压轴承; (b) …」，分号后面确实空着一格。
#let _sub-separator(sep, layout) = context {
  sep
  if not has-cjk(plain-text(sep)) { _half-gap(layout) }
}

// 一条分图题拆成*编号*与*题名*两截。换行时编号要单独占一格，所以不能
// 先拼起来（见 _sub-block）。
#let _sub-piece(index, body, lang, layout) = (
  head: context {
    let num = numbering(setting-of("subcaption-numbering"), index)
    num
    // *半角编号后空一格，全角不空。* 本科范例印的是「(a) 气体静压轴承」
    // ——右括号之后量到 5.77，而那一页的整字身是 11.1，正好半个字身加字距。
    // 全角那一档不补：「（）」自带边距，补了就是两份。同一条判据也管着引用里
    // 「图1-1 (a)」那个空当，见 caption-rules 的 show ref。
    if not has-cjk(plain-text(num)) { _half-gap(layout) }
  },
  // *英文那一行与图题那一行同一个处理*：过一遍大小写、花括号在那儿剥
  // （见 src/fonts/case.typ）。先前这一处直接排原文，「{DNA}」的花括号印了出来、
  // title-case 也管不到分图题——图题那一层写着「英文名过一遍大小写」，分图题没有
  // 理由另走一套。要在 context 里调（读开关），measure 那两处钻得进去
  body: {
    let b = title-of(body, lang)
    if lang == "en" { context english-title(b, slot: "caption") } else { b }
  },
)

// 这一组分图题排哪几行。
//
// *要给英文就得全给*，缺一条就整组不排英文行。分图题「可以只用中文书写」
// （指南 2.13.1），双语这一档一处出处都没有，所以宁可不排也不替用户编。
//
// 先前是「缺的那条回落中文」，与图题那一层*自相矛盾*——那边写着「没写 #en
// 就只排中文，不拿中文冒充英文」。而且回落还排出参差：实测 (a) 两行 (b) 一行，
// 把母图题顶下去了。另外两种排法也不成立：编号后面空着、或跳过缺的那条，读着都
// 像排漏了。一行是一行，只能整行要么有要么没有。
#let _sub-langs(bodies) = {
  // *分图题自己一个开关*，不跟图题那一档：规范说分图题「可以只用中文书写」，
  // 双语那句点的是图题与表题，所以默认不排，见 src/settings/defaults.typ
  let bilingual = resolve-subcaption-bilingual()
  if bilingual and bodies.len() > 0 and bodies.all(b => find-en(b) != none) {
    ("zh", "en")
  } else {
    // *单语那一档跟文档语言*：英文档排的是英文那一行，与图题那一层一致
    // （_caption-line 收的 lang 就是文档语言）。先前一律写死 "zh"，英文档的分图题
    // 虽然*排*出来是对的（题里本来就只有英文，title-of 回落到正文槽），却因此
    // 被当成中文那一行，大小写与花括号都不处理
    (doc-lang.get(),)
  }
}

// 排一组分图题。lines 是已经拼好的每一行。
//
// *行首那个零宽空格是为了居中。* 默认的分图号「（a）」以全角左括号起头，
// Typst 会把行首的全角开括号压掉半个字身，整行的居中就算在压缩后的宽度上——实测
// 题的中线比分图中线偏左 2.49 与 2.61（正是半个五号字身 5.25 的一半）。换成半角
// "(a)" 或裸字母就正好（+0.14 / +0.02），可见压缩是唯一的原因。跟一个零宽空格让
// 括号不再是行首那个字符即可，与 _caption-line 末尾那一个是同一招。
//
// *写满换行时两端对齐、末行居中*：justify 加 align(center) 在 Typst 里正是
// 这个效果，与 hithesis 的 subcapcenterlast 一致。
//
// *双语两行各自居中*，跟图题表题那两行一个样——那是范例上量得到的，没有理由
// 让分图题另走一套。
//
// width 是唯一按位置分的：连排那一行在图题之下，本来就是整幅宽；分图题属于它那张
// 分图，跟着格子走。这不是格式分叉，是位置本身。
// hanging 给了就是「换行时把它悬挂出去」，与图题表题那一条同一个处理（见
// _caption-line）：一行排得下照旧居中，排不下才左对齐、缩到题名首字之下。
// 连排那一档不给——它一行里串着几条题，编号是*穿插*的，没有唯一的那一个
// 可挂。这不是格式分叉，是结构本身，跟块宽那一条同理。
//
// *每一行各自成块*，不是一个段落里用 linebreak 断开：悬挂缩进是按段落算的，
// 两行在同一段里会把英文行的「（a）」也缩进去。各自成块之后基线步进不变——两行
// 都是中易，上块行深 6.355 + 下块上升部 10.666 = 17.021，与段内断行一样。
#let _sub-block(rows, layout, style, width: auto, hang: false) = block(
  above: 0pt, below: 0pt, width: width,
  {
    show: style-rules.rules.with(style + (justify: true), layout: layout, set-font: true)
    show: western.hyphenate-rules
    set align(center)
    show par: p => p
    for row in rows {
      block(above: 0pt, below: 0pt, if not hang {
        sym.zws + row.head + row.body
      } else {
        _region(size => context {
          let whole = sym.zws + row.head + row.body
          if measure(whole).width <= size.width {
            whole
          } else {
            grid(
              columns: (auto, 1fr), align: left,
              // *两头都要零宽空格。* 编号单独入格之后，「（a）」的左括号是
              // 格里的行首、右括号是行末，Typst 两头都压：左括号压掉半个字身害得
              // 整格左移，右括号压掉半个字身害得它与题名之间少了半格（实测同一条
              // 题不换行时「）」步进 10.50，换行进了格子只剩 5.25）。
              sym.zws + row.head + sym.zws,
              par(justify: true, row.body),
            )
          }
        })
      })
    }
  },
)

// 分图题排在*分图之下*那一档——本科指南 2.13.1 给的两种写法里的另一种
// （连排那一种见下面的 subs-line 与 src/figure/kinds/image.typ 的 _subs-mark）：
//
//   #figure(
//     grid(columns: 2, column-gutter: 1cm,
//       [#subfigure(image("a.png"), caption: [静压]) <sub:static>],
//       [#subfigure(image("b.png"), caption: [动压]) <sub:dynamic>],
//     ),
//     caption: [气体润滑轴承的分类],
//   )
//
// *它返回一个真的 figure 元素*，kind 自成一档。这么做只为一件事：标签能
// *挂在外面*，跟 #figure(…) <fig:x> 一个写法——Typst 的 <label> 只在标记
// 语言里挂得上，所以格子要写成内容块 […]，但标签的位置与别处一致了。
// 先前它返回一个普通的块，标签只能写进题里（caption: [静压 <sub:static>]），
// 与整个 Typst 生态不一致。那个写法*仍然收*，见 caption-rules 的 show ref。
//
// 换来的好处不止写法：编号、引用、题注位置全走 Typst 自己的那一套，我们只在
// 题注那条规则里加一档分支。计数器每张母图从头数，由 caption-rules 那条重置。
//
// *题居中于分图*，这一条*是我们定的*：范例那一档是左对齐段落加手打
// 空格凑的，两格还凑得不一样——博士范例第 11 页那张量下来，分图中线 196.21 与
// 423.56、分图题中线 176.72 与 393.02，差 19.5 与 30.5；左缘也对不上，差 +35.7
// 与 +12.3。既不是居中也不是左对齐，就是排版的人拿空格比划的，没有规矩可依。
// 居中也是他明显想做而没做准的那件事。figure 自己就把题居中在body 上，白得。
//
// *分图与分图题之间取 0*，与图题表题同一个处理（set figure(gap: 0pt)）。
// 范例那张量到分图底缘到分图题基线 15.27 / 15.51（两格一致，这个数是准的），
// 我们排出来是一个上升部 10.67，差 4.6——与母图题那一处的差是同一笔账（图底到
// 图题基线范例 21.03、我们 10.67），一并留到题注对拍那一轮，见文件头的「待校」。
#let subfigure(body, caption: none) = figure(
  body,
  caption: caption,
  kind: subfigure-kind,
  // 分图题只有编号与题名，没有「图」这个名——那是跟着母图的序号走的
  supplement: none,
  // *numbering 这里不给。* 显式写下的字段任何 set 规则都盖不动——先前给了
  // 个 "1" 占位，caption-rules 那条按 subcaption-numbering 设的 set 就永远不生效，
  // 分图题排出来是「1静压」。不写则由那条 set 供给，计数器照样步进。
  // 分图不进图清单
  outlined: false,
)

// 分图题那一档：只有编号与题名，没有「图」那个名——名是跟着母图的序号走的。
#let sub-caption(it, layout, style) = context {
  let index = it.counter.get().first()
  // 题里写标签那一档（caption: [静压 <sub:static>]）也收：与连排一致
  let l = label-of(it.body)
  if l != none {
    let loc = here()
    subs-refs.update(m => m + ((str(l)): (loc: loc, index: index)))
  }
  // *这一档双语按每条自己判*，不看兄弟：连排那一档「要给就得全给」是因为整组是一行，缺一条
  // 就参差；分图之下每条题是自己那张分图下的一段，哪条写了 #en 哪条排两行（examples/captions.typ
  // 一直是这么写的，先前却按兄弟全有才排，写了 #en 的那条也不出英文）
  _sub-block(
    _sub-langs((it.body,)).map(lang => _sub-piece(index, it.body, lang, layout)),
    layout, style, hang: true,
  )
}

// 分图题连排的那一行（双语时两行），排在图题之下。
//
// 本科指南 2.13.1 原话：「分图号用（a）、（b）等表示，*在图题之下连续排列，
// 用『；』间隔*」；本科范例真印的是半角——居中一行
// 「(a) 气体静压轴承; (b) 气体动压轴承; (c) 气体动静压轴承; (d) 气体压膜轴承」。
// 写法与分隔都可配，见 src/settings/defaults.typ
//
// *硕博没有这一条*：研究生规范只说「分图题置于分图之下或图题之下，可以只用
// 中文书写，分图号用 a)、b) 等表示」，既没说连排也没说分隔符。没有规定就跟着本科
// 那份走，不另立一套。
//
// *一律不撑开、不对齐*：范例那一行是普通的居中文本，编号落在哪儿全看前面的
// 题名多长。要编号成列对齐的是范例的*另一种写法*（分图题排在分图之下、左对
// 齐、中间手打空格），靠的是分图自己的列位置，跟连排不是一回事——见 examples/。
//
// 编号、行首、对齐、双语判据都在 _sub-piece / _sub-langs / _sub-block 里，与分图
// 之下那一档*共用*——两种排法是分工，不是两种口味，排出来必须一个样。
#let subs-line(items, layout, style, start: 0) = context {
  // *引用登记。* 用户写在项里的标签（#subs([静压 <fig:static>], …)，或是
  // 挂在 #en[…] 后面的 <1>）捞出来，连同排好的引用文字与落点记进一张表，
  // 由 caption-rules 里那条 show ref 取用。
  //
  // *不另挂一份标签。* 先前的做法是埋一个带同名标签的记号，结果与用户那个
  // 撞车——写成 [动压 <fig:dyn>] 时标签本来就跟着题名排在版面上，再挂一份就是
  // 「label occurs multiple times」（双语回落还会让同一个标签排两遍）。改成记
  // *落点*（here()），引用直接 link 到位置，标签有几份都不碍事。
  //
  let entries = items
    .enumerate()
    .map(((i, body)) => {
      let l = label-of(body)
      if l == none { none } else { (str(l), (loc: here(), index: start + i + 1)) }
    })
    .filter(e => e != none)
  let anchors = if entries.len() == 0 { none } else {
    subs-refs.update(m => m + entries.to-dict())
  }
  let langs = _sub-langs(items)
  anchors
  // 连排那一行整条是一格：编号穿插在题名之间，没有唯一的那一个可挂
  _sub-block(
    langs.map(lang => (
      head: [],
      body: items
        .enumerate()
        .map(((i, body)) => {
          let p = _sub-piece(start + i + 1, body, lang, layout)
          p.head + p.body
        })
        .join(_sub-separator(setting-of("subcaption-separator"), layout)),
    )),
    layout, style, width: 100%,
  )
}

// 这一堆位置参数是版面还是文字：有一个版面元素就是排布
#let _layout-ish(c) = (
  type(c) == array
    or (type(c) == content and (
      c.func() in (image, stack, grid, box, block, rect, circle, polygon, curve)
        or (c.has("children") and c.children.any(_layout-ish))
        or (c.has("body") and _layout-ish(c.body))
    ))
)

// ── 树 ────────────────────────────────────────────────────────────
//
// 节点三种：leaf（一张图或一块钉死的东西）、row（ltr）、col（ttb）。每个节点带两条一次
// 函数：宽是高的 (a, b)，高是宽的 (c, d)。钉死的两条都是常数。要在 context 里建——量自然尺寸。
#let _build(c, gutter) = {
  if type(c) == array { return _build(stack(dir: ttb, ..c), gutter) }
  if type(c) == content and c.func() == stack {
    let dir = c.at("dir", default: ttb)
    let kids = c.children.filter(k => not (type(k) == content and k.func() == [ ].func()))
    if kids.len() == 0 { panic("subs: empty stack") }
    let spacing = c.at("spacing", default: none)
    let g = if spacing == none { gutter } else { spacing }
    let horizontal = dir in (ltr, rtl)
    let kids = if dir in (rtl, btt) { kids.rev() } else { kids }
    let nodes = kids.map(k => _build(k, gutter))
    // 同向的套一层拍平：几何等价，间距按外层的
    let nodes = nodes.map(n => if n.kind == (if horizontal { "row" } else { "col" }) { n.children } else { (n,) }).flatten()
    if nodes.len() == 1 { return nodes.first() }
    let gaps = (nodes.len() - 1) * g
    return if horizontal {
      // 同高 h：w = Σ(aᵢh + bᵢ) + gaps
      let a = nodes.map(n => n.a).sum()
      let b = nodes.map(n => n.b).sum() + gaps
      // 钉死的孩子高不跟 h 走，行的实际高是 max(h, 它们的高)
      let fixed-h = nodes.filter(n => n.a == 0).map(n => n.d).fold(0pt, calc.max)
      // 不放大的上限：这一行里没钉的孩子各自的自然高，取最小
      let cap = nodes.filter(n => n.a != 0).map(n => n.cap).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "row", children: nodes, gap: g, a: a, b: b,
        c: if a == 0 { 0 } else { 1 / a }, d: if a == 0 { fixed-h } else { -b / a },
        cap: cap, cap-w: if cap == none { none } else { a * cap + b })
    } else {
      // 同宽 w：h = Σ(cᵢw + dᵢ) + gaps
      let c0 = nodes.map(n => n.c).sum()
      let d0 = nodes.map(n => n.d).sum() + gaps
      let fixed-w = nodes.filter(n => n.c == 0).map(n => n.b).fold(0pt, calc.max)
      // 竖叠的「不放大」上限换算到高：每个孩子的自然宽 → 最窄的那个定了格宽，格高随之
      let cap-w = nodes.filter(n => n.c != 0).map(n => n.cap-w).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "col", children: nodes, gap: g,
        a: if c0 == 0 { 0 } else { 1 / c0 }, b: if c0 == 0 { fixed-w } else { -d0 / c0 },
        c: c0, d: d0,
        cap: if cap-w == none { none } else { c0 * cap-w + d0 },
        cap-w: cap-w)
    }
  }
  // 叶子
  let is-image = type(c) == content and c.func() == image
  let pinned = not is-image or c.at("width", default: auto) != auto or c.at("height", default: auto) != auto
  if pinned {
    let nat = measure(c)
    return (kind: "leaf", body: c, image: is-image, pinned: true, a: 0, b: nat.width, c: 0, d: nat.height, cap: nat.height, cap-w: nat.width)
  }
  // *宽高比不能直接量图的高*：figure 里那条「装图的行占整数个网格行」的 show image
  // （caption.typ）把图裹进一个 rows × 行距 的块，measure 出来的高是取整过的，比按它算
  // 一行里三张图各差 3%、等高就不等了。宽不受那个块影响：量一张定高 100pt 的图，宽 ÷ 100
  // 就是真的宽高比；自然宽另量一次（同样只取宽）
  let nat-w = measure(c).width
  let r = measure(image(c.source, height: 100pt)).width / 100pt
  if nat-w == 0pt or r == 0 {
    return (kind: "leaf", body: c, image: true, pinned: true, a: 0, b: nat-w, c: 0, d: nat-w, cap: nat-w, cap-w: nat-w)
  }
  (kind: "leaf", body: c, image: true, pinned: false, a: r, b: 0pt, c: 1 / r, d: 0pt, cap: nat-w / r, cap-w: nat-w)
}

// 叠在第 k 张图上的编号。spec 是 numbering 那一档解到这一张之后的值：none / auto 不叠，
// 串是编号格式，字典是快捷键（pattern / fill / stroke / font / size / alignment / dx / dy），
// 函数自己画
#let _place-number(k, spec, default-font, default-size) = {
  if spec == none or spec == auto { return none }
  // 字典里写 auto 的键当没写
  let d = if type(spec) == dictionary { spec.pairs().filter(((k, v)) => v != auto).to-dict() } else { (:) }
  let pattern = if type(spec) == str { spec } else { d.at("pattern", default: setting-of("subcaption-numbering")) }
  // font 写角色名（serif / sans / songti / heiti…，与样式表里的 font 同一套词）就走字体表，
  // 写家族名或数组就照 text(font:) 的原样交过去
  let font = if "font" not in d { default-font }
    else if type(d.font) == str and d.font in roles { fonts.font(d.font, fonts.current.get().families) }
    else { d.font }
  let body = if type(spec) == function { spec(k) } else {
    text(
      font: font, size: d.at("size", default: default-size),
      ..(if "fill" in d { (fill: d.fill) } else { (:) }),
      ..(if "stroke" in d { (stroke: d.stroke) } else { (:) }),
      numbering(pattern, k),
    )
  }
  // 函数返回的已经是 place 就原样贴；别的贴到默认位置——离角半个字，按编号自己那一档的字（五号）算
  if type(body) == content and body.func() == place { return body }
  place(
    d.at("alignment", default: top + left),
    dx: d.at("dx", default: 0.5 * default-size), dy: d.at("dy", default: 0.5 * default-size),
    body,
  )
}

// 把尺寸发下去：给节点一个宽和高，返回 (w, h, 渲染好的内容, 走到这儿的 ctx)。ctx 里的
// index 是下一张图的序号，逐张递增——编号与分图题都按排出来的次序数
#let _render(node, w, h, ctx) = {
  if node.kind == "leaf" {
    let (w, h) = if node.pinned { (node.b, node.d) } else { (w, h) }
    let k = ctx.index.at(0)
    ctx.index.at(0) += 1
    // *不重发 image，按比例缩用户那一个元素*：重发出来的元素 span 在这个文件里，预览里
    // 点图跳不回用户写 image(…) 的那一行。scale 一个比例（不拆 x / y，避开 typst#6636）、
    // reflow 让缩后的尺寸进版面，元素本身原封不动
    let body = if node.pinned { node.body } else {
      scale(100% * (w / node.cap-w), reflow: true, node.body)
    }
    // 编号叠在*图*上（盒子只裹图，分图题在盒子外面——bottom + right 才是图的右下角）
    let spec = if type(ctx.numbering) == array { ctx.numbering.at(k - 1, default: auto) } else { ctx.numbering }
    let num = _place-number(k, spec, ctx.font, ctx.size)
    let body = if num == none { body } else { box(width: w, { body; num }) }
    // 写了 captions: 的就是「分图之下」那一档：每格一个真 figure，题各自居中在它下面
    let body = if ctx.captions.len() >= k {
      subfigure(body, caption: ctx.captions.at(k - 1))
    } else { body }
    (w: w, h: h, body: body, ctx: ctx)
  } else if node.kind == "row" {
    let cells = ()
    let ws = ()
    for n in node.children {
      let r = _render(n, if n.a == 0 { n.b } else { n.a * h + n.b }, h, ctx)
      ctx = r.ctx
      cells.push(r.body); ws.push(r.w)
    }
    let hh = calc.max(h, ..node.children.map(n => if n.a == 0 { n.d } else { 0pt }))
    (w: ws.sum() + (ws.len() - 1) * node.gap, h: hh,
      body: grid(columns: ws, column-gutter: node.gap, align: center + horizon, ..cells), ctx: ctx)
  } else {
    let cells = ()
    let hs = ()
    for n in node.children {
      let r = _render(n, w, if n.c == 0 { n.d } else { n.c * w + n.d }, ctx)
      ctx = r.ctx
      cells.push(r.body); hs.push(r.h)
    }
    (w: w, h: hs.sum() + (hs.len() - 1) * node.gap,
      body: grid(columns: 1, row-gutter: node.gap, align: center, ..cells), ctx: ctx)
  }
}

// 一行：解 h，不放大，渲染，居中。scale 是整体缩的比例（比版心还高时用）
#let _row(items, W, g, ctx, scale: 1) = {
  let node = _build(stack(dir: ltr, ..items), g)
  // 一行里只有一格时 _build 直接交回那一格，套一层行好走同一条路
  let node = if node.kind == "row" { node } else {
    (kind: "row", children: (node,), gap: g, a: node.a, b: node.b, c: node.c, d: node.d, cap: node.cap)
  }
  let h = if node.a == 0 { node.d } else { (W - node.b) / node.a }
  let h = if node.cap == none { h } else { calc.min(h, node.cap) }
  let r = _render(node, node.a * h * scale + node.b, h * scale, ctx)
  (body: align(center, r.body), h: r.h, ctx: r.ctx)
}

// 排布那一支。参数都是解好的（auto 在 subs 里折成默认值）
#let _subs-layout(items, columns, width, gutter, captions, numbering) = {
  let items = items.filter(k => not (type(k) == content and k.func() == [ ].func()))
  if items.len() == 0 { panic("subs: nothing to lay out") }
  if type(captions) != array { panic("subs: captions: expected array, found " + str(type(captions))) }
  // 切行：auto 一行，整数每行几个，数组逐行几个
  let rows = if columns == auto { (items,) } else if type(columns) == int {
    range(0, items.len(), step: columns).map(i => items.slice(i, calc.min(i + columns, items.len())))
  } else if type(columns) == array {
    let out = (); let i = 0
    for n in columns { out.push(items.slice(i, calc.min(i + n, items.len()))); i += n }
    if i < items.len() { out.push(items.slice(i)) }
    out
  } else { panic("subs: columns: expected auto, integer, or array, found " + repr(columns)) }
  layout(size => context {
    // 当前生效的版面；没进过 iota-hit 的文档从本档默认起
    let lay = _layout.current-layout()
    let g = (if gutter == auto { chars.ccwd(1) } else { chars.resolve-chars(gutter, lay) }).to-absolute()
    let W = if type(width) == ratio { size.width * width } else { width.to-absolute() }
    let fresh = (index: (1,), captions: captions, numbering: numbering,
      font: fonts.font("sans", fonts.current.get().families), size: zihao.wuhao)
    let ctx = fresh
    let out = ()
    for row in rows {
      let r = _row(row, W, g, ctx)
      ctx = r.ctx
      out.push(r)
    }
    // 整体比版心还高就整体缩到装下：图不能跨页。只管单行——多行各自成块，续图机制接得住
    let room = lay.text-height - 3 * lay.docgrid.line-pitch
    if out.len() == 1 and out.first().h > room {
      out = (_row(rows.first(), W, g, fresh, scale: room / out.first().h),)
    }
    // 网格开着时一行占整数个网格行、行在里面居中——与单张图那条规则同一个模型
    // （caption.typ 的 show image），只是按行不按张：里面的图那条规则见到记号就不碰
    let snapped = lay.docgrid.grid and lay.docgrid.line-pitch != 0pt
    let row-block(r) = if snapped {
      // 量排出来的（分图之下那一档每格还挂着题，比解出来的行高高）
      let h = measure(block(width: size.width, r.body)).height
      let rows = calc.max(1, calc.ceil(h / lay.docgrid.line-pitch))
      block(width: 100%, height: rows * lay.docgrid.line-pitch, above: 0pt, below: 0pt, align(horizon, r.body))
    } else { block(width: 100%, above: 0pt, below: 0pt, r.body) }
    subs-rows.update(true)
    out.map(row-block).join(v(g))
    subs-rows.update(false)
  })
}

// 公开的那一个：看位置参数决定走哪一支
// *每一项都收 auto ＝ 不写*（包里的惯例）：columns 一行、width 90%、gutter 一个字、captions
// 没有、numbering 不叠；numbering 的数组里某一项写 auto 也是不叠，字典里的键写 auto 就是
// 那一项的默认
#let subs(gap: auto, columns: auto, width: auto, gutter: auto, captions: auto, numbering: auto, ..items) = {
  if items.pos().any(_layout-ish) {
    _subs-layout(
      items.pos(), columns,
      if width == auto { 90% } else { width },
      gutter,
      if captions == auto { () } else { captions },
      if numbering == auto { none } else { numbering },
    )
  } else {
    _subs-mark(gap: gap, ..items)
  }
}

