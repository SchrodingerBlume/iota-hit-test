// 图（kind image）这一种独有的东西：组图——几张分图怎么摆。题注本身在 ../caption.typ。
//
// 同一个名字两个位置，靠上下文分：写在图题里的 #subs([静压], [动压]) 是分图题
// （连排在图题之下，见 src/figure/caption.typ 的 subs）；写在图的正身里的
// #subs(image("a.png"), image("b.png")) 是排布。判法看位置参数——里面有 image / stack
// 这类版面元素就是排布，全是文字就是分图题。
//
//     #figure(
//       subs(image("a.png"), stack(image("b.png"), image("c.png")), columns: auto, width: 90%),
//       caption: [气体润滑轴承的分类 #subs([静压 <fig:s>], [动压], [动静压])],
//     ) <fig:1-1>
//
// *模型*：一行里的图等高、各保宽高比、撑到给定的宽。任何一个节点的宽都是高的一次
// 函数 w(h) = a·h + b——叶子 w = r·h；横排（ltr）孩子同高、宽相加；竖叠（ttb）孩子同宽、
// 高相加，反解回来还是一次的；套多少层都只是一次函数的复合。最外层令 w(h) = W 一步
// 解出 h，再自顶向下把尺寸发下去。不二分、不迭代。
//
// *行与列直接收原生的 stack*：stack(dir: ltr | ttb, …) 的 dir 与 children 就是树，随便嵌。
// rtl / btt 与 ltr / ttb 同一套几何，只把孩子倒过来；横排里套横排、竖叠里套竖叠拍平成
// 一层；一个孩子的 stack 透明；空的当场报错。stack(spacing:) 写了照写的，没写用 gutter。
// columns: 2 / (3, 2) 是「切成几行、每行各自撑满」的糖。
//
// *写了什么守什么*：图自己写了 width / height 的算钉死，按写的排，不缩不放，解的时候
// 从 W 里扣掉它的宽；不是 image 的叶子（rect、cetz、文字块）按 measure 的自然尺寸钉死，
// 要它跟着缩就自己裹一层 box(width: …)。一行全钉死了就没有自由量，按自然总宽居中。
//
// *不放大*：解出来的行高不超过这一行里任何一张没钉的图的自然高——两张小图本来装得下，
// 不该被拉到版心那么宽（范例的分图都是自然尺寸）。装不下才缩。整体比版心还高（一竖溜
// 三张竖图）就整体等比缩到装下——图不能跨页；columns 切出来的多行不在此列，那是各自
// 的块，续图机制接得住（每行一个块，行间 v(gutter)，见 caption.typ 的 _split）。
//
// *分图题在哪跟着它写在哪儿*：写在图题里就是「图题之下」连排（现在的 #subs 那一档），
// 写在这里的 captions: 就是「分图之下」（每格换成 #subfigure，题各自居中在自己那张分图
// 下，标签写在条目里）。指南 2.13.1 那句「分图题置于分图之下或图题之下」只有这两处，
// 一个字写在哪儿就排在哪儿，不设开关。
//
// *叠在图上的编号* numbering，照原生 figure(numbering:) 的三态再加一档：
//   none        不叠（默认）——分图号通常已经画在图里
//   "(a)"       编号串，交 numbering() 排；默认样子五号 sans 黑字、左上角、离角半个字
//   (pattern: "a)", fill: white, alignment: bottom + right, dx: -4pt, dy: -4pt)
//               字典，只写要改的——都是快捷键，键名借原生的：pattern 是编号串（原生文档叫它
//               numbering pattern，datetime.display(pattern) 里就是参数名；没写跟
//               subcaption-numbering）；fill / stroke / font / size
//               是 text 的（font 写角色名 serif / sans / songti… 走字体表，写家族名原样交）；
//               alignment / dx / dy 是 place 的。再多的（描边圆底之类）走函数
//   n => …      函数收序号；返回 place 元素就原样贴上（位置样式全听它的），返回别的按
//               默认位置贴
//   数组        逐图一项，每项上面四态混着写
#import "../../layout/chars.typ" as chars
#import "../../layout/resolve.typ" as _layout
#import "../../fonts/resolve.typ" as fonts
#import "../../styles/rules.typ" as style-rules
#import "../../settings/resolve.typ": setting-of
#import "../caption.typ": subs as _subs-mark, subfigure, subs-rows
#import "../../fonts/presets.typ": zihao, roles

// 这一堆位置参数是版面还是文字：有一个版面元素就是排布
#let _layout-ish(c) = (
  type(c) == array
    or (type(c) == content and (
      c.func() in (image, stack, grid, box, block, rect, circle, polygon, curve)
        or (c.has("children") and c.children.any(_layout-ish))
        or (c.has("body") and _layout-ish(c.body))
    ))
)

// ── 树 ────────────────────────────────────────────────────────────
//
// 节点三种：leaf（一张图或一块钉死的东西）、row（ltr）、col（ttb）。每个节点带两条一次
// 函数：宽是高的 (a, b)，高是宽的 (c, d)。钉死的两条都是常数。要在 context 里建——量自然尺寸。
#let _build(c, gutter) = {
  if type(c) == array { return _build(stack(dir: ttb, ..c), gutter) }
  if type(c) == content and c.func() == stack {
    let dir = c.at("dir", default: ttb)
    let kids = c.children.filter(k => not (type(k) == content and k.func() == [ ].func()))
    if kids.len() == 0 { panic("subs: empty stack") }
    let spacing = c.at("spacing", default: none)
    let g = if spacing == none { gutter } else { spacing }
    let horizontal = dir in (ltr, rtl)
    let kids = if dir in (rtl, btt) { kids.rev() } else { kids }
    let nodes = kids.map(k => _build(k, gutter))
    // 同向的套一层拍平：几何等价，间距按外层的
    let nodes = nodes.map(n => if n.kind == (if horizontal { "row" } else { "col" }) { n.children } else { (n,) }).flatten()
    if nodes.len() == 1 { return nodes.first() }
    let gaps = (nodes.len() - 1) * g
    return if horizontal {
      // 同高 h：w = Σ(aᵢh + bᵢ) + gaps
      let a = nodes.map(n => n.a).sum()
      let b = nodes.map(n => n.b).sum() + gaps
      // 钉死的孩子高不跟 h 走，行的实际高是 max(h, 它们的高)
      let fixed-h = nodes.filter(n => n.a == 0).map(n => n.d).fold(0pt, calc.max)
      // 不放大的上限：这一行里没钉的孩子各自的自然高，取最小
      let cap = nodes.filter(n => n.a != 0).map(n => n.cap).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "row", children: nodes, gap: g, a: a, b: b,
        c: if a == 0 { 0 } else { 1 / a }, d: if a == 0 { fixed-h } else { -b / a },
        cap: cap, cap-w: if cap == none { none } else { a * cap + b })
    } else {
      // 同宽 w：h = Σ(cᵢw + dᵢ) + gaps
      let c0 = nodes.map(n => n.c).sum()
      let d0 = nodes.map(n => n.d).sum() + gaps
      let fixed-w = nodes.filter(n => n.c == 0).map(n => n.b).fold(0pt, calc.max)
      // 竖叠的「不放大」上限换算到高：每个孩子的自然宽 → 最窄的那个定了格宽，格高随之
      let cap-w = nodes.filter(n => n.c != 0).map(n => n.cap-w).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "col", children: nodes, gap: g,
        a: if c0 == 0 { 0 } else { 1 / c0 }, b: if c0 == 0 { fixed-w } else { -d0 / c0 },
        c: c0, d: d0,
        cap: if cap-w == none { none } else { c0 * cap-w + d0 },
        cap-w: cap-w)
    }
  }
  // 叶子
  let is-image = type(c) == content and c.func() == image
  let pinned = not is-image or c.at("width", default: auto) != auto or c.at("height", default: auto) != auto
  if pinned {
    let nat = measure(c)
    return (kind: "leaf", body: c, image: is-image, pinned: true, a: 0, b: nat.width, c: 0, d: nat.height, cap: nat.height, cap-w: nat.width)
  }
  // *宽高比不能直接量图的高*：figure 里那条「装图的行占整数个网格行」的 show image
  // （caption.typ）把图裹进一个 rows × 行距 的块，measure 出来的高是取整过的，比按它算
  // 一行里三张图各差 3%、等高就不等了。宽不受那个块影响：量一张定高 100pt 的图，宽 ÷ 100
  // 就是真的宽高比；自然宽另量一次（同样只取宽）
  let nat-w = measure(c).width
  let r = measure(image(c.source, height: 100pt)).width / 100pt
  if nat-w == 0pt or r == 0 {
    return (kind: "leaf", body: c, image: true, pinned: true, a: 0, b: nat-w, c: 0, d: nat-w, cap: nat-w, cap-w: nat-w)
  }
  (kind: "leaf", body: c, image: true, pinned: false, a: r, b: 0pt, c: 1 / r, d: 0pt, cap: nat-w / r, cap-w: nat-w)
}

// 叠在第 k 张图上的编号。spec 是 numbering 那一档解到这一张之后的值：none / auto 不叠，
// 串是编号格式，字典是快捷键（pattern / fill / stroke / font / size / alignment / dx / dy），
// 函数自己画
#let _place-number(k, spec, default-font, default-size) = {
  if spec == none or spec == auto { return none }
  // 字典里写 auto 的键当没写
  let d = if type(spec) == dictionary { spec.pairs().filter(((k, v)) => v != auto).to-dict() } else { (:) }
  let pattern = if type(spec) == str { spec } else { d.at("pattern", default: setting-of("subcaption-numbering")) }
  // font 写角色名（serif / sans / songti / heiti…，与样式表里的 font 同一套词）就走字体表，
  // 写家族名或数组就照 text(font:) 的原样交过去
  let font = if "font" not in d { default-font }
    else if type(d.font) == str and d.font in roles { fonts.font(d.font, fonts.current.get().families) }
    else { d.font }
  let body = if type(spec) == function { spec(k) } else {
    text(
      font: font, size: d.at("size", default: default-size),
      ..(if "fill" in d { (fill: d.fill) } else { (:) }),
      ..(if "stroke" in d { (stroke: d.stroke) } else { (:) }),
      numbering(pattern, k),
    )
  }
  // 函数返回的已经是 place 就原样贴；别的贴到默认位置——离角半个字，按编号自己那一档的字（五号）算
  if type(body) == content and body.func() == place { return body }
  place(
    d.at("alignment", default: top + left),
    dx: d.at("dx", default: 0.5 * default-size), dy: d.at("dy", default: 0.5 * default-size),
    body,
  )
}

// 把尺寸发下去：给节点一个宽和高，返回 (w, h, 渲染好的内容, 走到这儿的 ctx)。ctx 里的
// index 是下一张图的序号，逐张递增——编号与分图题都按排出来的次序数
#let _render(node, w, h, ctx) = {
  if node.kind == "leaf" {
    let (w, h) = if node.pinned { (node.b, node.d) } else { (w, h) }
    let k = ctx.index.at(0)
    ctx.index.at(0) += 1
    // *不重发 image，按比例缩用户那一个元素*：重发出来的元素 span 在这个文件里，预览里
    // 点图跳不回用户写 image(…) 的那一行。scale 一个比例（不拆 x / y，避开 typst#6636）、
    // reflow 让缩后的尺寸进版面，元素本身原封不动
    let body = if node.pinned { node.body } else {
      scale(100% * (w / node.cap-w), reflow: true, node.body)
    }
    // 编号叠在*图*上（盒子只裹图，分图题在盒子外面——bottom + right 才是图的右下角）
    let spec = if type(ctx.numbering) == array { ctx.numbering.at(k - 1, default: auto) } else { ctx.numbering }
    let num = _place-number(k, spec, ctx.font, ctx.size)
    let body = if num == none { body } else { box(width: w, { body; num }) }
    // 写了 captions: 的就是「分图之下」那一档：每格一个真 figure，题各自居中在它下面
    let body = if ctx.captions.len() >= k {
      subfigure(body, caption: ctx.captions.at(k - 1))
    } else { body }
    (w: w, h: h, body: body, ctx: ctx)
  } else if node.kind == "row" {
    let cells = ()
    let ws = ()
    for n in node.children {
      let r = _render(n, if n.a == 0 { n.b } else { n.a * h + n.b }, h, ctx)
      ctx = r.ctx
      cells.push(r.body); ws.push(r.w)
    }
    let hh = calc.max(h, ..node.children.map(n => if n.a == 0 { n.d } else { 0pt }))
    (w: ws.sum() + (ws.len() - 1) * node.gap, h: hh,
      body: grid(columns: ws, column-gutter: node.gap, align: center + horizon, ..cells), ctx: ctx)
  } else {
    let cells = ()
    let hs = ()
    for n in node.children {
      let r = _render(n, w, if n.c == 0 { n.d } else { n.c * w + n.d }, ctx)
      ctx = r.ctx
      cells.push(r.body); hs.push(r.h)
    }
    (w: w, h: hs.sum() + (hs.len() - 1) * node.gap,
      body: grid(columns: 1, row-gutter: node.gap, align: center, ..cells), ctx: ctx)
  }
}

// 一行：解 h，不放大，渲染，居中。scale 是整体缩的比例（比版心还高时用）
#let _row(items, W, g, ctx, scale: 1) = {
  let node = _build(stack(dir: ltr, ..items), g)
  // 一行里只有一格时 _build 直接交回那一格，套一层行好走同一条路
  let node = if node.kind == "row" { node } else {
    (kind: "row", children: (node,), gap: g, a: node.a, b: node.b, c: node.c, d: node.d, cap: node.cap)
  }
  let h = if node.a == 0 { node.d } else { (W - node.b) / node.a }
  let h = if node.cap == none { h } else { calc.min(h, node.cap) }
  let r = _render(node, node.a * h * scale + node.b, h * scale, ctx)
  (body: align(center, r.body), h: r.h, ctx: r.ctx)
}

// 排布那一支。参数都是解好的（auto 在 subs 里折成默认值）
#let _subs-layout(items, columns, width, gutter, captions, numbering) = {
  let items = items.filter(k => not (type(k) == content and k.func() == [ ].func()))
  if items.len() == 0 { panic("subs: nothing to lay out") }
  if type(captions) != array { panic("subs: captions: expected array, found " + str(type(captions))) }
  // 切行：auto 一行，整数每行几个，数组逐行几个
  let rows = if columns == auto { (items,) } else if type(columns) == int {
    range(0, items.len(), step: columns).map(i => items.slice(i, calc.min(i + columns, items.len())))
  } else if type(columns) == array {
    let out = (); let i = 0
    for n in columns { out.push(items.slice(i, calc.min(i + n, items.len()))); i += n }
    if i < items.len() { out.push(items.slice(i)) }
    out
  } else { panic("subs: columns: expected auto, integer, or array, found " + repr(columns)) }
  layout(size => context {
    // 当前生效的版面；没进过 iota-hit 的文档从本档默认起
    let lay = _layout.current-layout()
    let g = (if gutter == auto { chars.ccwd(1) } else { chars.resolve-chars(gutter, lay) }).to-absolute()
    let W = if type(width) == ratio { size.width * width } else { width.to-absolute() }
    let fresh = (index: (1,), captions: captions, numbering: numbering,
      font: fonts.font("sans", fonts.current.get().families), size: zihao.wuhao)
    let ctx = fresh
    let out = ()
    for row in rows {
      let r = _row(row, W, g, ctx)
      ctx = r.ctx
      out.push(r)
    }
    // 整体比版心还高就整体缩到装下：图不能跨页。只管单行——多行各自成块，续图机制接得住
    let room = lay.text-height - 3 * lay.docgrid.line-pitch
    if out.len() == 1 and out.first().h > room {
      out = (_row(rows.first(), W, g, fresh, scale: room / out.first().h),)
    }
    // 网格开着时一行占整数个网格行、行在里面居中——与单张图那条规则同一个模型
    // （caption.typ 的 show image），只是按行不按张：里面的图那条规则见到记号就不碰
    let snapped = lay.docgrid.grid and lay.docgrid.line-pitch != 0pt
    let row-block(r) = if snapped {
      // 量排出来的（分图之下那一档每格还挂着题，比解出来的行高高）
      let h = measure(block(width: size.width, r.body)).height
      let rows = calc.max(1, calc.ceil(h / lay.docgrid.line-pitch))
      block(width: 100%, height: rows * lay.docgrid.line-pitch, above: 0pt, below: 0pt, align(horizon, r.body))
    } else { block(width: 100%, above: 0pt, below: 0pt, r.body) }
    subs-rows.update(true)
    out.map(row-block).join(v(g))
    subs-rows.update(false)
  })
}

// 公开的那一个：看位置参数决定走哪一支
// *每一项都收 auto ＝ 不写*（包里的惯例）：columns 一行、width 90%、gutter 一个字、captions
// 没有、numbering 不叠；numbering 的数组里某一项写 auto 也是不叠，字典里的键写 auto 就是
// 那一项的默认
#let subs(gap: auto, columns: auto, width: auto, gutter: auto, captions: auto, numbering: auto, ..items) = {
  if items.pos().any(_layout-ish) {
    _subs-layout(
      items.pos(), columns,
      if width == auto { 90% } else { width },
      gutter,
      if captions == auto { () } else { captions },
      if numbering == auto { none } else { numbering },
    )
  } else {
    _subs-mark(gap: gap, ..items)
  }
}
