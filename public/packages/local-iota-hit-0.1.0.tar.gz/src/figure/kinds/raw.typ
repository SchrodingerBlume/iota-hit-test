#import "@local/banshi:0.1.0" as banshi
#import "../../settings/resolve.typ" as _settings
#import banshi.fonts as _fonts
#import banshi.styles as sheet
#import "../../styles/lookup.typ" as _lookup
#import banshi.layout as _layout
#import "../kinds.typ": in-listing
#import banshi.styles as _table
#import "../continued.typ": continued-step
#import "./algorithm.typ": _number, _column, _NUMBER-GAP
#let _line-offset() = {
  let sel = figure.where(kind: raw)
  let mine = query(sel.before(here(), inclusive: true))
  if mine.len() == 0 { return 0 }
  let cur = mine.last()
  let n = 0
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    cur = continued-step(sel, cur)
    if cur == none { break }
    let b = cur.body
    if type(b) == content and b.func() == raw { n += b.text.split("\n").len() }
  }
  n
}
#let _hang(text-of-line) = {
  let n = 0
  for c in text-of-line.clusters() {
    if c == " " or c == "\t" { n += 1 } else { break }
  }
  if n == 0 { return 0pt }
  let space = measure(text(tracking: 0pt, "x x")).width - measure(text(tracking: 0pt, "xx")).width
  let half = _layout.current-page-setup().docgrid.tracking / 2
  n * (space + half) - _fonts.boundary-pad(half)
}
#let _lines(it, st, offset) = {
  let numbered = st.line-numbering != none
  set text(.._fonts.mono-edges-em(
    _lookup.current-styles().body.size,
    _lookup.current-styles().body.at("line-spacing", default: 1),
  ))
  let col = _column(st.line-numbering, offset, offset + it.lines.len())
  let rows = for (i, line) in it.lines.enumerate() {
    let hang = _hang(line.text)
    block(width: 100%, above: 0pt, below: 0pt, pad(left: hang, {
      h(-hang, weak: false)
      if numbered { _number(offset + i + 1, 0, st.line-numbering, col) }
      if line.text == "" { hide(text("x")) }
      line
    }))
  }
  // 行号悬到版心外（负向挪出去），代码顶着版心写，编不编号左缘一样
  rows
}
#let listing(it) = context {
  let st = _settings.resolve-raw-style()
  let ts = _table.table-style()
  let s = ts.stroke
  let x = ts.inset.x
  let piece = block.with(width: 100%, above: 0pt, below: 0pt)
  let main = piece(inset: (x: x), _lines(it, st, _line-offset()))
  let rule(stroke) = piece(height: 0pt, stroke: (top: stroke))
  set align(left)
  if st.frame == "tabular" {
    piece(stroke: (top: s.top, bottom: s.bottom), inset: (top: s.top / 2, bottom: s.bottom / 2), main)
  } else if st.frame == "ruled" {
    rule(s.header)
    piece(inset: (top: s.header / 2, bottom: s.bottom / 2), main)
    rule(s.bottom)
  } else if st.frame == "boxed" {
    piece(stroke: s.header, inset: (y: s.header / 2), main)
  } else {
    main
  }
}
#let listing-rules(doc) = {
  show raw.where(block: true): it => context {
    if in-listing.get() { listing(it) } else {
      _lines(it, _settings.resolve-raw-style() + (line-numbering: none), 0)
    }
  }
  doc
}

