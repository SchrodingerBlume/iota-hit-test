// 三线表：三条线的粗细（数住样式表，见下）与续排页上的「表N-N（续表）」那一行。
// 表格本身怎么接到 Typst 上（格里的行高、内边距、居中、表头里注一格）是通用的
// Word 表格模型，在 banshi/src/styles/table.typ。

#import "@local/banshi:0.1.0" as banshi
#import "../../heading/numbering.typ" as _numbering
#import "../continued.typ": find-continued
#import "../../terms/lang.typ": doc-lang
#import "../../references/refs.typ" as refs
#import banshi.styles as _table
#import banshi.styles: table-style, cell-style, built-mark

// 三线表的三条线。*读自范例的 docx，不是从 PDF 上量的*。
//
// 指南只说「不加左右边线」「建议采用国际通行的三线表」，一个数都没给。范例里
// 那张表的 tblPr 是全框 sz=4，三条线由*单元格级*的 w:tcBorders 逐格盖掉：
//
//   表头行  top=single sz=12   bottom=single sz=8   left/right=nil
//   数据首行 top=single sz=8    其余 nil
//   末行    bottom=single sz=12  其余 nil
//   中间各行 四边全 nil
//
// w:sz 的单位是八分之一磅，sz=12 / 8 就是 Word「边框和底纹」里那个宽度下拉框上的
// *1½ 磅*与*1 磅*——写界面上的数，换算是我们内部的事。
// （更早那组 1 / 0.5 / 1 是按出版界通行值拍的，后来量了 PDF，现在是读出来的。）
// 数在 src/styles/presets.typ 的 _table.stroke，键 top / header / bottom。

// 续排那一页「表N-N（续表）」那一行的上下位置，*与单元格同一条规则算出来*：
// 单倍行高在网格行里居中。
//
// 实测本科范例第 14 页（trace 读线，stext 读基线）：
//
//   标注基线 121.28（五号、右对齐）   顶线 127.05–128.55，中心 127.80
//   版心顶 107.75 → 标注基线 13.53      标注基线 → 顶线中心 6.52
//
// 模型算：
//
//   上 = (19.15 − 13.617) / 2 + 上升部 10.66 = 13.43   （差 0.10）
//   下 = 行深 2.96 + 下半格 2.77 + 半条顶线 0.75 = 6.48（差 0.04）
//
// docx 那一段写着 w:jc="right"、sz=21、*没有 w:spacing*——单倍，与表内
// 单元格一样。博士范例第 16 页量到 13.55 / 6.45，两份对得上。
//
// 先前这里存的是 13.53 / 6.52 两个实测数。
// 注入到表头里的那一格：起始页什么也不排，续排的页上排「表N-N（续表）」。
//
// 找「这是哪个表」的办法与页眉找「这是哪一章」同一套：查出全部表，取起始页
// 不晚于本页的最后一个。用 <= 而不是 <——本页起的表也算。
#let continued-row(metrics, top-rule, by-chapter) = context {
  let page-now = here().page()
  // *这一行属于哪张表：按文档顺序取「在我之前最后起排的」那一张。*
  //
  // 注进去的这一行看不见外面的 figure，只能自己找。先前按页码判，两个方向各
  // 错一次：收「≤ 本页」时，续排页上又起了新表就取到新表、判成起始页，标注丢
  // 掉；收「< 本页」时，跨页表*之后*的任何一张表都会取到那张跨页表，白多
  // 一条标注。页码分不开同页的先后，位置分得开——这一行在自己那张表里面，
  // 所以在它之前起排的最后一个 figure 必是自家的。
  let me = here().position()
  let owners = query(figure.where(kind: table)).filter(g => {
    let at = g.location().position()
    at.page < me.page or (at.page == me.page and at.y <= me.y)
  })
  if owners.len() == 0 { return }
  let f = owners.last()
  // 起始页不排——那一页有正经的表题。手工拆表的后半是例外：它本页起排，
  // 而题里写着 #continued()，那正是「这一张是上一张的续」的意思
  let mark = find-continued(f.caption.body)
  if f.location().page() == page-now and mark == none { return }
  if f.numbering == none { return }
  let lang = doc-lang.get()
  // 接的是哪一张表的号。
  //
  // *跨页接排*：f 就是那张表本身，直接取它的号。
  //
  // *手工拆表*：f 是后半那个 figure，Typst 已经替它记过一次数，于是
  //   一、号要取*它接的那一张*——写了 #continued(<tab:one>) 就按标签找，
  //       没写就接紧挨着的前一张（拆表就是把相邻的一张拆成两半）；
  //   二、计数器要退回去，否则后面那个真表跳号（指南 2.12：续表不占新号）。
  let src = if mark == none {
    f
  } else if mark.target != none {
    query(mark.target).first()
  } else {
    let before = query(figure.where(kind: table)).filter(
      g => g.location().position().page < f.location().position().page
        or (g.location().position().page == f.location().position().page
            and g.location().position().y < f.location().position().y),
    )
    if before.len() == 0 { return }
    before.last()
  }
  // *只在那张表*起排*的那一页退。* 这一行住在表头里，表头每页重排一次，
  // 这个 context 就每页跑一次（文件里别处也记着「实测重复出来的表头里 context 会
  // 按页重算」）——不加这一条，手工拆开的后半张表跨几页就退几格：实测续表占两页时
  // 它后面那张表印成「表1-1」与第一张*重号*（不报错、不告警），表再长
  // （60 行起）直接 error: number must be at least zero 加 did not converge。
  if mark != none and f.location().page() == page-now {
    counter(figure.where(kind: table)).update(v => v - 1)
  }
  // *章号要按「被接的那张表」所在的位置取。* figure 的编号闭包里写的是
  // counter(heading).get()——读的是*排它的那个位置*的章号。正常题注就在
  // 图表旁边，没差；续排标注可能排到下一章去（长表跨章），那时 get() 读到的是
  // 下一章的号，排出来就成了「表6-1（续表）」。所以这里不调那个闭包，自己按
  // src 的位置取章号与序号。
  let seq = counter(figure.where(kind: table)).at(src.location())
  let num = if by-chapter {
    _numbering.chapter-numbered(src.location(), seq)
  } else {
    numbering("1", ..seq)
  }
  // *上面那点空当由行高自己出。* 这一格的内边距是清零的（起始页那一格是空的，
  // 留着会白占一行高），先前用 v(半个行间) 补出来；格里改成贴网格之后，行高本身就是
  // 一个网格行、字面在里面居中，那半个行间已经在盒子里，再补就多一份。
  //
  // *标注不参与列宽计算。* 它注在一格 colspan 满行的单元格里，照直排的话
  // 内容宽度会挤进列宽——而 Typst 把多出来的宽度*全给最后一列*，于是表被
  // 单侧撑开，各列的文字虽然各自居中，整张表看着就歪了（实测两列小表：第一列
  // 21.3、第二列 47.8）。
  //
  // *标注不参与列宽计算。* 主表的列宽由数据定，续表那一行不该把它撑开
  // ——同一张表在起始页和续排页会宽窄不一，看着就不是一张表了。
  //
  // 所以套一个零宽盒子（外层宽 0 不给列提最低要求），里面按实测宽度定宽，再自己
  // 挪到位。内层必须定宽：外层可用宽度是 0，不定宽文字会被压得逐字换行（实测
  // 「表」「1-1」「（续」「表）」各占一行）。
  //
  // *放得下贴右缘，放不下居中*。
  //
  // *Typst 的对齐按盒子里*内容*的宽度算，不是按声明的 0*——所以整表
  // 那条 align: center 已经把内容摆在格子中央了（内容心 ＝ 格心）。于是：
  //
  //   w > 格宽   dx = 0              已经居中，两边各溢出一半，比一头长出去好看
  //   w ≤ 格宽   dx = (格宽 − w)/2   往右推半个空当，右缘落到表的右缘上
  //                                 （指南 2.12「表右上角注明编号」）
  //
  // 合起来就是 max(0, (格宽 − w)/2)。
  //
  // 试过两条别的路：塞进一格 colspan 让它照直占宽，Typst 把多出来的宽度全给最后
  // 一列，表被单侧撑开（两列小表 21.3 / 47.8）；改成每列各摊一份 w/n 撑得是匀了，
  // 可主表并没有这回事，同一张表两页宽窄不同。width: 100% 更不行——自动列里那种
  // 百分比按整个版心算，第一列被撑到 90.45。
  // 这张表显式写了名（figure(table, supplement: [清单])）就照它，标注用光的「（续）」，
  // 与题注那一支同一条（见 refs.given-supplement）
  let given = refs.given-supplement(src.fields(), table, doc-lang.get())
  let mark-text = {
    let name = if given != auto { given } else { refs.word(lang, "table") }
    // 「（续表）」里的名不带「附」（指南 2.12 的原话就是「（续表）」）；号前面的名带——附录里
    // 数那几档的表叫「附表1」，续排那一行也是「附表1（续表）」，与题注那一支同（caption.typ）
    let mark = refs.continued-mark(lang, name)
    let name = if given != auto { given } else {
      _numbering.appendix-prefix(src.location(), lang, by-chapter: by-chapter) + name
    }
    name + (if lang == "en" { " " }) + num + refs.continued-gap(mark)
    mark
    sym.zws
  }
  context {
    let w = measure(mark-text).width
    layout(size => box(width: 0pt, move(
      dx: calc.max(0pt, (size.width - w) / 2),
      box(width: w, mark-text),
    )))
  }
  // 下面那半条线（Typst 把线画在格边界正中，Word 的线整条在表里）由这一格的
  // 内边距垫，见 show table 里的 mark-cell——先前这儿 v(半条线)，与内边距是同一份，
  // 两处都留就多一半
}

// 接到 table 上：通用的重建（banshi/src/styles/table.typ）加「（续表）」那一格。src/iota-hit.typ 紧接着
// caption-rules 装（次序不变）。参数与 caption-rules 同名同义：header-rows 表头占几行，
// by-chapter 号按不按章
#let table-rules(by-chapter: true, header-rows: 1, doc) = _table.table-rules(
  header-rows: header-rows,
  note: (metrics, top-rule) => continued-row(metrics, top-rule, by-chapter),
  doc,
)
