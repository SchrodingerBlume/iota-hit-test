// 三线表：线、内边距、单元格里的段落、续排页上的「表N-N（续表）」那一行。

#import "../../heading/numbering.typ" as _numbering
#import "../../styles/sheet.typ" as sheet
#import "../continued.typ": find-continued
#import "../../terms/lang.typ": doc-lang
#import "../../styles/presets.typ": default-styles
#import "../../references/refs.typ" as refs
#import "../../layout/resolve.typ" as _layout
#import "../../styles/rules.typ" as style-rules
#import "../../paragraph/linebox.typ" as linebox

// 三线表的数据行：*行高就是文档网格的行距，行盒在行里垂直居中*。
//
// 实测本科范例第 12 页那张表（trace 读三条线，stext 读基线）：
//
//   顶线 327.35–328.85（1.5）  表头下 386.12–387.12（1.0）  底线 521.40–522.90（1.5）
//   数据基线 400.62 … 515.65，七行六步共 115.03，一步 19.17
//   行高 = (521.40 − 387.12) / 7 = 19.18
//   首基线距行顶 = 400.62 − 387.12 = 13.50
//
// 那一节（第 4～6 章，拷贝进来的 FLUENT）的 docGrid 是 linePitch=383，也就是
// 19.15 磅——步进与行高都是它。而 13.50 由模型算得出来：五号行盒 1.296875 × 10.5
// = 13.617 在 19.15 的行里居中，上留 (19.15 − 13.617) / 2 = 2.77，基线 = 2.77 +
// 上升部 10.66 = 13.43，与量到的 13.50 差 0.07。
//
// 所以两个内边距都是 (网格行距 − 行盒高) / 2，*一个常数都不用存*。终稿默认
// 的跨度是 391 缇 ＝ 19.55（见 src/layout/presets.typ），表在正文里排出来的行高就是
// 19.55、首基线距行顶 13.63——范例那张表落在 383 的节里才是 19.15，规则不变。
//
// *先前这里存过 13.98 / 19.24*，还写着一段「为什么不是上下对称」——那是
// 当初把行高当成了 15.84（行盒加两个 1.11）才得出的结论；行高取网格的 19.15
// 之后，对称居中恰好就是对的。
//
// 横向那一份是读出来的：范例的表没写 tblCellMar，用的是 styles.xml 里
// docDefaults 那一份——上下 0、左右各 0.19 厘米（「表格属性 → 单元格边距」上
// 就是这么显示的，存进 docx 是 108 缇）。
// *数住样式表*（src/styles/presets.typ 的 _table，Word 那张「表格」卡），这里只留默认值的
// 别名给别处 import；排的时候读当前那一份（style），局部 #show: new-styles.with(…) 改得动
#let inset-x = default-styles.figure.table.inset.x


// 续排那一页「表N-N（续表）」那一行的上下位置，*与单元格同一条规则算出来*：
// 单倍行盒在网格行里居中。
//
// 实测本科范例第 14 页（trace 读线，stext 读基线）：
//
//   标注基线 121.28（五号、右对齐）   顶线 127.05–128.55，中心 127.80
//   版心顶 107.75 → 标注基线 13.53      标注基线 → 顶线中心 6.52
//
// 模型算：
//
//   上 = (19.15 − 13.617) / 2 + 上升部 10.66 = 13.43   （差 0.10）
//   下 = 行深 2.96 + 下半格 2.77 + 半条顶线 0.75 = 6.48（差 0.04）
//
// docx 那一段写着 w:jc="right"、sz=21、*没有 w:spacing*——单倍，与表内
// 单元格一样。博士范例第 16 页量到 13.55 / 6.45，两份对得上。
//
// 先前这里存的是 13.53 / 6.52 两个实测数。
// 三线表的三条线。*读自范例的 docx，不是从 PDF 上量的*。
//
// 指南只说「不加左右边线」「建议采用国际通行的三线表」，一个数都没给。范例里
// 那张表的 tblPr 是全框 sz=4，三条线由*单元格级*的 w:tcBorders 逐格盖掉：
//
//   表头行  top=single sz=12   bottom=single sz=8   left/right=nil
//   数据首行 top=single sz=8    其余 nil
//   末行    bottom=single sz=12  其余 nil
//   中间各行 四边全 nil
//
// w:sz 的单位是八分之一磅，sz=12 / 8 就是 Word「边框和底纹」里那个宽度下拉框上的
// *1½ 磅*与*1 磅*——写界面上的数，换算是我们内部的事。
// （更早那组 1 / 0.5 / 1 是按出版界通行值拍的，后来量了 PDF，现在是读出来的。）

// 续排那一页「表N-N（续表）」那一行的上下位置，*与单元格同一条规则算出来*：
// 单倍行盒在网格行里居中。
//
// 实测本科范例第 14 页（trace 读线，stext 读基线）：
//
//   标注基线 121.28（五号、右对齐）   顶线 127.05–128.55，中心 127.80
//   版心顶 107.75 → 标注基线 13.53      标注基线 → 顶线中心 6.52
//
// 模型算：
//
//   上 = (19.15 − 13.617) / 2 + 上升部 10.66 = 13.43   （差 0.10）
//   下 = 行深 2.96 + 下半格 2.77 + 半条顶线 0.75 = 6.48（差 0.04）
//
// docx 那一段写着 w:jc="right"、sz=21、*没有 w:spacing*——单倍，与表内
// 单元格一样。博士范例第 16 页量到 13.55 / 6.45，两份对得上。
//
// 先前这里存的是 13.53 / 6.52 两个实测数。
// 三线表的三条线。*读自范例的 docx，不是从 PDF 上量的*。
//
// 指南只说「不加左右边线」「建议采用国际通行的三线表」，一个数都没给。范例里
// 那张表的 tblPr 是全框 sz=4，三条线由*单元格级*的 w:tcBorders 逐格盖掉：
//
//   表头行  top=single sz=12   bottom=single sz=8   left/right=nil
//   数据首行 top=single sz=8    其余 nil
//   末行    bottom=single sz=12  其余 nil
//   中间各行 四边全 nil
//
// w:sz 的单位是八分之一磅，sz=12 / 8 就是 Word「边框和底纹」里那个宽度下拉框上的
// *1½ 磅*与*1 磅*——写界面上的数，换算是我们内部的事。
// （更早那组 1 / 0.5 / 1 是按出版界通行值拍的，后来量了 PDF，现在是读出来的。）
#let strokes = default-styles.figure.table.stroke

// 当前生效的表格那一档样式（文档级并过局部的），inset 折成 (x:, y:) 字典。*要在 context 里调*。
// 单元格里的段落属性（字号、行距、贴格、缩进）从这一份取，字号由 show table: set text(size:)
// 那条 show-set 给、用户就地 set 的压过它，所以排格子时字号读样式链、不读这里

// 当前生效的表格那一档样式（文档级并过局部的），inset 折成 (x:, y:) 字典。*要在 context 里调*。
// 单元格里的段落属性（字号、行距、贴格、缩进）从这一份取，字号由 show table: set text(size:)
// 那条 show-set 给、用户就地 set 的压过它，所以排格子时字号读样式链、不读这里
#let style() = {
  let ts = sheet.current-styles().figure.table
  let inset = ts.inset
  let inset = if type(inset) == length { (x: inset, y: inset) } else {
    (x: inset.at("x", default: 0pt), y: inset.at("y", default: 0pt))
  }
  ts + (inset: inset)
}
// 格子那一档的段落样式：表格那一档去掉不是段属性的键，字号按样式链上当前的

// 格子那一档的段落样式：表格那一档去掉不是段属性的键，字号按样式链上当前的
#let cell-style(ts, size) = {
  let st = ts
  for k in ("above", "gap", "below", "inset", "stroke") { let _ = st.remove(k, default: none) }
  st + (size: size)
}

// 「图」「表」两种题注的编号计数器

// 伪代码的 figure 是重造的（见 caption-rules 里那条 show figure），用户写的那个 kind 还是
// image 的*原件*仍然在：可查、记数、进 outline（实测被换掉的元素照样在 query 里，图的
// 计数器也被它步进了一格——原件后面那张图印成「图1-3」、插图索引里多一条「图1-2 算法」）。
// 所以凡是按 kind 查图的地方都要把原件剔掉，计数器由重造那条规则退回去

// Typst 自己的默认值。*用来分辨「用户显式写的」与「没写」*——fields()
// 两者都给得出来，只有拿默认值比对能分开。见 show table 那一段。
// Typst 没被碰过时 inset 的样子。stroke 那一档比不了相等，判结构，见 show table
#let typst-default-inset = 0% + 5pt

// 重造过的表自带这个记号，见下面 show table 那一段的说明

// 重造过的表自带这个记号，见下面 show table 那一段的说明
#let built-mark = metadata((iota-table-built: true))

#let built(c) = {
  if type(c) != content { return false }
  if c.func() == metadata {
    return type(c.value) == dictionary and "iota-table-built" in c.value
  }
  if c.has("children") {
    for k in c.children { if built(k) { return true } }
  }
  if c.has("body") { return built(c.body) }
  false
}

// 注入到表头里的那一格：起始页什么也不排，续排的页上排「表N-N（续表）」。
//
// 找「这是哪个表」的办法与页眉找「这是哪一章」同一套：查出全部表，取起始页
// 不晚于本页的最后一个。用 <= 而不是 <——本页起的表也算。

// 注入到表头里的那一格：起始页什么也不排，续排的页上排「表N-N（续表）」。
//
// 找「这是哪个表」的办法与页眉找「这是哪一章」同一套：查出全部表，取起始页
// 不晚于本页的最后一个。用 <= 而不是 <——本页起的表也算。
#let continued-row(metrics, top-rule, by-chapter) = context {
  let page-now = here().page()
  // *这一行属于哪张表：按文档顺序取「在我之前最后起排的」那一张。*
  //
  // 注进去的这一行看不见外面的 figure，只能自己找。先前按页码判，两个方向各
  // 错一次：收「≤ 本页」时，续排页上又起了新表就取到新表、判成起始页，标注丢
  // 掉；收「< 本页」时，跨页表*之后*的任何一张表都会取到那张跨页表，白多
  // 一条标注。页码分不开同页的先后，位置分得开——这一行在自己那张表里面，
  // 所以在它之前起排的最后一个 figure 必是自家的。
  let me = here().position()
  let owners = query(figure.where(kind: table)).filter(g => {
    let at = g.location().position()
    at.page < me.page or (at.page == me.page and at.y <= me.y)
  })
  if owners.len() == 0 { return }
  let f = owners.last()
  // 起始页不排——那一页有正经的表题。手工拆表的后半是例外：它本页起排，
  // 而题里写着 #continued()，那正是「这一张是上一张的续」的意思
  let mark = find-continued(f.caption.body)
  if f.location().page() == page-now and mark == none { return }
  if f.numbering == none { return }
  let lang = doc-lang.get()
  // 接的是哪一张表的号。
  //
  // *跨页接排*：f 就是那张表本身，直接取它的号。
  //
  // *手工拆表*：f 是后半那个 figure，Typst 已经替它记过一次数，于是
  //   一、号要取*它接的那一张*——写了 #continued(<tab:one>) 就按标签找，
  //       没写就接紧挨着的前一张（拆表就是把相邻的一张拆成两半）；
  //   二、计数器要退回去，否则后面那个真表跳号（指南 2.12：续表不占新号）。
  let src = if mark == none {
    f
  } else if mark.target != none {
    query(mark.target).first()
  } else {
    let before = query(figure.where(kind: table)).filter(
      g => g.location().position().page < f.location().position().page
        or (g.location().position().page == f.location().position().page
            and g.location().position().y < f.location().position().y),
    )
    if before.len() == 0 { return }
    before.last()
  }
  // *只在那张表*起排*的那一页退。* 这一行住在表头里，表头每页重排一次，
  // 这个 context 就每页跑一次（文件里别处也记着「实测重复出来的表头里 context 会
  // 按页重算」）——不加这一条，手工拆开的后半张表跨几页就退几格：实测续表占两页时
  // 它后面那张表印成「表1-1」与第一张*重号*（不报错、不告警），表再长
  // （60 行起）直接 error: number must be at least zero 加 did not converge。
  if mark != none and f.location().page() == page-now {
    counter(figure.where(kind: table)).update(v => v - 1)
  }
  // *章号要按「被接的那张表」所在的位置取。* figure 的编号闭包里写的是
  // counter(heading).get()——读的是*排它的那个位置*的章号。正常题注就在
  // 图表旁边，没差；续排标注可能排到下一章去（长表跨章），那时 get() 读到的是
  // 下一章的号，排出来就成了「表6-1（续表）」。所以这里不调那个闭包，自己按
  // src 的位置取章号与序号。
  let seq = counter(figure.where(kind: table)).at(src.location())
  let num = if by-chapter {
    _numbering.chapter-numbered(src.location(), seq)
  } else {
    numbering("1", ..seq)
  }
  // *上面那点空当由行盒自己出。* 这一格的内边距是清零的（起始页那一格是空的，
  // 留着会白占一行高），先前用 v(半个行间) 补出来；格里改成贴网格之后，行盒本身就是
  // 一个网格行、字面在里面居中，那半个行间已经在盒子里，再补就多一份。
  //
  // *标注不参与列宽计算。* 它注在一格 colspan 满行的单元格里，照直排的话
  // 内容宽度会挤进列宽——而 Typst 把多出来的宽度*全给最后一列*，于是表被
  // 单侧撑开，各列的文字虽然各自居中，整张表看着就歪了（实测两列小表：第一列
  // 21.3、第二列 47.8）。
  //
  // *标注不参与列宽计算。* 主表的列宽由数据定，续表那一行不该把它撑开
  // ——同一张表在起始页和续排页会宽窄不一，看着就不是一张表了。
  //
  // 所以套一个零宽盒子（外层宽 0 不给列提最低要求），里面按实测宽度定宽，再自己
  // 挪到位。内层必须定宽：外层可用宽度是 0，不定宽文字会被压得逐字换行（实测
  // 「表」「1-1」「（续」「表）」各占一行）。
  //
  // *放得下贴右缘，放不下居中*。
  //
  // *Typst 的对齐按盒子里*内容*的宽度算，不是按声明的 0*——所以整表
  // 那条 align: center 已经把内容摆在格子中央了（内容心 ＝ 格心）。于是：
  //
  //   w > 格宽   dx = 0              已经居中，两边各溢出一半，比一头长出去好看
  //   w ≤ 格宽   dx = (格宽 − w)/2   往右推半个空当，右缘落到表的右缘上
  //                                 （指南 2.12「表右上角注明编号」）
  //
  // 合起来就是 max(0, (格宽 − w)/2)。
  //
  // 试过两条别的路：塞进一格 colspan 让它照直占宽，Typst 把多出来的宽度全给最后
  // 一列，表被单侧撑开（两列小表 21.3 / 47.8）；改成每列各摊一份 w/n 撑得是匀了，
  // 可主表并没有这回事，同一张表两页宽窄不同。width: 100% 更不行——自动列里那种
  // 百分比按整个版心算，第一列被撑到 90.45。
  // 这张表显式写了名（figure(table, supplement: [清单])）就照它，标注用光的「（续）」，
  // 与题注那一支同一条（见 refs.given-supplement）
  let given = refs.given-supplement(src.fields(), table, doc-lang.get())
  let mark-text = {
    let name = if given != auto { given } else { refs.word(lang, "table") }
    // 「（续表）」里的名不带「附」（指南 2.12 的原话就是「（续表）」）；号前面的名带——附录里
    // 数那几档的表叫「附表1」，续排那一行也是「附表1（续表）」，与题注那一支同（caption.typ）
    let mark = refs.continued-mark(lang, name)
    let name = if given != auto { given } else {
      _numbering.appendix-prefix(src.location(), lang, by-chapter: by-chapter) + name
    }
    name + (if lang == "en" { " " }) + num + refs.continued-gap(mark)
    mark
    sym.zws
  }
  context {
    let w = measure(mark-text).width
    layout(size => box(width: 0pt, move(
      dx: calc.max(0pt, (size.width - w) / 2),
      box(width: w, mark-text),
    )))
  }
  // 下面那半条线（Typst 把线画在格边界正中，Word 的线整条在表里）由这一格的
  // 内边距垫，见 show table 里的 mark-cell——先前这儿 v(半条线)，与内边距是同一份，
  // 两处都留就多一半
}

// 「用户自己写过 show figure.caption: set text(size: …) 吗」那个哨兵。
//
// *题注的字号是规范定死的*（五号，两份指南的图题表题那几节），所以挡住
// 原生那条路——可*挡住就必须出声*，静默不生效是最难查的一种。
//
// 难在分不出「用户设过」：text.size 没有 auto 那样的哨兵，用户写 12pt 时读回来
// 的 12 与正文的 12 一模一样（实测），比值比不出来。所以*自己往样式链上
// 插一个没人会写的字号*：文档级先把题注设成它，用户那条 show 规则定义在我们
// 之后（#show: iota-hit 把整份文档裹在里面）会把它盖掉——读回来不是它，就说明
// 有人设过。与 figure.numbering 那个闭包哨兵同一个路子。
//
// *印不出来*：下面那条 show figure.caption 把题注整个重排，字号从
// styles.figure.caption 现取。

// *单元格是单倍行距，不是题注那一档的 1.25。* 六张三线表（本科范例三张、
// 博士范例三张）的单元格段落一个 w:line 都没写，也就是单倍。
//
// *而且对齐到文档网格：格里*每一行*都占一个网格行。* 那六张表的单元格
// 段落也一个 snapToGrid 都没写——Word 的默认就是对齐，所以格内折行与整行同待遇。
// 逐条量过（本科范例表6-1，那一节的网格是 383 ＝ 19.15）：数据行之间 19.08–19.20，
// 表头那一格自己折的三行（「流量修正值」／「M (m³/s)」／「×10⁻⁴」）也是 19.08、
// 19.20，与数据行一模一样。
//
// *西文行不例外。* 那三行里第二行「M (m³/s) lgΔP lg M」通篇没有汉字，照样
// 是一个网格行。中文档里「纯西文段走自然行高」那一条（src/styles/body.typ 的
// show par）不适用于格里——那一条的出处（英文摘要、英文题注、英文版表格）在范例里
// 每一处都写着 snapToGrid=0 或非单倍行距，是段落上的显式设定，不是 Word 按脚本判的。
// 自造探针核实过：拿范例 d-stem.docx 本身追加一页（同一节、同一份 Normal），Word
// 导出实测正文汉字 19.44/19.68、正文纯西文 19.44/19.68、格内汉字 19.68、格内纯西文
// 19.68、混排 19.68——都是一个网格行。
//
// *范例里 19.15 那个数不跟*：它是那一节的 w:docGrid linePitch=383，两份范例
// 各十一节里只有放这张表的那一节是 383，其余 391（19.55）。要跟的是「每行一个
// 网格行」这条规矩，落到我们的网格上就是 19.55。
//
// *行距按网格开关分两档。* 贴网格那一档设*单倍*——范例那几格的
// pPr 里一个 w:line 都没写，走 Normal 的单倍，再由网格撑成一个网格行；倍数
// 在贴网格时乘的是*网格行*（写 1.25 排出来是 24.44，不是 19.55）。
//
// *网格不启用的那一档就差在这儿*：深圳本科那两份报告的 docGrid 没有
// w:type、单元格还显式写着 <w:snapToGrid w:val="0"/>，没有网格行可贴，行盒
// 只能按行距算——原件那几格写的正是 <w:spacing w:line="300"/> ＝ 1.25 倍，
// 与题注那一档同数，所以跟着 style 走（用户改 styles.figure.caption 也一并跟上）。
// 写死单倍的话那一档会塌成 13.62。
//
// *以上是标定的记录；数现在住在 styles.figure.table（src/styles/presets.typ 的 _table）*：
// 单倍贴格是那一档的默认，网格不启用的那几档在 variant-styles 里写 1.25。排格子时读
// 当前那一份（three-line.style），文档级 iota-hit(styles:) 与局部 #show: new-styles.with(…) 都改得动
// *纵向内边距只有线的那一半，而且只在挨着线的那一边。* 贴网格之后行盒自己就是
// 一个网格行、自然行盒在里面居中（见 src/paragraph/linebox.typ 的 _ascent-of），垫的活儿
// 都在行盒里；剩下的是 *Word 的线占自己的厚度*：格子的内容框从线的内沿起排，
// Typst 把线画在格子边界的正中——所以挨着线的那一边各垫半条线，不挨线的边是 0。
// 三条线各自算：顶线垫在首行的上边、表头线垫在表头行的下边与首个数据行的上边、
// 底线垫在末行的下边；顶线与底线探出表外的那一半由 pad 补（见下面 built）。
//
// 两份 Word 排的表都对得上：
//
//   本科范例 p15（贴网格 383 ＝ 19.15，线 1.5 / 1 / 1.5）：表题基线 → 顶线心 7.22
//   ＝ 五号 1.25 倍的行深 6.44 ＋ 0.75；三行的表头 58.80 ＝ 0.75 ＋ 3 × 19.15 ＋ 0.5；
//   末行基线 → 底线心 6.44 ＝ 格内居中的下半 5.80 ＋ 0.75（p16）
//   深圳本科中期表 2-1（不贴网格，三条都 1.5）：表头线心 → 首行基线 12.96
//   ＝ 0.75 ＋ 上升部 12.1；末行基线 → 底线心 8.16 ＝ 行深 7.35 ＋ 0.75
//
// 先前上边 +半条、下边 −半条，行高不变、线心落在内容框顶上：一张表比 Word 矮
// 「三条线之和」（2.5～3pt），后面的标题跟着高。
//
// *用户写的 inset 也当 Word 的边距收*（元素上的 table(inset:)、或 show table: set
// table(inset:)）：他抄的是表格属性对话框上的数，从线内沿量，挨线的半条线照补。先前
// 原样用，比 Word 少半条线
// 边距收长度或字典；fields() 里用户写的 (x: 1cm) 已被 Typst 摊成 left / right / top / bottom
// （实测），这几种拼法都认。*左右一份、上下一份*：Word 的边距就这两栏
#let cell-inset(margin, strokes, off, header-rows, last) = {
  let side(keys) = if type(margin) == length { margin } else {
    let hit = keys.find(k => k in margin)
    if hit == none { margin.at("rest", default: 0pt) } else { margin.at(hit) }
  }
  let mx = side(("x", "left", "right"))
  let my = side(("y", "top", "bottom"))
  (x, y) => (
    x: mx,
    top: my + (if y == off { strokes.top / 2 }
      else if header-rows > 0 and y == off + header-rows { strokes.header / 2 }
      else { 0pt }),
    bottom: my + (if off <= y and y < off + header-rows { strokes.header / 2 }
      else if y == last { strokes.bottom / 2 }
      else { 0pt }),
  )
}

// ── 接到 table 上：三线表重建、比版心宽的居中、续排页的「（续表）」 ────────────
// 从 caption.typ 的 caption-rules 搬来，src/iota-hit.typ 紧接着 caption-rules 装（次序不变）。
// 参数与 caption-rules 同名同义：header-rows 表头占几行，by-chapter 号按不按章（格里的字号
// 从样式链读，题注那一档的 style 用不着）
#let table-rules(by-chapter: true, header-rows: 1, doc) = {
  // 三线表，外加*续排那一页自动补上「（续表）」*。
  //
  // 顶线与表头线走 stroke 闭包；*底线是追加在末尾的 table.hline*——那个闭包只对
  // 真实存在的格子调用（y 取 0..行数−1），拿不到总行数，实测让它对 y == 行数
  // 返回线宽什么也不画；不带 y 的 hline 落在它所在的位置，摆在最后一格之后就是
  // 表底，长表跨页也只出现在末页。*先前是在表外面包一个 block 画下边*：块在流里
  // 取版心宽，表比版心宽（深圳本科英文中期原件那张表列宽加起来 15.11cm，版心
  // 15.0cm）时底线就比顶线短一截。表头下那条画成*表头行的下边*而不是首个数据行的
  // 上边：跨页时 Typst 重复 table.header，重复出来的那份 y 仍是 0，画上边线跟
  // 得上；而首个数据行留在前一页，画它的上边线在续页就没了（实测续页只有顶线
  // 与底线，缺那条 0.5）。
  //
  // *比版心宽的表居中*，照 Word：表单里那张表 w:jc="center"，排出来两边各探出
  // 1.5（83.52–511.68 对版心 85.05–510.23）；Typst 把超宽的块顶在左边、全探到右边。
  // 用负的左右 pad 把容器撑到表那么宽，表就落在正中。列宽有 auto／fr 的表撑不
  // 过版心，量出来不比版心宽，这一支不走。
  //
  // *「（续表）」这一行是往 table.header 里注入的。* 指南 2.12 要求转页时
  // 「表右上角注明编号，编号后加『（续表）』，并重复表头」——重复表头 Typst 自己
  // 会做，那一行标注它没有钩子。办法是插一格跨列、右对齐、无边线的内容，里面
  // 放一个 context：*实测重复出来的表头里 context 会按页重算*（同一个探针
  // 在第 1/2/3 页分别报 1/2/3），所以它能自己判断「这一页不是表的起始页」。
  //
  // *这是全项目唯一一处重造用户的元素。* 别处的 show 规则都只设属性。
  // 重造要防递归：新建的 table 会再次命中这条规则，而内层写一条 identity 的
  // show 规则*拦不住*（实测 maximum show rule depth exceeded）。改成让它
  // *自识别*——注入的那一格里埋一个 metadata，再进来看见就原样放行。
  //
  // *用户显式写的 stroke / inset 要留住。* 重建把它们一并丢弃过——实测
  // 写了 inset 也毫无效果。fields() 分不出「用户写的」与「没写」，只能拿 Typst
  // 的默认值比对：没人会去显式写一个与默认一模一样的值。
  //
  // *stroke 不能用相等比。* 实测默认那一个与 1pt + black *既不 ==
  // 也不 repr 相同*，虽然打印出来一模一样。能分的是结构：没被碰过的 stroke，
  // thickness 与 paint 都是 auto；用户写 0.4pt 的那个 thickness 就是 0.4pt。
  show table: it => context {
    if built(it) { return it }
    let layout = _layout.current-layout()
    // 格里的字号读样式链：lib.typ 那句 show table: set text(size:) 给的默认（表格样式的
    // 五号），用户就地 show table: set text(size: …) 压过它。字体同理，这里不 set
    let ts = style()
    let cell = cell-style(ts, text.size)
    let strokes = ts.stroke
    let m = linebox.metrics(cell, layout: layout)
    let f = it.fields()
    let kids = f.remove("children")
    // fields() 给的是「显式值或 Typst 默认值」，不含 set 规则的值——实测重建后
    // inset 回到 5pt（Typst 的默认）而不是我们 set 的 1.11，..f 展开时会盖过
    // 下面的 set。所以这两项先摘出来，判过是不是默认再决定用谁的。
    let raw-stroke = f.remove("stroke", default: none)
    let raw-inset = f.remove("inset", default: none)
    let raw-align = f.remove("align", default: auto)
    let stroke-untouched = (
      type(raw-stroke) == stroke
        and raw-stroke.thickness == auto
        and raw-stroke.paint == auto
    )
    // 边距三处来源：元素上写的、show table: set table(inset:) 写的（读样式链）、表格样式
    // 里的，前面的压后面的，都当 Word 的边距
    let inset-untouched = raw-inset == typst-default-inset
    let margin = if not inset-untouched { raw-inset }
      else if table.inset != typst-default-inset { table.inset }
      else { ts.inset }
    // *不写 columns 的表列数是 1。* 那个字段*总是在*，没写时是空数组
    // ——default: 1 永远走不到，空数组的 len() 是 0，注入格 colspan: 0 当场报
    // 「number must be positive」，而 #table([甲], [乙]) 在 Typst 原生是合法的单列表
    let cols = f.at("columns", default: 1)
    let n = if type(cols) == int { calc.max(cols, 1) } else if type(cols) == array {
      calc.max(cols.len(), 1)
    } else { 1 }
    let has-header = kids.any(k => k.func() == table.header)
    // 注入的那一格。*记号要在 context 外面*——built 走的是 children /
    // body，钻不进 context 元素里，塞进去就自识别不出来，当场无限递归。
    // *内边距要清零*：起始页那一格是空的，留着内边距会让它照样占一行高
    // ——实测同一份长表从 2 页涨到 4 页，起始页表头上方还多出一道空隙。
    // 续排页要的那点间距由内容自己发（见 continued-row 的 v()）。
    // *下边垫顶线的那一半*：顶线画在这一格与首行的边界正中，Word 里线整条在表里、
    // 标注段落的底就是线的上沿（本科范例 p16：标注基线 → 顶线心 6.52 ＝ 网格行里
    // 居中的下半 5.80 ＋ 0.75）。起始页这一格是空的，垫的这半条就是顶线探出表外的那一半
    let mark-cell = table.cell(
      colspan: n, stroke: none, inset: (bottom: strokes.top / 2, rest: 0pt),
      built-mark + continued-row(
        m, strokes.top, by-chapter,
      ),
    )
    // *没写 table.header 的表也注入一个*，里面只装那一格。两个理由：
    //
    // 一、指南 2.12 说转页时「表右上角注明编号，编号后加『（续表）』，并重复表
    // 头」——前半句*不以有没有表头为条件*，没有表头的长表转页照样要标。
    //
    // 二、这是*递归的出口*。重建出来的表靠注入格里的 built-mark 自识别，
    // 先前没有表头就什么都不注入，重建出来的表再次命中这条规则——*一张不带
    // table.header 的表根本编译不了*（maximum show rule depth exceeded）。
    let kids = if not has-header {
      (table.header(mark-cell), ..kids)
    } else {
      kids.map(k => if k.func() != table.header { k } else {
        // *repeat 与 level 要一起搬过去。* 只搬 children 的话
        // table.header(repeat: false) 被静默丢掉——实测 60 行的长表跨三页，
        // 写了 repeat: false 表头照样每页重复。别处（figure.caption.separator、
        // figure.numbering）遇到没法兑现的写法是当场 panic，这一处不该一声不响
        table.header(
          mark-cell, ..k.fields().children,
          repeat: k.at("repeat", default: true),
          level: k.at("level", default: 1),
        )
      })
    }
    // 注入那一行占了 y == 0，三条线的位置整体后移一格
    let off = 1
    // *注入那一行也得给个高*，不然它跟着吃用户写的 rows:——`rows: 100pt`
    // 的表在表头之上凭空多出 100pt（实测题注基线到顶线 106.35，该是 6.35；
    // `rows: 30pt` 那份是 36.36）。
    //
    // track 的写法是「给的不够就重复最后一个」（实测 rows: (0pt, 30pt) 排五行
    // 得 0/30/30/30/30），所以在前面补*一格*就正好，后面几行照旧。
    //
    // *补的那一格写 auto，不写 0pt。* 它两页上的高本来就该不同：首页那一格是空的，
    // auto 给的就是 0（`rows: 100pt` 那个毛病不会回来，实测题注到表头 21.5）；续页
    // 标注一印，auto 给的是标注的自然高。先前写死 0pt，续页那一页整个错位——标注
    // 与表头只差 0.7（该差 21.0，字叠在一起）、顶线被顶到版心顶 107.75（该在 128.05），
    // 与页眉那条双线（97.72／100.72）之间只剩 7pt，看着就是表框贴着页眉。
    //
    // *没写 rows 时 fields() 交回的是空数组，不是 auto*（实测；写了
    // rows: 30pt 交回的也已经是数组 (30pt,)）。空的就别动——那一档整张表本来就是
    // 每行按内容自然高，注入的那一格也一样，补不补一个 auto 都一样
    let f = {
      let rs = f.at("rows", default: ())
      if type(rs) != array or rs.len() == 0 { f } else { f + (rows: (auto, ..rs)) }
    }
    // 表头线只有*真有表头*时才画：注入的那一格不是表头，它下面没有线
    let header-rows = if has-header { header-rows } else { 0 }
    // *末行是第几行*：底线那半条垫在它的下边。行数 ＝ 各格占的格位（colspan × rowspan）
    // 之和除以列数——表排得满时正好整除；线、注入的那一格不算
    let slots(k) = if k.func() == table.cell {
      k.at("colspan", default: 1) * k.at("rowspan", default: 1)
    } else if k.func() == table.header {
      k.fields().children.filter(c => c != mark-cell).map(slots).sum(default: 0)
    } else if k.func() in (table.hline, table.vline) { 0 } else { 1 }
    let last = off + calc.ceil(kids.map(slots).sum(default: 0) / n) - 1
    let inset = cell-inset(margin, strokes, off, header-rows, last)
    // 底线只在*我们自己画三线*时才补。用户给了 stroke 就整表听他的，
    // 再补一条会在表底多出一根线
    let kids = if stroke-untouched { kids + (table.hline(stroke: strokes.bottom),) } else { kids }
    let built = {
      // *字号、行盒与内边距都要在这里设。* 重建出来的表是新元素，外面那两条
      // show table: set … 规则罩不到它——实测重建后字号回到正文的 12、内边距回到
      // Typst 默认的 5pt，行步进涨到 29.45，长表页数翻倍。
      //
      // *罩的是 style-rules.rules 而不是只设字号*：行高得按模型的行盒来，只设字号
      // 的话走 Typst 自己的字体度量（实测五号内容盒 9.07，模型是 13.617），
      // 上面按 m.box 算出来的居中内边距就白算了。
      show: style-rules.rules.with(cell, layout: layout)
      set table(
        // *单元格内容居中。* 范例那几张表的数据格段落都写着
        // <w:jc w:val="center"/>——同一格里「供气压力」起笔 93.30、「Ps (MPa)」
        // 95.05，两行不齐正是居中的痕迹。Typst 默认靠左，续表标注把列撑宽之后
        // 尤其显眼（文字缩在左边，表框却伸到右边）。用户自己写了 align 就听他的。
        align: if raw-align == auto { center } else { raw-align },
        inset: inset,
        stroke: if not stroke-untouched { raw-stroke } else { (x, y) => (
          top: if y == off { strokes.top } else { none },
          bottom: if off <= y and y < header-rows + off { strokes.header } else { none },
        ) },
      )
      table(..f, ..kids)
    }
    // *底线探出表外的那一半*：Typst 把线画在表的下边界正中，Word 的线整条都在表里，
    // 底线的下沿才是下一段的起点（顶线的那一半垫在注入的那一格里，见 mark-cell）。
    // 只在我们自己画三线时垫；用户给了 stroke 就不知道线多粗
    let built = if stroke-untouched { pad(bottom: strokes.bottom / 2, built) } else { built }
    // 比版心宽就居中（见抬头）；量的是重建出来的整张表
    let over = measure(built).width - layout.text-width
    if over > 0.05pt { pad(x: -over / 2, built) } else { built }
  }
  doc
}
