// 三线表：线、内边距、单元格里的段落、续排页上的「表N-N（续表）」那一行。

#import "../../heading/numbering.typ" as _numbering
#import "../../styles/sheet.typ" as sheet
#import "../continued.typ": find-continued
#import "../../terms/lang.typ": doc-lang
#import "../../styles/presets.typ": default-styles
#import "../../references/refs.typ" as refs

// 三线表的数据行：*行高就是文档网格的行距，行盒在行里垂直居中*。
//
// 实测本科范例第 12 页那张表（trace 读三条线，stext 读基线）：
//
//   顶线 327.35–328.85（1.5）  表头下 386.12–387.12（1.0）  底线 521.40–522.90（1.5）
//   数据基线 400.62 … 515.65，七行六步共 115.03，一步 19.17
//   行高 = (521.40 − 387.12) / 7 = 19.18
//   首基线距行顶 = 400.62 − 387.12 = 13.50
//
// 那一节（第 4～6 章，拷贝进来的 FLUENT）的 docGrid 是 linePitch=383，也就是
// 19.15 磅——步进与行高都是它。而 13.50 由模型算得出来：五号行盒 1.296875 × 10.5
// = 13.617 在 19.15 的行里居中，上留 (19.15 − 13.617) / 2 = 2.77，基线 = 2.77 +
// 上升部 10.66 = 13.43，与量到的 13.50 差 0.07。
//
// 所以两个内边距都是 (网格行距 − 行盒高) / 2，*一个常数都不用存*。终稿默认
// 的跨度是 391 缇 ＝ 19.55（见 src/layout/presets.typ），表在正文里排出来的行高就是
// 19.55、首基线距行顶 13.63——范例那张表落在 383 的节里才是 19.15，规则不变。
//
// *先前这里存过 13.98 / 19.24*，还写着一段「为什么不是上下对称」——那是
// 当初把行高当成了 15.84（行盒加两个 1.11）才得出的结论；行高取网格的 19.15
// 之后，对称居中恰好就是对的。
//
// 横向那一份是读出来的：范例的表没写 tblCellMar，用的是 styles.xml 里
// docDefaults 那一份——上下 0、左右各 0.19 厘米（「表格属性 → 单元格边距」上
// 就是这么显示的，存进 docx 是 108 缇）。
// *数住样式表*（src/styles/presets.typ 的 _table，Word 那张「表格」卡），这里只留默认值的
// 别名给别处 import；排的时候读当前那一份（style），局部 #show: new-styles.with(…) 改得动
#let inset-x = default-styles.figure.table.inset.x


// 续排那一页「表N-N（续表）」那一行的上下位置，*与单元格同一条规则算出来*：
// 单倍行盒在网格行里居中。
//
// 实测本科范例第 14 页（trace 读线，stext 读基线）：
//
//   标注基线 121.28（五号、右对齐）   顶线 127.05–128.55，中心 127.80
//   版心顶 107.75 → 标注基线 13.53      标注基线 → 顶线中心 6.52
//
// 模型算：
//
//   上 = (19.15 − 13.617) / 2 + 上升部 10.66 = 13.43   （差 0.10）
//   下 = 行深 2.96 + 下半格 2.77 + 半条顶线 0.75 = 6.48（差 0.04）
//
// docx 那一段写着 w:jc="right"、sz=21、*没有 w:spacing*——单倍，与表内
// 单元格一样。博士范例第 16 页量到 13.55 / 6.45，两份对得上。
//
// 先前这里存的是 13.53 / 6.52 两个实测数。
// 三线表的三条线。*读自范例的 docx，不是从 PDF 上量的*。
//
// 指南只说「不加左右边线」「建议采用国际通行的三线表」，一个数都没给。范例里
// 那张表的 tblPr 是全框 sz=4，三条线由*单元格级*的 w:tcBorders 逐格盖掉：
//
//   表头行  top=single sz=12   bottom=single sz=8   left/right=nil
//   数据首行 top=single sz=8    其余 nil
//   末行    bottom=single sz=12  其余 nil
//   中间各行 四边全 nil
//
// w:sz 的单位是八分之一磅，sz=12 / 8 就是 Word「边框和底纹」里那个宽度下拉框上的
// *1½ 磅*与*1 磅*——写界面上的数，换算是我们内部的事。
// （更早那组 1 / 0.5 / 1 是按出版界通行值拍的，后来量了 PDF，现在是读出来的。）

// 续排那一页「表N-N（续表）」那一行的上下位置，*与单元格同一条规则算出来*：
// 单倍行盒在网格行里居中。
//
// 实测本科范例第 14 页（trace 读线，stext 读基线）：
//
//   标注基线 121.28（五号、右对齐）   顶线 127.05–128.55，中心 127.80
//   版心顶 107.75 → 标注基线 13.53      标注基线 → 顶线中心 6.52
//
// 模型算：
//
//   上 = (19.15 − 13.617) / 2 + 上升部 10.66 = 13.43   （差 0.10）
//   下 = 行深 2.96 + 下半格 2.77 + 半条顶线 0.75 = 6.48（差 0.04）
//
// docx 那一段写着 w:jc="right"、sz=21、*没有 w:spacing*——单倍，与表内
// 单元格一样。博士范例第 16 页量到 13.55 / 6.45，两份对得上。
//
// 先前这里存的是 13.53 / 6.52 两个实测数。
// 三线表的三条线。*读自范例的 docx，不是从 PDF 上量的*。
//
// 指南只说「不加左右边线」「建议采用国际通行的三线表」，一个数都没给。范例里
// 那张表的 tblPr 是全框 sz=4，三条线由*单元格级*的 w:tcBorders 逐格盖掉：
//
//   表头行  top=single sz=12   bottom=single sz=8   left/right=nil
//   数据首行 top=single sz=8    其余 nil
//   末行    bottom=single sz=12  其余 nil
//   中间各行 四边全 nil
//
// w:sz 的单位是八分之一磅，sz=12 / 8 就是 Word「边框和底纹」里那个宽度下拉框上的
// *1½ 磅*与*1 磅*——写界面上的数，换算是我们内部的事。
// （更早那组 1 / 0.5 / 1 是按出版界通行值拍的，后来量了 PDF，现在是读出来的。）
#let strokes = default-styles.figure.table.stroke

// 当前生效的表格那一档样式（文档级并过局部的），inset 折成 (x:, y:) 字典。*要在 context 里调*。
// 单元格里的段落属性（字号、行距、贴格、缩进）从这一份取，字号由 show table: set text(size:)
// 那条 show-set 给、用户就地 set 的压过它，所以排格子时字号读样式链、不读这里

// 当前生效的表格那一档样式（文档级并过局部的），inset 折成 (x:, y:) 字典。*要在 context 里调*。
// 单元格里的段落属性（字号、行距、贴格、缩进）从这一份取，字号由 show table: set text(size:)
// 那条 show-set 给、用户就地 set 的压过它，所以排格子时字号读样式链、不读这里
#let style() = {
  let ts = sheet.current-styles().figure.table
  let inset = ts.inset
  let inset = if type(inset) == length { (x: inset, y: inset) } else {
    (x: inset.at("x", default: 0pt), y: inset.at("y", default: 0pt))
  }
  ts + (inset: inset)
}
// 格子那一档的段落样式：表格那一档去掉不是段属性的键，字号按样式链上当前的

// 格子那一档的段落样式：表格那一档去掉不是段属性的键，字号按样式链上当前的
#let cell-style(ts, size) = {
  let st = ts
  for k in ("above", "gap", "below", "inset", "stroke") { let _ = st.remove(k, default: none) }
  st + (size: size)
}

// 「图」「表」两种题注的编号计数器

// 伪代码的 figure 是重造的（见 caption-rules 里那条 show figure），用户写的那个 kind 还是
// image 的*原件*仍然在：可查、记数、进 outline（实测被换掉的元素照样在 query 里，图的
// 计数器也被它步进了一格——原件后面那张图印成「图1-3」、插图索引里多一条「图1-2 算法」）。
// 所以凡是按 kind 查图的地方都要把原件剔掉，计数器由重造那条规则退回去

// Typst 自己的默认值。*用来分辨「用户显式写的」与「没写」*——fields()
// 两者都给得出来，只有拿默认值比对能分开。见 show table 那一段。
// Typst 没被碰过时 inset 的样子。stroke 那一档比不了相等，判结构，见 show table
#let typst-default-inset = 0% + 5pt

// 重造过的表自带这个记号，见下面 show table 那一段的说明

// 重造过的表自带这个记号，见下面 show table 那一段的说明
#let built-mark = metadata((iota-table-built: true))

#let built(c) = {
  if type(c) != content { return false }
  if c.func() == metadata {
    return type(c.value) == dictionary and "iota-table-built" in c.value
  }
  if c.has("children") {
    for k in c.children { if built(k) { return true } }
  }
  if c.has("body") { return built(c.body) }
  false
}

// 注入到表头里的那一格：起始页什么也不排，续排的页上排「表N-N（续表）」。
//
// 找「这是哪个表」的办法与页眉找「这是哪一章」同一套：查出全部表，取起始页
// 不晚于本页的最后一个。用 <= 而不是 <——本页起的表也算。

// 注入到表头里的那一格：起始页什么也不排，续排的页上排「表N-N（续表）」。
//
// 找「这是哪个表」的办法与页眉找「这是哪一章」同一套：查出全部表，取起始页
// 不晚于本页的最后一个。用 <= 而不是 <——本页起的表也算。
#let continued-row(metrics, top-rule, by-chapter) = context {
  let page-now = here().page()
  // *这一行属于哪张表：按文档顺序取「在我之前最后起排的」那一张。*
  //
  // 注进去的这一行看不见外面的 figure，只能自己找。先前按页码判，两个方向各
  // 错一次：收「≤ 本页」时，续排页上又起了新表就取到新表、判成起始页，标注丢
  // 掉；收「< 本页」时，跨页表*之后*的任何一张表都会取到那张跨页表，白多
  // 一条标注。页码分不开同页的先后，位置分得开——这一行在自己那张表里面，
  // 所以在它之前起排的最后一个 figure 必是自家的。
  let me = here().position()
  let owners = query(figure.where(kind: table)).filter(g => {
    let at = g.location().position()
    at.page < me.page or (at.page == me.page and at.y <= me.y)
  })
  if owners.len() == 0 { return }
  let f = owners.last()
  // 起始页不排——那一页有正经的表题。手工拆表的后半是例外：它本页起排，
  // 而题里写着 #continued()，那正是「这一张是上一张的续」的意思
  let mark = find-continued(f.caption.body)
  if f.location().page() == page-now and mark == none { return }
  if f.numbering == none { return }
  let lang = doc-lang.get()
  // 接的是哪一张表的号。
  //
  // *跨页接排*：f 就是那张表本身，直接取它的号。
  //
  // *手工拆表*：f 是后半那个 figure，Typst 已经替它记过一次数，于是
  //   一、号要取*它接的那一张*——写了 #continued(<tab:one>) 就按标签找，
  //       没写就接紧挨着的前一张（拆表就是把相邻的一张拆成两半）；
  //   二、计数器要退回去，否则后面那个真表跳号（指南 2.12：续表不占新号）。
  let src = if mark == none {
    f
  } else if mark.target != none {
    query(mark.target).first()
  } else {
    let before = query(figure.where(kind: table)).filter(
      g => g.location().position().page < f.location().position().page
        or (g.location().position().page == f.location().position().page
            and g.location().position().y < f.location().position().y),
    )
    if before.len() == 0 { return }
    before.last()
  }
  // *只在那张表*起排*的那一页退。* 这一行住在表头里，表头每页重排一次，
  // 这个 context 就每页跑一次（文件里别处也记着「实测重复出来的表头里 context 会
  // 按页重算」）——不加这一条，手工拆开的后半张表跨几页就退几格：实测续表占两页时
  // 它后面那张表印成「表1-1」与第一张*重号*（不报错、不告警），表再长
  // （60 行起）直接 error: number must be at least zero 加 did not converge。
  if mark != none and f.location().page() == page-now {
    counter(figure.where(kind: table)).update(v => v - 1)
  }
  // *章号要按「被接的那张表」所在的位置取。* figure 的编号闭包里写的是
  // counter(heading).get()——读的是*排它的那个位置*的章号。正常题注就在
  // 图表旁边，没差；续排标注可能排到下一章去（长表跨章），那时 get() 读到的是
  // 下一章的号，排出来就成了「表6-1（续表）」。所以这里不调那个闭包，自己按
  // src 的位置取章号与序号。
  let seq = counter(figure.where(kind: table)).at(src.location())
  let num = if by-chapter {
    _numbering.chapter-numbered(src.location(), seq)
  } else {
    numbering("1", ..seq)
  }
  // *上面那点空当由行盒自己出。* 这一格的内边距是清零的（起始页那一格是空的，
  // 留着会白占一行高），先前用 v(半个行间) 补出来；格里改成贴网格之后，行盒本身就是
  // 一个网格行、字面在里面居中，那半个行间已经在盒子里，再补就多一份。
  //
  // *标注不参与列宽计算。* 它注在一格 colspan 满行的单元格里，照直排的话
  // 内容宽度会挤进列宽——而 Typst 把多出来的宽度*全给最后一列*，于是表被
  // 单侧撑开，各列的文字虽然各自居中，整张表看着就歪了（实测两列小表：第一列
  // 21.3、第二列 47.8）。
  //
  // *标注不参与列宽计算。* 主表的列宽由数据定，续表那一行不该把它撑开
  // ——同一张表在起始页和续排页会宽窄不一，看着就不是一张表了。
  //
  // 所以套一个零宽盒子（外层宽 0 不给列提最低要求），里面按实测宽度定宽，再自己
  // 挪到位。内层必须定宽：外层可用宽度是 0，不定宽文字会被压得逐字换行（实测
  // 「表」「1-1」「（续」「表）」各占一行）。
  //
  // *放得下贴右缘，放不下居中*。
  //
  // *Typst 的对齐按盒子里*内容*的宽度算，不是按声明的 0*——所以整表
  // 那条 align: center 已经把内容摆在格子中央了（内容心 ＝ 格心）。于是：
  //
  //   w > 格宽   dx = 0              已经居中，两边各溢出一半，比一头长出去好看
  //   w ≤ 格宽   dx = (格宽 − w)/2   往右推半个空当，右缘落到表的右缘上
  //                                 （指南 2.12「表右上角注明编号」）
  //
  // 合起来就是 max(0, (格宽 − w)/2)。
  //
  // 试过两条别的路：塞进一格 colspan 让它照直占宽，Typst 把多出来的宽度全给最后
  // 一列，表被单侧撑开（两列小表 21.3 / 47.8）；改成每列各摊一份 w/n 撑得是匀了，
  // 可主表并没有这回事，同一张表两页宽窄不同。width: 100% 更不行——自动列里那种
  // 百分比按整个版心算，第一列被撑到 90.45。
  // 这张表显式写了名（figure(table, supplement: [清单])）就照它，标注用光的「（续）」，
  // 与题注那一支同一条（见 refs.given-supplement）
  let given = refs.given-supplement(src.fields(), table, doc-lang.get())
  let mark-text = {
    let name = if given != auto { given } else { refs.word(lang, "table") }
    let mark = refs.continued-mark(lang, name)
    name + (if lang == "en" { " " }) + num + refs.continued-gap(mark)
    mark
    sym.zws
  }
  context {
    let w = measure(mark-text).width
    layout(size => box(width: 0pt, move(
      dx: calc.max(0pt, (size.width - w) / 2),
      box(width: w, mark-text),
    )))
  }
  // 下面那半条线（Typst 把线画在格边界正中，Word 的线整条在表里）由这一格的
  // 内边距垫，见 show table 里的 mark-cell——先前这儿 v(半条线)，与内边距是同一份，
  // 两处都留就多一半
}

// 「用户自己写过 show figure.caption: set text(size: …) 吗」那个哨兵。
//
// *题注的字号是规范定死的*（五号，两份指南的图题表题那几节），所以挡住
// 原生那条路——可*挡住就必须出声*，静默不生效是最难查的一种。
//
// 难在分不出「用户设过」：text.size 没有 auto 那样的哨兵，用户写 12pt 时读回来
// 的 12 与正文的 12 一模一样（实测），比值比不出来。所以*自己往样式链上
// 插一个没人会写的字号*：文档级先把题注设成它，用户那条 show 规则定义在我们
// 之后（#show: iota-hit 把整份文档裹在里面）会把它盖掉——读回来不是它，就说明
// 有人设过。与 figure.numbering 那个闭包哨兵同一个路子。
//
// *印不出来*：下面那条 show figure.caption 把题注整个重排，字号从
// styles.figure.caption 现取。
