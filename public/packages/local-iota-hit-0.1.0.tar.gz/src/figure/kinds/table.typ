
#import "@local/banshi:0.1.0" as banshi
#import "../../heading/numbering.typ" as _numbering
#import "../continued.typ": find-continued
#import "../../terms/lang.typ": doc-lang
#import "../../references/refs.typ" as refs
#import banshi.paragraph: spacing
#import "../table-style.typ": table-style, cell-style, borders
#let continued-row(metrics, top-rule, by-chapter) = context {
  let page-now = here().page()
  let me = here().position()
  let owners = query(figure.where(kind: table)).filter(g => {
    let at = g.location().position()
    at.page < me.page or (at.page == me.page and at.y <= me.y)
  })
  if owners.len() == 0 { return }
  let f = owners.last()
  // 没有表题的表没有续表可标
  if f.caption == none { return }
  let mark = find-continued(f.caption.body)
  if f.location().page() == page-now and mark == none { return }
  if f.numbering == none { return }
  let lang = doc-lang.get()
  let src = if mark == none {
    f
  } else if mark.target != none {
    query(mark.target).first()
  } else {
    let before = query(figure.where(kind: table)).filter(
      g => g.location().position().page < f.location().position().page
        or (g.location().position().page == f.location().position().page
            and g.location().position().y < f.location().position().y),
    )
    if before.len() == 0 { return }
    before.last()
  }
  if mark != none and f.location().page() == page-now {
    counter(figure.where(kind: table)).update(v => v - 1)
  }
  let seq = counter(figure.where(kind: table)).at(src.location())
  let num = if by-chapter {
    _numbering.chapter-numbered(src.location(), seq)
  } else {
    numbering("1", ..seq)
  }
  let given = refs.given-supplement(src.fields(), table, doc-lang.get())
  let mark-text = {
    let name = if given != auto { given } else { refs.word(lang, "table") }
    let mark = refs.continued-mark(lang, name)
    let name = if given != auto { given } else {
      _numbering.appendix-prefix(src.location(), lang, by-chapter: by-chapter) + name
    }
    name + (if lang == "en" { " " }) + num + refs.continued-gap(mark)
    mark
    sym.zws
  }
  // 那一格左对齐、标注不占宽：放得下就推到表右缘，放不下就居中、两边各溢出一半
  context {
    let w = measure(mark-text).width
    layout(size => box(width: 0pt, move(
      dx: if w <= size.width { size.width - w } else { -(w - size.width) / 2 },
      box(width: w, mark-text),
    )))
  }
}
// 模板自己排的表单（答辩页的评阅表）不是数据表，打上它就不重建
#let form-label = <iota-form>
// 重建出来的表再次命中 show table 时靠它放行；内层写恒等 show 规则拦不住（maximum show rule depth exceeded）
#let _built-mark = metadata((iota-table-built: true))
#let _built(c) = {
  if type(c) != content { return false }
  if c.func() == metadata { return type(c.value) == dictionary and "iota-table-built" in c.value }
  if c.has("children") {
    for k in c.children { if _built(k) { return true } }
  }
  if c.has("body") { return _built(c.body) }
  false
}
// Typst 自己的默认值：分辨「用户显式写的」与「没写」，fields() 两者都给得出来，只有拿默认值比对能分开
#let _typst-default-inset = 0% + 5pt
#let _t(v) = if v == none { 0pt } else { v }
// 单元格 (x, y) 四边挨着哪条线
#let _edges(b, n, off, header-rows, last) = (x, y) => (
  top: if y == off { b.top } else if header-rows > 0 and y == off + header-rows { b.header } else { b.inside-horizontal },
  bottom: if y == last { b.bottom } else if header-rows > 0 and y == off + header-rows - 1 { b.header } else { b.inside-horizontal },
  left: if x == 0 { b.left } else { b.inside-vertical },
  right: if x == n - 1 { b.right } else { b.inside-vertical },
)

// 表按 Word 重建：字号行高取表格样式、单元格按文档网格、边距从线的内沿量、线按样式画，
// 表头那一行上插一格（随表头逐页重复）；表格 figure 里的表在那一格排续表注记，裸表没有号，那一格空着
#let _rebuild(header-rows, by-chapter, in-figure: true) = it => context {
  if _built(it) or it.at("label", default: none) == form-label { return it }
  let layout = banshi.layout.current-page-setup()
  let ts = table-style()
  // 格子里的行贴不贴网格由 Word 的 w:adjustLineHeightInTable 定（博后没写：不贴，一行只是五号单倍）
  let cell = banshi.table.cell-style(cell-style(ts, text.size))
  let b = borders(ts.at("stroke", default: auto))
  let m = spacing(cell, layout: layout)
  let f = it.fields()
  // 空格子里仍有一个段落标记：Word 按它（西文字体）占一行，整行空着也不塌成 0 高
  let mark = banshi.paragraph.paragraph-mark(
    size: cell.size, line-spacing: cell.at("line-spacing", default: "single"),
    snap: cell.at("snap-to-grid", default: false), layout: layout,
  )
  let lines(body) = banshi.table.cell-body(cell, layout, body)
  let fill(k) = if type(k) != content { k } else if k.func() == table.cell {
    let g = k.fields()
    let body = g.remove("body")
    table.cell(..g, if banshi.content.blank(body) { mark } else { lines(body) })
  } else if k.func() in (table.header, table.footer) {
    let g = k.fields(); let ch = g.remove("children"); (k.func())(..g, ..ch.map(fill))
  } else if k.func() in (table.hline, table.vline) { k } else if banshi.content.blank(k) { mark } else { lines(k) }
  let kids = f.remove("children").map(fill)
  let raw-stroke = f.remove("stroke", default: none)
  let raw-inset = f.remove("inset", default: none)
  let raw-align = f.remove("align", default: auto)
  let stroke-untouched = (
    type(raw-stroke) == stroke
      and raw-stroke.thickness == auto
      and raw-stroke.paint == auto
  )
  let inset-untouched = raw-inset == _typst-default-inset
  let margin = if not inset-untouched { raw-inset }
    else if table.inset != _typst-default-inset { table.inset }
    else { ts.inset }
  let cols = f.at("columns", default: 1)
  let n = if type(cols) == int { calc.max(cols, 1) } else if type(cols) == array {
    calc.max(cols.len(), 1)
  } else { 1 }
  let has-header = kids.any(k => k.func() == table.header)
  // 这一格左对齐，不跟表的 align 走：内容从格左起排，往哪儿摆由续表注记自己定
  let mark-cell = table.cell(
    colspan: n, stroke: none, align: left, inset: (bottom: _t(b.top) / 2, rest: 0pt),
    _built-mark + if in-figure { continued-row(m, _t(b.top), by-chapter) },
  )
  let kids = if not has-header {
    (table.header(mark-cell), ..kids)
  } else {
    kids.map(k => if k.func() != table.header { k } else {
      table.header(
        mark-cell, ..k.fields().children,
        repeat: k.at("repeat", default: true),
        level: k.at("level", default: 1),
      )
    })
  }
  let off = 1
  let f = {
    let rs = f.at("rows", default: ())
    if type(rs) != array or rs.len() == 0 { f } else { f + (rows: (auto, ..rs)) }
  }
  let header-rows = if has-header { header-rows } else { 0 }
  let slots(k) = if k.func() == table.cell {
    k.at("colspan", default: 1) * k.at("rowspan", default: 1)
  } else if k.func() == table.header {
    k.fields().children.filter(c => c != mark-cell).map(slots).sum(default: 0)
  } else if k.func() in (table.hline, table.vline) { 0 } else { 1 }
  let last = off + calc.ceil(kids.map(slots).sum(default: 0) / n) - 1
  let edges = _edges(b, n, off, header-rows, last)
  let inset(x, y) = {
    let e = edges(x, y)
    banshi.table.cell-inset(margin, top: e.top, bottom: e.bottom, left: e.left, right: e.right)
  }
  // 底线追加成 hline：stroke 闭包只对真实存在的格子调用，拿不到总行数；不带 y 的 hline 落在
  // 最后一格之后，长表跨页也只出现在末页
  let kids = if stroke-untouched and b.bottom != none { kids + (table.hline(stroke: b.bottom),) } else { kids }
  let built = {
    show: banshi.styles.rules.with(cell, layout: layout)
    set table(
      align: if raw-align == auto { center } else { raw-align },
      inset: inset,
      // 每条线只由一侧的格子画：横线归下面那一格的 top（表头下线归表头行的 bottom——跨页
      // 时重复出来的表头 y 仍是 0，画在它自己的下边才跟得上），竖线归左边那一格的 right、
      // 首列的 left；底线是上面追加的 hline
      stroke: if not stroke-untouched { raw-stroke } else { (x, y) => {
        let e = edges(x, y)
        (
          top: if y == off { e.top } else if header-rows > 0 and y == off + header-rows { none } else { e.top },
          bottom: if header-rows > 0 and y == off + header-rows - 1 { b.header } else { none },
          left: if x == 0 { e.left } else { none },
          right: e.right,
        )
      } },
    )
    table(..f, ..kids)
  }
  let built = if stroke-untouched { pad(bottom: _t(b.bottom) / 2, built) } else { built }
  let out = if banshi.table.fixed-columns(cols) { banshi.table.overhang(measure(built).width, layout.text-width) } else { 0pt }
  if out > 0pt { pad(x: -out, built) } else { built }
}

/// 表都按 Word 排，包不包 figure 一样：字号取表格样式（原生 show table: set text 仍压得过），其余见 _rebuild
/// -> content
#let table-rules(by-chapter: true, header-rows: 1, size: auto, doc) = {
  show table: set text(size: size) if size != auto
  show table: _rebuild(header-rows, by-chapter, in-figure: false)
  show figure.where(kind: table): it => {
    show table: _rebuild(header-rows, by-chapter)
    it
  }
  doc
}
