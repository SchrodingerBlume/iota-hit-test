#import "@local/banshi:0.1.0" as banshi
#import banshi.styles as _rules
#import banshi.fonts: fontset-state
#import banshi.paragraph: families-of
#import banshi.layout as _layout
#import banshi.content: plain-text, edge, metadata-of
#import banshi.runs: has-cj
#import "../terms/lang.typ": doc-lang
#import "../references/refs.typ": word as _word
#import "../settings/resolve.typ": setting-of

// 图注、表注：写在 figure 正身里，排在写的位置（图后、题之上；表后）。指南 2.13「有图注或其他说明时
// 应置于图题之上」。只是一条 metadata，宽与样式由 figure 的 show 规则按所在的图表给。
#let mark = "iota-figure-note"
#let note(lead: auto, width: auto, body) = {
  if width != auto and type(width) not in (ratio, length) {
    panic("note: width: expected auto, a ratio such as 80%, or a length, found " + repr(width))
  }
  metadata(((mark): (lead: lead, width: width, body: body)))
}
#let is-note(el) = el.func() == metadata and type(el.value) == dictionary and mark in el.value
// 分图的注嵌在 grid 格里，得往里找
#let has-note(body) = metadata-of(body, mark).len() > 0

// 每条注所在的容器：正身顶层的注跟整个正身，嵌在 grid／stack／table 格子里的跟那一格，
// 装在 block／box 里的跟那个块。按出现顺序列出来，排的时候按序号取
#let _containers(c, container) = {
  if type(c) != content { return () }
  if is-note(c) { return (container,) }
  if c.has("children") {
    let cells = c.func() in (grid, stack, table)
    return c.children.map(k => _containers(k, if cells { k } else { container })).flatten()
  }
  if c.has("body") { return _containers(c.body, c) }
  ()
}
#let _counter = counter(mark)
#let reset() = _counter.update(0)
#let widths-of(body, page-setup) = _containers(body, body).map(k => (
  calc.min(measure(k, width: page-setup.text-width).width, page-setup.text-width)
))
// 宽：局部 > 文档级 note-width > auto（跟所在的图表）
#let _width(local, own, page-setup) = {
  let v = if local != auto { local } else { setting-of("note-width") }
  if v == auto { own } else if type(v) == ratio { v * page-setup.text-width } else { v }
}
#let note-block(value, widths, style, page-setup) = {
  let lang = doc-lang.get()
  let lead = if value.lead == auto { _word(lang, "note") } else { value.lead }
  _counter.step()
  context {
    let i = _counter.get().first() - 1
    let own = if i < widths.len() { widths.at(i) } else { page-setup.text-width }
    block(width: _width(value.width, own, page-setup), above: 0pt, below: 0pt, {
      show: _rules.rules.with(style, layout: page-setup, families: families-of(style, fontset-state.get()))
      set par(first-line-indent: 0pt)
      set align(left)
      if lead == none { value.body } else {
        // 引导词自成一列，续行悬挂到它之后；西文引导词后空四分之一字
        grid(
          columns: (auto, 1fr),
          column-gutter: if has-cj(edge(lead, true)) { 0pt } else { 0.25em },
          lead, value.body,
        )
      }
    })
  }
}
