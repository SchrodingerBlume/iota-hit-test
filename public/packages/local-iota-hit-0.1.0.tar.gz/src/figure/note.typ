#import "@local/banshi:0.1.0" as banshi
#import banshi.styles as _rules
#import banshi.fonts: fontset-state
#import banshi.paragraph: families-of
#import banshi.layout as _layout
#import banshi.content: plain-text, edge
#import banshi.runs: has-cj
#import "../terms/lang.typ": doc-lang
#import "../references/refs.typ": word as _word
#import "../settings/resolve.typ": setting-of

// 图注、表注：写在 figure 正身里，排在写的位置（图后、题之上；表后）。指南 2.13「有图注或其他说明时
// 应置于图题之上」。只是一条 metadata，宽与样式由 figure 的 show 规则按所在的图表给。
#let mark = "iota-figure-note"
#let figure-note(lead: auto, width: auto, body) = {
  if width != auto and type(width) not in (ratio, length) {
    panic("figure-note: width: expected auto, a ratio such as 80%, or a length, found " + repr(width))
  }
  metadata(((mark): (lead: lead, width: width, body: body)))
}
#let is-note(el) = el.func() == metadata and type(el.value) == dictionary and mark in el.value
#let has-note(body) = body.has("children") and body.children.any(is-note)

// 宽：局部 > 文档级 figure-note-width > auto（跟图表自己的宽）
#let _width(local, body-width, layout) = {
  let v = if local != auto { local } else { setting-of("figure-note-width") }
  if v == auto { body-width } else if type(v) == ratio { v * layout.text-width } else { v }
}
#let note-block(value, body-width, style, layout) = {
  let lang = doc-lang.get()
  let lead = if value.lead == auto { _word(lang, "note") } else { value.lead }
  let w = _width(value.width, body-width, layout)
  block(width: w, above: 0pt, below: 0pt, {
    show: _rules.rules.with(style, layout: layout, families: families-of(style, fontset-state.get()))
    set par(first-line-indent: 0pt)
    set align(left)
    if lead == none { value.body } else {
      // 引导词自成一列，续行悬挂到它之后；西文引导词后空四分之一字
      grid(
        columns: (auto, 1fr),
        column-gutter: if has-cj(edge(lead, true)) { 0pt } else { 0.25em },
        lead, value.body,
      )
    }
  })
}
