// 图表三段空当（styles.figure.image / table 的 above、gap、below）是模板的键，交给 banshi 合并之前在这儿验；auto ＝ 不写，去掉后落到模板那一档
#let _sides = ("above", "gap", "below")
#let without-auto(local) = {
  let fig = if type(local) == dictionary { local.at("figure", default: none) }
  if type(fig) != dictionary { return local }
  for which in ("image", "table") {
    let st = fig.at(which, default: none)
    if type(st) != dictionary { continue }
    for key in _sides.filter(k => k in st) {
      let v = st.at(key)
      if v == auto {
        let _ = st.remove(key)
      } else if not (type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))) {
        panic("styles.figure." + which + "." + key + ": expected auto, a length, or a dictionary with \"lines\", found " + repr(v))
      }
    }
    fig.insert(which, st)
  }
  local + (figure: fig)
}
