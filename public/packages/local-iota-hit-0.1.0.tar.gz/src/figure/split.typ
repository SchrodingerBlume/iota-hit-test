// 自动拆页：图与框图型伪代码跨页时题注跟头一页、续页末尾「图1-1（续图）」。
// 从 caption.typ 搬来——排法与理由见下面那段；接哪一张、号怎么取在 ./continued.typ，
// 题注那几行由 ./caption.typ 的 caption 排。
#import "@local/banshi:0.1.0" as banshi
#import "./caption.typ": caption, width-mark
#import "./continued.typ": find-continued, continued-head
#import "./kinds/image.typ": find-subs
#import "./kinds.typ" as kinds
#import banshi.layout as _layout
#import "../settings/resolve.typ": resolve-algorithm-style, resolve-raw-style

// ── 自动拆页的图与框图型伪代码 ─────────────────────────────────────
//
// 图默认整块不拆（Typst 的 figure 就是这样），*但拆得开*：指南 2.13.2 先说「插图与其
// 图题为一个整体，不得拆开排写于两页」，接着写「有分图时，分图过多在一页内安排不下时，
// 可转到下页，总图题只出现在该页，下页标『图序（续图）』字样」——总图题跟着头一页，
// 后面每一页末尾一条「图1-1（续图）」。用户写 show figure.where(kind: image): set
// block(breakable: true) 就走这一条；框图型伪代码当图处理，algorithm-style.breakable:
// true 同一个排法（「算法1-1（续算法）」）。表不走这里，续表注在表右上角（three-line.continued-row）。
//
// *排法*：正文与题注装进一个单列 grid，题注放 grid.footer（每页重排一次、里面的
// context 按页重算，与表头那一格同一个实测结论）——头一页排整条题注，续页排续图
// 标注；figure 自己那一条题注不要了（这里不调 it，figure 元素照样在、照样记数、照样
// 引用，只是版面由我们出）。题注排在 footer 里而不是判「这是末页」：footer 每页等高，
// 末页判不判都不改版面，判了反而要靠题注落在哪一页，而那又取决于 footer 高不高——
// 一个循环。
//
// *分图题跟着分图走*：body 里每一张 image 前面埋一个记号（metadata 可定位、不占位），
// 这一页有哪几张就排哪几条分图题、号接着数（范例第 11 页正是上一页 (a)(b)、续图页
// (c)(d)）。记号数与 #subs 的条数对不上（图里另有图例、一张分图两张图）就退成整条
// 分图题跟总图题排在头一页。分图题写在分图之下那一档（#subfigure）天然跟着分图，不用管。
//
// *不重造 figure*：show figure 里再造一个同 kind 的 figure，原来那个仍然可查、仍然记数
// （实测两张图印成 Figure 2 / Figure 4）。这里返回的是一个块，不是 figure。
//
// 浮动的（placement 给了）不拆——浮动块本来就不能断页，原样交回
#let _piece = metadata((iota-piece: true))
#let split(it, layout, style, by-chapter, gap, size, position) = {
  let sel = figure.where(kind: it.kind)
  // figure 元素自己就在手上（show 规则的 it 带位置，题注的 kind / counter / numbering 已补齐），
  // 不去 query 找「我之前最后一张」
  let f = it
  // 续页的标注：手工续排的那张取它接的链头，与题注那一条同一个办法；*没写 #continued 的
  // 就是它自己*——continued-head 收 none 时按「接紧挨着的前一张」找，拿到的是前一张
  // （实测 algorithmic 那张的续页印成了前一张的号）
  let mark-of(pieces) = {
    let chain = find-continued(f.caption.body)
    let src = if chain == none { f } else { continued-head(sel, chain) }
    caption(
      f.caption, layout, style, by-chapter, source: if src == none { f } else { src },
      pieces: pieces,
    )
  }
  // *题注在上*：续表那一套——题注排在头一页上方（这里不调 it，题注得自己发；粘住下面的
  // 正文，与 _caption-line 里题注在上那一档同），往 grid.header 里注一格，续页右上角
  // 「名N-N（续名）」（指南 2.12「表右上角注明编号，编号后加（续表）」的样子，自造的
  // kind 套同一条）；起排页那一格空着、零高
  if position == top {
    let head = grid.cell(inset: 0pt, { set text(size: size); context {
      if here().page() != f.location().page() { mark-of((from: 0, to: 0)) }
    } })
    return block(width: 100%, breakable: true, {
      set text(size: size)
      context caption(f.caption, layout, style, by-chapter)
      v(gap)
      // 裹一层零间距的块：不裹的话正文那一块自己的 above（raw 的块距）落在题注与正文之间，
      // 比 figure 自己排的多出一截（实测 39.6 对 20.0）；figure 里正文也是裹在块里的
      //
      // grid 整版心宽；续页标注的右缘落在正文右缘（与续表落在表右上角同）那一步在
      // _caption-line 里做——它读 figure 前面的 width-mark，靠右之后垫一段空当推过去。
      // *不把 grid 收成正文那么宽*：标注比正文宽的（几行短代码）在窄格子里会折行（实测）
      block(above: 0pt, below: 0pt, width: 100%,
        grid(columns: 1fr, align: center, grid.header(repeat: true, head), it.body))
    })
  }
  // 字号按正文那一档，与 show figure.caption 那条同（理由见那里）
  let tail = grid.cell(inset: (top: gap, rest: 0pt), { set text(size: size); context {
    let start = f.location().page()
    // 这一页上落了哪几张分图：记号按文档序数，截到下一张同 kind 的 figure 为止
    let subs = find-subs(f.caption.body)
    let pieces = if subs == none { none } else {
      let mine = query(selector(metadata.where(value: _piece.value)).after(f.location()))
      let nxt = query(sel.after(f.location(), inclusive: false))
      let mine = if nxt.len() == 0 { mine } else {
        let stop = nxt.first().location().position()
        mine.filter(m => {
          let at = m.location().position()
          at.page < stop.page or (at.page == stop.page and at.y < stop.y)
        })
      }
      if mine.len() != subs.len() { none } else {
        let here-page = here().page()
        let on = mine.enumerate().filter(((i, m)) => m.location().page() == here-page).map(((i, m)) => i)
        if on.len() == 0 { (from: 0, to: 0) } else { (from: on.first(), to: on.last() + 1) }
      }
    }
    if here().page() == start {
      caption(f.caption, layout, style, by-chapter, pieces: pieces)
    } else {
      // 分图对不上页时（pieces 为 none）整条分图题已经跟总图题排在头一页，续页给空区间
      mark-of(if pieces == none { (from: 0, to: 0) } else { pieces })
    }
  } })
  block(width: 100%, breakable: true, {
    show image: img => _piece + img
    grid(columns: 1fr, align: center, it.body, grid.footer(repeat: true, tail))
  })
}

// 接到 figure 上。用法：show: split-rules.with(style: …, by-chapter: …, body-metrics: …)，
// 参数与 caption-rules 同名同义
#let split-rules(style: none, by-chapter: true, body-metrics: none, doc) = {
  // *装在 caption-rules 之外、之前*（src/iota-hit.typ）：Typst 后定义的规则先跑，这一条
  // 返回的不是 figure，排在它前面跑的规则才轮得到（编号的守门、网格取整那条 show image）
  //
  // *按题注在上在下分两路，不按 kind*：题注在下的（图、框图型伪代码、用户自造的 kind）走
  // 续图那一套——题注跟头一页、续页末尾「名N-N（续名）」；题注在上的（自造 kind 与 raw 写了
  // set figure.caption(position: top) 的）走续表那一套——题注照排在头一页上方、续页右上角
  // 「名N-N（续名）」。表自己有表头可注（three-line.continued-row）、表格型伪代码的标注在 lovelace 的
  // title 里、线条型不标注（用户定的），这三档不走这里
  show figure: it => context {
    let splits = if it.kind == table {
      false
    } else if it.kind == kinds.algorithm-kind {
      resolve-algorithm-style().frame == "boxed" and block.breakable
    } else if it.kind == raw and resolve-raw-style().frame == "ruled" {
      // 代码清单线条型：不画线不标注、接着排（与伪代码线条型同，用户定的）
      false
    } else { block.breakable }
    if not splits or it.placement != none { return it }
    split(it, _layout.current-layout(), style, by-chapter, it.gap, body-metrics.size, figure.caption.position)
  }
  doc
}
