#import "@local/banshi:0.1.0" as banshi
#import "./caption.typ": caption, width-mark
#import "./continued.typ": find-continued, continued-head
#import "./kinds/image.typ": find-subs
#import "./kinds.typ" as kinds
#import banshi.layout as _layout
#import "../settings/resolve.typ": resolve-algorithm-style, resolve-raw-style
#let _piece = metadata((iota-piece: true))
#let split(it, layout, style, by-chapter, gap, size, position) = {
  let sel = figure.where(kind: it.kind)
  let f = it
  let mark-of(pieces) = {
    let chain = find-continued(f.caption.body)
    let src = if chain == none { f } else { continued-head(sel, chain) }
    caption(
      f.caption, layout, style, by-chapter, source: if src == none { f } else { src },
      pieces: pieces,
    )
  }
  if position == top {
    let head = grid.cell(inset: 0pt, { set text(size: size); context {
      if here().page() != f.location().page() { mark-of((from: 0, to: 0)) }
    } })
    return block(width: 100%, breakable: true, {
      set text(size: size)
      context caption(f.caption, layout, style, by-chapter)
      v(gap)
      block(above: 0pt, below: 0pt, width: 100%,
        grid(columns: 1fr, align: center, grid.header(repeat: true, head), it.body))
    })
  }
  let tail = grid.cell(inset: (top: gap, rest: 0pt), { set text(size: size); context {
    let start = f.location().page()
    let subs = find-subs(f.caption.body)
    let pieces = if subs == none { none } else {
      let mine = query(selector(metadata.where(value: _piece.value)).after(f.location()))
      let nxt = query(sel.after(f.location(), inclusive: false))
      let mine = if nxt.len() == 0 { mine } else {
        let stop = nxt.first().location().position()
        mine.filter(m => {
          let at = m.location().position()
          at.page < stop.page or (at.page == stop.page and at.y < stop.y)
        })
      }
      if mine.len() != subs.len() { none } else {
        let here-page = here().page()
        let on = mine.enumerate().filter(((i, m)) => m.location().page() == here-page).map(((i, m)) => i)
        if on.len() == 0 { (from: 0, to: 0) } else { (from: on.first(), to: on.last() + 1) }
      }
    }
    if here().page() == start {
      caption(f.caption, layout, style, by-chapter, pieces: pieces)
    } else {
      mark-of(if pieces == none { (from: 0, to: 0) } else { pieces })
    }
  } })
  block(width: 100%, breakable: true, {
    show image: img => _piece + img
// 重复页脚能读取当前页；预先计算末页会形成布局循环。
    grid(columns: 1fr, align: center, it.body, grid.footer(repeat: true, tail))
  })
}
#let split-rules(style: none, by-chapter: true, body-metrics: none, doc) = {
  show figure: it => context {
    let splits = if it.kind == table {
      false
    } else if it.kind == kinds.algorithm-kind {
      resolve-algorithm-style().frame == "boxed" and block.breakable
    } else if it.kind == raw and resolve-raw-style().frame == "ruled" {
      false
    } else { block.breakable }
    if not splits or it.placement != none { return it }
    split(it, _layout.current-page-setup(), style, by-chapter, it.gap, body-metrics.size, figure.caption.position)
  }
  doc
}
