// 表格那一档样式（styles.figure.table）：Word 表格样式的字号、行距、线与单元格边距。banshi 只给映射值，样式在这里
#import "@local/banshi:0.1.0" as banshi
#import banshi.errors as _errors
#import "../styles/lookup.typ" as _lookup

/// 当前生效的表格样式（含局部 new-styles），`inset` 统一为 `(x:, y:)`；没写取 Word 的默认单元格边距。
/// 必须在 context 中调用。
/// -> dictionary
#let table-style() = {
  let ts = _lookup.current-styles().figure.table
  let inset = ts.at("inset", default: banshi.table.default-cell-margin)
  let inset = if type(inset) == length { (x: inset, y: inset) } else {
    (x: inset.at("x", default: 0pt), y: inset.at("y", default: 0pt))
  }
  ts + (inset: inset)
}

/// 由表格样式生成单元格段落样式：去掉边框、边距与空当，字号换成 `size`。
/// -> dictionary
#let cell-style(ts, size) = {
  let st = ts
  for k in ("above", "gap", "below", "inset", "stroke", "caption") { let _ = st.remove(k, default: none) }
  st + (size: size)
}

// 边框：Word「边框和底纹」里的几条——外框四边、内部横线、内部竖线，外加表头行下边线（header，三线表用）。
// 样式没写就是 Word 插入表格的默认：网格型，全部 0.5pt（w:sz=4）；写了字典就只有写到的边；写一个长度是四边与内部都用它
#let edges = ("top", "bottom", "left", "right", "inside-horizontal", "inside-vertical", "header")
#let word-grid = edges.map(k => (k, 0.5pt)).to-dict()
#let borders(value) = {
  if value == none or value == auto { return word-grid }
  if type(value) == length { return edges.map(k => (k, value)).to-dict() }
  edges.map(k => (k, value.at(k, default: none))).to-dict()
}

// inset、stroke 在样式表里是模板自己的键，banshi 原样放过，在这里验
#let check(ts, name: "styles.figure.table") = {
  if "inset" in ts {
    let v = ts.inset
    let ok(x) = type(x) == length
    if not (ok(v) or (type(v) == dictionary and v.keys().all(k => k in ("x", "y")) and v.values().all(ok))) {
      panic(name + ".inset: expected a length or a dictionary with \"x\" and \"y\" (Word's cell margins), found " + repr(v))
    }
  }
  if "stroke" in ts {
    let v = ts.stroke
    if not (v == auto or type(v) == length or (type(v) == dictionary and v.keys().all(k => k in edges) and v.values().all(x => type(x) == length or x == none))) {
      panic(name + ".stroke: expected auto (Word's grid, all 0.5pt), a length, or a dictionary of edges "
        + _errors.one-of(edges.map(repr)) + " in pt, found " + repr(v))
    }
  }
}

/// 局部改样式：同 banshi 的 new-styles，改到表格那一档时先验 inset / stroke，字号落到这一段里的表上。
/// -> content
#let new-styles(local, body) = banshi.styles.new-styles(local, {
  let tl = if type(local) == dictionary { local.at("figure", default: (:)).at("table", default: none) } else { none }
  if type(tl) == dictionary { check(tl, name: "new-styles: figure.table") }
  if type(tl) != dictionary or "size" not in tl { body } else {
    show table: set text(size: tl.size)
    body
  }
})
