// 附录。用法：#show: appendix
//
// *它是个阶段开关，不是一页。* 附录里可以有好几章，每章照旧写 `= 标题`，
// 走的是同一套章标题制度（章前跳页、进目录、字样）——只有*章号*换了轴：
// 正文是「第 1 章」，附录是「附录A」。所以它与 frontmatter / mainmatter 同形，
// 住在 src/flow 而不是 pages。
//
// *指南对附录的编号一个字都没规定。* 本科指南 2.15 与研究生规范 2.16 一字不差，
// 通篇只讲「什么内容可以放进附录」（比正文更详尽的信息、篇幅过大的材料、原始
// 数据与自编程序……），没有编号、没有标题格式；两份范例里也没有附录实例。所以
// 这一处只能跟 hithesis，取值与代价见 src/config/settings.typ 的
// appendix-numbering-auto。
//
// *人文社科档的附录与正文同一套写法*：章「附录一」，二级往下仍是「一、」
// 「（一）」「1.」——不是「一.1」。理由是那一档的正文本来就不把上级号累加进来
// （节只印本级的「一、」），附录没有道理另起一套；而理工那一档的「A.1」正是把
// 正文的「1.1」换掉头一位，两边各自自洽。
//
// *附录里的图表公式跟着章号走*——「图 A-1」「表 A-1」「式（A-1）」。这一条
// 不必在这里做：拼法收在 src/blocks/chapter.typ，点亮那个状态就够了。hithesis 是逐个
// \renewcommand \thefigure / \thetable / \theequation（hithesis.dtx:5958–5960），
// 我们是一处。
#import "../blocks/chapter.typ" as _chapter
#import "../engine/settings.typ" as _settings
#import "../engine/terms.typ": term-table
#import "../engine/info.typ": info-get
#import "../engine/lang.typ": doc-lang
#import "../config/numbering.typ" as _numbering

#let appendix(
  // 章号那一位的编号串："A"（附录A）／"I"（附录I）／"1"（附录1）／"一"（附录一）。
  // *就地压过文档级的同名参数*——auto ＝ 不表态，往上找文档级，再找不到才
  // 按门类与学位。登记在 setting-homes 里，与 #toc(heading-body-indent: …) 同形。
  // 取值与依据见 src/config/settings.typ
  appendix-numbering: auto,
  // 这一份用哪一层词条排。auto 跟随文档语言
  lang: auto,
  overrides: (:),
  doc,
) = context {
  // 号那一位的编号串。*下游只认这个串*，不认识学位，也不认识门类
  let l = if lang == auto { doc-lang.get() } else { lang }
  let pat = _settings.resolve-appendix-numbering(
    local: appendix-numbering,
    degree-level: info-get().degree-level,
    category: info-get().category,
    lang: l,
  )
  let t = term-table(l, "appendix", overrides: overrides)
  // 号前空不空：中文「附录A」连着写（hithesis 同），英文 Appendix A 中间一个空格
  let gap = if l == "en" { " " } else { "" }

  // 章号从头数。附录第一章是 A（或 1），不接着正文往下走
  counter(heading).update(0)
  // 点亮之后，图表公式的章号那一位改按 pat 印，见 src/blocks/chapter.typ
  _chapter.appendix-numbering.update(pat)

  // *只有一个附录就不编号*——章标题光印「附录」「Appendix」，后面直接跟题名。
  // 一份东西不必编号来分辨；Word 里作者也是直接写「附录」。
  //
  // *数出来的，不是让人写的*：这一页往后还有几个一级标题，query 一问便知。
  // 中文档的图表跟着少一位（「附图1」），英文档照 APA 仍印字母（Fig. A-1），见
  // src/blocks/chapter.typ。
  //
  // *两个条件缺一不可*：位置在附录里（读那个状态——它一开就再没关过），
  // *而且这一条自己是编号的*。附录之后还会有致谢、成果、简历这些一级标题，
  // 它们照样落在「附录里」，但都是 numbering: none 的（term-chapter 那一族），
  // 不是附录的章——先前只按状态数，一篇「一个附录 + 致谢」就数成了两个，
  // 章标题印回「附录1」
  let single = query(heading.where(level: 1))
    .filter(h => h.numbering != none and _chapter.appendix-numbering.at(h.location()) != none)
    .len() <= 1
  _chapter.appendix-single.update(single)

  // *理工那两档只换章号那一位*：二级往下照旧是点号数字（A.1、A.1.1），与正文
  // 的 1.1、1.1.1 同一个形状。*人文社科那一档整套跟正文*：一、／（一）／1.
  // ——那一档的节本来就只印本级的号，把「一」累加进来反而与正文两副样子。
  set heading(numbering: (..nums) => {
    let n = nums.pos()
    if n.len() == 1 {
      if single { return t.title }
      return t.title + gap + _numbering.appendix-mark(pat, n.at(0))
    }
    // *整串递进去*，别切掉章那一位——hit-numbering-hass 按层数挑写法，
    // 切了就只剩一位、当成章印成「第一章」（实测附录二级印出了「第一章调查问卷」）；
    // 它自己只用最后一位的数，章号本来就不进节的编号
    //
    // *"One" 那一档就是人文社科的英文档*：二级往下与中文档一模一样
    // （一、／（一）／1.），与那一档的正文（hit-numbering-hass-en）同一副样子
    if pat == "一" { return _numbering.hit-numbering-hass(..n) }
    if pat == "One" { return _numbering.hit-numbering-hass-en(..n) }
    // *章号那一位不存在时，节往下也少一位*：只有一个附录，中文档印「1」
    // 「1.1」——与图表少一位（附图1）同一条规矩，三处一致。英文档那一位仍是字母
    // （A.1），照 APA：英文的附录靠字母认，一个附录也照样是 A。判据与图表共用一处，
    // 见 src/blocks/chapter.typ 的 chapter-mark
    if single and l != "en" { return n.slice(1).map(str).join(".") }
    numbering(pat, n.at(0)) + "." + n.slice(1).map(str).join(".")
  })
  doc
}
