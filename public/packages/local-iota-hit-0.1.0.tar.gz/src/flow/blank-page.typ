// 清页与空白页。
//
// *补出来的空白页必须是彻底空白*——没有页眉、没有页脚、没有页码。
// hithesis 的做法是把 \cleardoublepage 整个换掉：
//
//     \cs_new:Npn \hit@clear@empty@double@page
//       { \clearpage { \pagestyle{hit@empty} \hit@clear@double@page } }
//
// 先 clearpage 冲干净，再*在一个分组里*把 pagestyle 设成 empty 才调真正的
// 双页清；分组一结束原来的 pagestyle 就回来了。这一套在 Typst 里原样可用：
// 实测裸写 pagebreak(to: "odd")，补出来的空白页*带页眉带页码*；套一层
// set page(header: none, footer: none, numbering: none) 再跳，补出来的是空页，
// 而下一页页眉页码照常回来、页码继续往下数（不跳号）。
//
// *不做「不插空白页、改用计数器跳号」那一档。* neu-typst-latest-cap-able
// 的单面模式是那么干的，代价是页码有视觉断档（IX 之后直接 XI）。那是它自己的
// 需求；HIT 这边 hithesis 的 openright 默认就是关的（hit-thesis.cls:6540），
// 关着就只是普通 clearpage，页码始终连续。

// 清到下一页；to 给 "odd" / "even" 时补出来的空白页不带页眉页脚页码。
//
// *也是用户的兜底。* 想在某个 markup 标题前面单独跳一次（那种地方带不了
// 参数），写一句 clear-page(to: "odd") 就是——等价于 hithesis 的 \cleardoublepage，
// 它自己的文档也是这么教的。
#let clear-page(to: none) = {
  if to == none {
    pagebreak(weak: true)
  } else {
    // 这个 set 圈在本代码块里，只罩住紧跟其后的那次跳页
    set page(header: none, footer: none, numbering: none)
    pagebreak(weak: true, to: to)
  }
}
