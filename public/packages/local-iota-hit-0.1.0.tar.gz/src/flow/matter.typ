// 前言段 → 正文段的切换。
//
// 照 hithesis 的三档 matter，但只有*正文*这一档需要用户显式写——前言是
// 从文档一开始就生效的默认态，后置部分与正文同一套页码页眉，也不必另开。
// 这与 neu-typst-latest-cap-able 的判断一致：mainmatter 是唯一有真实状态切换
// 的过渡点（切阿拉伯页码、重置页计数、页眉上场）。
//
// *右翻页按段管。* 三个 matter 各收一个 openright，决定「自己这一段整体
// 从右手页起吗」——段内每一章都落右手页，段的入口自然也是。取值层层可覆盖：
// 单章单部件 → 所在 matter → 总闸 → 默认表（见 src/config/settings.typ）。
//
// *正文入口那一跳就是正文第一章的跳*，只是必须提前到页码重置之前发出。
// 那张空白页仍在罗马页码这一段里（换制式与归零都在它之后），它是前置的最后
// 一页、消耗一个罗马数字——*纸归前置*，而「正文要不要从右手页起」这个
// *决定归正文*，两者不是一回事。
//
// *hithesis 不是这么分的。* 它的 \mainmatter 对博士单独写了一条
// （\bool_if:NTF \g__hit_doctor_bool …），封面序列另有无条件的
// \__hit_cover_break:，每章则由 openright 管——三处各自为政，还得靠 library
// 一票否决才关得掉。我们按段收拢之后没有关不掉的跳，也就不需要那个否决。
//
// 默认表现在全是 false，依据是范例：研究生范例第 9 页 Contents 印码 IV、
// 第 10 页就是第 1 章 印码 1，中间没有空白页。

#import "../engine/info.typ": info-get
#import "../engine/settings.typ": resolve-openright
#import "./blank-page.typ": clear-page
#import "../blocks/abbreviations.typ": reset as reset-abbreviations
#import "../engine/layout.typ" as _layout
#import "./section.typ": section-sets, front-page-numbering, main-page-numbering

// *当前这一段整体跳不跳。* 三个 matter 各自算好写进来，章标题的 show
// 规则读它——章跳不跳就是它所在那一段的事，见 src/engine/settings.typ。
// 初值 false：还没进任何 matter 时（对拍件那种只排正文的文档）不跳。
#let matter-openright = state("iota-hit-matter-openright", false)

// *前置段的显式取值*，给内封读——内封是前置的页，frontmatter 写了显式值
// 就该罩住它；没写（auto）它才去查自己那一档默认表。
#let frontmatter-openright = state("iota-hit-frontmatter-openright", auto)

// *正文段解出来的值*，给后置兜底用——正文与后置同一套页码页眉
// （指南 2.2），排布策略自然跟着。
#let mainmatter-openright = state("iota-hit-mainmatter-openright", auto)

// 这一段的页面设置：局部字典并到当前那一份上（整份就整份替换）——梯子的第三层，
// 见 src/engine/layout.typ。返回并好的版面，auto 返回 none（什么都不改）；写进
// layout-state 与重发一节的 set 在下面的 _section 里。*要在 context 里调*
//
// *承的是当前那一份，不是文档那一份。* 三个 matter 是层层套着的 show 作用域，
// 后置写在正文里面，没写 layout 就承正文的——Word 的节也这么承上一节。
//
// *段级不能开关字符网格。* 西文 run 那两条 show 规则装不装是按文档级的版面定的
// （一条 show regex 哪怕原样交回也会造 run 边界，不能一律装上，见
// src/engine/styles.typ 的 shows）；段里把 char-pitch 加上或去掉，那两条规则不会跟着
// 装上或拆掉，西文的半份字距就错了。与其静默错，不如当场拦下。
#let _merge-layout(layout) = {
  if layout == auto { return none }
  let old = _layout.layout-state.get()
  let old = if old == none { _layout.standalone-layout(none) } else { old }
  let merged = _layout.resolve-local(old, layout)
  if (merged.docgrid.tracking == 0pt) != (old.docgrid.tracking == 0pt) {
    panic(
      "layout: a section cannot switch the character grid on or off (char-pitch / "
        + "chars-per-line); write it at iota-hit(layout:) for the whole document",
    )
  }
  merged
}

// 并好的版面写进 layout-state 给段里的页函数、正文的 show 规则与 ccwd 取，再把
// 一节的 set 按它重发一次（见 src/flow/section.typ）；没改（none）就什么都不发
#let _section(layout, doc) = if layout == none { doc } else {
  _layout.layout-state.update(layout)
  section-sets(layout, doc)
}

// 前言开始：罗马页码，从 I 起。用法：#show: frontmatter
//
// *封面与内封不在这一档里。* 那两页自己按 layout.header.shown 不出页眉页脚
// （部件差额，见 src/config/layout.typ），本来就不出页码；罗马页码从摘要起算，
// 与范例一致。
#let frontmatter(openright: auto, layout: auto, doc) = context {
  let layout = _merge-layout(layout)
  frontmatter-openright.update(openright)
  matter-openright.update(resolve-openright(
    "frontmatter", degree-level: info-get().degree-level, local: openright,
  ))
  // *先跳页、后重置计数器。* 反过来的话，计数器在跳页*前*那一页上
  // 被设成 1，紧接着第一个部件的章标题自己又跳一次奇数页，于是前言第一页成了
  // II——实测研究生 openright 档的章起始落在 II / IV / VI。
  set page(numbering: front-page-numbering)
  _section(layout, doc)
}

// 前置部分里*带页码*的部件在开头登记一次，头一个把页码归到 I。
//
// *为什么不由 frontmatter 直接归零。* 封面与内封在规范里就是前置部分，
// 所以 #show: frontmatter 该写在它们*之前*——否则用户会以为那两页不属于
// 前置。可它们又不参与页码编排（范例里摘要是 - I -，不是 - III -），
// frontmatter 一上来就归零的话，封面数 I、内封数 II、摘要就成了 III。
//
// 所以归零这件事交给「头一个带页码的部件」：摘要、目录这些在自己的章标题排完
// 之后调一次，谁先来谁触发，后来的看见旗子已立就不动。这样与「有没有封面、
// 有几页不带页码」完全无关。做法学自 neu-typst-latest-cap-able 的
// frontmatter-module-enter。
//
// *要在章标题之后调。* 标题会先切一页，若在它之前归零，那一下落在
// *上一页*（内封那一页）上，摘要就成了 II——与 mainmatter 那处「先跳页、
// 后重置」是同一个坑。
//
// *正文开始后不再触发。* 万一有人把摘要写在 #show: mainmatter 之后，
// 归零会把正文页码打乱；这一条挡住它。
// *封面序列的出口。* titlepage() 把「这一档要不要落奇数页」记在这儿，
// *由后面第一个前置部件把那一跳补上*——摘要或目录，谁先来谁发。
//
// 为什么不由 titlepage() 自己发：那一跳的目的是「把紧跟其后的东西顶到右手页」，
// 而 pagebreak 带上 to: "odd" 之后，weak 就不再管用了——文末也照补一张
// （实测「甲 #pagebreak(weak: true)」是 1 页，加上 to: "odd" 变 2 页）。于是
// 只排封面内封、后面什么都没有的文档，末尾会多一张空白。目的在后面那个东西
// 身上，就该由它来发；没有后续内容，自然没人发。
//
// *要在章标题之前调*——标题自己那次弱跳到时会被丢掉（已经在新页页首了）。
// front-numbering-enter 同样在标题之前，理由见那里。
#let cover-exit-odd = state("iota-hit-cover-exit-odd", false)

// 「第一个来的人」这条旗子不能用 state 的读一次写一次来立：update 落在读它的
// 那个 context 自己身上，get() 看得见自己那一次写，于是第一轮读到 false 就写、
// 第二轮读到 true 就不写、第三轮又没得读……实测 typst 报「did not converge」，
// 值在 false / true 之间来回跳满五轮。
//
// 换成计数器：step 是独立元素，无条件、且落在读它的 context *之前*，
// 第 n 次调用就稳稳读到 n，只有第 1 次动手。
#let cover-exit-count = counter("iota-hit-cover-exit")

#let cover-exit() = {
  cover-exit-count.step()
  context {
    if cover-exit-count.get().first() == 1 {
      clear-page(to: if cover-exit-odd.get() { "odd" } else { none })
    }
  }
}

#let mainmatter-started = state("iota-hit-mainmatter-started", false)

// 头一个带页码的前置部件把页码归到 I。
//
// *这一跳得自己发，不能借标题那次。* 归零要排在标题*之前*——目录
// 条目读的是标题那个元素位置上的计数器值，排在后面的话第一条会印物理页号
// （实测博士 auto 摘要那条印 VII，页脚却是 I）。可光是提前又不行：计数器会
// 落在跳页*前*那一页上，摘要就成了印码 2。所以顺序只能是「先跳、再
// 归零、最后标题」，标题自己那次弱跳到时已在页首，会被丢掉。
//
// *跳法要跟标题将要解出的值一致*，否则归零又落在跳页前那一页上。所以
// openright 得从部件透进来：auto 才跟随段级，与 src/blocks/heading-rules.typ 里那个「带记号
// 就照记号、没带才跟随 matter-openright」是同一套判断。
//
// 「第一个来的人」用计数器立旗，理由同 cover-exit。
#let front-numbering-count = counter("iota-hit-front-numbering")

#let front-numbering-enter(openright: auto) = {
  front-numbering-count.step()
  context {
    if mainmatter-started.get() { return }
    if front-numbering-count.get().first() == 1 {
      let odd = if openright != auto { openright } else { matter-openright.get() }
      clear-page(to: if odd { "odd" } else { none })
      counter(page).update(1)
    }
  }
}

// 正文开始。用法：#show: mainmatter
//
// 博士也不强制奇数页起（默认表里 mainmatter 那格是 false，见 src/config/settings.typ）；
// 图书馆版要的「不留空白页」就是 openright: false，没有单独的开关。
#let mainmatter(openright: auto, layout: auto, doc) = context {
  let layout = _merge-layout(layout)
  let odd = resolve-openright(
    "mainmatter", degree-level: info-get().degree-level, local: openright,
  )
  matter-openright.update(odd)
  mainmatter-openright.update(odd)
  // *入口那一跳就是正文第一章的跳*，只是必须提前到页码重置之前发出——
  // 反过来的话计数器落在跳页*前*那一页上，正文第一页会变成印码 2。
  //
  // *那张空白页仍在罗马页码这一段里*（换制式与归零都在它之后），它是
  // 前置的最后一页，消耗一个罗马数字——归属对得上。
  clear-page(to: if odd { "odd" } else { none })
  mainmatter-started.update(true)
  // 页码从头数，样式换成阿拉伯
  set page(numbering: main-page-numbering)
  // *正文一律归一。* 论文的前置是罗马页码、正文另起一套；报告的前置*不
  // 印页码*——文档级的 numbering 是 none，页脚那一句因此什么都不排（见
  // src/flow/section.typ），正文这一节才从 1 起。
  //
  // 出处：七份表单里给了页码的四份都是这样——学校发的硕士中期那份写着封面无号、
  // 正文那一节 w:pgNumType start="1"，深圳那四份的目录页页脚是空的、正文第一页
  // 印「1」或「- 1 -」。先前这儿写的是「目录归过了就不再归」，带目录的报告正文
  // 因此从 2 起，那是我们自己定的，与四份原件都对不上。
  //
  // 深圳本科那两份的前置是罗马页码（它们的正文照终稿排，见 src/flow/stage.typ 的
  // final-body），归一这一步与终稿那一支同一件事
  counter(page).update(1)
  // 缩略语的「用过」清一遍：正文第一次出现仍全写，规范说的「文中第一次出现」
  // 指的就是正文，见 src/blocks/abbreviations.typ 的 reset
  reset-abbreviations()
  _section(layout, doc)
}

// 后置部分开始。用法：#show: backmatter
//
// *它*不*换页码制度。* 指南 2.2「正文以后的页码用阿拉伯数字编排」
// ——后置与正文同一套页码、同一套页眉，mainmatter 那一档一直管到末尾。
// hithesis 的 \backmatter 同样只清一页并保持 @mainmatter 为真：
//
//     \cs_set:Npn \backmatter
//       { \bool_if:NTF \g__hit_openright_bool { \cleardoublepage } { \clearpage }
//         \@mainmattertrue }
//
// 所以它只做一件事：清页；openright 开着时清成双页，后置从奇数页起。
//
// *别去「修」它。* frontmatter 与 mainmatter 都改页码，看着这一档不改
// 像是漏了——不是漏了，规范就是这么定的。
//
// 后置部分包括：参考文献、附录、攻读学位期间取得的成果、原创性声明与使用
// 授权说明、致谢（指南 2.4 的次序）。
#let backmatter(openright: auto, layout: auto, doc) = context {
  let layout = _merge-layout(layout)
  let odd = resolve-openright(
    "backmatter",
    degree-level: info-get().degree-level,
    local: openright,
    matter: mainmatter-openright.get(),
  )
  matter-openright.update(odd)
  clear-page(to: if odd { "odd" } else { none })
  _section(layout, doc)
}
