// 一份文档处在哪一档，以及「这一页属不属于这一档」。
//
// *stage 是一根轴*（src/config/axes.typ）：final 是终稿本身，proposal 与
// interim 是开题与中期那两份表单。绝大多数页面只在 final 出现——摘要、内封、
// 原创性声明、答辩决议这些，报告里根本没有这一页。
//
// *不属于本档的页面静默跳过。* 这样一份模板改一行 stage 就能出任何一档，
// 用户不必把十来行调用注释来注释去。
//
// *这一条是本包唯一容许的静默失效，写在这里免得日后被「修」掉。* 别处
// 一律相反——覆盖键落进没人读的桶、缩略语选项拼错、内封 fields 没透下去，
// 每一处都专门做了报错，注释里也写着「静默失效比报错糟」。这里反过来，
// 是因为它*不是错*：在开题报告里写 #abstract 不是手滑，是同一份模板
// 通吃三档时必然出现的写法。要排就写 shown: true，一个词的事。
#import "../engine/info.typ": info-get

#let report-stages = ("proposal", "interim")

// *正文照终稿排的那几档。*
//
// 深圳校区本科那两份报告（本科毕业设计开题报告_模板.docx、本科毕业论文（设计）
// 中期报告-模板.dotx）*只有首页是表单，正文与终稿同构*——判据在文件里：
//
//   版面    开题那份正文节的 w:pgMar 2154/1701/1701/1701 与 docGrid 391/1861
//           与终稿逐个数相同（版面那一层已经照它排，见 src/config/layout.typ 的
//           _shenzhen-bachelor-proposal）
//   样式    章 小二黑体居中、节 小三、条 四号，与终稿同；中期那份连样式名都还是
//           本科毕业论文模板的（「一级节标题2.3」「非章节标题-摘要结论参考文献」）
//   跳页    两份的章都另起一页（中期在 heading 1 的样式里写着 pageBreakBefore，
//           开题写在各章那一段上——导出来的 PDF 第 5–9 页各自起一章）
//   页码    目录罗马、正文阿拉伯重新起（导出来的 PDF 上是 I 与「- 1 -」）
//   图表    按章编号（中期范例里印的是「图2-4 涡室的截面形状」）
//
// *只有编号那一条仍照报告*：这两份的章印的是「1」不是「第1章」，与本部
// 三份报告一致（见 src/config/numbering.typ 的 hit-numbering-report）。
//
// 首页、页眉、页脚仍按报告那一档走（那三样是表单自己的），所以这一支只管正文。
#let final-body(campus, degree-level, stage) = (
  stage in report-stages and campus == "shenzhen" and degree-level == "bachelor"
)

// 这一页只在终稿出现。shown 三态：
//
//   auto   不写 ＝ 按档决定：final 排，报告不排
//   true   强制排——写在开题报告里也照排
//   false  强制不排，连 final 也按掉
//
// *名字与 outlined / indexed / printed 同一族*：过去分词，说的是「这一页
// 要不要参与这件事」。
//
// *这是一句判据，不是一层包装。* 先前它是 (..args) => …——套上去之后
// 那一页的签名就没了，编辑器只认声明出来的参数，沉没参数里的名字它看不见
// （dispatch.typ 里那句「参数逐条写出来，不用 ..args 一兜」说的是同一件事）。
// 十二个终稿页因此整排补全不出来，连 shown 自己都补不出来。改成判据之后
// 各页自己收 shown、自己在头一句问一次，签名一个字都不必抄。
#let final-only-wanted(shown) = if shown != auto { shown } else {
  info-get().stage == "final"
}
