#import "@local/docxtyp:0.1.0" as d
#import "./fonts/presets.typ": default-metrics, metrics, presets, roles, zihao
#import "./fonts/resolve.typ": fangsong, font, fontset, fontset-state, heiti, is-hant-only, kaishu, mono-edges-em, mono-table, sans, serif, songti
#import "./fonts/probes.typ": probes
#import d.fonts: boundary-pad
#import "./fonts/underline.typ": underline-of
#import "./fonts/fake.typ": fake-bold, wants-bold-for
