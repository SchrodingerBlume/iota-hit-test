// 简繁转字。
//
// 这一档只为楷体而设，但管的是转字，不是字体——楷体的入口在
// src/fonts/resolve.typ。
//
// *要解决的事。* webapp 那一档的楷体是教育部标准楷书 TW-MOE-Std-Kai——
// Web App 上没有简体楷体，只有它。而它*只有繁体字形*，直接排简体会缺字，
// 所以用到它时要把汉字转成繁体。做法学自 ElegantBook。
//
// *依赖是急切的。* Typst 没有条件 import，写在这里就是每个用户都要下
// @preview/zhconv，哪怕从不用 webapp 档。这一条与 ElegantBook 相同，
// 没有更好的办法。
//
// *但规则不必总是发。* ElegantBook 是无条件挂一条
// show regex("[\p{Han}]+")，靠 context 逐段判当前字体是不是教育部楷书。
// 我们把这一层往前挪：解析完字体表就知道有没有繁体档的家族，没有就*一条
// 规则都不发*。这不是洁癖——那条 regex 会在每段汉字两端各吃掉 0.4543 的
// tracking（机制见 src/fonts/tracking.typ），默认档 windows 的楷体是 KaiTi，
// 本来就不需要转字，不该跟着付这笔。
//
// 发了之后仍照 ElegantBook 逐段判字体：同一份文档里楷体那几段转繁，
// 别处不动。
//
// *转字要整段交给 zhconv。* 一段连续的汉字整体转，它才能靠词组语境分开
// 「皇后」与「后台」——实测 zhconv("皇后在后台", "zh-hant") 出「皇后在後台」，
// 前一个 后 不动、后一个转 後。逐字转分不出来。

#import "@preview/zhconv:0.3.1": zhconv
#import "./resolve.typ" as fonts
// 当前生效的字体表里有没有繁体档的家族。字体表可能是单个字符串、
// 也可能是数组，数组项还可能是带 covers 的字典。
#let _uses-hant(font) = {
  let families = if type(font) == array { font } else { (font,) }
  families.any(f => fonts.is-hant-only(
    if type(f) == dictionary { f.name } else { f },
  ))
}

// 解析出来的字体表里有没有繁体档的家族。有才发规则。
#let _needs-hant(font-table) = font-table.families.values().any(v => (
  type(v) == str and fonts.is-hant-only(v)
))

#let hant-rules(font-table, doc) = {
  if not _needs-hant(font-table) { return doc }
  show regex("\p{Han}+"): it => context {
    if _uses-hant(text.font) { zhconv(it.text, "zh-hant") } else { it }
  }
  doc
}
