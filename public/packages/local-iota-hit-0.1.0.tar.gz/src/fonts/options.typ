#let _state = state("iota-font-options", (fake-bold: auto, fake-italic: auto))
#let keys = ("fake-bold", "fake-italic")
#let checked(value) = {
  for (key, v) in value {
    if key in keys and v not in (auto, true, false) { panic(key + ": expected auto, true, or false") }
  }
  value
}
#let apply(value) = _state.update(old => old + checked(value).pairs().filter(((k, _)) => k in keys).to-dict())
#let option-of(key) = _state.get().at(key)
