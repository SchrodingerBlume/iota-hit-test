// 模板字体角色的选择器；不作为通用脚本检测或 OOXML 字体槽分类。
// 反向集合保留既有覆盖：Arabic/Hebrew、数字及许多符号也可能由 latin 角色策略处理。
#let latin-role-run = regex(
  "[^\p{Han}\p{Hiragana}\p{Katakana}\p{Hangul}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}"
  + "\u{00D7}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}"
  + "\u{00B7}\u{2014}\u{2018}-\u{201D}\u{2026}"
  + "\n\p{Co}\u{200B}\u{2060}]+"
)
#let has-latin-role(s) = s.contains(latin-role-run)

// CJK 触发的基线校正片段，可包含周围非 Latin 文本；不保证片段中每个字符都是 CJK。
// 两翼必须贪婪，避免逐字切开并触发 Typst 的分组深度上限。
#let cjk-baseline-run = regex(
  "(?:[^\p{Latin}\p{Co}\u{2060}\s][^\p{Latin}\p{Co}\u{2060}]*)?"
  + "[\p{Han}\p{Hiragana}\p{Katakana}\u{3000}-\u{303F}\u{FF00}-\u{FFEF}]"
  + "(?:[^\p{Latin}\p{Co}\u{2060}]*[^\p{Latin}\p{Co}\u{2060}\s])?"
)
#let role-tags = (
  songti: "izst", heiti: "izht", kaishu: "izks", kaishu-gb2312: "izkg",
  fangsong: "izfs", lishu: "izls",
)
#let role-features(role) = {
  if role not in role-tags { return (:) }
  role-tags.pairs().map(((r, tag)) => (tag, if r == role { 1 } else { 0 })).to-dict()
}
