#import "@local/docxtyp:0.1.0" as d
#import d.fonts: profile as _profile, is-profile as _is-profile
#import "./resolve.typ": lacks-bold, cjk-first, fontset-state, font
#import "./fake.typ": wants-bold-for, wants-bold, fake-bold
#import "./presets.typ": zh-roles, en-roles
#import "./regex.typ": role-features, latin-role-run

#let is-bold(weight) = if type(weight) == int { weight >= 600 } else {
  weight in ("semibold", "bold", "extrabold", "black")
}

#let ready(style) = {
  if "font" not in style { return false }
  let p = style.font
  if not _is-profile(p) or "iota-policy" not in p { return true }
  let source = p.iota-policy
  (source.asian-font == style.at("asian-font", default: source.asian-font)
    and source.latin-font == style.at("latin-font", default: source.latin-font)
    and source.weight == style.at("weight", default: "regular")
    and source.latin-bold == style.at("latin-bold", default: false))
}

#let _policy(doc, latin: false, profile: none) = context {
  let style = profile.iota-policy
  let asian = style.at("asian-font", default: "songti")
  let role = if latin { style.at("latin-font", default: "serif") } else { asian }
  let bold = is-bold(style.weight)
  let latin-bold = style.at("latin-bold", default: false)
  show: it => {
    if bold and wants-bold-for(role) {
      fake-bold(it, when: () => is-bold(text.weight) and wants-bold())
    }
    else if latin-bold and lacks-bold(asian) {
      set text(weight: "bold")
      if not lacks-bold("songti") {
        show cjk-first: set text(weight: "regular")
        it
      } else { it }
    } else { it }
  }
  if latin-bold and not lacks-bold(asian) {
    show latin-role-run: r => context {
      if text.font.contains(lower(fontset-state.get().math)) { r } else { text(weight: "bold", r) }
    }
    doc
  } else { doc }
}

#let typography(style, doc, latin: false) = {
  let p = style.at("font", default: auto)
  if not _is-profile(p) or "iota-policy" not in p { return doc }
  if not is-bold(p.iota-policy.weight) and not p.iota-policy.latin-bold { return doc }
  show: _policy.with(latin: latin, profile: p)
  doc
}

#let renderer(style, latin: false) = {
  let p = style.at("font", default: auto)
  if not _is-profile(p) or "iota-policy" not in p { return none }
  if not is-bold(p.iota-policy.weight) and not p.iota-policy.latin-bold { return none }
  _policy.with(latin: latin, profile: p)
}

// 角色只在 iota 的样式入口解析；docxtyp 收到原生字体和显式度量。
#let resolve(style, fontset, metrics: auto, strip: false, paragraph-defaults: true) = {
  let existing = style.at("font", default: auto)
  if existing != auto and not (_is-profile(existing) and "iota-asian" in existing) {
    return style
  }
  let asian = style.at("asian-font", default: if _is-profile(existing) { existing.iota-asian } else { "songti" })
  let latin = style.at("latin-font", default: if _is-profile(existing) { existing.iota-latin } else { "serif" })
  if asian not in zh-roles { panic("asian-font: unknown iota font role " + repr(asian)) }
  if latin not in en-roles { panic("latin-font: unknown iota font role " + repr(latin)) }
  let m = if metrics == auto { fontset.metrics } else { metrics }
  let key = (asian, latin, fontset.families, fontset.em-dash, m.at(asian), m.latin,
    style.at("weight", default: "regular"), style.at("latin-bold", default: false))
  if _is-profile(existing) and existing.at("iota-key", default: none) == key {
    let result = style
    if strip {
      let _ = result.remove("asian-font", default: none)
      let _ = result.remove("latin-font", default: none)
    }
    return result
  }
  let base = style
  let _ = base.remove("font", default: none)
  let primary = font(asian, fontset.families, latin: latin, em-dash: fontset.em-dash)
  let western = font(latin, fontset.families, asian: asian)
  let policy = (asian-font: asian, latin-font: latin,
    weight: style.at("weight", default: "regular"), latin-bold: style.at("latin-bold", default: false))
  let p = _profile(primary, metrics: m.at(asian), latin: western,
    latin-metrics: m.latin, features: role-features(asian)) + (
      iota-asian: asian, iota-latin: latin, iota-key: key, iota-policy: policy,
    )
  if strip {
    let _ = base.remove("asian-font", default: none)
    let _ = base.remove("latin-font", default: none)
  }
  // 模板样式显式补齐排版缺省；通用底层保持原生继承。
  base + (font: p, weight: policy.weight, tracking: style.at("tracking", default: 0pt),
    justify: style.at("justify", default: false)) + (if paragraph-defaults {
      (first-line-indent: style.at("first-line-indent", default: none),
        hanging-indent: style.at("hanging-indent", default: none))
    } else { (:) })
}

#let resolve-tree(table, fontset) = table.pairs().map(((name, entry)) => {
  if type(entry) != dictionary { return (name, entry) }
  let result = entry
  for (key, value) in entry {
    if type(value) == dictionary and key not in ("font", "inset", "stroke", "first-line-indent", "hanging-indent", "left-indent", "above", "below", "line-spacing") {
      result.insert(key, resolve-tree(((key): value), fontset).at(key))
    }
  }
  if "size" in result or "asian-font" in result or "latin-font" in result { result = resolve(result, fontset) }
  (name, result)
}).to-dict()
