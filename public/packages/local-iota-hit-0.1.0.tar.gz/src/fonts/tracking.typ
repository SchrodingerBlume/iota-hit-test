#import "../content.typ": plain-text
#import "../msword.typ": has-cjk
#import "./resolve.typ": boundary-loss
// 行内标记两侧把 tracking 补回来。
//
// *要治的毛病。* 字符网格靠 text(tracking:) 给每个汉字补一段字距增量
// 撑满一格，而 Typst 在切换 text run 时会丢掉该 run 最后一个字形的 tracking。
// 行内标记就是在造 run 边界，于是每处标记两侧各少一段：实测 `汉字*粗体*汉字`
// 的「字→粗」与「体→汉」都从 12.4543 掉到 12.0000。
//
// 这是 Typst 的原生行为，不是本模板引入的——`show regex` 哪怕函数体写成
// `it => it` 也照掉。两端对齐会把这点差摊到同一行的其余字缝上，行末仍然精确，
// 但标记处会局部窄一点。
//
// *补法。* 在标记两侧各发一段与 tracking 等长的间距。丢的*恒定*是
// 一段 tracking，与两侧是中文还是西文无关（实测中西两侧都是），所以补得回来
// 且不会补多。
//
// *长度不写死，读 text.tracking。* 这是唯一的源：正文、各级标题、页眉
// 各自的字距不同（标题还要加 tracking），用户也可能自己改；读当前生效的
// 值就永远对。实测把 tracking 改成 2pt，补偿跟着变，步进仍是 14.0000。
//
// *weak 不能省。* 标记落在行首或行尾时那段间距要丢掉，否则会多出一截
// 缩进或行末余量。weak 的间距正是这个语义。
//
// *后面那段 weak 会把紧跟着的一个裸空格顶掉，留着不改。* Typst 的弱间距取代后面的
// 空格（不取较大者，tracking 是 0 也一样），前面的空格不受影响。引用是 link，走这条
// 规则——中文里 `@fig 所示` 那个空格是 @ 语法逼出来的（`@fig所示` 读成标签
// fig所示），排出来该是「图1-1所示」，吃掉正好；要空格写 ~ 或 #" "。2026-09-17 试过
// 改成不 weak：显式敲的空格留住了，可全篇 `@fig 中文` 都多出一格，用户定了维持现状。
//
// *补不到的地方。* 用户自己写的 #box[…]、#text(…)[…]，以及第三方包造的
// run 边界——那些我们不知道名字，挂不上 show。另有一处边界情形：标记前紧挨
// 空格时（`汉字 *粗体*`），补偿落在空格上而不是前一个汉字上；中文里不会在
// 标记前打空格，影响很小。

// 补一段 tracking。部件层给中文标题里的西文加粗时也用它——那同样是
// 一处 run 边界，丢的同样是一段 tracking。
#let tracking-pad(it, probe: auto) = context {
  // *只给汉字强调补。* 这一份补的是「汉字 run 的末字被丢掉的那点字距」，
  // 只有强调自身是汉字时才谈得上。落在西文强调上会犯两个错：
  //
  //   一、多补 0.4543——实测「丙#emph[abc]丁」的两处边界是 12.9086 与 5.7805，
  //       而不加强调时同样的边界是 12.4543 与 5.3280；
  //   二、*把后面那个空格顶掉*——Typst 里显式的弱间距紧挨着空格时是取代它，
  //       不是取较大者，于是「_Externally_ pressurized」挤成了一个词。
  // probe 是「拿什么去判有没有汉字」。默认就判它自己；*内容被重建过的调用
  // 要显式给原件*——src/styles/body.typ 那条 show emph 把元素换成了 kaishu(…) 包着的
  // context 块，plain 钻不进 context，判出来永远没有汉字（实测汉字强调的字距掉回
  // 12.0000，该是 12.4543）。
  if not has-cjk(plain-text(if probe == auto { it } else { probe })) { return it }
  h(text.tracking * boundary-loss(), weak: true)
  it
  h(text.tracking * boundary-loss(), weak: true)
}

#let tracking-rules(doc) = {
  show strong: tracking-pad
  show emph: tracking-pad
  // underline 不在这儿：它的线要按 Word 改画法（一条通线、evade 关掉），补偿由 src/fonts/underline.typ 发一次
  show highlight: tracking-pad
  show strike: tracking-pad
  show link: tracking-pad
  show math.equation.where(block: false): tracking-pad
  doc
}
