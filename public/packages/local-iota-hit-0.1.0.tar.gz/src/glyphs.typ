// 画字：有限几个字不靠字体，按提出来的轮廓画。
//
// *三副字各有一小把*（数据在 *-outline.typ，由 tools/extract-outline.py 生成）：封面校名的
// 楷体、本科报告落款的隶书、深圳本科首页校名与文种的华文新魏。它们都是表单定死的几行，
// 装没装那副字不该影响印出来的样子——楷体_GB2312 不画，缺了回落到楷体（字形同源，
// 见 banshi/src/fonts/resolve.typ 的 role-chain），隶书与新魏没有近亲，回落到别的字就不是那一行了。
//
// *画面不参与度量，行高由那层真文本撑。* 先前是一个 height 写死的 box，它顶掉了模型
// 算出来的行高——实测封面校名（小二、行距 1.35）之后那一跳只有 18.0（正是
// (asc−desc)/upm × 字号），真楷体那边是 31.514（1.35 × 1.296875 × 18）。
// 试过「字形塞进零宽零高的 box 里 place 出去」，锚点是错的：实测框落在页面的 x 472 /
// y 0，零尺寸的盒子立不住 place 的容器。现在：盒子只写宽度，行内放那层透明真文本
// （它带来高度与基线，与真字体一模一样），字形 place 在同一个盒子里；字形顶距盒顶 =
// top-edge − 字体上升部，top-edge 是 style-rules.rules 写在 text 上的那一份。
//
// *字距照 Word 的 run 字距*：每个字的步进是字身加 text.tracking（深圳本科那两行
// 写着 w:spacing=20），透明文本整体横向缩放到与画出来的总宽一致，PDF 里复制出来就是
// 原文串，也避开了孤立全角标点触发的行首标点压缩。
#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts as fonts
#import banshi.content: plain-text

// 伪粗体描边系数：加粗时在填充轮廓外再以 (字号 × _bold-coef) 线宽描边。
// 系数由 Word 建立 docx 导出 PDF 实测标定：48.025pt 加粗 → "2 Tr 1.3721 w"，
// 24pt 加粗 → "2 Tr 0.68571 w"，两者均精确等于 字号/35；线型为 PDF 默认 miter join、
// miterlimit 10。
#let _bold-coef = 1 / 35

// 当前上下文是否按加粗渲染（#strong / *…* / text(weight: ..) 均生效）
#let _is-bold(wgt) = {
  if type(wgt) == int { wgt >= 600 } else { wgt in ("semibold", "bold", "extrabold", "black") }
}

// 渲染一段连续字符：矢量字形逐个排布，底下垫同一串透明文本
#let _render-run(font, s, bold) = context {
  let em = text.size
  let upm = font.upm
  let h = (font.asc - font.desc) / upm * em
  let tr = text.tracking
  let tracking = tr.abs + tr.em * em
  let chs = s.clusters()
  let total = chs.map(c => font.glyphs.at(c).adv / upm * em + tracking).sum()
  let f = text.fill
  let hex = if type(f) == color { f.to-hex() } else { "#000000" }
  let stroke-attrs = if bold or _is-bold(text.weight) {
    (
      " stroke=\"" + hex + "\" stroke-width=\"" + str(upm * _bold-coef)
        + "\" stroke-linejoin=\"miter\" stroke-miterlimit=\"10\""
    )
  } else { "" }
  let hidden = text(fill: rgb(0, 0, 0, 0), s)
  let nat = measure(hidden).width
  if nat > 0pt {
    hidden = scale(x: 100% * (total / nat), origin: left, reflow: false, box(width: nat, hidden))
  }
  let top-edge = text.top-edge
  let glyph-top = if type(top-edge) == length {
    top-edge.abs + top-edge.em * em - font.asc / upm * em
  } else { 0pt }
  let glyphs = box(width: total, height: h, {
    let x = 0pt
    for c in chs {
      let g = font.glyphs.at(c)
      let w = g.adv / upm * em
      if g.d != "" {
        let svg = (
          "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 "
            + str(g.adv) + " " + str(font.asc - font.desc)
            + "\"><g transform=\"translate(0," + str(font.asc)
            + ") scale(1,-1)\"><path fill=\"" + hex + "\"" + stroke-attrs
            + " d=\"" + g.d + "\"/></g></svg>"
        )
        place(top + left, dx: x, image(bytes(svg), width: w, height: h))
      }
      x += w + tracking
    }
  })
  box(width: total, {
    place(top + left, dy: glyph-top, glyphs)
    hidden
  })
}

// 把 body 展平成 (text, bold) 段：内嵌 *…*/#strong 记为粗体段
#let _segments(it, bold) = {
  if type(it) == str {
    if it == "" { () } else { ((text: it, bold: bold),) }
  } else if type(it) == content {
    if it.func() == strong { _segments(it.body, true) }
    else if it.has("text") { ((text: it.text, bold: bold),) }
    else if it.has("children") { it.children.map(c => _segments(c, bold)).sum(default: ()) }
    else if it.has("body") { _segments(it.body, bold) }
    else if it == [ ] { ((text: " ", bold: bold),) }
    else { () }
  } else { ((text: str(it), bold: bold),) }
}

// 按 font 画 body。字全得在收录里（空白原样过），出了收录当场报错——
// 要不要画由调用处先判（covered），这里不静默回落
#let outline-text(font, body) = {
  let merged = ()
  for s in _segments(body, false) {
    if merged.len() > 0 and merged.last().bold == s.bold {
      let l = merged.pop()
      merged.push((text: l.text + s.text, bold: s.bold))
    } else { merged.push(s) }
  }
  for seg in merged {
    let run = ""
    for ch in seg.text.clusters() {
      if ch in font.glyphs { run += ch }
      else if ch.trim() == "" {
        if run != "" { _render-run(font, run, seg.bold); run = "" }
        ch
      } else {
        panic(font.name + "-outline: 未收录字符「" + ch + "」，已收录: " + font.glyphs.keys().join())
      }
    }
    if run != "" { _render-run(font, run, seg.bold) }
  }
}

// 这几个字是不是都收录了
#let covered(font, s) = s.clusters().all(c => c in font.glyphs or c.trim() == "")

// 探针：一个家族能不能排汉字。要在 context 里调。
//
// *关掉回落再量*——缺字时 Typst 会静默换字体，量出来照样有宽度，问不出
// 「这个家族在不在」。关掉之后缺字宽度是 0（实测装了的 KaiTi / SimSun 出 200pt，
// 没装的 TW-MOE-Std-Kai 出 0pt）。
//
// *代价*：家族真的不存在时 Typst 会打一条 unknown font family 的警告，
// 这个探测会把它提前引出来——今天只有排到那一处才出现，往后每篇都会出现一次。
#let family-usable(family) = {
  measure(text(font: family, fallback: false, size: 100pt)[一二]).width > 0pt
}

// 隶书、新魏那一档：装了就用真字，没装、字又全在收录里就画；出了收录交回去，
// 让字体表的回落链接住（楷体 → 宋体）。要在 context 里调。
// 楷体那一档另有繁体的讲究，在 src/glyphs/cover.typ
#let outlined(role, font, body) = {
  if family-usable(fonts.fontset-state.get().families.at(role)) { return body }
  if covered(font, plain-text(body)) { outline-text(font, body) } else { body }
}
