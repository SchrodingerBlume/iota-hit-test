// 章号怎么印。
//
// *为什么要单开一处。* 图题、表题、分图题、公式、引用，五处都要排「章号-序号」，
// 先前各自写着同一段算术：
//
//     let ch = counter(heading).at(loc)
//     numbering("1-1", if ch.len() > 0 { ch.first() } else { 0 }, ..seq)
//
// 到了附录，章号不再是数字而是*字母*（附录A 的图就是「图 A-1」），而
// numbering() 只吃整数，喂不进 "A"。所以整串不能再交给它，得拆成
// 「章号 + 分隔 + 序号」自己拼——拼法只该有一处。
//
// *一律收 location，不收当前位置。* 引用要在*被引对象*那一处求号
// （见 src/figure/refs.typ 的 number），图表索引也是（见
// src/pages/outline.typ）；两处都踩过「在用的地方求值，章计数器还停在 0」
// 那个坑。收 loc 就没有第二种用法。
#import "./numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-of

// 现在排的是不是附录，以及附录的章号用哪一种数。
//
//   none  正文——章号是阿拉伯数字
//   串    附录——章号按这个编号串印（"A" ／ "1" ／ "一" ／ "One"，见
//         src/document/matter.typ 与 src/heading/numbering.typ）
//
// *存成串而不是布尔*：这一处只管「怎么印」，「用不用字母」那个开关在入口
// 处已经解成串了，下游不必再认识学位。
#let appendix-numbering = state("iota-hit-appendix-numbering", none)

// 附录只有一章时，章号那一位整个不存在——章标题就叫「附录」「Appendix」，
// 中文档的图表跟着少一位（「附图1」）。由 src/document/matter.typ 数好写进来
#let appendix-single = state("iota-hit-appendix-single", false)

// 附录里的图表公式，章号那一位怎么印、名前加不加「附」。四种情形：
//
//   正文             1        图1-1
//   附录·英文档      A        Fig. A-1 ——*不论章标题的号印的是什么*
//   附录·中文·字母   A        图A-1
//   附录·中文·数     没有／1  单个附录「附图1」，多个「附图1-1」
//
// *英文档一律用字母*：英文里没有「附图」这个词法，靠字母把附录的图表与正文
// 分开是英文通行的办法（APA 的 Table A1、GB/T 7713.1 的「图A.1」都是这个形状），
// 单个附录也照样印 A。所以「附」这个字只在中文档里出现，词条表也只有中文那一份。
//
// *中文·数那三档要加「附」*：附录1／附录一／Appendix One 的图表若照章号排，
// 印出来是「图1-1」（与正文第 1 章撞号）或者「图一-1」「图One-1」（不成话）。
// 单个附录连章号那一位都没有，也靠「附」与正文分开。
#let _en-doc() = doc-lang.get() == "en"

#let appendix-prefixed(loc) = {
  let pat = appendix-numbering.at(loc)
  if pat == none or _en-doc() { return false }
  appendix-single.at(loc) or _numbering.appendix-numeric(pat)
}

// 名前那个「附」，取自词条表；不该加就答 none。*三个条件*：这一处在附录里、
// 章号那一位不是字母（见上）、而且图表公式是*按章编号*的——连续编号那一档
// 附录的图接着正文往下数（图21），本来就不撞号，也就不必加。
//
// *中文档里的英文行也要加*——双语题注的英文行、英文那份插图索引，印的是
// 「Appendix Fig. 1-1」。同一张图两行只能是*同一个号*（1-1），所以两行要分开
// 就只能分在名上；光中文那行加「附」的话，英文行的「Fig. 1-1」与正文那张一模一样。
// 这不与「英文档不发明附」冲突：*英文档*的附录用字母（Fig. A-1），压根到不了
// 这里；「Appendix」只作为「附」在中文档里的译法出现
#let appendix-prefix(loc, lang, by-chapter: true) = if (
  by-chapter and appendix-prefixed(loc)
) {
  // 英文的名与名之间空一格，与「Fig. 1-1」那个空格同一条
  term-of(lang, "caption", "appendix") + (if lang == "en" { " " })
}

// 这一章的号，印在*图表公式*里是什么。答 none 就是「没有这一位」（中文档、
// 单个附录）。
//
// *与章标题自己的号是两回事*：标题印「附录一」，它的图印「附图1-1」；英文档
// 标题印「Appendix One」，图仍印「Fig. A-1」。标题那一份走 _numbering.appendix-mark，
// 见 src/document/matter.typ
#let chapter-mark(loc) = {
  let ch = counter(heading).at(loc)
  let n = if ch.len() > 0 { ch.first() } else { 0 }
  let pat = appendix-numbering.at(loc)
  if pat == none { return str(n) }
  // 英文档一律字母，见上；写了罗马数字的照写的——它与字母一样不与正文撞号
  if _en-doc() { return numbering(if pat == "I" { "I" } else { "A" }, n) }
  if appendix-single.at(loc) { return none }
  if _numbering.appendix-numeric(pat) { return str(n) }
  numbering(pat, n)
}

// 「章号-序号」，两侧可以再套括号（公式那一处要）。
//
// *序号那一位仍走 numbering*——它永远是数字，交给原生的好过自己 str()。
//
// *prefix 是给公式那一处的*：图表的「附」加在名前头（附表1-1），而公式在
// 版面上只有一个号、没有名，「附」只能挤进括号里——「（附1-1）」。所以这一位由
// 调用方给，图表那几处不传（它们的「附」进了名），见 src/math/math.typ
#let chapter-numbered(loc, seq, open: "", sep: "-", close: "", prefix: none) = {
  let mark = chapter-mark(loc)
  let head = if mark == none { "" } else { mark + sep }
  let pre = if prefix == none { "" } else { prefix }
  open + pre + head + numbering("1", ..seq) + close
}
