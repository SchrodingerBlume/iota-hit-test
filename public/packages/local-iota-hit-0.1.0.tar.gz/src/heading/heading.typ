// 章标题这一层。
//
// *住在这里而不是 frontmatter.typ*：结论是*正文*的组成部分
// （写作指南 1.4.3），它也要用拉开的不编号标题——正文的部件去 frontmatter
// 拿东西又是一次依赖方向倒置，正是上一轮刚修好的毛病。

#import "../terms/lookup.typ": term-table, term-for, info-variant
#import "../layout/resolve.typ" as _layout
#import "../info.typ": info-get, final-only-wanted
#import "../fonts/case.typ": english-title
#import "../errors.typ": once
#import "../content.typ": plain-text, fold-linebreaks, trim-tail, metadata-of
#import "../terms/lang.typ": en as en-mark, zh as zh-mark, find-en
#import "./spread.typ": spread-mark, spread-title
#import "../terms/lang.typ": resolve-lang

// ── 标题里的记号（挖的机制见 src/content.typ 的 metadata-of） ────────────

// 这一章要不要从右手页起。*三态*：true / false / none（没写，跟随文档级）。
//
// 内部件。用户写的是 #chapter(openright: …) 与部件的同名参数，由那些函数塞进来；
// src/heading/rules.typ 的章标题规则读它，读到什么就照什么切页——所以单处能盖过文档级，
// 两个方向都能盖。
#let openright-mark(value) = metadata((iota-openright: value))

#let find-openright(c) = {
  let r = metadata-of(c, "iota-openright")
  if r.len() == 0 { none } else { r.first() }
}

// 这一章自己的文档网格：#chapter(layout: (char-pitch: …))。只记局部字典，并到这一节的
// 版面上、写进 layout-state 是章标题那条 show 规则的事（src/heading/rules.typ），收哪些键
// 见 src/layout/resolve.typ 的 chapter-layout
#let layout-mark(local) = metadata((iota-layout: local))

#let find-layout(c) = {
  let r = metadata-of(c, "iota-layout")
  if r.len() == 0 { none } else { r.first() }
}

// 「这是 #chapter() / #section() 那一支发的标题」的记号。英文档里换正文槽的那条
// show 规则（src/heading/rules.typ）靠它认：markup 写法只换有编号的，词条页
// （numbering 为 none、整页回退中文的声明页）不换，而 #chapter(numbering: none, en: …)
// 得换——三者只凭 numbering 分不开
#let leveled-mark() = metadata((iota-leveled: true))

#let find-leveled(c) = {
  let r = metadata-of(c, "iota-leveled")
  if r.len() == 0 { none } else { r.first() }
}

// 目录条目里*必须在这儿折*的记号。标题里的换行本身在目录里是被折掉的
// （声明页那条两行的词条，见 src/pages/outline.typ），所以「只在目录里换行」得另起
// 一个记号：写在标题里不显示、不占位（metadata），目录取条目时换成 linebreak。
// 与 #en 同一套做法。「不许在这儿折」不用记号，写 ~（不断行空格）原生就认。
#let tocbreak() = metadata((iota-tocbreak: true))

// 把内容里的 tocbreak 记号换成换行。只走 sequence 一层层下去；记号夹在 strong、
// link 这类元素*里面*不认（重建那些元素会丢样式），写在标题正文里就够了。
// 换出来的 linebreak 带 justify: true——目录折标题换行的那条规则只折 justify: false
// 的（作者敲的 \ 都是这一种），这一种就留下了；目录不两端对齐，justify 本身没有作用。
#let replace-tocbreak(c) = {
  if type(c) != content { return c }
  if c.func() == metadata {
    let v = c.value
    return if type(v) == dictionary and "iota-tocbreak" in v { linebreak(justify: true) } else { c }
  }
  if c.has("children") {
    // 没有记号可换就原样交回，理由同 trim-tail
    let kids = c.children.map(replace-tocbreak)
    return if kids == c.children { c } else { kids.join() }
  }
  c
}

// 目录与页眉里一条标题是用户的还是学校的：#chapter() 那一支带 leveled 记号，markup
// 写法有编号；两样都没有的是词条页（term-chapter 发的）
#let heading-slot(h) = if find-leveled(h.body) != none or h.numbering != none { "heading" } else { "term" }

// 两字标题撑开的机制搬去了 src/heading/spread.typ（判据、开关、记号），这里只调
// 章标题的*正文槽*。字样、两份目录名的记号、右手页起的记号，都在这里。
//
// *不带 context，收已经解析好的 lang。* term-chapter 必须在*它自己那一个*
// context 里把这一份算出来——正文槽里再套一个 context，目录取条目时就穿不过去：
// 实测「Abstract」那一条的行盒从汉字基准的 19.45 掉成西文的 17.25，Word 是 18.75。
#let _term-body(
  name, lang,
  overrides: (:), spread: auto, bold: false, outlined: true,
  openright: auto, title: auto, toc-name: auto,
  // 这一部分只出一页（本硕、英文档、lang: 指定）：英文目录里就叫光名字（Contents），
  // 不带桶里 in-english-toc 的 (In Chinese) 尾巴——两页才需要分。摘要与清单是调用方在
  // context 里自己取了传 toc-name，目录走这一项：它的对拍件直接调 toc()，不在 context 里
  single: false,
  // 学科门类。字样按它挑：桶里有 title-hass 就取它，没有就取光键名的 title
  // ——两份范例的英文目录各是各的（声明页人文印 letter 小写、致谢人文印
  // Acknowledgments），见 src/terms/built-in.typ。调用方在 context 里读好传进来
  category: "stem",
) = {
  let t = term-table(lang, name, overrides: overrides)
  let by-category(table) = term-for(table, "title", info-variant() + (category: category))
  // *英文目录里这一条叫什么。* 默认就是这一部分*英文版的标题*
  // ——结论在英文目录里叫 Conclusions，那正是 en.conclusion.title。
  // 只有摘要与清单不是这样：一个部分两页，得把两页分别叫出来，所以它们在自己的桶里
  // 写了 in-english-toc。写错的覆盖挡得住（_resolve-key 逐键验），所以这一处
  // 的「有就用、没有就取 en 标题」不是静默兜底。
  // *toc-name 给按学位分档的标题用*：成果那一章中英字样都按学位换，
  // 桶里没有光键名的 title，调用方挑好了传进来（与 title 同一个理由）
  // *英文目录名存原文，不在这儿转大小写*：记号的取值由英文目录与页眉在印的时候
  // 各转各的（src/pages/outline.typ、src/layout/header.typ），这里再转一遍就是转两遍
  // ——第一遍把花括号剥了，第二遍就没有保护了（实测 Abstract (In {Chinese}) 印成
  // in chinese）。页面上自己印的那一份（下面的 name-text）才在这儿转
  let toc-name = if toc-name != auto { toc-name } else if not single and "in-english-toc" in t {
    term-for(t, "in-english-toc", info-variant() + (category: category))
  } else {
    by-category(term-table("en", name, overrides: overrides))
  }
  if spread not in (auto, true, false) {
    panic("spread: expected auto, true, or false, found " + repr(spread))
  }
  // *字样叫 title，撑开之后那一份叫 rendered*——同名再绑一次，读的人会以为
  // 是同一个东西，而它们差着「撑没撑开」这一步；spread 那个名也占着（是参数）。
  // 两字的撑一个字，见 src/heading/spread.typ；记号里存的是没撑的，目录与页眉各自再撑
  let name-text = if title != auto { title } else { by-category(t) }
  let name-text = if lang == "en" { english-title(name-text, slot: "term") } else { name-text }
  let rendered = spread-title(name-text, slot: "term", local: spread)
  // 两份目录名照样存成记号：中文目录取 zh 那一份（摘要页在中文目录里就叫
  // 「摘  要」），英文目录取 en 那一份（叫 Abstract (In Chinese)）。
  // 目录自己那一页默认不进目录（outlined: false），那时两份名字都不挂。
  // 换行会断开表达式（行首的 + 会被当成一元加），所以整串包在括号里
  (
    (if bold { text(weight: "bold", rendered) } else { rendered })
      + (if outlined { zh-mark(name-text) + en-mark(toc-name) })
      + (if spread != auto { spread-mark(spread) })
      + (if openright != auto { openright-mark(openright) })
  )
}

// 上面那一份的*薄壳*，自己解语言。
//
// *给 omni 的 bibliography 用*：它把 gb7714(title:) 收到的内容塞进自己的
// heading(level: 1, numbering: none, …) 里，所以那一处要的正是这一份体，不是整个
// term-chapter——整个塞进去就是 heading 套 heading，里层的章前跳页落进容器，
// 当场报 pagebreaks are not allowed inside of containers。
// 见 src/pages/references.typ。
#let term-title(
  name,
  lang: auto,
  overrides: (:),
  spread: auto,
  bold: auto,
  outlined: auto,
  openright: auto,
  title: auto,
  toc-name: auto,
  single: false,
) = context _term-body(
  name, resolve-lang(lang),
  overrides: overrides, spread: spread, bold: bold == true,
  outlined: outlined != false, openright: openright, title: title,
  toc-name: toc-name, single: single, category: info-get().category,
)


// 规范固定部分的章标题。
//
// *共用的只到这一层。* 结论、致谢、附录、参考文献、原创性声明这几部分
// 看着像同一个形状，其实不是：
//
//   结论 / 致谢    不编号标题 + *用户写的*正文
//   附录          还要切一整套编号制度（附录 A、图 A-1）
//   参考文献       条目是*生成的*，用户给的是一份 .bib
//   原创性声明     文字是*排好的*，还带签名栏；本科那份指南让去教务处
//                 网站下载（指南 1.7），连字样都不由我们定
//
// 真正共用的是这个标题：不编号、字拉开、挂英文目录名、进目录。所以原语落在
// 标题这一级，各部分自己去组合它还需要的东西。hithesis 那边同样是一个
// \hit@appendix@chapter* 顶在下面（hit-thesis.cls:8546）。
//
// *名字里的 chapter 是实话*——它排的永远是一级标题，摘要、目录、结论、
// 致谢、将来的参考文献附录声明，全是章级。叫 heading 会把它说宽，读的人会
// 以为能排出节。
//
// *名字说的是「字面从词条表来」*，不是「不编号」——不编号只是它五件事里的
// 一件，而且 #chapter(numbering: none) 与 <-> 那个糖也做同一件事，同名会撞。
// 它与普通章的实质区别是：标题字面、拉不拉开、英文目录里叫什么，全由词条桶给，
// 调用方只给桶名。见 src/terms/built-in.typ。
//
// *摘要与目录也走这一条。* 它们先前各自手搓了一遍「不编号 + 拉开 +
// 挂英文名」，三处一模一样。
//
//   name      词条桶名，见 src/terms/built-in.typ
//   lang      取哪一档词条。英文摘要页走 "en"
//   spread    两字标题撑不撑开：auto 跟文档级 title-spread、true / false 就地定。撑不撑
//             是判据（恰好两个汉字）说了算，开关只是让不让撑，见 src/heading/spread.typ
//   bold      标题要不要加粗。英文目录那一页要——实测研究生范例第九页的
//             「Contents」是 TimesNewRomanPS-BoldMT，hithesis 写的也是
//             \engcontentsname { \bfseries Contents }。中文标题不用：黑体
//             本身就是粗的，再加粗会走合成加粗
//   outlined  进不进目录。不进就不挂名字（目录自己那一页默认不进）
#let term-chapter(
  name,
  // 这一份用哪一层词条排。auto 跟随文档语言，写死的就照写的——中英摘要
  // 那两截是各自固定语言的两个部分，写死；结论、致谢、目录跟随文档。
  // 见 src/terms/lang.typ
  lang: auto,
  overrides: (:),
  spread: auto,
  // 加粗。auto ＝ 不写 ＝ 不加粗——黑体本身够重，规范也没要求。
  //
  // *这不是按语言分的。* 博士范例逐页量下来：「摘  要」「目  录」是
  // SimHei，英文摘要页的「Abstract」是 TimesNewRomanPSMT（*常规体*），
  // 只有英文目录的「Contents」是 TimesNewRomanPS-BoldMT。加粗是那一页自己的
  // 事，所以由调用方显式写 true，auto 一律解成不加粗。
  bold: auto,
  // 进不进目录。auto ＝ 不写 ＝ 进。目录自己那一页显式写 false
  outlined: auto,
  // 这一处要不要从右手页起。auto 跟随文档级，true / false 就地覆盖
  openright: auto,
  // 标题字样的就地覆盖。auto 取词条桶里的 heading。
  //
  // *给按学位分档的标题用*——声明页那一份本科是「哈尔滨工业大学本科毕业
  // 论文原创性声明和使用权限」、研究生是「哈尔滨工业大学学位论文原创性声明和
  // 使用权限」，两条都住在同一个桶里（title-bachelor / title-graduate），
  // 词条表按语言与页分桶，没有学位这一维，只能由调用方挑好了传进来。
  //
  // *不能叫 heading*——那是 Typst 的标题函数，下面正要用它，参数一同名
  // 就把它遮住了（实测 expected function, found content）。
  title: auto,
  // 英文目录里叫什么。auto 取桶里的 in-english-toc，再取英文桶的 title；
  // 按学位分档的（成果那一章）由调用方挑好了传进来
  toc-name: auto,
  // 只出一页时英文目录里叫光名字，见 _term-body
  single: false,
) = context {
  heading(
    level: 1,
    numbering: none,
    outlined: outlined != false,
    _term-body(
      name, resolve-lang(lang),
      overrides: overrides, spread: spread, bold: bold == true,
      outlined: outlined != false, openright: openright, title: title,
      toc-name: toc-name, single: single, category: info-get().category,
    ),
  )
}

// 四级标题的函数式写法。
//
// *= 那条路一行没改*，这一族是「要参数时」的写法。两处 = 表达不了：
//
//   openright   哪一章从右手页起。markup 标题带不了参数，只能在它前面手写
//               一句 clear-page(to: "odd")，还得记住放在标题之前
//   en          写成参数就没有顺序可错。marker 那条路上「= 甲 <a> #en[A]」会
//               *静默*丢掉英文名——label 之后的内容不算标题正文，见
//               src/terms/lang.typ 的 en
//
// *记号写进正文里与写成参数完全等价*：
//
//     #chapter(en: [Introduction])[绪论]      两者一样
//     #chapter[绪论 #en[Introduction]]
//
// 下面会把 body 里的记号提出来，连同它前面那个字面空格一起摘掉。两者都写
// 就参数优先——显式的外层赢。曾经只有参数式能换正文槽，同一个函数两种写法
// 行为不同（实测英文档里参数式印 Introduction、记号式仍印「绪论」），
// 而记号式还会让 find-zh 挖出 sequence([绪论], [ ], metadata(…))。
//
// *题注只有记号一条路*（figure 是 Typst 原生的，加参数得包壳），所以
// #en[…] 是全项目通用的写法，en: 留给标题是拼出来、不方便嵌记号的场合。
//
// *三条路两种能力*——换正文槽要能在不丢 label 的前提下改正文槽：
//
//     #chapter(en: […])[中文]        换。正文槽是中文字面，英文档由 show 规则换印
//     #chapter[中文 #en[…]]          换。等价于上一行
//     = 中文 #en[…] / 裸 heading()   有编号的换，没编号的不换（词条页要回落中文）
//
// *正文槽里放字面，不放 context。* 先前正文槽是 context { 按语言取 }，PDF 书签
// 取的是正文槽的*字面*（plain text），context 排出来的字它拿不到，书签里就只剩
// 编号（实测「第一章 」后面是空的）。换语言交给 src/heading/rules.typ 那条
// show 规则（与 markup 写法同一条），靠 leveled-mark 认出这一支。书签因此在中文档
// 里是完整的中文名；英文档的书签仍是中文名——Typst 书签只认字面，show 规则换
// 不了，重发 heading 又会把 label 连同 @ref 一起弄丢，这是已知限制。
//
// 名字用的是已有词汇：样式表的四个键就叫 chapter / section /
// subsection / subsubsection，对应写作指南 3.2 的章 / 节 / 条 / 款项。
//
// *openright 只有 chapter 收*——节不会另起一页，给它这个参数等于给一个
// 永远无效的东西。
//
// numbering 收 auto（跟随文档级）/ none（不编号）/ 任何 Typst 编号写法。
// 只想关编号的话，标签 <-> 更省事，见 src/heading/numbering.typ 的 nonumber-rules。
//
// warning：英文目录里这一条读着是中文时发不发红字，与 #en(warning:) 同义——参数式写法
// 的英文名走 en: 不经过 #en，所以这里也收一份，塞进同一个记号；没给 en: 也能写
// warning: false（不再报「没写英文名」）。auto 跟那一页的开关，见 src/pages/outline.typ 的 _en-warn
#let _leveled(level, body, en: none, numbering: auto, openright: auto, spread: auto, warning: auto, layout: auto) = {
  if spread not in (auto, true, false) {
    panic("spread: expected auto, true, or false, found " + repr(spread))
  }
  if warning not in (auto, true, false) {
    panic("warning: expected auto, true, or false, found " + repr(warning))
  }
  // 记号与参数等价，见上。摘记号用 trim-tail——它连同末尾的字面空格一起裁，
  // 那个空格是「绪论 #en[…]」里的，留着会跟进中文名，见 src/content.typ 的 trim-tail
  let marked = find-en(body)
  let en = if en != none { en } else { marked }
  let body = if marked != none { trim-tail(body) } else { body }
  // 章级版面：一级标题把「这一节 ⊕ 这一章」写进 layout-state，没写 layout 的退回这一节那份
  if level == 1 {
    context {
      let section = _layout.section-layout-state.get()
      if section != none {
        _layout.layout-state.update(if layout == auto { section } else { _layout.chapter-layout(section, layout) })
      }
    }
  }
  heading(
    level: level,
    ..(if numbering != auto { (numbering: numbering) } else { (:) }),
    // *两份名字都存成记号，正文槽放中文字面*（书签取它），英文档由 show 规则
    // 换印英文那一份，见上
    zh-mark(body)
      + (if en != none or warning != auto { en-mark(en, warning: warning) })
      + leveled-mark()
      + (if spread != auto { spread-mark(spread) })
      // *正文槽里手动换的行折掉*：书签取的是这一槽的字面，「研究\ 与实现」不折就成了
      // 「研究 与实现」（linebreak 后面还跟着一个 space 元素）。页面上印的是 zh 记号
      // 那一份（带换行），见 src/heading/rules.typ；markup 写法（= 标题\ 二行）
      // 没有记号、正文槽就是印出来的那一份，书签里那个空格是已知限制
      + fold-linebreaks(body)
      + (if openright != auto { openright-mark(openright) })
      + (if layout != auto { layout-mark(layout) }),
  )
}

// spread：两字的章标题撑不撑开（auto 跟文档级 title-spread），见 src/heading/spread.typ
// layout：这一章自己的文档网格（原稿第 1 章那一节是另一格），只收网格那一族键，作用到下一个
// 一级标题为止，见 src/layout/resolve.typ 的 chapter-layout
#let chapter(body, en: none, numbering: auto, openright: auto, spread: auto, warning: auto, layout: auto) = _leveled(
  1, body, en: en, numbering: numbering, openright: openright, spread: spread, warning: warning, layout: layout,
)
#let section(body, en: none, numbering: auto, warning: auto) = _leveled(2, body, en: en, numbering: numbering, warning: warning)
#let subsection(body, en: none, numbering: auto, warning: auto) = _leveled(3, body, en: en, numbering: numbering, warning: warning)
#let subsubsection(body, en: none, numbering: auto, warning: auto) = _leveled(4, body, en: en, numbering: numbering, warning: warning)

// 「章壳 ＋ 用户给的内容」——一整页只有这两样的那几页（结论、致谢、个人简历）。
//
// *与 term-chapter 同族，所以同住一处*：那一支发章标题，这一支把「章标题 ＋
// 内容」包成一个页面函数。三页先前是三份逐字节相同的复制品，差别只有一个桶名。
//
// *三页仍各留自己的文件*——一页一个文件是 pages/ 的规矩，函数体收成一行
// 不改变「哪一页在哪个文件」。
#let term-page(name) = (
  content,
  lang: auto,
  overrides: (:),
  openright: auto,
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
  // 两字标题撑不撑开。auto 跟文档级 title-spread，与 #achievements / #nomenclature /
  // #index 同款——term-chapter 两个都收，这一族没有理由少两个
  title: auto,
  spread: auto,
) => context {
  if not final-only-wanted(shown) { return }
  once(name)
  term-chapter(
    name, lang: lang, title: title, spread: spread,
    overrides: overrides, openright: openright,
  )
  content
}
