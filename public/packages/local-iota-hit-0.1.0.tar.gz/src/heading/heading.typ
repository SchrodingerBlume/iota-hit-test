
#import "@local/banshi:0.1.0" as banshi
#import "../terms/lookup.typ": term-table, term-for, info-variant
#import "../info.typ": info-get, final-only-wanted
#import "../settings/defaults.typ": two-hanzi-auto
#import "../settings/resolve.typ": setting-of
#import banshi.runs: has-cjk
#import banshi.styles as sheet
#import "../styles/lookup.typ" as _lookup
#import "../case.typ": english-title
#import "../once.typ": once
#import banshi.content: plain-text, fold-linebreaks, trim-tail, metadata-of
#import "../terms/lang.typ": en as en-mark, zh as zh-mark, original as original-mark, find-en, find-zh, own-of
#import "../terms/lang.typ": resolve-lang
#import "./numbering.typ": heading-top
#let openright-mark(value) = metadata((iota-openright: value))

#let find-openright(c) = {
  let r = metadata-of(c, "iota-openright")
  if r.len() == 0 { none } else { r.first() }
}
#let leveled-mark() = metadata((iota-leveled: true))
// 模板自己排的术语页标题（目录、摘要这类）：排在顶级，不受作者标题的层级报错管
#let term-mark() = metadata((iota-term: true))
#let is-term(c) = metadata-of(c, "iota-term").len() > 0

#let find-leveled(c) = {
  let r = metadata-of(c, "iota-leveled")
  if r.len() == 0 { none } else { r.first() }
}
#let tocbreak() = metadata((iota-tocbreak: true))
#let replace-tocbreak(c) = {
  if type(c) != content { return c }
  if c.func() == metadata {
    let v = c.value
    return if type(v) == dictionary and "iota-tocbreak" in v { linebreak(justify: true) } else { c }
  }
  if c.has("children") {
    let kids = c.children.map(replace-tocbreak)
    return if kids == c.children { c } else { kids.join() }
  }
  c
}
#let heading-slot(h) = if find-leveled(h.body) != none or h.numbering != none { "heading" } else { "term" }
// 标题套哪条样式：顶级不编号的是 term-heading，其余按相对级；样式表本身按阶段给，这里不问阶段
#let style-name(h, top: auto) = {
  let top = if top == auto { heading-top.get() } else { top }
  if h.level == top and heading-slot(h) == "term" { "term-heading" } else { "heading-" + str(h.level - top + 1) }
}
// 节那一层：四级的表（有章）是第二级，三级的表（报告）是顶级
#let section-style(styles) = if "heading-4" in styles { "heading-2" } else { "heading-1" }
// 全文作者自己写的标题里最高的一级（编号与否都算）：markup 的 = 只有 depth，heading(level:) 才有 level
#let _shallowest(c) = {
  if type(c) != content { return none }
  if c.func() == metadata and type(c.value) == dictionary and "iota-shallowest" in c.value { return c.value.at("iota-shallowest") }
  if c.func() == heading {
    let l = c.at("level", default: auto)
    return if l == auto { c.at("depth", default: 1) } else { l }
  }
  let kids = if c.has("children") { c.children } else if c.has("child") { (c.child,) } else if c.has("body") { (c.body,) } else { () }
  let best = none
  for k in kids {
    let r = _shallowest(k)
    if r == 1 { return 1 }
    if r != none and (best == none or r < best) { best = r }
  }
  best
}
// show: 规则当场套用，iota-hit 只看得见 matter 函数交出的 context：由它们把各自正文里最高的一级留作记号
#let shallowest-mark(doc) = { let l = _shallowest(doc); if l != none { metadata((iota-shallowest: l)) } }
// 无章的报告：全文有章命令（=）就是它当节，一个都没有就是 ==（hithesis 的老用户从 \section 起写）
#let report-top(doc) = if _shallowest(doc) in (none, 1) { 1 } else { 2 }
#let style-centered(name) = _lookup.current-styles().at(name, default: (:)).at("align", default: left) == center
#let heading-centered(h, top: auto) = style-centered(style-name(h, top: top))


#let _tri(v) = v in (auto, true, false)

#let check-two-hanzi(v) = if not _tri(v) {
  panic("two-hanzi: expected auto, true, or false, found " + repr(v))
}
#let _intersperse(body, gap) = {
  let s = if type(body) == str { body } else { plain-text(body) }
  if s == none { return body }
  let cs = s.clusters()
  if cs.len() <= 1 or (type(body) != str and body != [#s]) { return body }
  cs.intersperse(h(gap)).join()
}
#let two-hanzi(c) = {
  let s = if type(c) == str { c } else { plain-text(c) }
  if s == none { return false }
  let cs = s.trim().clusters()
  cs.len() == 2 and cs.all(has-cjk)
}
#let two-hanzi-title(c, centered: true, local: auto) = {
  if c == none { return none }
  let on = if local != auto { local } else if setting-of("two-hanzi") != auto { setting-of("two-hanzi") } else {
    two-hanzi-auto.at(info-get().degree-level, default: true)
  }
  if not on or not centered or not two-hanzi(c) { return c }
  _intersperse(c, 1em)
}
#let two-hanzi-mark(value) = metadata((iota-two-hanzi: value))

#let find-two-hanzi(c) = {
  let r = metadata-of(c, "iota-two-hanzi")
  if r.len() == 0 { auto } else { r.first() }
}
#let _term-body(
  name, lang,
  overrides: (:), two-hanzi: auto, bold: false, outlined: true,
  openright: auto, title: auto, toc-name: auto,
  single: false,
  category: "stem",
  centered: auto,
) = {
  let t = term-table(lang, name, overrides: overrides)
  let by-category(table) = term-for(table, "title", info-variant() + (category: category))
  let toc-name = if toc-name != auto { toc-name } else if not single and "in-english-toc" in t {
    term-for(t, "in-english-toc", info-variant() + (category: category))
  } else {
    by-category(term-table("en", name, overrides: overrides))
  }
  if two-hanzi not in (auto, true, false) {
    panic("two-hanzi: expected auto, true, or false, found " + repr(two-hanzi))
  }
  let name-text = if title != auto { title } else { by-category(t) }
  let name-text = if lang == "en" { english-title(name-text, slot: "term") } else { name-text }
  let centered = if centered == auto { style-centered("term-heading") } else { centered }
  let rendered = two-hanzi-title(name-text, centered: centered, local: two-hanzi)
  (
    (if bold { text(weight: "bold", rendered) } else { rendered })
      + (if outlined { original-mark([]) + zh-mark(name-text) + en-mark(toc-name) })
      + (if two-hanzi != auto { two-hanzi-mark(two-hanzi) })
      + (if openright != auto { openright-mark(openright) })
  )
}
#let term-title(
  name,
  lang: auto,
  overrides: (:),
  two-hanzi: auto,
  bold: auto,
  outlined: auto,
  openright: auto,
  title: auto,
  toc-name: auto,
  single: false,
) = context _term-body(
  name, resolve-lang(lang),
  overrides: overrides, two-hanzi: two-hanzi, bold: bold == true,
  outlined: outlined != false, openright: openright, title: title,
  toc-name: toc-name, single: single, category: info-get().category,
)
#let term-chapter(
  name,
  lang: auto,
  overrides: (:),
  two-hanzi: auto,
  bold: auto,
  outlined: auto,
  openright: auto,
  title: auto,
  toc-name: auto,
  single: false,
) = context {
  heading(
    level: heading-top.get(),
    numbering: none,
    outlined: outlined != false,
    term-mark() + _term-body(
      name, resolve-lang(lang),
      overrides: overrides, two-hanzi: two-hanzi, bold: bold == true,
      outlined: outlined != false, openright: openright, title: title,
      toc-name: toc-name, single: single, category: info-get().category,
    ),
  )
}
#let _leveled(level, body, numbering: auto, openright: auto, two-hanzi: auto, warning: auto) = {
  if two-hanzi not in (auto, true, false) {
    panic("two-hanzi: expected auto, true, or false, found " + repr(two-hanzi))
  }
  if warning not in (auto, true, false) {
    panic("warning: expected auto, true, or false, found " + repr(warning))
  }
  // 标记各归各；原文（去掉标记、折行之前的那份）另存一份，排出来的那份折了行
  let en = find-en(body)
  let zh = find-zh(body)
  let own = own-of(body)
  let own = if own == none { [] } else { own }
  heading(
    level: level,
    ..(if numbering != auto { (numbering: numbering) } else { (:) }),
    original-mark(own)
      + (if zh != none { zh-mark(zh) })
      + (if en != none or warning != auto { en-mark(en, warning: warning) })
      + leveled-mark()
      + (if two-hanzi != auto { two-hanzi-mark(two-hanzi) })
      // 排出来的那份折了行、剥了花括号（书签只认这一份的字面；大小写在渲染时按原文另算）
      + fold-linebreaks(english-title(own, mode: none))
      + (if openright != auto { openright-mark(openright) }),
  )
}
#let chapter(body, numbering: auto, openright: auto, two-hanzi: auto, warning: auto) = _leveled(
  1, body, numbering: numbering, openright: openright, two-hanzi: two-hanzi, warning: warning,
)
#let section(body, numbering: auto, warning: auto) = _leveled(2, body, numbering: numbering, warning: warning)
#let subsection(body, numbering: auto, warning: auto) = _leveled(3, body, numbering: numbering, warning: warning)
#let subsubsection(body, numbering: auto, warning: auto) = _leveled(4, body, numbering: numbering, warning: warning)
#let term-page(name) = (
  content,
  lang: auto,
  overrides: (:),
  openright: auto,
  shown: auto,
  title: auto,
  two-hanzi: auto,
) => context {
  if not final-only-wanted(shown) { return }
  once(name)
  term-chapter(
    name, lang: lang, title: title, two-hanzi: two-hanzi,
    overrides: overrides, openright: openright,
  )
  content
}
