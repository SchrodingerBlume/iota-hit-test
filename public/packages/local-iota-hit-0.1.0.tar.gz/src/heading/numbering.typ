// 编号：正文层次的代号、附录的代号、图表公式里的「章号-序号」、不编号的 <->。
//
// 两份《学位论文写作指南》各给了一张「表2  层次代号及说明」，逐格量过（新版
// g-stem.docx / g-hss.docx）：
//
//   层次   理工类            人文社科类     说明（两份一字不差）
//   章     第1章 □□…       第一章 □□…    章序及章名*居中*排
//   节     1.1 □□…         一、 □□…      题序*顶格*书写，与标题间空 2 个半角
//   条     1.1.1 □□…       （一）□□…     字符，阐述内容另起一段
//   款     1.1.1.1 □□…     1. □□…        （说明那一格是节到款的合并单元格）
//   项     （1）□□…        首先…其次…     题序空 4 个半角字符书写，内容*接排*
//
// *项不做*：它是接排的，题序与内容都空 4 个半角跑在同一段里，那是段落写法
// 不是标题，与 #chapter/#section 那一族不是一回事——理工那档的「（1）」同理。
//
// *版面那一层两份一字不差*（字号、行距、段前段后、页眉、图表、公式、参考文献、
// 成果、答辩决议、简历、书脊），落到版式上的差别只有编号这一处。
//
// *但不止编号不同*——人文社科那份还多一节「（十五）正文页下脚注」（①②③，理工
// 那份一个「脚注」都没有，包里还没做）；目录清单的措辞也不同（那份不含物理量表与索引）；
// 「索引」那份没有这一条，但那是「不排这一页」，不是换个字样。所以这一根轴只落在这个文件上，词条表一个字
// 都不动——axes 那张表自己的规矩就是「只放眼下真有词条按它分档的轴」，这一根是
// 例外中的例外：它分的不是词条，是编号。

// 「第1章」「1.1」「1.1.1」「1.1.1.1」。理工类那一份，也是默认
//
// *「第」「1」「章」之间不写空格。* 范例 docx 里那三段 run 直接相连，看着有空是 Word
// 「自动调整中文与西文的间距」加的 1/4 em（18pt 标题量到 4.75、9pt 页眉 2.25）；Typst 的
// cjk-latin-spacing 给的也是 1/4 em，写不写空格版面一样（四种写法探过，「1」落点相同）。
// 先前写着字面空格，PDF 里复制出来、书签里、检索时都是「第 1 章」，Word 是「第1章」
#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-of

#let hit-numbering(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "第" + str(n.at(0)) + "章" } else { n.map(str).join(".") }
}

// *开题与中期报告那一套*：「1」「1.1」「1.1.1」——没有「第X章」这一级。
//
// 出处是三份表单（硕士开题、硕士中期、博士开题）「说　明」页里的「层次代号及
// 说明」表，三份逐格相同：
//
//   节  1 □□……□        题序顶格书写，阐述内容另起一段（节条款三行合并的一格）
//   条  1.1 □□……□
//   款  1.1.1 □□……□
//   项  （1）□□…□      题序空 4 个半角字符书写，内容空 4 个半角字符接排
//
// 与论文那张「表2」逐字对得上，*只少了「章」那一行*——所以报告的第一级就是
// 论文的节。项照旧不做（它是接排的段落写法，不是标题），与论文同。
//
// *不分语言与门类*：三份表单的说明页一字不差，英文版表单也是同一张
// （硕士开题英文版、中期英文版的正文规定与中文版逐条相同）；数字本来也不分中西。
#let hit-numbering-report(..nums) = nums.pos().map(str).join(".")

// 英文档那一套：「Chapter 1」「1.1」「1.2.1」。范例的英文目录正是这样排的，
// 与中文那套同一个计数器、两种写法。见 src/pages/outline.typ
#let hit-numbering-en(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "Chapter " + str(n.at(0)) } else { n.map(str).join(".") }
}

// 人文社科类那一份：「第一章」「一、」「（一）」「1.」。
//
// *章序用汉字数字*（「章序用一、二、三、四……」），节与条各自只印*本级*
// 的序号——不是「一、1.」这种累加，表里的示例就是光秃秃的「一、」「（一）」「1.」。
// 第五级不做，理由见文件头。
#let hit-numbering-hass(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "第" + numbering("一", last) + "章"
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}

// 英文里的章序数词。人文社科范例的英文目录印的是「Chapter One」「Chapter Three」
// ——Typst 的 numbering 没有英文数词这一档，只能自己给一张表。
//
// *到二十为止*，再多回落成数字：一篇论文二十章已经离谱，而表越长越可能
// 抄错；回落成「Chapter 21」也读得懂，不是坏字。
#let en-words = (
  "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
  "Eighteen", "Nineteen", "Twenty",
)

// 第 n 个的英文数词。*章与附录共用*——英文目录里印的是「Chapter One」
// 与「Appendix One」，同一个计数写法，见 src/pages/outline.typ
#let en-word(n) = if n >= 1 and n <= en-words.len() { en-words.at(n - 1) } else { str(n) }

// 号那一位印出来是什么
#let appendix-mark(pat, n) = if pat == "One" { en-word(n) } else { numbering(pat, n) }

// *英文目录里*那一位印出来是什么：汉字数字那一档换成英文数词（附录一 →
// Appendix One），与「第一章 → Chapter One」同一个道理。字母与阿拉伯数字两种
// 文字通用，照印。见 src/pages/outline.typ
#let appendix-mark-en(pat, n) = if pat in ("一", "One") { en-word(n) } else {
  numbering(pat, n)
}

// 这一档的号是不是*数*。字母与罗马数字那两档（附录A、附录I）的图表与正文本来就
// 分得开（表A-1、表I-1 不会与正文的表1-1 撞），数那三档都会撞，图表公式得另加「附」
// ——判据只此一处，见 src/heading/numbering.typ
#let appendix-numeric(pat) = pat != none and pat not in ("A", "I")

// 人文社科类的*英文目录*那一份：「Chapter One」「一、」「（一）」「1.」。
//
// *只有章换成英文数词，节与条照旧是中文的顿号与括号*——《博士研究生学位论文
// 书写范例（人文社科类）》的英文目录逐条就是这样：
//
//     Chapter One  introduction            1
//     一、Problem introduction              1
//     （一）Research issue                  1
//     Chapter Three  realistic basis …     2
//
// 与理工那份（Chapter 1 / 1.1 / 1.2.1）的差别正好对应中文侧的差别，多的只有数词。
#let hit-numbering-hass-en(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "Chapter " + en-word(last)
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}

// 按文档语言、门类与*这一份是什么材料*挑一份。*写死了就照写的*——auto ≡ 不写
#let resolve-numbering(value, lang: "zh", category: "stem", stage: "final") = {
  if value != auto { return value }
  // *报告先分出去*：它的层次表自己写在表单的说明页上（见 hit-numbering-report），
  // 与论文那张表2 不是一回事，语言与门类都不进来
  if stage != "final" { return hit-numbering-report }
  if lang == "en" {
    return if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
  }
  if category == "hass" { return hit-numbering-hass }
  hit-numbering
}

// 英文目录那一份（中文档里博士要出的第二份目录）。同一张表，按门类挑
#let resolve-numbering-en(value, category: "stem", stage: "final") = {
  if value != auto { return value }
  // *报告先分出去*，与 resolve-numbering 同一条：报告的章印的是光「1」，
  // 不是「Chapter 1」——深圳本科英文版的目录里逐条量的就是这样（「1  Main
  // Research Contents…」），与它自己的正文标题一致
  if stage != "final" { return hit-numbering-report }
  if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
}

// ── 章号-序号：图表公式的号里那一位章号怎么印（Word「题注编号 → 包含章节号」） ──
//
// *为什么要单开一处。* 图题、表题、分图题、公式、引用，五处都要排「章号-序号」，
// 先前各自写着同一段算术：
//
//     let ch = counter(heading).at(loc)
//     numbering("1-1", if ch.len() > 0 { ch.first() } else { 0 }, ..seq)
//
// 到了附录，章号不再是数字而是*字母*（附录A 的图就是「图 A-1」），而
// numbering() 只吃整数，喂不进 "A"。所以整串不能再交给它，得拆成
// 「章号 + 分隔 + 序号」自己拼——拼法只该有一处。
//
// *一律收 location，不收当前位置。* 引用要在*被引对象*那一处求号
// （见 src/references/refs.typ 的 number），图表索引也是（见
// src/pages/outline.typ）；两处都踩过「在用的地方求值，章计数器还停在 0」
// 那个坑。收 loc 就没有第二种用法。

// 现在排的是不是附录，以及附录的章号用哪一种数。
//
//   none  正文——章号是阿拉伯数字
//   串    附录——章号按这个编号串印（"A" ／ "1" ／ "一" ／ "One"，见
//         src/layout/matter.typ 与 src/heading/numbering.typ）
//
// *存成串而不是布尔*：这一处只管「怎么印」，「用不用字母」那个开关在入口
// 处已经解成串了，下游不必再认识学位。
#let appendix-numbering = state("iota-hit-appendix-numbering", none)

// 附录只有一章时，章号那一位整个不存在——章标题就叫「附录」「Appendix」，
// 中文档的图表跟着少一位（「附图1」）。由 src/layout/matter.typ 数好写进来
#let appendix-single = state("iota-hit-appendix-single", false)

// 附录里的图表公式，章号那一位怎么印、名前加不加「附」。四种情形：
//
//   正文             1        图1-1
//   附录·英文档      A        Fig. A-1 ——*不论章标题的号印的是什么*
//   附录·中文·字母   A        图A-1
//   附录·中文·数     没有／1  单个附录「附图1」，多个「附图1-1」
//
// *英文档一律用字母*：英文里没有「附图」这个词法，靠字母把附录的图表与正文
// 分开是英文通行的办法（APA 的 Table A1、GB/T 7713.1 的「图A.1」都是这个形状），
// 单个附录也照样印 A。所以「附」这个字只在中文档里出现，词条表也只有中文那一份。
//
// *中文·数那三档要加「附」*：附录1／附录一／Appendix One 的图表若照章号排，
// 印出来是「图1-1」（与正文第 1 章撞号）或者「图一-1」「图One-1」（不成话）。
// 单个附录连章号那一位都没有，也靠「附」与正文分开。
#let _en-doc() = doc-lang.get() == "en"

#let appendix-prefixed(loc) = {
  let pat = appendix-numbering.at(loc)
  if pat == none or _en-doc() { return false }
  appendix-single.at(loc) or appendix-numeric(pat)
}

// 名前那个「附」，取自词条表；不该加就答 none。*三个条件*：这一处在附录里、
// 章号那一位不是字母（见上）、而且图表公式是*按章编号*的——连续编号那一档
// 附录的图接着正文往下数（图21），本来就不撞号，也就不必加。
//
// *中文档里的英文行也要加*——双语题注的英文行、英文那份插图索引，印的是
// 「Appendix Fig. 1-1」。同一张图两行只能是*同一个号*（1-1），所以两行要分开
// 就只能分在名上；光中文那行加「附」的话，英文行的「Fig. 1-1」与正文那张一模一样。
// 这不与「英文档不发明附」冲突：*英文档*的附录用字母（Fig. A-1），压根到不了
// 这里；「Appendix」只作为「附」在中文档里的译法出现
#let appendix-prefix(loc, lang, by-chapter: true) = if (
  by-chapter and appendix-prefixed(loc)
) {
  // 英文的名与名之间空一格，与「Fig. 1-1」那个空格同一条
  term-of(lang, "caption", "appendix") + (if lang == "en" { " " })
}

// 这一章的号，印在*图表公式*里是什么。答 none 就是「没有这一位」（中文档、
// 单个附录）。
//
// *与章标题自己的号是两回事*：标题印「附录一」，它的图印「附图1-1」；英文档
// 标题印「Appendix One」，图仍印「Fig. A-1」。标题那一份走 appendix-mark，
// 见 src/layout/matter.typ
#let chapter-mark(loc) = {
  let ch = counter(heading).at(loc)
  let n = if ch.len() > 0 { ch.first() } else { 0 }
  let pat = appendix-numbering.at(loc)
  if pat == none { return str(n) }
  // 英文档一律字母，见上；写了罗马数字的照写的——它与字母一样不与正文撞号
  if _en-doc() { return numbering(if pat == "I" { "I" } else { "A" }, n) }
  if appendix-single.at(loc) { return none }
  if appendix-numeric(pat) { return str(n) }
  numbering(pat, n)
}

// 「章号-序号」，两侧可以再套括号（公式那一处要）。
//
// *序号那一位仍走 numbering*——它永远是数字，交给原生的好过自己 str()。
//
// *prefix 是给公式那一处的*：图表的「附」加在名前头（附表1-1），而公式在
// 版面上只有一个号、没有名，「附」只能挤进括号里——「（附1-1）」。所以这一位由
// 调用方给，图表那几处不传（它们的「附」进了名），见 src/math/equation.typ
#let chapter-numbered(loc, seq, open: "", sep: "-", close: "", prefix: none) = {
  let mark = chapter-mark(loc)
  let head = if mark == none { "" } else { mark + sep }
  let pre = if prefix == none { "" } else { prefix }
  open + pre + head + numbering("1", ..seq) + close
}

// 「不编号」的糖：给任何东西打上 <-> 就不编号。
//
//     = 说明 <->
//     #figure(image("a.png"), caption: [示意]) <->
//     $ a = b $ <->
//
// 三种元素各一条规则。*拿 label 当开关*是 Typst 生态里的既成写法
// ——show ….where(label: …) 正是给这种用法留的。
//
// *打十次也不报错*：Typst 只在 @ref 指向重复标签时才报，而没人会去引用
// 一个「不编号」的记号。代价是它占掉了 label 位——「既不编号又要被引用」做不到，
// 而那个组合本来就不成立（引用要靠编号）。
//
// *不编号的也不进目录、不进图表索引。* 无论标题、图、表——目录与索引列的
// 是「编了号的东西」，不编号的条目在那里没有可指的序。Typst 原生的 numbering: none
// 不带 outlined: false（不编号的标题照样进目录），所以这里两条一起设。
// 公式没有 outlined 这一项。
//
// 别的不改：不编号的章仍然切页，字距行距照旧。「不编号 + 拉开字距 + 挂英文名
// + *进目录*」那一整套（摘要、结论那种）走的是 src/heading/heading.typ 的
// term-chapter——那几章是规范定的固定部分，进目录是它们的规矩，不经这里。
#let nonumber-rules(doc) = {
  show heading.where(label: <->): set heading(numbering: none, outlined: false)
  show figure.where(label: <->): set figure(numbering: none, outlined: false)
  show math.equation.where(label: <->): set math.equation(numbering: none)
  doc
}
