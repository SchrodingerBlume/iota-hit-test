#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-of
// 正文顶级是第几级：终稿恒为 1；无章的报告按正文第一个带编号的标题定（1 或 2），见 heading.typ 的 report-top
#let heading-top = state("iota-hit-heading-top", 1)

#let hit-numbering(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "第" + str(n.at(0)) + "章" } else { n.map(str).join(".") }
}
// 博后模板的章号是 Word 自动编号：编号标签里的汉字与数字之间 Word 不加自动空隙（硕博范例的章号是打上去的字，有）。
// Typst 按整段读 cjk-latin-spacing，段里的一截写 none 不起作用，装进盒子自成一段
#let hit-numbering-postdoc(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { box(text(cjk-latin-spacing: none, "第" + str(n.at(0)) + "章")) } else { n.map(str).join(".") }
}
#let hit-numbering-report(..nums) = nums.pos().map(str).join(".")
#let hit-numbering-en(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "Chapter " + str(n.at(0)) } else { n.map(str).join(".") }
}
#let hit-numbering-hass(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "第" + numbering("一", last) + "章"
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}
#let en-words = (
  "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
  "Eighteen", "Nineteen", "Twenty",
)
#let en-word(n) = if n >= 1 and n <= en-words.len() { en-words.at(n - 1) } else { str(n) }
#let appendix-mark(pat, n) = if pat == "One" { en-word(n) } else { numbering(pat, n) }
#let appendix-mark-en(pat, n) = if pat in ("一", "One") { en-word(n) } else {
  numbering(pat, n)
}
#let appendix-numeric(pat) = pat != none and pat not in ("A", "I")
#let hit-numbering-hass-en(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "Chapter " + en-word(last)
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}
#let resolve-numbering(value, lang: "zh", category: "stem", stage: "final", degree-level: "doctor") = {
  if value != auto { return value }
  if stage != "final" { return hit-numbering-report }
  if degree-level == "postdoc" and lang == "zh" { return hit-numbering-postdoc }
  if lang == "en" {
    return if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
  }
  if category == "hass" { return hit-numbering-hass }
  hit-numbering
}
#let resolve-numbering-en(value, category: "stem", stage: "final") = {
  if value != auto { return value }
  if stage != "final" { return hit-numbering-report }
  if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
}
#let appendix-numbering = state("iota-hit-appendix-numbering", none)
#let appendix-single = state("iota-hit-appendix-single", false)
#let _en-doc() = doc-lang.get() == "en"

#let appendix-prefixed(loc) = {
  let pat = appendix-numbering.at(loc)
  if pat == none or _en-doc() { return false }
  appendix-single.at(loc) or appendix-numeric(pat)
}
#let appendix-word(lang) = term-of(lang, "appendix", "prefix")

#let appendix-prefix(loc, lang, by-chapter: true) = if (
  by-chapter and appendix-prefixed(loc)
) {
  appendix-word(lang) + (if lang == "en" { " " })
}
#let chapter-mark(loc) = {
  let n = counter(heading).at(loc).at(heading-top.at(loc) - 1, default: 0)
  let pat = appendix-numbering.at(loc)
  if pat == none { return str(n) }
  if _en-doc() { return numbering(if pat == "I" { "I" } else { "A" }, n) }
  if appendix-single.at(loc) { return none }
  if appendix-numeric(pat) { return str(n) }
  numbering(pat, n)
}
#let chapter-numbered(loc, seq, open: "", sep: "-", close: "", prefix: none) = {
  let mark = chapter-mark(loc)
  let head = if mark == none { "" } else { mark + sep }
  let pre = if prefix == none { "" } else { prefix }
  open + pre + head + numbering("1", ..seq) + close
}
#let nonumber-rules(doc) = {
  show heading.where(label: <->): set heading(numbering: none, outlined: false)
  show figure.where(label: <->): set figure(numbering: none, outlined: false)
  show math.equation.where(label: <->): set math.equation(numbering: none)
  doc
}
