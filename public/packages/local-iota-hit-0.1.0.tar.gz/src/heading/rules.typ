
#import "@local/banshi:0.1.0" as banshi
#import banshi.content: plain-text
#import banshi.runs: has-asian
#import "../layout/matter.typ": clear-page, matter-openright
#import "./heading.typ": find-openright, find-leveled, heading-slot, style-name, heading-centered, two-hanzi-title, find-two-hanzi, is-term
#import "../terms/lang.typ": title-of, doc-lang
#import "../case.typ": english-title
#import "../settings/resolve.typ" as settings
#import "../settings/defaults.typ": heading-number-suffix
#import "../info.typ": info-get
#import "../native.typ": heading-sentinels, check-heading-show-set
#import "./numbering.typ" as _numbering
#let _body(it, top) = {
  let mine = it.numbering != none or find-leveled(it.body) != none
  if doc-lang.get() == "en" and mine {
    english-title(title-of(it.body, "en"))
  } else if mine {
    two-hanzi-title(title-of(it.body, "zh"), centered: heading-centered(it, top: top), local: find-two-hanzi(it.body))
  } else { it.body }
}
// 标题这一段按它那一档样式排：段前分页、段前段后、与下段同页、段中不分页；全西文的按西文行高；编号、编号之后、题名依次排
#let heading-rules(styles, top: 1, doc) = {
  show heading: it => context {
    let layout = banshi.layout.current-page-setup()
    let f = banshi.fonts.fontset-state.get()
    let style = styles.at(style-name(it, top: top))
    let sp = banshi.paragraph.spacing(style, layout: layout, metrics: f.metrics)
    let break-before = style.at("pagebreak-before", default: false)
    if break-before { pagebreak(weak: true) }
    // Word 保留手动分页后的段前：分页之后的页顶照给，别处由块间距给
    if break-before and sp.above != 0pt { v(sp.above, weak: false) }
    let bs = banshi.styles.block-spacing(if break-before { 0pt } else { sp.above }, sp.below)
    block(
      above: bs.above,
      below: bs.below,
      inset: (bottom: bs.inset.bottom),
      width: 100%,
      sticky: style.at("sticky", default: false),
      breakable: style.at("breakable", default: true),
      {
        let body = _body(it, top)
        let number = if it.numbering != none { counter(heading).display(it.numbering) }
        let text = plain-text(body)
        let latin = text.match(regex("[\\p{Latin}0-9]")) != none and not has-asian(text)
        show: banshi.styles.rules.with(style, layout: layout, families: banshi.paragraph.families-of(style, f, latin: latin), latin: latin)
        set align(style.at("align", default: left))
        show: if latin {
          banshi.paragraph.latin-box.with(style, layout)
        } else {
          banshi.paragraph.latin-line-rules.with(style, docgrid: layout.docgrid)
        }
        if number != none {
          // 编号以括号起头时垫一个零宽空格，躲开行首标点压缩
          if plain-text(number).starts-with(regex("[（［【「『〔《〈]")) { sym.zws }
          number
          // 编号尾字的字距在接缝处丢了，与目录的 run-pad 同一个补法：汉字一份、西文半份
          let tail-cjk = banshi.runs.has-cjk(plain-text(number).clusters().last())
          let pad = banshi.fonts.boundary-pad(layout.docgrid.tracking / (if tail-cjk { 1 } else { 2 }))
          let suffix = if settings.setting-of("heading-body-indent") == auto {
            heading-number-suffix.at(info-get().degree-level, default: none)
          }
          h(if suffix != none { pad + suffix } else {
            banshi.layout.resolve-chars(settings.resolve-heading-body-indent(
              lang: doc-lang.get(), category: info-get().category, level: it.level - top + 1,
            ), layout)
          })
        }
        body
      },
    )
  }
  doc
}
// 层级按指南表2：标题到款为止（有章四级、无章的报告三级），再往下是项，写列表；规范没定的就报错，不落到最近一档
#let heading-checks(numbering: none, chapter-pagebreak: true, top: 1, deepest: 4, doc) = {
  set heading(numbering: numbering)
  show: heading-sentinels
  show heading: it => {
    context check-heading-show-set()
    if not is-term(it.body) and it.level < top {
      panic(
        "heading " + "=" * it.level + " was hidden from the scan that decides a report's top level (inside context, "
          + "or a show rule of your own?): move it out so the template sees it",
      )
    }
    if not is-term(it.body) and it.level - top + 1 > deepest {
      let names = if deepest == 3 { "节/条/款 in a report" } else { "章/节/条/款" }
      panic(
        "heading " + "=" * it.level + " goes below 款: the guide's level table stops there (" + names
          + "); the next layer, 项 （1）, is a numbered list — write + items instead",
      )
    }
    context {
      if (
        it.numbering != none
          and it.numbering != numbering
          and _numbering.appendix-numbering.get() == none
      ) {
        panic(
          "heading numbering has no effect (the template numbers headings by the "
            + "guide's level table; write iota-hit(category: \"hass\") or "
            + "iota-hit(lang: \"en\") to switch schemes)",
        )
      }
    }
    if it.level == top and chapter-pagebreak {
      let mark = find-openright(it.body)
      context {
        let odd = if mark != none { mark } else { matter-openright.get() }
        clear-page(to: if odd { "odd" } else { none })
      }
    }
    it
  }
  doc
}
