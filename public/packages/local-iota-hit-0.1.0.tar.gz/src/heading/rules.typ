// 接到标题上。
//
// 对照 hithesis 的 src/utils/hit-format.dtx「接到标题上」一节。那边分三步：
// hit@format@compute:n 算，__hit_format_build:n 把字体字号行距对齐拼成一串
// 排版命令，hit@format@apply@heading:n 连着段前段后发给 \ctexset。
// 这边第一步是共用的 styles.resolve，后两步合成一个 show 规则。
//
// 有两样旧格式里有、这边有意不要的，照 hithesis 的原话：
// 一是行距的伸缩量——Word 的行距是刚性的，照 Word 建模就不发伸缩量；
// 二是各级标题的加粗——黑体本身够重，规范也没要求，要加粗写 bold: true。

#import "@local/banshi:0.1.0" as banshi
#import "../layout/matter.typ": clear-page, matter-openright
#import "./heading.typ": find-openright, find-leveled, heading-slot, levels, report-levels, heading-centered, two-hanzi-title, find-two-hanzi
#import "../terms/lang.typ": title-of, doc-lang
#import "../case.typ": english-title
#import "../settings/resolve.typ" as settings
#import "../info.typ": info-get
#import "./numbering.typ" as _numbering

// 对齐照 Typst 的词（left / center / right），键名 align。先前收 alignment: "centered"
// 这种自造的字符串，写错了静默靠左；现在不是 alignment 就报错
// 标题这一层归 banshi 装（banshi/src/styles/headings.typ：按级取样式、段前分页、段前段后、
// 编号与编号之后）；这里只给它那张关系表，加两条本模板自己的 show 规则：右手页起，与
// 「改了 numbering 报错」。

/// banshi.document(headings:) 那张关系表：第几级用哪条样式（报告整体上移一级）、题序与
/// 标题之间空多少（按语言与门类）、标题正文按语言取词条名／转大小写／两字撑开
#let heading-relation(levels: levels) = (
  // 按级取；词条页（摘要、结论那些一级标题）一律用章那一档，报告也是——报告的四级整体
  // 上移一格，词条页不跟着移
  link-level-to-style: it => if it.level == 1 and heading-slot(it) == "term" { "chapter" } else {
    levels.at(calc.min(it.level, levels.len()) - 1)
  },
  // 指南 3.2「题序与标题间空 2 个半角字符」＝ 一个字；英文档与人文那几档另有数，见
  // src/settings/defaults.typ 的 heading-body-indent-auto（Typst 列表里这一段就叫 body-indent）
  body-indent: level => settings.resolve-heading-body-indent(
    lang: doc-lang.get(), category: info-get().category, level: level,
  ),
  body: it => {
    let mine = it.numbering != none or find-leveled(it.body) != none
    if doc-lang.get() == "en" and mine {
      english-title(title-of(it.body, "en"))
    } else if mine {
      two-hanzi-title(title-of(it.body, "zh"), centered: heading-centered(it), local: find-two-hanzi(it.body))
    } else { it.body }
  },
)

/// 本模板在标题上自己的两条：章从右手页起（openright，按 matter 与标题上的记号定），
/// 以及用户改了 numbering 当场报错。装在 banshi 的标题规则之后（后定义的先跑）
#let heading-checks(numbering: none, chapter-pagebreak: true, doc) = {
  set heading(numbering: numbering)
  show heading: it => {
    context {
      if (
        it.numbering != none
          and it.numbering != numbering
          and _numbering.appendix-numbering.get() == none
      ) {
        panic(
          "heading numbering has no effect (the template numbers headings by the "
            + "guide's level table; write iota-hit(category: \"hass\") or "
            + "iota-hit(lang: \"en\") to switch schemes)",
        )
      }
    }
    // 右手页起：奇数页是分节符的档，Word 里每章就是一节。这里清到奇数页，banshi 那条
    // 段前分页随后落在页首，不再翻
    if it.level == 1 and chapter-pagebreak {
      let mark = find-openright(it.body)
      context {
        let odd = if mark != none { mark } else { matter-openright.get() }
        clear-page(to: if odd { "odd" } else { none })
      }
    }
    it
  }
  doc
}
