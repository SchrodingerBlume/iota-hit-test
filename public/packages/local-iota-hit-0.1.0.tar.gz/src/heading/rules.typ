
#import "../docxtyp.typ" as banshi
#import banshi.content: plain-text
#import banshi.paragraph: use-latin-metrics
#import "../layout/matter.typ": clear-page, matter-openright
#import "./heading.typ": find-openright, find-leveled, heading-slot, style-name, heading-centered, two-hanzi-title, find-two-hanzi, is-term
#import "../terms/lang.typ": title-of, doc-lang
#import "../case.typ": english-title
#import "../settings/resolve.typ" as settings
#import "../settings/defaults.typ": heading-number-suffix
#import "../info.typ": info-get
#import "../native.typ": heading-sentinels, check-heading-show-set
#import "./numbering.typ" as _numbering
#import "../pages/report/shenzhen/doctor-interim.typ" as _doctor-interim
#let _body(it, top) = {
  let mine = it.numbering != none or find-leveled(it.body) != none
  if doc-lang.get() == "en" and mine {
    english-title(title-of(it.body, "en"))
  } else if mine {
    two-hanzi-title(title-of(it.body, "zh"), centered: heading-centered(it, top: top), local: find-two-hanzi(it.body))
  } else { it.body }
}
// 标题这一段按它那一档样式排：段前分页、段前段后、与下段同页、段中不分页；全西文的按西文行高；编号、编号之后、题名依次排
#let heading-rules(styles, top: 1, doc) = {
  show heading: it => context {
    let layout = banshi.layout.current-page-setup()
    let f = banshi.fonts.fontset-state.get()
    let form = _doctor-interim.wanted(info-get())
    let row = if form and it.level == top { _doctor-interim.header-format.at(it.location()) } else { none }
    let style = styles.at(style-name(it, top: top)) + (if row == none { (:) } else {
      (above: 0pt, below: 0pt, first-line-indent: row.indent)
    })
    let sp = banshi.paragraph.spacing(style, layout: layout, metrics: f.metrics)
    let break-before = style.at("pagebreak-before", default: false)
    if _doctor-interim.wanted(info-get()) and _doctor-interim.frame-active.get() and it.level == top and not is-term(it.body) {
      _doctor-interim.divider()
    }
    if break-before { pagebreak(weak: true) }
    // Word 保留手动分页后的段前：分页之后的页顶照给，别处由块间距给
    if break-before and sp.above != 0pt { v(sp.above, weak: false) }
    let bs = banshi.styles.block-spacing(if break-before { 0pt } else { sp.above }, sp.below)
    block(
      above: bs.above,
      below: bs.below,
      inset: (bottom: bs.inset.bottom),
      width: 100%,
      sticky: style.at("sticky", default: false),
      breakable: style.at("breakable", default: true),
      {
        if not break-before and it.level == top and sp.above != 0pt {
          // 报告的顶层标题不自行分页，但 mainmatter／手动分页后的页首仍须保留段前。
          // 锚点放在标题块内部、补偿间距之前，避免“补间距→位置变了→撤销补偿”的循环。
          let key = (iota-heading-start: it.location())
          block(height: 0pt, above: 0pt, below: 0pt, sticky: true, metadata(key))
          context {
            let marks = query(metadata.where(value: key))
            // 页眉过高时底层会扩大实际天头；这里读取原生页面边距，而非预设中的 top。
            let top-edge = if type(page.margin) == dictionary { page.margin.at("top", default: layout.margin.top) } else { layout.margin.top }
            let top-edge = if type(top-edge) == relative { top-edge.length + top-edge.ratio * layout.paper-height } else { top-edge }
            if marks.len() > 0 and calc.abs(marks.first().location().position().y - top-edge) < 0.01pt {
              v(sp.above, weak: false)
            }
          }
        }
        let body = _body(it, top)
        // 栏目规划会预布局不可拆格；按原生标题位置读取，不能取预布局 context 的临时位置。
        let number = if it.numbering != none {
          if form { numbering(it.numbering, ..counter(heading).at(it.location())) }
          else { counter(heading).display(it.numbering) }
        }
        let text = plain-text(body)
        let latin = text.match(regex("[\\p{Latin}0-9]")) != none and use-latin-metrics(text)
        let first-line = banshi.paragraph.indent(style, layout: layout).first-line
        show: banshi.styles.rules.with(style + (first-line-indent: 0pt), layout: layout, font: banshi.paragraph.families-of(style, f, latin: latin), latin: latin)
        set align(style.at("align", default: left))
        show: if latin {
          banshi.paragraph.latin-box.with(style, layout)
        } else {
          banshi.paragraph.latin-line-rules.with(style, docgrid: layout.docgrid)
        }
        h(first-line)
        if number != none {
          // 编号以括号起头时垫一个零宽空格，躲开行首标点压缩
          if plain-text(number).starts-with(regex("[（［【「『〔《〈]")) { sym.zws }
          number
          // 编号尾字的字距在接缝处丢了，与目录的 run-pad 同一个补法：汉字一份、西文半份
          let tail-cjk = banshi.runs.has-cjk(plain-text(number).clusters().last())
          let pad = banshi.fonts.boundary-pad(layout.docgrid.tracking / (if tail-cjk { 1 } else { 2 }))
          let suffix = if settings.setting-of("heading-body-indent") == auto and it.level - top + 1 < 5 {
            heading-number-suffix.at(info-get().degree-level, default: none)
          }
          h(if row != none { row.gap } else if suffix != none { pad + suffix } else {
            banshi.layout.resolve-chars(settings.resolve-heading-body-indent(
              lang: doc-lang.get(), category: info-get().category, level: it.level - top + 1,
            ), layout)
          })
        }
        body
      },
    )
  }
  doc
}
// 人文社科终稿的“项”是无自动编号的文字段落。show-set 保留原生标题与标签，引用取题名。
#let _unnumbered-levels(first, last, doc) = {
  show heading.where(level: first): set heading(numbering: none)
  if first < last { _unnumbered-levels(first + 1, last, doc) } else { doc }
}
// 作者层级保留；编号、样式和目录按当前变体映射，不因“款”之后仍有标题而拒绝编译。
#let heading-checks(numbering: none, chapter-pagebreak: true, top: 1, unnumbered-from: none, deepest: 6, doc) = {
  set heading(numbering: numbering)
  show: heading-sentinels
  show heading: it => {
    context check-heading-show-set()
    if not is-term(it.body) and it.level < top {
      panic(
        "heading " + "=" * it.level + " was hidden from the scan that decides a report's top level (inside context, "
          + "or a show rule of your own?): move it out so the template sees it",
      )
    }
    context {
      if (
        it.numbering != none
          and it.numbering != numbering
          and _numbering.appendix-numbering.get() == none
      ) {
        panic(
          "heading numbering has no effect (the template numbers headings by the "
            + "guide's level table; write iota-hit(category: \"hass\") or "
            + "iota-hit(lang: \"en\") to switch schemes)",
        )
      }
    }
    if it.level == top and chapter-pagebreak {
      let mark = find-openright(it.body)
      context {
        let odd = if mark != none { mark } else { matter-openright.get() }
        clear-page(to: if odd { "odd" } else { none })
      }
    }
    it
  }
  if unnumbered-from != none and unnumbered-from <= deepest {
    show ref: it => context {
      let found = query(it.target)
      if found.len() == 0 or it.fields().at("form", default: "normal") == "page" { return it }
      let el = found.first()
      if el.func() != heading or el.level < unnumbered-from or el.numbering != none { return it }
      let given = it.fields().at("supplement", default: auto)
      let title = title-of(el.body, doc-lang.get())
      link(el.location(), if given in (auto, none, []) { title } else { given + sym.space.nobreak + title })
    }
    _unnumbered-levels(unnumbered-from, deepest, doc)
  } else { doc }
}
