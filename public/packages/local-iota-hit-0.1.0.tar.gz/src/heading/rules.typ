// 接到标题上。
//
// 对照 hithesis 的 src/utils/hit-format.dtx「接到标题上」一节。那边分三步：
// hit@format@compute:n 算，__hit_format_build:n 把字体字号行距对齐拼成一串
// 排版命令，hit@format@apply@heading:n 连着段前段后发给 \ctexset。
// 这边第一步是共用的 styles.resolve，后两步合成一个 show 规则。
//
// 有两样旧格式里有、这边有意不要的，照 hithesis 的原话：
// 一是行距的伸缩量——Word 的行距是刚性的，照 Word 建模就不发伸缩量；
// 二是各级标题的加粗——黑体本身够重，规范也没要求，要加粗写 bold: true。

#import "../styles/rules.typ" as style-rules
#import "../paragraph/latin.typ" as western
#import "../layout/matter.typ": clear-page, matter-openright
#import "./heading.typ": find-openright, find-leveled, heading-slot, levels, report-levels, heading-centered, two-hanzi-title, find-two-hanzi
#import "../terms/lang.typ": title-of, doc-lang
#import "../fonts/case.typ": english-title
#import "../paragraph/linebox.typ" as linebox
#import "../content.typ": plain-text
#import "../msword.typ": has-cjk
#import "../layout/chars.typ" as chars
#import "../settings/resolve.typ" as settings
#import "../info.typ": info-get
#import "./numbering.typ" as _numbering
#import "../layout/resolve.typ" as _layout

// 对齐照 Typst 的词（left / center / right），键名 align。先前收 alignment: "centered"
// 这种自造的字符串，写错了静默靠左；现在不是 alignment 就报错
#let _align-of(value) = {
  if type(value) != alignment {
    panic("align: expected alignment (left, center, or right), found " + repr(value))
  }
  value
}

// 把四级标题的取值算成行盒，再发成一条 show 规则。
//
// 段前段后落到 block 的 above / below。Word 相邻两段取段后与段前的较大者、
// 不相加，Typst 的块间距也是取大者，语义正好相同；页首的段前 Typst 也会丢掉，
// 与 TeX 和 Word 一致，所以章标题另起一页那一档不用另外处理。
//
// *块间基线距就是「上块行深 ＋ 下块上升部 ＋ max(上块段后, 下块段前)」，没有别的。*
// 先前照 hithesis 在外面再套一道 max(正文行距, …)——TeX 往竖直表里放盒子时的行间胶，
// 「两块接起来不够正文的 baselineskip 就补上」——Word 没有这一道，量过两处
// （2026-09-15）：
//
//   论文档探针  正文小四 1.25 → 款项标题小四黑体 1.2 → 正文：款项→正文 Word 18.50，
//              就是 18.675（款项那一行自己的行高）减去落笔取整；套了胶是 19.45
//   报告档正文  固定值 21 的正文 → 款项标题（小四 1.25、段前 0）：Word 16.3，
//              套了胶是 21.0；节／条也各多出 1.6／2.5——全篇标题逐个往下累
//
// Word 的模型里多倍行距多出来的那一截长在行*底下*（上升部不随倍数变，见
// src/styles/rules.typ），所以「正文→比它矮的块」这一跳本来就是正文一整行、用不着
// 补；「矮的块→正文」这一跳就是矮块自己那一行，Word 不补、我们也不补。

// *版面不在装规则时捕获。* 四级的行盒、段前段后（「一行」＝ 网格行距）、正文
// 那一份行盒（算内层那道 max 用）都在每个标题自己的 context 里按当前这一节的版面
// 现算——段级改了行跨度，章标题段前跟着换。样式表是文档级的，照旧传进来。
#let heading-rules(
  formats,
  font-table: (:),
  body-font: ("Songti SC",),
  numbering: none,
  // auto ＝ 要，见 lib.typ 的同名参数
  heading-1-pagebreak: auto,
  // 四级各按样式表里的哪一条排。报告走 report-levels，见上
  levels: levels,
  doc,
) = {
  let styles = levels.map(name => formats.at(name, default: (:)))

  let heading-1-pagebreak = heading-1-pagebreak != false

  set heading(numbering: numbering)

  show heading: it => context {
    let layout = _layout.current-layout()
    let computed = levels.map(name => linebox.metrics(
      formats.at(name, default: (:)),
      layout: layout,
    ))
    // *把「用户改了章节编号」拦下来。* 与图表编号、公式编号同一套哨兵（见
    // src/figure/caption.typ 与 src/math/rules.typ）：上面那句 set 摆在这一层，用户写
    // #set heading(numbering: …) 盖得住它、我们也就读得到他写了什么；闭包比得了
    // 身份，一改就分得出来。层次编号是规范定死的（两份指南各一张「表2 层次代号
    // 及说明」），改了排出来就不合格——实测 #set heading(numbering: "§1.") 得到
    // 「§1.」与章标题脱成两行、二级重复成「§1§1.」。
    //
    // *不拦两种*：none 是打了 <-> 的不编号标题（见 src/heading/numbering.typ 的 nonumber-rules）；附录那一档
    // 的编号是*我们自己*在 src/layout/matter.typ 里换的，按那个状态放行。
    context {
      if (
        it.numbering != none
          and it.numbering != numbering
          and _numbering.appendix-numbering.get() == none
      ) {
        panic(
          "heading numbering has no effect (the template numbers headings by the "
            + "guide's level table; write iota-hit(category: \"hass\") or "
            + "iota-hit(lang: \"en\") to switch schemes)",
        )
      }
    }
    let i = calc.min(it.level, levels.len()) - 1
    // *词条页的一级标题一律用「章」那一档*——目录、参考文献这些不编号的
    // 标题，深圳那四份表单上全是小二黑体居中，而报告里*正文*的一级标题是
    // 小三左起（说明页写的「节标题小3号」，见 report-levels）。两者是两回事：
    // 一个是「这一页叫什么」，一个是正文的层次。
    //
    // *终稿那一档本来就是章*，这一句在那儿是恒等式；本部报告的参考文献是
    // 编号的节（见 lib.typ 的 numbered-references），带编号 ＝ slot 判成 heading，
    // 也不走这一支
    let term-title = it.level == 1 and heading-slot(it) == "term"
    let metrics = if term-title {
      linebox.metrics(formats.at("chapter", default: (:)), layout: layout)
    } else { computed.at(i) }
    let style = if term-title { formats.at("chapter", default: (:)) } else { styles.at(i) }

    let family = font-table.at(style.at("font-zh", default: "heiti"), default: body-font)

    // *补出来的空白页要彻底空白*，所以走 clear-page 而不是裸的
    // pagebreak——那一条会把页眉页码带到空白页上，见 src/layout/matter.typ
    //
    // *单处能盖过文档级，两个方向都能。* 标题正文里若带着 openright 记号
    // （#chapter(openright: …) 与各部件的同名参数会塞），就照它；没带才跟随
    // 文档级。见 src/heading/heading.typ 的 openright-mark
    if it.level == 1 and heading-1-pagebreak {
      // 章跳不跳就是它所在那一段的事；标题正文里的记号是就地覆盖，
      // 两个方向都能盖。见 src/heading/heading.typ 的 openright-mark 与 src/layout/matter.typ
      let mark = find-openright(it.body)
      context {
        let odd = if mark != none { mark } else { matter-openright.get() }
        clear-page(to: if odd { "odd" } else { none })
      }
    }

    let above = metrics.above
    let below = metrics.below

    // *段前在页首不该被吞。* Typst 把块间距当作页首可丢的量，
    // 章标题跟在 pagebreak 后面，段前就没了——实测章标题首行落在
    // 版心顶 + 上升部，比 Word 少一个段前。Word 那边照发：范例的摘要页
    // 「摘  要」在 145.55，正是 107.75 + 19.55 + 20.56。
    //
    // 所以在页首改用一段*强*间距（weak: false，页首不丢），块自己的
    // above 置零；不在页首时仍走 block 的 above，好保住「相邻两块取大者」
    // 那套折叠——Word 的段前段后正是取大者，换成强间距就变成相加了。
    //
    // 判据不查落点，直接看「是不是刚发过 pagebreak」。
    // 用 here().position().y 与版心顶比也能判，但那是个布局查询——发出去的
    // 间距会改变下一轮的落点，实测 Typst 五轮迭代不收敛（会报
    // "document did not converge"）。章标题跟在 pagebreak 后面就一定在页首，
    // 这个判据是确定的，不进布局回路。
    //
    // *Word 那边发的其实是 max(0, 段前 − 前段段后)。* 段间距照常折叠成
    // max(前段段后, 本段段前)，但其中「前段段后」那一份已经花在*上一页
    // 页底*，只带超出的部分到新页。拿研究生范例的段落原文做过对照实验，只改
    // 前一段的段后，量新页首行：
    //
    //   前段段后    0     5.00   10.00   15.00   19.55   30.00  pt
    //   段前实得   19.52  14.52   9.52    4.52    0.00    0.00
    //
    //（范例第九页的「Contents」比同款章标题高 10.00，就是因为作者在它前面
    // 留了个 w:after=200 的空段——见 tests/check-toc-en.py。）
    //
    // 这里发的是*整份*段前。章标题前面挨着的是正文，正文段后是 0，
    // 两者一致；等哪天有部件在章标题前面留段后，再把这一条接上。
    //
    // *够不到的情形：* 关掉 heading-1-pagebreak 时的章标题，以及别级标题
    // 恰好被自然分页顶到页首——那两种仍会被 Typst 吞掉段前。要治得有个
    // 稳定的「我在不在页首」查询，上游眼下没有。
    let at-top = it.level == 1 and heading-1-pagebreak
    if at-top and above != 0pt { v(above, weak: false) }

    block(
      above: if at-top { 0pt } else { above },
      below: below,
      width: 100%,
      {
        // 字与段的设置交给部件层，与正文、封面共用同一套。
        // 标题的字距在那边是「吃网格就取网格那一份，不吃就取零，再加
        // tracking」——两项相加是 Word 的算法：docGrid 的字距被
        // snapToGrid=0 关掉，run 上的 w:spacing 照样生效，章标题正是这个情形。
        show: style-rules.rules.with(style, layout: layout, families: family)
        set align(_align-of(style.at("align", default: left)))
        context {
        // *题序与标题之间那一段自己排。* 本科指南 3.2：「题序顶格书写，与标题
        // 间空 2 个半角字符」——2 个半角就是 1 个全角。Typst 自己插的是 0.3em，
        // 章标题只空 5.4，而范例量到 ~17.9（节 ~15.8、条 ~14.7，都是那一级自己的
        // 一个字宽）。可配，见 src/settings/defaults.typ 的 heading-body-indent。
        //
        // *这一整块包在一个 context 里*，是为了先把要印的那份正文取出来
        // （英文档印 #en 那一份），再按它有没有汉字挑行盒——见下面那一句。
        let mine = it.numbering != none or find-leveled(it.body) != none
        let body = if doc-lang.get() == "en" and mine {
          english-title(title-of(it.body, "en"))
        } else if mine {
          // 居中的两字标题中间空一个字（two-hanzi-title）；词条页的标题在 term-chapter 里
          // 已经处理过，原样印。居不居中按这一级落到的样式看，报告的顶级是左起的节，不空
          two-hanzi-title(title-of(it.body, "zh"), centered: heading-centered(it), local: find-two-hanzi(it.body))
        } else { it.body }
        // *行盒按「这一段有没有汉字」挑，不按「哪几个 run 是拉丁字母」*：题序
        // 「2.1.1」是数字，run 那一档（latin-run）认的是拉丁字母，数字与点号是
        // Common、留在汉字那个 run 里——于是一行西文标题只要带着题序，整行就退回
        // 汉字行盒（英文报告实测章标题两行之间 26.65，原件 25.92）。判据与正文那条
        // 同源，见 src/paragraph/latin.typ 的 latin-auto；*标题这儿够不到 show par*
        // ——标题块里的那一段不是 par 元素，规则挂上去一次都不发（试过）。
        //
        // 这一份按*本级自己*的行距倍数算，不吃正文那一份。
        show: if (
          plain-text(body).match(regex("[\p{Latin}0-9]")) != none
            and not has-cjk(plain-text(body))
        ) {
          western.latin-box.with(style, layout)
        } else {
          western.latin-line-rules.with(style, docgrid: layout.docgrid)
        }
        if it.numbering != none {
          // 题序的加粗（英文档的报告标题在原件里是整行 Times Bold）跟着 latin-bold
          // 那两条路走：整段 set weight 或 latin-slot-run，数字都在里面，见
          // src/styles/rules.typ 的 shows。先前那条正则只认拉丁字母，这儿单独包过一层
          //
          // *行首的全角开括号前垫一个零宽空格。* Typst 把落在行首的全角开标点压成
          // 半格（字形往左挪半个字，墨迹顶着左缘），Word 不压：人文社科条级「（一）」
          // 对拍，Word 的「（」起点 85.0、「一」99.5，我们 77.8、92.3——整行左移半个
          // 四号字。垫了零宽空格括号就不在行首，起点回到 85.0（探针
          // scratchpad/paren.typ）。只在编号确实以开标点起头时垫，理工那三档的
          // 「第1章」「1.1」一个不可见字符都不多发；目录条目同一招，见 src/pages/outline.typ
          // *写 std.numbering*：这个函数的参数表里有一个叫 numbering 的（传进来的编号函数），
          // 光写 numbering(…) 调的是它——人文档里 hit-numbering-hass(it.numbering, 1) 得出
          // 「一、」，条件永远不成立，踩过
          if plain-text(std.numbering(it.numbering, ..counter(heading).get())).starts-with(regex("[（［【「『〔《〈]")) { sym.zws }
          counter(heading).display(it.numbering)
          context {
            // auto 按文档语言、门类与*本级*解：理工四级都一个字；人文社科
            // 章一个字、节与条不空、款半个字（编号自带顿号括号）；英文半个字（暂定）。
            // 见 src/settings/defaults.typ 的 heading-body-indent-auto
            let value = settings.resolve-heading-body-indent(
              lang: doc-lang.get(), category: info-get().category, level: it.level,
            )
            h(chars.resolve-chars(value, layout))
          }
        }
        // *英文档里印英文名。* 正文槽一律是中文字面（书签取它，见
        // src/heading/heading.typ 的 _leveled），英文名是个记号；英文档里有编号的标题、
        // 以及 #chapter() 那一支发的（带 leveled 记号，不论编不编号）印 #en 那一份，
        // 没写 #en 的照旧印中文（目录里会红字提示）。词条页的标题（numbering 为 none、
        // 不带 leveled 记号）不动——声明页那种整页回退中文的页，标题也跟着回落，
        // 它的英文名只给英文目录用。取哪一份在上面那个 context 的开头
        body
        }
      },
    )
  }

  doc
}
