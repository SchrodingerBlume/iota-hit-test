// 论文元信息：题目、姓名、学位、日期这些。
//
// 上半是默认表（info-defaults），只放值；下半是机制——state、写入时的校验与读取
// （info、info-get、value-of、date-fields）。

#import "./terms/built-in.typ": term-defaults

// 认得的键。写错键名是*静默失效*（存进去没人读），所以要挡住。
#let info-defaults = (
  // 学位层次：bachelor / master / doctor。*默认博士*：三档里它的页最全（双语题注、
  // 英文内封、双份索引……），不写就拿到全套；本硕写一行就少排
  degree-level: "doctor",
  // 学位类别：auto 按学位判（本科不发，研究生发学术学位）
  degree-type: auto,
  // *学科门类*：stem / hass，见 src/axes.typ。它*不印在任何页上*，
  // 住这儿是因为 degree-level 也是一根轴、也住这儿——各页要按门类分档时从同一处取。
  // 眼下只有正文层次的编号按它分，见 src/heading/numbering.typ
  category: "stem",
  // *交上去的是哪一种东西*：dissertation 写出来的论文，practice 做出来的成果。
  // 见 src/axes.typ 的 form——本科的「毕业设计」与硕博的「实践成果」是
  // 同一档，本科写 design 也认（别名），往下只见 practice。
  //
  // 两档的分量差得很远，都在词条表里：本科只改内封第一行勾哪个框（指南通篇写
  // 「本科毕业论文（设计）」，一个字都不换）；硕博是换一份指南，封面、内封、
  // 页眉、原创性声明的字全跟着换。
  form: "dissertation",
  // 哪一份材料：final 那份成果本身 / proposal 开题报告 / interim 中期报告。
  // 与 form 正交，见 src/axes.typ
  stage: "final",
  // 校区。harbin（本部，默认）／shenzhen。深圳的开题与中期是另发的一套表单，
  // 见 src/axes.typ 的 campus
  campus: "harbin",
  title: [`title`],
  // *带 -en 的那几条一律 auto ＝ 没写*，取值时回落到不带后缀的那一条
  // （src/info.typ 的 value-of）；显式写了就照写的来。
  //
  // *为什么不预置一份英文样例。* 双语的文档（论文）两边都得填，那是填表
  // 人的事；而*单语的文档*（英文版的开题与中期报告）整页只有一种语言，
  // 逼着他把同一个学院名写两遍毫无道理——「没写」就该拿他写过的那一条来用。
  // 预置样例反而更糟：忘了填时封面上印的是*别人论文里的那一句*，比印自己
  // 的中文题目更难发现。
  //
  // 先例是 defense-date-en（见下面），它一开始就是 auto。
  title-en: auto,
  // 英文题目的字号：auto 让算法判，塞得下就不缩
  title-en-xiaoer: auto,
  // 副题目。*没有就是 none*——「没有副题目」不是一个要写出来的值，也就
  // 没有 auto 那一档。「当题目内容层次很多，难以简化时，可采用主题目与副题目
  // 相结合的方法」（指南 2.1）。
  //
  // 中文另起一行、比主题目退 4 个半角字符、破折号起头，用小 2 号字；英文用
  // 冒号接在主题目*同一段*里（指南 3.3.1 末句）。内封「格式同封面」
  // （3.3.2 末句），所以封面与两页内封读的是同一对键。
  //
  // *字数不替用户数。* 主副题目字数之和「不应超过」35 个汉字（人文社科版
  // 是 40 个汉字或 80 个字符）——原话是「不应」不是「不得」，而且中英混排、
  // 数学符号在内，数出来的数不可信，数错了拦下一份能交的论文比不拦更糟
  subtitle: none,
  subtitle-en: none,
  author: [`author`],
  institution: term-defaults.zh.base.university,
  // *日期写 ISO*，yyyy / yyyy-mm / yyyy-mm-dd，写到哪一级就排到哪一级；
  // 中文档排「2022年6月」、英文档排「June, 2020」，同一个值两边同源。认不出
  // ISO 就原样排出，写 [二〇二二年六月] 照样能用。见 src/terms/date.typ
  date: [`date`],
  // 内封字段表填的那几项
  student-id: [`student-id`],
  supervisor: [`supervisor`],
  supervisor-en: auto,
  // 副导师与行业导师。*没有就是 none，整行不排*——指南 3.3.2 那张表的
  // 括注写的就是「无副导师的研究生不列此项」「无行业导师不列此项」。范例那位
  // 研究生两样都没有，所以默认也没有（别的字段默认是 □□□ 那种占位格子，
  // 这两个不是：占位格子说的是「这一行有、内容待填」）
  co-supervisor: none,
  co-supervisor-en: none,
  industry-supervisor: none,
  industry-supervisor-en: none,
  degree-applied: [□□博士],
  degree-applied-en: auto,
  speciality: [`speciality`],
  // 实践成果类型，只有 form: "practice" 用得上：封面那一行印「（专业学位
  // □□……□）」，□□……□ 就是它（调研报告、案例分析报告、产品设计报告、
  // 作品创作报告、方案设计报告、重大装备报告、仪器设备报告、硬件产品报告、
  // 软件产品报告、设计方案报告、技术标准报告、案例研究报告——《实践成果写作
  // 指南》表 2，按专业学位类别与*层次*分行：调研报告那五个是硕士层次的，
  // 重大装备报告那六个是博士层次的）。*不校验*——表 2 那句「表中未提及的
  // 专业学位类别，研究生可依据开展课题具体工作参考选用」说明它是参考不是定死。
  //
  // *默认是官方空白封页上那串占位方框*，与 author 的 □□□ 同款：忘了写
  // 就在封面上看得见，不会静默排成「（专业学位）」
  practice-type: [□□……□],
  speciality-en: auto,
  affiliation: [`affiliation`],
  affiliation-en: auto,
  defense-date: "2020-06",
  // *auto ＝ 从 defense-date 出英文*。手写一份别的仍然可以，口子留着
  defense-date-en: auto,
  author-en: auto,
  // *英文那一份不回落到中文校名*：auto 会退回 institution（中文词条），英文内封的
  // 「Degree-Conferring-Institution」就印成了汉字（博士范例整本对拍时量到的，2026-09-16）；
  // 默认取英文词条那一份，用户写了照写的
  institution-en: term-defaults.en.base.university,
  // 关键词。*它是著录用的元数据，不是摘要页的排版内容*——文献标引靠它，
  // 跟题目、作者同级；hithesis 也把 keywords 放在 cover 那个块里，与 title、
  // author 并排，而它的 abstract 文件里只有两段正文。
  //
  // 放这儿还顺手解决了摘要的形状：关键词一走，#abstract 只剩两份正文，
  // 于是能合成一次调用 #abstract(en: […])[中文]，与 #chapter(en: […])[…] 同款。
  keywords: (),
  keywords-en: (),
  // 内封表头那几格
  secrecy: [公开],
  classified-index: [××××],
  udc: [××××],
  school-code: [10213],
)

// ── 机制：state、写入时的校验与读取 ──────────────────────────────
//
// *一处填，各页读。* 封面、中文内封、英文内封印的是同一个题目、同一个
// 姓名；先前每个部件各自收参数，用户就得把题目抄三遍，改一处忘两处。
// 这里存进 state，各页从里面取——与 neu-typst-latest-cap-able 的 info-setup
// 同一个路子。
//
// *部件本身仍收显式参数。* 存进 state 的只是*默认值*：包装层把它们
// 填给部件，用户在调用处写的参数照样压过去。对拍件因此一行不用改——它们直接
// 调部件，根本不经过 state。

#import "./terms/date.typ" as _date

#let info-state = state("iota-hit-info", none)

// 哪几个字段是日期。*在写进来的时候就校*——报错指着用户那一行
// info(date: …)，比等到排封面时才炸在部件里好找。
#let date-fields = ("date", "defense-date", "defense-date-en")

// 行表里*一个字段的值*：按语言挑 info 的哪一份，日期走解析。
//
// *语言与字段身份是两回事*，所以在这一层统一贴——行表里不必逐行写
// author-en。写 -en 那一份的人少，没写就回落到原值：答辩日期只存一个 ISO，
// 中英各自排，不必存两遍。
//
// *只有日期字段走解析*。别的字段收到字符串是照排的——用户写
// author: "张三" 天经地义，不该被当成一个写坏了的日期。默认不把 lang 递给
// _date.render：日期跟 text.lang 走，各页自己设了语言。date-lang 给了才递——深圳
// 报告首页要拿 plain() 看这一格里有没有汉字来选行的度量，而跟 text.lang 走的日期是
// 个 context 块，plain() 看不进去；那一页自己设的 text.lang 就是它传进来的 lang。
//
// *内封与报告首页共用这一支*（src/pages/titlepage.typ 与 report/cover.typ
// 的行表）。先前报告那一页自己写了个简化版、少了 -en 那一步，于是*英文
// 报告封面的六格印的是中文值*——学院、导师、学科都是，只有题目单独特判过。
#let value-of(info, name, lang: "zh", date-lang: auto) = {
  let suffix = if lang == "en" { "-en" } else { "" }
  let v = info.at(name + suffix, default: auto)
  if v == auto { v = info.at(name) }
  if name in date-fields { _date.render(v, lang: date-lang) } else { v }
}

#let info(..fields) = {
  if fields.pos().len() != 0 {
    panic("unexpected argument")
  }
  for key in fields.named().keys() {
    if key not in info-defaults {
      panic("unexpected argument: " + key)
    }
  }
  for (key, value) in fields.named() {
    if key in date-fields and type(value) == str and _date.parse(value) == none {
      panic(
        "expected an ISO date such as \"2026\", \"2026-06\", or \"2026-06-05\", found "
          + repr(value) + " (write content like [" + value
          + "] to print it as given)",
      )
    }
  }
  info-state.update(old => {
    (if old == none { info-defaults } else { old }) + fields.named()
  })
}

// 取当前的元信息。要在 context 里调。
#let info-get() = {
  let v = info-state.get()
  if v == none { info-defaults } else { v }
}

// ── 这一页属不属于本篇 ──────────────────────────────────────────
// *stage 是一根轴*（src/axes.typ）：final 是终稿本身，proposal 与
// interim 是开题与中期那两份表单。绝大多数页面只在 final 出现——摘要、内封、
// 原创性声明、答辩决议这些，报告里根本没有这一页。
//
// *不属于本档的页面静默跳过。* 这样一份模板改一行 stage 就能出任何一档，
// 用户不必把十来行调用注释来注释去。
//
// *这一条是本包唯一容许的静默失效，写在这里免得日后被「修」掉。* 别处
// 一律相反——覆盖键落进没人读的桶、缩略语选项拼错、内封 fields 没透下去，
// 每一处都专门做了报错，注释里也写着「静默失效比报错糟」。这里反过来，
// 是因为它*不是错*：在开题报告里写 #abstract 不是手滑，是同一份模板
// 通吃三档时必然出现的写法。要排就写 shown: true，一个词的事。
// 这一页只在终稿出现。shown 三态：
//
//   auto   不写 ＝ 按档决定：final 排，报告不排
//   true   强制排——写在开题报告里也照排
//   false  强制不排，连 final 也按掉
//
// *名字与 outlined / indexed / printed 同一族*：过去分词，说的是「这一页
// 要不要参与这件事」。
//
// *这是一句判据，不是一层包装。* 先前它是 (..args) => …——套上去之后
// 那一页的签名就没了，编辑器只认声明出来的参数，沉没参数里的名字它看不见
// （api.typ 里那句「参数逐条写出来，不用 ..args 一兜」说的是同一件事）。
// 十二个终稿页因此整排补全不出来，连 shown 自己都补不出来。改成判据之后
// 各页自己收 shown、自己在头一句问一次，签名一个字都不必抄。
#let final-only-wanted(shown) = if shown != auto { shown } else {
  info-get().stage == "final"
}
