
#import "./terms/built-in.typ": term-defaults
#import "./terms/lang.typ": split as _split
#import "./settings/defaults.typ": shown-auto
#let canonical-field(name) = (
  student-number: "student-id", speciality: "specialty", speciality-en: "specialty-en",
  classified-index: "clc",
).at(name, default: name)
// 两种语言的字段：公开面只有一个键，英文那半写在 #en[] 里；表里仍是 zh / -en 两格，各页照旧按语言取
#let bilingual-fields = (
  "title", "subtitle", "author", "institution", "supervisor", "associate-supervisor",
  "industry-supervisor", "degree-applied", "specialty", "affiliation",
)
#let info-defaults = (
  degree-level: "doctor",
  degree-type: auto,
  category: "stem",
  form: "dissertation",
  stage: "final",
  campus: "harbin",
  title: [`title`],
  title-en: auto,
  title-en-xiaoer: auto,
  subtitle: none,
  subtitle-en: none,
  author: [`author`],
  institution: term-defaults.zh.base.university,
  date: (:),
  student-id: [`student-id`],
  supervisor: [`supervisor`],
  supervisor-en: auto,
  associate-supervisor: none,
  associate-supervisor-en: none,
  industry-supervisor: none,
  industry-supervisor-en: none,
  degree-applied: [□□博士],
  degree-applied-en: auto,
  specialty: [`specialty`],
  practice-type: [□□……□],
  specialty-en: auto,
  affiliation: [`affiliation`],
  affiliation-en: auto,
  author-en: auto,
  institution-en: term-defaults.en.base.university,
  secrecy: [公开],
  clc: [××××],
  udc: [××××],
  school-code: [10213],
  // 博后出站报告的编号与流动站；日期统一放在 date 中。
  report-number: [××××],
  station: [`station`],
)

#import "./terms/date.typ" as _date

#let info-state = state("iota-hit-info", none)
#let value-of(info, name, lang: "zh") = {
  let name = canonical-field(name)
  if name in ("date", "final-defense") {
    return _date.entry(info.date, if name == "date" { info.stage } else { "final-defense" },
      lang: lang)
  }
  let suffix = if lang == "en" { "-en" } else { "" }
  let v = info.at(name + suffix, default: auto)
  if v == auto { v = info.at(name) }
  v
}

#let canonical-fields(fields) = {
  let given = (:)
  for (key, value) in fields {
    let name = canonical-field(key)
    if name in given { panic("info: duplicate field " + repr(name) + " (including aliases)") }
    given.insert(name, value)
  }
  given
}
#let info(..fields, lang: "zh") = {
  if fields.pos().len() != 0 { panic("unexpected argument") }
  let given = canonical-fields(fields.named())
  for key in given.keys() {
    if key not in info-defaults { panic("unexpected argument: " + key) }
  }
  if "date" in given { given.insert("date", _date.checked(given.date)) }
  for key in bilingual-fields {
    if key in given and type(given.at(key)) == content {
      let s = _split(given.at(key), lang: lang)
      if not s.plain {
        given.insert(key, if s.zh == none { s.en } else { s.zh })
        given.insert(key + "-en", if s.en == none { s.zh } else { s.en })
      }
    }
  }
  info-state.update(old => {
    (if old == none { info-defaults } else { old }) + given
  })
}
#let info-get() = {
  let v = info-state.get()
  if v == none { info-defaults } else { v }
}
#let final-only-wanted(shown, page: none) = if shown != auto { shown } else {
  let i = info-get()
  i.stage == "final" and (page == none or shown-auto.at(page, default: (:)).at(i.degree-level, default: true))
}
