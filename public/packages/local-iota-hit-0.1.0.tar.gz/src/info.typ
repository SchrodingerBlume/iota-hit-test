
#import "./terms/built-in.typ": term-defaults
#import "./terms/lang.typ": split as _split
// 两种语言的字段：公开面只有一个键，英文那半写在 #en[] 里；表里仍是 zh / -en 两格，各页照旧按语言取
#let bilingual-fields = (
  "title", "subtitle", "author", "institution", "supervisor", "co-supervisor",
  "industry-supervisor", "degree-applied", "speciality", "affiliation", "defense-date",
)
#let info-defaults = (
  degree-level: "doctor",
  degree-type: auto,
  category: "stem",
  form: "dissertation",
  stage: "final",
  campus: "harbin",
  title: [`title`],
  title-en: auto,
  title-en-xiaoer: auto,
  subtitle: none,
  subtitle-en: none,
  author: [`author`],
  institution: term-defaults.zh.base.university,
  date: [`date`],
  student-id: [`student-id`],
  supervisor: [`supervisor`],
  supervisor-en: auto,
  co-supervisor: none,
  co-supervisor-en: none,
  industry-supervisor: none,
  industry-supervisor-en: none,
  degree-applied: [□□博士],
  degree-applied-en: auto,
  speciality: [`speciality`],
  practice-type: [□□……□],
  speciality-en: auto,
  affiliation: [`affiliation`],
  affiliation-en: auto,
  defense-date: "2020-06",
  defense-date-en: auto,
  author-en: auto,
  institution-en: term-defaults.en.base.university,
  secrecy: [公开],
  classified-index: [××××],
  udc: [××××],
  school-code: [10213],
)

#import "./terms/date.typ" as _date

#let info-state = state("iota-hit-info", none)
#let date-fields = ("date", "defense-date", "defense-date-en")
#let value-of(info, name, lang: "zh", date-lang: auto) = {
  let suffix = if lang == "en" { "-en" } else { "" }
  let v = info.at(name + suffix, default: auto)
  if v == auto { v = info.at(name) }
  if name in date-fields { _date.render(v, lang: date-lang) } else { v }
}

#let info(..fields, lang: "zh") = {
  if fields.pos().len() != 0 {
    panic("unexpected argument")
  }
  for key in fields.named().keys() {
    if key not in info-defaults {
      panic("unexpected argument: " + key)
    }
  }
  for (key, value) in fields.named() {
    if key in date-fields and type(value) == str and _date.parse(value) == none {
      panic(
        "expected an ISO date such as \"2026\", \"2026-06\", or \"2026-06-05\", found "
          + repr(value) + " (write content like [" + value
          + "] to print it as given)",
      )
    }
  }
  let given = fields.named()
  for key in bilingual-fields {
    if key in given and type(given.at(key)) == content {
      let s = _split(given.at(key), lang: lang)
      if not s.plain {
        given.insert(key, if s.zh == none { s.en } else { s.zh })
        given.insert(key + "-en", if s.en == none { s.zh } else { s.en })
      }
    }
  }
  info-state.update(old => {
    (if old == none { info-defaults } else { old }) + given
  })
}
#let info-get() = {
  let v = info-state.get()
  if v == none { info-defaults } else { v }
}
#let final-only-wanted(shown) = if shown != auto { shown } else {
  info-get().stage == "final"
}
