// iota-hit() 本体：文档级的那一个 show——六根轴、元信息、三态开关、样式表与页面设置在这一个
// 签名里收齐，然后把整条 show 规则链装上。前置页的公开包装（把 info 填给部件）在
// src/pages/front.typ；lib.typ 只 re-export 并配文档，用户看到的签名就是这里的签名。

// ── 内部件 ────────────────────────────────────────────────────────
// 整包挂在模块名下。别名带下划线，是因为 iota-hit() 的参数就叫 layout / styles / info /
// terms / settings——裸名会被参数遮住。公开面在 lib.typ 逐个 re-export，这里不导出什么。
#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing, amount
#import "./axes.typ": report-stages as _report-stages
#import "./axes.typ": final-body as _final-body
#import banshi.fonts as _fonts
#import "./heading/rules.typ" as _heading
#import "./heading/heading.typ" as _heading-mod
#import banshi.layout as _layout
#import banshi.layout: chars
#import "./layout/parts.typ": default-inputs as _default-inputs
#import "./math/equation.typ" as _equation
#import "./terms/lang.typ" as _lang
#import "./figure/caption.typ" as _captions
#import "./figure/split.typ" as _split
#import "./figure/kinds/table.typ" as _three-line
#import "./figure/kinds.typ": algorithm-kind as _algorithm-kind
#import "./figure/kinds/raw.typ" as _listing
// 缩略语：接 glossy 的那一层。主 show 把它的规则装在最内层，见那个文件
#import "./references/abbreviations.typ" as _abbreviations


// 版面：整份自己拼时用。局部改写不必经它——给 iota-hit(layout:) 一个字典就并到
// 本档默认上，字段表见 banshi/src/layout/resolve.typ；用户写 3.8cm，折缇是包里的事
// 中文字号：写 zihao.wuhao（10.5pt）。*字号只有这一种写法*——styles: (body: (size: zihao.xiaosi))、
// enter(size: zihao.erhao)、layout: (font-size: zihao.xiaosi)、set text(size: zihao.wuhao) 都是它；
// 先前包自己的口子还收字符串档名 "xiaosi"，同一个字号两种写法，删了

// 排版时会用到的几个函数

// 参考文献。*条目表就是 omni 自己那个 bibliography，我们不套壳*——套了
// LSP 就补不出它那七十多个参数。章壳走 gb7714(title:) 发进去，见那个文件
#import "./pages/references.typ": _omni, references-title as _references-title
#import "./references/bibliography.typ": gb7714-for as _gb7714-for
#import "@local/omni-gb7714:0.1.0": bibliography
#import "./heading/numbering.typ": nonumber-rules as _nonumber-rules
#import "./case.typ" as _case
// 只该印一次的页：公开名上套一层计数，页面模块自己不计——对拍件要在一篇里排
// 几份变体，直接调页面模块那一份。见 banshi/src/errors.typ


// 中文字族入口。写 songti(...) 而不是写家族名，换字体档自动跟上
#import banshi.fonts: songti, kaishu
// 六档字体方案那张表。
//
// *表叫 presets，参数叫 fontset*：表里装的是现成的几套，挑出来的那一套就是
// 这篇文档的 fontset——用户自己手写一份角色字典同样是 fontset，只是不是 preset。
//
// 「以某一档为底、改其中一两个角色」用 Typst 自己的字典合并就够了，不另造机制：
//
//     fontset: presets.founder + (kaishu: "TW-MOE-Std-Kai")
//
// 见 banshi/src/fonts/presets.typ
#import banshi.fonts: zihao

// 元信息与文档流
#import "./info.typ" as _info
#import "./settings/resolve.typ" as _settings
// *整模块导入，不平铺。* term-of 与 terms-overrides 是内部件，平铺进来
// 就会跟着 lib.typ 的 * 漏进用户作用域；而且 iota-hit 有个同名参数会遮蔽
// terms-overrides。挂在 _terms 下两件事一起解决。
#import "./terms/lookup.typ" as _terms
#import "./axes.typ" as _axes
#import banshi.errors as _errors
// 一节的 set（版心、页眉页脚、正文的字与段），文档级发一次，各段再发一次
#import "./layout/matter.typ" as _matter
// 附录。阶段开关，与 matter 同形：#show: appendix。章号换成「附录A」/「附录1」，
// 里面的图表公式跟着变成「图 A-1」，见 src/layout/matter.typ

// 样式表的机制：局部字典并到默认表（src/styles/presets.typ）上、键名验错、记进 state
#import banshi.styles as sheet
#import banshi.styles as _figure-spacing
#import "./styles/lookup.typ" as _lookup
// 局部样式 new-styles / restore-styles 住在 banshi/src/styles/local.typ，lib.typ 从那儿导出

#import "./styles/presets.typ" as _config-styles
#import "./settings/defaults.typ" as _config-settings
#import "./info.typ": info-defaults as _info-defaults

// 正文层次的四份编号预设。*不导出*——层次编号是规范定死的（两份指南各一张
// 「表2 层次代号及说明」），auto 按 lang 与 category 把官方那四种情形全覆盖了；
// 用户改了会被 src/heading/rules.typ 的哨兵拦下并指到那两个参数上。
// 取值与出处见 src/heading/numbering.typ
#import "./heading/numbering.typ" as _numbering

// 开题报告与中期报告那两档。*它们不是论文的一个变体*，是另发的表单：
// 版面、页眉页脚、页码三样全不一样，见 src/layout/presets.typ。

#let iota-hit(
  // 页面设置（Word 的「节」：页边距、文档网格、页眉页脚），见 banshi/src/layout/resolve.typ。
  //
  //   auto        按档：终稿一份，开题与中期按学位与阶段各一份（本科四边 2.3cm、
  //               无网格；硕博上左右 2.5cm、下边距各份各写、开着行网格），
  //               表在 src/layout/presets.typ
  //   局部字典    并到本档默认上：layout: (margin: (top: 3cm), header: (shown: false))
  //   整份        msword-layout(...) 就是整份替换
  //
  // 段与页还能再并：frontmatter / mainmatter / backmatter(layout:) 与各页函数的 layout:
  layout: auto,
  // 样式表（Word 的样式窗格：一条 = 字体对话框 + 段落对话框）。局部字典逐条并到
  // 默认表上，键是 body / chapter / section / subsection / subsubsection / caption /
  // toc-1 / toc-2 / toc-3 / toc-4：
  //
  //     styles: (body: (size: "wuhao"), chapter: (align: left))
  //
  // 每条能写什么、默认值与出处见 src/styles/presets.typ；不认识的键当场报错。
  // 页眉页脚的样式不在这里，住 layout.header.style / layout.footer.style。
  styles: (:),
  // 字体方案。*auto ＝ 不写 ＝ 模板决定*，默认档名只有 banshi/src/fonts/presets.typ 一份
  // （先前这里写死 "windows"，与那边的 default-preset 是同一个默认的两份抄本）
  fontset: auto,
  // 每个角色在 Word 里按哪副字算行高与上升部：角色 → 家族名（查 banshi 的 metrics 表）或
  // (single:, ascent:) 两个数。不写 ＝ 中易那一套加 Times，与本模板的目标字体一致。*与 fontset
  // 无关*——fontset 是这台机器上装的、拿来排的字体，metrics 是范例 .docx 里 w:rFonts 写的那副字
  // 的数，换 fontset 不动版面（tests/check-fonts.sh）。见 banshi/src/fonts/presets.typ 的 metrics
  metrics: (:),
  // 中文加粗、中文强调怎么合成，都是三态。auto 各问各的：伪粗问「这个字体有没有
  // 真粗面」，伪斜问「楷体在不在」——伪粗是真粗的替代品，伪斜是「换楷体」的第三
  // 顺位。取值与理由见 src/settings/defaults.typ 的 base 桶
  fake-bold: auto,
  fake-italic: auto,
  // *学科门类*，不是学位类别（那个是 degree-type）。学校的《学位论文写作指南》
  // 出成两份：（理工类）与（人文社科类）——两份逐条对过，*只有正文层次的编号
  // 不同*（第一章／一、／（一）／1.），字号行距段距一个数都不差。
  //
  //     #show: iota-hit.with(category: "hass")    人文社科类，"hss" 是同一档的别名
  //
  // auto ＝ 不写 ＝ "stem"。档名照学校自己的文件名（g-stem.docx / g-hss.docx），
  // 正名取含艺术的 hass，见 src/axes.typ
  category: auto,
  // 页码的样式。*auto ＝ 按 form 挑*：论文与实践成果排阿拉伯数字，开题与
  // 中期*不排页码*——两份表单的 default 页脚是空的（even 那一份里躺着一个
  // PAGE 域，可文档既没有 w:evenAndOddHeaders 也没有 w:titlePg，那个域不生效）。
  // 整篇论文由 #show: frontmatter 与 #show: mainmatter 两处切换，见 src/flow。
  page-numbering: auto,
  // 文档语言，收 "zh" / "en" / auto。*一篇一个值，中途改不了*——
  // 它定的是整篇的结构（标题取哪一份、词条走哪一层、目录出几份、页眉排哪一份、
  // 编号用哪一套），这些跨页的东西不该因为某一段切了语言就抖。见 src/terms/lang.typ
  //
  // *默认是 "zh" 而不是 auto*，这一处是 auto 约定的例外。auto 的意思是
  // 「跟 #show: iota-hit *之前*那句 #set text(lang: …) 走」，可 Typst 的
  // text.lang *默认就是 "en"*（实测 #context text.lang 给 en）——写 auto
  // 而外面什么都没设，读出来是英文。「不写＝中文」与「auto＝不写」两条只能留
  // 一条，留的是前者：绝大多数人写的是中文论文，不该先学一个开关。
  //
  // 所以三种写法：
  //
  //     #show: iota-hit                                  中文
  //     #show: iota-hit.with(lang: "en")                 英文
  //     #set text(lang: "en"); #show: iota-hit.with(lang: auto)   英文
  lang: "zh",
  // 英文标题的大小写：auto（＝本档默认，现在是 none）、none 原样、"sentence" 句式、
  // "title" 题式；也收字典按槽分——(term: 学校字样, heading: 章节名, caption: 题注
  // 英文名, rest: 兜底)，如 (term: none, rest: "title")。名与义照 omni 的
  // titles-text-case；花括号 {…} 里的不动（跟 .bib 一个方案，开没开都剥掉括号，
  // {{ }} 印字面）；词里有非首字母大写或数字的自动不动。见 src/case.typ
  title-case: auto,
  // 居中的两字标题中间空不空一个字（「摘  要」「绪  论」，固定一个字）：auto ＝ 空、
  // true / false。页函数与 #chapter() 的 two-hanzi: 就地压过它。见 src/heading/heading.typ
  two-hanzi: auto,
  // 参考文献那一层的配置，*原样透给 omni-gb7714*。
  //
  // *不在这儿列它的选项。* 那边有五十多个（style / version / cite-form /
  // note / cite-merge / 各种 punct-style……），抄一遍就是抄一份会烂的表：它加了
  // 我们不知道，它改了我们不跟。所以收一个字典整份摊过去——用户读它的文档，
  // 写什么我们传什么。
  //
  //     #show: iota-hit.with(gb7714: (style: "author-date", cite-form: "super"))
  //
  // 我们只按范例定了两条默认（文献表编号与类型标识用全角），压在 omni 的默认
  // 之上、用户这一份之下，见 src/pages/references.typ 的 gb7714-defaults。
  //
  // *omni 由我们装，用户不必再写 #show: gb7714*——装两遍是白装。
  // 条目怎么排见 src/pages/references.typ 的 bibliography。
  gb7714: (:),
  // ── 论文的元信息 ──────────────────────────────────────────────
  //
  // *与排版设定同住一个签名。* 先前它们分在 #info() 与 iota-hit()
  // 两处，而分界线不是自明的——degree-level 在那边、lang 在这边，两个都决定词条
  // 取哪一档。合成一处之后「写在哪」这个问题就不存在了，补全也一次给全。
  //
  // *一律 auto ＝ 不写 ＝ 取默认*。默认值住在 src/info.typ 的
  // info-defaults，那是唯一一份，这里不抄。写了才盖过去。
  //
  // title 就是*这篇文档*的标题，与原生的 document(title:) 同义；
  // 封面内封印的就是它。各部件的 title 是「那一块印的标题」，见 #toc(title:)。
  degree-level: auto,
  degree-type: auto,
  form: auto,
  // 哪一份材料：auto ＝ final（那份成果本身）／"proposal" 开题／"interim" 中期。
  // 与 form 正交，见 src/axes.typ
  stage: auto,
  // 校区：auto ＝ "harbin"（本部）／"shenzhen"。*眼下只有报告那两档按它分*
  // ——深圳的开题与中期是另发的一套表单（封面字段、落款、页眉、版面、题序间距
  // 逐条不同）；终稿的规范是全校一套。见 src/axes.typ 的 campus
  campus: auto,
  title: auto,
  title-en: auto,
  title-en-xiaoer: auto,
  // 副题目。「题目内容层次很多、难以简化时」才有，写了才排，见 src/info.typ
  subtitle: auto,
  subtitle-en: auto,
  author: auto,
  institution: auto,
  date: auto,
  student-id: auto,
  supervisor: auto,
  supervisor-en: auto,
  // 副导师、行业导师。*没写就没这一行*——指南那张表的括注写的就是
  // 「无副导师的研究生不列此项」，见 src/info.typ
  co-supervisor: auto,
  co-supervisor-en: auto,
  industry-supervisor: auto,
  industry-supervisor-en: auto,
  degree-applied: auto,
  degree-applied-en: auto,
  speciality: auto,
  // 实践成果类型（调研报告、产品设计报告……），只有 form: "practice" 用得上，
  // 见 src/info.typ
  practice-type: auto,
  speciality-en: auto,
  affiliation: auto,
  affiliation-en: auto,
  defense-date: auto,
  defense-date-en: auto,
  author-en: auto,
  institution-en: auto,
  keywords: auto,
  keywords-en: auto,
  secrecy: auto,
  classified-index: auto,
  udc: auto,
  school-code: auto,
  // 覆盖本地化词条，一层扁平字典：(titlepage-author-bachelor: [作者])
  // 只给要改的那几条，别的照旧。键名写错会报错，见 src/terms/lookup.typ
  overrides: (:),
  // 一级标题要不要另起一页——Word 里就是「标题 1」样式上那个「段前分页」的勾。
  // *按级不按名*：论文的一级是章，报告的一级是节（报告没有章），名字里因此写 1
  // 不写 chapter，与 toc-1～toc-4 同一套。auto ＝ 论文要（写作指南 3.2 的章是一级
  // 分界，范例里每一章都另起页）、报告不要（一节一页会把五千字排成五页）；
  // 关掉也给对拍件与短样张用
  heading-1-pagebreak: auto,
  // 右翻页的总闸，三态：false 一段都不跳 / true 三段都跳 / auto 各段用默认表。
  // 单段用 frontmatter / mainmatter / backmatter 的同名参数覆盖，单章单部件用
  // #chapter(openright:) 这些覆盖。见 src/settings/defaults.typ
  openright: auto,
  // 题注排不排双语，三态。auto 按学位：博士双语（中文在上、英文在下），
  // 本硕只中文。见 src/settings/defaults.typ
  caption-bilingual: auto,
  // 题注编号按不按章。三态：true「图1-1」并在章标题处重置 / false 全文连续
  // 「图1」不重置 / auto 查默认表（现在一律 true）。见 src/settings/defaults.typ
  //
  // *只有这条路。* 用户自己写 #set figure(numbering: "1") 盖不过我们——
  // 实测仍排「图1-1」，因为 show figure: set figure(numbering:) 里的 set 更内层。
  caption-numbering-by-chapter: auto,
  // 公式编号按不按章。三态，auto ＝ 按章（指南 2.11 明写）。*与题注那一条
  // 分开*——公式与图表是两个部件，共用一个开关就表达不了「图表按章、公式连续」。
  equation-numbering-by-chapter: auto,
  // 公式编号的括号用不用全角。三态，auto ＝ 半角（跟范例；指南的叙述写全角，
  // 两者矛盾，取印出来的那一个）。见 src/settings/defaults.typ
  equation-numbering-fullwidth: auto,
  // 缩略语要不要顺带登记进索引。默认不登记，见 src/settings/defaults.typ
  abbreviation-indexed: auto,
  // 编号列表的续行悬不悬挂。三态，auto ＝ 不悬挂（Word 范例的「（1）……」是普通
  // 段落）；单次覆盖 #enum-hanging[…]。见 src/settings/defaults.typ
  enum-hanging: auto,
  // 圆点列表的续行悬不悬挂。三态，auto ＝ 悬挂（指南没规定，照原生）；false 排成段，
  // 与编号列表同一个排法；单次覆盖 #list-hanging(false)[…]。见 banshi/src/paragraph/list.typ
  list-hanging: auto,
  // 缩略语：条目在印表的那一处声明（#list-of-abbreviations(条目) 或
  // #nomenclature(abbreviations: 条目)[…]），正文里写 @SCNA。这两条是正文里每个缩写怎么
  // 排的文档级开关：首次展开的括号逗号全角还是半角（auto 按用处语言）、缩写链不链到表
  // （auto ＝ 链）。见 src/references/abbreviations.typ
  abbreviation-fullwidth: auto,
  abbreviation-links: auto,
  // 分图号的写法与分隔，见 src/settings/defaults.typ
  subcaption-numbering: auto,
  subcaption-separator: auto,
  // *分图题*排不排双语。三态，auto ＝ 不排——规范说分图题「可以只用中文
  // 书写」，双语那句点的是图题与表题。与 caption-bilingual 分开，见
  // src/settings/defaults.typ
  subcaption-bilingual: auto,
  // 图题与连排分图题之间插什么。auto ＝ 什么都不插（范例就是紧挨着的）；收长度
  // 就空这么高，收内容就原样插进去（enter(1) ＝ 空一行）。见 src/settings/defaults.typ
  subcaption-gap: auto,
  // 题注里编号与题名之间空多少。收长度，与 Typst 的 enum(body-indent:) 同名同义。
  // auto ＝ 一个汉字宽（指南写「空 2 个半角字符」，两份范例印出来也是这个）。
  // 见 src/settings/defaults.typ
  caption-body-indent: auto,
  // 标题里题序与标题之间空多少。收长度，auto ＝ 一个汉字宽（指南 3.2「题序顶格
  // 书写，与标题间空 2 个半角字符」）。见 src/settings/defaults.typ
  heading-body-indent: auto,
  // 伪代码的样子，一个字典，键都收 auto：frame（"tabular" 默认 / "ruled" / "boxed"，
  // PlutoThesis 记的哈工大三个门派）、keyword-case（"upper" 默认 / "lower" / "title"）、
  // indent-guide（"bar" 默认 / "hook" / none）。见 src/settings/defaults.typ 与 src/figure/kinds/algorithm.typ
  algorithm-style: auto,
  // 代码清单（进了 figure 的代码块）的样子，与 algorithm-style 同型：frame（"tabular" 默认 /
  // "ruled" / "boxed" / none）、line-numbering（"1" 默认 / "1:" / "①" / 函数 / none）。
  // 见 src/settings/defaults.typ 与 src/figure/kinds/raw.typ
  raw-style: auto,
  // 破折号排中文字体（"cjk"，「——」中间断一截）还是西文字体（"latin"，连成一条）。
  // 三态，auto 按分支跟各自的原件：深圳的报告西文、其余中文。见 src/settings/defaults.typ
  em-dash: auto,
  // 附录的章号用字母还是数字。三态，auto 按学位——本科数字、硕博字母。
  // 就地压过写 #show: appendix.with(appendix-numbering: …)
  appendix-numbering: auto,
  // 目录条目正文右边留多宽——留出来是为了让长条目提前折行（指南 3.6）。
  // auto ＝ hithesis 的 4em。三份目录（目录、插图索引、表格索引）共用
  outline-entry-right-margin: auto,
  // 目录条目的编号怎么摆：auto / none 不取列、left 靠左取列、right 靠右取列。
  // 收 alignment，与 enum(number-align:) 同型。见 src/settings/defaults.typ
  outline-entry-number-align: auto,
  doc,
) = context {
  // *整个函数体包在 context 里*，为的是在自己那句 set text 之前读到
  // 外层的 text.lang——lang: auto 那一档要的正是「#show 之前设的那个值」。
  // 元信息写进 state，各页从里面取。*只把写了的传下去*——auto 那些留给
  // info-defaults，别拿一串 auto 把默认表盖掉
  // 门类。auto ＝ 不写 ＝ 理工类；别名（hss）在轴那一层折成正名，往下一律只见正名。
  // *要在写进 info 之前折*——各页从 info 取的得是正名
  // 两根轴同一个路子：auto ＝ 不写 ＝ 默认档；别名在轴那一层折成正名（hss → hass、
  // design → practice），*要在写进 info 之前折*——各页从 info 取的得是正名
  let resolve-axis(axis, value, fallback) = {
    let v = _axes.normalize(((axis): if value == auto { fallback } else { value })).at(axis)
    if v not in _axes.axes.at(axis) {
      panic(_errors.expected-one-of(_axes.axes.at(axis), v) + " (axis: " + axis + ")")
    }
    v
  }
  let category = resolve-axis("category", category, "stem")
  let form = resolve-axis("form", form, "dissertation")
  let stage = resolve-axis("stage", stage, "final")
  let campus = resolve-axis("campus", campus, "harbin")
  // 报告那两档的三样默认，全在这一处分：版面、页码、页眉页脚。*学位耦合与
  // 文种耦合都只住在默认表里*，写了就照写的
  let is-report = stage in _report-stages
  // 学位没写就按 info 的默认，与写进 info 的是同一个值
  let this-degree = if degree-level == auto { _info-defaults.degree-level } else { degree-level }
  // *正文照不照终稿排*，见 src/axes.typ 的 final-body：深圳本科那两份
  // 只有首页是表单，正文与终稿同构。首页、页眉、页脚仍走 is-report 那一支
  let report-body = is-report and not _final-body(campus, this-degree, stage)
  // 设定表按阶段分档的那几条（图表按不按章编号、题注双不双语、正文与标题的
  // 字与行距）跟着正文走
  let body-stage = if report-body { stage } else { "final" }
  // *参考文献编不编号*：本部那三份表单的「说　明」页把它列成正文内容的一条
  // （第 9／10 条），与「1．课题来源」并排——是编号的节；深圳那四份的目录里它与
  // 各章并排、不带号，正文里也是光三个字——照终稿排
  let numbered-references = report-body and campus != "shenzhen"
  // *版面按档挑，报告那一套还要再按学位与阶段挑一次*（本科那两份四边 2.3cm、
  // 无页眉页码、网格整个不启用；硕博三份上左右 2.5cm、下边距各份各写、开着行
  // 网格，见 src/layout/presets.typ）。用户的局部字典并在那一份上，整份就整份替换。
  let layout = _layout.merge-page-setup(
    _layout.page-setup(_default-inputs(
      degree-level: this-degree, stage: stage, campus: campus,
    )),
    layout,
  )
  let page-numbering = if page-numbering != auto {
    page-numbering
  } else if report-body { none } else { "1" }
  _info.info(..(
    ("degree-level", degree-level),
    ("degree-type", degree-type),
    ("category", category),
    // 交上去的是哪一种东西，见 src/axes.typ 的 form
    ("form", form),
    ("stage", stage),
    ("campus", campus),
    ("title", title),
    ("title-en", title-en),
    ("title-en-xiaoer", title-en-xiaoer),
    ("subtitle", subtitle),
    ("subtitle-en", subtitle-en),
    ("author", author),
    ("institution", institution),
    ("date", date),
    ("student-id", student-id),
    ("supervisor", supervisor),
    ("supervisor-en", supervisor-en),
    ("co-supervisor", co-supervisor),
    ("co-supervisor-en", co-supervisor-en),
    ("industry-supervisor", industry-supervisor),
    ("industry-supervisor-en", industry-supervisor-en),
    ("degree-applied", degree-applied),
    ("degree-applied-en", degree-applied-en),
    ("speciality", speciality),
    ("practice-type", practice-type),
    ("speciality-en", speciality-en),
    ("affiliation", affiliation),
    ("affiliation-en", affiliation-en),
    ("defense-date", defense-date),
    ("defense-date-en", defense-date-en),
    ("author-en", author-en),
    ("institution-en", institution-en),
    ("keywords", keywords),
    ("keywords-en", keywords-en),
    ("secrecy", secrecy),
    ("classified-index", classified-index),
    ("udc", udc),
    ("school-code", school-code),
  ).filter(((k, v)) => v != auto).to-dict())
  // 破折号那一档要在字体表解出来之前定：它是字体表里的一条 covers
  let em-dash = _settings.resolve-em-dash(
    local: em-dash, campus: campus, degree-level: this-degree, stage: stage,
  )
  let f = _fonts.fontset(value: fontset, em-dash: em-dash, metrics: metrics)
  // *语言的基线先算*：文档级的词条覆盖要用它（光键名的那一档落在文档主语言上，
  // 见 src/terms/lookup.typ 抬头），报告那两档的标题段前段后也按它分。auto 读外层设的
  let doc-lang = _lang.normalize(if lang == auto { text.lang } else { lang })
  // 样式表：局部并到默认，写进 state（目录三级从那儿取）
  // 各档与论文不一样的那几个样式值：*按语言取桶、档位写在键名上*（报告也是
  // 一档——stage 那根轴的 -not-final），表在 src/styles/presets.typ 的 variant-styles，
  // 查法在 src/styles/lookup.typ 的 variant-style。写 auto 的那几格是「这一档没有
  // 自己的数」，照终稿那一套排；*所以这儿不必判是不是报告*
  let variant-style(name) = _lookup.variant-style(
    name, lang: doc-lang, degree-level: this-degree, stage: stage, campus: campus,
  )
  // 正文行距。*正文照终稿排的那一档（深圳本科报告）只换行距*——它的标题走
  // 终稿那一套，可正文段写的是 1.25 倍、不贴行网格（那两份的 docGrid 一个没有
  // w:type、一个的正文段自己关了贴网格，量出来都是 19.44）
  let body-line-spacing = variant-style("body-line-spacing")
  // *英文档的报告标题，西文那一槽加粗*，加粗到第几级按学位分（中文桶与
  // 终稿都是 0，一级都不加）。*正文照终稿排的那一档（深圳本科）也吃这一条*
  // ——它的标题走终稿那一套，可英文版原件里章与节仍是 Times Bold
  let bold-upto = variant-style("heading-bold")
  let bold(level) = if level <= bold-upto { (latin-bold: true) } else { (:) }
  // *首行缩进只有一格与众不同*（深圳本科英文版三个字），auto ＝ 不覆盖
  let body-indent = {
    let v = variant-style("body-indent")
    if v == auto { (:) } else { (first-line-indent: v) }
  }
  // 行距同理：auto ＝ 这一档没有自己的数
  let body-spacing = if body-line-spacing == auto { (:) } else {
    (line-spacing: body-line-spacing)
  }
  // 章标题那一格：报告的行距与字距与终稿不同，见 variant-styles 的 chapter
  let chapter = variant-style("chapter")
  // 图表那一把伞（image / table / caption）：报告那几档与终稿不同（英文版装图段
  // 1.5 倍、四个空当各是各的数；深圳本科中文版图表与正文贴着排），见 variant-styles
  let figure-style = variant-style("figure")
  let styles = sheet.styles(_config-styles.default-styles, styles, preset: if is-report and not report-body {
    (
      body: (snap-to-grid: false) + body-spacing + body-indent,
      figure: figure-style,
      chapter: bold(1) + chapter, section: bold(2),
      subsection: bold(3), subsubsection: bold(4),
    )
  } else if not report-body { (:) } else {
    // 节与条的段前段后按文档语言分两档（中文 0.5 行、英文 6 磅），出处与探针
    // 见 src/styles/presets.typ 的 variant-styles；款项两版都是 0，不分
    let gap = variant-style("heading-spacing")
    // *只加粗西文那一槽*：英文档的标题在原件里是 Times Bold，可*黑体
    // 不该被伪粗*——黑体没有粗体面，整段加粗会让夹在英文标题里的汉字走描边合成。
    // 见 banshi/src/styles/rules.typ 的 latin-bold
    (
      body: body-spacing + body-indent,
      figure: figure-style,
      chapter: bold(1) + chapter,
      section: (above: gap, below: gap) + bold(2),
      subsection: (above: gap, below: gap) + bold(3),
      subsubsection: bold(4),
    )
  })
  // 章前分页：段落对话框的「段前分页」写进章那一档。*报告的节不另起页*——它没有「章」
  // 这一级，第一级是节，节前跳页会把一份五千字的报告排成一节一页；写 true 仍能强制跳
  let chapter-pagebreak = if heading-1-pagebreak != auto { heading-1-pagebreak } else { not report-body }
  let heading-levels = if report-body { _heading.report-levels } else { _heading.levels }
  // 写在章那一档（词条页也用它）与第一级链接的那一档上——报告的第一级是节，两处才都对
  let styles = styles + ("chapter", heading-levels.first()).dedup().map(name => (
    name, styles.at(name) + (page-break-before: chapter-pagebreak),
  )).to-dict()
  let body = styles.body
  let family = f.at(body.at("font-zh", default: "songti"))
  let body-metrics = spacing(body, layout: layout, metrics: f.metrics)
  // *overrides 只装词条。* 设定一律走具名参数——设定统共十来条，每条都在
  // 这个签名里列着，签名本身就是文档；再开一条字典的路，同一件事就有两种拼法，
  // 而且「两边都写了谁赢」还得再解释一遍。写错了当场报错并指路，见
  // src/settings/resolve.typ 的 not-a-term。
  if overrides != (:) { _terms.terms-overrides(overrides, lang: doc-lang) }
  // 具名参数压在 overrides 上：写了具名的以具名为准。
  //
  // *只写真的给了的那些*——具名参数一律默认 auto（＝不写＝模板决定），
  // 照单全写会把 overrides 里刚设好的值用一串 auto 盖回去（实测文档级
  // overrides: (heading-body-indent: 2em) 一点不生效）。
  _settings.settings-overrides(
    (
      openright: openright,
      fake-bold: fake-bold,
      fake-italic: fake-italic,
      caption-bilingual: caption-bilingual,
      em-dash: em-dash,
      algorithm-style: algorithm-style,
      raw-style: raw-style,
      equation-numbering-fullwidth: equation-numbering-fullwidth,
      abbreviation-indexed: abbreviation-indexed,
      enum-hanging: enum-hanging,
      list-hanging: list-hanging,
      subcaption-numbering: subcaption-numbering,
      subcaption-separator: subcaption-separator,
      subcaption-bilingual: subcaption-bilingual,
      subcaption-gap: subcaption-gap,
      caption-body-indent: caption-body-indent,
      // *深圳研究生那两份的题序与标题间空 1 个半角*（说明页的层次表写着），
      // 用户没写才用——它是这一档的默认值，不是硬规矩，见 src/settings/defaults.typ
      // 的 report-heading-body-indent
      heading-body-indent: if heading-body-indent != auto { heading-body-indent } else {
        let value = _config-settings.report-heading-body-indent
          .at(campus, default: (:))
          .at(this-degree, default: none)
        if is-report and value != none { value } else { auto }
      },
      appendix-numbering: appendix-numbering,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
    )
      .pairs()
      .filter(((k, v)) => v != auto)
      .to-dict(),
  )
  // 模板自己的 show 链，交给 banshi.document 装在字的规则之后、段的规则之前
  // （次序见 banshi/src/document.typ）。里面同一选择器上的先后是这儿自己排的
  // 图表编号按不按章：按阶段与学位解一次，题注关系表、题注规则与拆页规则三处共用
  let caption-by-chapter = _settings.resolve-caption-numbering-by-chapter(
    local: caption-numbering-by-chapter, stage: body-stage,
    campus: campus, degree-level: this-degree,
  )
  let rules(doc) = {
    set page(numbering: page-numbering)
    // *章节的引用不带 supplement，直接显示编号。*
    //
    // Typst 的 ref 一律排「supplement + 编号」，也就是「名在前」。图、表、附录
    // 正好是这个语序（指南 [197][214]：「见图1-1」「如表1-1所示」），章却不是
    // ——「第1章」是名字*包着*号，给 supplement: [第] 只会得到「第 1」；
    // 节更是连名都不要，指南自己写的是「具体编排方法见3.2」。
    //
    // 而 hit-numbering 排出来的本来就是完整的「第 1 章」「1.1」，编号自己已经
    // 把语序解决了，supplement 只会多出一个「小节」——Typst 中文档的默认值。
    //
    // 图表那边*需要* supplement（图 / 表），等做题注时在那儿设。
    set heading(supplement: none)

    // 语言的基线在上面算过了（词条覆盖要用），这里记进 state
    _lang.doc-lang.update(doc-lang)
    _case.check-title-case(title-case)
    _case.title-case-state.update(if title-case == auto { none } else { title-case })
    _heading-mod.check-two-hanzi(two-hanzi)
    _heading-mod.two-hanzi-state.update(two-hanzi)
    // 编号按文档语言与门类挑，见 src/heading/numbering.typ。
    //
    // *不开公开参数。* 层次编号是规范定死的（两份指南各一张「表2 层次代号及
    // 说明」），四份预设把官方的四种情形全覆盖了（中文理工 / 英文 / 人文社科 /
    // 人文社科的英文目录），auto 按 lang 与 category 自己挑——再开一个口子只会让人
    // 排出不合格的东西。要换写法就换 category 或 lang。
    let numbering = _numbering.resolve-numbering(
      auto, lang: doc-lang, category: category, stage: stage,
    )
    // 脚注正文小五。*两份指南都没规定脚注的字号*——人文社科版只写了标记
    // （（十五）：「在正文的右上标和页下以 ①②③……来表示」），理工版通篇没有
    // 「脚注」二字，四份书写范例里也一个脚注实例都没有。
    //
    // *没出处也得给个数*：原生那一档是 0.85em，正文小四时折出 10.2pt——
    // 那不是任何一个中文字号，Word 里敲不出来。取小五跟 hithesis
    // （\renewcommand\footnotesize{…\xiaowu[1.5]}，hithesisbook.cls:596），
    // 它是这一处唯一的参照。*不给配置项*：规范没定的东西不在包里立一档，
    // 用户要改就写原生那一句——show footnote.entry: set text(size: 10pt)，
    // 在内层，赢。
    //
    // 标记不在这儿设：①②③ 由 omni-gb7714 装（它的 note-numbering-style
    // 默认就是 circled，而 omni 是我们替用户装的），我们再设一遍是两处争。
    // 钉住它的是 tests/check-footnote.py
    show footnote.entry: set text(size: zihao.xiaowu)
    // 字的规则（断字、贪心断行、正文字体、代码、繁简、引号、数学、字距补偿、上下标、下划线、
    // 伪粗）由 banshi.document 装在这之前，段的规则装在这之后，见 banshi/src/document.typ
    // 标题：banshi 按关系表装（document(headings:)），这里只留本模板的两条检查规则
    show: _heading.heading-checks.with(numbering: numbering, chapter-pagebreak: chapter-pagebreak)
    // 顺序要紧：一节的 set（_matter.section，里面是 set page 与正文的 set text /
    // set par）摆在最内层，好让它发的规则最后定义。Typst 里同一选择器上后定义的
    // show 规则压过先定义的，而 set page 的页眉页脚是在正文的样式里排的——正文那条
    // 给西文 run 换行高的规则会漏进页眉，用正文的行距倍数给「第 1 章」里的 1 发
    // 行深，页眉行被撑高 1.27。page-rules 在 styled 里按页眉自己的取值重发一份，
    // 摆在内层才压得住。
    // 题注与三线表。摆在正文规则之前——它自己会用正文的行高定图表的上下间距
    // 解好的那个值*也写进 state*：插图与表格索引在文档中途读它，编号才与题注
    // 一致。见 src/settings/resolve.typ 的 caption-by-chapter
    _settings.caption-by-chapter.update(caption-by-chapter)
    _settings.equation-by-chapter.update(
      _settings.resolve-equation-numbering-by-chapter(
        local: equation-numbering-by-chapter, stage: body-stage,
      ),
    )
    // 代码清单的框与行号（进了 figure 的代码块），见 src/figure/kinds/raw.typ；要挂在 caption-rules
    // 之外这一层：figure 那条规则在里面记 state，这条 show raw 读它
    // 三段空当写 auto 的按默认表（(lines: 1)，见 src/styles/presets.typ 的 _figure）；解数与落成
    // show-set 都是 banshi 的（banshi/src/styles/figure.typ，document 装在这边的规则之前），这里
    // 算一份只给伪代码与代码清单那两条 gap 用
    let figure-spacing = _figure-spacing.figure-spacing(
      styles + (figure: styles.figure + ("image", "table").map(which => (which, {
        let st = styles.figure.at(which)
        for key in ("above", "below") {
          if st.at(key, default: auto) == auto { st.insert(key, _config-styles.default-styles.figure.image.above) }
        }
        st
      })).to-dict()),
      layout, f.metrics,
    )
    // 题注里号与名之间那一格按文档语言（中文一个字、英文四分之一），走原生的 separator；
    // 用户自己 set 的在内层、压得过
    set figure.caption(separator: context h(chars(_config-settings.caption-separator-auto.at(doc-lang, default: _config-settings.caption-separator-auto.zh).chars)))
    show: _listing.listing-rules
    // 自动拆页那条 show figure *装在 caption-rules 之外、之前*：后定义的先跑，它返回的不是
    // figure，caption-rules 里那些规则得先跑完；参数与 caption-rules 同名同义
    show: _split.split-rules.with(style: styles.figure.caption, by-chapter: caption-by-chapter, body-metrics: body-metrics)
    show: _captions.caption-rules.with(
      style: styles.figure.caption,
      // 只给图表上下空一行那条 show-set 用：show-set 的值给不了 context，按文档级算，
      // 见 src/figure/caption.typ 抬头
      body-metrics: body-metrics,
      by-chapter: caption-by-chapter,
      // 公式的引用也由 caption-rules 里那条 show ref 排，理由见那里
      equation-by-chapter: _settings.resolve-equation-numbering-by-chapter(
        local: equation-numbering-by-chapter, stage: body-stage,
      ),
    )
    // 三线表那条 show table 从 caption-rules 里搬出来，紧接着装（次序不变），见 src/figure/kinds/table.typ
    show: _three-line.table-rules.with(by-chapter: caption-by-chapter)
    // 打上 <-> 就不编号，见 src/heading/numbering.typ 的 nonumber-rules。*摆在题注规则之后*——同一属性上
    // 后定义的 show 规则压过先定义的，摆在前面会被题注那条 set figure(numbering:)
    // 盖掉（实测打了 <-> 的图照样排出「图1-2」）
    // 公式自动编号，按章排「(1-1)」、序号右端对齐（指南 2.11）。不想编号的打 <->
    //
    // *必须排在 heading-rules 之后*：那一条把标题换成了 block，先定义的规则
    // 就再也看不到 heading 元素——实测这条里的计数器重置一次没发，第二章的公式接着
    // 第一章数成了「(2-3)」。caption-rules 的图表重置能发，正是因为它也在后面。
    //
    // 而它又必须排在 nonumber-rules 之前：那一条要用 numbering: none 盖掉这里设的。
    // 伪代码与代码清单的题注与本体之间：表格型、线条型紧贴（线条型题注在两条线之间，中间那条
    // 细线是本体的上边，隔开就断了；表格型题注与顶线之间的空当由题注自己的行高出，与三线表
    // 同）；框图型题注在框外下方、与图一样，走图那一份 gap；清单不画框的也走图那一份。
    // *写成 show-set*：gap 是 figure 造好时填进字段的，show 规则里的 set 到不了（实测），而
    // show-set 给不了 context，框哪一档按参数在这儿解（resolve-*-style 的 from）
    show figure.where(kind: _algorithm-kind): set figure(gap: if (
      _settings.resolve-algorithm-style(from: algorithm-style).frame == "boxed"
    ) { figure-spacing.image.gap } else { 0pt })
    show figure.where(kind: raw): set figure(gap: if (
      _settings.resolve-raw-style(from: raw-style).frame in ("boxed", none)
    ) { figure-spacing.image.gap } else { 0pt })
    // 编号列表的编号串：中文全角「（1）」、英文半角「(1)」，都是范例与深圳英文指南里的写法
    // （Word 自己的默认是「1.」，那是 banshi 留给 Typst enum 的默认）。用户在文档里 set 能压过
    set enum(numbering: if doc-lang == "en" { "(1)" } else { "（1）" })
    show: _equation.equation-rules.with(
      by-chapter: _settings.resolve-equation-numbering-by-chapter(
        local: equation-numbering-by-chapter, stage: body-stage,
      ),
      supplement: _terms.term-of(doc-lang, "caption", "equation"),
    )

    // 参考文献。*摆在这儿*——先前要用户自己在 #show: iota-hit 之后写
    // #show: gb7714，那个位置就是这里：比我们的规则更内层，引用先过它的手，
    // 不是文献键的它原样交回（实测两条 show ref 嵌套时内层 return it 外层照样
    // 接手），再落到我们那条上。
    // *我们的默认压在它的默认之下，用户的又压在我们之上*——范例量出来的那
    // 几条当默认，别的一概听 omni 的，见 references.typ。方括号半角还是全角*按
    // 学科门类*：理工全角、人文半角，两份范例整篇数出来的
    // 章标题按文档语言生成，塞在两层之间：见 references.typ 的 references-title
    show: _omni.gb7714.with(
      .._gb7714-for(category)
        + (title: if numbered-references { none } else { _references-title(doc-lang, centered: styles.chapter.align == center) })
        + gb7714,
    )
    // *本部报告的参考文献是一个编号的节*，不是不编号的章：三份表单「说　明」
    // 页把它列成正文内容的第 9 条（博士开题第 10 条），与「1．课题来源」「2．国内外
    // 研究现状」并排。*深圳那几份不是*——它们的目录里「参考文献」与各章并排、
    // 不带号，正文里也是光三个字，所以那一档照终稿排（见上面 numbered-references）。omni 把 title 塞进自己那个 heading(numbering: none) 里，那是章的
    // 形状——所以报告这一档不把标题交给它，改成我们自己发一条一级标题，编号、进目录、
    // 接着数都照常。
    //
    // *要摆在 omni 那条之后*——后写的更内层、先跑：我们先给原件添上一条标题，
    // 再交给 omni 把条目表排出来。摆在前面的话 omni 那条先把 bibliography 元素换成了
    // 它自己的一块内容，我们这条就再也匹配不到（实测标题一个字都不出）。
    let report-bibliography(doc) = {
      // *要写 std.bibliography*：这个文件里的 bibliography 是 omni 那个壳
      // （上面 import 进来的），壳不是元素函数，当不了选择器
      show std.bibliography: it => {
        // *编号串要显式写在元素上*：show 规则里现造的标题拿不到外面那句
        // set heading(numbering:)（实测排出来光「参考文献」三个字，没有号）。
        // 传的就是本档那一份闭包，与哨兵比的也是它，不会撞上「用户改了编号」那条
        heading(level: 1, numbering: numbering, _references-title(doc-lang))
        it
      }
      doc
    }
    show: if numbered-references { report-bibliography } else { doc => doc }
    show: _nonumber-rules
    // 缩略语那条 show ref 罩在模板规则的最后：它认不得的键原样交回，再落到上面 omni 与
    // 题注那两条上。没有条目它什么都不装，见 src/references/abbreviations.typ 的 rules。
    // 它先前套在一节的 set 里面，只是要比 omni 与题注晚定义、比 baseline-rules 早——
    // 放在这儿同样满足（对拍过，逐字不变）
    show: _abbreviations.rules
    // 缩略语的两个文档级开关，发在正文之前；条目由印表的页声明
    _abbreviations.configure(fullwidth: abbreviation-fullwidth, links: abbreviation-links)
    doc
  }
  banshi.document(
    layout, styles, f,
    lang: doc-lang,
    options: banshi.options(
      fake-bold: fake-bold, fake-italic: fake-italic,
      enum-hanging: enum-hanging, list-hanging: list-hanging,
    ),
    // 页眉页脚按 stage 定，与三个 matter 同一份，见 src/layout/matter.typ
    .._matter.header-footer(layout, stage),
    // 标题：第几级用哪条样式、题序与标题之间空多少、标题正文怎么造，见 src/heading/rules.typ
    headings: _heading.heading-relation(levels: heading-levels),
    // 题注：图题在下表题在上、编号按章（附录字母）、每条题注排几行，见 src/figure/caption.typ
    captions: _captions.caption-relation(by-chapter: caption-by-chapter),
    rules: rules,
    doc,
  )
}
