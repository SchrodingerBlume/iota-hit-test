#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing, amount, families-of
#import "./axes.typ": report-stages as _report-stages
#import "./axes.typ": final-body as _final-body
#import banshi.fonts as _fonts
#import "./heading/rules.typ" as _heading
#import "./heading/heading.typ" as _heading-mod
#import banshi.layout as _layout
#import banshi.layout: chars
#import "./layout/parts.typ": default-inputs as _default-inputs
#import "./math/equation.typ" as _equation
#import "./math/theorem.typ" as _theorem
#import "./vendor/quan/lib.typ": quan as _quan
#import "./terms/lang.typ" as _lang
#import "./figure/caption.typ" as _captions
#import "./figure/split.typ" as _split
#import "./figure/kinds/table.typ" as _three-line
#import "./figure/table-style.typ" as _table-style
#import "./figure/kinds.typ": algorithm-kind as _algorithm-kind
#import "./figure/kinds/raw.typ" as _listing
#import "./references/abbreviations.typ" as _abbreviations
#import "./pages/references.typ": _omni, references-title as _references-title
#import "./references/bibliography.typ": gb7714-for as _gb7714-for
#import "@local/omni-gb7714:0.1.0": bibliography
#import "./heading/numbering.typ": nonumber-rules as _nonumber-rules
#import "./case.typ" as _case
#import banshi.fonts: songti, kaishu
#import banshi.fonts: zihao

#import "./info.typ" as _info
#import "./settings/resolve.typ" as _settings
#import "./terms/lookup.typ" as _terms
#import "./axes.typ" as _axes
#import banshi.errors as _errors
#import "./layout/matter.typ" as _matter
#import banshi.styles as sheet
#import "./figure/spacing.typ" as _figure-spacing
#import "./styles/lookup.typ" as _lookup
#import "./styles/presets.typ" as _config-styles
#import "./settings/defaults.typ" as _config-settings
#import "./info.typ": info-defaults as _info-defaults

#import "./heading/numbering.typ" as _numbering
#import "./native.typ": native-checks as _native-checks, outline-entry-sentinels as _outline-entry-sentinels

#let iota-hit(
  layout: auto,
  styles: (:),
  fontset: auto,
  metrics: (:),
  fake-bold: auto,
  fake-italic: auto,
  category: auto,
  page-numbering: auto,
  lang: "zh",
  title-case: auto,
  two-hanzi: auto,
  gb7714: (:),
  degree-level: auto,
  degree-type: auto,
  form: auto,
  stage: auto,
  campus: auto,
  title: auto,
  title-en-xiaoer: auto,
  subtitle: auto,
  author: auto,
  institution: auto,
  date: auto,
  student-id: auto,
  supervisor: auto,
  associate-supervisor: auto,
  industry-supervisor: auto,
  degree-applied: auto,
  speciality: auto,
  practice-type: auto,
  affiliation: auto,
  defense-date: auto,
  secrecy: auto,
  classified-index: auto,
  udc: auto,
  school-code: auto,
  report-number: auto,
  station: auto,
  research-start-date: auto,
  research-end-date: auto,
  report-submit-date: auto,
  work-finish-date: auto,
  overrides: (:),
  top-level-heading-pagebreak-before: auto,
  openright: auto,
  caption-bilingual: auto,
  caption-numbering-by-top-level-heading: auto,
  equation-numbering-by-top-level-heading: auto,
  equation-numbering-fullwidth: auto,
  theorem-numbering-by-top-level-heading: auto,
  theorem-body-indent: auto,
  note-width: auto,
  abbreviation-indexed: auto,
  enum-hanging: auto,
  list-hanging: auto,
  abbreviation-fullwidth: auto,
  abbreviation-links: auto,
  subcaption-numbering: auto,
  subcaption-separator: auto,
  subcaption-bilingual: auto,
  subcaption-gap: auto,
  heading-body-indent: auto,
  algorithm-style: auto,
  raw-style: auto,
  em-dash: auto,
  appendix-numbering: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  doc,
) = context {
// lang: auto 必须在本函数安装文本规则前读取外层 text.lang。
  let resolve-axis(axis, value, fallback) = {
    let v = _axes.normalize(((axis): if value == auto { fallback } else { value })).at(axis)
    if v not in _axes.axes.at(axis) {
      panic(_errors.expected-one-of(_axes.axes.at(axis), v) + " (axis: " + axis + ")")
    }
    v
  }
  let this-degree = if degree-level == auto { _info-defaults.degree-level } else { degree-level }
  let fixed = _axes.fixed-axes.at(this-degree, default: (:))
  let category = if "category" in fixed { fixed.category } else { resolve-axis("category", category, "stem") }
  let form = if "form" in fixed { fixed.form } else { resolve-axis("form", form, "dissertation") }
  let stage = if "stage" in fixed { fixed.stage } else { resolve-axis("stage", stage, "final") }
  let campus = if "campus" in fixed { fixed.campus } else { resolve-axis("campus", campus, "harbin") }
  let is-report = stage in _report-stages
  let report-body = is-report and not _final-body(campus, this-degree, stage)
  let body-stage = if report-body { stage } else { "final" }
  let numbered-references = report-body and campus != "shenzhen"
  let layout = _layout.merge-page-setup(
    _layout.page-setup(_default-inputs(
      degree-level: this-degree, stage: stage, campus: campus,
    )),
    layout,
  )
  let page-pattern = if page-numbering != auto {
    page-numbering
  } else if report-body { none } else { "1" }
  let doc-lang = _lang.normalize(if lang == auto { text.lang } else { lang })
  _info.info(lang: doc-lang, ..(
    ("degree-level", degree-level),
    ("degree-type", degree-type),
    ("category", category),
    ("form", form),
    ("stage", stage),
    ("campus", campus),
    ("title", title),
    ("title-en-xiaoer", title-en-xiaoer),
    ("subtitle", subtitle),
    ("author", author),
    ("institution", institution),
    ("date", date),
    ("student-id", student-id),
    ("supervisor", supervisor),
    ("associate-supervisor", associate-supervisor),
    ("industry-supervisor", industry-supervisor),
    ("degree-applied", degree-applied),
    ("speciality", speciality),
    ("practice-type", practice-type),
    ("affiliation", affiliation),
    ("defense-date", defense-date),
    ("secrecy", secrecy),
    ("classified-index", classified-index),
    ("udc", udc),
    ("school-code", school-code),
    ("report-number", report-number),
    ("station", station),
    ("research-start-date", research-start-date),
    ("research-end-date", research-end-date),
    ("report-submit-date", report-submit-date),
    ("work-finish-date", work-finish-date),
  ).filter(((k, v)) => v != auto).to-dict())
  let em-dash = _settings.resolve-em-dash(
    local: em-dash, campus: campus, degree-level: this-degree, stage: stage,
  )
  let f = _fonts.fontset(value: fontset, em-dash: em-dash, metrics: metrics)
  let variant-style(name) = _lookup.variant-style(
    name, lang: doc-lang, degree-level: this-degree, stage: stage, campus: campus,
  )
  let body-line-spacing = variant-style("body-line-spacing")
  let bold-upto = variant-style("heading-bold")
  let bold(level) = if level <= bold-upto { (latin-bold: true) } else { (:) }
  let body-indent = {
    let v = variant-style("body-indent")
    if v == auto { (:) } else { (first-line-indent: v) }
  }
  let body-spacing = if body-line-spacing == auto { (:) } else {
    (line-spacing: body-line-spacing)
  }
  let chapter = variant-style("chapter")
  let figure-style = variant-style("figure")
  // 报告没有章，样式表是终稿那张左移一格的（heading-1 是节）；加粗与间距仍按层次数：章 1、节 2……
  let base = if report-body { _config-styles.report-styles } else {
    _config-styles.final-styles-by-degree.at(this-degree, default: _config-styles.default-styles)
  }
  let preset = if is-report and not report-body {
    (
      body: (snap-to-grid: false) + body-spacing + body-indent,
      figure: figure-style,
      theorem: variant-style("theorem"),
      term-heading: bold(1) + chapter,
      heading-1: bold(1) + chapter, heading-2: bold(2),
      heading-3: bold(3), heading-4: bold(4),
    )
  } else if not report-body { (theorem: variant-style("theorem")) } else {
    let gap = variant-style("heading-spacing")
    (
      body: body-spacing + body-indent,
      figure: figure-style,
      theorem: variant-style("theorem"),
      term-heading: bold(1) + chapter,
      heading-1: (above: gap, below: gap) + bold(2),
      heading-2: (above: gap, below: gap) + bold(3),
      heading-3: bold(4),
    )
  }
  let styles = sheet.styles(base, _figure-spacing.without-auto(styles), preset: preset)
  let chapter-pagebreak = if top-level-heading-pagebreak-before != auto { top-level-heading-pagebreak-before } else { not report-body }
  let top = if report-body { _heading-mod.report-top(doc) } else { 1 }
  let styles = styles + ("term-heading", "heading-1").map(name => (
    name, styles.at(name) + (pagebreak-before: chapter-pagebreak),
  )).to-dict()
  for key in styles.theorem.head.keys() {
    if key not in _theorem.head-keys {
      panic("styles.theorem.head: unknown key \"" + key + "\"; " + _errors.expected-one-of(_theorem.head-keys, key)
        + " (the head is a run inside the paragraph; size and spacing come from styles.theorem.body)")
    }
  }
  let styles = styles + (theorem: (
    head: (asian-font: styles.body.asian-font, latin-font: styles.body.at("latin-font", default: "serif")) + styles.theorem.head,
    body: styles.body + (above: 0pt, below: 0pt) + styles.theorem.body,
  ))
  // 图注、表注与题注同一档：字号行距跟题注走，只是左起、不缩进
  let styles = styles + (figure: styles.figure + (
    note: styles.figure.caption + (align: left, first-line-indent: (chars: 0)) + styles.figure.note,
  ))
  _table-style.check(styles.figure.table)
  let body = styles.body
  let family = families-of(body, f)
  let body-metrics = spacing(body, layout: layout, metrics: f.metrics)
  if overrides != (:) { _terms.terms-overrides(overrides, lang: doc-lang) }
  _settings.settings-overrides(
    (
      openright: openright,
      fake-bold: fake-bold,
      fake-italic: fake-italic,
      caption-bilingual: caption-bilingual,
      em-dash: em-dash,
      algorithm-style: algorithm-style,
      raw-style: raw-style,
      equation-numbering-fullwidth: equation-numbering-fullwidth,
      abbreviation-indexed: abbreviation-indexed,
      enum-hanging: enum-hanging,
      list-hanging: list-hanging,
      subcaption-numbering: subcaption-numbering,
      subcaption-separator: subcaption-separator,
      subcaption-bilingual: subcaption-bilingual,
      subcaption-gap: subcaption-gap,
      theorem-body-indent: theorem-body-indent,
      note-width: note-width,
      heading-body-indent: heading-body-indent,
      appendix-numbering: appendix-numbering,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
      two-hanzi: two-hanzi,
      page-numbering: page-numbering,
      title-case: title-case,
      top-level-heading-pagebreak-before: top-level-heading-pagebreak-before,
      caption-numbering-by-top-level-heading: caption-numbering-by-top-level-heading,
      equation-numbering-by-top-level-heading: equation-numbering-by-top-level-heading,
      theorem-numbering-by-top-level-heading: theorem-numbering-by-top-level-heading,
      abbreviation-fullwidth: abbreviation-fullwidth,
      abbreviation-links: abbreviation-links,
    )
      .pairs()
      .filter(((k, v)) => v != auto)
      .to-dict(),
  )
  let caption-by-chapter = _settings.resolve-caption-numbering-by-top-level-heading(
    local: caption-numbering-by-top-level-heading, stage: body-stage,
    campus: campus, degree-level: this-degree,
  )
  let user-doc = doc
  let rules(doc) = {
    let figure-spacing = sheet.figure-spacing(
      layout, f.metrics, image: styles.figure.image, table: styles.figure.table, caption: styles.figure.caption,
    )
    // 排在模板别的规则之前：单个图表写原生 block(above:, below:, figure(…)) 才压得过，分图那条 0 也是
    set figure(gap: figure-spacing.image.gap)
    show figure.where(kind: table): set figure(gap: figure-spacing.table.gap)
    show figure: set block(above: figure-spacing.image.above, below: figure-spacing.image.below)
    show figure.where(kind: table): set block(above: figure-spacing.table.above, below: figure-spacing.table.below)
    // 图表前后那一行按 Word 段距落到块上：段距相加的文档，段后放进外面一层块里，不与下一段的段前取大合并
    show figure: it => context {
      let fs = if it.kind == table { figure-spacing.table } else { figure-spacing.image }
      let bs = banshi.styles.block-spacing(fs.above, fs.below)
      if bs.inset.bottom == 0pt { it } else {
        block(above: bs.above, below: bs.below, inset: (bottom: bs.inset.bottom), width: 100%, it)
      }
    }
    show: _heading.heading-rules.with(styles, top: top)
    show: _captions.numbering-rules.with(by-chapter: caption-by-chapter, top: top)
    _native-checks(user-doc)
    show: _outline-entry-sentinels
    set page(numbering: page-pattern)
    set heading(supplement: none)
    _lang.doc-lang.update(doc-lang)
    _case.check-title-case(title-case)
    _heading-mod.check-two-hanzi(two-hanzi)
    _numbering.heading-top.update(top)
    let numbering = _numbering.resolve-numbering(
      auto, lang: doc-lang, category: category, stage: stage, degree-level: this-degree,
    )
    // 从 == 起的报告，最外层那一级的号恒为 0，不印
    let numbering = if top == 1 { numbering } else { (..n) => numbering(..n.pos().slice(top - 1)) }
    show footnote.entry: set text(size: zihao.xiaowu)
    show: _heading.heading-checks.with(
      numbering: numbering, chapter-pagebreak: chapter-pagebreak, top: top, deepest: if report-body { 3 } else { 4 },
    )
    _settings.caption-by-chapter.update(caption-by-chapter)
    _settings.equation-by-chapter.update(
      _settings.resolve-equation-numbering-by-top-level-heading(
        local: equation-numbering-by-top-level-heading, stage: body-stage,
      ),
    )
    // 带标签：认得出是模板的默认、不是用户 set 的，博后才好按行换
    set figure.caption(separator: [#context h(chars(_config-settings.caption-separator-auto.at(doc-lang, default: _config-settings.caption-separator-auto.zh).chars))<iota-caption-separator>])
    show: _listing.listing-rules
    show: _split.split-rules.with(style: styles.figure.caption, by-chapter: caption-by-chapter, body-metrics: body-metrics)
    show: _captions.caption-rules.with(
      style: styles.figure.caption,
      table-style: styles.figure.table.caption,
      note-style: styles.figure.note,
      body-metrics: body-metrics,
      by-chapter: caption-by-chapter,
      equation-by-chapter: _settings.resolve-equation-numbering-by-top-level-heading(
        local: equation-numbering-by-top-level-heading, stage: body-stage,
      ),
    )
    show: _three-line.table-rules.with(by-chapter: caption-by-chapter, size: styles.figure.table.size)
    show figure.where(kind: _algorithm-kind): set figure(gap: if (
      _settings.resolve-algorithm-style(from: algorithm-style).frame == "boxed"
    ) { figure-spacing.image.gap } else { 0pt })
    show figure.where(kind: raw): set figure(gap: if (
      _settings.resolve-raw-style(from: raw-style).frame in ("boxed", none)
    ) { figure-spacing.image.gap } else { 0pt })
    set enum(numbering: if doc-lang == "en" { "(1)" } else {
      _config-settings.enum-numbering-by-degree.at(this-degree, default: "（1）")
    })
    show: _equation.equation-rules.with(
      by-chapter: _settings.resolve-equation-numbering-by-top-level-heading(
        local: equation-numbering-by-top-level-heading, stage: body-stage,
      ),
      supplement: _terms.term-of(doc-lang, "caption", "equation"),
      top: top,
    )
    show: _theorem.theorem-rules.with(
      by-chapter: _settings.resolve-theorem-numbering-by-top-level-heading(
        local: theorem-numbering-by-top-level-heading, stage: body-stage,
      ),
      style: styles.theorem,
      top: top,
    )
    show: _omni.gb7714.with(
      .._gb7714-for(category)
        + (title: if numbered-references { none } else { _references-title(doc-lang, centered: styles.term-heading.align == center) })
        + gb7714,
    )
    // 脚注编号画圈（omni 装的 quan）：圈里的数字用宋体，与 ①–⑩ 的字形同一副；正文里的数字不受影响
    set footnote(numbering: n => text(font: f.families.songti, _quan(n)))
    // 标记不走 super：Typst 的 super 只抬字形不抬盒子，quan 画的圈会留在原处、数字冒到圈顶。
    // 整个标记装进盒子用 move 抬（同 quan-super，不撑行高；box(baseline:) 会把那一行撑高 1.2），
    // 字号与抬升量照 super 的默认（0.6em、0.5em）；引用式脚注（footnote(<label>)）取被引那条的号
    show footnote: it => context {
      let loc = if type(it.body) == label { query(it.body).first().location() } else { it.location() }
      let n = std.numbering(it.numbering, ..counter(footnote).at(loc))
      link(loc, box(text(size: 0.6em, move(dy: -0.5em, n))))
    }
    // 页下的条目也自己排：omni 装的 quan-footnote 会绕过 footnote.numbering 自己画圈（数字就不是宋体了）。
    // 样子照 Typst 原生条目：缩进一字、上标号（0.7em、抬 0.4em）、号后 0.05em、正文
    show footnote.entry: it => context {
      let loc = it.note.location()
      let n = std.numbering(footnote.numbering, ..counter(footnote).at(loc))
      h(footnote.entry.indent)
      link(loc, box(text(size: 0.7em, move(dy: -0.4em, n))))
      h(0.05em)
      it.note.body
    }
    let report-bibliography(doc) = {
      show std.bibliography: it => {
        heading(level: top, numbering: numbering, _references-title(doc-lang))
        it
      }
      doc
    }
    show: if numbered-references { report-bibliography } else { doc => doc }
    show: _nonumber-rules
    // 原生 outline 不走我们的条目规则：编号、间距、引导点都不对，图表清单还丢了章号；我们自己那几处打了标签
    show outline: it => if it.has("label") and it.label == <iota-outline> { it } else {
      panic(
        "#outline() is not allowed: it skips the template's entry layout (numbers, gaps, leaders, and the "
          + "chapter prefix in figure lists); use #table-of-contents(), #list-of-figures(), #list-of-tables() "
          + "or #list-of-equations() instead",
      )
    }
    show: _abbreviations.rules
    _abbreviations.configure(fullwidth: abbreviation-fullwidth, links: abbreviation-links)
    doc
  }
  banshi.document(
    layout, styles, f,
    lang: doc-lang,
    options: banshi.options(
      fake-bold: fake-bold, fake-italic: fake-italic,
      enum-hanging: enum-hanging, list-hanging: list-hanging,
      html-paragraph-auto-spacing: _config-settings.html-paragraph-auto-spacing.at(this-degree, default: true),
      adjust-line-height-in-table: _config-settings.adjust-line-height-in-table.at(this-degree, default: true),
      .._config-settings.numbering-tab-by-degree.at(this-degree, default: (:)),
    ),
    .._matter.header-footer(layout, stage),
    rules: rules,
    doc,
  )
}
