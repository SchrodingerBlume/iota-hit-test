#import "@local/docxtyp:0.1.0" as d
#import "../fonts/resolve.typ": fontset as _fontset, fontset-state
#import "../fonts/style.typ": resolve as _resolve-style, resolve-tree as _resolve-tree
#import "../styles/state.typ": current-styles
#import "../styles/engine.typ": native-format
#import "./presets.typ": page-text-defaults
#import d.layout: page-setup as _page-setup, merge-page-setup as _merge-page-setup, section as _section
#import d.layout: (current-page-setup, emulated, is-page-setup, linebreaks-sets, page-setup-state,
  chars as _chars, h-chars as _h-chars, half-width-space, resolve-chars, merge)
#let chars(..n, layout: auto) = _chars(..n, page-setup: layout)
#let h-chars(..n, layout: auto) = _h-chars(..n, page-setup: layout)
#let _defaults = _fontset()
#let _inputs(inputs) = {
  let result = inputs
  for name in ("header", "footer") {
    if name in result and "format" in result.at(name) {
      result.insert(name, result.at(name) + (format: _resolve-style(result.at(name).format, _defaults,
        strip: true, paragraph-defaults: false)))
    }
  }
  result
}
#let resolve(layout, fontset) = {
  let result = layout
  for name in ("header", "footer") {
    result.insert(name, result.at(name) + (format: _resolve-style(result.at(name).format, fontset,
      strip: true, paragraph-defaults: false)))
  }
  result
}
#let page-setup(..args) = {
  if args.pos().len() > 1 or (args.pos().len() == 1 and args.named().len() > 0) {
    panic("page-setup: expected either named fields or one input dictionary")
  }
  let inputs = if args.pos().len() == 1 { args.pos().first() } else { args.named() }
  _page-setup(_inputs(merge(page-text-defaults, inputs)))
}
#let merge-page-setup(base, local) = _merge-page-setup(base, if type(local) == dictionary { _inputs(local) } else { local })
#let section(layout, fontset: auto, ..args) = context {
  let f = if fontset == auto { fontset-state.get() } else { fontset }
  let forwarded = args.named()
  let styles = forwarded.remove("styles", default: auto)
  let apply(body) = _section(resolve(layout, f), _state: false, ..forwarded, body)
  // iota 的 matter/new-layout/restore-layout 已管理页面状态和恢复链。
  if styles == auto and fontset == auto { apply(..args.pos()) } else {
    let resolved = _resolve-tree(if styles == auto { current-styles() } else { styles }, f)
    d.paragraph.format(native-format(resolved.body), page-setup: layout, apply(..args.pos()))
  }
}
