#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": info-get
#import "../terms/lang.typ": doc-lang, title-of
#import banshi.content: fold-linebreaks
#import "../case.typ": english-title
#import "../heading/heading.typ": heading-slot, heading-centered, two-hanzi-title, find-two-hanzi
#import "../terms/lookup.typ": term-apply, term-table, term-for, variant-of, has-term
#import "../axes.typ": report-stages
#import "../settings/resolve.typ": resolve-heading-body-indent
#import "../axes.typ": campus-for, degree-type-for
#import "../pages/report/title.typ" as _report-title
#let chapter-line(t, variant, lang, gap) = {
  let started = query(heading.where(level: 1)).filter(
    it => it.location().page() <= here().page(),
  )
  if started.len() == 0 { return none }
  let last = started.last()
  let fold = fold-linebreaks
  if last.numbering == none { fold(last.body) } else {
    let value = resolve-heading-body-indent(
      local: gap, lang: lang, category: info-get().category, level: 1,
    )
    term-apply(
      t, "chapter", variant,
      numbering(last.numbering, ..counter(heading).at(last.location())),
      h(if type(value) == dictionary {
        if type(value.at("chars", default: none)) not in (int, float) {
          panic("expected number for \"chars\", found " + repr(value.at("chars", default: none)))
        }
        value.chars * 1em
      } else { value }),
      fold(if lang == "en" { english-title(title-of(last.body, "en"), slot: heading-slot(last)) }
        else if last.level == 1 and heading-slot(last) == "heading" { two-hanzi-title(title-of(last.body, "zh"), centered: heading-centered(last), local: find-two-hanzi(last.body)) }
        else { last.body }),
    )
  }
}
#let header-line(parity, gap) = {
  let i = info-get()
  let lang = doc-lang.get()
  let t = term-table(lang, "header")
  let is-report = i.stage in report-stages
  let variant = variant-of(i) + (if is-report { (:) } else { (degree-level: i.degree-level) })
  let p = (
    university: term-for(t, "university", variant),
    document-type: if is-report { none } else { term-for(t, "document-type", variant) },
    chapter: if is-report { none } else { chapter-line(t, variant, lang, gap) },
    report-title: if is-report { _report-title.report-title(t, lang, i, variant) } else { none },
    stage: if is-report { _report-title.stage-word(t, variant) } else { none },
  )
  let name = if parity == "even" and has-term(t, "even", variant) { "even" } else { "odd" }
  term-apply(t, name, variant, p)
}
