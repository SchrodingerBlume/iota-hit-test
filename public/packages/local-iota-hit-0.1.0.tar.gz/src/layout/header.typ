// 页眉的内容——一节的 set 里页眉那一格的*内容*。排不排由 layout.header.shown 定，
// 内容按档定、不开放，见 src/layout/resolve.typ 与 src/layout/section.typ。
//
#import "../document/info.typ": info-get
#import "../terms/lang.typ": doc-lang
#import "../text/plain.typ": fold-linebreaks
#import "../heading/marks.typ": title-of
#import "../text/case.typ": english-title, heading-slot
#import "../text/spread.typ": spread-title
#import "../heading/marks.typ": find-spread
#import "../terms/lookup.typ": term-apply, term-table, term-for, variant-of
#import "../settings/resolve.typ": resolve-heading-body-indent
#import "../axes.typ": campus-for, degree-type-for
#import "../pages/report/title.typ" as _report-title

// 照写作指南 3.4 与两份范例：
//
//   本科    除封面内封外*每页*都排「哈尔滨工业大学本科毕业论文（设计）」，
//           不分奇偶——指南 3.4 的原话是「要求单面复印或胶印，页眉不分奇偶页」
//   硕士    也是每页同一行：指南 3.4「硕士学位论文单面印刷，页眉为“哈尔滨工业
//           大学硕士学位论文”」、3.8「硕士要求单面复印或胶印，单面印时页眉不分
//           奇偶页」；实践成果与人文社科两份指南同一句话，只换文种。先前这儿把
//           硕士归进「研究生双面交替」，是拿博士范例套的——硕士没有范例，看指南
//   博士    双面交替：*奇数页*排本章的章标题，偶数页排校名加学位那一行
//
// *奇偶按印码算，不是物理页。* 博士范例逐页量下来，印码 I / III / 1 / 3 /
// 5 / 7 是「摘  要」「目  录」「第1 章  绪  论」「第6 章 …」，印码 II / IV / 2 /
// 4 / 6 是「哈尔滨工业大学博士学位论文」。而那张「摘  要」在范例里是*物理
// 第 6 页*（偶数），印码才是 I——两者同奇偶纯属封面那几张空白页凑出来的巧合。
// openright 一关空白页就没了，物理页与印码错开一截，判物理页会把整篇页眉排反。
//
// *章起始页照样有页眉。* 先前这里跟的是 LaTeX 的惯例——\chapter 会发
// \thispagestyle{plain}，hithesis 的 plain 里连页眉横线都是 \relax。但两份
// 范例都不是这样：本科范例第 4/5/6/8 页、研究生范例第 6/8/10 页都是章起始页，
// 页眉一个不少。指南 3.4 写的是「除封面及内封外，*各页*均应加页眉」，
// 没有例外。封面与内封不出页眉，是那两页的部件差额把 header.shown 写成 false
// （src/layout/presets.typ 的 part-layouts），部件按它发 set page(header: none)。
//
// *编号与标题之间空一个字，跟着 heading-body-indent 走。* 先前这里硬写
// 0.5em，理由记的是 hithesis 的 \chaptermark ＝「\CTEXthechapter \enspace 标
// 题」——但*博士范例不是这么排的*：那份 Word 出的 PDF 第 10 页页眉
// 「第1 章  绪  论」，章 的字身 9.000、章→绪 origin 差 18.000，中间那一段
// *9.000*，正是 9pt 下的一个汉字宽；我们排出来是 4.500，窄了一半。
//
// *(chars: n) 在这里折成 n × 1em，不是 ccwd(n)*。ccwd 是「一格的宽度」＝
// 1em ＋ 字距增量，而字距增量是*字符网格*的性质——页眉不在网格上：范例与
// 我们的页眉，汉字步进都是 9.000 整（正文是 12.4543）。所以这里的「一个字宽」
// 就是 1em。「几个字」这个语义各处相同，各自按各自的网格折算，折出来的数不同
// 才是对的。auto 按文档语言解成 (chars: 1) 或 (chars: 0.5)，见
// src/settings/defaults.typ 的 heading-body-indent-auto。
//
// 按页码筛而不用 selector.before(here())：页眉的位置在本页正文之前，
// before 取不到本页的东西，实测页眉是空的。

// *函数体不裹 context*：页眉是在 src/layout/resolve.typ 的 context 里排的，那儿
// 要拿到*真的内容*判断这一页的页眉是不是纯西文（plain 钻不进 context 块）。
// 里面用到的 state / counter / query 都要 context，所以这个函数只能在 context 里调。
// *不公开*：页眉排不排由 layout.header.shown 定，内容按档定，见 src/layout/resolve.typ
// 与 src/layout/section.typ——那儿把它装进 set page(header:)，文档级发一次、每段再发一次
#let final-header-body(gap) = {
  let i = info-get()
  let degree-level = i.degree-level
  // *校名那一行跟文档语言*——英文档印 Harbin Institute of Technology
  // Doctoral Dissertation。词条两档都有，见 src/terms/built-in.typ
  let lang = doc-lang.get()
  let t = term-table(lang, "header")
  let institution-line = (
    t.university
      + (if lang == "en" { " " })
      + term-for(t, "document-type", variant-of(i) + (degree-level: degree-level))
  )
  // 本硕单面，每页同一行字
  if degree-level != "doctor" { return institution-line }
  // 博士双面，偶数印码是校名式。要的是页脚印出来的那个数，不是
  // here().page()——理由见上面
  if calc.even(counter(page).at(here()).first()) { return institution-line }
  // 奇数印码排本章的章标题。这一处筛的是元素落在第几页，比的是*物理页*，
  // 与上面判奇偶用的印码是两回事。用 <= 而不是 <——这一页起的新章也算本章
  let started = query(heading.where(level: 1)).filter(
    it => it.location().page() <= here().page(),
  )
  if started.len() == 0 { return none }
  // 变量别叫 h：那是 Typst 的水平间距函数，下面 h(gap) 要用
  let last = started.last()
  // *标题里的换行折掉，页眉排成一行。* 章标题手动分行（「……的研究\\ 与实现」）
  // 是为了标题那一处好看，页眉里没有那么宽的排法也不该有；目录条目同一条规则
  // （src/pages/outline.typ）。汉字之间折掉不留空格——先前用 show linebreak 折，「\ 」后面
  // 那个 space 元素留了下来，页眉里多一个空格，见 src/text/plain.typ 的 fold-linebreaks
  let fold = fold-linebreaks
  // 不编号的那一档原样交 last.body（词条页的标题）：它自己会按页面语言解，声明页那种
  // 整页回退中文的页，页眉也跟着回落。页眉那一层判「是不是纯西文」读的是 plain(body)，
  // styled 元素会进 child 里读（src/text/plain.typ），「Contents」这种读得到。
  if last.numbering == none { fold(last.body) } else {
    // 换行会断开表达式，所以整串包在括号里
    let value = resolve-heading-body-indent(
      local: gap, lang: lang, category: info-get().category, level: 1,
    )
    (
      numbering(last.numbering, ..counter(heading).at(last.location()))
        + h(if type(value) == dictionary {
          // 形状的验法与 chars.resolve-chars 同一句话
          if type(value.at("chars", default: none)) not in (int, float) {
            panic("expected number for \"chars\", found " + repr(value.at("chars", default: none)))
          }
          value.chars * 1em
        } else { value })
        // 英文档印英文名，与正文里的标题同一条（src/heading/rules.typ）
        // 两字的章标题撑开（词条页的标题已在 term-chapter 里撑过，原样印），见 src/text/spread.typ
        + fold(if lang == "en" { english-title(title-of(last.body, "en"), slot: heading-slot(last)) }
           else if last.level == 1 and heading-slot(last) == "heading" { spread-title(title-of(last.body, "zh"), slot: "heading", local: find-spread(last.body)) }
           else { last.body })
    )
  }
}


// 报告那两档的页眉。
//
// *本部三份没有页眉*（写作指南明写「报告不要设置页眉」，三份 header.xml
// 都是空的），排不排由 layout.header.shown 定——本部那三份是 auto ＝ 不排，
// 深圳那几份写着 true。所以走到这儿的通常只有深圳，但用户把 shown 打开时
// 本部也要有字可印，见 src/terms/built-in.typ 的 header 桶那条光键名 report。
//
// *整行居中、逐档一个字面*，不看页码奇偶、也不跟章走——它是表单上印死的
// 一行字，与论文页眉那条「奇偶交替、奇数页排本章标题」不是一回事。
#let report-header-body() = {
  let i = info-get()
  let lang = doc-lang.get()
  let t = term-table(lang, "header")
  // 首页那一支查词条时递的是同一组轴（见 src/pages/report/cover.typ 的 variant），
  // 这儿只多不少：校区按学位定（深圳只发了研究生与本科那几份），学位类别那一根
  // 页眉用不着
  // form 也递：深圳本科的页眉印的是「毕业论文」还是「毕业设计」跟它走
  let variant = variant-of(i)
  // 表单名与阶段名的料都从*自己的桶*取：header 桶里那几条 from("cover") 把
  // 首页的那一族搬了过来，页眉因此有自己的键（header-report-title-…），改页眉
  // 不必动首页——先前这儿硬读 cover 桶，页眉印的东西用户在页眉这一头改不了
  term-apply(
    t, "report", variant,
    term-for(t, "university", variant),
    _report-title.report-title(t, lang, i, variant),
    _report-title.stage-word(t, variant),
  )
}
