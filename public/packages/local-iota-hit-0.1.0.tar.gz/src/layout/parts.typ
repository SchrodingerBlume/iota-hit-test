// 页函数那一层的版面：本档默认那张输入表（终稿一份、报告按学位与阶段各一份）、部件差额、
// layout-for / layout-of / current-layout。折算与并表的机制在 ./resolve.typ（那一半是通用的
// Word 页面设置模型，与哪所学校无关）；这里是拿它干活的那一层，值住在 ./presets.typ。
#import "@local/banshi:0.1.0" as banshi
#import banshi.layout as _resolve
#import banshi.layout: page-setup, merge, is-page-setup
#import banshi.layout: page-setup-state
#import "./presets.typ": final-layout, report-layouts, part-layouts
#import "../axes.typ": report-stages
#import "../axes.typ" as _axes
#import banshi.errors as _errors

// 本档默认那张输入表：终稿一份，报告按学位与阶段各一份，见 layout/presets.typ
#let default-inputs(degree-level: "bachelor", stage: "final", campus: "harbin") = {
  if stage in report-stages {
    // 校区 → 学位 → 阶段。深圳那两份是另发的表单，见 layout/presets.typ；
    // *深圳只有硕士那两份*，本科与博士按本部排，见 axes.typ 的 campus-for
    let by-campus = report-layouts.at(_axes.campus-for(campus, degree-level))
    let by-degree = by-campus.at(degree-level, default: none)
    if by-degree == none {
      panic(_errors.expected-one-of(by-campus.keys(), degree-level) + " (degree-level)")
    }
    by-degree.at(stage)
  } else {
    final-layout
  }
}

// 页函数那一层：文档＋段（page-setup-state）→ 部件差额 → 这一页自己的。
// *要在 context 里调*。没进过 iota-hit 的文档（对拍件直接调页函数）从
// 本档默认起。part 给 none 就没有部件差额。
#let layout-for(part, local) = {
  if is-page-setup(local) { return local }
  let s = page-setup-state.get()
  let inputs = if s == none { default-inputs() } else { s.inputs }
  if part != none { inputs = merge(inputs, part-layouts.at(part, default: (:))) }
  if local != auto { inputs = merge(inputs, local) }
  page-setup(inputs)
}

// 当前生效的那一份（文档＋段），没进过 iota-hit 的文档从本档默认起（见 resolve.typ 的
// current-layout）。*要在 context 里调*。*公开*（lib.typ），站内预览靠它读当前的字符网格，见 layout-of
#let current-layout() = _resolve.current-page-setup(default: default-inputs())

// 页函数用的那套部件名。有部件差额的在 layout/presets.typ 的 part-layouts 里，没有的
// （abstract、toc……）就是文档＋段那一份——名字仍然收，好让调用方不必知道哪些页有差额
#let parts = (
  "cover", "titlepage", "abstract", "toc", "index", "nomenclature",
  "achievements", "declarations", "declarations-graduate",
)

// *公开*：某个部件页函数实际用的那份折好的版面。part 收上面 parts 里的名字（与页函数
// 自己调 layout-for 传的一致），local 是这一页用户就地写的 layout:（没写就 auto）。
// 返回的记录 is-page-setup 为真：docgrid.tracking、docgrid.char-pitch、docgrid.line-pitch、
// margin、text-width……见 fold。*要在 context 里调*。
//
// *给站内预览（iota4web）读字符网格用的*：那边用 fork 引擎的 par(linebreaks: (mode:
// "msword", char-pitch: …)) 排字，把模板发的 text(tracking:) 清零、换成引擎的字符步进，
// 每个部件用哪一格得从模板现读。先前它直接 import 包内子路径，Typst 不让；改名或改
// 返回形状要连带告知那边。写错的部件名当场报错，不静默回落到文档那一份。
#let layout-of(part, local: auto) = {
  if part != none and part not in parts {
    panic(_errors.expected-one-of(parts, part) + " (part)")
  }
  layout-for(part, local)
}

// 同一件事的免 context 版：只有本档默认加部件差额。封面与内封在 context 外面
// 发 set page，直接调它们的对拍件走这一条；用户那条路（lib.typ 的 cover）
// 由 src/pages/front.typ 在 context 里用 layout-for 填好再传进来。
#let standalone-layout(part) = page-setup(
  merge(default-inputs(), part-layouts.at(part, default: (:))),
)
