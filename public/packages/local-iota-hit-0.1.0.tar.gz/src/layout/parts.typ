#import "@local/banshi:0.1.0" as banshi
#import banshi.layout as _resolve
#import banshi.layout: page-setup, merge, is-page-setup
#import banshi.layout: page-setup-state
#import "./presets.typ": final-layout, report-layouts, part-layouts
#import "../axes.typ": report-stages
#import "../axes.typ" as _axes
#import banshi.errors as _errors
#let default-inputs(degree-level: "bachelor", stage: "final", campus: "harbin") = {
  if stage in report-stages {
    let by-campus = report-layouts.at(_axes.campus-for(campus, degree-level))
    let by-degree = by-campus.at(degree-level, default: none)
    if by-degree == none {
      panic(_errors.expected-one-of(by-campus.keys(), degree-level) + " (degree-level)")
    }
    by-degree.at(stage)
  } else {
    final-layout
  }
}
#let layout-for(part, local) = {
  if is-page-setup(local) { return local }
  let s = page-setup-state.get()
  let inputs = if s == none { default-inputs() } else { s.inputs }
  if part != none { inputs = merge(inputs, part-layouts.at(part, default: (:))) }
  if local != auto { inputs = merge(inputs, local) }
  page-setup(inputs)
}
#let current-layout() = _resolve.current-page-setup(default: default-inputs())
#let parts = (
  "cover", "titlepage", "abstract", "toc", "index", "nomenclature",
  "achievements", "declarations", "declarations-graduate",
)
#let layout-of(part, local: auto) = {
  if part != none and part not in parts {
    panic(_errors.expected-one-of(parts, part) + " (part)")
  }
  layout-for(part, local)
}
#let standalone-layout(part) = page-setup(
  merge(default-inputs(), part-layouts.at(part, default: (:))),
)
