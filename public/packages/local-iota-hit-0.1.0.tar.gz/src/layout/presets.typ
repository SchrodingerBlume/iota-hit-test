#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
// 三档页面设置的取值表：终稿一份，开题报告与中期报告本科、硕博两套；外加
// 部件差额。*只放值*——都是 Word「页面设置」对话框那张表的原样（字段与
// 折法见 banshi/src/layout/resolve.typ 的 fold），挑哪一份、怎么折是 engine 的事。
//
// 写的一律是 Word 界面上的数：厘米、磅、字号档名。缇只在注释里作出处。
//
// ── 终稿 ──────────────────────────────────────────────────────────
//
// 页面设置来自学校发的「本科毕业论文书写范例（理工类）」，解法是拆开 .docx
// 读 w:sectPr 与各个 w:pPr，再拿导出的 PDF 逐条基线核对；字号、行距照
// 「本科毕业论文（设计）写作指南（理工类）」3.2 节的原话。
// 取值与 hithesis 的 src/setup/hit-defaults.dtx 同源。
//
// 页边距上 3.8cm，左右下 3cm，页眉距边界 3cm，页脚距边界 2.3cm——折出来是
// 2155 / 1701 / 1304 缇，正是 hithesis 从 .docx 里读出来的那一组 pgMar。
//
// ── 开题报告与中期报告 ────────────────────────────────────────────
//
// *与终稿并列*——报告是另发的表单，页边距、页眉页脚、网格三样全不一样。
// *本科与硕博两套*，差别不在 stage 而在 degree-level：本科那两份四边 2.3cm、
// 无页眉页码、网格整个不启用；硕博三份上左右 2.5cm、页眉页脚各有距边界的值、
// 开着行网格。
//
//                论文（书写范例）        本科开题·中期          硕博三份
//   纸张         A4                      A4                     A4
//   页边距       上 3.8、左右下 3cm      *四边 2.3cm*       上左右 2.5cm、
//                                        （pgMar 1304 缇）      下边距各份各写
//   页眉         双线 + 校名／章标题     *没有*            引用的那一份是空的
//   页码         版心下居中              *没有*            *没有*
//   文档网格     type="linesAndChars"    *整个不启用*       *只开行网格*
//                linePitch 391           <w:docGrid             <w:docGrid
//                charSpace 1861          linePitch="312"/>      w:type="lines"
//                                        没有 w:type            linePitch="312"/>
//
// *网格那一条要看 w:type，不是看有没有 linePitch。* `w:type` 缺省是
// `default` ＝ 不启用，本科那两份的 312 只是躺在文件里的一个数，Word 不用它；
// 硕博三份写着 w:type="lines"，那 312（＝ 15.6pt）就是真的行网格跨度，段落的
// 行高要往上取整到它的整数倍（贴不贴逐段由 snapToGrid 定，见
// src/pages/report/cover.typ）。
//
// *横向两边都没有网格*：五份的 docGrid 一个都没写 charSpace，所以汉字之间
// 不加那 0.4543 的增量（ccwd 就是纯 1em）——两套表都不写 char-pitch。
//
// *页码那一条别被 footer1 骗了。* 两份文件的 even 页脚里都躺着一个 PAGE
// 域，可文档既没有 w:evenAndOddHeaders 也没有 w:titlePg——even 与 first 的引用
// 因此*不生效*，真正用的是 default 那一份，而它是空的。所以 shown 一律 false。

// 终稿。
//
// 文档网格：*写 Word 界面上那两个数*——「页面设置 → 文档网格」里跨度是磅
// （19.55），字符网格那一格由 charSpace 折出来（12 + 1861/4096 = 12.4543）。
//
// *跨度取 391 缇 ＝ 19.55 磅，不取 383 ＝ 19.15。* 两份官方范例的 .docx 各有
// 十二个节（w:sectPr），逐节读 w:docGrid：
//
//   本科理工范例 / d-stem           linePitch   charSpace   第几节
//   封面、内封                        395         1861        1、2
//   摘要、Abstract、目录              391         1861        3、4、5
//   第 1～3 章                        391         2752        6
//   第 4～6 章（拷贝进来的 FLUENT）   383         1861        7
//   结论、参考文献                    391         1861        8、9
//   成果（d-stem 还有答辩页）         391         2752        10（d-stem 10、11）
//   声明、致谢、简历                  391         1861        11（d-stem 12）
//
// 十二节里八节是 391/1861；383 只出现在拷贝进来的 FLUENT 那一节（第 4～6 章），
// 2752 只在第 1～3 章与成果。人文社科范例（本科与研究生两份）整篇都是 391/1861。指南
// 本身只说「每页约 33 行」——19.55 × 33 = 645.15，版心高 649.09 装得下。
// 先前取 383 是跟着 hithesis 的 hit-defaults.dtx，那一份读的正是 FLUENT 那一节。
//
// 「一行」这个单位也跟着它：章标题段前 1 行 ＝ 391 缇 ＝ 19.55、段后 0.8 行 ＝
// 312.8 截成 312 缇 ＝ 15.6、节标题段前段后 0.5 行 ＝ 195.5 截成 195 缇 ＝ 9.75。
// 三个数都是 Word 自己写进 .docx 的：本科理工范例的段 139/512（heading 1）写着
// beforeLines=100 before=391、afterLines=80 after=312，段 515/522（声明页小标题）
// 写着 beforeLines=50 before=195。PDF 上也对得上：章标题首行 145.55 ＝ 107.75 +
// 19.55 + 18.226（摘要 p4、结论 p15、参考文献 p16，d-stem p17/p18/p22 同）。
//
// 正文是多倍 1.25 加不对齐网格，行距 1.25 × 1.296875 × 12 = 19.453125pt，
// 首行基线落在版心顶下方 1.008 × 12 + 0.082 = 12.178pt。研究生指南 3.2 写的也是
// 「小 4 号字，建议行间距 1.25 倍，段前 0 行，段后 0 行」，与本科同。
//
// 页眉：宋体小五、单倍行距、不对齐网格（Word「页眉」样式的原样）；下边框 thinThickSmallGap，粗线 2.25 磅
// （w:sz=18）、距文字 1 磅（w:space=1）。页脚：小五，字体跟正文。
//
// 页脚的落点不用补：距边界量到块底、一行全西文按 Times 的行高，都在 banshi 的 page-rules 里
// （范例「- 2 -」基线离页底 67.02 ＝ 65.20 ＋ 10.35 − 8.48 − 0.05，末一项是范例页码那个
// 文本框自己的 y=1 缇，不跟）。先前这儿存着 dx 0.24、dy −1.52 两个「补偿」，前者是那个
// 文本框「框按版心居中、框里左对齐」多出来的四分之一磅，后者是量错了的块底。
#let final-layout = (
  margin: (top: 3.8cm, rest: 3cm),
  line-pitch: 19.55pt,
  char-pitch: 12.4543pt,
  font-size: zihao.xiaosi,
  header: (
    shown: auto,
    from-edge: 3cm,
    style: (font-zh: "songti", size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false),
    border: (style: "thin-thick-small-gap", thickness: 2.25pt, from-text: 1pt),
  ),
  footer: (
    shown: auto,
    from-edge: 2.3cm,
    style: (size: zihao.xiaowu),
    border: none,
  ),
)

// 本科那两份：四边 2.3cm，页眉页脚距边界 0（pgMar header="0" footer="0"），
// 网格整个不启用。
//
// 「一行」这个单位。*网格关着，可 Word 的「段前 0.5 行」仍要有个行*
// ——那就是正文的单倍行高：小四 12pt × 中易的 1.296875 ＝ 15.5625pt，落到缇上
// 是 311.25 → 312，正是文件里 <w:docGrid w:linePitch="312"/> 的那个数。
//
// *所以那个 312 不是网格跨度，是行高的四舍五入。* 文件里既有它、又没有
// w:type，两件事合起来才说得通：Word 把行高记了下来，但没打开网格。
// *页码：五份表单里只有硕士中期给了*，别的四份连页脚引用都没有。那一份的
// 页脚是「- 」＋ PAGE 域 ＋「 -」，框住居中（w:framePr xAlign="center"），页脚样式
// w:sz=18 ＝ 小五，页脚距边界 w:footer="992" 缇 ＝ 1.75cm；封面那一节写着 titlePg 与
// pgNumType start="0"（封面无号），正文那一节 start="1"。
//
// *五份统一按它排*：本科那两份的 w:footer 写的是 0，那是「没打算放页脚」的默认，
// 不是一个能用的位置。页码从*正文*起数（封面与目录不排），与那一份「正文那一节
// 从 1 起」一致——文档级的 page-numbering 在报告那一档是 none，mainmatter 换成 "1"
// 并归一，见 lib.typ 与 src/layout/matter.typ。
//
// *位置照学校自己发的那份 PDF*（硕士学位中期报告模板.pdf，Windows 的 Word 365 排的，
// 与封面那几份用的是同一个靶子）：页码基线 790.68（离页底 51.21 ＝ 49.61 ＋ 1.60）、墨迹
// 287.93..307.49（中点 297.71，正是页宽的一半 297.68）。块底与一行全西文的行高在 banshi 的
// page-rules 里，见 final-layout 那段注释；这一份比模型（＋1.87）低 0.26：原件的页脚是一个
// 文本框*外加一个空段*（footer2.xml），文本框挂在空段的位置上，光一个段的模型不出这一截，不跟。
#let _report-footer = (
  shown: true,
  from-edge: 1.75cm,
)

#let _bachelor-report = (
  margin: (rest: 2.3cm),
  line-pitch: 15.6pt,
  font-size: zihao.xiaosi,
  header: (shown: false, from-edge: 0cm),
  footer: _report-footer,
)

// 硕博那三份：上左右 2.5cm，页眉距边界 1.5cm、页脚 1.75cm，*开着行网格*
// （docGrid w:type="lines"，只纵向，没有 charSpace）。15.6pt ＝ 文件里的
// <w:docGrid w:type="lines" w:linePitch="312"/>——*这一份是真网格*，段落的
// 行高要往上取整到它的整数倍。
//
// *下边距各份不同*：硕士开题 2.2、硕士中期 2.3、博士开题 2.5cm——上左右
// 三边三份都是 1418 缇，只有下边距各写各的，看不出规律，那就照各自的写。
// 手上没有博士中期那份文件，按同学位的开题走 2.5cm。
#let _graduate-report(bottom) = (
  margin: (top: 2.5cm, x: 2.5cm, bottom: bottom),
  line-pitch: 15.6pt,
  font-size: zihao.xiaosi,
  header: (shown: false, from-edge: 1.5cm),
  footer: _report-footer,
)

// 深圳那两份。*这张表说的是正文那一节*——首页另有一套的写在下面
// report-cover-layouts 里。
//
// *页眉要排。* 本部明写「报告不要设置页眉」，深圳那两份却都有页眉、且带
// 边框线：「哈尔滨工业大学（深圳）硕士学位论文开题报告」「哈尔滨工业大学（深圳）
// 中期报告」（word/header2.xml，两份都写着 w:pBdr thinThickSmallGap w:sz="24"
// ＝ 粗线 3pt——终稿那一档是 sz18 ＝ 2.25）。字样见 src/terms/built-in.typ 的 header 桶。
//
// *开题的正文另起一节*，与封面那一节不是一套：w:pgMar 1814/1588/1701/1701
// ＝ 上 3.2 右 2.8 下 3 左 3cm、页眉 1701 ＝ 3cm、页脚 1304 ＝ 2.3cm，docGrid
// linesAndChars 391/2662 ＝ 行 19.55、字 12 ＋ 2662/4096 ＝ 12.6499（终稿是
// 391/1861 ＝ 12.4543，同一副网格、字距增量另一个数）。*正文这一节与终稿
// 同构*，所以报告这一档在深圳开题上是有字符网格的，本部三份没有。
//
// 中期那一节仍与本部中期一样（2.5/2.5/2.3、docGrid lines 312 ＝ 15.6），
// 只是多了页眉（距边界 1020 缇 ＝ 1.8cm）。
#let _shenzhen-header = (
  shown: true,
  // thinThickSmallGap w:sz="24" ＝ 3pt。*取中文那两份的*：英文版一份写着
  // sz18（2.25）、一份干脆是一条细单线，三份三个样，取官方现行中文版那一个
  border: (style: "thin-thick-small-gap", thickness: 3pt, from-text: 1pt),
)

#let _shenzhen-proposal = (
  margin: (top: 3.2cm, left: 3cm, right: 2.8cm, bottom: 3cm),
  line-pitch: 19.55pt,
  char-pitch: 12.6499pt,
  font-size: zihao.xiaosi,
  header: _shenzhen-header + (from-edge: 3cm),
  // 页脚距边界 w:footer="1304" ＝ 2.3cm，*再加一行*：那一份的页脚里有两段
  // ——页码一段、空一段，而「页脚距边界」量到的是页脚底（见 _report-footer），
  // 页码因此比只有一段时高出整整一行（页脚样式小五：9 × 1.296875 ＝ 11.67，
  // 对着原件量出来是 11.88，取实测）
  footer: _report-footer + (from-edge: 2.3cm + 11.88pt),
)

#let _shenzhen-interim = (
  margin: (top: 2.5cm, x: 2.5cm, bottom: 2.3cm),
  line-pitch: 15.6pt,
  font-size: zihao.xiaosi,
  header: _shenzhen-header + (from-edge: 1.8cm),
  footer: _report-footer,
)

// 深圳*本科*那两份是另一路：*正文照终稿排*，只有首页是表单。
//
// *2026 年 9 月版把这件事坐实了。* 新发的开题与中期（深圳本科毕业论文
// （设计）开题报告20269月版.doc、深圳20269月版本科毕业论文（设计）中期报告.doc）
// 三节的 pgMar 与 docGrid *逐个数相同*，正文那一节正是 2154/1701 ＋
// 391/1861 ——与终稿一字不差。*旧版中期那一套（上下 2.85cm、网格 412/3481）
// 没有了*，两个阶段因此合成一档；先前为「照论文补齐」开的那个配置项也随之作废。
//
// 从 final-layout 起，只覆盖两处差额：
#let _shenzhen-bachelor = final-layout + (
  // *网格不启用*：那一节的 docGrid 写着 391/1861，可*没有 w:type*
  // ——量出来正文的汉字步进是 12.00（终稿是 12.4543），行距是 1.25 倍的 19.44
  // 而不是网格的 19.55。
  //
  // *数照留、只说它不生效*：line-pitch 仍是原件写着的 391 ＝ 19.55，
  // grid: none 一并管住贴网格与「一行有多长」两件事——标题的段前段后写的是
  // (lines: 1)／(lines: 0.8)／(lines: 0.5)（就是红字那句），网格不启用时一行
  // 折成正文的一个字号 12，与原件段落上缓存的 240／192／120 缇一个不差；
  // 终稿那一档网格启用，同样几句折成 19.55／15.64／9.78，也与它的 391／312／195
  // 对得上。见 banshi/src/layout/resolve.typ 的 fold。
  grid: none,
  char-pitch: 12pt,
  // 页眉距边界 2.4cm（w:header="1361"）＋那一段自己写的段前 12pt
  // （w:spacing w:before="240"），横线 thinThickSmallGap sz24 ＝ 3pt、离字 4pt
  // （w:space="4"）。新旧三份（旧开题、新开题、新中期）逐条相同
  header: final-layout.header + (
    shown: true,
    from-edge: 2.4cm + 12pt,
    border: (style: "thin-thick-small-gap", thickness: 3pt, from-text: 4pt),
  ),
  footer: final-layout.footer + (shown: true),
)

#let report-layouts = (
  harbin: (
    bachelor: (proposal: _bachelor-report, interim: _bachelor-report),
    master: (proposal: _graduate-report(2.2cm), interim: _graduate-report(2.3cm)),
    doctor: (proposal: _graduate-report(2.5cm), interim: _graduate-report(2.5cm)),
  ),
  // 深圳发的是*研究生*那一套：硕士与博士同一份表单。本科按本部排，
  // 见 src/axes.typ 的 campus-for
  shenzhen: (
    // 本科那两份*从终稿那一份起*，见 _shenzhen-bachelor 抬头
    bachelor: (proposal: _shenzhen-bachelor, interim: _shenzhen-bachelor),
    master: (proposal: _shenzhen-proposal, interim: _shenzhen-interim),
    doctor: (proposal: _shenzhen-proposal, interim: _shenzhen-interim),
  ),
)

// 部件差额：页函数从 page-setup-state（文档＋段）取，再把这一份并上去。
//
// 封面与内封是范例的第一节：与正文*同一组页边距*，文档网格却是
// <w:docGrid linePitch="395" charSpace="1861"/>——跨度 19.75 磅，只有贴网格的
// 那一段（中文题目）用得上；这两页也不出页眉页脚（指南 3.4「除封面及内封外」）。
//
// 声明页与合并的符号表没有自己的节，小标题的段前段后 0.5 行按正文的跨度算
// （0.5 × 391 ＝ 195 缇 ＝ 9.75，范例段 515/522 的 beforeLines=50 存的正是 195），
// 不在这张表里。
// *目录页不排页眉的那几份*，校区 → 学位 → 阶段。
//
// 深圳中期那份的说明页在「四、字体、字号及其他规定」下写着「目录不需有页眉」，
// 导出来的 PDF 也确实是：正文页有页眉，目录那一页没有。*别的几份不是*——
// 深圳开题与深圳本科那两份的目录页都带着页眉（逐页量过）；本部三份整篇没有页眉
// （说明页写的是「报告不要设置页眉」），这张表与它们无关。
#let report-toc-headerless = (
  shenzhen: (master: ("interim",), doctor: ("interim",)),
)

// 报告首页的*差额*，按校区再按阶段。首页与正文同一节的（本部五份、深圳
// 中期）不写——那一节的版面就是它自己的。
//
// *深圳开题的首页自成一节*：w:pgMar 1089/1021/1134/1021 ＝ 上 1.92 左右 1.8
// 下 2cm，docGrid linesAndChars linePitch=312 ＝ 15.6（正文那一节是 391/2662，
// 见 _shenzhen-proposal）。页眉页脚不必写——首页那个部件自己发的 set page 里
// header 与 footer 都是 none（w:titlePg，那一节的首页页眉页脚都空着）。
// *深圳本科那两份的首页自成一节*，两个阶段同一套（2026 年 9 月版逐个数
// 相同）：w:pgMar 1440/1800/1440/1800 ＝ 上下 72pt（2.54cm）、左右 90pt（1800 缇；
// 折回厘米是 3.17，再折回缇差 3 缇，所以写磅）；docGrid 395/1861 *没有
// w:type*，网格不启用（与本部本科那两份同一个写法）
#let _shenzhen-bachelor-cover = (
  margin: (top: 72pt, x: 90pt, bottom: 72pt),
  line-pitch: 19.75pt,
  char-pitch: 12pt,
)

#let report-cover-layouts = (
  shenzhen: (
    master: (
      proposal: (
        margin: (top: 1.92cm, x: 1.8cm, bottom: 2cm),
        line-pitch: 15.6pt,
        // 首页那一节*没有字距增量*（charSpace 没写 ＝ 0），正文那一节才有
        char-pitch: 12pt,
      ),
    ),
    // *本科那两份的首页同一套*（2026 年 9 月版两份逐个数相同），见
    // _shenzhen-bachelor-cover 抬头
    bachelor: (
      proposal: _shenzhen-bachelor-cover,
      interim: _shenzhen-bachelor-cover,
    ),
  ),
)

#let part-layouts = (
  cover: (line-pitch: 19.75pt, header: (shown: false), footer: (shown: false)),
  titlepage: (line-pitch: 19.75pt, header: (shown: false), footer: (shown: false)),
  // 声明页*跟论文的字符网格*，不另开一档。教务处单发的那份签字页（指南 1.7 说的就是它）
  // sectPr 里 <w:docGrid w:type="lines" w:linePitch="312"/> 没写 charSpace、各段
  // snapToGrid=0，Word 排出来汉字步进 12.0；先前这一页照它写了 char-pitch: 12pt。但装订进
  // 论文的是范例里那页：2025-05 版本科范例（威海那份，现行文本，带「（设计）」与 AI 那句）
  // 第 11 节 linesAndChars 391 / 1861，签名行 firstLineChars=800 折成 1993 缇 ＝ 8 × 12.4543
  // ——它在论文的网格上。「…使用权限如下：」那段按 12.4543 要三行，页面靠让空段收住
  // （src/pages/declarations.typ），不靠改网格。
  //
  // *研究生的声明页与成果页是另一格：charSpace 2752*。字符网格按节不按段——博士范例
  // 第 10 节（成果）、第 11 节（声明）写的是 2752，不是正文的 1861；本科两份范例的成果节
  // 也是 2752（声明节仍是 1861）。一格 ＝ 12 ＋ 2752/4096 ＝ 12.672 磅（1861 是 12.4543）。
  // 量出来的后果：声明页「（1）学校可以…」那一行 Word 排 32 个字、一个标点都不压
  // （「（」「）」各占整格），我们按 12.4543 塞进 34 个、把「）」「、」压成半格，看着是
  // 「（ 1）」——不是断行器的错，是格宽错了。2026-09-17 改按节取
  achievements: (char-pitch: 12.672pt),
  declarations-graduate: (char-pitch: 12.672pt),
)
