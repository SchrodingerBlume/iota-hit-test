#import "@local/docxtyp:0.1.0" as banshi
#import banshi.fonts: zihao
// 模板自己的页眉页脚基准格式；不依赖引擎自动套用中文 Word 样式。
#let page-text-defaults = (
  header: (
    format: (size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false,
      align: center, justify: false, tracking: 0pt, baseline: 0pt),
    border: (style: "single", thickness: 0.75pt, from-text: 1pt),
  ),
  footer: (
    format: (size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false,
      align: center, justify: false, tracking: 0pt, baseline: 0pt),
    border: none,
  ),
)
// 数值取自原始 DOCX，换算结果由 PDF 回归测试固定。
#let final-layout = (
  margin: (top: 3.8cm, rest: 3cm),
  line-pitch: 19.55pt,
  char-pitch: 12.4543pt,
  size: zihao.xiaosi,
  header: (
    shown: auto,
    from-edge: 3cm,
    format: (asian-font: "songti", size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false),
    border: (style: "thin-thick-small-gap", thickness: 2.25pt, from-text: 1pt),
  ),
  footer: (
    shown: auto,
    from-edge: 2.3cm,
    format: (size: zihao.xiaowu),
    border: none,
  ),
)
// 博后报告：《博士后研究工作报告模板》docx 的 sectPr；页眉下边框五份里四份是中间距细＋粗双线，偶数页那份的大间距判为模板毛病
#let postdoc-layout = (
  margin: (top: 3cm, bottom: 2.5cm, left: 3.5cm, right: 2.5cm),
  line-pitch: 18pt,
  char-pitch: 12.4543pt,
  size: zihao.xiaosi,
  header: (
    shown: auto,
    from-edge: 2cm,
    format: (asian-font: "songti", size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false),
    border: (style: "thin-thick-medium-gap", thickness: 1.5pt, from-text: 1pt),
  ),
  footer: (
    shown: auto,
    from-edge: 1.75cm,
    format: (size: zihao.xiaowu),
    border: none,
  ),
)
// 终稿按学位换整份版面（报告另走 report-layouts）
#let final-layouts-by-degree = (postdoc: postdoc-layout)
#let _report-footer = (
  shown: true,
  from-edge: 1.75cm,
)

#let _bachelor-report = (
  margin: (rest: 2.3cm),
  line-pitch: 15.6pt,
  size: zihao.xiaosi,
  header: (shown: false, from-edge: 0cm),
  footer: _report-footer,
)
#let _graduate-report(bottom) = (
  margin: (top: 2.5cm, x: 2.5cm, bottom: bottom),
  line-pitch: 15.6pt,
  size: zihao.xiaosi,
  header: (shown: false, from-edge: 1.5cm),
  footer: _report-footer,
)
#let _shenzhen-header = (
  shown: true,
  border: (style: "thin-thick-small-gap", thickness: 3pt, from-text: 1pt),
)

#let _shenzhen-proposal = (
  margin: (top: 3.2cm, left: 3cm, right: 2.8cm, bottom: 3cm),
  line-pitch: 19.55pt,
  char-pitch: 12.6499pt,
  size: zihao.xiaosi,
  header: _shenzhen-header + (from-edge: 3cm),
  footer: _report-footer + (from-edge: 2.3cm + 11.88pt),
)

#let _shenzhen-interim = (
  margin: (top: 2.5cm, x: 2.5cm, bottom: 2.3cm),
  line-pitch: 15.6pt,
  size: zihao.xiaosi,
  header: _shenzhen-header + (from-edge: 1.8cm),
  footer: _report-footer,
)
// 深圳博士中期原始 RTF：纸张 11905×16837 缇，四边 566／453／453／538 缇，表宽 10674 缇。
#let _shenzhen-doctor-interim = (
  paper: (width: 595.25pt, height: 841.85pt),
  // 行级 trgaph10 对应 0.5pt 内容边距；框宽仍为 10674 缇，不是整页可用宽度。
  margin: (left: 28.8pt, right: 33.75pt, top: 22.65pt, bottom: 26.9pt),
  line-pitch: 15.6pt, size: zihao.xiaosi,
  header: (shown: false), footer: (shown: false),
)
#let _shenzhen-bachelor = final-layout + (
  grid: none,
  char-pitch: 12pt,
  header: final-layout.header + (
    shown: true,
    from-edge: 2.4cm + 12pt,
    border: (style: "thin-thick-small-gap", thickness: 3pt, from-text: 4pt),
  ),
  footer: final-layout.footer + (shown: true),
)

#let report-layouts = (
  harbin: (
    bachelor: (proposal: _bachelor-report, interim: _bachelor-report),
    master: (proposal: _graduate-report(2.2cm), interim: _graduate-report(2.3cm)),
    doctor: (proposal: _graduate-report(2.5cm), interim: _graduate-report(2.5cm)),
  ),
  shenzhen: (
    bachelor: (proposal: _shenzhen-bachelor, interim: _shenzhen-bachelor),
    master: (proposal: _shenzhen-proposal, interim: _shenzhen-interim),
    // 深圳博士开题：肖同学原始 DOC 的 A4、四边 1418 缇；正文不设文字页眉。
    doctor: (proposal: _graduate-report(2.5cm), interim: _shenzhen-doctor-interim),
  ),
)
#let report-toc-headerless = (
  shenzhen: (master: ("interim",), doctor: ("interim",)),
)
#let _shenzhen-bachelor-cover = (
  margin: (top: 72pt, x: 90pt, bottom: 72pt),
  line-pitch: 19.75pt,
  char-pitch: 12pt,
)

#let report-cover-layouts = (
  shenzhen: (
    master: (
      proposal: (
        margin: (top: 1.92cm, x: 1.8cm, bottom: 2cm),
        line-pitch: 15.6pt,
        char-pitch: 12pt,
      ),
    ),
    bachelor: (
      proposal: _shenzhen-bachelor-cover,
      interim: _shenzhen-bachelor-cover,
    ),
  ),
)

#let part-layouts = (
  cover: (line-pitch: 19.75pt, header: (shown: false), footer: (shown: false)),
  titlepage: (line-pitch: 19.75pt, header: (shown: false), footer: (shown: false)),
  achievements: (char-pitch: 12.672pt),
  declarations-graduate: (char-pitch: 12.672pt),
)
