// 页面设置的机制：把 Word「页面设置」对话框那张表折成版面记录；把版面发成
// set page 加页眉页脚。
//
// ── 一节 ─────────────────────────────────────────────────────────
//
// 用户面上的 layout 就是 Word 的一个*节*：页面设置四页（页边距、文档网格）
// 加这一节的页眉页脚。收的是对话框上的格子，字段表见下面的 fold；值全是
// 用户在 Word 里看得见的数——3.8cm、19.55pt——折成缇是这一层的事。
//
// 五层梯子，每一层都是*局部字典并到上一层的输入表*，最后折一次：
//
//   本档默认（layout/presets.typ） → iota-hit(layout:) → frontmatter/mainmatter/
//   backmatter(layout:) → 部件差额（part-layouts） → 页函数 layout:
//
// 整份 msword-layout(...) 就是整份替换——它已经折好，带着 docgrid 那一族键，
// 不再往上并。折好的记录带 inputs 键，装的是折之前那张表，上面每一层都在它
// 上面并。
//
// ── 折算 ──────────────────────────────────────────────────────────
//
// 学校发的范例是 Word 排的，规范里写的也是 Word 的话：「页边距上 3.8 厘米」
// 「文档网格每页 33 行、间距 19.55 磅」。这些量与版心、行距不是一一对应的，
// 中间隔着 Word 自己的几条规则，逐条抄在下面。对照 hithesis 的
// src/utils/hit-msword.dtx。
//
// ── 页眉页脚 ──────────────────────────────────────────────────────
//
// 对照 hithesis 的 src/flow/hit-thesis-pagestyle.dtx 与 src/utils/hit-msword.dtx
// 里页眉页脚那两条规则（第六条）：页眉那个距离量到页眉块的\顶，页脚那个量到
// 页脚块的\底。
//
// Typst 这边两个锚点各差一截，换算写在下面：
//   header-ascent   量到页眉块的\底，等于版心顶减去页眉块的顶与高
//   footer-descent  量到页脚块的\顶，而规范给的是页脚基线，差一个上升部

#import "../fonts/presets.typ": zihao
#import "../msword.typ": twip
#import "../styles/linebox.typ" as linebox
#import "../styles/sheet.typ" as sheet
#import "../errors.typ" as _errors
#import "./presets.typ": final-layout, report-layouts, part-layouts
#import "../axes.typ": report-stages
#import "../axes.typ" as _axes

// 当前生效的版面。iota-hit 在最外层写进来（文档层），三个 matter 在它上面并
// （段层），页函数从这里取再并部件差额与自己那一份。ccwd 这类给用户用的函数
// 也从这里取，不必每次手动传 layout——与 fonts.current 同一个路子。
// 定义住在 src/layout/state.typ（那边说了为什么），这里再导出一次。
#import "./state.typ": layout-state

// 纸张不收：规范只有 A4
#let _paper-width = 210mm
#let _paper-height = 297mm

// 折成缇。Word 存盘的单位是缇（1/20 磅），页边距、行距、页眉页脚距边界全在
// 这个单位上取整；用户写的是对话框上的数，怎么折要看它写的是磅还是厘米：
//
//   磅    整到百分位再乘 20 取整。对话框上就两位小数，19.15 → 383 缇
//   厘米  整到百分位再乘 567 取整。Word 用 567 缇一厘米，不是精确的 566.929：
//         3.8cm → 2154.6 → 2155 缇 ＝ 107.75pt（写 3.8cm 让 Typst 精确换算得
//         107.7165，差 0.034——排版走的是缇，不是厘米）；3cm → 1701；2.3cm → 1304。
//         三个数与范例 .docx 的 pgMar 分毫不差。
//   其余  直接落缇取整（毫米、英寸那些）
//
// Typst 的 length 不记它是用什么单位写的，只能从值反推：磅数落在百分位上的当
// 磅，厘米数落在百分位上的当厘米，两个都不是就直接落缇。
//
// em、%、fr 报错：页面设置里没有「相对于字号」这一档，写了只能是手滑。
#let _twips(value, key) = {
  if type(value) != length {
    panic(key + ": expected absolute length (pt or cm), found " + repr(value))
  }
  if value.em != 0 {
    panic(key + ": expected absolute length (pt or cm), found " + repr(value) + " (em is relative)")
  }
  let near(a, b) = calc.abs(a - b) < 1e-6
  let pt = value.pt()
  let cm = value.cm()
  let twips = if near(pt, calc.round(pt, digits: 2)) {
    calc.round(pt, digits: 2) * 20
  } else if near(cm, calc.round(cm, digits: 2)) {
    calc.round(cm, digits: 2) * 567
  } else {
    pt * 20
  }
  calc.round(twips) * twip
}

// 不折的长度（move、以及 base-size 给长度时）也得是绝对量
#let _absolute(value, key) = {
  if type(value) != length or value.em != 0 {
    panic(key + ": expected absolute length, found " + repr(value))
  }
  value
}

// 字距那一格落在 1/4096 磅上：docGrid 的 w:charSpace 就是这个单位，范例写着
// 1861，1861/4096 = 0.4543pt。存的是跨度本身，跨度减字号才是字距增量。
#let _quarter-k(value, key) = {
  let v = _absolute(value, key)
  calc.round(v.pt() * 4096) / 4096 * 1pt
}

// 规则二：行距与每页行数互推，以行距为准。
// 给行数时 Word 拿版心的缇数除以行数，往下截而不是四舍五入。
#let _pitch-from-count(span, count, key) = {
  if type(count) != int or count <= 0 {
    panic(key + ": expected a positive integer, found " + repr(count))
  }
  calc.floor(span / twip / count) * twip
}

// 字数推字距*不截缇*：charSpace 的精度是 1/4096 磅，比缇细得多
#let _char-pitch-from-count(span, count, key) = {
  if type(count) != int or count <= 0 {
    panic(key + ": expected a positive integer, found " + repr(count))
  }
  calc.round(span.pt() / count * 4096) / 4096 * 1pt
}

// 页边距。收 Word 对话框的四格，外加三个简写：x（左右）、y（上下）、rest
// （没单写的那几边）。具体的压简写：(top: 3.8cm, rest: 3cm) 就是上 3.8、
// 其余三边 3。缺一边就报错，页边距没有默认值可言。
#let _margin-keys = ("top", "bottom", "left", "right", "x", "y", "rest")

#let _margin(value) = {
  if type(value) != dictionary {
    panic("margin: expected dictionary, found " + repr(value))
  }
  for k in value.keys() {
    if k not in _margin-keys {
      panic("margin: unknown key " + repr(k) + "; " + _errors.expected-one-of(_margin-keys, k))
    }
  }
  let side(name, axis) = {
    let v = value.at(name, default: value.at(axis, default: value.at("rest", default: none)))
    if v == none {
      panic("margin: missing " + name + " (write " + name + ", " + axis + ", or rest)")
    }
    _twips(v, "margin." + name)
  }
  (
    top: side("top", "y"), bottom: side("bottom", "y"),
    left: side("left", "x"), right: side("right", "x"),
  )
}

// 页眉页脚各一条记录，两份同形。键就是 Word 里那几处：
//
//   shown      排不排。auto 按档（终稿排、报告不排），true / false 就照写的
//   from-edge  页面设置 → 版式 → 「页眉／页脚距边界」，折缇
//   style      那一段的字体与段落对话框，与正文样式同一套词（src/styles/rules.typ）
//   border     页眉段落的下边框：(thickness:, from-text:) 或 none。线型是
//              thinThickSmallGap，细线与间隙各 0.75 磅由线型定死，见 _rule-gap
//   move       整块的挪动 (dx:, dy:)，不折——它是量出来的补偿，不是对话框上的数
//
// 内容不开放：按档定（本科校名式、研究生奇偶、页脚「- n -」），见 lib.typ。
#let _record-keys = ("shown", "from-edge", "style", "border", "move")
#let _shown-values = (auto, true, false)

// 记录自己的默认。距边界 0 是「什么都没写」的意思——各档的数在 layout/presets.typ
// 里；边框默认给规范那条线（粗 2.25 磅、距文字 1 磅），页脚默认没有边框。
#let _header-defaults = (
  shown: auto, from-edge: 0pt,
  style: (font-zh: "songti", size: zihao.xiaowu, line-spacing: 0),
  border: (thickness: 2.25pt, from-text: 1pt),
  move: (dx: 0pt, dy: 0pt),
)
#let _footer-defaults = (
  shown: auto, from-edge: 0pt,
  style: (size: zihao.xiaowu),
  border: none,
  move: (dx: 0pt, dy: 0pt),
)

#let _fold-record(value, name) = {
  if type(value) != dictionary {
    panic(name + ": expected dictionary, found " + repr(value))
  }
  for k in value.keys() {
    if k not in _record-keys {
      panic(name + ": unknown key " + repr(k) + "; " + _errors.expected-one-of(_record-keys, k))
    }
  }
  let shown = value.at("shown")
  if shown not in _shown-values {
    panic(name + ".shown: expected auto, true, or false, found " + repr(shown))
  }
  // 样式那一格与 styles 表里的一条同形，词汇与值域也同一张，见
  // src/styles/sheet.typ 的 validate-style
  let style = value.at("style")
  sheet.validate-style(style, name + ".style")
  let border = value.at("border")
  let border = if border == none { none } else {
    if type(border) != dictionary {
      panic(name + ".border: expected none or dictionary with \"thickness\" and \"from-text\", found " + repr(border))
    }
    for k in border.keys() {
      if k not in ("thickness", "from-text") {
        panic(name + ".border: unknown key " + repr(k) + "; expected \"thickness\" or \"from-text\"")
      }
    }
    for k in ("thickness", "from-text") {
      if k not in border { panic(name + ".border: missing " + k) }
    }
    (
      thickness: _twips(border.thickness, name + ".border.thickness"),
      from-text: _twips(border.from-text, name + ".border.from-text"),
    )
  }
  let move = value.at("move")
  if type(move) != dictionary {
    panic(name + ".move: expected dictionary with \"dx\" and \"dy\", found " + repr(move))
  }
  for k in move.keys() {
    if k not in ("dx", "dy") {
      panic(name + ".move: unknown key " + repr(k) + "; expected \"dx\" or \"dy\"")
    }
  }
  (
    shown: shown,
    from-edge: _twips(value.at("from-edge"), name + ".from-edge"),
    style: style,
    border: border,
    move: (
      dx: _absolute(move.at("dx", default: 0pt), name + ".move.dx"),
      dy: _absolute(move.at("dy", default: 0pt), name + ".move.dy"),
    ),
  )
}

// 局部字典并到输入表。header / footer 那两条记录（以及记录里的 style、border、
// move 字典）再深一层合并：写 (header: (shown: false)) 只动这一格，距边界与
// 边框照旧。给 none 的（border: none）就是替换。margin 也逐键并，但简写要让路，
// 见 _merge-margin。别的键整个替换。
#let _deep-keys = ("header", "footer")

#let _merge-dict(base, local) = {
  let out = base
  for (k, v) in local {
    if type(v) == dictionary and type(out.at(k, default: none)) == dictionary {
      out.insert(k, _merge-dict(out.at(k), v))
    } else {
      out.insert(k, v)
    }
  }
  out
}

// 页边距那张表逐键并——用户写 (margin: (top: 3cm)) 是「上边距改成 3cm」，不是
// 「页边距只剩上边距」。可简写与具体边之间有压制关系（具体 > x/y > rest，见
// _margin），照搬 _merge-dict 会让默认里的简写压不住、局部的简写压不动，所以
// 先把局部这一份压掉的默认清掉，再逐键并：
//
//   局部写了具体边    只换那一边
//   局部写了 x        默认里的 left / right 让路
//   局部写了 y        默认里的 top / bottom 让路
//   局部写了 rest     默认里六个全让路，再并
//
// 终稿默认 (top: 3.8cm, rest: 3cm) 并上 (top: 3cm) 得 (top: 3cm, rest: 3cm)
// ——上 1701 缇 ＝ 85.05，其余三边照旧；并上 (rest: 2cm) 得 (rest: 2cm)，四边全
// 1134 缇；并上 (x: 2.5cm) 得 (top: 3.8cm, rest: 3cm, x: 2.5cm)，左右 1418 缇，
// 上下不动。并完仍照 _margin 的次序解。对拍件 tests/demo-layout-margin.typ。
#let _margin-clears = (
  x: ("left", "right"),
  y: ("top", "bottom"),
  rest: ("top", "bottom", "left", "right", "x", "y"),
)

#let _merge-margin(base, local) = {
  let cleared = ()
  for (k, sides) in _margin-clears {
    if k in local { cleared += sides }
  }
  let out = base.pairs().filter(((k, _)) => k not in cleared).to-dict()
  for (k, v) in local { out.insert(k, v) }
  out
}

#let merge(base, local) = {
  if type(local) != dictionary {
    panic("layout: expected dictionary, found " + repr(local))
  }
  let out = base
  for (k, v) in local {
    if k == "margin" and type(v) == dictionary and type(out.at(k, default: none)) == dictionary {
      out.insert(k, _merge-margin(out.at(k), v))
    } else if k in _deep-keys and type(v) == dictionary and type(out.at(k, default: none)) == dictionary {
      out.insert(k, _merge-dict(out.at(k), v))
    } else {
      out.insert(k, v)
    }
  }
  out
}

// 字段表。不认识的键当场报错并列全表。
#let _keys = (
  "margin", "line-pitch", "lines-per-page", "char-pitch", "chars-per-line",
  "base-size", "latin-line-height", "grid", "header", "footer",
)
#let _latin-line-heights = (auto, "latin", "cjk")

// 把输入表折成版面记录。
//
// 规则一：版心只由页边距定。宽是纸宽减左右边距，高是纸高减上下边距。
//         文档网格不参与，页眉页脚也不占版心。
// 规则七：一行只排整数个字，装不满的余量原样留在右边不摊开。
#let fold(inputs) = {
  if type(inputs) != dictionary {
    panic("layout: expected dictionary, found " + repr(inputs))
  }
  for k in inputs.keys() {
    if k not in _keys {
      panic("layout: unknown key " + repr(k) + "; " + _errors.expected-one-of(_keys, k))
    }
  }
  let margin = _margin(inputs.at("margin", default: (:)))
  let text-width = _paper-width - margin.left - margin.right
  let text-height = _paper-height - margin.top - margin.bottom

  // 基准字号：这一节 Normal 样式的字号。长度（zihao.xiaosi 或 12pt）
  let base-size = inputs.at("base-size", default: zihao.xiaosi)
  if type(base-size) != length or base-size.em != 0 {
    panic("base-size: expected absolute length such as zihao.xiaosi or 12pt, found " + repr(base-size))
  }

  // 行距与每页行数二选一。都给了就按 Word 显示的关系校验：对话框上「行数」
  // 那一格显示的是 floor(版心高 ÷ 跨度)，两个数对不上就是写错了一个
  let given-pitch = inputs.at("line-pitch", default: none)
  let given-lines = inputs.at("lines-per-page", default: none)
  if given-pitch == none and given-lines == none {
    panic("layout: expected line-pitch or lines-per-page")
  }
  let line-pitch = if given-pitch != none {
    _twips(given-pitch, "line-pitch")
  } else {
    _pitch-from-count(text-height, given-lines, "lines-per-page")
  }
  if given-pitch != none and given-lines != none {
    let shown = calc.floor(text-height / line-pitch)
    if shown != given-lines {
      panic(
        "layout: line-pitch " + repr(given-pitch) + " gives " + str(shown)
          + " lines per page, but lines-per-page says " + str(given-lines)
          + "; write one of them, or make them agree",
      )
    }
  }

  // 字距那一格同样二选一；没给就没有字符网格，字距增量为零
  let given-char = inputs.at("char-pitch", default: none)
  let given-chars = inputs.at("chars-per-line", default: none)
  let char-pitch = if given-char != none {
    _quarter-k(given-char, "char-pitch")
  } else if given-chars != none {
    _char-pitch-from-count(text-width, given-chars, "chars-per-line")
  } else {
    0pt
  }
  if given-char != none and given-chars != none {
    let shown = calc.floor(text-width / char-pitch)
    if shown != given-chars {
      panic(
        "layout: char-pitch " + repr(given-char) + " gives " + str(shown)
          + " characters per line, but chars-per-line says " + str(given-chars)
          + "; write one of them, or make them agree",
      )
    }
  }

  // 规则八：字距*增量*与字号无关，一格的宽度才与字号有关。
  //
  // docGrid 上写的是 w:charSpace，单位是 1/4096 磅：范例的封面与正文
  // 都写着 charSpace=1861，1861/4096 = 0.4543pt。实测这个增量在 12pt、
  // 22pt、24pt 三个字号上都是同一个数（封面 22pt 量到 22.437、
  // 24pt 量到 24.500，都是字号加 0.4543 再落到 Word 的落笔格上），
  // 所以它是*每个全宽字后面加一段定长*，不是「一格减字号」。
  //
  // 一格的宽度 = 基准字号 + 增量。缩进按「几个字」算时用的是一格的宽度
  // ——范例正文 firstLineChars=200 存成 firstLine=498 缇 = 24.9pt = 2×12.45，
  // 对得上。字距增量则不能用「一格减字号」倒推：那个式子只在基准字号上
  // 成立，封面的 22pt 拿它算会得到 −9.5。所以这里存的是「跨度减*基准*字号」。
  let tracking = if char-pitch == 0pt { 0pt } else { char-pitch - base-size }
  let cells = if char-pitch == 0pt { 0 } else { calc.floor(text-width / char-pitch) }

  // *文档网格启没启用*——Word 的 w:docGrid 有没有 w:type。
  //
  // auto ＝ 启用：范例与本部那几份表单的每一节都写着 type="linesAndChars"。
  // 写 false 就是那一节的 docGrid *只有 linePitch／charSpace 而没有 w:type*
  // ——数照记（原件写着多少就是多少），可 Word 不拿它排。深圳本科那两份报告
  // 正是这一档（391/1861，没有 w:type）。
  //
  // 它管两件事：贴不贴行网格，以及*「一行」有多长*（见下面的 line-unit）。
  let grid = inputs.at("grid", default: auto)
  if grid not in (auto, true, false) {
    panic("grid: " + _errors.expected-one-of((true, false), grid) + " (or auto)")
  }
  let grid = grid != false

  // 纯西文行按哪一份行高：auto ＝ "latin"（照 Word，按 Times 的 1.15），
  // "cjk" 一律按中文行高。读点在 src/styles/linebox.typ 的 resolve
  let latin-line-height = inputs.at("latin-line-height", default: auto)
  if latin-line-height not in _latin-line-heights {
    panic(
      "latin-line-height: " + _errors.expected-one-of(("latin", "cjk"), latin-line-height)
        + " (or auto)",
    )
  }

  // 两条记录先验是不是字典再并——写 header: false 那种，并进去会在 for 上炸出
  // 「cannot loop over boolean」，指不到路
  for (k, defaults) in (header: _header-defaults, footer: _footer-defaults) {
    let v = inputs.at(k, default: (:))
    if type(v) != dictionary {
      panic(
        k + ": expected dictionary (" + _record-keys.map(x => x + ":").join(", ")
          + "), found " + repr(v) + "; to drop it write (shown: false)",
      )
    }
  }
  let header = _fold-record(
    _merge-dict(_header-defaults, inputs.at("header", default: (:))), "header",
  )
  let footer = _fold-record(
    _merge-dict(_footer-defaults, inputs.at("footer", default: (:))), "footer",
  )

  (
    paper-width: _paper-width,
    paper-height: _paper-height,
    margin: margin,
    text-width: text-width,
    text-height: text-height,
    docgrid: (
      line-pitch: line-pitch,
      char-pitch: char-pitch,
      tracking: tracking,
      latin-line-height: latin-line-height,
      grid: grid,
      // *段前段后写 (lines: n) 时乘的就是它*。Word 的「行」有两种长度，
      // 由网格开关定：
      //
      //   网格启用    一个网格行（终稿范例 391 缇 ＝ 19.55）
      //   不启用      正文的一个字号（深圳本科报告 240 缇 ＝ 小四 12）
      //
      // 出处是 Word 自己缓存在段落上的折算，六个数一个不差：终稿的
      // 1 行 → 391、0.8 行 → 312、0.5 行 → 195（基准 391）；深圳本科报告的
      // 1 行 → 240、0.8 行 → 192、0.5 行 → 120（基准 240）。两份样式里写的
      // 都是 beforeLines="100" afterLines="80" ／ beforeLines="50"，一模一样
      // ——正是两份红字说明里那句「段前1行，段后0.8行 ／ 0.5行」。
      line-unit: if grid { line-pitch } else { base-size },
    ),
    base-size: base-size,
    cells: cells,
    header: header,
    footer: footer,
    inputs: inputs,
  )
}

// 整份版面。收 Word「页面设置」与这一节页眉页脚的那几格，字段与折法见 fold。
// 交给 iota-hit(layout:) 就是整份替换，不再往上并。
#let msword-layout(
  margin: (:),
  line-pitch: none,
  lines-per-page: none,
  char-pitch: none,
  chars-per-line: none,
  base-size: zihao.xiaosi,
  latin-line-height: auto,
  header: (:),
  footer: (:),
) = fold((
  ("margin", margin), ("line-pitch", line-pitch), ("lines-per-page", lines-per-page),
  ("char-pitch", char-pitch), ("chars-per-line", chars-per-line),
  ("base-size", base-size), ("latin-line-height", latin-line-height),
  ("header", header), ("footer", footer),
).filter(((k, v)) => v != none).to-dict())

// 折好的记录还是局部字典。折好的带 docgrid（no-docgrid 那份假记录也带）
#let is-folded(value) = type(value) == dictionary and "docgrid" in value

// 本档默认那张输入表：终稿一份，报告按学位与阶段各一份，见 layout/presets.typ
#let default-inputs(degree-level: "bachelor", stage: "final", campus: "harbin") = {
  if stage in report-stages {
    // 校区 → 学位 → 阶段。深圳那两份是另发的表单，见 layout/presets.typ；
    // *深圳只有硕士那两份*，本科与博士按本部排，见 axes.typ 的 campus-for
    let by-campus = report-layouts.at(_axes.campus-for(campus, degree-level))
    let by-degree = by-campus.at(degree-level, default: none)
    if by-degree == none {
      panic(_errors.expected-one-of(by-campus.keys(), degree-level) + " (degree-level)")
    }
    by-degree.at(stage)
  } else {
    final-layout
  }
}

// 局部并到某一层。local 是 auto（什么都不改）、局部字典（并上去再折）或整份
// （直接用）。base 是折好的记录，并在它的 inputs 上。
#let resolve-local(base, local) = {
  if local == auto { return base }
  if is-folded(local) { return local }
  fold(merge(base.inputs, local))
}

// 页函数那一层：文档＋段（layout-state）→ 部件差额 → 这一页自己的。
// *要在 context 里调*。没进过 iota-hit 的文档（对拍件直接调页函数）从
// 本档默认起。part 给 none 就没有部件差额。
#let layout-for(part, local) = {
  if is-folded(local) { return local }
  let s = layout-state.get()
  let inputs = if s == none { default-inputs() } else { s.inputs }
  if part != none { inputs = merge(inputs, part-layouts.at(part, default: (:))) }
  if local != auto { inputs = merge(inputs, local) }
  fold(inputs)
}

// 当前生效的那一份（文档＋段），没进过 iota-hit 的文档从本档默认起。正文的 show
// 规则（标题、题注、公式、段落里的西文 run）在各自的 context 里调它取版面的数——
// 段级改了行跨度、版心，规则里的数当场跟着换，不用装规则时捕获的那份。
// *要在 context 里调*
#let current-layout() = layout-for(none, auto)

// 同一件事的免 context 版：只有本档默认加部件差额。封面与内封在 context 外面
// 发 set page，直接调它们的对拍件走这一条；用户那条路（lib.typ 的 cover）
// 由 src/api.typ 在 context 里用 layout-for 填好再传进来。
#let standalone-layout(part) = fold(
  merge(default-inputs(), part-layouts.at(part, default: (:))),
)
