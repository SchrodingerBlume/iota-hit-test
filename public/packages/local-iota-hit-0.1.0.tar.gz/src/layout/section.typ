// 一节的 set 规则：版心与页眉页脚（set page）加正文那一档的字与段（set text /
// set par）。
//
// 五层梯子里「段」那一层落地的地方。版面分两类规则接到 Typst 上：
//
//   set 规则   能重发——内层压外层，重发不叠加。iota-hit 在文档级发一次，
//              frontmatter / mainmatter / backmatter 在自己的 show 作用域里用并好的
//              版面再发一次，段级改的版心、行跨度、页眉页脚就落到那一段的页上。
//   show 规则  绝不能重发——latin-run 那条会在西文前补 h(tracking)，重发就补两次。
//              只在文档级装一次（lib.typ），规则里用到版面的数都在各自的 context 里
//              从 layout-state 现取（src/styles/rules.typ 的 shows、src/blocks 的
//              heading-rules / caption-rules / equation-rules / body-rules）。
//
// *页眉页脚的内容闭包跟着 set page 一起重发，不从 state 读。* 自己量过
// （typst 0.15）：页眉里 state.get() 读到的是*本页开头之前*的值，页脚读到的是
// *本页末尾*的值。段的 update 只能落在某一页上——落在跳页之前，上一页的页脚
// 就读到下一段的；落在跳页之后，下一页的页眉就读到上一段的。两头总有一页错。
// set page 是按作用域切页的，页眉页脚跟着它走一页不差，所以整条 set page 连内容
// 一起重发；重发的只是内容闭包，不是 show 规则。
//
// 段边界的 set page 会引起分页，而 matter 入口本来就跳页，不多一页（对拍
// tests/check-assemble.py 与 tests/matrix 的页序不变）。

#import "./resolve.typ" as _layout
#import "./rules.typ": page-rules, decorated-number
#import "../styles/rules.typ" as style-rules
#import "../styles/sheet.typ" as sheet
#import "../fonts/resolve.typ" as _fonts
#import "../info.typ": info-get
#import "./header.typ": final-header-body, report-header-body
#import "../axes.typ": report-stages

// 发一节的 set。styles 是样式表（正文那一档从里面取），font-table 是解析好的角色表，
// stage 定报告那两档的页眉页脚默认（auto ＝ 报告不排）。三样给 auto 就从 state 取
// ——matter 在 context 里这么调；iota-hit 自己刚算好，直接传，不必等 state 落地。
// 前置段与正文段的页码制式。*住在这儿是因为页脚要按它分档*——报告的前置
// 那一页不加短横（见下面的 footer-content）。matter 发 set page 时从这儿取，
// 两处认的是同一个字面
#let front-page-numbering = "I"
#let main-page-numbering = "1"

#let section-sets(layout, styles: auto, font-table: auto, stage: auto, doc) = {
  let styles = if styles == auto { sheet.styles-state.get() } else { styles }
  let f = if font-table == auto { _fonts.current.get() } else { font-table }
  let stage = if stage == auto { info-get().stage } else { stage }
  let body = styles.body
  let family = f.at(body.at("font-zh", default: "songti"))
  // 页眉页脚排不排看 layout 里那两条记录的 shown：auto 按档——终稿排、报告不排
  // （两份表单的三份 header 都是空的，页脚见 src/layout/presets.typ）。内容按档定，
  // 不开放：本科校名式、研究生奇偶交替、页脚「- n -」
  let is-report = stage in report-stages
  let shown(record) = if record.shown == auto { not is-report } else { record.shown }
  show: page-rules.with(
    layout,
    font-table: f,
    body-font: family,
    // *页眉的内容按 stage 分两支*：终稿走论文那一条（本科校名式、研究生
    // 奇偶交替、跟着本章走），报告走表单上印死的那一行（见 layout/header.typ）
    header-content: if not shown(layout.header) { none } else if is-report {
      () => report-header-body()
    } else { () => final-header-body(auto) },
    // *没有页码制式就不排页码*。counter(page).display() 在 numbering 为 none
    // 时照样给「1」（实测），照它排的话报告的目录页会印出一个「- 1 -」——而深圳
    // 那四份原件的目录页页脚都是空的，正文那一节才从 1 起。Word 的模型也是这个：
    // 页脚里没有 PAGE 域就什么都不印。报告的文档级 numbering 是 none、mainmatter
    // 换成 "1"（见 lib.typ 与 src/layout/matter.typ），于是前置不印、正文印
    footer-content: if shown(layout.footer) {
      () => context if page.numbering != none {
        // *正文一律「- n -」*。深圳研究生开题那两份的页脚在原件里是一个光
        // PAGE 域（Word 排出来就是「1」），另外六份写的都是「- PAGE -」——当作
        // 那两份漏写，不跟（用户定的）。
        //
        // *报告的前置那一页不加短横*：深圳本科 2026 年 9 月版两份的目录页
        // 印的就是光一个号（中期罗马「I」、开题阿拉伯「1」，都在 x≈296），正文
        // 那一节才是「- 1 -」（x 288.00–307.54）。*论文不在此列*——本科范例
        // 的前置三页印的是「- I -」「- II -」「- III -」，带短横
        if is-report and page.numbering == front-page-numbering {
          counter(page).display()
        } else {
          decorated-number(counter(page).display())
        }
      }
    } else { none },
  )
  // 正文那一档的字与段。字体不在这里设——那是 iota-hit 在最外层设的一句
  // set text(font:)，与版面无关。latin-par: true ＝ 正文的段参与「纯西文段换西文行盒」
  // 那条 show par（src/styles/body.typ），别的部件默认不参与
  show: style-rules.sets.with(body, layout: layout, latin-par: true)
  // 引擎画字符网格那一档的 set par(linebreaks:)——文档级与每个 matter 段各发一次，
  // 没给 --input linebreaks 就什么都不发，见 src/layout/resolve.typ 的「断行引擎」
  show: _layout.linebreaks-sets.with(layout)
  doc
}
