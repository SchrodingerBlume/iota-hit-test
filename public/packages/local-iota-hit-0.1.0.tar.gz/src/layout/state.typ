// 当前生效的版面（一节）。
//
// iota-hit 在最外层写进来（文档层），三个 matter 在它上面并（段层），页函数从这里
// 取再并部件差额与自己那一份；ccwd 这类给用户用的函数也从这里取——与 fonts.current
// 同一个路子。
//
// *单独成一个文件，只为断开一个环*：src/layout/resolve.typ 要用 src/styles/rules.typ
// 的换算（页眉页脚的行盒），而 styles.typ 里正文那几条 show 规则又要在 context 里
// 读这个 state（段级改了版面，规则里的数得跟着换，见那边的 shows）。Typst 不许互相
// import，所以 state 落在两边都能 import 的地方。写 layout-state 或
// layout.layout-state 的地方一个字不用改——两边都再导出一次。
#let layout-state = state("iota-hit-layout", none)
