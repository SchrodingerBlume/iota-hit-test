// 当前生效的版面（一节）。
//
// iota-hit 在最外层写进来（文档层），三个 matter 在它上面并（段层），页函数从这里
// 取再并部件差额与自己那一份；ccwd 这类给用户用的函数也从这里取——与 fonts.current
// 同一个路子。
//
// *单独成一个文件，只为断开一个环*：src/layout/resolve.typ 要用 src/styles/rules.typ
// 的换算（页眉页脚的行盒），而 styles.typ 里正文那几条 show 规则又要在 context 里
// 读这个 state（段级改了版面，规则里的数得跟着换，见那边的 shows）。Typst 不许互相
// import，所以 state 落在两边都能 import 的地方。写 layout-state 或
// layout.layout-state 的地方一个字不用改——两边都再导出一次。
// *state 名是站内预览的接口*（iota4web 直接读过它；现在有公开的 current-layout()，但名字仍别动）
#let layout-state = state("iota-hit-layout", none)

// 这一节（文档级或 matter 段）的版面，不含章级的改写。layout-state 是*当前生效*的那一份
// ——#chapter(layout:) 会把它改成「这一节 ⊕ 这一章」，下一章没写就退回这一份；正文那条
// show par 拿两者比，不同才按当前那份重发字距与行盒。写 layout-state 的两处（iota-hit、
// matter）同时写它
#let section-layout-state = state("iota-hit-section-layout", none)

// 这一段（matter）的版面：restore-layout 回到的那一份。new-layout 开的节写 section-layout-state
// 不写它；iota-hit 与写了 layout 的 matter 三个都写
#let matter-layout-state = state("iota-hit-matter-layout", none)
