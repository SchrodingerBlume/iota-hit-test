// 公式底下那份符号注释——「式中　x——某某；」。
//
// 依据是写作指南 2.11 公式：
//
//   公式中第一次出现的物理量代号应给予注释，*注释的转行应与破折号「——」
//   后第一个字对齐。破折号占 4 个半角字符*，注释物理量需用公式表示时，公式后
//   不应出现公式序号。格式见下例：
//     式中　　——试样断裂前的最大扭矩()；
//     式中　　、——分别为定子、转子绕组电阻（Ω）；
//
// 第二个示例说明*一条可以挂多个符号*（用「、」连）。
//
// *形制照范例的规范章那张表量的*（「1-8 页+规范章补全+中英摘要」，
// 段 580–603，是一张四列无框表）：
//
//   列0  715 缇 − 两侧单元格边距 216 ＝ 499 缇 ＝ 24.95pt ＝ 2 个汉字宽  「式中」，左
//   列1  472 − 216 ＝ 256 缇 ≈ 1 个汉字宽                             符号，*右对齐*
//   列2  715 − 216 ＝ 499 缇 ＝ 2 个汉字宽（「——」正好两个全角）        破折号，居中
//   列3 6450 − 216 ＝ 311.7pt                                        说明，左，转行悬挂
//
// 范例第 4 章还有一处是*手敲的*——三行各自一段，缩进写成 firstLineChars
// 280 与 292，*两行数值都不一样*。按证据次序（styles.xml → 指南原话 →
// 段落级直接格式）那一处不作数。
//
// *顶格。* 指南那两行示例与范例段 235 都*没有* w:ind，而紧挨着的正文段
// 都显式写着 firstLineChars=200。所以引导词顶格，不跟正文的首行缩进。
//
// *学 hithesis 的 eqdenote*（v3.2a 手册 2.8.3）：每条注释一个 \item，
// 「引导词、列距、破折号与表后的行距都由环境处理」，底下是 xltabular、放不下
// 自动转页接排；手动拆成两段时*可选参数传空*，后半段不再重复引导词而左缘
// 照旧对齐。引导词这个口子照抄，见 lead。
#import "@local/banshi:0.1.0" as banshi
#import banshi.layout as chars
#import banshi.styles as style-rules
#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-of

// 破折号。*指南写死「占 4 个半角字符」*，而「——」本身就是两个全角，
// 正好 4 个半角——所以这一列的宽度就是它的自然宽度，不必另设。
#let _dash = [——]

// 上一块的符号列宽。*给 lead: none 那一档用*——手动拆开的后半段要与前半段
// 左缘对齐（hithesis 的承诺就是这一条），可两半各按自己最宽的符号算宽就对不上了：
// 实测前半段只有 $k$、后半段只有 $b$，两个字形宽度差 0.13，说明列跟着错开
// 153.190 / 153.321。所以后半段沿用前一块记下的宽度，取两者的大者——自己更宽时
// 不至于挤掉破折号。
#let _last-symbol-width = state("iota-hit-eqdenote-symw", 0pt)

// 把 terms 元素拆成 (符号, 说明) 的表。
//
// *输入收原生的 terms 语法*（`/ 符号: 说明`）。语义完全对应——它就是
// Typst 的术语列表；多符号那一档写 `/ $x$、$y$: …` 天然成立，不必另造语法。
// 解析器与 nomenclature 共用，见 banshi/src/paragraph/terms.typ
#import banshi.paragraph: items as _items

#let _rows(body) = {
  let items = _items(body)
  if items.len() == 0 {
    panic(
      "expected a term list, found " + repr(body.func())
        + " (write eqdenote[/ $x$: explanation])",
    )
  }
  items.map(it => (it.term, it.description))
}

// 公式底下的符号注释。
//
// lead 是引导词：auto 取词条（中文档「式中」、英文档 where），none 不印。
// *none 那一档是给手动拆开的后半段用的*——引导词不重复，而左缘照旧对齐，
// 与 hithesis 的 \begin{eqdenote}[] 同义。
#let eqdenote(lead: auto, body) = context {
  let rows = _rows(body)
  if rows.len() == 0 { return }
  let word = if lead == auto { term-of(doc-lang.get(), "caption", "denote") } else { lead }
  // 引导词那一列：范例是 2 个汉字宽（715 缇减掉两侧单元格边距 216）。取最大值
  // 而不是钉死——英文档的 where 比两个汉字还宽，钉死就折行了。
  let lead-width = calc.max(
    chars.ccwd(2).to-absolute(),
    if word == none { 0pt } else { measure(word).width },
  )

  // *一个字都不重设。* 字体、字号、行盒、字距、段距全走*正文那一份*
  // ——banshi/src/styles/body.typ 装的 style-rules.rules 就罩在这个块上，改 iota-hit(body: …) 它
  // 自动跟上。只覆盖首行缩进：引导词与每一条都顶格，见上面的证据。
  set par(first-line-indent: 0pt)
  // 符号那一列*宽度就等于最宽的那个符号*，右对齐。
  //
  // *不设下限。* 范例把它钉死在一个汉字宽（472 缇），那是连着它的单元格边距
  // 一起看才成立的；我们的空当由列间距给（见下），再垫一个下限就成了双份——实测
  // 一条只有 $k$ 时，列宽被垫到 12.45、符号在里面右对齐，左缘落在 128.999，
  // 离「式中」19.5，快两个 ccwd 了。
  //
  // 去掉下限之后规则干净：*最宽的那个符号，左缘正好离「式中」一个 ccwd*。
  // 比它窄的行会被右对齐推开——那是右对齐的必然结果，不是间距设错了，取舍是
  // 保住破折号成列（范例那一列写着 jc=right）。
  let own = calc.max(0pt, ..rows.map(r => measure(r.at(0)).width))
  // *照搬，不取大者。* 取 max 时后半段若有更宽的符号，用的还是它自己那一份，
  // 左缘照样对不上（实测 $k$ 5.5 与 $b$ 5.6，max 之后仍是两个值）。照搬才对齐，
  // 与 hithesis 那个固定宽度的列同义；后半段真有更宽的符号就往左伸进空当里，
  // 这与 hithesis 的行为一致。
  let carried = _last-symbol-width.get()
  let symbol-width = if word == none and carried > 0pt { carried } else { own }
  _last-symbol-width.update(symbol-width)
  grid(
    columns: (lead-width, symbol-width, auto, 1fr),
    // 引导词与符号之间空*一个汉字宽*。指南那两行示例写的是「式中」加
    // *2 个半角空格*再接符号——Word 的字符网格里半角占半格，两个正好一格。
    // 范例表里那一处是单元格边距 108+108 缇 ＝ 10.8pt，与一格 12.45 同量。
    // 别的两处不空：破折号紧跟符号，说明紧跟破折号，指南与范例都是。
    column-gutter: (chars.ccwd(1), 0pt, 0pt),
    row-gutter: 0pt,
    align: (left + top, right + top, center + top, left + top),
    ..rows
      .enumerate()
      .map(((i, r)) => (
        if i == 0 and word != none { word } else { [] },
        r.at(0),
        _dash,
        r.at(1),
      ))
      .flatten(),
  )
}
