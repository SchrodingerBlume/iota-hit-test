#import "@local/banshi:0.1.0" as banshi
#import banshi.layout: chars
#import banshi.styles as style-rules
#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-of
#let _dash = [——]
#let _last-symbol-width = state("iota-hit-eqdenote-symw", 0pt)
#import "../pages/terms.typ": items as _items

#let _rows(body) = {
  let items = _items(body)
  if items.len() == 0 {
    panic(
      "expected a term list, found " + repr(body.func())
        + " (write eqdenote[/ $x$: explanation])",
    )
  }
  items.map(it => (it.term, it.description))
}
#let eqdenote(lead: auto, body) = context {
  let rows = _rows(body)
  if rows.len() == 0 { return }
  let word = if lead == auto { term-of(doc-lang.get(), "caption", "denote") } else { lead }
  let lead-width = calc.max(
    chars(2).to-absolute(),
    if word == none { 0pt } else { measure(word).width },
  )
  set par(first-line-indent: 0pt)
  let own = calc.max(0pt, ..rows.map(r => measure(r.at(0)).width))
  let carried = _last-symbol-width.get()
  let symbol-width = if word == none and carried > 0pt { carried } else { own }
  _last-symbol-width.update(symbol-width)
  grid(
    columns: (lead-width, symbol-width, auto, 1fr),
    column-gutter: (chars(1), 0pt, 0pt),
    row-gutter: 0pt,
    align: (left + top, right + top, center + top, left + top),
    ..rows
      .enumerate()
      .map(((i, r)) => (
        if i == 0 and word != none { word } else { [] },
        r.at(0),
        _dash,
        r.at(1),
      ))
      .flatten(),
  )
}
