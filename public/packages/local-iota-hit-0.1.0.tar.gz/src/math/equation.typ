#import "../docxtyp.typ" as banshi
#import banshi.paragraph: families-of
#import banshi.content: plain-text
#import "../settings/resolve.typ": setting-of
#import "../styles/lookup.typ": current-styles
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang
// U+2206 是有限增量符号，不是希腊字母 Δ（U+0394）。
#let increment = math.upright("\u{2206}")

// GB/T 3102.11：偏导正体、实虚部用算符、斜等号和平行号。
#let gb-rules(fontset, doc) = {
  show math.equation: set text(font: (
    (name: fontset.families.songti, covers: regex("∥")),
    fontset.math, fontset.families.songti,
  ))
  show math.equation: it => {
    show sym.partial: math.upright
    show sym.Re: math.op("Re")
    show sym.Im: math.op("Im")
    show sym.lt.eq: sym.lt.eq.slant
    show sym.gt.eq: sym.gt.eq.slant
    it
  }
  doc
}

#let equation-rules(by-chapter: true, supplement: [式], top: 1, doc) = {
  let eq-numbering = (..n) => context {
    let (open, close) = if setting-of("equation-numbering-fullwidth") == true {
      ("（", "）")
    } else { ("(", ")") }
    let num = if by-chapter {
      _numbering.chapter-numbered(
        here(), n.pos(), open: open, close: close,
        prefix: _numbering.appendix-prefix(here(), doc-lang.get()),
      )
    } else {
      numbering(open + "1" + close, ..n.pos())
    }
    // 编号是公式段里的普通字：正文字体（Times），不随公式用数学字体。网格字距照正文，西文半份、
    // 中文整份；正文那条半份的规则认出这是公式就不管，这里逐段排，接缝上补回丢的那份
    let lay = banshi.layout.current-page-setup()
    let t = if banshi.layout.emulated(lay) { lay.docgrid.tracking } else { 0pt }
    let runs = plain-text(num).matches(regex("[!-~]+|[^!-~]+")).map(m => m.text)
    text(font: families-of(current-styles().body, banshi.fonts.fontset-state.get()), runs.enumerate().map(((i, r)) => {
      let tr = if r.match(regex("^[!-~]+$")) != none { t / 2 } else { t }
      text(tracking: tr, r) + (if i < runs.len() - 1 { h(banshi.fonts.boundary-pad(tr)) })
    }).join())
  }
  set math.equation(supplement: supplement, numbering: eq-numbering)
  show heading.where(level: top): it => context {
    if by-chapter and math.equation.numbering == eq-numbering {
      counter(math.equation).update(0)
    }
    it
  }
  show math.equation.where(block: true): it => context {
    if math.equation.numbering != none and math.equation.numbering != eq-numbering {
      panic(
        "equation numbering has no effect (write "
          + "iota-hit(equation-numbering-fullwidth: true) for full-width "
          + "brackets, or iota-hit(equation-numbering-by-top-level-heading: false) "
          + "for continuous numbering)",
      )
    }
    it
  }
  doc
}
