// 公式的编号：按章（附录里「附」进括号）或连续、括号半角还是全角、换掉编号当场报错。
// 这一半是模板的（指南 2.11）；字体、国标字形、行高那一半是 Word 的行为，banshi.document 自己装。
#import "../settings/resolve.typ": setting-of
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang

// GB/T 3102.11 的有限增量：正体 U+2206 INCREMENT，不是希腊字母 Δ。
#let increment = math.upright("\u{2206}")

#let equation-rules(by-chapter: true, supplement: [式], doc) = {
  // *括号取半角，跟范例。* 指南 2.11 的叙述写的是全角——「序号为『（1-1）』」
  // （U+FF08/FF09），而范例*印出来*是半角 U+0028/0029。与分图号那一处是同一
  // 处矛盾的两个面（指南写「（a）」、范例印「(a) 」），两边照同一条取舍走。
  //
  // *是 set，不是 show math.equation: set。* 与 src/figure/caption.typ 的
  // 图表编号同一个理由：摆在 show 规则里，用户写 #set math.equation(numbering: …)
  // 盖不过我们，而且我们*读不到*他写了什么。挪到文档级，这一份就成了哨兵
  // ——闭包比得了身份，用户一改就分得出来。
  // *一个闭包管两档。* 括号宽窄要在排的时候查（setting-of 要上下文，而这句
  // set 在文档级、那会儿还没有）；按不按章是排版前就定死的参数，直接闭进来。
  //
  // 一条编号串管按章与连续：按章喂两个数、连续喂一个，Typst 的 numbering 自动截断
  // （实测 numbering("(1-1)", 5) 给出 "(5)"），不必另写一份。
  //
  // *连字符不跟着括号变全角*——指南那句原话里全角括号中间夹的就是半角
  // 连字符 U+002D，逐字量过。
  let eq-numbering = (..n) => context {
    // 括号单列，不从编号串里切——按章那一档拼不出整串交给 numbering()：章号
    // 可能是字母（附录），而 numbering() 只吃整数，见 src/heading/numbering.typ。
    // 引用那一处同源，见 src/references/refs.typ 的 number
    let (open, close) = if setting-of("equation-numbering-fullwidth") == true {
      ("（", "）")
    } else { ("(", ")") }
    if by-chapter {
      // *附录里公式的「附」进括号*：图表把它加在名前（附图1-1），公式在版面上
      // 只有一个号、没有名，「附」只能挤进括号里——「（附1-1）」。见
      // src/heading/numbering.typ
      _numbering.chapter-numbered(
        here(), n.pos(), open: open, close: close,
        prefix: _numbering.appendix-prefix(here(), doc-lang.get()),
      )
    } else {
      numbering(open + "1" + close, ..n.pos())
    }
  }
  set math.equation(supplement: supplement, numbering: eq-numbering)
  // 按章编号是两半：编号串 + 逐章重置。重置认哨兵，用户换掉编号时两半一起让开
  show heading.where(level: 1): it => context {
    if by-chapter and math.equation.numbering == eq-numbering {
      counter(math.equation).update(0)
    }
    it
  }
  // *换掉编号不放行，当场报错指到我们的开关上。* 指南 2.11 写死「公式序号
  // 按章编排」，改成别的排出来就不合格；而它由两半合成，用户只盖得住前一半。
  // none 要放过，那是打了 <-> 的公式（见 src/heading/numbering.typ 的 nonumber-rules）。
  show math.equation.where(block: true): it => context {
    if math.equation.numbering != none and math.equation.numbering != eq-numbering {
      panic(
        "equation numbering has no effect (write "
          + "iota-hit(equation-numbering-fullwidth: true) for full-width "
          + "brackets, or iota-hit(equation-numbering-by-chapter: false) "
          + "for continuous numbering)",
      )
    }
    it
  }
  doc
}

