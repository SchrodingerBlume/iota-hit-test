#import "../settings/resolve.typ": setting-of
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang
// U+2206 是有限增量符号，不是希腊字母 Δ（U+0394）。
#let increment = math.upright("\u{2206}")

#let equation-rules(by-chapter: true, supplement: [式], doc) = {
  let eq-numbering = (..n) => context {
    let (open, close) = if setting-of("equation-numbering-fullwidth") == true {
      ("（", "）")
    } else { ("(", ")") }
    if by-chapter {
      _numbering.chapter-numbered(
        here(), n.pos(), open: open, close: close,
        prefix: _numbering.appendix-prefix(here(), doc-lang.get()),
      )
    } else {
      numbering(open + "1" + close, ..n.pos())
    }
  }
  set math.equation(supplement: supplement, numbering: eq-numbering)
  show heading.where(level: 1): it => context {
    if by-chapter and math.equation.numbering == eq-numbering {
      counter(math.equation).update(0)
    }
    it
  }
  show math.equation.where(block: true): it => context {
    if math.equation.numbering != none and math.equation.numbering != eq-numbering {
      panic(
        "equation numbering has no effect (write "
          + "iota-hit(equation-numbering-fullwidth: true) for full-width "
          + "brackets, or iota-hit(equation-numbering-by-chapter: false) "
          + "for continuous numbering)",
      )
    }
    it
  }
  doc
}
