// 数学：字体、国标字形、积分号样式集。
//
// 对照 hithesis 的 src/utils/hit-math.dtx。那边 fontset-math 的 auto 走
// termes（TeX Gyre Termes Math），理由是「学校要的正文西文是 Times，Termes 是
// Times 的克隆，数学与正文同一血统；XITS 源自 STIX，空心体那批字形是几何化的
// 圆头，跟 Times 摆在一起不像一家」。代价是覆盖面窄——Termes 1112 个码位、
// XITS 2423 个、STIX Two 3607 个，缺口在冷门运算符与箭头。要覆盖面就把 math
// 这个角色改成 "STIX Two Math"。
//
// *字体要用 show math.equation 发。* set text(font:) 改不动数学字体——
// 实测 set text(font: "XITS Math") 之后公式仍然是 New Computer Modern Math。

// 积分号的样式集。GB 要直立形，而各家字体把它放在不同的样式集里。
//
// *眼下不发。* Typst 这一块还有问题——实测 New Computer Modern Math 开
// ss02 与不开*一模一样*（∫ 的墨迹宽高比都是 0.599），而表里记的正是 ss02；
// 说明要么那一版字体变了，要么 Typst 没把 features 传下去。在弄清楚之前不发这
// 一条，宁可用字体自己的默认形，也不要发一个*看着发了其实没发*的设置。
//
// *表留着*，标定结果不能丢——重新开启时改一处即可，见下面 math-rules 里
// 那一行注释掉的 features。
//
// 逐字体实测的办法：把 ∫ 在 ss01–ss20 下各排一遍，比 PDF 里的字形号；再量墨迹的
// 宽高比看直立了没有（越窄越立）。要用 show math.equation 发字体，
// set text(font:) 改不动数学字体。
//
// 量到的：
//
//   STIX Two Math   ss08 有效——宽高比 0.718 → 0.551，窄了两成三
//   XITS Math       ss08（早先标的，同源于 STIX）
//   New CM Math     ss02 *本机无效*，开与不开都是 0.599
//   TeX Gyre Termes 二十档一个都不换字形，它没得开
//   Cambria Math    二十档一个都不换字形，*但默认就是全场最直立的*
//                   （0.541，比 STIX 开了 ss08 还窄），本来也不需要
#import "../settings/resolve.typ": setting-of
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang
#import "../paragraph/linebox.typ" as linebox
#import "../layout/resolve.typ" as _layout

#let integral-features = (
  "XITS Math": ("ss08",),
  "STIX Two Math": ("ss08",),
  "New Computer Modern Math": ("ss02",),
  // Cambria Math 与 TeX Gyre Termes Math 不列——它们没有换字形的样式集
)

// 国标字形。依据是 GB/T 3102.11—1993《物理科学和技术中使用的数学符号》，
// neuthesis（LaTeX 版）的用户文档把它逐条列了出来，落到字形上的有四条：
//
//   第 3 条   希腊字母：大写默认*正体*，斜体加 it 前缀；小写默认斜体
//   第 4 条   微分、偏微分用正体；有限增量固定用正体的 U+2206，别拿 U+0394 顶
//   第 9 条   实部、虚部用罗马体
//   第 11 条  小于等于号用 ⩽，「勿用 ≤」；大于等于同理
//
// 逐条比 Typst 的默认（码位都是实测的）：
//
//   偏导符号  𝜕 U+1D715 →  ∂ U+2202     要动
//   实部虚部  ℜ U+211C  →  Re           要动（见下）
//   小于等于  ≤ U+2264  →  ⩽ U+2A7D     要动（见下）
//   有限增量  Typst 没有这个符号          要给（见下面的 increment）
//   大写希腊  Γ U+0393                   *不用动*，Typst 默认就是正体
//   小写希腊  𝛾 U+1D6FE                  不用动，本来就是斜体
//   dif 的 d  d U+0064                   不用动，本来就是直立
//
// *大写希腊先前被我们转成了斜体，那是错的，已撤。* 当时写的理由是「hithesis
// 的 math-style 有三档默认 GB」——hithesis 里*根本没有* math-style 这个选项
// （全文零命中）；math-style 是 unicode-math 的键，只有 ISO / TeX / french /
// upright 四档，*没有 GB 档*。四份证据一致指向正体：
//
//   Word 范例    「ΔP」六处，Δ 的 rPr 里只有 <w:iCs/>、*没有 <w:i/>* → 正体；
//                同一处的 P 有 <w:i/> → 斜体
//   Typst 默认   $Delta P$ 出 Δ U+0394 正体 ＋ 𝑃 U+1D443 斜体，正是范例那个排法
//   neuthesis    只翻了 partial，math-style 留在 unicode-math 的默认 TeX 档
//                ＝ 大写希腊正体；且特意定义 \varGamma→\itGamma 来提供斜体版
//   hithesis     用 newtxmath，newtx 默认同样是大写希腊正体
//
// 要斜的照写 italic(Gamma)，矢量矩阵的黑斜体写 bold(italic(Sigma))——都是原生的，
// 撤掉之后一样都不缺（实测 Gamma→Γ、italic(Gamma)→𝛤 U+1D6E4、bold(Gamma)→𝚪
// U+1D6AA、bold(italic(Gamma))→𝜞 U+1D71E）。
//
// 数学常数 e、π、i 的正体国标也要求，但 unicode-math 的 ISO 档同样不含这一条，
// 作者留给用户写 \symup{e}。这边同理，写 upright(e)、upright(pi)、upright(i)。
// 集合的粗正体写 bold(upright(R))，Nabla 的粗正体写 bold(nabla)（实测出
// 𝛁 U+1D6C1），矢量矩阵张量的粗斜体写 bold(x)——这几条 Typst 天然就合规。
//
// *小于等于换成斜等号。* 中文的 ⩽ 是斜等号，西文数学字体默认画的 ≤ 是横杠
// ——把两个字放大渲成点阵比过，SimSun / Noto Serif CJK 的第三笔是斜的，Termes /
// NCM / STIX Two / Cambria / XITS 是平的。
//
// *但用不着抢中文字体*（∥ 那一处的做法在这里是多余的）：四副数学字体*都*
// 带 U+2A7D ⩽ 与 U+2A7E ⩾，渲出来与 SimSun 的形状几乎重合，而 Typst 原生就有名字
// lt.eq.slant / gt.eq.slant。所以只换码位，不换字体，同一行里的 = < 仍与它同源。
//
// *这一条挡住原生*：换过之后横杠式的 ≤ 就写不出来了。规范把话说死了（「勿用
// ≤」），而它不像 frak(R) 那样能留逃生口——那一处认的是符号本身，frak 的文字内容
// 是 "R" 所以躲得开，这里没有这层间隔。
//
// *实部虚部转正体。* Typst 的默认是 TeX 传统的花体——实测 $Re$ 出 ℜ U+211C、
// $Im$ 出 ℑ U+2111。neuthesis 改的也是这一处：
// \renewcommand{\Re}{\operatorname{Re}}。
//
// *用 op 不用 upright*，为的是运算符间距。upright("Re") 只是一串直立字母，
// 是个普通原子，跟右边贴着排；op 让它按运算符算——实测 $Re z$ 在 e 与 z 之间
// 插了 1.833pt ＝ 11pt ÷ 6 的细空，$Re(a+b i)$ 在左括号前*不*插空，两处
// 都与 \operatorname 一致。
//
// *花体还写得出。* 这两条认的是符号本身，frak(R) 的文字内容是 "R"，花体是
// 数学变体在排版时套上去的，所以碰不到——实测 frak(R) 仍出 U+211C。真要花体的
// 场合（如黎曼 ℜ 的历史记法）照写 frak(R)、frak(I)。
#let _gb-shapes(doc) = {
  show sym.partial: math.upright
  show sym.Re: math.op("Re")
  show sym.Im: math.op("Im")
  show sym.lt.eq: sym.lt.eq.slant
  show sym.gt.eq: sym.gt.eq.slant
  doc
}

// 有限增量符号。GB/T 3102.11 要正体，且*码位是 U+2206 INCREMENT，不是
// U+0394 希腊大写 Delta*——neuthesis 的用户文档专门写了这一条：「须使用
// \increment 命令获得，建议不要使用 \upDelta（U+0394）」。Typst 没有这个符号
// （$increment$ 报 unknown variable），所以由我们给。
//
// *看不出差别，差在语义。* 两个码位在字体里是同一副轮廓——实测 Termes 的
// uni2206 与 Delta 逐点相同，Cambria 干脆让 U+2206 指向名叫 Delta 的那个字形。
// 值在于选中、检索、复制粘贴时它是增量算符而不是一个希腊字母，也在于万一哪天
// 有人把大写希腊设成斜体，这一个不会跟着斜。
//
// *是普通原子，不是运算符*：ΔX 里 Δ 与 X 贴着排，所以不套 math.op；
// 套 upright 是防着外面有人把数学字体整体设成斜体。
#let increment = math.upright("\u{2206}")

// 公式*自动编号*，不想编号的打 <->（见 src/heading/numbering.typ 的 nonumber-rules）。
//
// 指南 2.11：「论文中的公式应另起行，并居中书写……公式应标注序号，并将序号置于
// 括号内。公式序号按章编排，如第 1 章第 1 个公式的序号为『（1-1）』。公式的序号
// *右端对齐*。」居中与右端对齐是 Typst 的默认排法，不用另设。
//
// *半角括号跟范例*：指南正文写的是全角「（1-1）」，本科范例第 13 页印出来
// 是半角「(4-1)」，右缘顶着版心右边线 510.23。与分图号那一处同一个取舍——印出来
// 的比叙述里的实。
//
// *按章重置与图表同一条理由*：连续编号那一档不重置，否则第 2 章的公式变回
// 「(1)」跟第 1 章撞号，所以这两件事必须由同一个开关管。
//
// 引用出「式(1-1)」：supplement 取词条 caption.equation，指南 2.11 的原话是
// 「见式（1-1）」。
// 行盒按 Word 的模型给：*行盒高 ＝ 倍数 × 这一行的自然行高*，多出来的那一份
// 落在*基线下方*（上升部不变，见 src/paragraph/linebox.typ 的 _ascent-of）。
//
// *为什么公式要单发一份。* 我们的行盒把两条边写死成中易的度量，那是给文字行
// 用的；Word 那一行的自然行高取*这一行实际内容*的高度，公式有多高就按多高算，
// 再乘倍数。范例两处公式段的 pPr 都只写了 line=300 lineRule=auto（1.25 倍，与正文
// 同一档）、*没有段前段后*——指南那句「与周围文字留有足够的位置区分开」的
// 「位置」就是这么放出来的，不是靠段间距。
//
// 实测不发这一条时：分式的墨迹底离下一行墨迹顶只剩 2.3pt，而上方有 6.1——
// 上下不对称，下方偏紧。
//
// *只补下方。* 上方 Typst 已经给对了：公式块的上沿紧贴前一行的行盒底，
// 而它的上升部随内容长高（实测分式 上→式 26.93 ＝ 正文行深 7.275 + 公式上升部
// 19.65），正是 Word 的算法。
// 正文那一份行盒在每个公式自己的 context 里按当前这一节的版面现算——段级改了
// 行跨度（贴格那一档），公式的行盒跟着换。style 给 none 什么都不发。
#let _linebox-rules(style, doc) = {
  show math.equation.where(block: true): it => context {
    if style == none { return it }
    let metrics = linebox.metrics(style, layout: _layout.current-layout())
    // 自然行高：按*字体自己的*两条边量——把我们钉死的那一份让开，
    // 内容多高就多高。文字行量出来就是 coef × 字号，与正文那一档同源。
    let nat = measure(text(top-edge: "ascender", bottom-edge: "descender", it)).height
    let want = if metrics.snap {
      // 贴格那一档（研究生）：Word 把行贴到网格上，装不下就占整数个格
      let g = metrics.docgrid.line-pitch
      calc.ceil(nat / g) * g
    } else {
      // *倍数是算出来的，不另存一份*：正文的行盒除以它的自然行高就是它
      metrics.box / metrics.natural * nat
    }
    let extra = want - measure(it).height
    if extra <= 0pt { it } else { block(below: extra, it) }
  }
  doc
}

#let equation-rules(by-chapter: true, supplement: [式], body-style: none, doc) = {
  // *不能写成 if body-style != none { show: … }*——show 规则只在它自己所在
  // 的块里生效，套在 if 里等于没发（实测公式的行盒纹丝不动）。判空放进规则里。
  show: _linebox-rules.with(body-style)
  // *括号取半角，跟范例。* 指南 2.11 的叙述写的是全角——「序号为『（1-1）』」
  // （U+FF08/FF09），而范例*印出来*是半角 U+0028/0029。与分图号那一处是同一
  // 处矛盾的两个面（指南写「（a）」、范例印「(a) 」），两边照同一条取舍走。
  //
  // *是 set，不是 show math.equation: set。* 与 src/figure/caption.typ 的
  // 图表编号同一个理由：摆在 show 规则里，用户写 #set math.equation(numbering: …)
  // 盖不过我们，而且我们*读不到*他写了什么。挪到文档级，这一份就成了哨兵
  // ——闭包比得了身份，用户一改就分得出来。
  // *一个闭包管两档。* 括号宽窄要在排的时候查（setting-of 要上下文，而这句
  // set 在文档级、那会儿还没有）；按不按章是排版前就定死的参数，直接闭进来。
  //
  // 一条编号串管按章与连续：按章喂两个数、连续喂一个，Typst 的 numbering 自动截断
  // （实测 numbering("(1-1)", 5) 给出 "(5)"），不必另写一份。
  //
  // *连字符不跟着括号变全角*——指南那句原话里全角括号中间夹的就是半角
  // 连字符 U+002D，逐字量过。
  let eq-numbering = (..n) => context {
    // 括号单列，不从编号串里切——按章那一档拼不出整串交给 numbering()：章号
    // 可能是字母（附录），而 numbering() 只吃整数，见 src/heading/numbering.typ。
    // 引用那一处同源，见 src/references/refs.typ 的 number
    let (open, close) = if setting-of("equation-numbering-fullwidth") == true {
      ("（", "）")
    } else { ("(", ")") }
    if by-chapter {
      // *附录里公式的「附」进括号*：图表把它加在名前（附图1-1），公式在版面上
      // 只有一个号、没有名，「附」只能挤进括号里——「（附1-1）」。见
      // src/heading/numbering.typ
      _numbering.chapter-numbered(
        here(), n.pos(), open: open, close: close,
        prefix: _numbering.appendix-prefix(here(), doc-lang.get()),
      )
    } else {
      numbering(open + "1" + close, ..n.pos())
    }
  }
  set math.equation(supplement: supplement, numbering: eq-numbering)
  // 按章编号是两半：编号串 + 逐章重置。重置认哨兵，用户换掉编号时两半一起让开
  show heading.where(level: 1): it => context {
    if by-chapter and math.equation.numbering == eq-numbering {
      counter(math.equation).update(0)
    }
    it
  }
  // *换掉编号不放行，当场报错指到我们的开关上。* 指南 2.11 写死「公式序号
  // 按章编排」，改成别的排出来就不合格；而它由两半合成，用户只盖得住前一半。
  // none 要放过，那是打了 <-> 的公式（见 src/heading/numbering.typ 的 nonumber-rules）。
  show math.equation.where(block: true): it => context {
    if math.equation.numbering != none and math.equation.numbering != eq-numbering {
      panic(
        "equation numbering has no effect (write "
          + "iota-hit(equation-numbering-fullwidth: true) for full-width "
          + "brackets, or iota-hit(equation-numbering-by-chapter: false) "
          + "for continuous numbering)",
      )
    }
    it
  }
  doc
}

#let math-rules(font: "TeX Gyre Termes Math", cjk: none, gb: true, doc) = {
  show math.equation: set text(
    // *平行号抢给中文那一份。* 国标要*斜*的平行号（中文的写法是两道
    // 斜杠），而数学字体一律画成两条竖线——逐字体量过，把 ∥ 放大到 60pt 渲成图、
    // 比上下缘的墨迹重心：
    //
    //   Termes / NCM / STIX Two / Cambria / XITS Math   斜率 0.000  全是竖的
    //   Libertinus Serif                                0.000
    //   SimSun / FangSong                               0.417  斜
    //   Noto Serif CJK SC                               0.269  斜
    //
    // 所以这一个码位单挑出来给中文那一份。做法与 src/fonts/resolve.typ 的 cjk-first
    // 同源：带 covers 的条目排在最前，只管它圈住的那几个字。
    // neuthesis（LaTeX 版）也是这么办的——\setmathfont{SimSun}[range={"2225}]。
    // *汉字跟在数学字体后面。* 先前这里只设数学字体一个家族，$x_"进口"$
    // 里的中文于是没人管，落到 Typst 的全局兜底上——实测排出来是
    // SIL-Hei-Med-Jian，一个黑体，而正文同样几个字是 SimSun。公式里插的中文
    // 该与正文同一副字。
    //
    // *不加「全宽符号抢回中易」那一格*，与 src/fonts/resolve.typ 的 latin-table
    // 取舍相反：那一格是把「×」「←」从西文字体抢回中易的，在*正文*里对；
    // 在公式里它们是数学符号，本来就该由数学字体出，抢回来反倒错了。
    //
    // cjk 收的是*家族名*，不是整张表——fonts.resolve() 的角色键给的是表
    // （数组），families 那一份才是名字，拿错了会套出嵌套数组。
    font: if cjk == none { font } else {
      ((name: cjk, covers: regex("∥")), font, cjk)
    },
    // *眼下不发*，理由见上面 integral-features。要开就把下面这一行放开
    // features: integral-features.at(font, default: ()),
  )
  show math.equation: it => if gb { _gb-shapes(it) } else { it }
  doc
}
