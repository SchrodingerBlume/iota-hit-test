#import "@local/banshi:0.1.0" as banshi
#import banshi.layout: resolve-chars, current-page-setup
#import banshi.fonts: fontset-state, fake-bold, wants-bold-for
#import banshi.paragraph: amount, families-of, asian-font-of
#import banshi.runs: has-cj, latin-slot-run
#import banshi.content: plain-text
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-of
#import "../settings/resolve.typ": resolve-theorem-body-indent

// hithesis 的十三个定理类环境（src/config/hit-thm.dtx）；证明不编号。
#let _names = (
  "assumption", "definition", "proposition", "lemma", "theorem", "axiom",
  "corollary", "exercise", "example", "remark", "problem", "conjecture", "fact",
)
#let _mark = "iota-hit-theorem"
#let _counter(name) = counter(_mark + ":" + name)
#let _is-theorem(el) = el.func() == metadata and type(el.value) == dictionary and _mark in el.value

// 定理是一条带标签的 metadata，样子由 show 给：标签落在单个元素上，@label 才查得到。
#let _env(name, note, body) = metadata(((_mark): name, note: note, body: body))
#let proof(note: none, body) = _env("proof", note, body)
#let theorem(note: none, body) = _env("theorem", note, body)
#let lemma(note: none, body) = _env("lemma", note, body)
#let definition(note: none, body) = _env("definition", note, body)
#let proposition(note: none, body) = _env("proposition", note, body)
#let corollary(note: none, body) = _env("corollary", note, body)
#let axiom(note: none, body) = _env("axiom", note, body)
#let assumption(note: none, body) = _env("assumption", note, body)
#let example(note: none, body) = _env("example", note, body)
#let remark(note: none, body) = _env("remark", note, body)
#let problem(note: none, body) = _env("problem", note, body)
#let conjecture(note: none, body) = _env("conjecture", note, body)
#let fact(note: none, body) = _env("fact", note, body)
#let exercise(note: none, body) = _env("exercise", note, body)

// 计数在 show 里才步进，元素自己的位置上还是上一号
#let _number(name, loc, by-chapter) = {
  let n = _counter(name).at(loc).first() + 1
  if by-chapter { _numbering.chapter-numbered(loc, (n,), sep: ".") } else { str(n) }
}
// 「附」跟图表一样挂在名前（附推论1.1），不进号码
#let _word(name, loc, by-chapter) = {
  let lang = doc-lang.get()
  _numbering.appendix-prefix(loc, lang, by-chapter: by-chapter) + term-of(lang, "theorem", name)
}
// 前一截末字不是中日文字才空一格（Theorem 1.1、定理1.1 勾股），同题注的「图1-1」「Fig. 1-1」；谚文靠空格断词，算西文那边
#let _join(a, b) = {
  if b == none { return a }
  let t = plain-text(a).trim()
  a + (if t == "" or has-cj(t.last()) { "" } else { " " }) + b
}
#let _title(name, loc, by-chapter) = {
  let word = _word(name, loc, by-chapter)
  if name == "proof" { word } else { _join(word, _number(name, loc, by-chapter)) }
}
// 头与首段同段（trivlist 首行顶格）；块级内容（行间公式、列表）塞进 par 会被丢掉，到它为止。
#let _space = [ ].func()
#let _blocks = (
  list, list.item, enum, enum.item, terms, terms.item, figure, table, block, grid, stack,
  heading, image, place, align, pad, columns, line, rect, outline, pagebreak, colbreak, v, parbreak,
)
#let _is-block(k) = k.func() in _blocks or (k.func() in (math.equation, raw, quote) and k.block)
#let _flat(kids) = kids.map(k => if k.has("children") { _flat(k.children) } else { (k,) }).flatten()
#let _split(body) = {
  let kids = if body.has("children") { _flat(body.children) } else { (body,) }
  while kids.len() > 0 and kids.first().func() == _space { kids = kids.slice(1) }
  let i = kids.position(_is-block)
  if i == none { (kids.join(), none) } else { (kids.slice(0, i).join(), kids.slice(i).join()) }
}

// 头是一个 run：只认样式里字体那几个键
#let head-keys = ("asian-font", "latin-font", "bold", "latin-bold")
#let _head-run(head, f, body) = {
  let bold = head.at("bold", default: false)
  let t = text(font: families-of(head, f), weight: if bold { "bold" } else { "regular" }, {
    show latin-slot-run: set text(weight: if bold or head.at("latin-bold", default: false) { "bold" } else { "regular" })
    body
  })
  if bold and wants-bold-for(asian-font-of(head)) { fake-bold(t) } else { t }
}

#let theorem-rules(by-chapter: true, style: (head: (:), body: (:)), doc) = {
  show heading.where(level: 1): it => {
    if by-chapter { for name in _names { _counter(name).update(0) } }
    it
  }
  show metadata: it => {
    if not _is-theorem(it) { return it }
    let name = it.value.at(_mark)
    let (first, rest) = _split(it.value.body)
    if name != "proof" { _counter(name).step() }
    context {
      let layout = current-page-setup()
      let f = fontset-state.get()
      let t = _join(_title(name, it.location(), by-chapter), it.value.note)
      let gap = resolve-chars(resolve-theorem-body-indent(), layout)
      block(
        width: 100%, breakable: true,
        above: amount(style.body.at("above", default: 0pt), layout.docgrid),
        below: amount(style.body.at("below", default: 0pt), layout.docgrid),
        {
          show: banshi.styles.rules.with(style.body, layout: layout, set-font: true)
          par(first-line-indent: 0pt, _head-run(style.head, f, t) + h(gap) + first)
          rest
        },
      )
    }
  }
  show ref: it => context {
    let found = query(it.target)
    if found.len() == 0 or not _is-theorem(found.first()) { return it }
    let e = found.first()
    let name = e.value.at(_mark)
    if name == "proof" { panic("proofs are not numbered and cannot be referenced") }
    let given = it.fields().at("supplement", default: auto)
    let word = if given == auto { _word(name, e.location(), by-chapter) } else { given }
    let num = _number(name, e.location(), by-chapter)
    link(e.location(), if word in (none, []) { num } else { _join(word, num) })
  }
  doc
}
