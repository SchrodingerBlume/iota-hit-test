// 文档级的原生 set 碰上我们给的口子：写了要么被包内部压住、要么只生效一半，所以当场报错，指明该走哪个口子。
// 局部块 #[#set …] 与 #text(…)[…] 是 Typst 做局部调整的正路，不查。

// 文档级的 #set 把后文整个包成它的子节点，所以总在所在那串内容的末尾；局部块后面还有兄弟节点
#let _chain(c) = {
  if type(c) != content { return () }
  if c.has("styles") { return (c,) + _chain(c.child) }
  if c.has("children") and c.children.len() > 0 { return _chain(c.children.last()) }
  ()
}

// 受检字段：两个不同的预设——用户写了什么值，总有一个预设和它不同，读出来不等于预设就是写了
#let watched = (
  (
    rule: "set figure.caption(position: ...)",
    presets: (top, bottom),
    apply: (v, body) => { set figure.caption(position: v); body },
    read: () => figure.caption.position,
    hint: "the template places each kind's caption itself (tables above, figures below), so it would have no effect",
  ),
  (
    rule: "set par(first-line-indent: ...)",
    presets: ((amount: 1pt, all: false), (amount: 2pt, all: false)),
    apply: (v, body) => { set par(first-line-indent: v); body },
    read: () => par.first-line-indent,
    hint: "it would reach only plain body paragraphs while theorems, notes and the like keep the body style; "
      + "write iota-hit(styles: (body: (first-line-indent: ...))) instead",
  ),
  (
    rule: "set text(size: ...)",
    presets: (11pt, 13pt),
    apply: (v, body) => { set text(size: v); body },
    read: () => text.size,
    hint: "it would reach only plain body text while headings, captions, theorems and footnotes keep their own sizes; "
      + "write iota-hit(styles: (body: (size: ...))) and the other styles instead",
  ),
  // 预设用 Typst 自带的两副字，免得报「字体不存在」；读回来的族名是小写
  (
    rule: "set text(font: ...)",
    presets: ("libertinus serif", "dejavu sans mono"),
    apply: (v, body) => { set text(font: v); body },
    read: () => text.font,
    hint: "headings, captions and theorems keep their own fonts; choose fonts with iota-hit(fontset: ...) or a style's "
      + "asian-font / latin-font, and mark runs with #songti[...], #heiti[...], #serif[...] and the like",
  ),
  (
    rule: "set text(tracking: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set text(tracking: v); body },
    read: () => text.tracking,
    hint: "the template derives tracking from the document grid; change the grid with iota-hit(layout: (char-pitch: ...)) "
      + "or a style's tracking instead",
  ),
  (
    rule: "set text(weight: ...)",
    presets: ("light", "medium"),
    apply: (v, body) => { set text(weight: v); body },
    read: () => text.weight,
    hint: "the Chinese fonts have no bold face (the template fakes bold), so only Latin text would change; "
      + "use *...* or a style's bold: true instead",
  ),
  (
    rule: "set text(lang: ...)",
    presets: ("de", "fr"),
    apply: (v, body) => { set text(lang: v); body },
    read: () => text.lang,
    hint: "the document language is iota-hit(lang: ...), or a set text(lang: ...) written before #show: iota-hit",
  ),
  (
    rule: "set par(hanging-indent: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set par(hanging-indent: v); body },
    read: () => par.hanging-indent,
    hint: "it would reach only plain body paragraphs; write iota-hit(styles: (body: (hanging-indent: ...))) instead",
  ),
  (
    rule: "set par(justify: ...)",
    presets: (true, false),
    apply: (v, body) => { set par(justify: v); body },
    read: () => par.justify,
    hint: "each style carries its own justify; write iota-hit(styles: (body: (justify: ...))) instead",
  ),
  (
    rule: "set par(spacing: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set par(spacing: v); body },
    read: () => par.spacing,
    hint: "the template spaces paragraphs by the styles' above / below (Word's space before / after); write those in iota-hit(styles: ...) instead",
  ),
  (
    rule: "set block(above: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set block(above: v); body },
    read: () => block.above,
    hint: "the template spaces paragraphs by the styles' above / below (Word's space before / after); write those in iota-hit(styles: ...) instead",
  ),
  (
    rule: "set block(below: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set block(below: v); body },
    read: () => block.below,
    hint: "the template spaces paragraphs by the styles' above / below (Word's space before / after); write those in iota-hit(styles: ...) instead",
  ),
  // 读回来带着竖直分量；两个预设横竖都不同，只写一个分量的也抓得到
  (
    rule: "set align(...)",
    presets: (left + top, right + bottom),
    apply: (v, body) => { set align(v); body },
    read: () => align.alignment,
    hint: "each style carries its own align, so headings, captions and the like would not follow; "
      + "write iota-hit(styles: (body: (align: ...))) instead",
  ),
  (
    rule: "set figure(gap: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set figure(gap: v); body },
    read: () => figure.gap,
    hint: "the gap comes from the figure styles; write iota-hit(styles: (figure: (image: (gap: ...), table: (gap: ...)))) instead",
  ),
  (
    rule: "set table(inset: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set table(inset: v); body },
    read: () => table.inset,
    hint: "the cell margins come from the table style; write iota-hit(styles: (figure: (table: (inset: ...)))) instead",
  ),
  // 读回来是 stroke 值，跟 1pt 比不上
  (
    rule: "set table(stroke: ...)",
    presets: (stroke(1pt), stroke(2pt)),
    apply: (v, body) => { set table(stroke: v); body },
    read: () => table.stroke,
    hint: "the rules come from the table style (three-line table); write iota-hit(styles: (figure: (table: (stroke: ...)))) instead",
  ),
  (
    rule: "set outline.entry(fill: ...)",
    presets: (none, [.]),
    apply: (v, body) => { set outline.entry(fill: v); body },
    read: () => outline.entry.fill,
    hint: "the table of contents lays its entries out itself; write #table-of-contents(fill: ...) instead",
  ),
  // 纸张写 paper 也落在宽高上
  (
    rule: "set page(width: ...) / set page(paper)",
    presets: (100pt, 200pt),
    apply: (v, body) => { set page(width: v); body },
    read: () => page.width,
    hint: "the paper comes from iota-hit(layout: (paper: ...)), and the grid, header and footer are computed from it",
  ),
  (
    rule: "set page(height: ...) / set page(paper)",
    presets: (100pt, 200pt),
    apply: (v, body) => { set page(height: v); body },
    read: () => page.height,
    hint: "the paper comes from iota-hit(layout: (paper: ...)), and the grid, header and footer are computed from it",
  ),
  (
    rule: "set page(margin: ...)",
    presets: (1pt, 2pt),
    apply: (v, body) => { set page(margin: v); body },
    read: () => page.margin,
    hint: "the margins come from iota-hit(layout: (margin: ...)), and the grid, header and footer are computed from them",
  ),
  (
    rule: "set page(numbering: ...)",
    presets: ("1", "i"),
    apply: (v, body) => { set page(numbering: v); body },
    read: () => page.numbering,
    hint: "each part sets its own page numbers (front matter, main matter); write iota-hit(page-numbering: ...) instead",
  ),
  (
    rule: "set page(header: ...)",
    presets: (none, [x]),
    apply: (v, body) => { set page(header: v); body },
    read: () => page.header,
    hint: "the header and footer come from the template; change their text with iota-hit(overrides: ...) or hide them with iota-hit(layout: (header: (shown: false)))",
  ),
  (
    rule: "set page(footer: ...)",
    presets: (none, [x]),
    apply: (v, body) => { set page(footer: v); body },
    read: () => page.footer,
    hint: "the header and footer come from the template; change their text with iota-hit(overrides: ...) or hide them with iota-hit(layout: (header: (shown: false)))",
  ),
)

// matter 函数交出去的只有一个 context，外层看不见它正文里的 set：由它把自己那条链（连同下层交上来的）留个记号
#let _marks(c) = {
  if type(c) != content { return () }
  if c.func() == metadata and type(c.value) == dictionary and "iota-native" in c.value { return c.value.at("iota-native") }
  let kids = if c.has("children") { c.children } else if c.has("child") { (c.child,) } else if c.has("body") { (c.body,) } else { () }
  kids.map(_marks).flatten()
}
#let native-mark(doc) = {
  let nodes = _chain(doc) + _marks(doc)
  if nodes.len() > 0 { metadata(("iota-native": nodes)) }
}

// 把用户那句的样式原样套在探针上（Typst 看不见 styled 里设了什么，但能拿它的样式再排一次）。
// 探针只放文首：预设里有 set page，放在文中会另起一页
#let native-checks(doc) = {
  let probes = for s in _chain(doc) + _marks(doc) {
    for w in watched {
      for p in w.presets {
        (w.apply)(p, (s.func())(context if (w.read)() != p {
          panic(
            "#" + w.rule + " at the top level of the document is not allowed: " + w.hint
              + " (a local #[#set ...] block is left alone)",
          )
        }, s.styles))
      }
    }
  }
  if probes != none { hide(probes) }
}

// show X: set Y 另一套查法：我们在用户代码外层先把受检字段设成哨兵值，排这个元素的规则读到的不是哨兵，就是用户在里层写了。
// 哨兵取用户不会写的值；字体得是 Typst 自带的，不存在的族名会报警告
// 对齐只写一个分量时与哨兵的另一个分量合起来读，水平取标题上不会写的 end；竖直只能是默认的 top——
// 页面流里的块按竖直对齐摆，写 horizon 会把标题推到页中（写 top 的抓不到，那本来就是默认）
#let sentinel = (size: 0.31415pt, font: "dejavu sans mono", align: end + top, gap: 0.31415pt)
#let heading-sentinels(doc) = {
  show heading: set text(size: sentinel.size, font: sentinel.font)
  show heading: set align(sentinel.align)
  show heading: set block(above: sentinel.gap, below: sentinel.gap)
  doc
}
// 在排标题的规则里调（context 中）
#let check-heading-show-set() = {
  let hit = (
    ("set text(size: ...)", text.size != sentinel.size),
    ("set text(font: ...)", text.font != sentinel.font),
    ("set align(...)", align.alignment != sentinel.align),
    ("set block(above: ...)", block.above != sentinel.gap),
    ("set block(below: ...)", block.below != sentinel.gap),
  ).filter(((_, changed)) => changed)
  if hit.len() > 0 {
    panic(
      "show heading: " + hit.first().first() + " has no effect: the template lays headings out from its styles; "
        + "write iota-hit(styles: (heading-1: (...), heading-2: (...), term-heading: (...))) instead",
    )
  }
}
#let outline-entry-sentinels(doc) = {
  show outline.entry: set text(size: sentinel.size, font: sentinel.font)
  doc
}
// 在排目录条目的规则里调（context 中）
#let check-outline-entry-show-set() = {
  let hit = (
    ("set text(size: ...)", text.size != sentinel.size),
    ("set text(font: ...)", text.font != sentinel.font),
  ).filter(((_, changed)) => changed)
  if hit.len() > 0 {
    panic(
      "show outline.entry: " + hit.first().first() + " has no effect: the table of contents lays its entries out "
        + "from its styles; write iota-hit(styles: (toc-1: (...), toc-2: (...))) instead",
    )
  }
}
