// counter 在 introspection 中能稳定收敛；切换 state 可能来回振荡。
#let _count(name, key) = counter("iota-once:" + name + (if key == none { "" } else { ":" + key }))
#let _repeatable = state("iota-once-repeatable", false)
#let allow-repeats() = _repeatable.update(true)
#let once(name, key: none, hint: "") = {
  let c = _count(name, key)
  c.step()
  context {
    if c.get().first() > 1 and not _repeatable.get() {
      panic(
        "#" + name + "() appears more than once"
          + (if key != none { " for lang " + repr(key) } else { "" })
          + "; each page is printed once" + hint,
      )
    }
  }
}
#let never-with(name, other, hint) = context {
  if _count(other, none).final().first() > 0 {
    panic("#" + name + "() cannot be used together with #" + other + "(): " + hint)
  }
}
