// 只印一次的页：#cover() 写两遍、#nomenclature() 与 #list-of-symbols() 同时出现，当场报错。
// 计数器而不是 state：独立的 step 元素让 introspection 稳定收敛（见记忆里 state 交替 none 那一坑）。

// key 区分按语言各出一页的情形（目录中英各一份不算重复）。
#let _count(name, key) = counter("iota-once:" + name + (if key == none { "" } else { ":" + key }))

// 测试夹具要在一篇文档里排多份变体，关掉重复检查；模板不导出这个 state。
#let _repeatable = state("iota-once-repeatable", false)
#let allow-repeats() = _repeatable.update(true)

// 声明某页只能出现一次：第二次调用时报错。
#let once(name, key: none, hint: "") = {
  let c = _count(name, key)
  c.step()
  context {
    if c.get().first() > 1 and not _repeatable.get() {
      panic(
        "#" + name + "() appears more than once"
          + (if key != none { " for lang " + repr(key) } else { "" })
          + "; each page is printed once" + hint,
      )
    }
  }
}

// 声明两页互斥。final 看整篇文档，所以两页谁先写不影响结果。
#let never-with(name, other, hint) = context {
  if _count(other, none).final().first() > 0 {
    panic("#" + name + "() cannot be used together with #" + other + "(): " + hint)
  }
}
