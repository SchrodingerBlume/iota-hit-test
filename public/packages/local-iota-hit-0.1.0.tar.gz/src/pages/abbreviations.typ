// 缩略语表。
//
// *规范与范例都没有这一页*：博士范例的中英目录里都没有，研究生规范 2.4 的次序里也
// 没有；它是 hithesis 加的（list-of-abbreviations，手册 3.14.14）：字样「缩略语表」，
// 三列（缩写／英文全称／中文释义）、英文版两列，按缩写字母序，只列用过的，无列头、
// 无框线，放在物理量表之后、目录之前。它只对英文版自动插（\hit@structure@switch:nnn
// 那一条按 \g__hit_en_bool），中文版要写 list-of-abbreviations=true——我们不自动插，
// 写了 #list-of-abbreviations() 才有。
//
// *版式*是两列悬挂的术语列表——缩写一列、说明一列排到右边距，中英全称合成
// 一格「体细胞拷贝数变异（Somatic copy number alteration）」（thuthesis-example.pdf
// 第 VII 页「高效液相色谱（High Performance Liquid Chromatography）」同款）；
// hithesis 那张三列表（中文全称单占一列）右边必然空一截，不跟。整套版式与出处
// 见 src/blocks/term-list.typ，物理量名称及符号表共用。
//
// 条目在这儿声明并印表（#list-of-abbreviations(条目)，form: none 只声明不印）；正文里
// 怎么用、首次怎么组字、摘要后怎么重置，全在 src/blocks/abbreviations.typ。表的*内容*由 glossy 的 glossary() 给：谁用过、
// 按什么序，是它算的；每一条它按 theme 契约递给我们，我们只拿键（塞在它的 long
// 位上）去查自己的表，排成一张 grid。
#import "../flow/stage.typ": final-only-wanted
#import "@preview/glossy:0.9.2" as _glossy
#import "../blocks/abbreviations.typ" as _abbr
#import "../blocks/heading.typ": term-chapter
#import "../engine/terms.typ": term-table
#import "../engine/lang.typ": resolve-lang
#import "../flow/matter.typ": front-numbering-enter, cover-exit
#import "../engine/errors.typ" as _errors
#import "../engine/once.typ": once, never-with
#import "../blocks/term-list.typ": term-list, check-hanging-indent, check-header, resolve-header

// theme 递来的是 metadata 摞成的序列（一组一层、一条一个），拆成键的数组。
// 只有一条时 for 不造序列，递来的就是那一个 metadata 本身，所以三种都得认
#let _keys(body) = {
  // *一条都没有时 glossy 递来的是 none*——空表、声明了但正文里还没写 @缩写、
  // used-only: false 而一条都没声明，三种都会走到这儿。先前直接 body.func()，
  // 当场 type none has no method 'func'；而「先摆表、后写正文」是常见顺序
  if body == none { () }
  else if body.func() == [].func() {
    body.children.map(_keys).flatten()
  } else if body.func() == metadata {
    (body.value,)
  } else {
    ()
  }
}

// 说明格里的字：中文档「中文（English）」，只有一种就那一种；英文档只有英文全称
// （没有就中文）。括号跟首次展开同一个开关
#let _description(e, lang, fullwidth) = {
  if lang == "en" {
    return if e.long-en != none { e.long-en } else { e.long }
  }
  if e.long == none { return e.long-en }
  if e.long-en == none { return e.long }
  let (open, close) = if fullwidth { ("（", "）") } else { (" (", ")") }
  e.long + open + e.long-en + close
}

// 一张表：键按 glossy 给的次序，字从自己的表里取。版式见 src/blocks/term-list.typ
#let _rows(keys, lang, t, header, hanging-indent) = context {
  let all = _abbr.entries.final()
  let c = _abbr.config.final()
  let fullwidth = if c.fullwidth == auto { lang == "zh" } else { c.fullwidth }
  term-list(
    keys.map(key => (
      // 行上不挂标签：正文里的缩写链到表的开头（mark-printed 发的那一个），行标签会让
      // 排版不收敛，见 src/blocks/abbreviations.typ 的 table-label
      [#all.at(key).short],
      _description(all.at(key), lang, fullwidth),
    )),
    hanging-indent: hanging-indent,
    header: resolve-header(header, (strong(t.column-short), strong(t.column-long))),
  )
}

// glossy 的 theme 契约：section(title, body) / group(name, i, n, body) /
// entry(entry, i, n)。entry 只交出键，section 把它们收拢成一张表
#let _theme(rows) = (
  section: (title, body) => rows(_keys(body)),
  group: (name, index, total, body) => body,
  // long 位上放的是键，见 src/blocks/abbreviations.typ 的 rules
  entry: (e, index, total) => metadata(e.long),
)

// 表本身：glossy 的 glossary 加我们的 theme——章壳之外的那一半。合并页
// （nomenclature 的 abbreviations: 档）也调它，所以不带下划线；lang 收*已解好*
// 的值（合并页只解一次）
#let listing(
  lang: "zh", overrides: (:), header: auto, hanging-indent: auto,
  sort: auto, used-only: auto,
) = context {
  let t = term-table(lang, "list-of-abbreviations", overrides: overrides)
  set par(first-line-indent: 0pt)
  _glossy.glossary(
    title: [],
    theme: _theme(keys => _rows(keys, lang, t, header, hanging-indent)),
    sort: sort != false,
    ignore-case: true,
    show-all: used-only == false,
  )
}

// 选项名，报错时提示用

#let list-of-abbreviations(
  // 条目：一份字典（yaml("abbreviations.yaml") 读出来就是），或一个字典数组（几个 yaml
  // 与手写的混着给，按数组顺序合，同一个键出现两次当场报错）。*声明就在印表这一处*
  // ——先前挪到过 iota-hit(abbreviations:)，是把「摘要关键词那页不收敛」错归到声明位置上，
  // 二分之后发现与它无关（见 src/blocks/abbreviations.typ 的 table-label），于是改回来
  entries,
  // 这一份用哪一层词条、排几列。auto 跟随文档语言
  lang: auto,
  title: auto,
  overrides: (:),
  spread: auto,
  openright: auto,
  // 进不进目录。auto ＝ 进（hithesis 也进）
  outlined: auto,
  // 按缩写字母序、不分大小写。auto ＝ 排；false 照声明顺序（yaml 里的顺序）
  sort: auto,
  // 只列用过的。auto ＝ 是；false 全列
  used-only: auto,
  // 印不印列头，三态布尔：auto ＝ 跟模板（＝ 不印，hithesis 那张表没有列头）、
  // true 印、false 不印。字是词条 column-short／column-long，改字走 overrides
  // （list-of-abbreviations-column-short: […]）。名字照原生：table.header 是表头
  // （page(header:) 那个是页眉，两处各是各的）
  header: auto,
  // 说明从哪儿起，与 terms(hanging-indent:) 同名同义：首行接在缩写后面，续行悬挂到
  // 这里；首列宽就是它减 0.5cm。auto 按内容定，见 src/blocks/term-list.typ
  hanging-indent: auto,
  // auto ＝ 排这一页；none ＝ *只声明条目*——@SCNA 那套机制照常，章标题与表都不出，
  // 正文里的缩写也不链（表没排就没处链）。给「要机制不要表」的论文用。词与语义取自
  // 原生的 cite(form: none)：「不输出任何内容，但条目仍进参考文献表」
  form: auto,
  // 这一页只在终稿出现。三态见 src/flow/stage.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  if entries == none {
    panic("list-of-abbreviations: expected the entries as the first argument: a dictionary "
      + "(yaml(\"abbreviations.yaml\") reads as one), or an array of dictionaries")
  }
  if form not in (auto, none) {
    panic("list-of-abbreviations: form: expected auto or none, found " + repr(form))
  }
  for (name, value) in (sort: sort, used-only: used-only, outlined: outlined) {
    if value not in (auto, true, false) {
      panic("list-of-abbreviations: " + name + ": expected boolean or auto, found " + repr(value))
    }
  }
  check-hanging-indent("list-of-abbreviations", hanging-indent)
  check-header("list-of-abbreviations", header)
  // 声明是两个 state 更新，摘要在前也读得到（entries.final()）
  _abbr.declare(entries)
  if form == none { return }
  once("list-of-abbreviations")
  never-with(
    "list-of-abbreviations", "nomenclature",
    "nomenclature prints the symbols and the abbreviations together; write either "
      + "#nomenclature[...] or #list-of-symbols[...] + #list-of-abbreviations(), not both",
  )
  // 表排过了——正文里的缩写据此链到表，见 src/blocks/abbreviations.typ
  _abbr.mark-printed()
  // 封面序列的出口那一跳，第一个来的人补上，见 src/flow/matter.typ
  cover-exit()
  context {
    let l = resolve-lang(lang)
    // 头一个带页码的前置部件把页码归到 I；必须排在标题之前，见 src/flow/matter.typ
    front-numbering-enter(openright: openright)
    term-chapter(
      "list-of-abbreviations", lang: lang, title: title,
      overrides: overrides, spread: spread, openright: openright,
      outlined: outlined != false,
    )
    // 链接落点：章标题跳过页之后、表之前，见 src/blocks/abbreviations.typ 的 table-label
    _abbr.anchor()
    listing(
      lang: l, overrides: overrides, header: header,
      hanging-indent: hanging-indent, sort: sort, used-only: used-only,
    )
  }
}
