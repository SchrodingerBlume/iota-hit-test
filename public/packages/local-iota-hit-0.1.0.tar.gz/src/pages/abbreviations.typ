#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": final-only-wanted
#import "@preview/glossy:0.9.2" as _glossy
#import "../references/abbreviations.typ" as _abbr
#import "../heading/heading.typ": term-chapter
#import "../terms/lookup.typ": term-table
#import "../terms/lang.typ": resolve-lang
#import "../layout/matter.typ": front-numbering-enter, cover-exit
#import banshi.errors as _errors
#import "../once.typ": once, never-with
#import "./terms.typ": term-list, check-hanging-indent, check-header, resolve-header
#let _keys(body) = {
  if body == none { () }
  else if body.func() == [].func() {
    body.children.map(_keys).flatten()
  } else if body.func() == metadata {
    (body.value,)
  } else {
    ()
  }
}
#let _description(e, lang, fullwidth) = {
  if lang == "en" {
    return if e.long-en != none { e.long-en } else { e.long }
  }
  if e.long == none { return e.long-en }
  if e.long-en == none { return e.long }
  let (open, close) = if fullwidth { ("（", "）") } else { (" (", ")") }
  e.long + open + e.long-en + close
}
#let _rows(keys, lang, t, header, hanging-indent) = context {
  let all = _abbr.entries.final()
  let c = _abbr.config.final()
  let fullwidth = if c.fullwidth == auto { lang == "zh" } else { c.fullwidth }
  term-list(
    keys.map(key => (
      [#all.at(key).short],
      _description(all.at(key), lang, fullwidth),
    )),
    hanging-indent: hanging-indent,
    header: resolve-header(header, (strong(t.column-short), strong(t.column-long))),
  )
}
#let _theme(rows) = (
  section: (title, body) => rows(_keys(body)),
  group: (name, index, total, body) => body,
  entry: (e, index, total) => metadata(e.long),
)
#let listing(
  lang: "zh", overrides: (:), header: auto, hanging-indent: auto,
  sort: auto, used-only: auto,
) = context {
  let t = term-table(lang, "list-of-abbreviations", overrides: overrides)
  set par(first-line-indent: 0pt)
  _glossy.glossary(
    title: [],
    theme: _theme(keys => _rows(keys, lang, t, header, hanging-indent)),
    sort: sort != false,
    ignore-case: true,
    show-all: used-only == false,
  )
}

#let list-of-abbreviations(
  entries,
  lang: auto,
  title: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  sort: auto,
  used-only: auto,
  header: auto,
  hanging-indent: auto,
  form: auto,
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  if entries == none {
    panic("list-of-abbreviations: expected the entries as the first argument: a dictionary "
      + "(yaml(\"abbreviations.yaml\") reads as one), or an array of dictionaries")
  }
  if form not in (auto, none) {
    panic("list-of-abbreviations: form: expected auto or none, found " + repr(form))
  }
  for (name, value) in (sort: sort, used-only: used-only, outlined: outlined) {
    if value not in (auto, true, false) {
      panic("list-of-abbreviations: " + name + ": expected boolean or auto, found " + repr(value))
    }
  }
  check-hanging-indent("list-of-abbreviations", hanging-indent)
  check-header("list-of-abbreviations", header)
  _abbr.declare(entries)
  if form == none { return }
  once("list-of-abbreviations")
  never-with(
    "list-of-abbreviations", "nomenclature",
    "nomenclature prints the symbols and the abbreviations together; write either "
      + "#nomenclature[...] or #list-of-symbols[...] + #list-of-abbreviations(), not both",
  )
  _abbr.mark-printed()
  cover-exit()
  context {
    let l = resolve-lang(lang)
    front-numbering-enter(openright: openright)
    term-chapter(
      "list-of-abbreviations", lang: lang, title: title,
      overrides: overrides, two-hanzi: two-hanzi, openright: openright,
      outlined: outlined != false,
    )
    _abbr.anchor()
    listing(
      lang: l, overrides: overrides, header: header,
      hanging-indent: hanging-indent, sort: sort, used-only: used-only,
    )
  }
}
