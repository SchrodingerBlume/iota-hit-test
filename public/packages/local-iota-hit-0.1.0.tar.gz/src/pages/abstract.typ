// 中英文摘要页。
//
// 照 Word 范例排——本科取「1-8 页+规范章补全+中英摘要 本科毕业论文书写范例
// （理工类）.docx」的第四、五页。
//
// *这一档与封面、内封不同：它只发内容，不发页面。* 摘要是正文那一套版面
// 里的一页——有页眉「哈尔滨工业大学本科毕业论文」、有页脚罗马数字页码、
// 正文段落走的就是正文的行盒与首行缩进。页面、页眉页脚、页码归 iota-hit 管，
// 这里只管「章标题 + 若干正文段 + 一个空行 + 关键词行」这一段结构。
//
//   项    内容            行距      贴格   备注
//   64    摘  要          样式「1」  贴     段前 391 缇 = 19.55，段后 312 = 15.6
//   65–66 正文段          1.25 倍    不贴   首行缩进 2 字
//   67    空段            1.25 倍    不贴   *关键词前的那一个空行*
//   68    关键词：…       1.25 倍    不贴   不缩进，「关键词」走黑体
//
// *关键词前的空行用 enter(1, weak: true)。* 那一段的 ¶ 是继承来的
// Times 小四，1.25 倍算出来 17.25——与 hithesis 记的「36.8 = 19.4 + 17.25」
// 一致（19.4 是上一行正文的行距，17.25 是这个空段）。用 weak 是因为它是
// 「段与段之间的一口气」，落在页首时该丢掉，不该顶出一段空白。

#import "../blocks/enter.typ": enter
#import "../engine/part.typ"
#import "../engine/marks.typ": en
#import "../engine/fonts.typ"
#import "../engine/layout.typ": layout-for
#import "../blocks/heading.typ": term-chapter
#import "../flow/matter.typ": front-numbering-enter
#import "../engine/terms.typ": term-table
#import "../engine/errors.typ" as _errors
#import "../blocks/abbreviations.typ": reset as reset-abbreviations
#import "../engine/lang.typ": part-lang

// 关键词行。
//
// *冒号的字体两档不同，都要写死。* 实测 Word：中文那行的全角冒号走
// *黑体*（与「关键词」同一个 run），英文那行的走*宋体*（而标签
// 「Keywords」是 Times 粗体）。不写死的话：中文档的冒号会掉回宋体，
// 英文档的更糟——正文那一段整段走西文（正文规则把整段没有汉字的段落换成
// 西文字体表，见 src/engine/styles.typ 的 latin-par），全角冒号不在 Times 里，
// 一路回退到系统默认（本机上落到了楷体 Klee）。
//
// hithesis 用 \hit@put@keywords 把标签的宽度量出来当悬挂缩进，好让折行的词条
// 与第一个词对齐；我们用 par 的 hanging-indent 做同一件事。
// 每档语言的*版面*差别。字面在 src/config/terms.typ，这里只放「因为语言
// 不同才不同」的取值——每一项都实测自 Word 范例：
//
//   label-font  中文档标签与冒号同一个 run 走黑体；英文档标签是 Times 粗体，
//               不换字体角色，所以给 none
//   colon-font  英文档那个全角冒号*单独走宋体*——不写死的话它不在 Times 里，
//               一路回退到系统默认（本机上落到了楷体 Klee）
#let _profiles = (
  zh: (label-font: "heiti", colon-font: "heiti"),
  en: (label-font: none, colon-font: "songti"),
)

// 关键词那一行。
//
// *冒号的字体两档不同，都要写死。* 见 _profiles 上面的说明。
//
// hithesis 用 \hit@put@keywords 把标签的宽度量出来当悬挂缩进，好让折行的词条
// 与第一个词对齐；我们用 par 的 hanging-indent 做同一件事。
#let _keyword-line(label, items, separator, profile) = context {
  let families = fonts.current.get().families
  let em-dash = fonts.current.get().at("em-dash", default: "cjk")
  // 标签：中文档换黑体角色，英文档保持 Times 但加粗
  let head = if profile.label-font == none {
    text(weight: "bold", label)
  } else {
    text(font: part.font(profile.label-font, families, em-dash: em-dash), label)
  }
  let colon = text(font: part.font(profile.colon-font, families, em-dash: em-dash), "：")
  let width = measure(head + colon).width
  // *直接给 par，不能靠 set。* 这一行不缩进（范例第 68 段没有 w:ind），
  // 而正文那一档是首行缩进两字。写成 set par(first-line-indent: 0pt) 盖不住
  // ——context 不造段落边界，段落是在外层形成的，外层那条 set 照样生效
  // （实测仍缩 24.96，正好两字）。与内封密级那行同一个坑。
  par(
    first-line-indent: 0pt,
    hanging-indent: width,
    { head; colon; items.intersperse(separator).join() },
  )
}

// 摘要。中英文*同一个函数*，lang 定语言。
//
// *英文档的正文不用另立制度。* 正文那条 show par 把整段没有汉字的段落整段换成
// 西文的行盒、字体表与半份字距（src/engine/styles.typ 的 latin-par），英文摘要的每一段
// 都自动走那一支；先前这里手动接入的拉丁段落制度（latin-par 那个函数）已经撤了。
// 关键词那一行含一个全角冒号，有汉字，照汉字行盒算（上升部 12.18 而不是西文的
// 11.27），与 Word 一致，也是同一条判据自动分出来的。
#let abstract(
  content,
  // "zh" / "en"
  lang: "zh",
  // 这一页印的标题。auto 取词条（「摘  要」/ Abstract）。与别处的 title 同义：
  // 「这一块印出来的那个标题」
  title: auto,
  keywords: (),
  // 只改这一页的词条。文档级的改法见 iota-hit 的同名参数
  overrides: (:),
  // 只改这一页要不要从右手页起。auto 跟随所在的 matter，见 src/flow/matter.typ
  openright: auto,
  // 这一页的页面设置：局部字典并到文档＋段那一份上，整份就整份替换（见
  // src/engine/layout.typ 的 layout-for）
  layout: auto,
  // 关键词上面放什么。auto ＝ 一个弱空段（指南：「关键词在正文之后隔一行顶格书写」，
  // 范例也是隔一行；weak 是先前就有的：落到页首就收掉）；none 不空；长度按弱的
  // v() 发；内容原样放——v(1fr) 就把关键词挤到本页最下面。有人认为不该空行，所以
  // 开这个口，默认照规范。中英两页由外层包装一起传
  keywords-above: auto,
  // 只排一篇摘要（英文档只给英文那种）：英文目录里就叫 Abstract，不带 (In …) 尾巴。
  // 由外层包装按排几篇传进来，见 src/dispatch.typ
  single: false,
) = context {
  // std.content：这个函数的正文槽就叫 content，把类型名遮住了
  if keywords-above not in (auto, none) and type(keywords-above) not in (length, std.content) {
    panic("abstract: keywords-above: expected auto, none, length, or content, found " + str(type(keywords-above)))
  }
  let profile = _profiles.at(lang, default: none)
  if profile == none {
    panic(_errors.expected-one-of(_profiles.keys(), lang))
  }
  let layout = layout-for("abstract", layout)
  let t = term-table(lang, "abstract", overrides: overrides)
  // 摘要是*不编号*的章级标题，但要进目录（范例里就有「摘  要 I」）。
  // 与结论、致谢共用的那一层见 src/blocks/heading.typ
  // 头一个带页码的前置部件把页码归到 I；*必须排在标题之前*，
  // 否则目录里这一条印的是物理页号，见 src/flow/matter.typ
  front-numbering-enter(openright: openright)
  // 这一段的语言立给缩略语：英文摘要里的 @SCNA 按英文组字，见 src/engine/lang.typ 的
  // part-lang；「用过」也清一遍——每篇摘要都是独立读的，见 src/blocks/abbreviations.typ 的 reset
  part-lang.update(lang)
  reset-abbreviations()
  term-chapter(
    "abstract",
    lang: lang, title: title,
    overrides: overrides, openright: openright,
    toc-name: if single { term-table("en", "abstract", overrides: overrides).title } else { auto },
  )
  content
  // 关键词前的那一个空行。见文件头的说明与参数 keywords-above
  if keywords-above == auto {
    enter(1, weak: true, line-spacing: 1.25)
  } else if type(keywords-above) == length {
    v(keywords-above, weak: true)
  } else if keywords-above != none {
    keywords-above
  }
  _keyword-line(t.keywords, keywords, t.keywords-separator, profile)
  part-lang.update(auto)
}
