#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: paragraph-mark as enter
#import banshi.styles as style-rules
#import "../terms/lang.typ": en, part-lang
#import banshi.fonts as fonts
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": layout-for
#import "../heading/heading.typ": term-chapter
#import "../layout/matter.typ": front-numbering-enter
#import "../terms/lookup.typ": term-table
#import banshi.errors as _errors
#import "../references/abbreviations.typ": reset as reset-abbreviations
#let _profiles = (
  zh: (label-font: "heiti", colon-font: "heiti"),
  en: (label-font: none, colon-font: "songti"),
)
#let _keyword-line(label, items, separator, profile, hanging: false) = context {
  let families = fonts.fontset-state.get().families
  let em-dash = fonts.fontset-state.get().at("em-dash", default: "cjk")
  let head = if profile.label-font == none {
    text(weight: "bold", label)
  } else {
    text(font: fonts.font(profile.label-font, families, em-dash: em-dash), label)
  }
  let colon = text(font: fonts.font(profile.colon-font, families, em-dash: em-dash), "：")
  let width = if hanging { measure(head + colon + sym.zws).width } else { 0pt }
  par(
    first-line-indent: 0pt,
    hanging-indent: width,
    { head; colon; items.intersperse(separator).join() },
  )
}
#let abstract(
  content,
  lang: "zh",
  title: auto,
  keywords: (),
  overrides: (:),
  openright: auto,
  layout: auto,
  keywords-above: auto,
  keywords-hanging: auto,
  single: false,
) = context {
  let keywords-above = if type(keywords-above) == dictionary {
    for k in keywords-above.keys() {
      if k not in ("zh", "en") {
        panic("abstract: keywords-above: unknown key " + repr(k) + "; expected \"zh\" or \"en\"")
      }
    }
    keywords-above.at(lang, default: auto)
  } else { keywords-above }
  if keywords-above not in (auto, none) and type(keywords-above) not in (length, std.content) {
    panic("abstract: keywords-above: expected auto, none, length, content, or a (zh: …, en: …) dictionary of those, found " + str(type(keywords-above)))
  }
  if keywords-hanging not in (auto, true, false) {
    panic("abstract: keywords-hanging: expected auto or boolean, found " + repr(keywords-hanging))
  }
  let profile = _profiles.at(lang, default: none)
  if profile == none {
    panic(_errors.expected-one-of(_profiles.keys(), lang))
  }
  let layout = layout-for("abstract", layout)
  show: linebreaks-sets.with(layout)
  let t = term-table(lang, "abstract", overrides: overrides)
  front-numbering-enter(openright: openright)
  part-lang.update(lang)
  reset-abbreviations()
  term-chapter(
    "abstract",
    lang: lang, title: title,
    overrides: overrides, openright: openright,
    toc-name: if single { term-table("en", "abstract", overrides: overrides).title } else { auto },
  )
  content
  if keywords-above == auto {
    enter(1, weak: true, line-spacing: 1.25)
  } else if type(keywords-above) == length {
    v(keywords-above, weak: true)
  } else if keywords-above != none {
    keywords-above
  }
  _keyword-line(t.keywords, keywords, t.keywords-separator, profile, hanging: keywords-hanging == true)
  part-lang.update(auto)
}
