#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": final-only-wanted, info-get
#import "@local/omni-gb7714:0.1.0" as _omni
#import "../once.typ": once
#import "../heading/heading.typ": term-chapter
#import "../styles/group-heading.typ": group-heading
#import banshi.styles: paragraph
#import banshi.styles as sheet
#import "../styles/lookup.typ" as _lookup
#import "../terms/lookup.typ": term-table, term-for
#import "../terms/lang.typ": resolve-lang
#import banshi.errors as _errors
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": layout-for
#let _kinds = (
  papers: e => e.entry_type == "article",
  conferences: e => e.entry_type in ("inproceedings", "conference"),
  projects: e => e.entry_type in ("project", "award"),
  patents: e => e.entry_type in ("patent", "software"),
  books: e => e.entry_type in ("book", "inbook", "incollection"),
  standards: e => e.entry_type == "standard",
  reports: e => e.entry_type == "report",
  others: none,
)
#let _papers-wide = e => e.entry_type in ("article", "inproceedings", "conference")
#let _entries(source) = (
  source
    .matches(regex("(?m)^\\s*@(\\w+)\\s*[({]\\s*([^,\\s]+)\\s*,"))
    .map(m => (type: lower(m.captures.at(0)), key: m.captures.at(1)))
)
#let _refs(c) = {
  if type(c) != content { () }
  else if c.func() == ref { (str(c.target),) }
  else if c.has("children") { c.children.map(_refs).flatten() }
  else if c.has("body") { _refs(c.body) }
  else { () }
}
#let _project-drivers = (
  custom-fields: (funder: auto, award: auto),
  custom-drivers: (
    project: "author.title,funder<year => ,year>.<number => {课题编号：}number.>",
    award: "author.title.award<year => ,year>.",
  ),
)
#let _kind-options = (
  papers: (:),
  conferences: (:),
  projects: _project-drivers,
  patents: (show-patent-country: true),
  books: (:),
  standards: (:),
  reports: (:),
  others: (:),
)

#let achievements(
  source,
  papers: auto,
  conferences: auto,
  projects: auto,
  patents: auto,
  books: auto,
  standards: auto,
  reports: auto,
  others: auto,
  groups: auto,
  lang: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  title: auto,
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("achievements")
  if type(source) != str {
    panic("achievements: expected the contents of a .bib file (read(\"achievements.bib\")), found " + str(type(source)))
  }
  let l = resolve-lang(lang)
  let i = info-get()
  let degree-level = i.degree-level
  let category = i.category
  let t = term-table(l, "achievements", overrides: overrides)
  let pick(table, name) = term-for(table, name, (degree-level: degree-level, category: category))
  term-chapter(
    "achievements", lang: lang, overrides: overrides, two-hanzi: two-hanzi,
    openright: openright,
    title: if title != auto { title } else { pick(t, "title") },
    toc-name: pick(term-table("en", "achievements", overrides: overrides), "title"),
  )
  if groups != auto {
    for (name, value) in (papers: papers, conferences: conferences, projects: projects,
      patents: patents, books: books, standards: standards, reports: reports, others: others) {
      if value != auto {
        panic("achievements: " + name + " and groups cannot be given together")
      }
    }
    if type(groups) != array {
      panic("achievements: groups: expected array or auto, found " + str(type(groups)))
    }
  }
  let conf = if conferences != auto { conferences } else if category == "hass" { auto } else { none }
  let order = if category == "hass" {
    (("papers", papers), ("conferences", conf), ("patents", patents), ("books", books),
     ("projects", projects), ("standards", standards), ("reports", reports), ("others", others))
  } else {
    (("papers", papers), ("conferences", conf), ("patents", patents), ("projects", projects),
     ("books", books), ("standards", standards), ("reports", reports), ("others", others))
  }
  let declared = if groups != auto { groups } else {
    order.map(((kind, want)) => (name: kind, entries: want))
  }
  let declared = declared.map(g => {
    if type(g) != dictionary {
      panic("achievements: groups: expected dictionaries, found " + str(type(g)))
    }
    let name = g.at("name", default: none)
    if name != none and name not in _kinds {
      panic("achievements: groups: unknown name " + repr(name) + "; expected "
        + _errors.one-of(_kinds.keys().map(repr)) + " (custom groups give title:)")
    }
    let title = g.at("title", default: auto)
    let given-title = title != auto
    if title == auto {
      if name == none { panic("achievements: groups: a group needs name or title") }
      title = pick(t, name)
    }
    (
      name: name,
      given-title: given-title,
      title: title,
      entries: g.at("entries", default: auto),
      predicate: if name == none { none } else { _kinds.at(name) },
      catch-all: name != none and _kinds.at(name) == none,
      options: if name == none { (:) } else { _kind-options.at(name) },
    )
  })
  let declared = if declared.any(g => g.name == "conferences" and g.entries != none) {
    declared
  } else {
    declared.map(g => if g.name == "papers" { g + (predicate: _papers-wide) } else { g })
  }
  let entries = _entries(source)
  let named = declared.map(g => if type(g.entries) == content { _refs(g.entries) } else { () }).flatten()
  let preds = declared.map(g => {
    if g.entries == none { g.predicate }
    else if type(g.entries) == content { none }
    else if type(g.entries) == function { g.entries }
    else if g.predicate != none { g.predicate }
    else if g.catch-all { none }
    else {
      panic("achievements: groups: entries: auto needs a built-in name; a custom group gives a function or [@keys]")
    }
  })
  let earlier = ()
  let printed = ()
  for (i, g) in declared.enumerate() {
    if g.entries == none { continue }
    if type(g.entries) == content {
      printed.push((g, none))
      continue
    }
    let pred = if preds.at(i) != none { preds.at(i) } else {
      let others = preds.enumerate().filter(((j, q)) => j != i and q != none).map(((j, q)) => q)
      e => not others.any(q => q(e))
    }
    let mine = e => (
      pred(e)
        and e.entry_key not in named
        and not earlier.any(before => before(e))
    )
    let has = if type(g.entries) == function { true } else {
      entries.any(e => mine((entry_type: e.type, entry_key: e.key)))
    }
    if has {
      printed.push((g, mine))
      if preds.at(i) != none { earlier.push(pred) }
    }
  }

  let pattern = pick(t, "group-numbering")
  let lay = layout-for("achievements", auto)
  show: linebreaks-sets.with(lay)
  for (i, (g, mine)) in printed.enumerate() {
    let title = if g.name != "projects" or g.given-title { g.title } else {
      let named-keys = if mine == none { _refs(g.entries) } else { () }
      let has-award = entries.any(e => (
        e.type == "award"
          and (if mine == none { e.key in named-keys } else { mine((entry_type: e.type, entry_key: e.key)) })
      ))
      pick(t, if has-award { "projects-with-awards" } else { "projects" })
    }
    let head = numbering(pattern, i + 1) + title
    if category == "hass" {
      paragraph(head, _lookup.current-styles().section + (first-line-indent: (chars: 0)), layout: lay)
    } else {
      group-heading(head, lay)
    }
    _omni.bibliography(
      source,
      title: none,
      group: none,
      label: "achievements-" + str(i + 1),
      show-annotation: true,
      ..(if mine == none { (keys: g.entries) } else { (full: true, filter: mine) }),
      ..g.options,
    )
  }
}
