#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": final-only-wanted, info-get
#import "@local/omni-gb7714:0.1.0" as _omni
#import "../once.typ": once
#import "../heading/heading.typ": term-chapter, section-style
#import "../styles/group-heading.typ": group-heading
#import banshi.styles: paragraph
#import banshi.styles as sheet
#import "../styles/lookup.typ" as _lookup
#import "../terms/lookup.typ": term-table, term-for
#import "../terms/lang.typ": resolve-lang
#import banshi.errors as _errors
#import banshi.layout: linebreaks-sets
#import banshi.fonts: zihao
#import "../layout/parts.typ": layout-for
#let _papers-wide = e => e.entry_type in ("article", "inproceedings", "conference")
#let _kinds = (
  papers: e => e.entry_type == "article",
  // 「其它论文」只在博后期间默认列：论文全被「相关论文」先拿走，写键才有条目
  other-papers: _papers-wide,
  conferences: e => e.entry_type in ("inproceedings", "conference"),
  projects: e => e.entry_type in ("project", "award"),
  patents: e => e.entry_type in ("patent", "software"),
  books: e => e.entry_type in ("book", "inbook", "incollection"),
  standards: e => e.entry_type == "standard",
  reports: e => e.entry_type == "report",
  others: none,
)
// 博后两章的组名与条目都是 Normal 段：组名黑体加粗四号、固定 15.5 磅、不编号；条目自动编号「1」、悬挂 21 磅；组间空一个 Normal 段
#let _postdoc-normal = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: "single", snap-to-grid: true,
  first-line-indent: (chars: 0),
)
#let _postdoc-group = _postdoc-normal + (
  asian-font: "heiti", bold: true, size: zihao.sihao,
  line-spacing: (exactly: 15.5pt), snap-to-grid: false,
)
#let _postdoc-list = (bib-numbering-style: "plain", number-width: 21pt, number-gutter: 0pt)
#let _entries(source) = (
  source
    .matches(regex("(?m)^\\s*@(\\w+)\\s*[({]\\s*([^,\\s]+)\\s*,"))
    .map(m => (type: lower(m.captures.at(0)), key: m.captures.at(1)))
)
#let _refs(c) = {
  if type(c) != content { () }
  else if c.func() == ref { (str(c.target),) }
  else if c.has("children") { c.children.map(_refs).flatten() }
  else if c.has("body") { _refs(c.body) }
  else { () }
}
#let _project-drivers = (
  custom-fields: (funder: auto, award: auto),
  custom-drivers: (
    project: "author.title,funder<year => ,year>.<number => {课题编号：}number.>",
    award: "author.title.award<year => ,year>.",
  ),
)
#let _kind-options = (
  papers: (:),
  other-papers: (:),
  conferences: (:),
  projects: _project-drivers,
  patents: (show-patent-country: true),
  books: (:),
  standards: (:),
  reports: (:),
  others: (:),
)

#let achievements(
  source,
  papers: auto,
  conferences: auto,
  projects: auto,
  patents: auto,
  books: auto,
  standards: auto,
  reports: auto,
  others: auto,
  other-papers: auto,
  groups: auto,
  period: auto,
  lang: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  title: auto,
  shown: auto,
) = context {
  if not final-only-wanted(shown, page: if period == "doctoral" { "achievements-doctoral" }) { return }

  if type(source) != str {
    panic("achievements: expected the contents of a .bib file (read(\"achievements.bib\")), found " + str(type(source)))
  }
  let l = resolve-lang(lang)
  let i = info-get()
  let degree-level = i.degree-level
  let category = i.category
  let postdoc = degree-level == "postdoc"
  if period not in (auto, "doctoral", "postdoctoral") {
    panic("achievements: period: " + _errors.expected-one-of((auto, "doctoral", "postdoctoral"), period))
  }
  // 博后报告有两章成果：博士生期间（沿用博士的分组）与博士后期间（模板的六组）；别的学位只有自己那一章
  let doctoral = postdoc and period == "doctoral"
  let postdoctoral = postdoc and not doctoral
  once("achievements", key: if period == "doctoral" { "doctoral" })
  let given = (papers: papers, conferences: conferences, projects: projects, patents: patents,
    books: books, standards: standards, reports: reports, others: others, other-papers: other-papers)
  let t = term-table(l, "achievements", overrides: overrides)
  let variant = (degree-level: degree-level, category: category)
  let pick(table, name, variant: variant) = term-for(table, name, variant)
  // 博士生期间那一章的组名照博士学位论文
  let group-variant = if doctoral { (degree-level: "doctor", category: category) } else { variant }
  let title-key = if doctoral { "doctoral-title" } else { "title" }
  term-chapter(
    "achievements", lang: lang, overrides: overrides, two-hanzi: two-hanzi,
    openright: openright,
    title: if title != auto { title } else { pick(t, title-key) },
    toc-name: pick(term-table("en", "achievements", overrides: overrides), title-key),
  )
  if groups != auto {
    for (name, value) in given {
      if value != auto {
        panic("achievements: " + name + " and groups cannot be given together")
      }
    }
    if type(groups) != array {
      panic("achievements: groups: expected array or auto, found " + str(type(groups)))
    }
  }
  let conf = if conferences != auto { conferences } else if category == "hass" { auto } else { none }
  // 博后期间：模板六组在前；标准与兜底排在后面，有条目才印。会议论文并进「相关论文」
  let order = if postdoctoral {
    (("papers", papers), ("other-papers", other-papers), ("books", books), ("patents", patents),
     ("projects", projects), ("reports", reports), ("standards", standards), ("others", others))
  } else if category == "hass" {
    (("papers", papers), ("conferences", conf), ("patents", patents), ("books", books),
     ("projects", projects), ("standards", standards), ("reports", reports), ("others", others))
  } else {
    (("papers", papers), ("conferences", conf), ("patents", patents), ("projects", projects),
     ("books", books), ("standards", standards), ("reports", reports), ("others", others))
  }
  let declared = if groups != auto { groups } else {
    order.map(((kind, want)) => (name: kind, entries: want))
  }
  let declared = declared.map(g => {
    if type(g) != dictionary {
      panic("achievements: groups: expected dictionaries, found " + str(type(g)))
    }
    let name = g.at("name", default: none)
    if name != none and name not in _kinds {
      panic("achievements: groups: unknown name " + repr(name) + "; expected "
        + _errors.one-of(_kinds.keys().map(repr)) + " (custom groups give title:)")
    }
    let title = g.at("title", default: auto)
    let given-title = title != auto
    if title == auto {
      if name == none { panic("achievements: groups: a group needs name or title") }
      title = pick(t, name, variant: group-variant)
    }
    (
      name: name,
      given-title: given-title,
      title: title,
      entries: g.at("entries", default: auto),
      predicate: if name == none { none } else { _kinds.at(name) },
      catch-all: name != none and _kinds.at(name) == none,
      options: if name == none { (:) } else { _kind-options.at(name) },
    )
  })
  let declared = if declared.any(g => g.name == "conferences" and g.entries != none) {
    declared
  } else {
    declared.map(g => if g.name == "papers" { g + (predicate: _papers-wide) } else { g })
  }
  let entries = _entries(source)
  let named = declared.map(g => if type(g.entries) == content { _refs(g.entries) } else { () }).flatten()
  let preds = declared.map(g => {
    if g.entries == none { g.predicate }
    else if type(g.entries) == content { none }
    else if type(g.entries) == function { g.entries }
    else if g.predicate != none { g.predicate }
    else if g.catch-all { none }
    else {
      panic("achievements: groups: entries: auto needs a built-in name; a custom group gives a function or [@keys]")
    }
  })
  let earlier = ()
  let printed = ()
  for (i, g) in declared.enumerate() {
    if g.entries == none { continue }
    if type(g.entries) == content {
      printed.push((g, none))
      continue
    }
    let pred = if preds.at(i) != none { preds.at(i) } else {
      let others = preds.enumerate().filter(((j, q)) => j != i and q != none).map(((j, q)) => q)
      e => not others.any(q => q(e))
    }
    let mine = e => (
      pred(e)
        and e.entry_key not in named
        and not earlier.any(before => before(e))
    )
    let has = if type(g.entries) == function { true } else {
      entries.any(e => mine((entry_type: e.type, entry_key: e.key)))
    }
    if has {
      printed.push((g, mine))
      if preds.at(i) != none { earlier.push(pred) }
    }
  }
  // 那一页的字符网格 12.672 是硕博范例的；博后成果页与正文同一节
  let lay = layout-for(if postdoc { none } else { "achievements" }, auto)
  show: linebreaks-sets.with(lay)
  // 博后两章的段都关了中西文自动空隙（autoSpaceDE／DN）
  set text(cjk-latin-spacing: none) if postdoc
  let pattern = if not postdoc { pick(t, "group-numbering") }
  for (i, (g, mine)) in printed.enumerate() {
    let title = if g.name != "projects" or g.given-title { g.title } else {
      let named-keys = if mine == none { _refs(g.entries) } else { () }
      let has-award = entries.any(e => (
        e.type == "award"
          and (if mine == none { e.key in named-keys } else { mine((entry_type: e.type, entry_key: e.key)) })
      ))
      pick(t, if has-award { "projects-with-awards" } else { "projects" }, variant: group-variant)
    }
    if postdoc {
      if i > 0 { paragraph(sym.zws, _postdoc-normal, layout: lay) }
      paragraph(title, _postdoc-group, layout: lay)
    } else if category == "hass" {
      paragraph(numbering(pattern, i + 1) + title, { let s = _lookup.current-styles(); s.at(section-style(s)) } + (first-line-indent: (chars: 0)), layout: lay)
    } else {
      group-heading(numbering(pattern, i + 1) + title, lay)
    }
    {
      show: if postdoc { sheet.rules.with(_postdoc-normal, layout: lay, set-font: true) } else { it => it }
      _omni.bibliography(
        source,
        title: none,
        group: none,
        label: "achievements-" + (if doctoral { "doctoral-" } else { "" }) + str(i + 1),
        show-annotation: true,
        ..(if postdoc { _postdoc-list } else { (:) }),
        ..(if mine == none { (keys: g.entries) } else { (full: true, filter: mine) }),
        ..g.options,
      )
    }
  }
}
