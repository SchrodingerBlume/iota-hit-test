// 攻读学位期间取得创新性成果。
//
// 本科指南 1.6 / 研究生规范 1.6 说列什么：与论文相关的已发表、已录用论文；科研成果与
// 专利可单做一项分别列出；与论文无关的、第二作者以后的不列。研究生规范 2.17 说怎么
// 排：「*书写格式与参考文献相同*，页码后需注明该文章对应学位论文的章节
// 序号。如已发表的学术论文被 EI 或 SCI 收录，应标明收录号；SCI 论文一般应标注
// 发表当年的影响因子；对已录用但尚未发表的学术论文，请注明是否 EI 或 SCI 刊源。」
// 研究生规范 1.5 另说本人成果*不应列入参考资料*。
//
// *范例怎么排*（本科范例 p31、博士范例 p22，逐行量的）：标题与结论致谢
// 同一层（不编号、进目录、章前跳页）；三组「发表的学术论文」「申请及已获得的
// 专利」「参与的科研项目及获奖情况」，组名宋体小四、顶格、*加粗*，本科编「一、」、
// 博士编「（一）」；条目与参考文献同款——全角「［1］」、悬挂，*每组从［1］
// 重新数*，收录号一类写在条目尾。
//
// *条目是 omni 排的，我们只给数据与分组。* 「与参考文献相同」正由 omni
// 的 GB/T 7714 驱动兑现：一份专用 .bib（与 refs.bib 分开，1.5 天然满足），按
// 条目类型分三组——@patent 是专利，@project / @award 是项目与获奖，其余是论文；
// 每组一张表，group: none 让每组从［1］起，show-annotation 把 annote 字段
// （收录号、影响因子、对应章节）接在条目尾。
//
// *项目与获奖不是文献，GB/T 7714 没有它们的著录格式*，范例那两条也没有
// 标识码。所以自造两种条目类型，驱动登记在这一页里（omni 的 custom-drivers 与
// custom-fields 都能逐表传），用户的 .bib 只管写字段：
//
//     @project{key, author, title, funder（立项来源）, number（课题编号）, year}
//     @award{key, author, title, award（奖项）, year}
//
// 实测排出来「张三，李四. ××气体静压轴承技术研究. ××省自然科学基金项目，2020.
// 课题编号：××××.」「张三，李四. ××静载下预应力混凝土房屋结构设计统一理论.
// 黑龙江省科学技术二等奖，2007.」——后一条与博士范例逐字一致。没有的字段由
// 卫语句 <字段 => …> 收掉，不会印「[出版年不详]」。
//
// *模板里标点后面不写空格*：omni 的标点风格自己补空格，再写一个就叠成两个
// （实测「张三，李四.  ××」）。number 与 omni 内部字段撞名，课题编号只能用内置
// 的 number token，不能自造同名字段（实测 custom-fields 那条当场报错）。
//
// *学 eqdenote*：数据进、格式出。三个组参数各三态——auto 全列（按 .bib
// 原序，顺序编码制下 omni 不排序）、[@a@b] 只列这几条并按此序（omni 的 keys）、
// none 不列；某组 auto 却一条都没有也不排（范例：无专利时此项不必列出），
// 编号只数排出来的组。
#import "../info.typ": final-only-wanted, info-get
#import "@local/omni-gb7714:0.1.0" as _omni
#import "../errors.typ": once
#import "../heading/heading.typ": term-chapter
#import "../paragraph/group-heading.typ": group-heading
#import "../styles/parts.typ": paragraph
#import "../styles/sheet.typ" as sheet
#import "../terms/lookup.typ": term-table, term-for
#import "../terms/lang.typ": resolve-lang
#import "../errors.typ" as _errors
#import "../layout/resolve.typ": layout-for, linebreaks-sets

// 三组各收哪些条目类型。收 omni 递来的条目（有 entry_type），也收数类型时
// 拼的字典——两处同一条判据
// *组的次序照规范 1.6 的枚举*：学术论文、科研成果、专利、专著、产品、
// 行业标准、研究报告、竞赛获奖。我们的七组按它排下来是——论文、科研项目及获奖、
// 专利、专著、行业标准、研究报告、其他。
//
// *这一处没照范例。* 两份范例的三个组名逐字相同、次序是「论文 / 专利 /
// 项目及获奖」，把专利排在项目前面；按本包的证据次序（范例 → 规范原话）本该跟
// 范例。但范例只有三组，规范列的是八类——*要把七组排出一个次序，只有规范
// 那句给得出完整的答案*，拿三组的次序去推七组是外推。所以这一处取枚举。
//
// 次序是*默认*，不是规矩：`groups:` 收一个有序数组，写几组、按什么次序
// 全由作者定，见下面那个参数。
#let _kinds = (
  // *四组，照规范那句列的八类分。*《研究生学位论文写作指南》1.6（理工与
  // 人文社科一字不差）：「攻读学位期间所获得的不同形式的成果，如*学术论文、
  // 科研成果、专利、专著、产品、行业标准、研究报告、竞赛获奖*等可单独分项分别
  // 列出」。八类里前四类各有归处，后四类（专著、产品、行业标准、研究报告）
  // 规范*与论文并列*，不是论文的子类。
  //
  // *兜底的是第四组，不是论文组。* 先前论文组兜底，于是 @book 与 @standard
  // 被印在「发表的学术论文」标题底下——把一本专著算成论文，与规范原话直接冲突
  // （实测过）。改成论文组只收真论文，其余归 others。
  //
  // *兜底非有不可*：规范那句是「如……*等*」，单子是开口的，所以
  // 「不认识的类型就报错」走不通——规范明说还有别的形式可以列。
  //
  // *软著归专利那组*：软件著作权与专利同属知识产权，omni 给 @software 的
  // 类型标识是［CP］（计算机程序），与［P］同族；规范那八类里它最接近「产品」，
  // 但「产品」在规范里与专利并列而不是与论文并列，归专利组比归兜底更贴。
  papers: e => e.entry_type == "article",
  // 国际会议论文单成一组——人文范例（s-hss）的第二组「二、发表的国际会议论文」。
  // *理工范例不拆*：d-stem 论文组的第 ［6］ 条就是 ［C］，会议论文排在
  // 「（一）发表的学术论文」底下。所以这一组*只有人文默认列出*，理工不列；
  // 不列时论文组照收会议论文，见下面的 _papers-wide
  conferences: e => e.entry_type in ("inproceedings", "conference"),
  // 科研项目与竞赛获奖*合成一组，依据是范例*：那一组的字样「参与的科研项目
  // 及获奖情况」两份范例逐字相同，它自己就把两件事写在一个标题里。规范 1.6 把
  // 「科研成果」与「竞赛获奖」分开点名，但范例的字样比枚举更近一层证据。
  projects: e => e.entry_type in ("project", "award"),
  patents: e => e.entry_type in ("patent", "software"),
  // *规范点了名的各成一组*，见词条那边。*析出的章节也归这儿*：人文范例
  // 「三、参与的专著」那一条就是一章（「第十三章：……虚拟社会人类学导论[M]」），
  // .bib 里是 @incollection / @inbook；先前它们归论文组
  books: e => e.entry_type in ("book", "inbook", "incollection"),
  standards: e => e.entry_type == "standard",
  reports: e => e.entry_type == "report",
  // 兜底：判据由「其余各组的判据取反」现算，见 achievements 里的 mine
  others: none,
)

// 会议论文那一组不在场时，论文组的判据——把会议论文收回来。理工范例就是这个样子
#let _papers-wide = e => e.entry_type in ("article", "inproceedings", "conference")

// .bib 文本里各条目的键与类型，按原序。为两件事：判断「这一组有没有条目」——
// 有才排组名、才占编号（omni 遇到空表什么都不印，组名却是我们发的，得自己知道）；
// 以及「这一条被前面哪一组领走了」，见下面的先到先得
#let _entries(source) = (
  source
    .matches(regex("(?m)^\\s*@(\\w+)\\s*[({]\\s*([^,\\s]+)\\s*,"))
    .map(m => (type: lower(m.captures.at(0)), key: m.captures.at(1)))
)

// 一个内容块里点名的条目键，按书写顺序。[@a@b] 那一档用，与 omni 的 keys: 同款
// ——它自己也是递归地把块里的引用收出来
#let _refs(c) = {
  if type(c) != content { () }
  else if c.func() == ref { (str(c.target),) }
  else if c.has("children") { c.children.map(_refs).flatten() }
  else if c.has("body") { _refs(c.body) }
  else { () }
}


// 项目与获奖那两种自造类型的驱动，见文件头
#let _project-drivers = (
  custom-fields: (funder: auto, award: auto),
  // *项目用逗号、获奖用句号*——两份范例逐字一致地这么分：
  //
  //   项目  ×××. ××气体静压轴承技术研究*,* ××省自然科学基金项目.课题编号：××××.
  //   获奖  ×××. ××静载下预应力混凝土房屋结构设计统一理论*.* 黑江省科学技术二等奖, 2007.
  //
  // 读得通：项目那一条，基金是这个项目*的*来源，与题名同一句；获奖那一条，
  // 奖项是对成果的另一句陈述。*先前项目那处写的是句号*，与范例不符；
  // 一度把获奖也改成逗号，那是过头——范例两条本来就不一样。
  //
  // *DSL 里一律写半角*：omni 说「自定义条目格式里裸写的 , : ( ) ; ? ! . 同走
  // 本套风格（句号仍总是半角）」——全角半角与标点前后的空隙由它统一，我们不纠正。
  // 要某个标点原样不动才写反引号字面量。
  //
  // *例外是 {…} 里那个冒号*：花括号是 verbatim 定界，里面写什么印什么、
  // 不受纠正——所以「课题编号：」的冒号得自己写成全角（写半角就真印半角了）。
  custom-drivers: (
    project: "author.title,funder<year => ,year>.<number => {课题编号：}number.>",
    award: "author.title.award<year => ,year>.",
  ),
)

// 内置那三组各自要额外发给 omni 的选项
#let _kind-options = (
  papers: (:),
  conferences: (:),
  // 专利著录国别：范例「：中国，88105607.3［P］」
  projects: _project-drivers,
  patents: (show-patent-country: true),
  books: (:),
  standards: (:),
  reports: (:),
  others: (:),
)

#let achievements(
  // 专用 .bib 的内容：read("achievements.bib")。包读不到用户的文件，只能收
  // read() 的结果，与 omni 的 bibliography 同一个口
  source,
  // 内置那三组各列什么。auto 全列、[@a@b] 只列这几条并按此序、none 不列。
  // *与 groups 二选一*——两条路都能定分组，同时写就不知道听谁的
  papers: auto,
  // 国际会议论文。*auto ＝ 模板决定*：人文列（范例的第二组），理工不列（范例
  // 把会议论文放在论文组里）。不列时会议论文回论文组，不会掉进兜底组
  conferences: auto,
  projects: auto,
  patents: auto,
  // 规范点了名的另外三类，各自一组；others 是兜底，收「如……等」放开的别的形式。
  // *一组没有条目就不排*，所以多开几组不会多印空标题。见 _kinds
  books: auto,
  standards: auto,
  reports: auto,
  others: auto,
  // 整套分组，有序。auto ＝ 内置那三组（论文、专利、项目与获奖），由上面三个参数管。
  //
  // *分几组、叫什么名是作者的事*——研究生规范 1.6（理工与人文社科一字不差）：
  // 「攻读学位期间所获得的*不同形式的成果*，如学术论文、科研成果、专利、专著、
  // 产品、行业标准、研究报告、竞赛获奖等*可单独分项分别列出*」。写死三组比
  // 规范还严，所以开这个口。一组一个字典：
  //
  //     (name: "papers", entries: auto)                  内置组，名从词条来
  //     (title: [专著], entries: e => e.entry_type == "book")   自造判据
  //     (title: [软件著作权], entries: [@sw1@sw2])         点名
  //
  //   name     内置组的键（papers / patents / projects）。名从词条桶取，overrides
  //            改得动；那三组还各自带着自己的 omni 选项（专利的国别、项目的驱动）
  //   title    字面，压过 name 取来的名；自造的组只写它
  //   entries  auto 按内置判据筛（只有内置组有判据）、函数当判据、[@a@b] 点名并按
  //            此序、none 不列
  //
  // *专著、标准、软著不必我们做什么*：@book 出［M］、@standard 出［S］，
  // omni 还有 custom-marks 能给 @software 指定［CP］——.bib 里写真实类型，
  // 这里分项列出就是了。
  groups: auto,
  // 这一份用哪一层词条排。auto 跟随文档语言
  lang: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  // 标题字样的就地覆盖。auto 按学位取词条
  title: auto,
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("achievements")
  if type(source) != str {
    panic("achievements: expected the contents of a .bib file (read(\"achievements.bib\")), found " + str(type(source)))
  }
  let l = resolve-lang(lang)
  let i = info-get()
  let degree-level = i.degree-level
  let category = i.category
  let t = term-table(l, "achievements", overrides: overrides)
  let pick(table, name) = term-for(table, name, (degree-level: degree-level, category: category))
  // 章壳：中英字样都按学位挑好了传进去
  term-chapter(
    "achievements", lang: lang, overrides: overrides, two-hanzi: two-hanzi,
    openright: openright,
    title: if title != auto { title } else { pick(t, "title") },
    toc-name: pick(term-table("en", "achievements", overrides: overrides), "title"),
  )
  // 分组：写了 groups 就照它，没写就是内置那三组
  if groups != auto {
    for (name, value) in (papers: papers, conferences: conferences, projects: projects,
      patents: patents, books: books, standards: standards, reports: reports, others: others) {
      if value != auto {
        panic("achievements: " + name + " and groups cannot be given together")
      }
    }
    if type(groups) != array {
      panic("achievements: groups: expected array or auto, found " + str(type(groups)))
    }
  }
  // 会议论文那一组只有人文默认列，见 _kinds 的 conferences
  let conf = if conferences != auto { conferences } else if category == "hass" { auto } else { none }
  // *默认的组序按门类，各照各的范例*：理工 d-stem 是「论文 / 专利 / 项目及获奖」，
  // 人文 s-hss 是「学术论文 / 国际会议论文 / 专著 / 课题项目」。两份范例都只列了自己
  // 用得上的那几组，其余几组接在后面——次序取规范 1.6 的枚举（学术论文、科研成果、
  // 专利、专著、产品、行业标准、研究报告、竞赛获奖）。
  //
  // 次序是*默认*，不是规矩：groups: 收一个有序数组，写几组、按什么次序全由作者定
  let order = if category == "hass" {
    (("papers", papers), ("conferences", conf), ("patents", patents), ("books", books),
     ("projects", projects), ("standards", standards), ("reports", reports), ("others", others))
  } else {
    (("papers", papers), ("conferences", conf), ("patents", patents), ("projects", projects),
     ("books", books), ("standards", standards), ("reports", reports), ("others", others))
  }
  let declared = if groups != auto { groups } else {
    order.map(((kind, want)) => (name: kind, entries: want))
  }
  // 每一组解成 (title, entries, options)：名从 name 取词条、title 压过它
  let declared = declared.map(g => {
    if type(g) != dictionary {
      panic("achievements: groups: expected dictionaries, found " + str(type(g)))
    }
    let name = g.at("name", default: none)
    if name != none and name not in _kinds {
      panic("achievements: groups: unknown name " + repr(name) + "; expected "
        + _errors.one-of(_kinds.keys().map(repr)) + " (custom groups give title:)")
    }
    let title = g.at("title", default: auto)
    let given-title = title != auto
    if title == auto {
      if name == none { panic("achievements: groups: a group needs name or title") }
      // *按门类取*：人文的专著、项目另有说法，见 src/terms/built-in.typ
      title = pick(t, name)
    }
    (
      name: name,
      given-title: given-title,
      title: title,
      entries: g.at("entries", default: auto),
      predicate: if name == none { none } else { _kinds.at(name) },
      // 兜底那一组（论文）的判据是现算的，见下面的 mine
      catch-all: name != none and _kinds.at(name) == none,
      options: if name == none { (:) } else { _kind-options.at(name) },
    )
  })

  // 会议论文那一组不在场时，论文组照收会议论文——理工范例就是这样，见 _papers-wide
  let declared = if declared.any(g => g.name == "conferences" and g.entries != none) {
    declared
  } else {
    declared.map(g => if g.name == "papers" { g + (predicate: _papers-wide) } else { g })
  }

  // *一条成果只进一组。* 点名的（[@a@b]）先落袋——不管它排在第几组，别的组
  // 按判据筛时都得把它让出来（先前不让，patents: [@x] 那一条会在论文组里再印一遍）；
  // 判据组之间则*先到先得*，前面的组认领过的，后面的组不再收。
  let entries = _entries(source)
  let named = declared.map(g => if type(g.entries) == content { _refs(g.entries) } else { () }).flatten()
  // 各组的判据先解出来：写了函数就用它，内置组用自己那一份；论文那组是兜底的，
  // 判据是「其余各组都不要」，所以得等别人都解完
  let preds = declared.map(g => {
    // *写 none 的组仍占住自己那几类*——「不列」是把它们排除，不是把它们赶进
    // 兜底组（先前 projects: none 会让项目与获奖跑到论文组里去，还没有驱动）
    if g.entries == none { g.predicate }
    else if type(g.entries) == content { none }
    else if type(g.entries) == function { g.entries }
    else if g.predicate != none { g.predicate }
    else if g.catch-all { none }
    else {
      panic("achievements: groups: entries: auto needs a built-in name; a custom group gives a function or [@keys]")
    }
  })
  let earlier = ()
  let printed = ()
  for (i, g) in declared.enumerate() {
    if g.entries == none { continue }
    if type(g.entries) == content {
      printed.push((g, none))
      continue
    }
    let pred = if preds.at(i) != none { preds.at(i) } else {
      // 兜底组：其余各组的判据取反。*与顺序无关*——它要的就是「谁都不要的」，
      // 不管那些组排在它前面还是后面
      let others = preds.enumerate().filter(((j, q)) => j != i and q != none).map(((j, q)) => q)
      e => not others.any(q => q(e))
    }
    let mine = e => (
      pred(e)
        and e.entry_key not in named
        and not earlier.any(before => before(e))
    )
    // 这一组一条都没有就不排——范例：无专利时此项不必列出。*按类型判得准的
    // 只有内置那三组*；自造判据可能要看别的字段，我们这儿只有键与类型，判不了，
    // 那就照排（作者自己声明的组，空着也是他的选择）
    let has = if type(g.entries) == function { true } else {
      entries.any(e => mine((entry_type: e.type, entry_key: e.key)))
    }
    if has {
      printed.push((g, mine))
      // *兜底组不进 earlier*：它认领的是「谁都不要的」，本来就与别人不重叠，
      // 压进去只会让后面的判据组白白少收
      if preds.at(i) != none { earlier.push(pred) }
    }
  }

  let pattern = pick(t, "group-numbering")
  let lay = layout-for("achievements", auto)
  // 引擎画字符网格那一档：这一页的 set par(linebreaks:)（没给 --input linebreaks 就什么都不发），见 src/layout/resolve.typ
  show: linebreaks-sets.with(lay)
  for (i, (g, mine)) in printed.enumerate() {
    // 组名：顶格（范例 85.03，与版心左缘齐）、*加粗*、不进目录，字体走正文。
    //
    // *段前段后各 5 磅、1.25 倍行距、不对齐网格*——两份范例（本科理工、博士
    // d-stem）三条组名的 pPr 一字不差：spacing before=100 after=100（缇，＝5 磅）
    // line=300 auto（1.25 倍）、snapToGrid=0。PDF 上组名前后的基线步进都是 24.9
    // 上下（正文 19.55 + 5），先前我们按正文段排，前后都只有一行。本科范例第三
    // 组「三、」那一段没有这两格、还带着悬挂缩进，是那一条手抖了，不照它。
    //
    // 加粗的依据是 docx：三条组名的 run 都写着 <w:b/>（本科范例 1-8 页那份）。
    // PDF 里看不出来——字体名仍是 SimSun，Word 给没有粗体面的宋体合成的粗是
    // 描边，与我们的伪粗同一个做法（src/fonts/presets.typ 的 fake-roles）。
    // hithesis 手册里也是 \textbf{（一）…}。
    //
    // *不写 #strong，也不写样式里的 bold: true。* strong 走正文那条
    // tracking-pad（src/fonts/tracking.typ），段首会多垫一份字距——实测组名落在
    // 85.50，范例 85.03；样式里的 bold 那条路（styles.shows 的描边包装）紧挨着
    // omni 的条目表时会把条目末尾的汉字多画一遍（mutool 的 txt 里「论文一」变成
    // 「论文一一」，成因没查清）。这里照 styles 那一层的做法自己发：字重加粗，
    // 宋体没有粗体面就描边，判据与 #strong 同一个（synth.wants-bold-for）。
    // 「参与的科研项目及获奖情况」里那半句「及获奖情况」*跟着内容走*：这一组里
    // 真有 @award 才带。两份范例都自证——理工那组有一条「黑江省科学技术二等奖」，
    // 名字带；人文那组只有一条基金项目，名字就是光「参与的课题项目」。作者自己写了
    // title: 的组不动
    let title = if g.name != "projects" or g.given-title { g.title } else {
      let named-keys = if mine == none { _refs(g.entries) } else { () }
      let has-award = entries.any(e => (
        e.type == "award"
          and (if mine == none { e.key in named-keys } else { mine((entry_type: e.type, entry_key: e.key)) })
      ))
      pick(t, if has-award { "projects-with-awards" } else { "projects" })
    }
    // *人文那一档的组标题是节标题*：s-hss 那四段的 pPr 写着 pStyle=2（标题 2
    // 样式），段前段后 195 缇 ＝ 9.75 磅 ＝ 0.5 行；理工那份没有样式、是加粗的正文段
    // （见上面那一大段实测）。所以人文走样式表的 section 那一档，理工走 group-heading。
    // 两档都是普通段落、不是真 heading——进不了目录也进不了书签，与两份范例一致
    let head = numbering(pattern, i + 1) + title
    if category == "hass" {
      paragraph(head, sheet.current-styles().section + (first-line-indent: (chars: 0)), layout: lay)
    } else {
      group-heading(head, lay)
    }
    _omni.bibliography(
      source,
      title: none,
      // 每组从［1］起，不接着参考文献往下数
      group: none,
      // *每组一个自己的列表名。* omni 的引用跳转查的是一张「锚点串 → 位置」的表，
      // 不给名的列表都算主列表，锚点串与参考文献表的撞在一起、后登记的盖掉先登记的
      // ——实测正文里 @zhang2020 点过去落到了成果页第一条。三组各自从［1］起编，
      // 组与组之间也会撞，所以名字带组号。正文的 @key 没有 set-bib-label，仍归主列表。
      label: "achievements-" + str(i + 1),
      // 收录号、影响因子、对应章节：写在 .bib 的 annote 字段里，接在条目尾
      show-annotation: true,
      ..(if mine == none { (keys: g.entries) } else { (full: true, filter: mine) }),
      ..g.options,
    )
  }
}
