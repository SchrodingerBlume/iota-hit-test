// 致谢。
//
// *排在最末。* 写作指南的次序是 1.4 论文正文（含结论）→ 1.5 参考文献
// → 1.6 攻读学士学位期间取得创新性成果 → 1.7 原创性声明及使用权限
// → 1.8 致谢。hithesis 那边允许放到前置部分去（\hit@structure@here 收
// front / back 两档），HIT 本科这一份规范没这个口子，就放末尾。
//
// 页码接着正文往下数——指南 2.2：「正文以后的页码用阿拉伯数字编排」，
// 所以它与结论一样不需要任何 matter 切换。
//
// 内容照指南 1.8：「对导师和给予指导或协助完成毕业论文（设计）工作的组织和
// 个人，对课题给予资助者表示感谢。内容应简朴、语言应含蓄。」
//
// 排法与结论同构，共用那一层见 src/heading/heading.typ 的 term-chapter。
//
// *正文全是用户写的*，这一页只出章壳——与结论、致谢、个人简历那三页
// 同一个形状，所以走同一支工厂，见 src/heading/heading.typ。
#import "../heading/heading.typ": term-page

#let acknowledgement = term-page("acknowledgement")
