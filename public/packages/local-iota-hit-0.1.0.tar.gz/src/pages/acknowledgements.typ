#import "../heading/heading.typ": term-page

#let acknowledgements = term-page("acknowledgements")
