#import "../heading/heading.typ": term-page

#let acknowledgments = term-page("acknowledgments")
