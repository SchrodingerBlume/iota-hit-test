// 博后报告的「永久通讯地址」：照模板三行，1.25 倍贴网格，悬挂到标签之后；标签连冒号黑体（西文标签加粗）
#import "@local/banshi:0.1.0" as banshi
#import banshi.styles: paragraph
#import banshi.fonts: zihao, heiti, boundary-pad
#import banshi.runs: has-cjk
#import banshi.content: plain-text
#import "../info.typ": final-only-wanted
#import "../once.typ": once
#import "../heading/heading.typ": term-chapter
#import "../terms/lookup.typ": term-table
#import "../terms/lang.typ": resolve-lang
#import "../layout/parts.typ": layout-for

// 悬挂照 docx：地址那行 7.12 字、另两行 7.36 字（hangingChars）
#let _hangs = (address: 7.12, email: 7.36, phone: 7.36)

#let permanent-address(
  address: none,
  email: none,
  phone: none,
  lang: auto,
  title: auto,
  overrides: (:),
  openright: auto,
  shown: auto,
) = context {
  if not final-only-wanted(shown, page: "permanent-address") { return }
  once("permanent-address")
  let t = term-table(resolve-lang(lang), "permanent-address", overrides: overrides)
  term-chapter("permanent-address", lang: lang, overrides: overrides, openright: openright, title: title)
  let lay = layout-for(none, auto)
  let style = (asian-font: "songti", size: zihao.xiaosi, line-spacing: 1.25, snap-to-grid: true)
  for (key, value) in (address: address, email: email, phone: phone) {
    let label = t.at(key)
    let cjk(c) = has-cjk(plain-text(c))
    let run(c) = if cjk(c) { heiti(c) } else { text(weight: "bold", c) }
    // 换字体的接缝上末字的字距丢了（上游 #5353），补回：汉字一份、西文半份
    let pad(c) = h(boundary-pad(lay.docgrid.tracking / (if cjk(plain-text(c).clusters().last()) { 1 } else { 2 })))
    let head = if cjk(label) == cjk(t.colon) { run(label + t.colon) + pad(t.colon) } else {
      run(label) + pad(label) + run(t.colon) + pad(t.colon)
    }
    paragraph({ head; value }, style + (hanging-indent: (chars: _hangs.at(key))), layout: lay)
  }
}
