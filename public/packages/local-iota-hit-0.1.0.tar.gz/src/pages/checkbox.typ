// 选项框：Wingdings 2 的空框与打勾框，轮廓 1:1 抠自官方 PDF。
//
// *两页在用*——本科内封第一行（☐毕业论文 ☐毕业设计）与深圳本科报告首页
// 那一行（2026 年 9 月版新加的「勾选毕设类型」）。抽在这儿，两处共用一份轮廓。
//
// *轮廓是从官方 PDF 里的字形 1:1 抠出来的。* Word 那两个框是 Wingdings 2 的
// U+F0A3（空）与 U+F052（打勾），官方内封（本科毕业论文（设计）书写范例（理工类）
// 第 3 页，以及带勾的那一版）把它们嵌进了 PDF。用 mutool extract 取出字体、
// fontTools 读 glyph 53 与 133 的轮廓，按 unitsPerEm 2048 归一化成 em，
// 就得到下面这两张表。
//
//   空框    外框 173..1653 × 0..1480 单位 → *1480 见方*，线宽 98.5
//   打勾    同一个框，外加一道勾；勾尖冲出框外，到 y=1568、x=1767
//
// 折成 12pt：边长 8.672、线宽 0.577、框底压基线、左缘在字位起点右 1.014。
// 字位宽 0.891 em（trace 里的 adv），实测 96.050 − 85.025 = 11.025 正是它。
//
// *为什么不直接用那个字。* Wingdings 2 是符号字体的私有位，本机未必有；
// □ U+25A1 在不同宋体里大小差得不少。存轮廓则与字体无关，且形状分毫不差——
// 先前用 rect 加两笔画的对钩是我自己描的，勾形不对。
//
// 坐标：x 从字位起点算，y 从*字形顶*往下算，所以盒高就是字形高、
// 盒底正好是基线（box 的默认基线是下缘）。填充用奇偶规则，框才是空心的。
#let checkbox-advance = 0.891em

#let _box-empty = (height: 0.72266em, path: (
    curve.move((0.13281em, 0.67432em)),
    curve.line((0.75928em, 0.67432em)),
    curve.line((0.75928em, 0.04785em)),
    curve.line((0.13281em, 0.04785em)),
    curve.close(),
    curve.move((0.08447em, 0.72266em)),
    curve.line((0.08447em, 0.0em)),
    curve.line((0.80713em, 0.0em)),
    curve.line((0.80713em, 0.72266em)),
    curve.close(),
))

#let _box-checked = (height: 0.76562em, path: (
    curve.move((0.42188em, 0.58447em)),
    curve.line((0.40039em, 0.59863em)),
    curve.quad((0.37256em, 0.6167em), (0.35254em, 0.63477em)),
    curve.quad((0.34863em, 0.61719em), (0.33301em, 0.57812em)),
    curve.line((0.32227em, 0.55029em)),
    curve.quad((0.28564em, 0.45996em), (0.2605em, 0.42407em)),
    curve.quad((0.23535em, 0.38818em), (0.20605em, 0.38525em)),
    curve.quad((0.24561em, 0.34912em), (0.27539em, 0.34912em)),
    curve.quad((0.31543em, 0.34912em), (0.36377em, 0.45801em)),
    curve.line((0.38135em, 0.49707em)),
    curve.quad((0.50879em, 0.26855em), (0.72021em, 0.09082em)),
    curve.line((0.13232em, 0.09082em)),
    curve.line((0.13232em, 0.71729em)),
    curve.line((0.75879em, 0.71729em)),
    curve.line((0.75879em, 0.10791em)),
    curve.quad((0.64551em, 0.21143em), (0.55493em, 0.3396em)),
    curve.quad((0.46436em, 0.46777em), (0.42188em, 0.58447em)),
    curve.close(),
    curve.move((0.80713em, 0.06689em)),
    curve.line((0.80713em, 0.76562em)),
    curve.line((0.08447em, 0.76562em)),
    curve.line((0.08447em, 0.04297em)),
    curve.line((0.78271em, 0.04297em)),
    curve.quad((0.81934em, 0.01758em), (0.84863em, 0.0em)),
    curve.line((0.86279em, 0.02539em)),
    curve.quad((0.83887em, 0.04248em), (0.80713em, 0.06689em)),
    curve.close(),
))

// *盒高写 0，图形用 place 摆*。内联盒的高度会把*行盒*撑开——而
// Word 那边这两个框是*文字*（Wingdings 2 的字形），受行距管：深圳本科报告
// 首页那一行写着 w:line="380" exact ＝ 19pt，字比它高就挤出去，行仍是 19。
// 我们的行盒由样式的 top-edge / bottom-edge 定死（见 src/styles/rules.typ 的
// rules），零高盒因此不参与，框照旧画在基线上——实测那一行的基线从 18.37 回到
// 15.2，与 Word 的 0.8 × 19 一致。
#let checkbox(checked) = {
  let g = if checked { _box-checked } else { _box-empty }
  box(width: checkbox-advance, height: 0pt, place(
    top + left, dy: -g.height,
    curve(fill: black, fill-rule: "even-odd", stroke: none, ..g.path),
  ))
}

