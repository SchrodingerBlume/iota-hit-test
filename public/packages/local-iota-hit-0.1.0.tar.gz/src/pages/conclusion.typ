// 结论。
//
// *它是正文的组成部分，不是后置部分。* 写作指南 1.4.3：「结论作为本科
// 毕业论文（设计）*正文的组成部分*，单独排写，不加章标题序号，不标注
// 引用文献。」所以它写在 #show: mainmatter 之后，页码仍是阿拉伯、页眉照旧，
// 不需要任何 matter 切换——这一点与致谢、附录不同，那两个在正文之后。
//
// 排法与摘要同构：不编号的章标题、字拉开、挂英文目录名、进目录。共用的那一层
// 见 src/heading/heading.typ 的 term-chapter。
//
// *正文全是用户写的*，这一页只出章壳——与结论、致谢、个人简历那三页
// 同一个形状，所以走同一支工厂，见 src/heading/heading.typ。
#import "../heading/heading.typ": term-page

#let conclusion = term-page("conclusion")
