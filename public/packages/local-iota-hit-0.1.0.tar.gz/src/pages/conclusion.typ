#import "../heading/heading.typ": term-page

#let conclusion = term-page("conclusion")
