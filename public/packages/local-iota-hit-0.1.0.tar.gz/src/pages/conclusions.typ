#import "../heading/heading.typ": term-page

#let conclusions = term-page("conclusions")
