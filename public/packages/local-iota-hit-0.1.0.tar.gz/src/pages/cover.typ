// 学位论文封面（封面一）。本科、硕士、博士共用这一套。
//
// 不照 hithesis 排，直接照 Word 范例的段落序列排——本科取「1-8 页+规范章补全+
// 中英摘要 本科毕业论文书写范例（理工类）.docx」的第二页，研究生取「研究生学位
// 论文书写范例…….docx」的第二页。范例那一页带批注（每个元素
// 下面跟着「↑」与「（宋体小1号字加粗）」两段说明），真封面就是把批注段删掉、
// 别的属性一个不动。
//
// 结构与取值全部从 docx 的 w:pPr / w:rPr 读出来，行盒位置在 Word 排出来的
// PDF 上逐条量过（tests/demo-cover-annotated.typ 复现带批注那一页做对拍）。
//
// *这一页只有中文题目那一段贴网格。* 别的段都显式写着 snapToGrid=0，
// 只有它没写、于是取默认的开——所以那一节的 docGrid linePitch=395（19.75pt）
// 只对它生效：自然行高 1.296875×22 = 28.531 装不下一格，占两格 39.5，
// 行盒居中，基线落在 (39.5−28.531)/2 + 22.258 = 27.743。别的段一律
// 「倍数 × 自然行高」，与正文不贴网格那一档同一套。

#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
#import "../terms/lookup.typ": static-terms, term-apply, term-for
#import "../terms/date.typ" as _date
#import banshi.paragraph as linebox
#import "../glyphs/cover.typ": cover-kaishu
#import banshi.fonts as fonts
#import banshi.paragraph: paragraph-mark as enter
#import "../axes.typ": axes, degree-type-for
#import banshi.errors as _errors
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": standalone-layout
#import banshi.styles: centered-line, overflow-note


// 英文题目该用几号字——*不按宽度判，按塞不塞得下判*。
//
// 规范给的是二号，「题目太长时可用小二号」。hithesis 把这句话落成一个宽度判据
// （hit-thesis.cls:6913）：按二号排成不折行的一行量宽，超过 250mm 就降小二。
//
//   \settowidth{\hit@etitlelength}{\erhao\hit@title@cover@en ...}
//   \dim_compare:nNnTF{\hit@etitlelength}>{250mm}{\xiaoer}{\erhao}
//
// *我们不用这个判据。* 250mm 约合封面版心的一又三分之二行——也就是说
// 英文题目一超过两行就降号，可封面上排三四行英文完全放得下。小二该尽量避免：
// 先按二号塞，空行让步全用尽了还装不下，才降小二。所以字号是让步阶梯的
// *最外层*，见下面 cover 里那个循环。
//
// 显式给 title-en-xiaoer 就照给的来，不参与让步。
//
// *范例那两页用的是小二*（<w:sz w:val="36"/>），而按上面这条策略同样的题目
// 会排二号——二号放得下。所以对拍件要*显式*写 title-en-xiaoer: true，
// 把「这是范例的选择、不是我们的策略」摆在明处，不藏在 annotated 里。
// *三态，不是字号*：
//
//   auto   算法判——先按二号塞，空行让步全用尽还装不下才降小二
//   true   用户主动缩：还没到极限就想用小二
//   false  用户强制二号：装不下宁可报错，也不自动降号
//
// *写成布尔而不是收一个字号名。* 规范只给了二号与小二两档，收一个 15pt
// 进来既不合规、也让「该不该降号」失去判据；那就不该长得像「随便给个字号」。
// 布尔加 auto 正好三态，与全项目「布尔项都收 auto」一致。
#let _en-title-size(xiaoer) = {
  assert(
    xiaoer == auto or type(xiaoer) == bool,
    message: "expected auto, true, or false, found " + repr(xiaoer),
  )
  if xiaoer == auto { auto } else { if xiaoer { zihao.xiaoer } else { zihao.erhao } }
}


// 学位类别那一行的字样。字面住在 src/terms/built-in.typ。
//
// 读的是*静态*的 term-defaults 而不是 term-of：这一行要参与封面那个
// 求解器的量高，那时候还进不了 context，读不了 state。用户覆盖经由
// src/pages/front.typ 那一层显式传进来，见 src/terms/lookup.typ 的 static-terms。
// 范例封面上的中英题目。*锚点靠它们算*——见下面求解器里
// sample-inst 那一段。同时就是 title / title-en 的默认值，不多存一份。
#let sample-title = [局部多孔质气体静压轴承关键技术的研究]
#let sample-title-en = [RESEARCH ON KEY TECHNOLOGIES OF PARTIAL POROUS
  EXTERNALLY PRESSURIZED GAS BEARING]

// 「排得够不够好」的阈值，单位是磅。
//
// 得分是 3 × 校名偏差 + 姓名偏离该在的位置，两项都折成长度。不动结构就能排到
// 这个分以内，就不动结构；超过了才把结构档放进来一起比。
//
// 取 10pt（约 3.5mm）：可增减的空行最小是 13.80，半个是 6.9——偏差过了半个空行
// 才开始看得出来，再留点余量。调小则更爱动结构，调大则更保守。
#let _quality-threshold = 10pt

#let cover(
  // 学位层次：bachelor / master / doctor
  degree-level: "doctor",
  // 学位类别那一行。auto 表示本科不发、研究生发「（学术学位论文）」；
  // 给 "professional" 换成专业学位；给 none 一律不发。
  degree-type: auto,
  // 交上去的是哪一种东西，见 src/axes.typ 的 form。practice 那一档换的是
  // 标签（□士实践成果）与学位类别那一行（（专业学位□□……□））
  form: "dissertation",
  // 学位类别那一行在 practice 档要把*实践成果类型*填进括号里（调研报告、
  // 产品设计报告……），见词条 cover-degree-type-professional-practice
  practice-type: [□□……□],
  // 本地化词条表。默认那份是静态的；用户覆盖由 frontpages 那一层传进来
  terms: static-terms("zh", "cover"),
  // 标签那一行，宋体小一号加粗。auto 按学位从 base 桶的 document-type 取
  label: auto,
  // 中文题目，黑体二号
  title: sample-title,
  // 英文题目，Times New Roman 加粗。规范给的是二号，题目太长时可用小二号
  // ——范例那一份题目长，用的是小二，所以默认取小二。
  title-en: sample-title-en,
  title-en-xiaoer: auto,
  // 副题目。none ＝ 没有，见 src/info.typ。中文另起一行排在主题目下面，
  // 英文用冒号接在主题目同一段里
  subtitle: none,
  subtitle-en: none,
  // 学生姓名，宋体小二号加粗。范例里是三个空格子
  author: [□□□],
  // 学校，楷体小二号加粗
  institution: static-terms("zh", "cover").university,
  // 年月，宋体与 Times New Roman 小二号加粗。范例批注的原话是「年、月用阿拉伯
  // 数字」——只提年月，所以规范这一处到月为止。写 ISO，见 src/terms/date.typ
  date: "2022-06",
  // 姓名那一行、校名那一行的*基线距页顶*的*参考位置*，实测自 Word
  // 范例第二页。
  //
  // 这两处不钉死，而是靠增减空段维持在参考位置*附近*——题目一长，
  // 就少发一个空段把它提回来；一短就多发一个。空段有最小粒度
  // （校名前 15.5625，姓名前 35.66），落点只能落在那个粒度上，
  // 所以是「大体不变」而不是精确不变。这正是 Word 里排版的人在做的事。
  //
  // 年月不单独维持——它紧跟校名，两行的相对位置由校名那一行的行盒定。
  //
  // auto ＝ *照范例那一页排一遍算出来*：名义空段 2/2/6、范例的中英题目，
  // 求解器拿它当靶子。见下面 sample-inst 那一段。
  //
  // 先前这里还有个 author-baseline，解析了却没有一处读它——姓名的位置是靠
  // 「在英文题目与校名之间的比例」维持的（ref-ratio），不是靠绝对落点。删了。
  institution-baseline: auto,
  // 这一页的页面设置。auto ＝ 本档默认加封面差额（行距 19.75、不出页眉页脚，见
  // src/layout/presets.typ）。用户那条路（lib.typ 的 cover）由 src/pages/front.typ 在
  // context 里把文档＋段那一份并好再传进来；这里 context 外面就要发 set page，
  // 读不了 state，所以 auto 只能是免 context 的那一份
  layout: auto,
  // 排不下时在纸角发一条红字提示。Typst 没有「警告」这一档，只有拦编译，
  // 而为了一页封面卡住整篇文档不合适——所以提示排进页面里，编译照常。
  //
  // auto ＝ 不写 ＝ 发。排不下是真出了事，默认该说一声
  warning: auto,
  // 排成范例那一页的样子——每个元素下面跟着「↑」与一行说明。*对拍用*，
  // 正常排版不要开。范例那一页是 Word 真排过、有 PDF 可逐条量基线的，
  // 对上了才说明取值没错；真封面就是把这些批注段删掉、别的一个不动。
  //
  // auto ＝ 不写 ＝ 不发批注。这一档得显式要
  annotated: auto,
  // 查词条递的轴（全部的轴，src/terms/lookup.typ 的 variant-of）。这一页进不了 context，
  // 由 src/pages/front.typ 按 info 算好传进来；直接调（对拍件）不给就只按这一页自己的参数
  variant: auto,
) = {
  let variant = (if variant == auto { (:) } else { variant }) + (degree-level: degree-level, form: form)
  let warning = warning != false
  let annotated = annotated == true
  let layout = if layout == auto { standalone-layout("cover") } else { layout }
  // 引擎画字符网格那一档：这一页的 set par(linebreaks:)（没给 --input linebreaks 就什么都不发），见 banshi/src/layout/resolve.typ
  show: linebreaks-sets.with(layout)
  assert(
    degree-level in axes.degree-level,
    message: _errors.expected-one-of(axes.degree-level, degree-level),
  )
  let label = if label == auto {
    term-for(terms, "document-type", variant)
  } else { label }
  // 日期跟 text.lang 走，这一页下面那句 set text 设的是 zh
  let date = _date.render(date)
  // 先验用户写的那个值，再谈本科要不要——写错键名该报错，与学位无关
  assert(
    degree-type == auto or degree-type == none or degree-type in axes.degree-type,
    message: "expected "
      + _errors.one-of(("auto", "none") + axes.degree-type.map(repr))
      + ", found " + repr(degree-type),
  )
  // 本科没有学位类别那一行。*显式写了也回落到 none*——学术/专业是*学位*
  // 的属性，本科毕业论文不授学位，这一行无从谈起，范例里也没有。
  //
  // 这是少有的*不照用户写的排*的地方：别处一律「用户咋写就咋排」，这里是
  // 因为写了也没有对应的字样可排（词条表里只有研究生那两条），排出来是错的。
  //
  // 研究生那一档不写时按 form 定（实践成果只有专业学位才交），*学位耦合住在
  // 轴那一层*——报告首页那一格也要问同一个问题，见 src/axes.typ
  let degree-type = degree-type-for(degree-level, degree-type, form)

  // 页眉页脚按 layout 那两条记录的 shown 定：封面差额写的是 false（指南 3.4
  // 「除封面及内封外，各页均应加页眉」）。auto 在这儿就是「随外面」，不动
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin,
    ..(if layout.header.shown == false { (header: none) } else { (:) }),
    ..(if layout.footer.shown == false { (footer: none) } else { (:) }),
  )
  // 这一节的 Normal 是 sz24，也就是小四 12pt。空段的高度按 ¶ 的字号算，
  // 而 ¶ 没写字号时继承 Normal——所以基准字号必须在这里设，
  // 不设的话 enter 读到的是 Typst 默认的 11pt，页顶三个空段就差 3.45。
  set text(size: zihao.xiaosi, lang: "zh", region: "cn")
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
  // 批注段：12pt 宋体居中，与范例那一页同款。
  //
  // *关掉时行要留着，只是字没了。* 真封面不是把批注段删掉，是把批注的
  // *字*删掉——段落还在，高度不变。所以这一档发一个同高的空段
  // （12pt 宋体一行 = 1.296875×12 = 15.5625），封面的纵向节奏与范例那一页
  // 完全一致，校名与年月钉的那个位置也就仍然对得上。
  let note(body) = if annotated {
    centered-line(body, font: "songti", size: zihao.xiaosi, layout: layout)
  } else {
    enter(size: zihao.xiaosi, font: "songti", line-spacing: 1)
  }

  // ==== 版面的三段与四处可调空行 ====
  //
  // 照 docx 的段落序列排。可调的*只有单倍行距的空行*——1.25 倍那两段
  // （第 31、35 段）是版式的一部分，不能增减。
  //
  //   段        内容                  行距    高        可调
  //   19–21     页顶三个空段          单倍    13.80     不动（动了整页都挪）
  //   22–25     标题名 / 中文题目
  //   26, 27    中英题目之间          单倍    15.5625   *最后*的可让项
  //   28        英文题目
  //   29, 30    英文题目→姓名         单倍    15.5625   可调，管姓名
  //   31        空段                  1.25    35.664    *不可动*
  //   32        姓名
  //   33, 34    姓名→校名             单倍    15.5625   可调，管校名
  //   35        空段                  1.25    25.875    *不可动*
  //   36–41     校名前六个空段        单倍    13.80     可调，管校名
  //   42, 43    校名 / 年月

  // 英文副题目「用冒号相连」（指南 3.3.1 末句）——*接在同一段里*，不另
  // 起一行：另起一行是中文那一档专有的说法。冒号用全角，与内封字段那一列的
  // 「Candidate：」同一个字（范例第 3 页），全套官方文件里英文侧的冒号都是它
  let title-en-full = if subtitle-en == none { title-en } else {
    title-en + [：] + subtitle-en
  }

  // 页顶到英文题目为止。squeeze 是挤占掉的中英题目之间的空行数。
  //
  // *sub 单独一档*：范例那一页没有副题目，靶子那几次调用要显式写 none，
  // 不然算出来的校名参考位置会带上一行副题目的高，凭空偏低
  let upto-en-block(en-size, squeeze, zh: title, sub: subtitle, en: title-en-full) = {
    // 空段的高按 ¶ 的字体算，而 ¶ 取的是 w:rFonts 的 *ascii 槽*。第 19–21
    // 段没有 rPr，ascii 继承 docDefaults 的 Times New Roman——所以按西文的
    // 1.15 算，一个 13.80，不是汉字的 15.5625。enter 的 font 默认就是这一档。
    enter(3, size: zihao.xiaosi, line-spacing: 1)
    centered-line(label, font: "songti", size: zihao.xiaoyi, bold: true, layout: layout)
    note[↑]
    note[（由 `degree-level: "bachelor"|"master"|"doctor"` 决定）]
    // 学位类别。本科那一页没有这一行，研究生范例里它排在标签与中文题目之间，
    // 宋体小二加粗，后面同样跟两个批注段。
    if degree-type != none {
      // practice 那一档的词条是*收值的函数*——括号里填专业学位类别的名目，
      // 收槽由 src/terms/lookup.typ 的 term-apply 管
      centered-line(
        term-apply(
          terms, "degree-type", variant + (degree-type: degree-type), practice-type,
        ),
        font: "songti", size: zihao.xiaoer, bold: true, layout: layout,
      )
      note[↑]
      note[（由 `degree-type: "academic"|"professional"|none` 决定）]
    }
    // 中文题目：黑体本身不加粗，夹在里头的西文要加粗
    centered-line(
      zh, font: "heiti", size: zihao.erhao, above: 12pt,
      snap: true, latin-bold: true, layout: layout,
    )
    if squeeze < 2 { note[↑] }
    if squeeze < 1 { note[（通过 `title: []` 键入）] }
    // 副题目：「另起一行，用小 2 号字，比主题目退 4 个半角字符加破折号书写」
    // （指南 3.3.1 末句）。
    //
    // *「退 4 个半角」是从居中位置往右挪 4 个半角*，也就是 2 个汉字。
    // 居中的一行要右移 d，就把左边让出 2d——剩下的宽度居中，净位移正好一半。
    // 4 个半角 ＝ 2 个汉字，所以左边让出 4 个汉字；小 2 号一个汉字就是 18pt，
    // 让出 72pt、净挪 36pt。hithesis 的 \hspace{-4em} 是同一个算法（4em 于
    // 小二就是 4 个汉字），只是它靠负空格把行盒缩窄，我们靠 pad——折行时
    // 两行都跟着挪，负空格只挪第一行。
    //
    // 字号规范写死小 2 号；*字体没写*，跟主题目走黑体（hithesis 也是）。
    // 上方不留额外间距：原话是「另起一行」，不是另起一段
    if sub != none {
      pad(left: 4 * zihao.xiaoer, centered-line(
        [——] + sub, font: "heiti", size: zihao.xiaoer, latin-bold: true, layout: layout,
      ))
    }
    centered-line(
      en, font: "serif", size: en-size, bold: true,
      above: 12pt, line-spacing: 1.25, layout: layout,
    )
  }

  // 英文题目与姓名之间。批注档要原样排那两段字，真封面才可以增减空行。
  let gap-en-author(n) = if annotated {
    note[↑]
    note[（通过 `title-en: []` 键入，太长时可用 `title-en-xiaoer: true` 转为小 2 号字）]
  } else if n > 0 {
    enter(n, size: zihao.xiaosi, font: "songti", line-spacing: 1)
  }
  // 第 31 段，宋体二号。ascii 显式写了宋体，所以按汉字的 1.296875 算：
  // 1.25 倍是 35.664，改成单倍是 28.531。
  //
  // *不参与增减*——它不是单倍空行。只有让步阶梯最后那几级才动它：
  // relax 1 把 1.25 倍改单倍（35.664→28.531），relax 2 起整段删掉。
  let fixed-before-author(relax) = if relax < 2 {
    enter(size: zihao.erhao, font: "songti", line-spacing: if relax == 0 { 1.25 } else { 1 })
  }

  // 姓名与校名之间：先是可增减的单倍空行（第 33、34 段那两个的位置），
  // 再是不可动的第 35 段，最后是可增减的单倍空行（第 36–41 段）。
  let gap-author-inst(blanks-below-author, blanks-before-inst, relax) = {
    if annotated {
      note[↑]
      note[（通过 `author: []` 键入）]
    } else if blanks-below-author > 0 {
      enter(blanks-below-author, size: zihao.xiaosi, font: "songti", line-spacing: 1)
    }
    // 第 35 段只设了 eastAsia="黑体"，*ascii 空着*，所以 ¶ 仍是继承来的
    // Times New Roman——按西文 1.15 算：1.25 倍是 25.875，单倍是 20.700。
    // 写成黑体会算成 29.18，差 3.3pt，是错的。不参与增减，只有最后那几级动它：
    // relax 1 改单倍（25.875→20.700），relax 3 才删掉——姓名上面那个先删。
    if relax < 3 {
      enter(size: zihao.xiaoer, line-spacing: if relax == 0 { 1.25 } else { 1 })
    }
    // 第 36–41 段，没有 rPr，同样是 Times 小四，一个 13.80
    if blanks-before-inst > 0 { enter(blanks-before-inst, size: zihao.xiaosi, line-spacing: 1) }
  }

  context {
    let author-metrics = linebox.metrics((size: zihao.xiaoer, font-zh: "songti"), layout: layout)
    let institution-metrics = linebox.metrics(
      (size: zihao.xiaoer, font-zh: "kaishu", line-spacing: 1.35), layout: layout,
    )

    // 量高度要*给版心宽*。measure 默认按无限宽量，英文题目不折行，
    // 量出来只有一行——正是我们要判的那件事被抹掉了。包一层定宽的 block
    // 只是为了量，不进版面。
    let height-of(it) = measure(block(width: layout.text-width, it)).height

    let author-line = centered-line(author, font: "songti", size: zihao.xiaoer, bold: true, layout: layout)
    let inst-lines = {
      // *校名那一行走三层回落*：真楷体 → SimKai 轮廓 → 教育部楷体 → 伪斜宋体。
      // 见 src/glyphs/cover.typ——webapp 那一档非画轮廓不可，那边的楷体只有繁体字形，
      // 照排会把校名变成「哈爾濱工業大學」。
      centered-line(cover-kaishu(institution), font: "kaishu",
        size: zihao.xiaoer, bold: true, line-spacing: 1.35, layout: layout)
      centered-line(date, font: "songti", size: zihao.xiaoer, bold: true, layout: layout)
    }

    // 各段的高只量一次，之后全是算术。相邻块的间距在这些切点上都是 0
    // （enter 发的块 spacing 为 0，centered-line 的 below 为 0、above 只在
    // 题目那两处非零且不在切点上），所以高度可加。
    let cjk-blank = height-of(enter(1, size: zihao.xiaosi, font: "songti", line-spacing: 1))   // 15.5625
    // 第 31、35 段的四档高，对应 relax 0..3：
    //   0  1.25 倍原样      35.664 / 25.875
    //   1  都改成单倍       28.531 / 20.700
    //   2  删掉姓名上面那个      0 / 20.700
    //   3  下面那个也删          0 /      0
    let blanks-above-heights = (0, 1, 2, 3).map(relax => height-of(fixed-before-author(relax)))
    let author-height = height-of(author-line)
    let blanks-below-heights = (0, 1, 2, 3).map(relax => height-of(
      if relax < 3 {
        enter(size: zihao.xiaoer, line-spacing: if relax == 0 { 1.25 } else { 1 })
      },
    ))
    let latin-blank = height-of(enter(1, size: zihao.xiaosi, line-spacing: 1))    // 13.80
    let institution-height = height-of(inst-lines)

    // 一组取值下的几个关键量
    let layout-at(
      upto-en-heights, squeeze,
      blanks-above-author, blanks-below-author, blanks-before-inst, relax,
    ) = {
      let en-bottom = layout.margin.top + upto-en-heights.at(squeeze)
      let author-top = en-bottom + blanks-above-author * cjk-blank + blanks-above-heights.at(relax)
      let inst-base = (
        author-top + author-height
          + blanks-below-author * cjk-blank + blanks-below-heights.at(relax)
          + blanks-before-inst * latin-blank
          + institution-metrics.ascent
      )
      let span = (inst-base - institution-metrics.ascent) - en-bottom
      (
        author: author-top + author-metrics.ascent,
        inst: inst-base,
        en-bottom: en-bottom,
        span: span,
        // 姓名的行盒中心在「英文题目底 ↔ 校名顶」这一段里的位置比例
        ratio: (author-top + author-metrics.box / 2 - en-bottom) / span,
        total: (inst-base - institution-metrics.ascent - layout.margin.top) + institution-height,
      )
    }

    // 姓名该落在什么比例上——*不拍数，从范例自己算*。
    //
    // Word 范例那一页用的是 2 / 2 / 6 这组空行数（第 29、30 段两个，
    // 第 33、34 段两个，第 36–41 段六个），我们排出来与它逐条差不到 0.24。
    // 所以把这组取值代进去，姓名落在「英文题目底 ↔ 校名顶」里的那个比例，
    // 就是范例的比例。题目变长变短时按这个比例去凑，姓名的视觉位置才不变。
    //
    // 这个比例*与题目长短、与字号都无关*：2/2/6 这组取值下，英文题目底到
    // 校名顶之间的每一段都是定长（35.664 + 姓名行 + 2×15.5625 + 25.875 +
    // 6×13.80），题目变长只是把整段一起往下推，跨度不变。所以拿任意一份题目
    // 代进去算出来都是同一个数，0.3412。
    // *靶子不是一个数，是范例那一页的排法。* 拿范例的中英题目、名义空段
    // 2/2/6、不挤占不让步，照 docx 排一遍，量出校名该落在哪。
    //
    // *按 degree-level 分档是自动的*：本科那一页没有「学位类别」那一行、标签也
    // 短一档，upto-en-block 里那个 if 自然让它短一截，算出来的靶子就跟着变——
    // 先前 _degree-baselines 里存的三对数（本科 631.92、硕博 686.45）正是这个
    // 差，现在不用存了。
    //
    // 题目按范例排 *小二*：范例那一页用的就是小二（<w:sz w:val="36"/>）。
    let sample-heights = (0, 1, 2).map(squeeze => height-of(
      upto-en-block(zihao.xiaoer, squeeze, zh: sample-title, sub: none, en: sample-title-en),
    ))
    let sample = layout-at(sample-heights, 0, 2, 2, 6, 0)
    let institution-baseline = if institution-baseline == auto {
      sample.inst
    } else { institution-baseline }
    let ref-ratio = layout-at((0pt, 0pt, 0pt), 0, 2, 2, 6, 0).ratio

    // 联合挑一组 (挤占数, 英文题目→姓名, 姓名→校名, 校名前)。
    //
    // 目标按优先级：
    //   一、校名与年月的位置尽可能不变
    //   二、姓名在视觉上居于英文标题与校名的正中
    //
    // 第一项按 0.5pt 量化再比——半磅是 0.18mm，肉眼分不出，两组在校名上差
    // 不到半磅就算打平，剩下的自由度让给姓名居中。不量化的话第一项永远分出
    // 胜负，第二项就成了摆设。
    //
    // 再往后两级用来断平局：挤占数小的优先（中英题目之间那两个空行是最后的
    // 途径，能不动就不动），然后是离 Word 自己那组取值（2 / 2 / 6）最近的。
    // 批注档只排范例那一页，不参与凑：第 29/30、33/34 段是有字的，
    // gap-en-author 与 gap-author-inst 在这一档一律原样发那两行字，
    // 让优化器去挑 blanks-above-author / blanks-below-author 反而会与真正排出来的高度对不上。
    // 联合挑一组取值。
    //
    // *让步阶梯。* 后两级是保底，只有前一级*一组可行解都找不到*
    // （也就是怎么排都跨页）时才打开，不拿来微调：
    //
    //   (0, 否)  只增减单倍空行——正常情形走这一档
    //   (1, 否)  挤占中英题目之间的一个空行
    //   (2, 否)  两个都挤占
    //   (2, 是)  *最后*：把第 31、35 段的 1.25 倍改成单倍
    //            （35.664→28.531，25.875→20.700，共省 12.31）
    //
    // *目标。* 两项都是长度，加权相加：
    //
    //   得分 = 3 × |校名偏差| + |姓名偏离该在的位置|
    //
    // 校名计三倍权，也就是「宁可姓名偏 3pt，也不让校名偏 1pt」。不用字典序：
    // 实测校名的可达落点很密，字典序下第一项几乎总能压到零点几磅，第二项就
    // 成了摆设——英文题目排五行那一档会为了校名的 0.04pt 把姓名推低 48pt。
    // 加权之后同一档选的是校名让 7pt、姓名回到位，明显更像人排的。
    //
    // 平局再看：挤占数小的优先，然后是离 Word 自己那组取值（2/2/6）最近的。
    let given = _en-title-size(title-en-xiaoer)
    let sizes = if given != auto {
      (given,)
    } else {
      (_en-title-size(false), _en-title-size(true))
    }

    // 每个字号下「页顶到英文题目为止」的高，三种挤占数各量一次
    let upto-en-heights-by-size = sizes.map(size => (0, 1, 2).map(
      squeeze => height-of(upto-en-block(size, squeeze)),
    ))

    // 某个字号、某一档结构下，挑最优的空行组合。
    //
    // 目标按优先级：一、校名与年月的位置尽可能不变；二、姓名在视觉上落在
    // 范例里那个比例上。两项都是长度，加权相加：
    //
    //   得分 = 3 × |校名偏差| + |姓名偏离该在的位置|
    //
    // 校名计三倍权，也就是「宁可姓名偏 3pt，也不让校名偏 1pt」。不用字典序：
    // 实测校名的可达落点很密，字典序下第一项几乎总能压到零点几磅，第二项就
    // 成了摆设——英文题目排五行那一档会为了校名的 0.04pt 把姓名推低 48pt。
    //
    // 平局看谁离 Word 自己那组取值（2/2/6）近。
    let best-at-rung(upto-en-heights, squeeze, relax) = {
      let best-key = none
      let picked-so-far = none
      for blanks-above-author in range(0, 7) {
        for blanks-below-author in range(0, 3) {
          for blanks-before-inst in range(0, 13) {
            let result = layout-at(
              upto-en-heights, squeeze,
              blanks-above-author, blanks-below-author, blanks-before-inst, relax,
            )
            if result.total > layout.text-height { continue }
            let score = (
              3 * calc.abs(result.inst - institution-baseline)
                + calc.abs(result.ratio - ref-ratio) * result.span
            )
            // 同分时挑离范例那组 2 / 2 / 6 最近的
            let rank-key = (
              score,
              calc.abs(blanks-above-author - 2)
                + calc.abs(blanks-below-author - 2)
                + calc.abs(blanks-before-inst - 6),
            )
            if best-key == none or rank-key < best-key {
              best-key = rank-key
              picked-so-far = (
                blanks-above-author, blanks-below-author, blanks-before-inst, score,
              )
            }
          }
        }
      }
      picked-so-far
    }

    // 结构性让步的六档。挤占中英题目之间的空行、把 1.25 倍的两段改成单倍、
    // 再到把它们删掉——每一档都在动 Word 的段落结构，代价依次变大。
    let rungs = ((0, 0), (1, 0), (2, 0), (2, 1), (2, 2), (2, 3))

    // *一、定字号：按塞不塞得下，不按排得好不好。*
    //
    // 取第一个「不动结构就排得下」的字号。降小二是规范明写允许的一档，但也
    // 只在二号排不下时才用——*不为了排得好看去缩号*。实测过：放开让字号
    // 参与择优，默认那份会为了校名 0.08pt、比例 0.028 就跑去小二，不合适。
    let size-index = none
    let base = none
    for i in range(0, sizes.len()) {
      if size-index == none {
        let picked = best-at-rung(upto-en-heights-by-size.at(i), 0, 0)
        if picked != none { size-index = i; base = picked }
      }
    }
    // 哪个字号都排不下，只能在最小的字号上动结构
    if size-index == none { size-index = sizes.len() - 1 }
    let upto-en-heights = upto-en-heights-by-size.at(size-index)

    // *二、结构档只在「排得不够好」时才进来。*
    //
    // 不动结构就能排到阈值以内，就不动——「最后的途径」的本意是不为小便宜
    // 动结构。但结构性让步不只是「让它装下」，它还在*重新分配空白*，
    // 而那正是姓名定位需要的：实测中英文题目都很长时，不动结构姓名的比例是
    // 0.5577（明显偏下，目标 0.3412），允许挤占加改行距就回到 0.3527。
    //
    // 平局偏向靠前的档。
    let best = if annotated {
      (sizes.at(0), 0, 2, 2, 6, 0)
    } else if base != none and base.at(3) <= _quality-threshold {
      (sizes.at(size-index), 0, base.at(0), base.at(1), base.at(2), 0)
    } else {
      let best-key = none
      let got = none
      for (rung-index, rung) in rungs.enumerate() {
        let (squeeze, relax) = rung
        let picked = best-at-rung(upto-en-heights, squeeze, relax)
        if picked != none {
          let rank-key = (picked.at(3), rung-index)
          if best-key == none or rank-key < best-key {
            best-key = rank-key
            got = (sizes.at(size-index), squeeze, picked.at(0), picked.at(1), picked.at(2), relax)
          }
        }
      }
      got
    }

    // 让步全用尽还是装不下。*不拦编译*——Typst 没有「警告」这一档，
    // panic 就是不让人编译，为了一页封面把整篇文档卡住不合适。
    // 按压得最紧的一组照排（会溢到第二页），另发一条页面内的红字提示。
    let overflow = best == none
    if overflow {
      best = (sizes.last(), 2, 0, 0, 0, 3)
    }

    let (en-size, squeeze, blanks-above-author, blanks-below-author, blanks-before-inst, relax) = best

    let body = {
      upto-en-block(en-size, squeeze)
      gap-en-author(blanks-above-author)
      fixed-before-author(relax)
      author-line
      gap-author-inst(blanks-below-author, blanks-before-inst, relax)
      inst-lines
    }

    // *只有跨页才提示。* 自动缩成小二是让步阶梯的正常一环，不是异常，
    // 每次都弹一条反而吵。红字那一块见 banshi/src/styles/parts.typ 的 overflow-note
    if overflow and warning {
      set page(foreground: overflow-note(terms.warning-overflow, terms.warning-false))
      body
    } else {
      body
    }
  }
}
