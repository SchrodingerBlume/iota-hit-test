// 原创性声明与使用权限。
//
// *正文是规范给死的，不是用户写的。* 指南 1.7 只说「作者可直接在教务处
// 网站下载本部分内容电子版。作者和导师本人签署姓名」——文字本身没印在指南里，
// 两份都抄自范例，见 src/config/terms.typ 的 declaration 桶。
//
// 排法逐条量自范例：本科抄「1-8 页+规范章补全…」第 32 页（字号干净，18 / 15 /
// 12），研究生抄「博士研究生学位论文书写范例」第 24 页。
//
// 版面：
//
//   大标题   小二黑体（18）居中。本科那份在范例里是*两行*——标题够短，
//            排得下一行，是那一页手工断的，照排
//   小标题   小三黑体（15）居中，两节各一个
//   正文     小四宋体（12），首行缩进 2 字，与正文同一档
//   签名行   小四宋体，「作者签名：」「日期：　年　月　日」
//
// *行距*：大标题走章标题那一档（1.25，见 src/config/styles.typ 的 _headings；范例
// 这一段没写 line、走样式表的 1.2，大标题→小标题因此差 1.17，见 tests/check-declarations.py）；
// 正文步进 19.45~19.55，与正文那一档一致。
//
// *照 docx 的段落序列排，不存量好的间距*——空当是空段，签名行里的空当是
// 字面空格，两样都由排版算出宽度，见下面各处。七个段间步进逐个对上范例第 18 页，
// 由 tests/check-declarations.py 钉着。
//
// *正文那一档就是全文的正文档*（src/config/styles.typ 的 default-styles.body），
// 这一页不另起。先前它自己抄了一份，抄的时候漏了两端对齐与横向字符网格。
//
// 居中那几行仍偏一点点（小标题量到 +1.13，范例 180.83、我们 181.96）：整行宽度
// 里末字那一份网格增量算不算，Word 与我们判得不同，差在半格以内，见 _line。

#import "../flow/stage.typ": final-only-wanted
#import "../engine/part.typ"
#import "../engine/styles.typ"
#import "../config/fonts.typ": zihao
#import "../blocks/enter.typ": enter
#import "../blocks/heading.typ": term-chapter
#import "../engine/terms.typ": subject-of, term-apply, term-of, term-table, term-for, info-variant
#import "../engine/info.typ": info-get
#import "../engine/lang.typ": doc-lang
#import "../engine/layout.typ": layout-for
#import "../engine/once.typ": once
#import "../blocks/paragraph.typ": paragraph
#import "../config/styles.typ": default-styles

// 三档的取值。字号规范没写，是从范例的字号反推的。
//
// *正文那几段的首行缩进各不相同。* 官方那份 docx 逐段写着 w:ind，
// Word 排出来的首字 x 与它一一对上（版心左 85.05，一个字 12.4543）：
//
//   本人郑重声明…           firstLineChars=200  2 字      110.05
//   本科毕业论文（设计）是…   firstLine=573 缇     28.65pt   113.80
//   （1）学校可以…           firstLineChars=150  1.5 字    103.80
//   保密论文… / 本人知悉…    firstLineChars=200  2 字      110.05
//
// 中间那两段*不是整字数*——573 缇既不是 2 字（480）也不是 2.5 字（600），
// 是排版的人手拖出来的；1.5 字那一段大概是为了让「（1）」的括号看齐左边。
// 先前五段一律按 2 字排，中间两段各偏了 3.75 与 6.25。
// ==== 版面的段落序列 ====
//
// 段与段之间的空当*全是空段*，不是段前段后。两份范例的 docx 摊开就是下面
// 这两张表——行距一律 w:line="300" auto（1.25 倍），w:spacing 的 before/after
// 一个都没写，只有本科那两个小标题各带 beforeLines/afterLines=50（0.5 行）。
//
// *空段的高按 ¶ 的字体算，而 ¶ 取的是 w:rFonts 的 ascii 槽。* 两份范例里
// 所有空段的 ascii 都空着，继承 docDefaults 的 Times New Roman，所以一律按西文的
// 1.15 算，不是汉字的 1.296875。研究生第 692 段写了 eastAsia="黑体" 而 ascii 仍
// 空着——与封面第 35 段同一个坑，写成黑体会算高 3pt 多，是错的。见
// src/pages/report/cover.typ 那一段同样的说明。
//
//   本科（范例第 18 页，段 513–531）
//     513,514  大标题两行            段后 0 / 段前 0
//     515      小标题                段前 0.5 行、段后 0.5 行，小三
//     516      正文
//     517,518  空段  小四  西文 1.15   17.25 一个
//     519      签名
//     520,521  空段  *四号*  西文  20.13 一个
//     522      小标题                段前 0.5 行、段后 0.5 行，小三
//     523–526  正文四段
//     527,528  空段  小四
//     529      签名
//     530      空段  小四
//     531      签名
//
//   研究生（博士范例，段 691–711）：*连那 0.5 行也没有*，全靠空段
//     691      大标题一行
//     692      空段  *三号*（sz=32）西文；ascii 空，eastAsia 写了黑体也不算数
//     693      小标题                小三
//     694      空段  小四
//     695      正文
//     696      空段  小四
//     697      签名
//     698–700  空段  *四号*  三个
//     701      小标题                小三
//     702      空段  小四
//     703–706  正文四段
//     707,708  空段  小四
//     709      签名
//     710      空段  小四
//     711      签名
//
// *先前这里存着六个量好的「基线步进」。* 那是把结果当成了原因——那些数是
// 「空几段、多大字号」在 Word 里排出来的*后果*，存后果的话字号一改、行距一
// 改就全错，改的人还无从知道该改成多少。封面那一页早就是照段落序列排的，空段交
// 给 enter() 发，这里跟上。

// 签名行与题目空白*都是字面空格敲出来的*，不是量出来的空当。
//
// 三份 docx 里那一行完全一样：作者签名：[18 空格]日期：[5 空格]年[3 空格]月
// [3 空格]日；题目那一格是《[15 空格]》。行本身*左缩进、不居中*——范例
// 第 18 页段 519 是 firstLineChars=800（8 字），段 529 / 531 是 750（7.5 字）。
//
// *空格按半宽走，一个 6.227。* 实测范例「作者签名：」起笔 184.83，五个
// 全角到 247.10，「日期：」落在 359.15；18 个空格摊下来 112.05 ÷ 18 = 6.225
// ＝ 半个网格格（12.4543 ÷ 2）——中易的空格是半宽 6.0，再吃半格增量 0.227。
//
// 先前这里存着四个 h() 的宽度和一个 95.06pt 的题目空白。那是把结果当成了原因：
// 字号一改就全错，而且把「这一行本来就是敲出来的空格」这件事整个盖住了。

// 原创性声明与使用权限那一页。
//
// *它不收内容*——正文是规范给死的。要改字走 overrides，键在
// declaration 桶里，比如 declaration-author。
#let declarations(
  // *三条都是 auto ＝ 取 info／文档语言那一份*。这一页没有包装层
  // （lib.typ 直接导出它，套一层 LSP 就没了），所以自己去拿
  degree-level: auto,
  // 交上去的是哪一种东西，见 src/config/axes.typ 的 form。practice 那一档整页
  // 换字（实践成果原创性声明……），并在导师之下多一行「行业导师签名：」
  form: auto,
  lang: auto,
  // 声明里《》那一格填什么。auto 取 info 的 title；给空内容就留一段空白手写
  title: auto,
  overrides: (:),
  // 这一页要不要从右手页起。auto 跟随所在的 matter——它按研究生规范 2.4 排在
  // 后置、致谢之前，右翻页正是它该有的开关（先前整个漏了）
  openright: auto,
  // 两字标题撑不撑开。auto 跟文档级 title-spread，见 src/engine/spread.typ
  spread: auto,
  // 这一页的页面设置：局部字典并到文档＋段那一份上，整份就整份替换。这一页没有
  // 自己的节，小标题的 0.5 行按正文的跨度算（195 缇 ＝ 9.75），见 src/config/layout.typ
  layout: auto,
  // 这一页的各档取值。*只有小标题是它自己的一档*——正文那一档就是全文的
  // 正文档（src/config/styles.typ 的 default-styles.body），别的三条只是它换一个首行缩进。
  // 先前这里自己抄了一份正文档，抄的时候漏了两端对齐与横向字符网格，一直到重新
  // 对范例才发现；复制品就是这么坏的。
  styles: (
    // 小标题：小三黑体，*居中*（docx 里 pStyle 那一档写着 w:jc="center"），
    // *段前段后各 0.5 行*（beforeLines/afterLines=50，本科才有）。字号规范
    // 没写，从范例反推；横向网格由版面给——实测逐字步进 15.48 ≈ 15.0 ＋ 0.4543。
    //
    // *align 与 above/below 写在格式里*，因为它们就是 Word 的段落
    // 属性（w:jc 与 w:spacing），不是排的时候临时决定的事。
    section: (
      snap-to-docgrid: false,
      size: zihao.xiaosan, font-zh: "heiti", line-spacing: 1.25, first-line-indent: (chars: 0),
      align: center, above: (lines: 0.5), below: (lines: 0.5),
    ),
    body: default-styles.body,
    // 那两段的首行缩进不是 2 字，见上面 w:ind 那张表：w:ind firstLine=573 缇 ＝ 28.65pt
    authorization-text-lead: default-styles.body + (first-line-indent: 28.65pt),
    authorization-text-items: default-styles.body + (first-line-indent: (chars: 1.5)),
    // 两条签名行的左缩进各一档：w:ind firstLineChars 800 与 750
    signature-first: default-styles.body + (first-line-indent: (chars: 8)),
    signature: default-styles.body + (first-line-indent: (chars: 7.5)),
  ),
  // 这一页只在终稿出现。三态见 src/flow/stage.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }
  // 只该印一次的页：对拍件要在一篇里排几份，走 overrides 各排各的也只发一条警告。
  // 见 src/engine/once.typ
  once("declarations")

  let degree-level = if degree-level == auto { info-get().degree-level } else { degree-level }
  let form = if form == auto { info-get().form } else { form }
  let lang = if lang == auto { doc-lang.get() } else { lang }

  // *正文一律取中文那一档。* 规范只有中文一份——英文桶里除了「这一页在
  // 英文目录里叫什么」之外什么也没有（见 src/config/terms.typ 的 declarations
  // 桶）。英文文档翻到这一页就*整页回退中文*，而不是排出一半英文一半中文。
  // 哪天官方出了英文版，把词条补进 en 桶、这里改回 lang 即可。
  let layout = layout-for("declarations", layout)
  let t = term-table("zh", "declarations", overrides: overrides)
  // 按学位挑词条：本科一套文字，硕博共用光键名那一套，见 src/config/axes.typ
  // 递全部的轴（用户自己起的档才在任何一根轴上都挑得到），这一页参数里给的学位与文种压过 info 的
  let variant = info-variant() + (degree-level: degree-level, form: form)
  let pick(name) = term-for(t, name, variant)
  // 「这份东西叫什么」——学位论文／实践成果／本科毕业论文（设计）。两个小标题
  // 与那句「本人知悉…」都是它加一截固定的话，词条收成了一条收槽的函数，
  // 见 src/engine/terms.typ 的 subject-of
  let subject = subject-of(t, variant)
  // 这一条是收槽的函数就把「这份东西叫什么」填进去，是内容就原样交回——
  // 判断住在 src/engine/terms.typ 的 term-apply
  let with-subject(name) = term-apply(t, name, variant, subject)
  // 步进是*量出来的版面数*，不是字面，所以不走词条那套档位后缀；本科与
  // 研究生两份，硕博同一份。*叫 series 不叫 form*——form 是轴名，这里说的
  // 是「照哪一份 docx 的段落序列排」，两回事
  let series = if degree-level == "bachelor" { "bachelor" } else { "graduate" }
  let graduate = series == "graduate"
  // *实践成果那一档只有研究生有*：本科毕业设计的 form 也是 practice（design 是它的
  // 别名），但本科指南只有一份声明（「本科毕业论文（设计）原创性声明和使用权限」），
  // 签名只有作者与导师，没有行业导师——那一行与为它让掉的空段都是研究生实践成果的
  // （《实践成果写作指南》附录 1）。先前光看 form，本科毕业设计多印了一行
  // 「行业导师签名：」、空段也按实践成果让了
  let practice = graduate and form == "practice"
  // 《》那一格：auto 取 info 的题目，空的就留空白
  let filled = if title != auto { title } else { info-get().title }
  // part.plain 对空内容给的是 none，不是空串——得先挡一道
  let plain = if filled == none { none } else { part.plain(filled) }
  // 题目留空就照 docx 敲 15 个空格，宽度由字体与网格自己算
  let slot = if plain == none or plain.trim() == "" { part.halfspace(15, layout) } else { filled }

  // *进目录，标题就是那个大标题。* 本科范例的目录第 6 页上正是
  // 「哈尔滨工业大学本科毕业论文原创性声明和使用权限」一条，不是拆成两条。
  term-chapter(
    "declarations", lang: lang, overrides: overrides,
    openright: openright, spread: spread,
    title: pick("title"),
  )

  // 一段一行，照 docx 的段落序列走。空段的段数与字号见上面那张表。
  //
  // *头一个小标题不发段前*——本科那 0.5 行由 term-chapter 排大标题时带上
  // 了（实测大标题末行到小标题 41.74；范例 40.50 是那一段走样式的 1.2），再发一次就多出
  // 整整半行。
  //
  // *空段只写字号与行距*：enter 的 font 默认就是 serif（空段没有汉字，按
  // ascii 槽走西文的 1.15），行距 w:line="300" auto ＝ 1.25 倍才是它默认值 1
  // 之外的那一处。
  // *小标题那 0.5 行是本科的*（范例段 515、522 的 beforeLines/afterLines=50），研究生那份
  // 「连那 0.5 行也没有，全靠空段」（见上面那张表）——先前两档都发，研究生的两个小标题
  // 各多出 9.75，博士范例整本对拍时量到（2026-09-16）
  let section = if graduate { styles.section + (above: 0pt, below: 0pt) } else { styles.section }
  let para(name, body) = paragraph(body, if name == "section" { section } else { styles.at(name) }, layout: layout)
  // 签名行：角色词从这一行自己的键取，「X签名：」由词条 signature 拼。
  // *日期那一列对齐*：原件把标签补到 14 个全角再接「日期：」——「作者签名：」后
  // 敲 18 个半角、「行业导师签名：」后 14 个（两份研究生指南附录 1 逐字数的），
  // 标签长短不同，日期落点一样。按标签的字数补
  let sign(who, style) = paragraph({
    let label = term-apply(t, "signature", (:), pick(who))
    label
    part.halfspace(28 - 2 * part.plain(label).clusters().len(), layout); t.date
    part.halfspace(5, layout); t.year
    part.halfspace(3, layout); t.month
    part.halfspace(3, layout); t.day
  }, styles.at(style), layout: layout)
  // 声明那一段两种写法都收：默认是「收题目、给整段」的函数，用户也可以直接给
  // 一整段内容——那就是不要《》那一格了。收槽与「给的是内容」两种情形由
  // src/engine/terms.typ 的 term-apply 一并管

  // if graduate { enter(1, size: "sanhao", line-spacing: 1.25) }   // 段 692，这段为了让最后一行不跨页，所以注释掉；Word 里是因为章标题段前间距被折叠了所以可以放下
  paragraph(with-subject("statement"), section + (above: 0pt), layout: layout)
  if graduate { enter(1, size: zihao.xiaosi, line-spacing: 1.25) }   // 段 694
  para("body", term-apply(t, "statement-text", (degree-level: degree-level, form: form), slot))
  enter(if graduate { 1 } else { 2 }, size: zihao.xiaosi, line-spacing: 1.25)  // 段 517,518 / 696
  sign("signer-author", "signature-first")
  // 段 520,521 / 698–700。
  //
  // *研究生这一档三个照排*：先前让掉一个（最后那行「导师签名：」差一点点排不下、整页
  // 流到第二页），是两个小标题各多发了 0.5 行挤的；那半行去掉后三个都放得下。
  //
  // *实践成果把三个让光*：那一档最后还多一行「行业导师签名：」，一个不够。
  // 让光了两节之间也不是贴着的——「使用权限」那个小标题的段前段后自带 0.5 行
  // （见上面 styles.section），空段让的是空段，不是那半行。
  //
  // *让空段是这一页仅有的旋钮*——字号、行距、缩进都是从 docx 量出来的，
  // 动一处就对不上范例了。先前为了让最后一行不跨页，已经把段 692 那个三号空段
  // 整个注释掉过（见上），是同一个办法。
  // 研究生那半行去掉之后省下 19.5，三个空段里让掉的那一个放得回来（页底 737 对版心底
  // 756.8）；实践成果那一档仍让光
  enter(
    if not graduate { 2 } else if practice { 0 } else { 3 },
    size: zihao.sihao, line-spacing: 1.25,
  )
  para("section", with-subject("authorization"))
  if graduate { enter(1, size: zihao.xiaosi, line-spacing: 1.25) }   // 段 702
  para("authorization-text-lead", pick("authorization-text-lead"))
  para("authorization-text-items", pick("authorization-text-items"))
  para("body", pick("authorization-text-secrecy"))
  para("body", with-subject("authorization-text-acknowledge"))
  // 段 527,528 / 707,708。实践成果那一档再让一个，理由同上——它比学位论文多
  // 一整行签名，一处让不出来
  enter(if practice { 1 } else { 2 }, size: zihao.xiaosi, line-spacing: 1.25)
  sign("signer-author", "signature")
  enter(1, size: zihao.xiaosi, line-spacing: 1.25)                   // 段 530 / 710
  sign("signer-supervisor", "signature")
  // 实践成果那一档在导师之下多一行「行业导师签名：」（《实践成果写作指南》
  // 附录 1）。*与导师那一行同款*——同一个空段、同一档签名样式
  if practice {
    enter(1, size: zihao.xiaosi, line-spacing: 1.25)
    sign("signer-industry-supervisor", "signature")
  }
}
