// 学位论文评阅人、答辩委员会名单及答辩决议。
//
// 新版研究生范例加的一页（「研究生学位论文书写范例-新增“学位论文评阅人、答辩
// 委员会名单及答辩决议”」），博士范例 p23 也有，排在成果之后、声明之前。规范正文
// 没有这一条，格式全部量自那两份件。本科没有；不按学位自动插，写了才有。
//
// *一张六列表，不是三张。* docx 里就是一个 w:tbl，三块靠合并单元格切出来：
//
//   评阅人块    左两列合并成标签「评阅人（根据实际人数填写）」，右四列
//               姓名 / 职称（是否博导）/ 工作单位 / 所在学科；表头一行 + 2 行
//   委员会块    最左一列竖排「答辩委员会成员」跨到底；第二列是职务：主席 1 行、
//               委员 6 行、秘书 1 行；表头一行
//   决议块      六列合一格，标签「答辩委员会决议（……）：」左对齐顶格
//
// 拆成三张表各画各的框，接缝处就是两道线，总高也多出几个线宽；hithesis 也是一张
// tblr 靠 SetCell 切的（hit-thesis-resolution.dtx）。
//
// *尺寸逐条量的*（博士范例 p23 的 PDF，与新增版 docx 对过）：
//
//   列宽    33.84 / 42.48 / 56.88 / 106.32 / 92.16 / 104.40，合计 436.08
//           ——比版心（424.7）宽 11.4：Word 的表按 jc=center 在*页上*居中，
//           单元格边距（0.19cm）撑到版心两侧各 5.7。hithesis 从 v3.1e 那张扫描
//           位图量到的六个数与此逐条相同（33.60/42.72/…）
//   行高    21.72（Word 属性写的是「最小 0.75cm」，实排 21.6 / 21.84 交替）——是
//           *下限*：格里的字折了行，那一行跟着长高，与纸质表一样（hithesis：
//           「内容顶不住时行仍会撑开」）
//   线      0.48，横竖一样（docx sz=4 = 0.5pt；hithesis 位图量的 0.72/0.48 不跟）
//   字      宋体、居中、紧排（格里不带网格字距，见下）；表头与各块标签
//           *加粗*（docx 的 run 写着 <w:b/>，
//           PDF 里字体名仍是 SimSun——Word 给宋体合成的粗是描边，与我们的伪粗
//           同一个做法，写 strong 就够）。
//
//           *字号按学科门类*：理工小四、人文五号。这一页的格里*没写
//           w:sz*，跟的是各自 Normal 的字号——d-stem.docx 的 Normal 是 24 半点
//           （小四），人文范例是 21（五号）。两份 PDF 实测正是 12.0 与 10.5。
//           *正文不受此影响*：两份的正文段都自己写了小四，只有这一页跟着
//           Normal 走
//   竖排    「答辩委员会成员」是 textDirection=tbRlV，PDF 里逐字一行。逐字步进
//           *跟字号走*：理工 12.50、人文 10.955，就是「字号 + 网格字距增量」
//           （人文那档 10.5 + 0.4543 = 10.954，分毫不差；理工 12.4543 对 12.50，
//           差 0.05）。先前存的是一个 12.66pt，两档都不对。
//           「委／员」的排法见 _label
//   决议格  Word 属性最小 5cm，范例实排 293.76（标签加 14 个空段，15 行 × 19.55，
//           表底 748.55 离版心底只剩 8）——与 hithesis 从位图量到的 293.76 一字不差；
//           取实排的那个数当最小高，正文长了跟着长
//
// *评阅人几行。* 新增版 docx 与 hithesis 都是 2 行，博士范例 PDF 印的是 3 行
// ——两份官方件不一致，跟最新的 docx。少了空着，与纸质表一样。
//
// *人比行数多，先借后加*——照 hithesis（hit-thesis-resolution.dtx 的
// \__hit_res_borrow:）：纸质表四块 2 / 1 / 6 / 1 一共十行，评阅人写三个就缺一行；
// 先看别块有没有空着的行——委员只填了四个，六行里空两行，就匀一行过来；四块
// 轮着来，一轮各让一行，让到够为止；全让完还不够，才把总行数加上去。这样能填进
// 纸质表的就不动总高，决议格也就不被挤。
//
// *学 eqdenote*：数据进，格式出。一人一条记录，四个键与 hithesis 的 defense
// 族同名（name / title / affiliation / discipline），缺的键那一格空着；什么都不给
// 就是一张空表，留着手填。
#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
#import "../info.typ": final-only-wanted, info-get
#import "../heading/heading.typ": term-chapter
#import "../terms/lookup.typ": subject-of, term-apply, term-table, term-for, info-variant
#import "../terms/lang.typ": resolve-lang
#import banshi.errors: once
#import banshi.layout as chars
#import banshi.styles as style-rules
#import banshi.layout: page-setup-state
#import banshi.msword: cm as msword-cm, has-cjk
// 正文那条 show table 把每张表当三线表重造（五号、三条线、续表头），见
// src/figure/caption.typ；格里注一个 _table.built-mark 它就放过——这张是表单，不是数据表
#import banshi.styles as _table

// 六列的宽，*按学科门类各一份，都读自各自 docx 的 tblGrid*（比从 PDF 上量准：
// PDF 那一层还带着描线的舍入）。两份的表不一样宽——理工 436.00 比版心（425.18）宽
// 10.8，靠单元格边距溢出、在*页*上居中（tblPr 写着 jc=center）；人文 424.70 正好
// 是版心宽，摆进去不溢出。缇除以 20 就是磅，写界面上的数
#let _columns-stem = (33.75pt, 42.55pt, 56.70pt, 106.30pt, 92.15pt, 104.55pt)
#let _columns-hass = (33.65pt, 41.75pt, 55.30pt, 103.40pt, 89.35pt, 101.25pt)
#let _columns-for(category) = if category == "hass" { _columns-hass } else { _columns-stem }
#let _row = 21.72pt
#let _rule = 0.48pt
// 格距。*不跟 Word 的 0.19cm，跟 hithesis 的 1pt*：「工作单位」那一列 92.16，
// 减两边 0.19cm 只剩 81.36，「哈尔滨工业大学」七个字紧排都要 84.32——最常见的单位
// 名在 Word 的边距下就得折行。hithesis 把格距收到 1pt（那一列留给字 87.46），七个字
// 排得进，八个字折；「职称（是否博导）」那列放得下八个。纸质表本来就是紧排的。
// 竖线画在格边界上，1pt 之外我们不再另减半道线
#let _inset = 1pt
// 决议框的左右内边距*跟 Word 的 0.19cm*，不跟表格那 1pt——那 1pt 是为了让
// 「哈尔滨工业大学」七个字排进 92.16 的格子（见上），决议框没有这个约束，照范例：
// 标签左缘理工 85.03、人文 90.72，各自离框左 5.50 与 5.52
#let _box-inset = msword-cm(0.19)
// 决议框上下各留的余地。*是零*——范例的表没写 tblCellMar，用的是 styles.xml 里
// docDefaults 那一份：上下 0、左右各 0.19 厘米（横向那一份见 _box-inset）。先前跟 hithesis
// 写了 2pt，标签的基线因此比范例低了正好 2（实测 16.17 对 14.25）
#let _pad = 0pt
// 纸质表各块的行数
#let _rows = (reviewers: 2, chair: 1, members: 6, secretary: 1)
// 借行时各块的下限：评阅人那两行是纸质表的门面，不借；别的块至少留一行放标签。
// hithesis 的条件是「行数 > 人数」，只填一个评阅人时会把第二行借走，主席一个不填时
// 连主席那行也借走，标签跟着没了——纸质表上那些行总在
#let _floors = (reviewers: 2, chair: 1, members: 1, secretary: 1)
#let _fields = ("name", "title", "affiliation", "discipline")

// 一条记录 → 四格；none 是空行
#let _cells(record) = _fields.map(k => if record == none { [] } else { record.at(k, default: []) })
// 收一条或一串记录
#let _list(value) = if value == none { () } else if type(value) == dictionary { (value,) } else { value }
// 补到 n 行
#let _padded(list, n) = list + range(calc.max(0, n - list.len())).map(_ => none)
// 四块各排几行：先借后加，见文件头。counts 是四块的人数，forms 是纸质表的行数，
// floors 是借行的下限
#let _row-counts(counts, forms, floors) = {
  let rows = counts.zip(forms).map(((c, f)) => calc.max(c, f))
  let need = counts.zip(forms).map(((c, f)) => calc.max(0, c - f)).sum()
  let moved = true
  while moved and need > 0 {
    moved = false
    for i in range(rows.len()) {
      if need > 0 and rows.at(i) > calc.max(counts.at(i), floors.at(i)) {
        rows.at(i) -= 1
        need -= 1
        moved = true
      }
    }
  }
  rows
}
// 竖排的标签——照 hithesis（hit-thesis-resolution.dtx「竖排还是横排」）：
//
//   横还是竖    按格子高度定：一摞排不下就横过来连成一行。「委员」那一块被别块
//               借到只剩一行时横排，行数上去了自然变成竖排
//   两个字      *排成真正的行流*：委、若干空行、员，整块在格里居中。Word 里
//               那一格就是五个段落——空、空、委、空、员（两份范例的 docx 逐字相同），
//               所以步进恒是*正文行距的整数倍*：实测理工 39.02 ＝ 2 × 19.51、
//               人文 39.12 ＝ 2 × 19.56，与格里的字号无关（小四／五号两档同）。
//               先前是算一个连续的步进、封顶 1.8 倍行高，六行时碰巧折在 39.10；
//               换成行流之后数是从行距里来的，行数一变自然跟着走
//   多字贴着排  逐字步进 ＝ 字号 + 网格字距增量（ccwd）：人文 10.5 + 0.4543 = 10.954
//               对实测 10.955，理工 12.4543 对 12.50。整摞居中
//
// 每个字装进定高的盒子叠起来——行盒的高度由字体的上下沿定，靠 leading 凑不出
// 这些数。西文没法逐字拆，转 90 度。rows 是这一格跨的行数，line 是正文行距
// （hithesis 的 baselineskip），「排不排得下」按每字一个行距算。
#let _plain(label) = if type(label) == str { label } else if label.has("text") { label.text } else { none }

// 两个字之间空几行。
//
// *先长两头，再长中间。* 格子高出来的地方，先给「委」之前与「员」之后（那由
// 居中自然摊开，连续、不必取整），中间这个数慢一拍再加——反过来的话三行的格子就
// 把两个字顶到上下两端、中间空一行，读着不像一个词。
//
// 比例照范例与用户定的四档反推：(两头, 中间) 依次是 (2,1) (3,1) (3,2) (4,2)，两头
// 大约是中间的两倍，所以中间 ＝ round((可用行数 − 2) / 5)。逐档核过：六行（范例
// 那一格）得 1，七行 1、九行 1、十行 2、十二行 2，与四档逐个对上。
//
// *封顶两行*（两字相距三个行距 ＝ 58.65）：再远就不像一个词了
#let _gap-max = 2
#let _gap(lines) = int(calc.min(calc.max(0, calc.round((lines - 2) / 5)), _gap-max))

// pitch 是竖排一格的高（字号 + 网格字距增量），*由调用方算好传进来*——写成
// chars.ccwd(1) 的话那个 1em 要在盒子里按周围的字号解析，罩了一层 style-rules.rules 之后
// 就被带偏了（实测人文那一摞的步进从 10.960 跳到 11.342）
#let _label(label, rows, line, pitch) = {
  let s = _plain(label)
  // 西文没法逐字拆，整条转 90°。*向右转（顺时针）*——Word 的竖排格
  // （textDirection=tbRlV）就是把西文向右转，读的时候头往右偏；Typst 的 rotate 正角
  // 顺时针，所以是 +90deg。先前写的 -90deg 是向左转，转反了。
  //
  // *也要自己居中*：三支竖排标签是一回事，格子顶对齐（照 Word 的 vAlign），
  // 摆中间是标签自己的事。先前只有汉字那两支写了居中，这一支漏了——表格还是
  // horizon 的时候看不出来，改成 top 之后「Defense Committee」缩在合并格最上沿，
  // 底下空了一百多磅
  if s == none or not has-cjk(s) {
    return align(center + horizon, rotate(90deg, reflow: true, strong(label)))
  }
  let chars = s.clusters()
  let n = chars.len()
  let cell = rows * _row + (rows - 1) * _rule
  if n < 2 or n * line > cell { return strong(label) }
  if n > 2 {
    // 多字：逐字贴着排，步进就是一格的宽（字号 + 网格字距增量）
    return align(center + horizon, stack(dir: ttb, ..chars.map(c => box(height: pitch, align(center + horizon, strong(c))))))
  }
  // 两个字：委、空行、员，每一行一个正文行距；空几行按格高定，排不下就减
  let lines = calc.floor(cell / line)
  let gap = _gap(lines)
  let gap = {
    let g = gap
    while g > 0 and (g + 2) * line > cell { g -= 1 }
    g
  }
  // *竖排的那一摞自己居中*：表格是顶对齐的（照 Word 的 vAlign），只有这一摞
  // 要在合并格里居中——那是这一页唯一一处 Word 也在视觉上摆中间的东西
  align(center + horizon, stack(
    dir: ttb,
    ..range(gap + 2).map(i => box(
      height: line,
      align(center + horizon, if i == 0 { strong(chars.first()) }
        else if i == gap + 1 { strong(chars.last()) }),
    )),
  ))
}

#let defense(
  // 评阅人：一条记录（字典）或一串
  reviewers: (),
  // 答辩委员会：主席、委员、秘书
  chair: none,
  members: (),
  secretary: none,
  // 决议正文。none 就只有标签，格子留着手填
  resolution: none,
  lang: auto,
  overrides: (:),
  openright: auto,
  // 交上去的是哪一种东西，见 src/axes.typ 的 form。practice 那一档换的是
  // 章标题与决议那一格的标签。*auto ＝ 取 info 那一份*——这一页没有包装层
  // （lib.typ 直接导出它），所以自己去拿
  form: auto,
  // 两字标题空不空一个字。auto 跟文档级 two-hanzi，与同族各页一致
  title: auto, two-hanzi: auto,
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }
  // 只该印一次的页，见 banshi/src/errors.typ
  once("defense")

  let this-lang = resolve-lang(lang)
  let l = this-lang
  let t = term-table(l, "defense", overrides: overrides)
  let form = if form == auto { info-get().form } else { form }
  let variant = info-variant() + (form: form)
  let pick(name) = term-for(t, name, variant)
  // 章标题是「这份东西叫什么」＋一截固定的话，词条收成了收槽的函数，见
  // src/terms/lookup.typ 的 subject-of。*这一页只有硕博*，所以 degree-level 不递。
  //
  // *英文目录那一条要自己算好递进去。* term-chapter 的 toc-name 默认是
  // 「取英文桶的 title」——而那一条现在也是收槽的函数，直接拿去拼会崩在
  // 「cannot join function with content」上。这正是 toc-name 那个口子的用途：
  // 按档分的标题由调用方挑好了传（成果那一章同款）。
  let titled(l) = {
    let tt = if l == this-lang { t } else { term-table(l, "defense", overrides: overrides) }
    term-apply(tt, "title", variant, subject-of(tt, variant))
  }
  term-chapter(
    "defense", lang: lang,
    title: if title == auto { titled(l) } else { title },
    toc-name: titled("en"),
    two-hanzi: two-hanzi,
    overrides: overrides, openright: openright,
  )

  // *格里的字号按学科门类*：理工小四、人文五号，见抬头。这一处要罩住底下所有的
  // measure——行高是量出来的，量的时候字号得与排的时候一样。
  //
  // *行落在网格上，单倍行距*——Word 这一页就是默认的 snapToGrid 加单倍行距，
  // 所以每一行恒占一个网格行（19.55），与字号无关：人文范例那一格 16 个空段正好
  // 312.80 ＝ 16 × 19.55。基线也跟着定：网格开时自然行盒在网格行里居中（见
  // banshi/src/paragraph/linebox.typ 的 _ascent-of），算出来小四 14.17、五号 13.63，对上范例的
  // 14.25 与 13.52（差 0.1）。
  //
  // *先前只 set 了字号*，行盒跟着字号缩——决议正文实测理工 19.45、人文 17.02，
  // 格内基线也比范例高 0.5～0.9。一度改成 (exactly: 19.55)，行距对了但基线落在
  // 0.8 倍盒高处（15.64），比范例低 1.4——那一档是给报告首页那种硬指定的用的
  let columns = _columns-for(info-get().category)
  let cell-style = (
    font-zh: "songti",
    size: if info-get().category == "hass" { zihao.wuhao } else { zihao.xiaosi },
    line-spacing: 1.0,
    snap-to-docgrid: true,
  )
  show: style-rules.rules.with(cell-style, layout: page-setup-state.get(), set-font: true)
  // 三线表那一档给所有 table 的字号 show-set（lib.typ，五号）在这一页也生效，而且比上面那句
  // 更内层——这张是表单不是数据表，字号再钉回来
  show table: set text(size: cell-style.size)

  let lists = (_list(reviewers), _list(chair), _list(members), _list(secretary))
  let counts = _row-counts(
    lists.map(l => l.len()),
    (_rows.reviewers, _rows.chair, _rows.members, _rows.secretary),
    (_floors.reviewers, _floors.chair, _floors.members, _floors.secretary),
  )
  let head(x) = strong(x)
  let line = page-setup-state.get().docgrid.line-pitch
  // 竖排一格的高：格里的字号 + 网格字距增量，一次算好传给 _label
  let glyph = cell-style.size + page-setup-state.get().docgrid.tracking

  // *格里的字紧排*——hithesis：「xeCJK 的 \CJKglue 在正文里撑开汉字之间的
  // 空隙好让整行对齐，表格里却不该有……纸质表也是紧排的」。我们那份胶是网格字距
  // （每字 +0.4543，见 banshi/src/layout/chars.typ），格里归零；决议正文不动，那一段要靠它对齐。
  // 首行缩进也关掉：正文那条缩进规则罩得到格里。
  let tight(c) = {
    set text(tracking: 0pt)
    // 格里折了行的字不两端对齐：英文表头「Title (Doctoral Supervisor?)」折两行，
    // 两端对齐把第一行拉成「Title       (Doctoral」；Word 的格是居中的
    set par(first-line-indent: 0pt, justify: false)
    c
  }
  // *行高逐行算*：21.72 是下限，四格里最高的那格折了行就按它长。量的时候
  // 用格里同一套紧排，不然量出来多一行
  let natural(content, col) = measure(block(
    width: columns.at(col) - 2 * _inset,
    tight(content),
  )).height
  let row-of(record) = calc.max(
    _row,
    .._cells(record).enumerate().map(((i, c)) => natural(c, i + 2)),
  )
  // *表头两行也按内容量*：中文表头一行装得下，英文的「Title (Doctoral
  // Supervisor?)」在 56.88 的格里折两行，按 21.72 排就冲出格子压到上一行
  let header-row(items) = calc.max(_row, ..items.map(((c, col)) => natural(head(c), col)))
  let head-revs = header-row((
    (t.column-name, 2), (t.column-title, 3), (t.column-affiliation, 4), (t.column-discipline, 5),
  ))
  let head-comm = header-row((
    (t.column-role, 1), (t.column-name, 2), (t.column-title, 3),
    (t.column-affiliation, 4), (t.column-discipline, 5),
  ))
  // *竖排的西文标签比它跨的那几行还长，就给这一块多一行空栏*——「Secretary」
  // 转过来将近 50，秘书那块纸质表上只有一行，装不下。
  //
  // *先匀后添*，跟各块定行数那一步（_row-counts）同一个路子：别块有多余的空行
  // 就匀一行过来（纸质表的总行数不变，样子也不变），匀不到才添一行。英文档实测：
  // 委员那块六行填了三个，匀一行给秘书，秘书成了「一个人 + 一行空栏」。
  //
  // 先前是把这一块的每一行按差额撑高（Word 里竖排格的行确实会随字长高），秘书那行
  // 就单独比别的行高出一截，横线不齐——纸质表上一行就是一行。
  //
  // 汉字标签不走这条：装不下时 _label 自己横过来排成一行
  let label-need(label) = {
    let s = _plain(label)
    if s == none or has-cjk(s) { 0pt } else { measure(strong(label)).width + 2 * _inset }
  }
  let needs = (0pt, label-need(t.chair), label-need(t.member), label-need(t.secretary))
  let block-height(i, n) = {
    let hs = _padded(lists.at(i), n).map(row-of)
    hs.sum() + (hs.len() - 1) * _rule
  }
  let counts = {
    let n = counts
    let floors = (_floors.reviewers, _floors.chair, _floors.members, _floors.secretary)
    // 匀得出一行的：这一块除了人数与下限之外还有空行，*且匀走之后自己的标签
    // 还装得下*——不加后半句，两块就会来回匀，停不下来
    let spare(j) = (
      n.at(j) > calc.max(lists.at(j).len(), floors.at(j))
        and block-height(j, n.at(j) - 1) >= needs.at(j)
    )
    let moved = true
    while moved {
      moved = false
      for i in range(n.len()) {
        if block-height(i, n.at(i)) >= needs.at(i) { continue }
        let donor = range(n.len()).find(j => j != i and spare(j))
        if donor != none { n.at(donor) -= 1 }
        n.at(i) += 1
        moved = true
      }
    }
    n
  }
  let (revs, chairs, mems, secs) = lists.zip(counts).map(((l, n)) => _padded(l, n))
  let rows = (
    (head-revs,) + revs.map(row-of) +
    (head-comm,) + chairs.map(row-of) + mems.map(row-of) + secs.map(row-of)
  )

  // *换页逻辑学 hithesis。* 名单是表，Typst 的表在行与行之间断页；决议区
  // 是一格连续的正文，一格切不开页——所以决议区不做成表格的最后一行，而是表
  // 底下一个可跨页的框（hithesis 用 tcolorbox 自己 \vsplit，我们用 breakable 的
  // block）。接缝处只画一道线：秘书那行的底线去掉，框的顶线就是它；续页的每一
  // 段框自带四条边，与 hithesis「续页那几个框自己把顶线补上」同一个样子。
  //
  // 框的高度只有一条规矩：*吃掉本页剩下的地方；装不下才顺着断页*。
  //
  // 范例正是这个样子——表底下那一格是标签加 14 个空段，框底 748.55 离版心底只剩 8，
  // 也就是「把这一页剩下的都占了」；那个 293.76 只是它*恰好*剩这么多，不是一个
  // 该存起来的数。先前把它当成了定高（没写决议时硬撑到它、写了决议时当下限），两头
  // 都出过事：表一长，空框被挤破，多出一页只剩空框和页眉；写了短决议时更早一步顶出去
  // ——实测两个评阅人、八个主席、九个委员那一份，第二页上多出一小截。
  //
  // 框高 ＝ *从框顶起数得下的整数行*。Word 里那一格就是标签加若干空段，作者
  // 敲到这一页放不下为止，所以框底恒落在行格上——而且是*框自己的行格*，不是
  // 整页的：表按 21.72 一行排，框顶早就不在正文的行格上了。
  //
  // 两份范例都这么算得出来：
  //
  //   理工  框顶 454.22，到版心底 302.62，放得下 15 行 ＝ 293.25 → 框底 747.47，
  //         实测 747.98（差 0.5；那一格正是标签加 14 个空段）
  //   人文  框顶 413.20，可用 343.64 放得下 17 行，作者只敲了 16 行 ＝ 312.80
  //         → 框底 726.00。少敲的那一行是他的事，不是规则
  //
  // 所以取「放得下几行就几行」：理工分毫不差，人文差一行。*先前是拿整页的行格
  // 算*（上边距 + 33 × 行距 ＝ 752.90），那个数与这一页无关——表不落在正文行格上。
  //
  // 框顶要*问位置*：here().position()。这一处不进布局回路——框自己的高度不影响
  // 它自己的起点（它底下没有别的东西），所以读得稳。
  let width = columns.sum()
  let body = {
    set par(first-line-indent: 0pt)
    head(pick("resolution"))
    if resolution != none {
      set par(first-line-indent: (amount: chars.ccwd(2), all: true))
      resolution
    }
  }
  let natural = measure(block(width: width - 2 * _inset, body)).height + 2 * _pad
  let resolution-box = context {
    let lay = page-setup-state.get()
    let line-pitch = lay.docgrid.line-pitch
    let page-bottom = lay.paper-height - lay.margin.bottom
    let top = here().position().y
    // 放得下几行（框内上下各留 _pad），框高就是那么多行
    let rows-in-box = calc.floor((page-bottom - top - 2 * _pad) / line-pitch)
    let remain = rows-in-box * line-pitch + 2 * _pad
    // 装得下就填到正文最后一行的底、不切开；装不下才让正文定高、顺着断页。
    //
    // *高只能写 1fr，不能写量出来的那个数*——写绝对量时整块会被挪到下一页，
    // 哪怕比剩余空间小 8pt 也一样（实测 y=431.55、剩 325.29，给 321.35 到 313.35 都
    // 被挪走；1fr 却填得满满当当）。所以填满交给 1fr，再用 pad 把「区域底到正文
    // 末行底」那一截垫掉——版心下边界 756.84，正文末行底 752.90，差 3.94
    let fits = natural <= remain
    let filled = block(
      width: width,
      height: 1fr,
      breakable: false,
      above: 0pt, below: 0pt,
      stroke: _rule + black,
      inset: (x: _box-inset, y: _pad),
      body,
    )
    if fits {
      // 高只能写 1fr（见上），所以把「框底到版心下边界」那一截用 pad 垫掉
      pad(bottom: page-bottom - top - remain, filled)
    } else {
      block(
        width: width,
        breakable: true,
        above: 0pt, below: 0pt,
        stroke: _rule + black,
        inset: (x: _box-inset, y: _pad),
        body,
      )
    }
  }
  // 最末一行（秘书）的底线不画，接缝处只留框的顶线
  let last(c) = table.cell(stroke: (bottom: none), c)

  // 「+」要写在行尾：行首的 + 是一元加，两行就断成两个表达式
  let cells = (
    (
      table.cell(colspan: 2, rowspan: 1 + revs.len(), _table.built-mark + head(t.reviewers)),
      head(t.column-name), head(t.column-title), head(t.column-affiliation), head(t.column-discipline),
    ) +
    revs.map(_cells).flatten() +
    (
      table.cell(
        rowspan: 1 + chairs.len() + mems.len() + secs.len(), stroke: (bottom: none),
        _label(t.committee, 1 + chairs.len() + mems.len() + secs.len(), line, glyph),
      ),
      head(t.column-role), head(t.column-name), head(t.column-title),
      head(t.column-affiliation), head(t.column-discipline),
      // 三个角色标签都走 _label：单行横排，跨行了就竖排摊开——「委员」如此，
      // 主席、秘书有两个人时也如此。hithesis 只给 委\\员 写了分行，主席跨两行
      // 仍横排；这条逻辑本就是公用的，没理由只给一个用
      table.cell(rowspan: chairs.len(), _label(t.chair, chairs.len(), line, glyph)),
    ) +
    chairs.map(_cells).flatten() +
    (table.cell(rowspan: mems.len(), _label(t.member, mems.len(), line, glyph)),) +
    mems.map(_cells).flatten() +
    // 秘书标签也要跨这一块的行数——先前没跨，第二个秘书起四格全往左错一列，
    // 名字落进「职务」栏
    (table.cell(rowspan: secs.len(), stroke: (bottom: none), _label(t.secretary, secs.len(), line, glyph)),) +
    secs.slice(0, -1).map(_cells).flatten() +
    _cells(secs.last()).map(last)
  )

  // 表比版心宽 11.4，在页上居中：两侧各让出一个单元格边距。
  //
  // *外面套一层 above: 0pt 的 block*：不套的话表顶落在 191.93，范例 172.07，
  // 差的正是一个行距 19.55——章标题的段后距之外又叠了一份段距。
  block(above: 0pt, below: 0pt, pad(x: -(width - page-setup-state.get().text-width) / 2, {
    set block(above: 0pt, below: 0pt)
    show table: tight
    table(
      columns: columns,
      rows: rows,
      stroke: _rule + black,
      inset: (x: _inset, y: 0pt),
      // *格里顶对齐*——Word 的 vAlign 默认就是 top，范例单行格的基线正是
      // 「行顶 + 上升部」（理工 14.25、人文 13.52，我们算出 14.17 / 13.63）。先前写的是
      // horizon，多出半截居中的空当，基线低了 1.1；竖排的标签另外自己居中，见 _label
      align: center + top,
      ..cells,
    )
    resolution-box
  }))
}
