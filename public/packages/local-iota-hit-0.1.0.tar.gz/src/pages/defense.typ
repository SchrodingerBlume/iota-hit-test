#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: amount
#import banshi.fonts: zihao
#import "../info.typ": final-only-wanted, info-get
#import "../heading/heading.typ": term-chapter
#import "../terms/lookup.typ": subject-of, term-apply, term-table, term-for, info-variant
#import "../terms/lang.typ": resolve-lang
#import "../once.typ": once
#import banshi.layout: chars
#import banshi.styles as style-rules
#import banshi.layout: page-setup-state
#import banshi.units: twips
#import banshi.runs: has-cjk
#import banshi.styles as _table
#let _columns-stem = (33.75pt, 42.55pt, 56.70pt, 106.30pt, 92.15pt, 104.55pt)
#let _columns-hass = (33.65pt, 41.75pt, 55.30pt, 103.40pt, 89.35pt, 101.25pt)
#let _columns-for(category) = if category == "hass" { _columns-hass } else { _columns-stem }
#let _row = 21.72pt
#let _rule = 0.48pt
#let _inset = 1pt
#let _box-inset = twips(0.19cm)
#let _pad = 0pt
#let _rows = (reviewers: 2, chair: 1, members: 6, secretary: 1)
#let _floors = (reviewers: 2, chair: 1, members: 1, secretary: 1)
#let _fields = ("name", "title", "affiliation", "discipline")
#let _cells(record) = _fields.map(k => if record == none { [] } else { record.at(k, default: []) })
#let _list(value) = if value == none { () } else if type(value) == dictionary { (value,) } else { value }
#let _padded(list, n) = list + range(calc.max(0, n - list.len())).map(_ => none)
#let _row-counts(counts, forms, floors) = {
  let rows = counts.zip(forms).map(((c, f)) => calc.max(c, f))
  let need = counts.zip(forms).map(((c, f)) => calc.max(0, c - f)).sum()
  let moved = true
  while moved and need > 0 {
    moved = false
    for i in range(rows.len()) {
      if need > 0 and rows.at(i) > calc.max(counts.at(i), floors.at(i)) {
        rows.at(i) -= 1
        need -= 1
        moved = true
      }
    }
  }
  rows
}
#let _plain(label) = if type(label) == str { label } else if label.has("text") { label.text } else { none }
#let _gap-max = 2
#let _gap(lines) = int(calc.min(calc.max(0, calc.round((lines - 2) / 5)), _gap-max))
#let _label(label, rows, line, pitch) = {
  let s = _plain(label)
  if s == none or not has-cjk(s) {
// Word 的 tbRlV 顺时针旋转；Typst 对应正角度。
    return align(center + horizon, rotate(90deg, reflow: true, strong(label)))
  }
  let chars = s.clusters()
  let n = chars.len()
  let cell = rows * _row + (rows - 1) * _rule
  if n < 2 or n * line > cell { return strong(label) }
  if n > 2 {
    return align(center + horizon, stack(dir: ttb, ..chars.map(c => box(height: pitch, align(center + horizon, strong(c))))))
  }
  let lines = calc.floor(cell / line)
  let gap = _gap(lines)
  let gap = {
    let g = gap
    while g > 0 and (g + 2) * line > cell { g -= 1 }
    g
  }
  align(center + horizon, stack(
    dir: ttb,
    ..range(gap + 2).map(i => box(
      height: line,
      align(center + horizon, if i == 0 { strong(chars.first()) }
        else if i == gap + 1 { strong(chars.last()) }),
    )),
  ))
}

#let defense(
  reviewers: (),
  chair: none,
  members: (),
  secretary: none,
  resolution: none,
  lang: auto,
  overrides: (:),
  openright: auto,
  form: auto,
  title: auto, two-hanzi: auto,
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }
  once("defense")

  let this-lang = resolve-lang(lang)
  let l = this-lang
  let t = term-table(l, "defense", overrides: overrides)
  let form = if form == auto { info-get().form } else { form }
  let variant = info-variant() + (form: form)
  let pick(name) = term-for(t, name, variant)
  let titled(l) = {
    let tt = if l == this-lang { t } else { term-table(l, "defense", overrides: overrides) }
    term-apply(tt, "title", variant, subject-of(tt, variant))
  }
  term-chapter(
    "defense", lang: lang,
    title: if title == auto { titled(l) } else { title },
    toc-name: titled("en"),
    two-hanzi: two-hanzi,
    overrides: overrides, openright: openright,
  )
  let columns = _columns-for(info-get().category)
  let cell-style = (
    asian-font: "songti",
    size: if info-get().category == "hass" { zihao.wuhao } else { zihao.xiaosi },
    line-spacing: 1.0,
    snap-to-grid: true,
  )
  show: style-rules.rules.with(cell-style, layout: page-setup-state.get(), set-font: true)
  show table: set text(size: cell-style.size)

  let lists = (_list(reviewers), _list(chair), _list(members), _list(secretary))
  let counts = _row-counts(
    lists.map(l => l.len()),
    (_rows.reviewers, _rows.chair, _rows.members, _rows.secretary),
    (_floors.reviewers, _floors.chair, _floors.members, _floors.secretary),
  )
  let head(x) = strong(x)
  let line = page-setup-state.get().docgrid.line-pitch
  let glyph = cell-style.size + page-setup-state.get().docgrid.tracking
  let tight(c) = {
    set text(tracking: 0pt)
    set par(first-line-indent: 0pt, justify: false)
    c
  }
  let natural(content, col) = measure(block(
    width: columns.at(col) - 2 * _inset,
    tight(content),
  )).height
  let row-of(record) = calc.max(
    _row,
    .._cells(record).enumerate().map(((i, c)) => natural(c, i + 2)),
  )
  let header-row(items) = calc.max(_row, ..items.map(((c, col)) => natural(head(c), col)))
  let head-revs = header-row((
    (t.column-name, 2), (t.column-title, 3), (t.column-affiliation, 4), (t.column-discipline, 5),
  ))
  let head-comm = header-row((
    (t.column-role, 1), (t.column-name, 2), (t.column-title, 3),
    (t.column-affiliation, 4), (t.column-discipline, 5),
  ))
  let label-need(label) = {
    let s = _plain(label)
    if s == none or has-cjk(s) { 0pt } else { measure(strong(label)).width + 2 * _inset }
  }
  let needs = (0pt, label-need(t.chair), label-need(t.member), label-need(t.secretary))
  let block-height(i, n) = {
    let hs = _padded(lists.at(i), n).map(row-of)
    hs.sum() + (hs.len() - 1) * _rule
  }
  let counts = {
    let n = counts
    let floors = (_floors.reviewers, _floors.chair, _floors.members, _floors.secretary)
    let spare(j) = (
      n.at(j) > calc.max(lists.at(j).len(), floors.at(j))
        and block-height(j, n.at(j) - 1) >= needs.at(j)
    )
    let moved = true
    while moved {
      moved = false
      for i in range(n.len()) {
        if block-height(i, n.at(i)) >= needs.at(i) { continue }
        let donor = range(n.len()).find(j => j != i and spare(j))
        if donor != none { n.at(donor) -= 1 }
        n.at(i) += 1
        moved = true
      }
    }
    n
  }
  let (revs, chairs, mems, secs) = lists.zip(counts).map(((l, n)) => _padded(l, n))
  let rows = (
    (head-revs,) + revs.map(row-of) +
    (head-comm,) + chairs.map(row-of) + mems.map(row-of) + secs.map(row-of)
  )
  let width = columns.sum()
  let body = {
    set par(first-line-indent: 0pt)
    head(pick("resolution"))
    if resolution != none {
      set par(first-line-indent: (amount: chars(2), all: true))
      resolution
    }
  }
  let natural = measure(block(width: width - 2 * _inset, body)).height + 2 * _pad
  let resolution-box = context {
    let lay = page-setup-state.get()
    let line-pitch = lay.docgrid.line-pitch
    let page-bottom = lay.paper-height - lay.margin.bottom
    let top = here().position().y
    let rows-in-box = calc.floor((page-bottom - top - 2 * _pad) / line-pitch)
    let remain = rows-in-box * line-pitch + 2 * _pad
    let fits = natural <= remain
    let filled = block(
      width: width,
      height: 1fr,
      breakable: false,
      above: 0pt, below: 0pt,
      stroke: _rule + black,
      inset: (x: _box-inset, y: _pad),
      body,
    )
    if fits {
      pad(bottom: page-bottom - top - remain, filled)
    } else {
      block(
        width: width,
        breakable: true,
        above: 0pt, below: 0pt,
        stroke: _rule + black,
        inset: (x: _box-inset, y: _pad),
        body,
      )
    }
  }
  let last(c) = table.cell(stroke: (bottom: none), c)
  let cells = (
    (
      table.cell(colspan: 2, rowspan: 1 + revs.len(), _table.verbatim-mark + head(t.reviewers)),
      head(t.column-name), head(t.column-title), head(t.column-affiliation), head(t.column-discipline),
    ) +
    revs.map(_cells).flatten() +
    (
      table.cell(
        rowspan: 1 + chairs.len() + mems.len() + secs.len(), stroke: (bottom: none),
        _label(t.committee, 1 + chairs.len() + mems.len() + secs.len(), line, glyph),
      ),
      head(t.column-role), head(t.column-name), head(t.column-title),
      head(t.column-affiliation), head(t.column-discipline),
      table.cell(rowspan: chairs.len(), _label(t.chair, chairs.len(), line, glyph)),
    ) +
    chairs.map(_cells).flatten() +
    (table.cell(rowspan: mems.len(), _label(t.member, mems.len(), line, glyph)),) +
    mems.map(_cells).flatten() +
    (table.cell(rowspan: secs.len(), stroke: (bottom: none), _label(t.secretary, secs.len(), line, glyph)),) +
    secs.slice(0, -1).map(_cells).flatten() +
    _cells(secs.last()).map(last)
  )
  block(above: 0pt, below: 0pt, pad(x: -(width - page-setup-state.get().text-width) / 2, {
    set block(above: 0pt, below: 0pt)
    show table: tight
    table(
      columns: columns,
      rows: rows,
      stroke: _rule + black,
      inset: (x: _inset, y: 0pt),
      align: center + top,
      ..cells,
    )
    resolution-box
  }))
}
