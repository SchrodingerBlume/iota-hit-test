// 前置页的入口：封面、内封、摘要、目录与图表公式索引的*公开*函数。lib.typ 只 re-export
// 并配文档，用户看到的签名就是这里的签名。pages/ 的规矩是一页一个文件，这一个不是页，是那
// 几页共用的一层壳——按 stage 派（论文封面 / 报告首页）、按学位定出几份目录都在这儿。
//
// 这一层只做一件事：*把 info 里的元信息填给部件*。部件本身仍然只认显式
// 参数——那是对拍件直接调的那一档，一行不用改；用户调的是这里的同名函数，
// 题目姓名只写一遍。
//
// 用户在调用处写的参数照样压过 info：两份字典相加，后者赢。
//
// *为什么不把 state 读进部件里。* 部件要在函数体一开头就用到题目
// （封面那个求解器要量题目的高），读 state 就得把整个函数体圈进 context，
// 而部件里还发着 set page——虽然实测 context 里发 set page 是好使的，但那样
// 每个部件都得改一遍，且对拍件也跟着进 context。放在外面一层最省。

#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": final-only-wanted, info-get, value-of
#import "../once.typ": once
#import "../terms/lookup.typ": term-table, variant-of
#import "../layout/matter.typ": frontmatter-openright, cover-exit-odd, cover-exit, clear-page, frontmatter, mainmatter, backmatter, appendix
#import "../settings/resolve.typ": resolve-openright
#import banshi.layout: page-setup as msword-layout
#import "../layout/parts.typ": layout-for
#import banshi.styles: new-styles
#import "../terms/lang.typ": normalize as normalize-lang, doc-lang
#import "./cover.typ" as _cover
#import "./titlepage.typ" as _titlepage
#import "./abstract.typ" as _abstract
#import "./outline.typ" as _toc
#import "./lists.typ" as _lists
#import "./report/cover.typ" as _report
#import "./report/shenzhen/cover.typ" as _report-shenzhen
#import "../layout/presets.typ": report-toc-headerless as _toc-headerless
#import "../axes.typ": campus-for

// *目录页排不排页眉，逐份不同*，见 src/layout/presets.typ 的
// report-toc-headerless。
//
// *走 set page，不走版面的差额*：页眉页脚是一节的 set 发的（见
// banshi/src/layout/section.typ），部件那一层的版面差额改不到它。裹在一个块里，只管
// 目录这几页——目录本来就另起一页，后面的部件也各自另起
#let _toc-headerless-page(info, body) = {
  let bare = info.stage in _toc-headerless
    .at(campus-for(info.campus, info.degree-level), default: (:))
    .at(info.degree-level, default: ())
  // *set 要与 body 同在一个块里*：写成 if bare { set … } 的话那条 set 只管
  // 那个空块，body 在块外照旧带页眉（实测目录页的页眉一个字没少）
  if bare {
    set page(header: none)
    body
  } else { body }
}

// 中文封面。
// *参数逐个列出来，不用 ..args。* 先前是个沉没参数，转发的其实就是下面这几个
// ——列得出来，不是无限集；而沉没参数把 LSP 的补全吃掉了，用户得翻源码才知道能写
// 什么。auto 一律表示「取 #info 存的那一份」。
// 报告那两档的首页与论文封面毫不相干，走 src/pages/report/cover.typ；
// *用户 API 不变*——第一页就是第一页，不该为报告另发明一个函数名
#import "../axes.typ": report-stages as _report-stages


// 页面的版面：文档＋段那一份（page-setup-state）并上部件差额，再并用户在这一页写的
// 局部字典；整份就整份替换。梯子的五层见 banshi/src/layout/resolve.typ 的 layout-for。
// 这一层本来就在 context 里，读得到 state；封面内封在 context 外面发 set page，
// 所以由这儿填好再传下去。

#let cover(
  // 印在封面上的*题目*。auto 取 info 的 title。
  // 目录、参考文献那些部件的 title 是「这一块印的标题」，封面印的标题就是论文
  // 题目——同一句话，不是两种含义
  title: auto,
  title-en: auto,
  title-en-xiaoer: auto,
  // 副题目。auto 取 info 的 subtitle / subtitle-en；那边的默认是 none ＝ 没有
  subtitle: auto,
  subtitle-en: auto,
  author: auto,
  institution: auto,
  date: auto,
  degree-level: auto,
  degree-type: auto,
  // 交上去的是哪一种东西，见 src/axes.typ 的 form。practice 那一档换标签
  // 与学位类别那一行，括号里填的是实践成果类型
  form: auto,
  practice-type: auto,
  // 排不下时发不发提示，见 src/pages/report/cover.typ
  warning: auto,
  // 排成范例那一页的样子——每个元素下面跟着「↑」与一行说明。*对拍用*
  annotated: auto,
  label: auto,
  layout: auto,
  // 只改这一页的词条
  overrides: (:),
) = context {
  once("cover")
  let i = info-get()
  if i.stage in _report-stages {
    // *深圳本科那两份是另一页*（两行小初华文新魏 ＋ 一张两列的表），
    // 与本部本科、与深圳研究生都不共构，所以在这儿分岔——那一支不 import
    // 这一支、这一支也不 import 那一支，页面按档挑是这一层的事。
    // 研究生那两份与本部同构，只是几个数不同，留在 _report 的表里
    if campus-for(i.campus, i.degree-level) == "shenzhen" and i.degree-level == "bachelor" {
      return _report-shenzhen.cover(
        stage: i.stage, info: i, overrides: overrides, layout: layout,
        lang: doc-lang.get(),
        ..(if title != auto { (title: title) } else { (:) }),
        ..(if warning != auto { (warning: warning) } else { (:) }),
      )
    }
    return _report.cover(
      stage: i.stage, info: i, overrides: overrides,
      ..(if title != auto { (title: title) } else { (:) }),
      // 排不下时纸角那条红字：与终稿封面同一个开关，写了才往下传
      ..(if warning != auto { (warning: warning) } else { (:) }),
      // *报告首页的版面在那一头解*：这一页有没有自己的一节要看校区与阶段
      // （深圳开题的首页自成一节，见 src/layout/presets.typ 的 report-cover-layouts），
      // 而校区那一档是在那一头按学位定的。用户这一页写的原样递过去，
      // 那边并在差额之上。报告首页整支都在 context 里，读得到 state
      layout: layout,
    )
  }
  let pick(v, k) = if v != auto { (k, v) } else { (k, i.at(k)) }
  // *带 -en 的那几条没写就回落*到不带后缀的那一条（默认表里它们是 auto，
  // 见 src/info.typ）——英文单语的文档不必把同一个学院名写两遍
  let pick-en(v, k, base) = if v != auto { (k, v) } else {
    (k, value-of(i, base, lang: "en"))
  }
  // *封面之后那一跳是封面自己的出口*，不是内封的：hithesis 的三次
  // \__hit_cover_break: 头一次就在封面之后。先前只有 titlepage() 记这条旗子，
  // 只排封面不排内封的文档（博士、cover 后直接目录）就静默不跳，目录落在第 2 页。
  // 这儿先按 titlepage 那个切页点记下，titlepage() 若跟着来会再记一次（同值）；
  // 跳本身仍由后面第一个前置部件补，理由见 src/layout/matter.typ 的 cover-exit
  cover-exit-odd.update(resolve-openright(
    "titlepage", degree-level: i.degree-level, matter: frontmatter-openright.get(),
  ))
  _cover.cover(
    terms: term-table("zh", "cover", overrides: overrides),
    variant: variant-of(i),
    ..(
      (
        pick(title, "title"), pick-en(title-en, "title-en", "title"),
        pick(title-en-xiaoer, "title-en-xiaoer"),
        pick(subtitle, "subtitle"), pick(subtitle-en, "subtitle-en"),
        pick(author, "author"),
        pick(institution, "institution"), pick(date, "date"),
        pick(degree-level, "degree-level"), pick(degree-type, "degree-type"),
        pick(form, "form"), pick(practice-type, "practice-type"),
      ).to-dict()
    ),
    ..(
      ((("warning", warning), ("annotated", annotated), ("label", label),
        ("layout", layout-for("cover", layout))).filter(((k, v)) => v != auto)).to-dict()
    ),
  )
}

// 内封（扉页）。中文一页；硕士与博士后面还跟一页英文内封。
//
// *英文内封不单独开一个函数。* 它不是用户要不要排的选择，是学位定的：
// hithesis（hit-thesis.cls:7340）写的是
//
//     \bool_lazy_or:nnF { postdoc } { bachelor } { … \hit@titlepage@en … }
//
// ——「既不是博士后、也不是本科」才排，即硕士与博士。所以这里按学位自动跟上，
// 用户写一次 titlepage() 就够。
//
// lang 说*排哪几份*，与 abstract / toc 同义：
//
//   auto        模板决定——按学位：研究生中英两页，本科只有中文那一页
//   "zh"        只排中文内封
//   "en"        只排英文内封
//
// *内封不跟文档语言走。* 英文版论文照旧要中文内封（规范没给英文版的
// 内封另立一档，我们也没有那份范例），所以 auto 只看学位。哪天有了英文版
// 的规定，改的是这一处，别处不动。
//
// en 收英文那一页的覆盖字典（比如 degree-attribute），不再兼任开关——
// 「排不排」由 lang 说了算，两件事分开。
//
// 位置参数（..args）只发给中文那一页——两页收的键不是一套（中文收 label /
// secrecy / school-code，英文收 degree-attribute），一份参数发两处会撞。
// 参数逐个列出来，理由同 cover：沉没参数把补全吃掉了。
// auto 一律表示「取 #info 存的那一份」。
#let titlepage(
  // 印在内封上的题目。中文页取 title，英文页取 title-en
  title: auto,
  title-en: auto,
  title-en-xiaoer: auto,
  // 副题目。「格式同封面」，中文页排在题目下面、英文页用冒号接上
  subtitle: auto,
  subtitle-en: auto,
  // 「Dissertation for the … Degree」那一行，只英文页有
  degree-attribute: auto,
  degree-level: auto,
  form: auto,
  secrecy: auto,
  classified-index: auto,
  udc: auto,
  // 字段表，(标签, 内容) 的有序表。*先前整个没透下去*——部件本身收它，
  // 而从 lib.typ 拿到的这个包装层不收，用户*加不了行*（副导师、行业导师这类
  // 规范里「无……不列此项」的行正要靠它）
  fields: auto,
  school-code: auto,
  // 排不下时发不发提示，见 banshi/src/styles/parts.typ 的 overflow-note
  warning: auto,
  // 排成范例那一页的样子，*对拍用*
  annotated: auto,
  label: auto,
  layout: auto,
  // 排中文页还是英文页。auto 按学位：本科只中文，研究生两页都排
  lang: auto,
  // 英文页专有的其余取值，原样透给它
  en: (:),
  openright: auto,
  overrides: (:),
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("titlepage")
  let i = info-get()
  // 内封从右手页起。四层让位：这次调用的参数 → frontmatter 段的显式值 →
  // 总闸 → 按学位的默认表（博士 true，本硕 false，见 src/settings/defaults.typ）。
  // 博士那一档跟的是 hithesis 的 \__hit_cover_break:。
  let odd = resolve-openright(
    "titlepage",
    degree-level: i.degree-level,
    local: openright,
    matter: frontmatter-openright.get(),
  )
  // 写了就用、没写就取 info 那一份；没有对应 info 键的（annotated 这些）写了才传，
  // 让内层的默认值说话
  let pick(v, k) = if v != auto { (k, v) } else { (k, i.at(k)) }
  // *带 -en 的那几条没写就回落*到不带后缀的那一条（默认表里它们是 auto，
  // 见 src/info.typ）——英文单语的文档不必把同一个学院名写两遍
  let pick-en(v, k, base) = if v != auto { (k, v) } else {
    (k, value-of(i, base, lang: "en"))
  }
  let only(..kv) = kv.pos().filter(((k, v)) => v != auto).to-dict()
  // *英文页专有的取值单独一份。* 中文页没有 title-en 这些参数，混进去会撞上
  // 「unexpected argument」。见 src/pages/titlepage.typ 的 en-only-keys。
  let en = en + only(
    ("title-en", title-en), ("title-en-xiaoer", title-en-xiaoer),
    ("subtitle-en", subtitle-en),
    ("degree-attribute", degree-attribute),
  )
  let named = only(
    ("title", title), ("subtitle", subtitle),
    ("form", form), ("secrecy", secrecy),
    // *这两个先前漏在这儿*：签名收着，转发时没带上，用户写了*静默失效*
    // （实测填了国内图书分类号与 UDC，页面上一个字都没有）
    ("classified-index", classified-index), ("udc", udc),
    ("fields", fields),
    ("school-code", school-code),
  ) + only(("warning", warning), ("annotated", annotated), ("label", label)) + (layout: layout-for("titlepage", layout))

  let want = if lang == auto {
    if i.degree-level in ("master", "doctor") { ("zh", "en") } else { ("zh",) }
  } else {
    (normalize-lang(lang),)
  }

  if "zh" in want {
  clear-page(to: if odd { "odd" } else { none })
  _titlepage.titlepage(..((
    terms: term-table("zh", "titlepage", overrides: overrides),
    info: i,
    degree-level: i.degree-level,
    title: i.title,
    subtitle: i.subtitle,
    secrecy: i.secrecy,
    form: i.form,
    classified-index: i.classified-index,
    udc: i.udc,
    school-code: i.school-code,
  ) + named))
  }

  if "en" in want {
    // 英文内封同样
    clear-page(to: if odd { "odd" } else { none })
    _titlepage.titlepage-en(..((
      terms: term-table("en", "titlepage", overrides: overrides),
      info: i,
      degree-level: i.degree-level,
      // *走 value-of 不直接读*——title-en 的默认是 auto（＝没写），
      // 回落到 title 那一条，见 src/info.typ
      title-en: value-of(i, "title", lang: "en"),
      title-en-xiaoer: i.title-en-xiaoer,
      subtitle-en: i.subtitle-en,
      form: i.form,
      classified-index: i.classified-index,
      udc: i.udc,
    ) + only(("warning", warning), ("annotated", annotated)) + (layout: layout-for("titlepage", layout)) + en))
  }
  // *收尾那一跳不在这儿发*，只把取值记下来，由后面第一个前置部件补上
  // ——理由见 src/layout/matter.typ 的 cover-exit。hithesis 是三次
  // \__hit_cover_break:（封面之后、中文内封之后、英文内封之后），末一次正是
  // 这一跳，它把摘要顶到右手页。
  cover-exit-odd.update(odd)
}

// 摘要。中英两份一次给全。
//
// *正文走位置参数，收尾随内容块*——摘要正文动辄十几行，写成具名参数会
// 被两行短短的关键词夹在中间，读起来找不到头。这也是 Typst 里内容型参数的
// 常规写法（#figure(…)[…]），neu-typst-latest-cap-able 的 neu-thesis-abstract
// 同款。
//
// *形状与 #chapter(en: […])[…] 同款*：正文槽恒为中文，en: 恒为英文。
// 早先摊平成四个参数（keywords / keywords-en / zh / en）配对全靠书写顺序，
// 那是因为关键词还在这一层；关键词进 info 之后只剩两份正文，具名一个就够了。
//
// 关键词从 info 取（zh 取 keywords，en 取 keywords-en）——它是著录用的元数据，
// 跟题目、作者同级，见 src/info.typ。
//
// lang 说*排哪几份*，与 titlepage / toc 同义：
//
//   auto        给了 en: 就两份都排，没给只排中文
//   "zh"/"en"   只排那一份。*只排一份而又没写 en: 时，正文槽就是那一份*
//               ——#abstract(lang: "en")[English body.] 照旧管用
//
// *不查「英文那份有没有写」。* 规范要求两页都有，但漏没漏是用户的事——
// 用户怎么写就怎么排。摘要正文也*不*跨语言回落：标题回落是因为印出来的
// 东西不能没有内容，而少一页摘要就是少一页，拿中文正文冒充英文摘要才是错的。
#let abstract(
  content,
  // 英文摘要正文
  en: none,
  // 这一页印的标题。auto 取词条。中英两页各一份——它们是两个部分，各印各的
  title: auto,
  title-en: auto,
  // 排哪几份，见上
  lang: auto,
  // 只改这一页的词条
  overrides: (:),
  // 只改这一页要不要从右手页起
  openright: auto,
  // 英文那一页的版面。auto 就用部件自己的默认（与正文同一套）
  layout: auto,
  // 关键词上面放什么：auto 隔一行（规范）、none 不空、长度、内容（v(1fr) 挤到页底）。
  // 一个值管中英两页；两页要不一样写 (zh: …, en: …)，见 src/pages/abstract.typ
  keywords-above: auto,
  // 关键词折行时后面的行要不要悬挂到第一个词下面。auto ＝ 不写 ＝ 顶格（指南「顶格书写」，
  // 范例没有折行的样子）；true 按 hithesis 的排法悬挂。中英两页同一个值
  keywords-hanging: auto,
  // 这一页的局部样式：字典形状与 iota-hit(styles:) 一样（眼下 body 与 figure.table），一个值管
  // 中英两页；两页不一样写 (zh: …, en: …)（缺的 ＝ auto），与 keywords-above 同形。作者自己的
  // Word 文件常见「英文摘要固定值 18 磅」这种与范例不同的排法，就写
  // styles: (en: (body: (line-spacing: (exactly: 18pt))))。实现就是替那一页套一层 new-styles
  styles: auto,
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }
  let styles-of(l) = if type(styles) == dictionary and styles.keys().all(k => k in ("zh", "en")) and styles.len() > 0 {
    styles.at(l, default: auto)
  } else { styles }

  once("abstract")
  // 封面序列的出口那一跳，第一个来的人补上，见 src/layout/matter.typ。
  // 放在包装层而不是部件里边：部件是照排版规矩画页面的，谁先谁后是装配的事。
  cover-exit()
  context {
    let i = info-get()
    let bodies = if lang != auto and en == none {
      // 只排一份、又没写 en:，正文槽就是那一份
      ((normalize-lang(lang), content),)
    } else {
      (("zh", content), ("en", en)).filter(((l, b)) => b != none)
    }
    if lang != auto {
      bodies = bodies.filter(((l, b)) => l == normalize-lang(lang))
    }
    for (l, body) in bodies {
      let page = _abstract.abstract(
        lang: l,
        // 只有一篇时英文目录里就叫 Abstract，两篇才带 (In Chinese) / (In English)
        single: bodies.len() == 1,
        title: if l == "en" { title-en } else { title },
        keywords: if l == "en" { i.keywords-en } else { i.keywords },
        overrides: overrides,
        openright: openright,
        layout: layout-for("abstract", layout),
        keywords-above: keywords-above,
        keywords-hanging: keywords-hanging,
        body,
      )
      let st = styles-of(l)
      if st == auto { page } else { new-styles(st, page) }
    }
  }
}

// 目录。lang: auto 时模板自己决定出哪几份——中文档按学位（博士中英两份，
// 硕本只有中文那份），英文档只出英文那一份。见 src/pages/outline.typ
// *参数逐条写出来，不用 ..args 一兜。* 兜起来 LSP 就补全不出来——编辑器
// 只认声明出来的签名，sink 里的名字它看不见。封面与内封当初也是这么改的。
//
// *默认值一律写 auto，不在这一层复述*：真正的默认住在 src/pages/outline.typ
// 那一份签名里，写了才往下传，没写就让它自己定。抄一遍默认就是抄一份会烂的表。
//
// degree-level 与 doc-lang 不在这一层露面：它们是从 info 与文档语言*推出来*的，
// 由这里填好再往下传，用户写不着。
#let _set(..pairs) = {
  let out = (:)
  for (k, v) in pairs.named() {
    if v != auto { out.insert(k, v) }
  }
  out
}

#let table-of-contents(
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  // 目录自己进不进目录。auto ＝ 不进，见 src/pages/outline.typ
  outlined: auto,
  // 收到第几级。auto ＝ 不写 ＝ 到条级（1.2.1）
  depth: auto,
  levels: auto,
  overrides: (:),
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  // 英文目录里读着是中文的条目后面的红字。auto ＝ 发，false 关这一页的；单条写
  // #en(warning: false)。见 src/pages/outline.typ 的 _en-warn
  warning: auto,
) = {
  // 同 abstract，见那里的说明
  cover-exit()
  context {
    let i = info-get()
    _toc-headerless-page(i, _toc.toc(
      degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
      title: title, title-en: title-en, two-hanzi: two-hanzi, openright: openright,
      overrides: overrides, heading-body-indent: heading-body-indent,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
      lang: lang, once: true, outlined: outlined, warning: warning,
      .._set(
        depth: depth, levels: levels,
        fill: fill, layout: layout-for("toc", layout),
      ),
    ))
  }
}

// 图表索引。语言判定与 toc 一字不差，所以学位与文档语言也在这一层填好。
// *两个只差交给谁排*，签名同一份，摊开写在这里
#let _list-of(which) = (
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  overrides: (:),
  levels: auto,
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  // 英文那一份里读着是中文的题注后面的红字，同 table-of-contents
  warning: auto,
) => context {
  let i = info-get()
  which(
    degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
    campus: campus-for(i.campus, i.degree-level),
    title: title, title-en: title-en, two-hanzi: two-hanzi, openright: openright,
    overrides: overrides, heading-body-indent: heading-body-indent,
    outline-entry-right-margin: outline-entry-right-margin,
    outline-entry-number-align: outline-entry-number-align,
    outlined: outlined, lang: lang, once: true, warning: warning,
    .._set(levels: levels, fill: fill), layout: layout-for("toc", layout),
  )
}

#let list-of-figures = _list-of(_lists.lof)
#let list-of-tables = _list-of(_lists.lot)

// 公式清单：条目是名、编号加公式本身。签名比图表清单多一个 form（公式按行内还是
// 行间形态排，见 src/pages/outline.typ）——只有它有这一项，所以单独一份包装
#let list-of-equations(
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  overrides: (:),
  levels: auto,
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  form: auto,
) = context {
  let i = info-get()
  _lists.loe(
    degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
    campus: campus-for(i.campus, i.degree-level),
    title: title, title-en: title-en, two-hanzi: two-hanzi, openright: openright,
    overrides: overrides, heading-body-indent: heading-body-indent,
    outline-entry-right-margin: outline-entry-right-margin,
    outline-entry-number-align: outline-entry-number-align,
    outlined: outlined, lang: lang, once: true, form: form,
    .._set(levels: levels, fill: fill), layout: layout-for("toc", layout),
  )
}
