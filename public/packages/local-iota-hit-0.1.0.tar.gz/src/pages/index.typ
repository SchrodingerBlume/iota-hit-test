// 索引页。
//
// 规范 2.18 说它*可选*、置于学位论文*之后*、中英两段中文在前、按拼音／
// 首字母排序；版式*有官方示例*——附录 6「索引示例」（最新版《研究生学位论文
// 撰写规范》，g-stem.docx / p-stem.docx 段 925–976），逐条量的：
//
//   *两栏*    一张 1 行 2 列的表格，两列各 4230 缇 ＝ 211.5pt（版心 8505 缇），
//                 整表居中；两个格的 tcBorders 全是 nil——*不画线*，
//                 是拿表格做的假分栏，左栏排完接右栏。
//                 我们用真分栏（columns）：内容多了自己流、自己跨页，比它的手工
//                 分栏好；栏间空白 10.8pt ＝ Word 那两个格的默认边距各 5.4pt
//   分组标题       *单个大写字母*，居中、加粗、小四；组间段前 12pt，首组没有
//   条目           行距 1.35（w:line="324" auto），页码右对齐、多页用「, 」连
//
// *hithesis 这一页排错了*：它把拼音排序键当分组标题印（「duan4」），官方是
// 单个大写字母；两栏它没错。
//
// 官方示例里*两处是手误*，不照抄：A 组标题与「安培计」之间多一个空段（B、C
// 两组都没有），以及 C 组前面那五个空段——手工把 C 挤到右栏用的，真分栏不需要。
// 末尾「注：按拼音字母顺序排序（注意多音字）」是给读者看的说明，不是版式。
//
// 标记、拼音与收集见 src/glossary/index.typ；这一层只有壳与版式。
#import "../document/info.typ": final-only-wanted
#import "../glossary/index.typ" as _index
#import "../errors.typ": once
#import "../heading/heading.typ": term-chapter
#import "../styles/presets.typ": default-styles
#import "../layout/resolve.typ": layout-for
#import "../styles/rules.typ" as style-rules
// 官方那张表两列各 4230 缇；栏间空白是两个格的默认边距之和
#let _gutter = 10.8pt
// 分组标题的段前，官方示例 w:before="240"
#let _group-above = 12pt

#let index(
  // 这一份用哪一层词条排。auto 跟随文档语言
  lang: auto,
  title: auto,
  overrides: (:),
  spread: auto,
  openright: auto,
  // 排几栏。auto ＝ 2（官方那张表就是两列）
  columns: auto,
  // 条目那一档的取值。*行距 1.35 是官方示例量的*（w:line="324" auto），比正文
  // 那一档（1.25）松；顶格；两端对齐关掉——一行是「词 + 页码」，拉伸没有意义
  style: default-styles.body + (line-spacing: 1.35, first-line-indent: (chars: 0), justify: false),
  // 这一页的页面设置：局部字典并到文档＋段那一份上，整份就整份替换
  layout: auto,
  // 这一页只在终稿出现。三态见 src/document/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("index")
  if columns != auto and (type(columns) != int or columns < 1) {
    panic("index: columns: expected a positive integer or auto, found " + repr(columns))
  }
  term-chapter(
    "index", lang: lang, title: title,
    overrides: overrides, spread: spread, openright: openright,
  )
  context {
    let layout = layout-for("index", layout)
    let n = if columns == auto { 2 } else { columns }
    let body = {
      // 行盒按包里那一套算，不自己拨 leading——见 src/styles/rules.typ 的 rules。
      // latin-par: true：西文条目靠正文那条 show par 拿西文行盒，边界字距补偿也按它定
      show: style-rules.rules.with(style, layout: layout, latin-par: true)
      set par(spacing: 0pt)
      // 中文在前、英文在后（规范 2.18）；两段接着排在同一栏流里
      let first = true
      for which in (_index.zh-segment, _index.en-segment) {
        for (letter, entries) in _index.segment(which) {
          // 分组标题：单个大写字母，居中、加粗、小四。加粗走 strong——伪粗由
          // src/fonts/fake.typ 那一层接手，与别处一致
          block(
            above: if first { 0pt } else { _group-above }, below: 0pt, width: 100%,
            align(center, strong(text(size: 12pt, letter))),
          )
          first = false
          for (term, pages) in entries {
            // 词顶格、页码右对齐到栏的右缘，多页用「, 」连。
            // *词与页码都点得回正文*——落点是标记元素自己的位置，见 src/glossary/index.typ
            // 的 segment；与目录条目、引用一样都是链接。词链到*头一处*（页码
            // 最小的那个），各页码各链各的那一处
            par(
              link(pages.first().at(1), term)
                + box(width: 1fr)
                + pages.map(((n, loc, _)) => link(loc, n)).join(", "),
            )
          }
        }
      }
    }
    if n == 1 { body } else { std.columns(n, gutter: _gutter, body) }
  }
}
