#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": final-only-wanted
#import "../references/index.typ" as _index
#import "../once.typ": once
#import "../heading/heading.typ": term-chapter
#import "../styles/presets.typ": default-styles
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": layout-for
#import banshi.styles as style-rules
#let _gutter = 10.8pt
#let _group-above = 12pt

#let index(
  lang: auto,
  title: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  columns: auto,
  style: default-styles.body + (line-spacing: 1.35, first-line-indent: (chars: 0), justify: false),
  layout: auto,
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("index")
  if columns != auto and (type(columns) != int or columns < 1) {
    panic("index: columns: expected a positive integer or auto, found " + repr(columns))
  }
  term-chapter(
    "index", lang: lang, title: title,
    overrides: overrides, two-hanzi: two-hanzi, openright: openright,
  )
  context {
    let layout = layout-for("index", layout)
    show: linebreaks-sets.with(layout)
    let n = if columns == auto { 2 } else { columns }
    let body = {
      show: style-rules.rules.with(style, layout: layout, latin-par: true)
      set par(spacing: 0pt)
      let first = true
      for which in (_index.zh-segment, _index.en-segment) {
        for (letter, entries) in _index.segment(which) {
          block(
            above: if first { 0pt } else { _group-above }, below: 0pt, width: 100%,
            align(center, strong(text(size: 12pt, letter))),
          )
          first = false
          for (term, pages) in entries {
            par(
              link(pages.first().at(1), term)
                + box(width: 1fr)
                + pages.map(((n, loc, _)) => link(loc, n)).join(", "),
            )
          }
        }
      }
    }
    if n == 1 { body } else { std.columns(n, gutter: _gutter, body) }
  }
}
