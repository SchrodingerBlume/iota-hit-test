#import "@local/banshi:0.1.0" as banshi
#import "../settings/resolve.typ" as settings
#import "../terms/lang.typ": en, title-of
#import "../figure/continued.typ": find-continued
#import "../figure/kinds.typ": find-algorithm
#import "../heading/heading.typ": term-chapter
#import "../case.typ": english-title
#import "../once.typ": once as _once
#import "../terms/lang.typ": normalize as normalize-lang, doc-lang
#import "../styles/presets.typ": list-levels
#import "../references/refs.typ" as refs
#import "../heading/numbering.typ" as _numbering
#import "../terms/lookup.typ": term-for, info-variant, term-table
#import "../axes.typ": report-stages
#import "./outline.typ": entry-rule, en-warn
#let _list-of(
  kind, name, sup-key,
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  overrides: (:),
  levels: auto,
  heading-body-indent: auto,
  fill: repeat(justify: false)[.],
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  layout: auto,
  lang: auto,
  degree-level: "doctor",
  campus: "harbin",
  stage: "final",
  doc-lang: "zh",
  category: "stem",
  once: false,
  form: auto,
  warning: auto,
) = {
  if warning not in (auto, true, false) {
    panic(name + ": warning: expected auto, true, or false, found " + repr(warning))
  }
  let levels = if levels != auto { levels } else { (list-levels,) }
  if form not in (auto, "inline", "display") {
    panic("list-of-equations: form: expected auto, \"inline\", or \"display\", found " + repr(form))
  }
  let by-chapter = settings.caption-by-chapter.get()
  let is-eq = kind == math.equation
  let eq-by-chapter = settings.equation-by-chapter.get()
  let want = if lang != auto {
    (normalize-lang(lang),)
  } else if doc-lang == "en" or stage in report-stages {
    (doc-lang,)
  } else if degree-level == "doctor" {
    ("zh", "en")
  } else {
    ("zh",)
  }
  for l in want {
    if once { _once(name, key: l) }
    term-chapter(
      name, lang: l, title: if l == "en" { title-en } else { title },
      overrides: overrides, two-hanzi: two-hanzi, openright: openright,
      outlined: outlined != false,
      toc-name: if want.len() == 2 { auto } else {
        term-table("en", name, overrides: overrides).title
      },
    )
    {
      show outline.entry: entry-rule(
        el => if is-eq {
          let num = refs.number(el, false, eq-by-chapter, running: false)
          if num == none { none } else {
            let sup = term-for(
              term-table(l, name, overrides: overrides), sup-key,
              info-variant() + (degree-level: degree-level, campus: campus),
            )
            sup + refs.gap(sup, num) + num
          }
        } else if el.caption == none { none } else if find-continued(el.caption.body) != none {
          none
        } else if find-algorithm(el.body) != none {
          none
        } else {
          let num = refs.number(el, by-chapter, false)
          if num == none { none } else {
            let given = refs.given-supplement(el.fields(), kind, doc-lang)
            let sup = (
              _numbering.appendix-prefix(el.location(), l, by-chapter: by-chapter)
            ) + (if given != auto { given } else { term-for(
              term-table(l, name, overrides: overrides), sup-key,
              info-variant() + (degree-level: degree-level, campus: campus),
            ) })
            sup + refs.gap(sup, num) + num
          }
        },
        it => if is-eq {
          math.equation(block: false, if form == "display" { math.display(it.element.body) } else { it.element.body })
        } else if it.element.caption == none { none } else if (
          find-continued(it.element.caption.body) != none
            or find-algorithm(it.element.body) != none
        ) { none } else {
          let body = it.element.caption.body
          let name = title-of(body, l)
          if l == "en" { en-warn(english-title(name, slot: "caption"), body, overrides, warning: warning) } else { name }
        },
        level => if is-eq {
          query(math.equation.where(block: true)).filter(e => e.numbering != none)
        } else { query(figure.where(kind: kind, outlined: true)).filter(f => find-algorithm(f.body) == none) },
        levels: levels, layout: layout, fill: fill,
        heading-body-indent: heading-body-indent,
        outline-entry-right-margin: outline-entry-right-margin,
        outline-entry-number-align: outline-entry-number-align,
        category: category,
      )
      if is-eq {
        context {
          for e in query(math.equation.where(block: true)) {
            if e.numbering != none { outline.entry(1, e) }
          }
        }
      } else {
        outline(title: none, target: figure.where(kind: kind))
      }
    }
  }
}

#let lof(..args) = _list-of(image, "list-of-figures", "image", ..args)
#let lot(..args) = _list-of(table, "list-of-tables", "table", ..args)
#let loe(..args) = _list-of(math.equation, "list-of-equations", "equation", ..args)
