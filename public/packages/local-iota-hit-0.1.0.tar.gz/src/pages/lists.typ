// 图表与公式索引：list-of-figures / list-of-tables / list-of-equations 三页，同一个 _list-of 按
// kind 派。条目怎么排（编号列、点线、页码、折行）与目录同一套，在 ./outline.typ 的 entry-rule；
// 规范没有这一项，给它是因为原生 outline 排不出我们的章壳。
#import "@local/banshi:0.1.0" as banshi
#import "../settings/resolve.typ" as settings
#import "../terms/lang.typ": en, title-of
#import "../figure/continued.typ": find-continued
#import "../figure/kinds.typ": find-algorithm
#import "../heading/heading.typ": term-chapter
#import "../case.typ": english-title
#import banshi.errors: once as _once
#import "../terms/lang.typ": normalize as normalize-lang, doc-lang
#import "../styles/presets.typ": list-levels
#import "../references/refs.typ" as refs
#import "../heading/numbering.typ" as _numbering
#import "../terms/lookup.typ": term-for, info-variant, term-table
#import "../axes.typ": report-stages
#import "./outline.typ": entry-rule, en-warn

// ── 图表索引 ────────────────────────────────────────────────────────────
//
// *规范里没有这一项。* 指南与规范章都只提「索引」，而那是研究生规范 2.18 的
// *专业词语*索引——「以论文中的专业词语为检索线索，指出其相关内容的所在
// 页码……中文按各词汉语拼音第一个字母排序，英文按该词第一个英文字母排序」，
// 与图表清单是两回事。范例里也没有。
//
// 给它是因为*原生那句用户写不出我们这一套*：#outline(target: …) 排得出
// 条目，但排不出我们的章壳（不编号、字样从词条来、进目录、章前跳页、挂英文
// 目录名），也对不上目录那套点线与右制表位。所以给快捷键，*但不挡原生*
// ——想自己排就照写 outline。
//
// 字样与「只有英文档才发」这两条都跟 hithesis（listfigurename / listtablename，
// hithesis.dtx:6153；\ifhit@english 那一段 hithesis.dtx:8016）。我们两档都给：
// 中文档一般不用，但要用得有。
//
// *语言判定与 toc 一字不差*：博士中英两份，本硕只中文；英文档只出英文。
#let _list-of(
  kind, name, sup-key,
  // 字样的就地覆盖。*两档各一个口*，与 toc 同形——博士档两份都出，
  // 一个 title 盖两边的话英文那页也会印成中文字样（实测 lof(title: [插图清单])
  // 把 List of Figures 也改掉了）
  title: auto,
  title-en: auto,
  two-hanzi: auto,
  openright: auto,
  // 进不进目录。*auto ＝ 不写 ＝ 不进*。写 true 就进，那时中英两页在英文
  // 目录里靠词条的 in-english-toc 分辨（… (In Chinese) / (In English)），与摘要
  // 同一套；不分的话一模一样的两条挨在一起。
  //
  // hithesis 那边索引是进目录的（\hit@listof 走 \hit@appendix@chapter*，里面有
  // \addcontentsline），我们默认不进。
  //
  // 目录自己那一页也有这一项，只是默认反过来（不进）——见 toc
  outlined: auto,
  overrides: (:),
  // 条目的字体与缩进。*一级就够了*——图表编号是平的（图1-1），没有层级。
  // hithesis 的 \l@figure 是 \@dottedtocline{1}{0em}{4em}：缩进 0、编号列 4em。
  // 我们与目录同一条规则：编号后空一个字，换成「图 A-1」这类也不用改数。
  levels: auto,
  heading-body-indent: auto,
  // 点线、右边距、编号的摆法，与 toc 同名同义
  fill: repeat(justify: false)[.],
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  // 这一页的页面设置：局部字典并到文档＋段那一份上，整份就整份替换
  layout: auto,
  lang: auto,
  // 与 toc 同样由外层填好再传进来，见 src/pages/front.typ
  degree-level: "doctor",
  // 校区，见 src/axes.typ。图那个名按它分档（深圳的英文档写 Figure），
  // 外层已经过了 campus-for
  campus: "harbin",
  // 这一份是终稿还是报告：报告只出一份目录／清单，见下面的 want
  stage: "final",
  doc-lang: "zh",
  // 学科门类，见 src/axes.typ。编号后的间距按它与本级取
  category: "stem",
  // 只印一次的检查，同 toc 那一条
  once: false,
  // 公式清单里公式按哪种形态排：auto ＝ "inline"（行内形态，分式上下标收紧，条目一行）；
  // "display" 行间形态（math.display，分式积分按正文里的大小），条目会长高。
  // 值照 Typst 自己的 math.inline / math.display；参数名照 cite(form:)——同一条内容排成
  // 哪种形态（style 在原生是 CSL 样式，不是这个意思）。只有公式清单的包装递它
  form: auto,
  // 英文那一份里读着是中文的题注后面发不发红字，同 toc
  warning: auto,
) = {
  if warning not in (auto, true, false) {
    panic(name + ": warning: expected auto, true, or false, found " + repr(warning))
  }
  let levels = if levels != auto { levels } else { (list-levels,) }
  if form not in (auto, "inline", "display") {
    panic("list-of-equations: form: expected auto, \"inline\", or \"display\", found " + repr(form))
  }
  // 图表编号按不按章。*没有这一页自己的开关*——一篇文档里题注只能有一种编号
  // 模式，索引必须跟着正文那一份走；给个口子只会让两边对不上（先前这里硬写 true，
  // 文档级写了 false 时正文印「图1」、索引却印「图 1-1」，而那个 1- 连按章的口径
  // 都不成立：计数器没在章处重置）。读 iota-hit 解好写进来的那个值，见
  // src/settings/resolve.typ 的 caption-by-chapter
  let by-chapter = settings.caption-by-chapter.get()
  // 公式清单：编号按不按章跟正文那一套（文档级设定），括号两档同源，见 refs.number
  let is-eq = kind == math.equation
  let eq-by-chapter = settings.equation-by-chapter.get()
  // 报告只出一份，理由同目录那一处
  let want = if lang != auto {
    (normalize-lang(lang),)
  } else if doc-lang == "en" or stage in report-stages {
    (doc-lang,)
  } else if degree-level == "doctor" {
    ("zh", "en")
  } else {
    ("zh",)
  }
  // 清单在英文目录里叫什么：两份都出（博士档）才带 (In Chinese) / (In English) 分开，
  // 只出一份就是光名字——与摘要同一条规则（两篇才带尾巴）
  for l in want {
    if once { _once(name, key: l) }
    term-chapter(
      name, lang: l, title: if l == "en" { title-en } else { title },
      overrides: overrides, two-hanzi: two-hanzi, openright: openright,
      // auto ＝ 进目录，与别的清单一致
      outlined: outlined != false,
      toc-name: if want.len() == 2 { auto } else {
        term-table("en", name, overrides: overrides).title
      },
    )
    {
      show outline.entry: entry-rule(
        // *编号要在对象那一处求。* it.prefix() 是在*索引这一页*求值的，
        // 章计数器还停在 0，排出来是「图 0-1」。与引用那一处同一个坑，也同一个
        // 解法：counter(...).at(元素的 location)，见 src/figure/caption.typ 的
        // refs.number——那一份两处共用，不另写算术。
        //
        // 名也在这里补上：范例的题注是「图1-1  某某」，索引条目照它。
        // *续表续图不进索引。* 拆开的下半张仍是一个 figure（编号也真的往下
        // 走，「表1-2」），照排就是同一张表在清单里出现两遍。判据是题注里那个
        // continued 记号，见 src/figure/continued.typ——它管的正是「这是上一张的续」。
        // *没有题注的图表不进索引。* 原生 outline 照样把它收成条目，
        // el.caption 是 none——先前直接取 .body，当场 cannot access fields on
        // type none。没有题名的东西本来也没什么可列的
        // 公式清单：「公式 (2-1)」/「Equation (2-1)」，名从 loe 桶取（正文里引用印的是
        // caption 桶的「式」/「Eq.」，清单里写全称），名与号之间照引用那条判据空一个
        el => if is-eq {
          let num = refs.number(el, false, eq-by-chapter, running: false)
          if num == none { none } else {
            let sup = term-for(
              term-table(l, name, overrides: overrides), sup-key,
              info-variant() + (degree-level: degree-level, campus: campus),
            )
            sup + refs.gap(sup, num) + num
          }
        } else if el.caption == none { none } else if find-continued(el.caption.body) != none {
          none
        } else if find-algorithm(el.body) != none {
          // 伪代码的原件（kind 还是 image 的那个，重造前的）不进插图索引——它不排、
          // 不该记数，见 src/figure/caption.typ 的 kinds.original
          none
        } else {
          let num = refs.number(el, by-chapter, false)
          if num == none { none } else {
            // 名从清单自己的桶取（list-of-figures.figure…），不去 caption 桶：三张清单
            // 一个形状，见 src/terms/built-in.typ。名与号之间空不空走引用那一条判据
            // （图表不空，英文档空），见 src/figure/caption.typ 的 refs.gap
            //
            // 附录里那几条的名前多一个「附」，与题注、引用同一处判据（清单里
            // 印的就是题注那个头），见 src/heading/numbering.typ
            // *图那个名按学位分档*（本科的英文档写全称 Figure），与正文
            // 题注同一条；清单桶的 from("caption") 把两档一起搬了过来
            // 这一张上显式写了 supplement 的照它印（与题注、引用同一条，见
            // src/figure/caption.typ 的 refs.given-supplement）；它没有英文那一份，两页同名。
            // *判「写没写」按文档语言*，不按这一页的：fields() 里填的是 Typst 按文档语言
            // 给的字样，拿英文那页的语言去比，中文档的「图」就会被当成用户写的
            let given = refs.given-supplement(el.fields(), kind, doc-lang)
            let sup = (
              _numbering.appendix-prefix(el.location(), l, by-chapter: by-chapter)
            ) + (if given != auto { given } else { term-for(
              term-table(l, name, overrides: overrides), sup-key,
              info-variant() + (degree-level: degree-level, campus: campus),
            ) })
            sup + refs.gap(sup, num) + num
          }
        },
        // 英文那一份取英文题名，与英文目录同一个办法（#en 挂的那个记号）；
        // 没挂英文名的回落成中文，同 title-of
        // 名也要一起哑掉：条目规则见「名一份都没有才不排」那一句
        // 公式清单的正身就是公式本身，排成行内公式；公式没有题注也没有名
        it => if is-eq {
          math.equation(block: false, if form == "display" { math.display(it.element.body) } else { it.element.body })
        } else if it.element.caption == none { none } else if (
          find-continued(it.element.caption.body) != none
            or find-algorithm(it.element.body) != none
        ) { none } else {
          let body = it.element.caption.body
          let name = title-of(body, l)
          // 中文那一侧印中文本来就对，没什么可警告的
          if l == "en" { en-warn(english-title(name, slot: "caption"), body, overrides, warning: warning) } else { name }
        },
        // 同级 = 同一种图表里进了清单的（只有一级，级别不看）：续图续表与不编号的
        // 由 prefix-of 给 none 滤掉
        level => if is-eq {
          query(math.equation.where(block: true)).filter(e => e.numbering != none)
        } else { query(figure.where(kind: kind, outlined: true)).filter(f => find-algorithm(f.body) == none) },
        levels: levels, layout: layout, fill: fill,
        heading-body-indent: heading-body-indent,
        outline-entry-right-margin: outline-entry-right-margin,
        outline-entry-number-align: outline-entry-number-align,
        category: category,
      )
      if is-eq {
        // 公式不是 outlinable 元素，outline(target:) 排不出；条目自己造——
        // outline.entry(level, element) 造出来的条目照样落进上面那条 show 规则
        context {
          for e in query(math.equation.where(block: true)) {
            if e.numbering != none { outline.entry(1, e) }
          }
        }
      } else {
        outline(title: none, target: figure.where(kind: kind))
      }
    }
  }
}

#let lof(..args) = _list-of(image, "list-of-figures", "image", ..args)
#let lot(..args) = _list-of(table, "list-of-tables", "table", ..args)
// 公式清单：条目是编号加公式本身（公式没有题注），见 _list-of
#let loe(..args) = _list-of(math.equation, "list-of-equations", "equation", ..args)
