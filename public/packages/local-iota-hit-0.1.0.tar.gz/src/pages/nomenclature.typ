// 物理量名称及符号表。
//
// 研究生规范 2.4（目录内容）：「物理量名称及符号表（*参照附录2，采用国家标准
// 规定符号者可略去此表*）」——可略，与「写了才有」一致；2.2：「摘要、目录、
// 物理量名称及符号表等文前部分的页码用罗马数字单独编排」。2.9 只管行文（名称
// 与符号遵 GB 3100/3102、符号斜体），*这一页怎么排规范没有规定*（hithesis
// 手册原话同），范例里也没有这一页。
//
// 版式跟 hithesis 的 symbols 环境——一行一个 \item[$\rho$] 密度 的 description
// 列表（labelwidth 2.5cm + labelsep 0.5cm，与 thuthesis 逐条相同），*不排序*：
// 「顺序完全由自己定」，国际期刊那种拉丁→希腊→数字的分组顺序手写就是；它的可选
// 参数 labelwidth 对应我们的 hanging-indent。两列悬挂那一套与缩略语表共用，见
// src/paragraph/terms.typ；它 demo 那页实测符号列 85.05、说明 170.09，正是同一个
// 模型。输入收原生 terms 语法（/ $sigma$: 应力），一条挂多个符号写 / $x$、$y$: …，
// 与 eqdenote 同一个解析器。
//
// *中文字样规范定死*；英文 Nomenclature 是这类表的专门词（hithesis 写的是
// List of physical quantities and symbols，hit-thesis.cfg:620，太长且不专门）。
//
// *verbatim: true 是逃生口*。规范允许「把符号分成几张表、各有各的列」（附录 2
// 法定计量单位那种带列头带线的），列表排不出那种版式——hithesis 为此留了
// symbols*。verbatim: true 只给壳（标题、进目录、罗马页码），正文*原样*排、
// 自己写 table，与 #resume 的「正文就是正文」同一个态度。*显式开关，不按内容
// 猜*——terms 语法写坏了要的是报错，不是静默排成原文。
//
// *两个页函数*：list-of-symbols 单独一页（物理量名称及符号表 / List of Physical
// Quantities and Symbols，字样跟 hithesis 的 list-of-symbols-heading-en），nomenclature
// 是合并页——hithesis 的第三个部件（手册 3.14.15：「不少论文只列一张“本文符号及
// 缩写”」）：章标题「符号及缩略语」/ Nomenclature（工科论文里这个词本就常同时列符号
// 与缩写），页内两段各带小标题，符号在上、缩略语在下（它写死的顺序，我们也不开
// 参数）；缩略语的条目由 abbreviations: 参数给（与 #list-of-abbreviations 的条目同型），@ 机制、重置全都
// 照走。*合并页与两张单页互斥*——都写了当场报错并指明用法，见 src/errors.typ。
// *一页只有一个 hanging-indent*——auto 按两段合起来的最宽标签取（同页两段的
// 说明列必须对齐；缩略语那段按声明的全部算，用没用过要到排表时才知道，宽度得先
// 定），写了长度就两段都用——「两段给得不一样」在语法上不存在。
//
// 这一页排成哪种形态 form: auto（＝ "achievements"，小标题照成果页的组名：宋体小四加粗
// 顶格、段前段后 5 磅）| "declarations"（小标题照声明页的内标题：小三黑体居中、段前段后
// 半行）| "no-subheadings"（不印小标题）| none（只声明缩略语条目、整页不印，与
// list-of-abbreviations(form: none) 同义）。词照原生 cite(form: "normal" | "prose" | … | none)
// ——同一条内容排成哪种形态，none 不输出；两档小标题是两套形态（字体、字号、对齐、间距
// 整套），不是对齐，值就说照哪一页。
#import "../fonts/presets.typ": zihao
#import "../info.typ": final-only-wanted
#import "./abbreviations.typ" as _page
#import "../references/abbreviations.typ" as _abbr
#import "../heading/heading.typ": term-chapter
#import "../paragraph/terms.typ": items, term-list, check-hanging-indent, check-header, auto-hanging-indent, resolve-header
#import "../terms/lookup.typ": term-table, lookup-key
#import "../terms/lang.typ": resolve-lang
#import "../layout/matter.typ": front-numbering-enter, cover-exit
#import "../styles/parts.typ": paragraph
#import "../layout/resolve.typ": layout-for, linebreaks-sets
#import "../paragraph/group-heading.typ": group-heading
#import "../errors.typ": once, never-with

// 页内的小标题：*照原创性声明页的内标题排*——那一页与合并页同构（一个章壳、
// 里面两个带名的块），而且它有范例：小三黑体、居中、段前段后各 0.5 行（本科范例
// p18 段 515/522 的 beforeLines/afterLines=50，字号从范例反推），取值就是
// declarations.typ 的 section 档。hithesis 合并页的小标题是 \bfseries 顶格
// （ctex 映射成黑体小四），不跟——它没有范例，声明页的类比更硬。
//
// *头一个小标题不发段前*——那 0.5 行由 term-chapter 排大标题时带上了，
// 再发一次就多出半行；与声明页同一条（见 declarations.typ）。第二个自带的
// 段前 0.5 行也正是两段之间的分隔，不必再垫空行
#let _subheading-style = (
  snap-to-docgrid: false,
  size: zihao.xiaosan, font-zh: "heiti", line-spacing: 1.25, first-line-indent: (chars: 0),
  align: center, above: (lines: 0.5), below: (lines: 0.5),
)

// 合并页的小标题：achievements 照成果页组名，declarations 照声明页内标题，no-subheadings 不印
#let _subheading(body, layout, form, first: false) = {
  if form == "no-subheadings" { return }
  if form == "achievements" { return group-heading(body, layout) }
  paragraph(
    body,
    _subheading-style + (if first { (above: 0pt) } else { (:) }),
    layout: layout,
  )
}

// 正文槽解成 (符号, 说明) 行；verbatim 时 none
#let _rows(body, verbatim, who) = {
  if verbatim { return none }
  let parsed = items(body).map(it => (it.term, it.description))
  if parsed.len() == 0 {
    panic(
      who + ": expected a term list, found " + repr(body.func())
        + " (write " + who + "[/ $x$: explanation], or verbatim: true to lay the body out yourself)",
    )
  }
  parsed
}

#let _check(who, verbatim, header, hanging-indent, outlined) = {
  check-hanging-indent(who, hanging-indent)
  if verbatim not in (auto, true, false) {
    panic(who + ": verbatim: expected boolean or auto, found " + repr(verbatim))
  }
  if outlined not in (auto, true, false) {
    panic(who + ": outlined: expected boolean or auto, found " + repr(outlined))
  }
  check-header(who, header)
  if header == true and verbatim == true {
    panic(who + ": header: only meaningful with a term list")
  }
}

// 物理量名称及符号表，单独一页
#let list-of-symbols(
  // 这一份用哪一层词条排。auto 跟随文档语言
  lang: auto,
  title: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  // 进不进目录。auto ＝ 进
  outlined: auto,
  // 说明从哪儿起，与 terms(hanging-indent:) 同名同义。auto 按内容定，
  // 见 src/paragraph/terms.typ
  hanging-indent: auto,
  // 这一页的页面设置：局部字典并到文档＋段那一份上，整份就整份替换
  layout: auto,
  // body 原样排、不解析。auto（＝ false）收原生 terms 语法（/ $x$: 说明）排成两列；
  // true 什么都不做——规范允许的「分几张表、各有各的列」自己写 table，见文件头。
  // 词取自原生 raw 一族的那层意思：交出去什么样就排成什么样
  verbatim: auto,
  // 印不印列头，三态布尔：auto ＝ 跟模板（＝ 不印，hithesis 与 thu 都不印）、true 印、
  // false 不印。字是词条 column-symbol／column-description，改字走 overrides
  // （list-of-symbols-column-symbol: […]）。名字照原生 table.header
  header: auto,
  body,
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  _check("list-of-symbols", verbatim, header, hanging-indent, outlined)
  let verbatim = verbatim == true
  let rows = _rows(body, verbatim, "list-of-symbols")
  once("list-of-symbols")
  never-with(
    "list-of-symbols", "nomenclature",
    "nomenclature prints the symbols and the abbreviations together; write either "
      + "#nomenclature[...] or #list-of-symbols[...] + #list-of-abbreviations(), not both",
  )
  // 封面序列的出口那一跳，第一个来的人补上，见 src/layout/matter.typ
  cover-exit()
  // 头一个带页码的前置部件把页码归到 I；必须排在标题之前，见 src/layout/matter.typ
  front-numbering-enter(openright: openright)
  term-chapter(
    "list-of-symbols", lang: lang, title: title,
    overrides: overrides, two-hanzi: two-hanzi, openright: openright,
    outlined: outlined != false,
  )
  if verbatim { body } else {
    set par(first-line-indent: 0pt)
    context {
      let t = term-table(resolve-lang(lang), "list-of-symbols", overrides: overrides)
      term-list(
        rows, hanging-indent: hanging-indent,
        header: resolve-header(header, (strong(t.column-symbol), strong(t.column-description))),
      )
    }
  }
}

// 符号及缩略语，合并页：符号在上、缩略语在下
#let nomenclature(
  // 缩略语的条目，与 #list-of-abbreviations 的头一个参数同型（字典、yaml、字典数组）。
  // 合并页必须给：没有缩略语就写 #list-of-symbols
  abbreviations: none,
  lang: auto,
  title: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  // 两段共一个 hanging-indent，auto 按两段合起来的最宽标签取
  hanging-indent: auto,
  // 合并页的小标题段前段后 0.5 行按正文的跨度算（195 缇 ＝ 9.75），与声明页同，见
  // src/layout/presets.typ
  layout: auto,
  verbatim: auto,
  // 印不印列头，三态布尔，两段一起；字各段取各的词条（符号／说明、缩写／全称），
  // 两段各改各的桶：overrides: (list-of-symbols-column-symbol: […],
  // list-of-abbreviations-column-short: […])
  header: auto,
  // 缩略语那一段：按缩写字母序、只列用过的，与 list-of-abbreviations 同名同义
  sort: auto,
  used-only: auto,
  // 这一页的形态：auto ＝ "achievements"（小标题照成果页的组名）、"declarations"（照声明页的
  // 内标题）、"no-subheadings"（不印小标题）、none（只声明条目、整页不印）。见文件头
  form: auto,
  body,
  // 这一页只在终稿出现。三态见 src/info.typ 的 final-only-wanted
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  _check("nomenclature", verbatim, header, hanging-indent, outlined)
  if abbreviations == none {
    panic("nomenclature: abbreviations: expected the abbreviation entries (a dictionary, "
      + "yaml(...), or an array of dictionaries); for symbols alone write #list-of-symbols[...]")
  }
  if form not in (auto, "achievements", "declarations", "no-subheadings", none) {
    panic("nomenclature: form: expected auto, \"achievements\", \"declarations\", \"no-subheadings\", or none, found " + repr(form))
  }
  let form = if form == auto { "achievements" } else { form }
  for (name, value) in (sort: sort, used-only: used-only) {
    if value not in (auto, true, false) {
      panic("nomenclature: " + name + ": expected boolean or auto, found " + repr(value))
    }
  }
  // form: none ＝ 只声明缩略语条目，符号槽与整页都不排——与 list-of-abbreviations(form: none)
  // 同一个用法；声明是两个 state 更新，摘要在前也读得到
  if form == none { return _abbr.declare(abbreviations) }
  let verbatim = verbatim == true
  let rows = _rows(body, verbatim, "nomenclature")
  once("nomenclature")
  let hint = (
    "nomenclature prints the symbols and the abbreviations together; write either "
      + "#nomenclature[...] or #list-of-symbols[...] + #list-of-abbreviations(), not both"
  )
  never-with("nomenclature", "list-of-symbols", hint)
  never-with("nomenclature", "list-of-abbreviations", hint)
  // 页面级 overrides 要分派给三个桶：光键名归本页（章标题那一层，本页的桶就是
  // nomenclature——title 只改章标题，不动小标题）；其余按桶名各回各家
  // （list-of-symbols-title、list-of-abbreviations-column-short）——词条机制只许页面级
  // 覆盖动本页的桶，混着发会当场报错。
  // *光键名跟着这一页的语言走*（见 src/terms/lookup.typ 抬头）：这里只取三元组里
  // 的桶名，中英两侧的键集在这三个桶上是一样的，所以桶名不受语言影响
  let bucket-of(k) = {
    let hit = lookup-key(k, lang: resolve-lang(lang))
    if hit == none { none } else { hit.at(1) }
  }
  let picked(bucket) = {
    let out = (:)
    for (k, v) in overrides {
      if bucket-of(k) == bucket { out.insert(k, v) }
    }
    out
  }
  let own = {
    let out = picked("nomenclature")
    for (k, v) in overrides {
      if bucket-of(k) == none { out.insert(k, v) }
    }
    out
  }
  _abbr.declare(abbreviations)
  // 表排过了——正文里的缩写据此链到这一页，见 src/references/abbreviations.typ
  _abbr.mark-printed()
  cover-exit()
  front-numbering-enter(openright: openright)
  term-chapter(
    "nomenclature", lang: lang, title: title,
    overrides: own, two-hanzi: two-hanzi, openright: openright,
    outlined: outlined != false,
  )
  // 链接落点：章标题跳过页之后，见 src/references/abbreviations.typ 的 table-label
  _abbr.anchor()
  context {
    let l = resolve-lang(lang)
    let lay = layout-for("nomenclature", layout)
    // 引擎画字符网格那一档：这一页的 set par(linebreaks:)（没给 --input linebreaks 就什么都不发），见 src/layout/resolve.typ
    show: linebreaks-sets.with(lay)
    let for-sym = picked("list-of-symbols")
    let for-abbr = picked("list-of-abbreviations")
    set par(first-line-indent: 0pt)
    std.layout(size => {
      let st = term-table(l, "list-of-symbols", overrides: for-sym)
      let at = term-table(l, "list-of-abbreviations", overrides: for-abbr)
      // 列头也占一行，两段的左格头都得进宽度测量
      let heads = if header == true {
        (strong(st.column-symbol), strong(at.column-short))
      } else { () }
      let labels = (
        (if rows == none { () } else { rows.map(((label, _)) => label) })
          + _abbr.entries.final().values().map(e => e.short)
          + heads
      )
      let indent = if hanging-indent != auto { hanging-indent } else {
        auto-hanging-indent(labels, size)
      }
      _subheading(st.title, lay, form, first: true)
      if verbatim { body } else {
        term-list(
          rows, hanging-indent: indent,
          header: resolve-header(header, (strong(st.column-symbol), strong(st.column-description))),
        )
      }
      _subheading(at.title, lay, form)
      _page.listing(
        lang: l, overrides: for-abbr, header: header, hanging-indent: indent,
        sort: sort, used-only: used-only,
      )
    })
  }
}
