#import "../native.typ" as _native
#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: indent
#import banshi.content: plain-text, fold-linebreaks, trim-tail
#import banshi.layout: resolve-chars
#import banshi.styles as style-rules
#import "../settings/resolve.typ" as settings
#import "../terms/lang.typ": en, find-en, find-en-warning, title-of, split as split-lang
#import "../figure/continued.typ": find-continued
#import "../figure/kinds.typ": find-algorithm
#import "../heading/heading.typ": replace-tocbreak, term-chapter, heading-slot, heading-centered, two-hanzi-title, find-two-hanzi
#import "../case.typ": english-title
#import "../once.typ": once as _once
#import "../terms/lang.typ": normalize as normalize-lang, doc-lang
#import banshi.fonts as fonts
#import banshi.units: twips
#import banshi.runs: cjk-ratio, has-cjk
#import banshi.fonts: boundary-pad
#import banshi.layout: linebreaks-sets, emulated
#import "../layout/parts.typ": layout-for
#import "../styles/presets.typ": list-levels
#import "../styles/lookup.typ": current-styles, resolve-toc-line-spacing
#import "../references/refs.typ" as refs
#import "../heading/numbering.typ" as _numbering
#import "../terms/lookup.typ": term-for, info-variant, term-table
#import "../layout/matter.typ": front-numbering-enter, mainmatter-started
#import "../settings/defaults.typ": toc-front-blank, outline-languages-auto
#import banshi.styles: paragraph
#import banshi.fonts: zihao
#import "../axes.typ": report-stages
#let _toc-tab(layout) = twips(layout.text-width - layout.docgrid.tracking, floor: true)
#let en-warn(name, source, overrides, warning: auto) = {
  if name == none { return name }
  let local = find-en-warning(source)
  let on = if local != auto { local } else { warning != false }
  if not on { return name }
  if cjk-ratio(plain-text(name)) <= 0.5 { return name }
  let t = term-table("en", "table-of-contents", overrides: overrides)
  // 没给英文：中文档里没写 #en，英文档里只写了 #zh
  let s = split-lang(source, lang: doc-lang.get())
  let missing = if doc-lang.get() == "en" { not s.plain and s.en == none } else { s.plain or s.en == none }
  let note = if missing { t.warning-english-missing } else { t.warning-english-cjk }
  name + [ ] + text(fill: rgb("#cc0000"), weight: "bold", note)
}
#import "../heading/numbering.typ": hit-numbering-en
#let _heading-prefix(el) = if el.numbering == none {
  none
} else {
  numbering(el.numbering, ..counter(heading).at(el.location()))
}
#let _heading-peers(level) = query(heading.where(level: level, outlined: true))
#let _right-margin(value, layout) = {
  if value == auto { return 0pt }
  if type(value) != length and not (type(value) == dictionary and "chars" in value) {
    panic(
      "outline-entry-right-margin: expected length, auto, or dictionary with "
        + "\"chars\", found " + str(type(value)),
    )
  }
  resolve-chars(value, layout)
}
#let _number-align(value) = {
  if value == auto or value == none { return none }
  if type(value) == alignment and (value == left or value == right) { return value }
  panic(
    "outline-entry-number-align: expected left, right, none, or auto, found "
      + repr(value),
  )
}
#let _glue-tail(c, tracking) = {
  if type(c) != content { return c }
  if c.has("children") {
    let ks = c.children
    if ks.len() == 0 { return c }
    let last = _glue-tail(ks.last(), tracking)
    if last == ks.last() { return c }
    return (..ks.slice(0, -1), last).join()
  }
  if not c.has("text") { return c }
  let cs = c.text.clusters()
  if cs.len() < 2 { return c }
  let tail = cs.slice(-2)
  if not tail.all(ch => ch.contains(regex("\\p{Han}"))) { return c }
  // 盒子前那一截丢的字距补回来；整条只有两个字时盒子就在行首，前面没有字，不补
  if cs.len() == 2 { return box(tail.join()) }
  cs.slice(0, -2).join() + h(tracking) + box(tail.join())
}

#let entry-rule(
  prefix-of, body-of, peers-of,
  levels: auto, layout: auto, fill: none, heading-body-indent: auto, category: "stem",
  outline-entry-right-margin: auto, outline-entry-number-align: auto,
  bold-chapter: false, degree-level: "doctor",
  stage: "final", lang: "zh",
) = it => context {
  _native.check-outline-entry-show-set()
  let layout = layout-for("toc", layout)
  show: linebreaks-sets.with(layout)
  let levels = if levels != auto { levels } else {
    let s = current-styles()
    (s.toc-1, s.toc-2, s.toc-3, s.toc-4)
  }.map(lv => if lv.at("line-spacing", default: none) == auto {
    lv + (line-spacing: resolve-toc-line-spacing(
      local: auto, degree-level: degree-level, category: category,
      stage: stage, lang: lang,
    ))
  } else { lv })
  let top = _numbering.heading-top.get()
  let rel = it.level - top + 1
  if rel > levels.len() {
    panic(
      "toc: entry at level " + str(rel) + " but only " + str(levels.len())
        + " level style(s) given; lower depth, or add a style (toc-"
        + str(rel) + " in iota-hit(styles:), or a longer levels: array)",
    )
  }
  let lv = levels.at(rel - 1)
  let f = fonts.fontset-state.get().families
  if fill != none and type(fill) != content {
    panic("fill: expected content or none, found " + str(type(fill)))
  }
  let padded(pre) = if pre == none { none } else {
    let head = if plain-text(pre).starts-with(regex("[（［【「『〔《〈]")) { sym.zws } else { none }
    let p = head + pre + sym.zws
    let cjk-tail = has-cjk(plain-text(pre).clusters().last())
    if cjk-tail and measure(p).width != measure(head + pre).width { p } else { head + pre }
  }
  let pre = padded(prefix-of(it.element))
  let bod = fold-linebreaks(replace-tocbreak(body-of(it)))
  if bod == none { return }
  let gap = resolve-chars(
    settings.resolve-heading-body-indent(
      local: heading-body-indent, lang: doc-lang.get(),
      category: category, level: rel,
    ),
    layout,
  )
  let margin = _right-margin(
    if outline-entry-right-margin != auto { outline-entry-right-margin } else {
      settings.setting-of("outline-entry-right-margin")
    },
    layout,
  )
  let number-align = _number-align(
    if outline-entry-number-align != auto { outline-entry-number-align } else {
      settings.setting-of("outline-entry-number-align")
    },
  )
  let latin = not has-cjk(plain-text(pre) + plain-text(bod))
  let bold-here = bold-chapter and rel == 1
  let style = if not latin {
    lv + (if bold-here { (latin-bold: true) } else { (:) })
  } else {
    lv + (if bold-here { (bold: true) } else { (:) })
  }
  let half-tracking = if emulated(layout) { layout.docgrid.tracking / 2 } else { 0pt }
  let first-main = rel == 1 and toc-front-blank.at(degree-level, default: false) and {
    let loc = it.element.location()
    let before = query(heading.where(level: it.level, outlined: true).before(loc, inclusive: false))
    mainmatter-started.at(loc) and before.len() > 0 and not mainmatter-started.at(before.last().location())
  }
  if first-main {
    paragraph(sym.zws, (asian-font: "songti", size: zihao.xiaosi, line-spacing: "single", snap-to-grid: true), layout: layout)
  }
  block(above: 0pt, below: 0pt, width: 100%, {
    show: style-rules.rules.with(style, layout: layout, set-font: true, latin: latin)
    context {
      let styled(p) = if p == none or not has-cjk(plain-text(p)) and not bold-here { p }
        else if bold-here and not has-cjk(plain-text(p)) {
          text(font: f.serif, tracking: half-tracking, weight: "bold", p)
        } else if bold-here { strong(p) } else { p }
      let widths(level) = (
        peers-of(level).map(prefix-of).filter(p => p != none)
          .map(p => measure(styled(padded(p))).width)
      )
      let shove = if number-align == right {
        range(top, it.level)
          .map(k => {
            let w = widths(k)
            if w.len() == 0 { 0pt } else { calc.max(..w) - calc.min(..w) }
          })
          .sum(default: 0pt)
      } else {
        0pt
      }
      let indent = indent(lv, layout: layout).left + shove
      h(indent)
      let pre-latin = latin or (
        bold-here and pre != none and not has-cjk(plain-text(pre))
      )
      // 编号末字是西文（数字、字母、点）就只吃半份字距，丢的也是半份
      let tail-latin = latin or (pre != none and not has-cjk(plain-text(pre).replace("\u{200B}", "").clusters().last()))
      let run-pad = boundary-pad(
        if not emulated(layout) { 0pt } else if tail-latin { layout.docgrid.tracking / 2 } else { layout.docgrid.tracking }
      )
      let column = if number-align == none or pre == none {
        0pt
      } else {
        calc.max(0pt, ..widths(it.level))
      }
      let wide-number = if number-align != left or pre == none { false } else {
        let ps = peers-of(it.level).map(prefix-of).filter(p => p != none)
        ps.any(p => measure(p).width == column and plain-text(p).match(regex("[0-9]{2,}")) != none)
      }
      let pre = if pre == none or latin { pre } else if bold-here and pre-latin {
        text(font: f.serif, tracking: half-tracking, weight: "bold", pre)
      } else if bold-here { strong(pre) } else { pre }
      let hang = if pre == none {
        0pt
      } else if number-align == none {
        measure(pre).width + run-pad + gap
      } else if number-align == left {
        column + run-pad + (if wide-number { gap / 2 } else { gap })
      } else {
        column + run-pad + gap
      }
      let leader-weight = if bold-here { "bold" } else { "regular" }
      let page-number = {
        set text(font: f.serif, weight: leader-weight)
        it.page()
      }
      let page-number-width = measure(page-number).width
      let rm = margin.to-absolute()
      let slot = calc.max(measure(text(font: f.serif)[VIII]).width, measure(text(font: f.serif)[888]).width)
      let min-leader = (1em).to-absolute()
      let margin = calc.max(rm, slot + min-leader, page-number-width + min-leader / 2)
      let col = _toc-tab(layout) - indent - rm
      assert(
        col > 0pt,
        message: "outline-entry-right-margin (" + repr(margin)
          + ") leaves no room for the entry text",
      )
      let is-repeat = fill != none and fill.func() == repeat
      let piece-width = if is-repeat {
        measure(text(font: f.serif, weight: leader-weight, fill.body)).width
      } else {
        0pt
      }
      let piece-gap = if is-repeat { fill.at("gap", default: 0pt).to-absolute() } else { 0pt }
      let piece = piece-width + piece-gap
      let leader = if is-repeat {
        repeat(
          gap: piece-gap, justify: fill.at("justify", default: true),
          std.layout(size => if size.width >= piece-width { box(width: piece-width, fill.body) }),
        )
      } else {
        fill
      }
      let phase = if piece > 0pt {
        calc.rem((layout.margin.left + _toc-tab(layout) - margin).pt(), piece.pt()) * 1pt
      } else {
        0pt
      }
      let phase-tail = if phase > 0pt { piece - phase } else { 0pt }
      let phase-column = if phase-tail - piece-gap <= margin - page-number-width {
        piece-gap - phase-tail
      } else {
        piece-gap - phase-tail + piece
      }
      box(width: col, link(it.element.location(), par(hanging-indent: hang, {
        if pre != none {
          if number-align == right {
            box(width: hang, { h(1fr); pre; h(run-pad + gap) })
          } else {
            box(width: hang, pre)
          }
        }
        _glue-tail(trim-tail(bod), if emulated(layout) { layout.docgrid.tracking } else { 0pt })
        sym.wj
        set text(font: f.serif, weight: leader-weight)
        box(width: 1fr, if fill != none { pad(right: phase-column, align(right, leader)) })
        sym.wj
        box(width: margin - rm, link(it.element.location(), box(width: margin, {
          box(width: 1fr, if is-repeat { pad(left: phase-tail, align(left, leader)) })
          page-number
        })))
      })))
    }
  })
}


#let toc(
  title: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  depth: 3,
  levels: auto,
  overrides: (:),
  heading-body-indent: auto,
  fill: repeat(justify: false)[.],
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  layout: auto,
  lang: auto,
  degree-level: "doctor",
  stage: "final",
  doc-lang: "zh",
  category: "stem",
  title-en: auto,
  once: false,
  warning: auto,
) = {
  if warning not in (auto, true, false) {
    panic("table-of-contents: warning: expected auto, true, or false, found " + repr(warning))
  }
  let want = if lang != auto {
    (normalize-lang(lang),)
  } else if doc-lang == "en" or stage in report-stages {
    (doc-lang,)
  } else {
    outline-languages-auto.at(degree-level, default: ("zh",))
  }
  let single = want.len() == 1
  front-numbering-enter(openright: openright)
  if once { for l in want { _once("table-of-contents", key: l) } }
  if "zh" in want {
  term-chapter(
    "table-of-contents", lang: "zh", title: title,
    overrides: overrides, two-hanzi: two-hanzi, outlined: outlined == true,
    single: single, openright: openright,
  )
  {
    show outline.entry: entry-rule(
      _heading-prefix, it => two-hanzi-title(title-of(it.element.body, "zh"), centered: heading-centered(it.element), local: find-two-hanzi(it.element.body)), _heading-peers,
      levels: levels, layout: layout, fill: fill,
      heading-body-indent: heading-body-indent,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
      category: category, degree-level: degree-level, stage: stage, lang: doc-lang,
    )
    context [#outline(title: none, depth: depth + _numbering.heading-top.get() - 1) <iota-outline>]
  }
  }
  if "en" in want {
    term-chapter(
      "table-of-contents", lang: "en", title: title-en,
      overrides: overrides, bold: true, outlined: outlined == true,
      single: single, openright: openright,
    )
    {
      show outline.entry: entry-rule(
        el => if el.numbering == none {
          none
        } else {
          let loc = el.location()
          let nums = counter(heading).at(loc)
          let pat = _numbering.appendix-numbering.at(loc)
          if pat == none {
            (_numbering.resolve-numbering-en(
              auto, category: category, stage: stage,
            ))(..nums.slice(_numbering.heading-top.at(loc) - 1))
          } else if nums.len() != 1 {
            _heading-prefix(el)
          } else {
            (
              term-table("en", "appendix", overrides: overrides).title
                + (
                  if _numbering.appendix-single.at(loc) { "" }
                  else { " " + _numbering.appendix-mark-en(pat, nums.first()) }
                )
            )
          }
        },
        it => en-warn(english-title(title-of(it.element.body, "en"), slot: heading-slot(it.element)), it.element.body, overrides, warning: warning),
        _heading-peers,
        levels: levels, layout: layout, fill: fill,
        heading-body-indent: heading-body-indent,
        outline-entry-right-margin: outline-entry-right-margin,
        outline-entry-number-align: outline-entry-number-align,
        category: category, degree-level: degree-level, stage: stage, lang: doc-lang,
        bold-chapter: true,
      )
      context [#outline(title: none, depth: depth + _numbering.heading-top.get() - 1) <iota-outline>]
    }
  }
}
