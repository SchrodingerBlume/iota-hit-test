// 目录，以及目录条目那一套排法（entry-rule：编号列、点线、页码、折行）——图表公式索引三页
// （./lists.typ）也用它。
//
// *终稿与开题（中期）报告都排这一页。* 目录不按「谁用」分文件——第一层
// 说的是「这是什么」，谁在用写在这儿一句话就够了。
//
// 照 Word 范例排——本科取「1-8 页+规范章补全+中英摘要 本科毕业论文书写范例
// （理工类）.docx」的第六页。
//
// 与摘要页一样，这一档*只发内容、不发页面*：目录是正文版面里的一页，
// 页面、页眉页脚归 iota-hit 管。
//
//   项    内容        样式    字体        左缩进      行距    实测 x
//   81    目  录      样式1   （章标题）   —          1.25    居中
//   82+   章级条目    TOC1    *黑体*  0          1.25    85.0
//          节级条目    TOC2    宋体        240 缇=12pt 1.25    97.0
//          条级条目    TOC3    宋体        480 缇=24pt 1.25    109.0
//          （款项级    TOC4    宋体        720 缇=36pt 1.25    范例没排，depth: 4 才出）
//
// 字号是*小四 12pt*——docx 里那个 w:sz val="21"（10.5）是 ¶ 的，不是正文的，
// run 上没写字号，继承 Normal 的 sz24。
//
// *点线与右制表位。* <w:tab w:val="right" w:leader="dot" w:pos="8494"/>，
// 8494 缇 = 424.7pt，页码右缘落在 85.05 + 424.7 = 509.75——*不是*版心右缘
// 425.15。差的这 0.45 看着小，但点线是逐点排的，右端对不齐一眼就看得出来，
// 所以条目装在定宽的盒里，不指望 fill 自己停对地方：正文列宽到制表位，末行的
// 尾巴（最短一截点线 + 页码那一格）是实宽的盒粘在末字后面，见 entry-rule。
//
// *点线是右锚定的，点钉在页网格上。* 实测范例第六页：同一点距、页码同为
// 一位数的各条末点恒在 498.20（3.0 点距）/ 497.45（3.25 点距；两位数页码的
// 492.20，罗马页码 I 的 501.17），首点随正文长短变；首点对点距取余一律 0.05~0.15
// （Word 把落笔量化到 1/300 英寸，0.24 一档），即点的原点是*页左缘*；正文
// 末字右缘到首点空 0.56~3.44，是贪心填格剩下的余数。三条性质我们都照排。
//
// *行距那几档看着杂，其实是中西文行高混排。* 实测 18.75 / 18.03 / 19.50 /
// 19.27，全部由「上块行深 + 下块上升部」解释：
//
//   摘要 → Abstract   行深(汉字 7.28) + 上升部(西文 11.27) = 18.55   实测 18.75
//   Abstract → 第1章  行深(西文 5.98) + 上升部(汉字 12.18) = 18.16   实测 18.03
//
// 这一套正文引擎已经在做，目录这边不用另写。

#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: indent
#import banshi.content: plain-text, fold-linebreaks, trim-tail
#import banshi.layout: resolve-chars
#import banshi.styles as style-rules
#import "../settings/resolve.typ" as settings
#import "../terms/lang.typ": en, find-en, find-en-warning, title-of
#import "../figure/continued.typ": find-continued
#import "../figure/kinds.typ": find-algorithm
#import "../heading/heading.typ": replace-tocbreak, term-chapter, heading-slot, heading-centered, two-hanzi-title, find-two-hanzi
#import banshi.fonts: english-title
#import banshi.errors: once as _once
#import "../terms/lang.typ": normalize as normalize-lang, doc-lang
#import banshi.fonts as fonts
#import banshi.units: twips
#import banshi.runs: latin-run, cjk-ratio, has-cjk
// *只借它当默认值*：目录两档都出，而报告那一档要传自己的版面进来。
// 一个默认值上的依赖，不是逻辑上的
#import banshi.layout: linebreaks-sets, emulated
#import "../layout/parts.typ": layout-for
// 图表索引条目的取值住 src/styles/presets.typ；目录四级从样式表（toc-1/2/3/4）取，
// iota-hit(styles:) 并好写进 styles-state，这里在 context 里读
#import "../styles/presets.typ": list-levels
#import "../styles/lookup.typ": current-styles, resolve-toc-line-spacing
#import "../references/refs.typ" as refs
#import "../heading/numbering.typ" as _numbering
#import "../terms/lookup.typ": term-for, info-variant, term-table
#import "../layout/matter.typ": front-numbering-enter
#import "../axes.typ": report-stages

// 右制表位：点线与页码右缘停在这里。
//
// *按本节的版心算，不写死。* 出处是范例 TOC 域的 w:tab w:pos="8494" 缇 ＝
// 424.7pt——那正是那一档的版心宽（425.20）减末字省掉的那一份字距增量（0.4543，
// 见 banshi/src/paragraph/spacing.typ 的 line-end-slack），再落到整缇上：425.20 − 0.4543 ＝
// 424.7457 ＝ 8494.9 缇 → 8494 → 424.7，与文件里的数分毫不差。
//
// *先前写死 424.7pt*，于是版心不是 425.20 的那些档全偏——报告那两档的版心
// 宽 453.54，目录的点线停在 495.6，右边白出 34.8（实测），看着整张目录往左歪。
// 报告那两档没有字符网格（char-pitch 不写），增量是 0，制表位就是版心宽。
#let _toc-tab(layout) = twips(layout.text-width - layout.docgrid.tracking, floor: true)

// 英文那一侧印出来的名读着是中文时，在后面缀一句红字。*目录与插图、表格
// 索引共用这一件*——它们都是目录，而题注比章标题更少有人挂英文名（实测英文档的
// List of Figures 里照印「图 6-1 仿真结果的对比」，先前一声不吭）。
//
// *判据是汉字占比过半，不是「含汉字」。* 英文档里裸的标题本来就落进英文
// 那一侧，英文名里带中文书名、人名、拉丁学名都是正当的，一见汉字就报会把这些
// 全打中。占比的算法见 banshi/src/runs.typ 的 cjk-ratio。
//
// *说哪一句看写没写 #en[…]*，那是唯一一件查得出来的事；写了个空的算没写，
// 见 src/terms/lang.typ 的 find-en。词条在 toc 桶，两处共用一份。
//
// *只提示不拦编译*：与封面排不下那一处同一个取舍——论文还得交，拦住不如
// 让作者一眼看见。
//
// 关法两级：warning 是这一页的（#table-of-contents(warning: false)、清单同名），
// 记号里 #en(warning: false) 就地关一条、true 就地开——就地的压过页的
#let en-warn(name, source, overrides, warning: auto) = {
  if name == none { return name }
  let local = find-en-warning(source)
  let on = if local != auto { local } else { warning != false }
  if not on { return name }
  if cjk-ratio(plain-text(name)) <= 0.5 { return name }
  let t = term-table("en", "table-of-contents", overrides: overrides)
  let note = if find-en(source) == none { t.warning-english-missing } else { t.warning-english-cjk }
  name + [ ] + text(fill: rgb("#cc0000"), weight: "bold", note)
}

// 英文目录的编号。范例是「Chapter 1  Introduction」「1.1  Background…」
// 「1.2.1  …」——一级写成 Chapter n，二三级是点号数字，与中文那套
// （第 n 章 / 1.1 / 1.2.1）同一个计数器、两种写法。
// *三份预设住在一处*，见 src/heading/numbering.typ
#import "../heading/numbering.typ": hit-numbering-en

// 标题的编号，与 outline.entry.prefix() 同一个式子：numbering(标题的 numbering,
// ..计数器在标题处的值)。收元素不收条目，取列时要量同级每一条，见 entry-rule
#let _heading-prefix(el) = if el.numbering == none {
  none
} else {
  numbering(el.numbering, ..counter(heading).at(el.location()))
}

// 某一级进目录的标题。不编号的（摘要那些）由 _heading-prefix 给 none，量列宽时
// 滤掉。收级别不收条目：right 档要往上看每一级的列，见 entry-rule
#let _heading-peers(level) = query(heading.where(level: level, outlined: true))

// 目录与索引共用的一条条目规则。*提到模块层*是为了图表索引也能用它——
// 那两份与目录是同一套排法（缩进、编号列、点线到右制表位、折行悬挂），
// 只是条目来自 figure 而不是 heading，见下面的 lof / lot。
// bold-chapter：英文目录里章级条目加粗。实测研究生范例第九页——
// 「Chapter 1  Introduction」是 TimesNewRomanPS-BoldMT，节级与条级是常规体；
// 与 hithesis 写进 .toe 的 \bfseries #4 一致（hit-thesis.cls:7636）。中文目录
// 那边不加粗：同一份文档里中文目录的「Abstract」是 TimesNewRomanPSMT，本科范例
// 也是——所以这是英文目录*独有*的一档，不能挂到 toc-1～toc-4 上。
//
// *点线与页码跟着章级条目一起粗。* Word 里引导点是制表符那个 run 排的、页码是
// 同一段里的 PAGEREF 域，都吃 TOC1 样式上的 w:b：深圳本科英文开题与中期的目录，
// 章级那几行的点与页码都是 TimesNewRomanPS-BoldMT（粗体句点大一圈、墨迹中心高
// 0.7，常规点排在粗字旁边看着就是矮一截）。研究生范例第九页的点是常规体，但那一页
// 是手打的（字面句点、左制表位，见 tests/check-toc-en.py），不是 TOC 样式排出来的，
// 不算数。中文目录章级不加粗，点与页码自然也不粗。
// 条目正文*每一行*右边留多宽。auto ＝ 0：正文一直排到制表位，只有末行给点线
// 与页码让路（Word 与范例的排法，见下面条目规则里的说明）；写 4em 就是 hithesis
// 那种每行提前折。依据见 src/settings/defaults.typ 的 outline-entry-right-margin；
// 也收长度与 (chars: n)，与目录里别的量同形，见 banshi/src/layout/chars.typ 的 resolve-chars。
#let _right-margin(value, layout) = {
  if value == auto { return 0pt }
  // 报错要点出是哪个参数：resolve-chars 那句只说「expected length …」，
  // 与 heading-body-indent 写坏了一字不差，用户分不出是哪一个
  if type(value) != length and not (type(value) == dictionary and "chars" in value) {
    panic(
      "outline-entry-right-margin: expected length, auto, or dictionary with "
        + "\"chars\", found " + str(type(value)),
    )
  }
  resolve-chars(value, layout)
}

// 编号怎么摆，见 src/settings/defaults.typ 的 outline-entry-number-align。
// auto 与 none 都是「不取列」（跟着各自编号的宽度走，范例的排法）；left / right 收
// alignment，与原生 align 同型——写成字符串 "left" 的照 Typst 的口径报错。
#let _number-align(value) = {
  if value == auto or value == none { return none }
  if type(value) == alignment and (value == left or value == right) { return value }
  panic(
    "outline-entry-number-align: expected left, right, none, or auto, found "
      + repr(value),
  )
}

// 目录与索引共用的一条条目规则。三个取值函数：
//
//   prefix-of(元素)   这一条的编号。*收元素不收条目*——取列要量这一级
//                     *所有*条目的编号，别的条目只拿得到元素
//   body-of(条目)     这一条的标题
//   peers-of(级别)    这一级要进这份目录的元素——量列宽用；right 档连上面
//                     几级也量，见下
// *中文题名末尾两个字粘住*：尾巴退下去时至少带两个字，不留「研｜究」这种半个词
// （西文本来就按词退，不动）。只动最后一个文本元素的最后两个汉字，别处的折点照旧；
// 末尾不是两个汉字（标点、西文、公式）就原样交回，不重发。
#let _glue-tail(c, tracking) = {
  if type(c) != content { return c }
  if c.has("children") {
    let ks = c.children
    if ks.len() == 0 { return c }
    let last = _glue-tail(ks.last(), tracking)
    if last == ks.last() { return c }
    return (..ks.slice(0, -1), last).join()
  }
  if not c.has("text") { return c }
  let cs = c.text.clusters()
  if cs.len() < 2 { return c }
  let tail = cs.slice(-2)
  if not tail.all(ch => ch.contains(regex("\\p{Han}"))) { return c }
  // *装进一个盒*而不是夹 wj：wj 是个 run 边界，前一个字的字距在那儿丢掉（上游 #5353，
  // 见 banshi/src/runs.typ），两个字之间就窄 0.45；盒里两个字是一个 run，丢的那份挪到盒前面，
  // 在那儿补一份 h——h 本身是折点，正好就是要折的地方
  cs.slice(0, -2).join() + h(tracking) + box(tail.join())
}

#let entry-rule(
  prefix-of, body-of, peers-of,
  levels: auto, layout: auto, fill: none, heading-body-indent: auto, category: "stem",
  outline-entry-right-margin: auto, outline-entry-number-align: auto,
  bold-chapter: false, degree-level: "doctor",
  // *条目行距按这两样再分一档*：本科英文报告 1.5 倍，见
  // src/styles/presets.typ 的 variant-styles（toc-line-spacing 那几条）。*参数叫 lang 不叫
  // doc-lang*——这一支里的 doc-lang 是那个 state（下面 heading-body-indent 那处
  // 读的就是它），同名会盖掉
  stage: "final", lang: "zh",
) = it => context {
  // 页面设置在这儿才折：条目规则是在 context 里排的，page-setup-state 只有这里读得到
  let layout = layout-for("toc", layout)
  // 引擎画字符网格那一档：这一页的 set par(linebreaks:)（没给 --input linebreaks 就什么都不发），见 banshi/src/layout/resolve.typ
  show: linebreaks-sets.with(layout)
  // 每级一条样式（含 left-indent）。auto 取样式表的 toc-1/2/3/4；行距写 auto 的
  // 按学科与学位填（理工本科 1.25、研究生 1.2；人文固定值 23 磅，见
  // src/styles/presets.typ 的 toc-line-spacing-auto）
  let levels = if levels != auto { levels } else {
    let s = current-styles()
    (s.toc-1, s.toc-2, s.toc-3, s.toc-4)
  }.map(lv => if lv.at("line-spacing", default: none) == auto {
    lv + (line-spacing: resolve-toc-line-spacing(
      local: auto, degree-level: degree-level, category: category,
      stage: stage, lang: lang,
    ))
  } else { lv })
  // *收到的级数比样式多就报错，不借上一级的档。* 先前 depth: 4 配三条样式
  // 时第四级静默套第三级的缩进，与条级平齐、看不出是下一级；写错了得当场知道
  if it.level > levels.len() {
    panic(
      "toc: entry at level " + str(it.level) + " but only " + str(levels.len())
        + " level style(s) given; lower depth, or add a style (toc-"
        + str(it.level) + " in iota-hit(styles:), or a longer levels: array)",
    )
  }
  let lv = levels.at(it.level - 1)
  let f = fonts.fontset-state.get().families
  // 与原生 outline(fill:) 同一句话报错；不守的话下面 fill.func() 报的是
  // 「type string has no method func」
  if fill != none and type(fill) != content {
    panic("fill: expected content or none, found " + str(type(fill)))
  }
  // *编号末尾垫一个零宽空格。* 人文社科档的编号以顿号或右括号收尾
  // （一、／（一）），而编号在这里是单独量、单独放进一个 box 的——Typst 的 CJK
  // 标点挤压把*末尾*的全角标点压成半格，量出来的宽度跟着缩，标题就贴上去了
  // （实测 measure[一、] 得 18.45，加一个零宽空格才是 24.45 ＝ 两整格；页面上
  // 目录里的「、」只占 6.455，正文里是整格）。垫在这里而不是排的时候垫——
  // 宽度与排版要用*同一份内容*，只垫一头就还是压。
  // 与内封密级行、声明页那两处同一招，见 src/pages/front.typ
  // *只在真被压了的时候垫。* 判据就是量一量：垫上零宽空格之后宽度变了，
  // 说明末尾那个标点原来被压了。理工那两档的编号以数字或「章」收尾，垫不垫一样宽，
  // 于是一个不可见字符都不多发（PDF 里复制出来的字也就干净）。
  // 取列时量同级各条编号也走它——列宽与本条的 hang 得按同一种内容量，否则人文档
  // 「（一）」的列宽比本条窄半个字，题名叠到括号上
  // *头上也垫*：编号以全角开括号起头（人文社科条级「（一）」），Typst 把行首的开标点
  // 压成半格、字形往左挪半个字——条目在 Word 里起于 109.0，我们 102.8。垫了就不在
  // 行首，不压；理工的编号不以标点起头，一个字符都不多发。正文标题同一招，见
  // src/heading/rules.typ
  let padded(pre) = if pre == none { none } else {
    let head = if plain-text(pre).starts-with(regex("[（［【「『〔《〈]")) { sym.zws } else { none }
    let p = head + pre + sym.zws
    if measure(p).width != measure(head + pre).width { p } else { head + pre }
  }
  let pre = padded(prefix-of(it.element))
  // 标题里的 #tocbreak() 记号在这儿换成换行，见 src/heading/heading.typ 的 replace-tocbreak
  // *条目里手动换的行折掉，整条排成一行。* 声明页那个词条是两行的
  // （「哈尔滨工业大学本科毕业论文（设计）\ 原创性声明和使用权限」，页面上要分两行），
  // 带进目录就成了：头一行没有引点也没有页码，看着像条目坏了。两份范例的目录里这一条
  // 都是*一行*——本科范例第 6 页「哈尔滨工业大学本科毕业论文原创性声明和使用权限......」，
  // 博士范例第 8 页同理。汉字之间折掉不留空格（先前用 show linebreak 折，「\ 」后面
  // 那个 space 元素留了下来，条目里多一个空格）、西文之间留一个，见 fold-linebreaks；
  // #tocbreak() 换出来的那一种（justify: true）留下
  let bod = fold-linebreaks(replace-tocbreak(body-of(it)))
  // 名字一份都没有才不排（term-chapter 的 outlined: false 那一档）
  if bod == none { return }
  // 编号与标题之间空多少。*就是全局那个 heading-body-indent*——目录里的
  // 这一段和正文标题里的那一段是同一件事，没有理由各起一个名字。只改这一页
  // 就写 #toc(heading-body-indent: …)——那是这一页的具名参数，登记在
  // src/settings/defaults.typ 的 setting-homes 里。
  //
  // 局部 → 全局 → 默认，每一层都用 auto 表示「我不表态」。默认那一档*按文档
  // 语言*解成一个字或半个字（en 档暂定，见 src/settings/defaults.typ 的
  // heading-body-indent-auto）；中文档与范例一致：按字形原点量，「章」到「绪」的
  // 步进 25.00，正是一个汉字 12.4543 加一个全宽空格 12.55（实测我们 24.91）。
  // *中文档的英文目录也空一个字*——读的是 doc-lang，不是这份目录的语言，
  // 两份目录的编号列才对得齐。
  //
  // 收一个长度，或 (chars: n)——「几个字」那一档走 banshi 的 chars，一个字就是
  // *字号 + 网格字距增量*，不是 1em：那是字身宽，不含网格那份 0.4543。
  //
  // 编号末字丢掉的那份 tracking 另补，不并进这里——那是 Typst 的 run 边界行为
  // （每个 text run *最后一个*字形的 tracking 会被丢掉，编号自成一个 run，
  // 「章」因此只占 12.00），与用户写的间距不是一回事。补法见下面的 h()。
  // *按本级取*——人文社科档节与条不空、款空半个字，见 src/settings/defaults.typ
  // 的 heading-body-indent-auto
  let gap = resolve-chars(
    settings.resolve-heading-body-indent(
      local: heading-body-indent, lang: doc-lang.get(),
      category: category, level: it.level,
    ),
    layout,
  )
  // 正文右边留多宽。局部 → 全局 → 默认，与上面 heading-body-indent 同一套三层；
  // 这一条三份目录（目录、插图索引、表格索引）共用，登记在 setting-homes 里。
  // 这里解出来的还可能带 em，折成绝对量要在字号定了之后，见下面。
  let margin = _right-margin(
    if outline-entry-right-margin != auto { outline-entry-right-margin } else {
      settings.setting-of("outline-entry-right-margin")
    },
    layout,
  )
  // 编号怎么摆，同一套三层
  let number-align = _number-align(
    if outline-entry-number-align != auto { outline-entry-number-align } else {
      settings.setting-of("outline-entry-number-align")
    },
  )
  // *整条是纯西文就换西文行高*（范例里「Abstract」那一条，英文目录则
  // 整页如此）。
  //
  // 靠 styles.latin-line-rules 逐 run 换不行：整条包在一个定宽 box 里，而 latin-run
  // 匹配的是*文本*，罩不到盒子——行高仍由外围的汉字基准定，实测那一条
  // 的步进是 19.45 而不是 Word 的 18.75。改判整条，把基准本身换掉。
  //
  // 纯西文那一条（font-zh: "latin"）的字距由 style-rules.rules 直接 set 成半格，不发
  // 「run 边界补字距」那条规则——那一档是为夹在汉字中间的西文准备的，而这里西文是
  // *整条的头一个 run*，前面没有字可补，补出来就是一段假缩进（实测「Abstract」
  // 的 A 落在 85.50，Word 85.03）。见 banshi/src/paragraph/latin.typ 的 pure-latin。
  let latin = not has-cjk(plain-text(pre) + plain-text(bod))
  // *章级加粗与「这条是不是纯西文」是两回事。* 先前加粗写在纯西文那一支里，
  // 于是*章标题没挂英文名时「Chapter 2」也跟着不加粗*了——那一条因为回落成
  // 中文标题而含汉字，走了另一支（实测「Chapter 1」是 TimesNewRomanPS-BoldMT、
  // 「Chapter 2」掉成 TimesNewRomanPSMT）。范例里英文目录的章级条目一律加粗，
  // 与标题是中是英无关，所以拆出来。
  let bold-here = bold-chapter and it.level == 1
  // 混排的章级条目只加粗西文（latin-bold，理由见下面 trim-tail 那一处）：走 style-rules.rules 里
  // latin-bold 那一路——整段 set weight，黑体落空、Times 换上真粗面，「Chapter 2」的数字、
  // 正身里的缩写都在里面；先前这儿自己挂 show latin-run，数字够不着
  let style = if not latin {
    lv + (if bold-here { (latin-bold: true) } else { (:) })
  } else {
    lv + (font-zh: "latin", font: "serif") + (if bold-here { (bold: true) } else { (:) })
  }
  // 编号里的西文那半份字距。引擎自己画网格时不发（见 banshi/src/layout/resolve.typ 的「断行引擎」）
  let half-tracking = if emulated(layout) { layout.docgrid.tracking / 2 } else { 0pt }
  block(above: 0pt, below: 0pt, width: 100%, {
    // 半宽的西文在 Word 的字符网格里吃半格增量：实测范例的「Abstract」逐字步进比
    // 字身宽平均多 0.20（Word 还会把每个落笔量化到 1/300 英寸，所以逐字不齐），
    // style-rules.rules 给纯西文段 set 的正是 0.227。审阅时量过没吃到增量的样子：「Abstract」
    // 逐字步进是裸的字身 8.66 / 6.0 / 4.67…（合计 40.66），范例 8.77 / 6.24 / 4.99…（42.04）。
    show: style-rules.rules.with(style, layout: layout, set-font: true)
    context {
      // *right 档下一级要再往右让。* 编号靠右取列时，窄的编号被推向右边，
      // 「第1章」不再顶在缩进处而是在列缘减自己的宽处；章多到「第100章」时它就
      // 推到了节的缩进上，一二级平齐。none 档每级编号都顶着各自的缩进，级差一个
      // 字。所以 right 档下面每一级的缩进都加上*上面各级里最窄编号被推开的
      // 那一段*（列宽减最窄编号宽），最窄的上级编号与本级编号之间仍差一个缩进，
      // 观感与 none 一致。列宽只在 left / right 才量，默认档一个都不多量。
      // 同级各条编号的宽：垫法与样式都与本条的 pre 同一套（见下面 styled），列宽才
      // 与本条落笔一致——英文目录的章级加粗后「Chapter 1」比常规宽 3.33，只量
      // 常规宽的话列比字窄，题名叠上去
      let styled(p) = if p == none or not has-cjk(plain-text(p)) and not bold-here { p }
        else if bold-here and not has-cjk(plain-text(p)) {
          text(font: f.serif, tracking: half-tracking, weight: "bold", p)
        } else if bold-here { strong(p) } else { p }
      let widths(level) = (
        peers-of(level).map(prefix-of).filter(p => p != none)
          .map(p => measure(styled(padded(p))).width)
      )
      let shove = if number-align == right {
        range(1, it.level)
          .map(k => {
            let w = widths(k)
            if w.len() == 0 { 0pt } else { calc.max(..w) - calc.min(..w) }
          })
          .sum(default: 0pt)
      } else {
        0pt
      }
      // 整条的左缩进（w:ind left）：样式的 left-indent，(chars: n) 或长度
      let indent = indent(lv, layout: layout).left + shove
      h(indent)
      // 补编号这个 run 末字被丢掉的那份字距，见 gap 的说明。西文吃的是
      // 半格，补的也是半格。
      //
      // *补多少跟编号自己的文种走，不跟整条。* 英文目录里章标题回落成中文的
      // 那一条，整条按汉字排，可编号「Chapter 1」仍是纯西文，吃的还是半格。跟着
      // 整条补整格，正身起点就比纯西文那条右出 0.4543。
      //
      // *只管章级。* 中文目录的「1.1」「1.2.1」也是纯西文，可那两档的间距是
      // 对着范例钉死的（编号末字右缘到标题首字 12.9086），照这条改就掉到 12.6815。
      // 范例怎么排的就怎么留着，见 check-toc.py。
      let pre-latin = latin or (
        bold-here and pre != none and not has-cjk(plain-text(pre))
      )
      let run-pad = (
        if not emulated(layout) { 0pt } else if pre-latin { layout.docgrid.tracking / 2 } else { layout.docgrid.tracking }
      ) * fonts.boundary-loss()
      // *折行的条目缩到标题首字处。*指南 3.6：「对于超过一行的目录
      // 内容提前换行，换行后缩进至相应标题第一个字符处」。标题起排的位置就是
      // 编号占的宽度加间距，三级同一条规则，见 src/styles/presets.typ 的 toc-1～toc-4；编号占多宽按
      // number-align 分三档，见 src/settings/defaults.typ：
      //
      //   none   这一条自己的编号宽 + 一个字
      //   left   这一级最宽的编号 + 一个字，编号靠左；最宽的编号
      //          里有两位以上的数（第10章、1.10）时只空半个字——列已经被那一位数字
      //          撑宽了半个字，再空整字题名就漂远了，半个字正好把它拉回一位数时的位置
      //   right  这一级最宽的编号 + 一个字，编号靠右贴齐列缘
      //
      // 量在这里做：外面还没进 style-rules.rules 的字体与字距，量出来会短。取列时把
      // 同级的每条编号都量一遍——只在 left / right 才做，默认档一个都不多量。
      // 无编号的条目（摘要那种）不进列，标题顶着缩进起排，与 hithesis 一致。
      let column = if number-align == none or pre == none {
        0pt
      } else {
        calc.max(0pt, ..widths(it.level))
      }
      // left 档的空当：最宽的那条编号里有没有两位以上的数
      let wide-number = if number-align != left or pre == none { false } else {
        let ps = peers-of(it.level).map(prefix-of).filter(p => p != none)
        ps.any(p => measure(p).width == column and plain-text(p).match(regex("[0-9]{2,}")) != none)
      }
      // *量的必须是排出来的那一份。*下面 hang 走 measure(pre)，而 pre 到了
      // 落笔处还要再套一层样式（见那儿的说明）——不统一就会：纯西文那条的
      // 「Chapter 2」在 style 里带 bold 量到粗体宽，混排那条的「Chapter 1」量到
      // 常规宽，Times 12pt 上差 3.33，两条的正身起点就错开这么多（实测 144.77
      // 与 141.44）。所以先把样式套好，measure 与落笔共用同一个 pre。
      let pre = if pre == none or latin { pre } else if bold-here and pre-latin {
        text(font: f.serif, tracking: half-tracking, weight: "bold", pre)
      } else if bold-here { strong(pre) } else { pre }
      let hang = if pre == none {
        0pt
      } else if number-align == none {
        measure(pre).width + run-pad + gap
      } else if number-align == left {
        column + run-pad + (if wide-number { gap / 2 } else { gap })
      } else {
        column + run-pad + gap
      }
      // *编号装进定宽盒，宽度就是 hang。* 这样标题的起点*按定义*
      // 等于折行的悬挂点，不必指望量出来的宽度与排出来的一致——而它们并不一致：
      // measure 拿不到*段落级*的中西文间距。实测附录那一档「附录B」，
      // 渲染时 录→B 的步进是 15.000（比一格多 2.546，正是中西文间距），
      // 而 measure 给的是 32.91（三个字身加一份字距，一点间距都没有），
      // 于是折行比首行偏左 2.091。box(par(…))、measure(par(…)) 都试过，
      // 三种量法没有一种拿得到那一段（那是 0.12 时代量的；0.15.1 上 measure([第1章])
      // ＝ 53.44 ＝ 字身加两份 1/4 em，已经把中西文间距算进去了，与排出来的盒一样宽，
      // 所以「第1章」的编号串去掉字面空格之后量与排照样一致）。
      //
      // 页码走西文字体，粗细跟着章级条目（理由见抬头 bold-chapter）。点线同样，
      // 见下面那句 set
      let leader-weight = if bold-here { "bold" } else { "regular" }
      let page-number = {
        set text(font: f.serif, weight: leader-weight)
        it.page()
      }
      // *右边距至少要装得下页码。* 页码是从右边距那一格里排出来的（见下），
      // 格比它窄，它就折到下一行去——把这条下限拿掉、边距写 2pt 试过：页码「5」
      // 掉到下一行、落在 507.75~513.75，还越过制表位。所以下限就是页码自己的
      // 宽度（含数字间的网格字距，「26」量出来是 12.4543）：写 0pt 得到的是「正文
      // 只给页码让路」，页码永远不会单独掉行——那正是指南 3.6 那句「提前换行」
      // 要避免的样子；负数同样落到这条下限上，不另报错。em 在这里折成绝对量：
      // 字号到这一层才定下来。
      let page-number-width = measure(page-number).width
      // *正文列只减「每行」那份右边距（默认 0），末行另给尾巴让路。* 尾巴 =
      // 最短一截点线 + 页码那一格，装进一个*实宽*的盒粘在末字后面（见下），
      // 折行器看得见它：末行装不下就把最后一个词一起退下去，页码永不独占一行；
      // 非末行排到制表位。这是 LaTeX \@dottedtocline 里 \nobreak + \@pnumwidth
      // 的做法，也是 Word 范例的几何——范例英文目录「Chapter 4 … FLUENT software」
      // 加粗后 444.67 超过版心 424.7，去掉 software 正好装下，Word 就在 software 前折。
      //
      // *页码那一格取固定宽，不读本条页码*：末行约束要是跟着本条页码宽变，
      // 罗马页码 VIII→IX 变窄时布局回路会来回震荡（实测 did not converge）。格取
      // 「VIII」与三位数取大者；本条页码真比它还宽（XVIII 那种）只作下限兜底。
      // 显式写了每行右边距（4em 那档）时尾巴宽取它，实宽盒退成零宽——与先前
      // hithesis 式的排法一字不差。
      let rm = margin.to-absolute()
      let slot = calc.max(measure(text(font: f.serif)[VIII]).width, measure(text(font: f.serif)[888]).width)
      let min-leader = (1em).to-absolute()
      let margin = calc.max(rm, slot + min-leader, page-number-width + min-leader / 2)
      let col = _toc-tab(layout) - indent - rm
      assert(
        col > 0pt,
        message: "outline-entry-right-margin (" + repr(margin)
          + ") leaves no room for the entry text",
      )
      // *点钉在 Word 的网格上。* 范例的点以页左缘为原点、按点距排成一张网格
      // （见文件头）。两段点线各自堆到列缘，列缘的绝对坐标已知（左页边 + 制表位
      // − 右边距），把它对点距的余数垫在列内那段的右边、补数垫在右边距那段的
      // 左边，两段的点就都落在网格上。实测本科目录：末点 498.00，范例 498.20，
      // 差在 Word 的量化档 0.24 之内。
      //
      // 左页边取的是这一页 layout 的：#toc(layout:) 与文档的 layout 左页边不同时，
      // 两段仍共一个原点（接缝照旧），只是原点不再是页左缘。
      //
      // 点距只认 repeat（body 的宽加 gap）——别的 fill 不知道点距，不垫，也只排
      // 在正文列那一段（原生 outline(fill:) 也只排一次）。
      let is-repeat = fill != none and fill.func() == repeat
      let piece-width = if is-repeat {
        measure(text(font: f.serif, weight: leader-weight, fill.body)).width
      } else {
        0pt
      }
      let piece-gap = if is-repeat { fill.at("gap", default: 0pt).to-absolute() } else { 0pt }
      let piece = piece-width + piece-gap
      // *格子自己看区域，装不下一个就交白卷。* 列内那段的盒子有时只剩不到
      // 一个点宽（正文末字恰好停在列缘前 0~3pt）。repeat 算个数是
      // ⌊(区域 + gap) / (格宽 + gap)⌋，而格子是*在那个区域里*排出来的：区域比
      // 字身窄，格子就被夹成区域那么宽，个数算出来是 1，于是靠右排出一个*整点*
      // 向左压在末字上——审阅时 921 条里撞上 30 条，最多压 2.86；把「.」装进定宽盒
      // 也一样被夹（实测 2pt 宽的盒照样排出一个点）。所以让格子用 layout 看一眼
      // 区域，比字身窄就给空内容，宽度为零的格子 repeat 一个都不排。
      //
      // *layout 只能放在格子这一层。* 放在 fr 盒的正身上量出来的宽不对（实测
      // 同一行只排出三个点）；repeat 递给格子的区域才是它真正填的那一段。
      // 写 std.layout 是因为这个函数的 layout 参数（版面）把原生的那个盖住了。
      let leader = if is-repeat {
        repeat(
          gap: piece-gap, justify: fill.at("justify", default: true),
          std.layout(size => if size.width >= piece-width { box(width: piece-width, fill.body) }),
        )
      } else {
        fill
      }
      let phase = if piece > 0pt {
        calc.rem((layout.margin.left + _toc-tab(layout) - margin).pt(), piece.pt()) * 1pt
      } else {
        0pt
      }
      // *跨着列缘的那个格子归列内那段。* 余数不为零时网格上正好有一个点
      // 跨在列缘上（原点在列缘前、右缘在列缘后），两段各自都装不下它，接缝处
      // 就空出一格——实测 456 → 462 跳了 6.0。所以列内那段的右边不是垫余数，
      // 而是*放宽*到那个格子的右缘（负的 pad），点线越过列缘那一小截落在
      // 右边距那段垫出来的空当里，两段严丝合缝。
      //
      // *repeat 的 gap 只在点与点之间*，右堆的末点右缘贴着盒缘、后面没有
      // 那一份，格子的边界在末点右缘再加一个 gap 处——所以两边都从 gap 起算。
      // 审阅时量过：不算这一份，gap: 2pt 的点线接缝处只空 3.0，别处 5.0。
      //
      // *放宽的前提是那一截还是点线的地盘。* 右边距只够装页码时（0pt 那一档），
      // 列缘就是页码左缘，放宽出去的点会压在页码上——实测末点右缘 504.00 对页码
      // 左缘 503.75。那时退回到前一个格子，与 Word 贪心填格到页码为止的规则一样。
      let phase-tail = if phase > 0pt { piece - phase } else { 0pt }
      let phase-column = if phase-tail - piece-gap <= margin - page-number-width {
        piece-gap - phase-tail
      } else {
        piece-gap - phase-tail + piece
      }
      // *正文列宽到制表位，末行给尾巴让路。* 尾巴 = 最短一截点线 + 页码那一格，
      // 是个*实宽*的盒，用 word joiner 粘在末字后面：折行器看得见它，末行装不下
      // 就连最后一个字一起退下去，页码永不独占一行；非末行排到制表位——这就是
      // LaTeX \@dottedtocline 里 \nobreak + \@pnumwidth 的做法，也是 Word 范例的
      // 几何（见上面 rm / margin 那一段）。
      //
      // hithesis 走的是另一半机理（hithesis.dtx:8047）：\rightskip \@tocrmarg 让
      // *每一行*正文在右边距处折，\parfillskip 让末行的 leaders 越过右边距填到
      // 页码。实测它的输出（hithesis-v3.1e-dev.20260128.pdf 第 12 页）：折行条目首行
      // 末字右缘 462.24，页码 504.24。范例不这样，所以那一档只在显式写了每行右边距
      // 时才有：Typst 没有 rightskip，只能把列收窄，尾巴盒退成零宽、内容从列缘溢出
      // 来盖住右边距那一格。
      //
      // 点线分*两段*排：列内一段是 1fr 的盒，填到尾巴左缘为止；尾巴里一段与
      // 页码一起。两段之间夹一个 word joiner，Typst 不会在两个盒之间折。
      //
      // *两段的点要接得上，点得钉在同一张网格上。* 列内那段靠右堆
      // （align(right) + justify: false，余量留在左边），右边距那段靠左堆，两段
      // 于是都以列缘为原点，接缝处的点距与别处一样——实测 tests/demo-toc-margin
      // 第 2 页「析与试验研究以及…」那条：55 个点从 336 到 498 步进全是 3.0，列缘
      // 461.75 在中间看不出来。
      //
      // *右堆本来就比左堆贴范例。* Word 的点线是右锚定的：实测范例第六页，
      // 同一点距、页码同为一位数的各条*末点*恒在 498.20（3.0 点距）/ 497.45
      // （3.25 点距），首点随正文长短变，点贪心填到页码左缘为止；首点对点距取余
      // 都是 0.05~0.15，即 Word 的网格以页左缘为原点。先前的左堆余量在右，末点
      // 逐条不齐，反而不像。
      //
      // *页码右缘停在制表位上*，点线与页码的右缘因此与 Word 对齐——尾巴盒的
      // 右缘就是制表位。
      // *链接得自己挂。* Typst 内建的 outline.entry 规则里整条是个
      // link，指向那个标题；我们把整条从头重排（编号、标题、点线、页码逐样
      // 自己拼），内建那层连同链接一起没了，目录点不动。
      //
      // 整条都可点，与内建的一致——点线和页码也在里面。
      // *直接给 par，不能靠 set。*box 里的 set par(hanging-indent:)
      // 不生效——实测折行仍回到盒子左缘；直接发一个 par 才吃得上。
      // 与摘要页关键词那行、内封密级那行同一个坑。
      box(width: col, link(it.element.location(), par(hanging-indent: hang, {
        // 编号放进宽 hang 的 box，标题因此从悬挂点起排。right 档编号靠右贴列缘
        // （h(1fr) 顶过去），列缘之后那份间距仍在盒里
        if pre != none {
          // *编号的排法跟编号自己，不跟正身。* 整条含汉字时走的是汉字那一档
          // （字距整格、字体中文族），可编号「Chapter 2」本身是纯西文，跟着走就
          // 宽出 1.8、编号末字落在 134.1 而纯西文那条在 132.3，两份条目对不齐。
          //
          // *只在这儿换，不动 hang*：hang 是按同级编号的*未加样式*宽度
          // 取的列宽，跟着改会把整块编号推走（试过，编号从 132.31 跑到 145.90）。
          //
          // *只管英文目录的章级那一条*：二三级的「1.1」在中文目录里也是纯西文，
          // 那一档的间距对着范例钉死（12.9086），一律改会带偏（实测 13.36 / 13.82）。
          // 零宽空格已经并进 pre，见上面
          if number-align == right {
            box(width: hang, { h(1fr); pre; h(run-pad + gap) })
          } else {
            box(width: hang, pre)
          }
        }
        // 末尾的空白要裁掉，否则标题与点线之间多一个空格，见 banshi/src/content.typ 的 trim-tail
        //
        // *混排的章级条目：只有西文加粗。* 章标题没挂英文名时，正身回落成
        // 中文，字体是*黑体*——本来就是重字面，再加粗要走伪粗（描边合成，见
        // banshi/src/fonts/fake.typ），黑体上再描一圈只会把字口糊住。范例里也没有加粗
        // 的汉字标题。夹在里面的西文（缩写、拉丁名、公式符号）有真粗体面，该跟
        // 「Chapter N」一起加粗，否则同一条里编号粗、正身里的 CNN 不粗，看着像漏排。
        //
        // 纯西文那一条整条加粗由 style 的 bold 管（见上），不进这儿。
        _glue-tail(trim-tail(bod), if emulated(layout) { layout.docgrid.tracking } else { 0pt })
        // *末字与尾巴之间不折*：折行器要么把整条尾巴留在末行，要么连最后
        // 一个词一起退下去。「不许在这儿折」的写法 ~ 也是这个字符的近亲
        sym.wj
        // 点线与页码走西文字体，粗细跟着章级条目
        set text(font: f.serif, weight: leader-weight)
        // 列内那段点线：右堆、垫相位，见上
        box(width: 1fr, if fill != none { pad(right: phase-column, align(right, leader)) })
        sym.wj
        // 尾巴那段点线与页码，见上
        //
        // *尾巴那一段要自己挂链接。* Typst 给链接的可点区域就是行内那一项
        // 的盒子，外盒退成零宽时（每行右边距那档）可点区域也是零宽——实测 PDF 里
        // 这一段的注释矩形是 461.75 → 461.75，右边距里的点与页码点不动；盒子里面
        // 的内容不再另发注释。里面再包一层 link，那一层按自己的盒子（尾巴宽）发。
        // 尾巴那一格：外盒占「尾巴宽 − 每行右边距」，内盒按尾巴宽画——每行右边距
        // 为 0 时两者一样宽，折行器按它让路；写了每行右边距时外盒退成零宽，
        // 内容从列缘溢出来盖住右边距那一格（先前的排法），页码右缘照旧落在制表位
        box(width: margin - rm, link(it.element.location(), box(width: margin, {
          box(width: 1fr, if is-repeat { pad(left: phase-tail, align(left, leader)) })
          page-number
        })))
      })))
    }
  })
}


#let toc(
  // auto 取本地化词条，见 src/terms/built-in.typ
  title: auto,
  // 目录标题「目  录」空不空一个字。auto 跟文档级 two-hanzi
  two-hanzi: auto,
  // 要不要从右手页起。auto 跟随所在的 matter，见 src/layout/matter.typ。
  // 中英文两页是一个部件的两截，一并跟着这一个值走。
  openright: auto,
  // 目录自己进不进目录。*auto ＝ 不写 ＝ 不进*——范例里没有这一条；写 true 就进，
  // 博士档中英两页在英文目录里靠词条的 in-english-toc 分辨（Contents (In Chinese) /
  // (In English)），与摘要、清单同一套。清单那边默认是进的（hithesis 也进）
  outlined: auto,
  // 收到第几级。范例到条级（1.2.1）为止，款项级不进目录。
  // 这一项直接透给 outline，用户想收到第几级自己改；写 4 就用样式表的 toc-4，
  // 再多就得自己给 levels，级数不够当场报错，见 entry-rule
  depth: 3,
  // 每级的字体、缩进、行距，一级一条样式。auto 取样式表的 toc-1/2/3/4
  // （iota-hit(styles:) 里改），见 src/styles/presets.typ；那四条的行距按 degree-level 挑
  levels: auto,
  // 只改这一页的词条。文档级的改法见 iota-hit 的同名参数
  overrides: (:),
  // 编号与标题之间空多少，只管这一页。auto 跟文档级的同名参数。
  // 登记在 src/settings/defaults.typ 的 setting-homes 里
  heading-body-indent: auto,
  // 点线。与原生 outline(fill:) 同名同义：给点线的*内容*，none 就不排点线。
  // 范例是句点，走西文字体。装盒的事条目规则自己做——点线分两段排，一段在
  // 正文列里、一段在右边距里，见 entry-rule；给 repeat 的话要写 justify: false，
  // 否则两段各自拉开，接缝处的点距对不上，末点还会贴到页码上。不是 repeat 的
  // 内容只排在正文列那一段。
  fill: repeat(justify: false)[.],
  // 正文右边留多宽，只管这一页。auto 跟文档级的同名参数，见
  // src/settings/defaults.typ；三份目录共用一条，登记在 setting-homes 里
  outline-entry-right-margin: auto,
  // 编号怎么摆，只管这一页。同上
  outline-entry-number-align: auto,
  // 这一页的页面设置：局部字典并到文档＋段那一份上，整份就整份替换
  layout: auto,
  // 排哪几份，与 abstract / titlepage 同义：
  //
  //   auto   模板决定——中文档按学位：博士中英两份，硕士与本科只有中文那份
  //          （照 hithesis 的默认，src/pages/hit-thesis-toc.dtx:130，那边的
  //          开关也是三态）；*英文档只出英文那一份*
  //   "zh"   只出中文目录。英文档想留一份中文目录，写这个再调一次
  //   "en"   只出英文目录。本科想要英文目录，写这个
  lang: auto,
  // 学位。lang: auto 那一档按它定排哪几份（见上），条目行距也按它与学科挑
  // （理工本科 1.25、研究生 1.2；人文 23 磅，见 src/styles/presets.typ 的 toc-line-spacing-auto）
  degree-level: "doctor",
  // 这一份是终稿还是报告：报告只出一份目录／清单，见下面的 want
  stage: "final",
  // 文档语言。同样只有 lang: auto 那一档用得上
  doc-lang: "zh",
  // 学科门类，见 src/axes.typ。编号后的间距按它与本级取
  category: "stem",
  // 英文目录的标题。范例是 Times 加粗小二，与 hithesis 的
  // \engcontentsname（\bfseries Contents）一致
  title-en: auto,
  // 只印一次的检查（按语言计）。*只有公开的包装层开它*（src/pages/front.typ）：
  // 对拍件直接调这一份、在一篇里排好几份变体，不该被拦
  once: false,
  // 英文目录里读着是中文的条目后面发不发红字。auto ＝ 发；false 关这一页的，
  // 单条的关法是 #en(warning: false)，见 en-warn
  warning: auto,
) = {
  if warning not in (auto, true, false) {
    panic("table-of-contents: warning: expected auto, true, or false, found " + repr(warning))
  }
  // 条目的排法，中英两份共用。两份只差取哪个名字，所以把「取编号」「取标题」
  // 拿出来当参数：两份各取自己那一语言的名字，取不到就回落到有的那一份
  // ——见 src/terms/lang.typ 的 title-of。

  // *报告只出一份*，不论学位：中英两版是两份表单（写中文报告用中文那份、
  // 写英文报告用英文那份），不是一份里排两遍。题注同理，见
  // src/settings/defaults.typ 的 caption-bilingual-auto
  let want = if lang != auto {
    (normalize-lang(lang),)
  } else if doc-lang == "en" or stage in report-stages {
    // 英文档只出英文目录。中文档按学位
    (doc-lang,)
  } else if degree-level == "doctor" {
    ("zh", "en")
  } else {
    ("zh",)
  }

  // *目录自己默认不进目录*（范例里没有这一条），写 outlined: true 才进，那时
  // 博士档两页靠词条的 in-english-toc 分开——与清单同一套。共用的那一层见
  // src/heading/heading.typ；不用 outline 内建的 title，那一档进不了我们的章标题制度。
  // 只出一份就叫光名字 Contents，两份才带 (In Chinese) / (In English)；取词条要在
  // context 里，交给 term-chapter 自己取（对拍件直接调这一份、不经 front.typ 的 context）
  let single = want.len() == 1
  // 头一个带页码的前置部件把页码归到 I；*必须排在标题之前*，
  // 否则目录里这一条印的是物理页号，见 src/layout/matter.typ
  front-numbering-enter(openright: openright)
  if once { for l in want { _once("table-of-contents", key: l) } }
  if "zh" in want {
  term-chapter(
    "table-of-contents", lang: "zh", title: title,
    overrides: overrides, two-hanzi: two-hanzi, outlined: outlined == true,
    single: single, openright: openright,
  )
  {
    // 中文目录排的就是标题原文——指南 1.3 与 2.4 都写「包括论文中全部
    // 章、节、条三级标题」，没有短标题这回事，见 src/terms/lang.typ 的 title-of
    show outline.entry: entry-rule(
      // 编号从元素算，与 outline.entry.prefix() 同一个式子：
      // numbering(标题的 numbering, ..计数器在标题处的值)
      // 正身取中文那一份记号里的内容，与英文目录取 #en 的路子一样，不走 it.body()：
      // 那个 body 里字面是由标题自己那个 context 排出来的，#tocbreak() 记号藏在
      // 记号的取值里，条目规则够不着（见 src/heading/heading.typ 的 replace-tocbreak）
      // 居中的两字标题中间空一个字（摘  要、绪  论），左起的节不空；记号里存的是没空的，
      // 见 src/heading/heading.typ 的 two-hanzi
      _heading-prefix, it => two-hanzi-title(title-of(it.element.body, "zh"), centered: heading-centered(it.element), local: find-two-hanzi(it.element.body)), _heading-peers,
      levels: levels, layout: layout, fill: fill,
      heading-body-indent: heading-body-indent,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
      category: category, degree-level: degree-level, stage: stage, lang: doc-lang,
    )
    outline(title: none, depth: depth)
  }
  }

  // 英文目录另起一页——它是个章级标题，章标题自己会发换页
  if "en" in want {
    term-chapter(
      "table-of-contents", lang: "en", title: title-en,
      overrides: overrides, bold: true, outlined: outlined == true,
      single: single, openright: openright,
    )
    {
      show outline.entry: entry-rule(
        // 编号与中文那份同一个计数器，只是换一种写法；不编号的标题
        // （摘要、结论这些）照旧没有编号
        el => if el.numbering == none {
          none
        } else {
          let loc = el.location()
          let nums = counter(heading).at(loc)
          // *附录那几条叫 Appendix，不叫 Chapter。* hithesis 为这一处专门
          // 开了个开关（\ifhit@inappendix，hithesis.dtx:8129），我们读
          // src/heading/numbering.typ 那个状态就够了——它答的正是「这一章在不在附录里、
          // 号那一位怎么印」。二级往下两边一样，是点号数字。
          let pat = _numbering.appendix-numbering.at(loc)
          if pat == none {
            // 英文目录的编号按门类挑：理工「Chapter 1 / 1.1」，人文社科
            // 「Chapter One / 一、/（一）」。*没有这一页自己的开关*——与正文
            // 那一份同理，规范定死的东西不开口子，见 src/heading/numbering.typ
            (_numbering.resolve-numbering-en(
              auto, category: category, stage: stage,
            ))(..nums)
          } else if nums.len() != 1 {
            // *二级往下两边一模一样*（A.1、A.1.1），直接取标题自己那一份——
            // 再拼一遍就是把 src/layout/matter.typ 的编号闭包抄第二遍。
            // 先前这里落到 numbering-en 上，附录的节印成了「1.1」而不是「A.1」。
            _heading-prefix(el)
          } else {
            // 换行会断开表达式（行首的 + 会被当成一元加），整串包在括号里。
            // *人文社科那一档的号在英文目录里也是英文数词*——与「Chapter One」
            // 共用一份表，不能印成「Appendix 一」，见 src/heading/numbering.typ
            (
              term-table("en", "appendix", overrides: overrides).title
                + (
                  // 只有一个附录就不编号，与正文那一份目录、章标题自己一致，
                  // 见 src/layout/matter.typ
                  if _numbering.appendix-single.at(loc) { "" }
                  else { " " + _numbering.appendix-mark-en(pat, nums.first()) }
                )
            )
          }
        },
        // *回落成中文就当场说出来。* 一份英文目录里混着中文条目，十有八九是
        // 漏写了 #en[…]——不该悄悄过去。句式照 Word 自己的「错误！未定义书签。」，
        // 红字与封面那条溢出提示同一个色（#cc0000）。
        //
        // *判据是「这一条读起来是中文的」*——汉字占比过半（cjk-ratio）。
        // 两处都试错过，记在这儿：
        //
        //   按「没写 #en[…]」判   英文档里*裸标题本身就是英文名*
        //                        （= Introduction，见 src/terms/lang.typ 的 title-of），
        //                        于是每一条都报（实测「Chapter 1 Introduction (Error!…)」）
        //   按「含汉字」判        「Research on 汉字 Recognition」这种合法的英文标题
        //                        也报；反过来「基于 CNN 的方法」有拉丁字母，又漏报
        //
        // *写了 #en[…] 的说另一句、语气也不同*：作者表过态，我们只能*猜*
        // 他是不是弄错了，所以是 Warning! 而不是 Error!，措辞也留余地。
        //
        // *只提示不拦编译*：与封面排不下那一处同一个取舍——论文还得交，
        // 拦住不如让作者一眼看见。
        it => en-warn(english-title(title-of(it.element.body, "en"), slot: heading-slot(it.element)), it.element.body, overrides, warning: warning),
        _heading-peers,
        levels: levels, layout: layout, fill: fill,
        heading-body-indent: heading-body-indent,
        outline-entry-right-margin: outline-entry-right-margin,
        outline-entry-number-align: outline-entry-number-align,
        category: category, degree-level: degree-level, stage: stage, lang: doc-lang,
        bold-chapter: true,
      )
      outline(title: none, depth: depth)
    }
  }
}
