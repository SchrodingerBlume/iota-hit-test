// 封面、内封排不排得下：题目先按纯文本折成几行数一数，排不下时在页角发红字提示、不拦编译。

#import "@local/banshi:0.1.0" as banshi
#import banshi.content: plain-text
#import banshi.fonts: zihao

// 按给定宽度把内容折成纯文本行，西文先在空格处断，超长的单词才逐字拆。first 是首行的宽，
// measure-as 给一个 t => content 按那一档字号量。
#let wrap-lines(body, room, size: auto, first: auto, measure-as: auto) = {
  let text-of = if type(body) == str { body } else { plain-text(body) }
  if text-of == none { return () }
  let text-of = text-of.trim()
  if text-of == "" { return () }
  let sized(t) = if measure-as != auto {
    (measure-as)(t)
  } else if size == auto { text(t) } else { text(size: size, t) }
  let fits(t, w) = measure(sized(t)).width <= w
  let first-room = if first == auto { room } else { first }
  let lines = ()
  let cur = ""
  let now = first-room
  for word in text-of.split(" ") {
    let next = if cur == "" { word } else { cur + " " + word }
    if fits(next, now) {
      cur = next
      continue
    }
    if cur != "" {
      lines.push(cur)
      cur = ""
      now = room
    }
    let rest = word
    while not fits(rest, now) and rest.clusters().len() > 1 {
      let take = ""
      for c in rest.clusters() {
        if not fits(take + c, now) { break }
        take += c
      }
      if take == "" { break }
      lines.push(take)
      now = room
      rest = rest.slice(take.len())
    }
    cur = rest
  }
  if cur != "" { lines.push(cur) }
  lines.map(l => l.trim())
}

// Typst 没有「警告」这一档，只有拦编译；为一页封面卡住整篇不合适。走 page 的 foreground 是为了
// 「每一页都有」——溢出时是两页。
#let overflow-note(body, off, lang: "zh") = place(top + left, dx: 8mm, dy: 8mm, block(
  width: 180mm,
  {
    let f = banshi.fonts.fontset-state.get()
    set text(
      size: zihao.xiaoer, fill: rgb("#cc0000"), weight: "bold",
      font: if lang == "en" { f.sans } else { f.heiti }, lang: lang,
      top-edge: "ascender", bottom-edge: "descender",
    )
    set par(leading: 0.5em)
    body
    linebreak()
    off
  },
))
