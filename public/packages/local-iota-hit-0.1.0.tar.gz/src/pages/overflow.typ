
#import "../docxtyp.typ" as banshi
#import banshi.content: plain-text
#import banshi.fonts: zihao
#let wrap-lines(body, room, size: auto, first: auto, measure-as: auto) = {
  let text-of = if type(body) == str { body } else { plain-text(body) }
  if text-of == none { return () }
  let text-of = text-of.trim()
  if text-of == "" { return () }
  let sized(t) = if measure-as != auto {
    (measure-as)(t)
  } else if size == auto { text(t) } else { text(size: size, t) }
  let fits(t, w) = measure(sized(t)).width <= w
  let first-room = if first == auto { room } else { first }
  let lines = ()
  let cur = ""
  let now = first-room
  for word in text-of.split(" ") {
    let next = if cur == "" { word } else { cur + " " + word }
    if fits(next, now) {
      cur = next
      continue
    }
    if cur != "" {
      lines.push(cur)
      cur = ""
      now = room
    }
    let rest = word
    while not fits(rest, now) and rest.clusters().len() > 1 {
      let take = ""
      for c in rest.clusters() {
        if not fits(take + c, now) { break }
        take += c
      }
      if take == "" { break }
      lines.push(take)
      now = room
      rest = rest.slice(take.len())
    }
    cur = rest
  }
  if cur != "" { lines.push(cur) }
  lines.map(l => l.trim())
}
#let overflow-note(body, off, lang: "zh") = place(top + left, dx: 8mm, dy: 8mm, block(
  width: 180mm,
  {
    let f = banshi.fonts.fontset-state.get()
    set text(
      size: zihao.xiaoer, fill: rgb("#cc0000"), weight: "bold",
      font: if lang == "en" { f.sans } else { f.heiti }, lang: lang,
      top-edge: "ascender", bottom-edge: "descender",
    )
    set par(leading: 0.5em)
    body
    linebreak()
    off
  },
))
