// 博后出站报告的封皮与内封：照《出站报告封皮模板》docx 逐段排——Normal 五号、只指定行网格 16.3pt、段距相加，
// 各段的字号、行距、段前段后、首行缩进是那一段的直接格式（缇 ÷ 20 ＝ 磅）
#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
#import banshi.styles: paragraph
#import banshi.content: plain-text
#import "../terms/lookup.typ": term-for
#import "../terms/date.typ" as _date
#import "./overflow.typ": wrap-lines
#import "../info.typ": value-of

#let layout-inputs = (
  line-pitch: 16.3pt, grid: "lines", font-size: zihao.wuhao,
  header: (shown: false), footer: (shown: false),
)
#let _normal = (asian-font: "songti", size: zihao.wuhao, line-spacing: "single", snap-to-grid: true)
#let _sihao = _normal + (size: zihao.sihao)
#let _exact(v) = (line-spacing: (exactly: v))
// 封皮两道题名线与两个日期线：锚在段上的浮动直线（v:line），from / to 从版心左边量、dy 从段顶量
#let _title-rule = (from: 76.3pt, to: 337.9pt)
#let _date-rule = (from: 174.4pt, to: 348.8pt)
// place 不能进段落：放在锚段前一个零高的块里。Word 的 dy 从锚段段前之上量起，零高块正好在那儿
#let _rule(r, dy) = block(width: 100%, height: 0pt, above: 0pt, below: 0pt,
  place(top + left, dx: r.from, dy: dy, line(length: r.to - r.from, stroke: 0.75pt)))

// 下划线填空：Word 是一串带下划线的空格（半角空格在这份文档里是半个字宽），线在基线下 1.5 起、0.75 粗，字居中
#let _blank(width, value) = {
  box(width: 0pt, height: 0pt, place(top + left, dy: 1.875pt, line(length: width, stroke: 0.75pt)))
  box(width: width, align(center, value))
}
// 字母之间加字距（UDC 那三个字母，w:spacing 116 缇），末字不加
#let _letter-spaced(body, gap) = {
  let cs = plain-text(body).clusters()
  cs.slice(0, -1).map(c => c + h(gap)).join() + cs.last()
}
// 标签撑到 n 个字宽：字之间均分（模板里是半角空格，四个字的空两个）
#let _spread(body, width) = context {
  let cs = plain-text(body).clusters()
  if cs.len() < 2 { return body }
  let gap = (width - measure(body).width) / (cs.len() - 1)
  cs.map(c => c).join(h(gap))
}
// 工作完成日期：没写就取研究工作起止的年月，中间一道破折号
#let _month(v) = if type(v) == str and _date.parse(v) != none {
  let d = _date.parse(v)
  _date.render(str(d.year) + (if d.month == none { "" } else { "-" + str(d.month) }), lang: "zh")
} else { v }
#let work-period(info) = if info.work-finish-date != auto { info.work-finish-date } else {
  _month(info.research-start-date) + [—] + _month(info.research-end-date)
}

#let _page(layout, body) = {
  set page(
    width: layout.paper-width, height: layout.paper-height, margin: layout.margin,
    header: none, footer: none, numbering: none,
  )
  set text(lang: "zh", region: "cn")
  body
}

#let cover(info: (:), terms: (:), variant: (:), layout: auto) = _page(layout, {
  let t(key) = term-for(terms, key, variant)
  let p(body, style) = paragraph(body, style, layout: layout)
  let mark = sym.zws
  p(mark, _normal + _exact(24pt))
  p({
    t("classified-index"); _blank(77pt, info.classified-index); h(98pt)
    t("secrecy"); _blank(84pt, info.secrecy)
  }, _sihao + (below: 8.15pt, first-line-indent: 38.05pt))
  p({
    _letter-spaced(t("udc"), 5.8pt); _blank(77pt, info.udc); h(98pt)
    t("report-number"); _blank(91pt, info.report-number)
  }, _sihao + _exact(24pt) + (below: 16.3pt, first-line-indent: 38pt))
  for _ in range(2) { p(mark, _normal + _exact(24pt)) }
  let heading = _normal + _exact(24pt) + (asian-font: "heiti", size: zihao.xiaoer, below: 16.3pt, align: center)
  p(t("university"), heading)
  p(plain-text(t("report")).clusters().join(h(0.5em)), heading)
  p(mark, _normal + _exact(24pt))
  // 题名两行：写了换行就照断，没写按题名线的宽度排满第一行；两行字号照模板，三号、小三
  let title = info.title
  let kids = if type(title) == content and title.has("children") { title.children } else { () }
  let rows = if kids.any(c => c.func() == linebreak) {
    let cut = kids.position(c => c.func() == linebreak)
    (kids.slice(0, cut).join(), kids.slice(cut + 1).join())
  } else { wrap-lines(title, _title-rule.to - _title-rule.from, size: zihao.sanhao) }
  let first = rows.at(0, default: [])
  let rest = rows.slice(calc.min(1, rows.len())).join()
  _rule(_title-rule, 27.6pt)
  p(first, _normal + _exact(24pt) + (size: zihao.sanhao, below: 8.15pt, align: center))
  p([#rest#mark], _normal + _exact(24pt) + (size: zihao.xiaosan, above: 8.15pt, align: center))
  _rule(_title-rule, 4.05pt)
  p(mark, _normal + _exact(24pt))
  p(info.author, _sihao + _exact(24pt) + (above: 8.15pt, align: center))
  p(mark, _normal + _exact(24pt) + (above: 8.15pt, align: center))
  let dated = _sihao + _exact(24pt) + (above: 8.15pt, first-line-indent: 76.3pt)
  _rule(_date-rule, 30.3pt)
  p({ t("work-finish-date"); h(1em); work-period(info) }, dated + (below: 16.3pt))
  _rule(_date-rule, 29.85pt)
  p({ t("report-submit-date"); h(1em); _date.render(info.report-submit-date, lang: "zh") }, dated + (below: 8.15pt))
  let foot = _normal + _exact(12pt) + (above: 8.15pt, below: 8.15pt, align: center)
  for _ in range(3) { p(mark, foot) }
  p([#t("issuer")#mark], foot + (size: zihao.sihao))
  p(_date.render(info.date, lang: "zh"), _sihao + _exact(24pt) + (above: 8.15pt, below: 8.15pt, align: center))
})

#let titlepage(info: (:), terms: (:), variant: (:), layout: auto) = _page(layout, {
  let t(key) = term-for(terms, key, variant)
  let p(body, style) = paragraph(body, style, layout: layout)
  let mark = sym.zws
  p(mark, _normal + (size: zihao.sanhao, align: center))
  p(info.title, _normal + (size: zihao.sanhao, align: center))
  p(mark, _normal + _exact(24pt))
  p(upper(value-of(info, "title", lang: "en")), _sihao + (align: center))
  // 英文题名下两个空段的段落标记也是三号，各占两行网格
  for _ in range(2) { p(mark, _normal + (size: zihao.sanhao)) }
  for _ in range(2) { p(mark, _normal + _exact(24pt)) }
  // 前四个标签撑到 7 个字宽（「研究工作起始时间」八个字不撑），后接全角冒号
  let field(label, value, spread: true) = p(
    { if spread { _spread(t(label), 7em) } else { t(label) }; [：]; value },
    _sihao + (line-spacing: 1.5, first-line-indent: (chars: 5)),
  )
  field("author", info.author)
  field("supervisor", info.supervisor)
  field("station", info.station)
  field("speciality", info.speciality)
  field("research-start-date", _date.render(info.research-start-date, lang: "zh"), spread: false)
  field("research-end-date", _date.render(info.research-end-date, lang: "zh"), spread: false)
  p(mark, _normal + (line-spacing: 1.5, align: center))
  let foot = _normal + _exact(12pt) + (above: 8.15pt, below: 8.15pt, align: center)
  for _ in range(3) { p(mark, foot) }
  p([#t("issuer")#mark], foot + (size: zihao.sihao))
  p(_date.render(info.date, lang: "zh"), _sihao + (line-spacing: 1.5, align: center))
})
