#import "@local/omni-gb7714:0.1.0" as _omni
#import "../heading/heading.typ": _term-body
#let references-title(lang, centered: auto) = _term-body("references", lang, centered: centered)
