// 参考文献。
//
// *终稿与开题（中期）报告都排这一页。* 目录不按「谁用」分文件——第一层
// 说的是「这是什么」，谁在用写在这儿一句话就够了。
//
// *条目不是我们排的。* 写作指南 1.5 要的是 GB/T 7714，那是一整套著录规则
// （著者、题名、载体标识、出版项、连续出版物的年卷期页……），另有专门的包做。
// 我们只管这一章的*壳*：不编号的章标题、字样从词条来、进目录、章前跳页，
// 与结论致谢同一层（src/heading/heading.typ 的 term-chapter）。
//
// *bibliography 我们一个字都不套，就用 omni 自己那个。* 套壳只有两种写法，
// 两种都坏：..args 一兜，LSP 就补不出它那七十多个参数（编辑器只认声明出来的
// 签名）；逐条抄，就是抄一份会烂的表——它加了我们不知道，它改了我们不跟，
// 与 lib.typ 里 gb7714 那一条不列选项是同一个理由。
//
// *章壳从 title 进去。* omni 的 gb7714(title:) 是全局的参考文献表标题，
// 收 auto / none / 自定义 content——我们把*我们的章标题*塞进去就完了：
// 不编号、字样从词条来、进目录、章前跳页，全在 term-chapter 那一份内容里。
// 用户照写 #bibliography(read("refs.bib"))，什么都不用多记；要改字样就写
// iota-hit(gb7714: (title: [文献])) 或者自己 #show: gb7714.with(title: …)。
//
// *title 强制 none。* 标题由我们发：要走章样式、要进目录、要挂英文目录名、
// 章前要跳页。底下那个包自己也会发一个，两个一起出就重了。用户写了 title 就当场
// 报错，指向 title——那一条是 term-chapter 的口子，覆盖字样用它。
//
// *接 omni-gb7714。* 它是本机唯一按 GB/T 7714—2025 做全的包，引用合并、
// 顺序编码制与著者-出版年制、脚注尾注都齐。*由 iota-hit 替用户装*，
// 用户不必写 #show: gb7714；要调它的选项就写 iota-hit(gb7714: (…))，
// 那一份原样透过去，见 lib.typ 的 gb7714 参数。
//
// *@local 是暂时的*：omni 还没上 @preview（实测 package not found）。
// 上了就把下面这一行的 local 改成 preview。
#import "@local/omni-gb7714:0.1.0" as _omni
#import "../heading/heading.typ": _term-body

// 交给 omni 的章标题：*不带 context 的那一份体*。
//
// 先前塞的是 term-title（= context _term-body），语言它自己解。可 omni 把这份内容
// 原样放进它的 heading 里，目录条目再拿 it.body() 去看时看到的是一个 context 块
// ——plain 读不出一个字，于是整条被判成纯西文（汉字落到西文字体的回落字
// 上，实测目录里「参考文献」是 SimSun，别的章条目是 SimHei）；title-of 也找不到
// 里面的英文目录名记号，英文目录里印的还是「参考文献」。语言在 iota-hit 那一层
// 本来就解好了（doc-lang），从那里递进来，内容就是平的。
// centered 是章那一档居不居中：iota-hit 在自己的 context 里调这一条，那时样式表的 state
// 还没落地，从解好的表里取了传进来（styles.chapter.align == center）
#let references-title(lang, centered: auto) = _term-body("references", lang, centered: centered)
