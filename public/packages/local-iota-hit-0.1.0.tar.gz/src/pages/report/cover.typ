#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing, amount
#import banshi.fonts: zihao
#import banshi.layout: merge-page-setup
#import "../../layout/parts.typ": layout-for
#import "../../layout/presets.typ": report-cover-layouts
#import "./wordmark.typ": wordmark
#import "../../glyphs.typ": outlined
#import "../../glyphs/lishu.typ": lishu-outline-font
#import banshi.styles: paragraph
#import "../overflow.typ": overflow-note, wrap-lines
#import banshi.paragraph: paragraph-mark as enter, paragraph-mark-height as enter-height
#import "../../terms/lookup.typ": term-table, term-for, variant-of
#import "../../info.typ": info-defaults, info-get, value-of
#import banshi.content: plain-text
#import banshi.styles as style-rules
#import banshi.units: emu, run-spacing
#import "../../axes.typ": degree-type-for, campus-for
#import "./title.typ" as _report-title
#import "../../terms/lang.typ": resolve-lang
#let sp(n) = text(spacing: 0.5em, " " * n)
#let label-spread(chars, cells) = {
  let chars = if type(chars) == str { chars } else { plain-text(chars) }
  let cs = chars.clusters()
  let han(c) = c.contains(regex("\\p{Han}"))
  let hans = range(cs.len()).filter(i => han(cs.at(i)))
  if hans.len() == 0 { return text(spacing: 0.5em, chars) }
  let core = hans.last() + 1
  if core >= cells { return text(spacing: 0.5em, chars) }
  let slots = range(core - 1).filter(i => han(cs.at(i)) and han(cs.at(i + 1)))
  let slots = if slots.len() > 0 { slots } else if core > 1 { (0,) } else { () }
  if slots.len() == 0 { return text(spacing: 0.5em, chars) }
  let want = int(calc.round(2 * (cells - core)))
  let each = int(calc.floor(want / slots.len()))
  let extra = want - each * slots.len()
  let out = ""
  for (i, c) in cs.enumerate() {
    out += c
    if i in slots {
      out += " " * (each + if i == slots.last() { extra } else { 0 })
    }
  }
  text(spacing: 0.5em, out)
}
#let _fill-spaces = 21

#let _filled(
  label, value, cells: 4, total-cells: 15, gap: 1, gap-underlined: false,
) = context {
  let total = total-cells * text.size
  let lab = label-spread(label, cells)
  let sp = if gap > 0 { sp(gap) } else { [] }
  let head = lab + (if gap-underlined { [] } else { sp })
  let head-w = measure(head + sym.zws).width
  let base-column = cells * text.size + (
    if gap-underlined { 0pt } else { gap * 0.5 * text.size }
  )
  let column = calc.max(head-w, base-column)
  let inner = (if gap-underlined { sp } else { [] }) + (
    if value == none { [] } else { value }
  )
  let used = column + measure(inner + sym.zws).width
  let gapw = if gap-underlined { gap * 0.5 * text.size } else { 0pt }
  let room = total - used + gapw
  let inner-w = used - column
  let centred = base-column + (total - base-column - inner-w + gapw) / 2 - column
  let left = calc.max(centred, gapw)
  let pad(amount) = if amount > 0pt {
    text(spacing: amount / _fill-spaces, " " * _fill-spaces)
  }
  let rule(body) = underline(evade: false, offset: 0.155em, stroke: 0.09em, body)
  let lead = { head; pad(column - head-w) }
  if room >= 0pt {
    lead
    rule({
      pad(left)
      if value != none { value }
      pad(room - left)
    })
  } else {
    let words = plain-text(value)
    if words == none or words.trim() == "" {
      lead
      rule({ pad(gapw); value })
    } else {
      let room-first = total - column - gapw
      let room-each = total - base-column - gapw
      let lines = wrap-lines(words, room-each, first: room-first)
      lead
      for (i, line) in lines.enumerate() {
        if i > 0 { h(base-column) }
        let room = if i == 0 { room-first } else { room-each }
        let used-here = measure(text(line) + sym.zws).width
        rule({
          pad(gapw)
          text(line)
          pad(room - used-here)
        })
        if i + 1 < lines.len() { linebreak() }
      }
    }
  }
}
#let _tracked(body, style, latin: false) = body + h(
// Word 居中时计入末字字距，Typst 不计。
  style.at("tracking", default: 0pt) / (if latin { 2 } else { 1 }),
)

#let _bachelor-rows = ("speciality", "author", "student-id", "supervisor", "date")
#let _graduate-rows = (
  "affiliation", "speciality", "supervisor", "author", "student-id", "date",
)
#let _graduate-field-cells = 20.5
#let _harbin-graduate = (
  title-size: zihao.erhao, blanks-before-form: 0, blanks-after-form: 2,
  field-first-above: 12pt, field-spacing: 1.75, field-snap: false,
  tail: ((3, 1.25, false),), blanks-after-seal: 0,
)

#let _graduate-sheet = (
  harbin: (
    master: (proposal: _harbin-graduate, interim: _harbin-graduate),
    doctor: (proposal: _harbin-graduate, interim: _harbin-graduate),
  ),
  shenzhen: (
    master: (
      proposal: (
        title-size: zihao.xiaoyi, form-row: false,
        blanks-before-university: (3, zihao.wuhao, 1.5),
        blanks-before-fields: (1, 1, 12pt),
        field-first-above: 12pt, field-spacing: 1.75, field-snap: false,
        field-indent: 2.25cm, field-cells: 20,
        en: (
          title-spacing: 40, blanks-before-fields: (2, 1, 12pt),
          field-indent: 2cm, field-cells: 25, title-reserve: 2,
        ),
        tail: ((3, 1.25, false),), blanks-after-seal: 0,
      ),
      interim: (
        title-size: zihao.erhao, form-row: false,
        blanks-before-university: (2, zihao.xiaoer, 1), blanks-before-fields: (2, 1, 0pt),
        field-first-above: 0pt, field-spacing: 1.75, field-snap: false,
        field-indent: 1.67cm, field-cells: 19,
        en: (
          title-spacing: 40, blanks-before-fields: (3, 1, 0pt),
          field-first-above: 12pt, field-indent: 1.5cm, field-first-indent: 0.86cm,
          field-cells: 19.5,
        ),
        tail: ((3, 1, false),), blanks-after-seal: 0,
      ),
    ),
  ),
)
#let _sheet-defaults = (
  form-row: true, blanks-before-university: (2, zihao.xiaoer, 1), blanks-before-fields: none,
  field-indent: auto, field-cells: _graduate-field-cells, title-centered: true,
  field-first-indent: 0pt,
  title-spacing: 40,
  title-reserve: 1,
  en: (title-spacing: 0),
)

#let cover(
  stage: "proposal",
  info: info-defaults,
  lang: auto,
  title: auto,
  terms: auto,
  overrides: (:),
  layout: auto,
  warning: auto,
  report-title: auto,
  styles: (:),
) = context {
  let this-lang = resolve-lang(lang)
  let latin = this-lang == "en"
  let t = if terms != auto { terms } else {
    term-table(this-lang, "cover", overrides: overrides)
  }
  let degree-level = info.degree-level
  let graduate = degree-level != "bachelor"
  let campus = campus-for(info.campus, degree-level)
  let layout = merge-page-setup(
    layout-for(none, report-cover-layouts
      .at(campus, default: (:))
      .at(degree-level, default: (:))
      .at(stage, default: (:))),
    layout,
  )
  let sheet = _sheet-defaults + (if graduate {
    let by-campus = _graduate-sheet.at(campus)
    let by-degree = by-campus.at(degree-level, default: by-campus.at("master"))
    by-degree.at(stage, default: by-degree.at("proposal"))
  } else {
    (title-size: zihao.xiaoyi, blanks-before-form: 0, blanks-after-form: 0,
      field-first-above: 0pt, field-spacing: 1.75, field-snap: false,
      field-cells: 15, tail: ((5, 1.25, false),), blanks-after-seal: 0)
  })
  let sheet = sheet + (if this-lang == "en" { sheet.en } else { (:) })
  let variant = variant-of(info) + (stage: stage, degree-level: degree-level, campus: campus) + (
    if graduate {
      (degree-type: degree-type-for(degree-level, info.degree-type, info.form))
    } else { (:) }
  )
  let pick(name) = term-for(t, name, variant)
  let stage-word = _report-title.stage-word(t, variant)
  let composed-title = _report-title.report-title(t, this-lang, info, variant)
  let label-of(name) = {
    let l = pick(name)
    if name == "date" and graduate and this-lang == "zh" and stage-word != none {
      stage-word + l
    } else { l }
  }
  set text(lang: this-lang, region: "cn", size: zihao.xiaosi)
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
  let normal = if graduate {
    (above: 0pt, below: 0pt, line-spacing: 1,
      snap-to-grid: true, bold: true)
  } else {
    (above: 3pt, below: 3pt, line-spacing: 1.25,
      snap-to-grid: false, bold: true)
  }
  let field-width = sheet.field-cells * zihao.sanhao
  let field-indent = if sheet.field-indent == auto {
    (layout.text-width - field-width) / 2
  } else { sheet.field-indent }
  let script(zh, font: auto) = if this-lang == "en" {
    (latin-font: "serif")
  } else {
    (asian-font: if font == auto { zh } else { font })
  }
  let built-in = if graduate {
    (
      university: normal + script("kaishu", font: "kaishu-gb2312") + (
        size: zihao.xiaoer, align: center, tracking: run-spacing(40),
      ),
      report-title: normal + script("songti") + (
        size: sheet.title-size, align: center,
        tracking: run-spacing(sheet.title-spacing),
      ),
      title: normal + script("songti") + (
        size: zihao.xiaoer, align: if sheet.title-centered { center } else { left },
      ),
      form: normal + script("songti") + (
        size: zihao.sanhao, align: center, above: 12pt,
      ),
      field: normal + script("songti") + (
        size: zihao.sanhao,
        left-indent: field-indent, first-line-indent: sheet.field-first-indent,
        line-spacing: sheet.field-spacing, snap-to-grid: sheet.field-snap,
      ),
      seal: normal + script("songti") + (size: zihao.sanhao, align: center),
    )
  } else {
    (
      report-title: normal + (
        size: zihao.xiaoyi, asian-font: "songti",
        align: center, tracking: run-spacing(40),
      ),
      wordmark: normal + (size: zihao.xiaoer, align: center),
      title: normal + (
        size: zihao.xiaoer, asian-font: "songti", align: center,
        first-line-indent: (chars: if stage == "interim" { 3 } else { 2.5 }),
      ),
      field: normal + (
        size: zihao.sanhao, asian-font: "songti",
        first-line-indent: field-indent,
        line-spacing: 1.5, above: 9.6pt,
      ),
      seal: normal + (size: zihao.xiaoer, asian-font: "lishu", align: center),
    )
  }
  let styles = {
    let out = built-in
    for (name, over) in styles {
      if name not in built-in {
        panic(
          "unknown style " + repr(name) + " on the report cover (expected one of "
            + built-in.keys().map(repr).join(", ") + ")",
        )
      }
      out.insert(name, built-in.at(name) + over)
    }
    out
  }
  let enter = enter.with(
    line-spacing: normal.line-spacing,
    spacing: normal.above,
    snap: normal.snap-to-grid,
    layout: layout,
  )
  let title-value = if title != auto { title } else {
    value-of(info, "title", lang: this-lang)
  }
  let title-metrics = spacing(styles.title, layout: layout, latin: latin)
  let title-as(body) = {
    show: style-rules.rules.with(styles.title, layout: layout, set-font: true, latin: latin)
    body
  }
  let label-w = measure(title-as(pick("title") + sym.zws)).width
  let title-rows = wrap-lines(
    title-value,
    layout.text-width,
    first: layout.text-width - label-w,
    measure-as: t => title-as(text(t)),
  )
  let title-lines = calc.max(1, title-rows.len())
  let blank-height(size, ls: auto, snap: auto, spacing: auto) = enter-height(
    size,
    line-spacing: if ls == auto { normal.line-spacing } else { ls },
    snap: if snap == auto { normal.snap-to-grid } else { snap },
    layout: layout,
  ) + (if spacing == auto { normal.above } else { spacing })
  let n-below-title = if graduate and not sheet.form-row {
    sheet.blanks-before-fields.at(0)
  } else if graduate { sheet.blanks-after-form } else {
    if stage == "interim" { 4 } else { 4 }
  }
  let n-above-form = if graduate and sheet.form-row { sheet.blanks-before-form } else { 0 }
  let n-title-gap = if graduate { 1 } else { 2 }
  let n-before-seal = if graduate { sheet.tail.map(((n, ..)) => n).sum() } else { 2 }
  let grow = (title-lines - sheet.title-reserve) * title-metrics.baseline-gap
  let eat(n, h, left) = {
    if left <= 0pt or n == 0 { return (n, left) }
    let k = calc.min(n, int(calc.round(left / h)))
    (n - k, calc.max(left - k * h, 0pt))
  }
  let seal-h = if graduate {
    blank-height(zihao.sanhao, ls: sheet.tail.at(0).at(1), snap: sheet.tail.at(0).at(2))
  } else { blank-height(zihao.sanhao) }
  let (before-seal, left1) = eat(n-before-seal, seal-h, grow)
  let (below-title, left2) = eat(
    n-below-title,
    blank-height(zihao.sanhao, snap: false, ls: if graduate and not sheet.form-row {
      sheet.blanks-before-fields.at(1)
    } else if graduate { 1.25 } else { 1.5 }),
    left1,
  )
  let (above-form, left3) = eat(n-above-form, blank-height(zihao.sanhao), left2)
  let (title-gap, left4) = eat(n-title-gap, blank-height(zihao.sanhao), left3)
  let body = {
    v(normal.above)


  if graduate {
    let (n-before, before-size, before-spacing) = sheet.blanks-before-university
    enter(n-before, size: before-size, line-spacing: before-spacing)
    let university = pick("university")
    paragraph(_tracked(university, styles.university, latin: latin), styles.university, layout: layout, latin: latin)
    enter(size: zihao.xiaoer)
  } else {
    enter(size: zihao.xiaosi)
    enter(2, size: zihao.xiaoer)
    let m = spacing(styles.wordmark, layout: layout, latin: true)
    paragraph(
      box(
        width: 2131060 * emu,
        height: 400685 * emu + m.baseline-gap - m.single,
        align(top, wordmark(width: 2131060 * emu)),
      ),
      styles.wordmark,
      layout: layout,
      latin: true,
    )
    enter(size: zihao.xiaoer)
  }

  paragraph(
    _tracked(
      if report-title != auto { report-title } else { composed-title },
      styles.report-title, latin: latin,
    ),
    styles.report-title,
    layout: layout,
    latin: latin,
  )
  enter(title-gap, size: zihao.sanhao)
  paragraph(
    {
      pick("title")
      for (i, row) in title-rows.enumerate() {
        let w = measure(title-as(text(row))).width
        if i > 0 { linebreak() }
        let mid = (layout.text-width - w) / 2
        h(calc.max(mid - (if i == 0 { label-w } else { 0pt }), 0pt))
        text(row)
      }
    },
    styles.title + (align: left, first-line-indent: (chars: 0)),
    layout: layout,
    latin: latin,
  )
  if graduate and not sheet.form-row {
    let (n, sp, above) = sheet.blanks-before-fields
    let n = below-title
    enter(n, size: zihao.sanhao, line-spacing: sp, spacing: above)
  } else if graduate {
    enter(above-form, size: zihao.sanhao)
    let (open, close) = if this-lang == "en" { ([(], [)]) } else { ([（], [）]) }
    paragraph(
      open + term-for(t, "form", variant) + close,
      styles.form,
      layout: layout,
      latin: latin,
    )
    enter(below-title, size: zihao.sanhao, line-spacing: 1.25, snap: false)
  } else {
    if stage == "interim" and below-title >= 4 { enter(size: zihao.sanhao) }
    enter(calc.min(below-title, if stage == "interim" { 3 } else { 4 }),
      size: zihao.sanhao, line-spacing: 1.5)
  }
  let field = styles.field
  for (i, name) in (if graduate { _graduate-rows } else { _bachelor-rows }).enumerate() {
    let value = value-of(info, name, lang: this-lang)
    paragraph(
      if graduate {
        _filled(
          label-of(name), value,
          cells: 6, total-cells: sheet.field-cells, gap-underlined: true,
        )
      } else {
        _filled(label-of(name), value, cells: 4, total-cells: sheet.field-cells, gap: 1)
      },
      field + (
        if graduate and i == 0 { (above: sheet.field-first-above) } else { (:) }
      ),
      layout: layout,
      latin: latin,
    )
  }
  if graduate {
    let left = n-before-seal - before-seal
    for (n, line-spacing, snap) in sheet.tail {
      let eaten = calc.min(left, n)
      enter(n - eaten, size: zihao.sanhao, line-spacing: line-spacing, snap: snap)
      left -= eaten
    }
  } else {
    enter(before-seal, size: zihao.sanhao)
  }
  let seal = pick("seal")
  if seal != none {
    paragraph(
      if graduate { seal } else { context outlined("lishu", lishu-outline-font, seal) },
      styles.seal, layout: layout, latin: latin,
    )
  }
    if graduate { enter(sheet.blanks-after-seal, size: zihao.sanhao) }
    else if stage == "interim" { enter(size: zihao.xiaoer) }
  }
  let too-tall = measure(block(width: layout.text-width, body)).height > layout.text-height
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin, header: none, footer: none,
    foreground: if too-tall and warning != false {
      overflow-note(pick("warning-overflow"), pick("warning-false"), lang: this-lang)
    },
  )
  body
}
