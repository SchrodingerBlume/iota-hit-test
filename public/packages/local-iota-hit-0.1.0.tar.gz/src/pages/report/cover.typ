// 开题报告与中期报告的首页。
//
// *它与论文封面毫不相干。* 论文那一页是对着 Word 范例逐条解基线的几何求解
// （src/pages/cover.typ），要在「校名落点尽量不动」与「姓名视觉居中」之间
// 联合挑一组空行数；报告这一页是一串定死的段落，照 docx 的顺序排下去就是。
//
// *一段一段照 Word 的段落属性排。* 有字的走 src/styles/paragraph.typ 的
// paragraph，空段走 src/styles/enter.typ 的 enter，样式表里写的就是 Word 段落对话框上
// 那几栏（字号、行距、段前段后、缩进、贴不贴网格）。
//
// *空段也是段。* 本科那份每一段都写着段前段后各 3pt、硕博那三份贴行网格
// ——空段一样吃。enter 先前收不了这两样（块间距恒为 0、也接不到网格），
// 本科因此丢了段间的 3pt、硕博整页没贴网格，差出 7～13pt；两档已经补进 enter，
// *不在这一页另起炉灶*。
//
// ── 两档，按 degree-level 分，不按 stage ─────────────────────────────────────
//
// 本科那两份是教务处发的表单，硕博三份是研究生院发的，*谱系不同*——
// 版面、Normal 样式、首页结构三样都不一样。（hithesis 也只做硕博，没有本科。）
//
//                本科（开题·中期）              硕博（硕开·硕中·博开）
//   版面         四边 2.3cm、无页眉页码         上左右 2.5cm、页眉 1.5／页脚 1.75cm
//                网格整个不启用                 *开着行网格*（312 缇 ＝ 15.6pt）
//   Normal       段前段后各 3pt、行距 1.25      *一个 spacing 都没有*
//   首行         校名题字（矢量图）             文字「哈尔滨工业大学」楷体_GB2312
//   form 那行    没有                           （学位论文/实践成果）二选一
//   字段         五格，首行缩进 6.86 字         六格，整段左缩进 63pt
//   末行         哈尔滨工业大学教务处制         研究生院制
//                （隶书小二）                   （宋体三号）
//
// *硕博那份贴行网格，这是整页几何的大头。* sectPr 写着
// <w:docGrid w:type="lines" w:linePitch="312"/>——只纵向，没有 charSpace。
// 贴网格的段，行盒高往上取整到整数个 15.6pt：小二 18pt 的空段自然行高
// 20.7（西文 1.15），取整成 2 格 ＝ 31.2，实测两个空段的基线差正是 31.2。
// 三处写着 snapToGrid=0 的不贴：六格（行距 1.75）与末尾五个空段（行距 1.25）。
// 先前整页按不贴网格排，各行少 7.6～12.5。
//
// *本科那份不贴。* 它的 docGrid 只有 linePitch、*没有 w:type*，缺省
// 是 default ＝ 不启用（见 src/layout/presets.typ）。
//
// 本科逐段（中期；开题只差标题那一行的字与「题 目：」的缩进，末尾少一个空段）：
//
//   0     空段            小四 12pt
//   1,2   空段            小二 18pt
//   3     校名题字        167.8 × 31.55pt，居中，行盒同小二
//   4     空段            小二 18pt
//   5     标题            宋体 小一 24pt 加粗 居中，字距 2pt
//   6,7   空段            三号 16pt
//   8     题 目：＋题目   宋体 小二 18pt 加粗，首行缩进 3 字（开题 2.5 字）
//   9     空段            三号 16pt
//   10-12 空段            三号 16pt，*行距 1.5*
//   13-17 五格            三号 16pt 加粗，首行缩进 6.86 字，行距 1.5，段前 9.6pt
//   18,19 空段            三号 16pt
//   20    教务处制        隶书 小二 18pt 加粗 居中
//   21    空段            小二 18pt（*只有中期有*）
//
// 硕博逐段。*四档（硕开·硕中·博开·博中）共用这一份清单*，只有标题那一行的
// 字号照各份的设计，见 _graduate-title-size：
//
//   0,1   空段            小二 18pt        贴网格
//   2     哈尔滨工业大学   楷体_GB2312 小二 18pt 加粗 居中，字距 4pt   贴网格
//   3     空段            小二 18pt        贴网格
//   4     标题            宋体 加粗 居中，字距 4pt，*字号逐份不同*   贴网格
//   5     空段            三号 16pt        贴网格
//   6     题 目：＋题目   宋体 小二 18pt 加粗，*整行居中*   贴网格
//   7     （学位论文/实践成果） 三号 16pt 居中，段前 12pt   贴网格
//         *前后的空段逐份不同*（博开前面一个、硕中后面两个），见
//         _graduate-sheet
//   8-13  六格            三号 16pt 加粗，整段 20.5 格、*在版心里居中*，
//                         行距 1.75（w:line=420），*不贴网格*；头一格段前 240 缇
//   14-18 空段            三号 16pt，行距 1.25（w:line="300"），*不贴网格*
//   19    研究生院制       宋体 三号 16pt 加粗 居中   贴网格
//
// *原件三份并不一致，那是手排。* 十一处差异（form 行前后的空段、六格的
// 缩进与格数与行距、头格段前、尾部空段、末行后空段）全部出自*同一次改版*
// ——实践成果进来之后，标题去掉「论文」、底下加一行二选一、「学科」扩成
// 「学科/专业学位类别」——三份三种改法：硕开把原来的空段*换成* form 行，
// 硕中*插进去*、空段留着，博开*保留*空段、追加在后。判据是留学生版
// 那两份上一代模板（正文双语、封面仍是中文）：它们没有 form 行、标题带「论文」、
// 学科那格是光「学 科」，三处同时成立。取硕开那一份——它是唯一把这次改版做
// 干净的。*唯独标题字号不在这次改版里*：同一条模板线的两代字号一样，
// 见 _graduate-title-size。
//
// *段前段后折叠成较大者*，与本包别处同一条（tests/check-adjacent.py）。
// 本科那份每一段都写着 before=60 after=60 ＝ 各 3pt，两段之间因此只进 3pt 不是
// 6pt：实测两个三号空段的基线差 25.92，＝ 行高 23.00（1.25 × 1.15 × 16）＋ 3。
//
// *空段的高按 ¶ 自己的字体算，而 ¶ 取 rFonts 的 ascii 槽*（见 src/styles/enter.typ
// 抬头）。五份表单的空段 ¶ *一个都没有指定 ascii*——写着的是
// eastAsia="楷体_GB2312"，那是中文槽，管不着段落标记。所以整页的空段一律走
// 西文的 1.15，不是中易的 1.296875。硕士开题末尾那五个空段实测步进 23.04，
// 1.25 × 1.15 × 16 ＝ 23.00 对得上，按中易算是 25.94，差得出来。
//
// ── 横向的三条，都是踩出来的 ──────────────────────────────────────────
//
// *一、字距是 4pt，不是文件写的那个 2pt。* 校名与标题那两段写着
// `w:spacing w:val="40"`，按 OOXML 是 40 缇 ＝ 2pt；*两台 Word 都排成
// 每字多 4.00pt*。用户在 macOS 上导出的那份如此，*学校自己发的*
// ~/Downloads/硕士学位中期报告模板.pdf（Producer 写着 Microsoft® Word 用于
// Microsoft 365，Windows 排的）也如此：校名 18pt 步进量出 22.07 / 21.94
// ＝ 18 ＋ 4.00，标题 22pt 26.02 ＝ 22 ＋ 4.00。另一处 `val="12"` 同样翻倍，
// 量出 1.20pt。*两个值都正好是缇值的两倍*，所以照排出来的写。
//
// *二、居中时末字的那段字距，Word 算进行宽，Typst 不算。* 「哈尔滨工业
// 大学」七字：Word 的行宽是 7 × 22 ＝ 154，居中后左缘 220.73；Typst 按 150
// 居中，左缘 222.64——整行右移了半段字距。末尾补一个 h(字距) 就一致
// （实测 220.68）。做在这一页的 _tracked 里，不动公共的 paragraph，理由见那儿。
//
// *三、六格的整段宽要数不要量。* docx 里那几行就是「标签 ＋ 一串带 w:u 的
// 空格」，把全角字记 1 格、半角空格记半格数一遍即可。六行各不相同（手敲空格的
// 出入），先取每份的多数，再在各份之间挑一个：
//
//   本科      五行全是 15.00 格
//   硕开      20.50 格（上一代的留学生版是 19.50——连自己都没沿用）
//   硕中      19.00 格（留学生版也是 19.00）
//   博开      18.50 格
//
// 18.5～20.5，纯手敲，没有稳定值，取硕开现行那一份（统一的理由见上）。
// 硕中那一份有学校发的 PDF 可对：按它自己的 19 格算，线右缘 118.25 ＋ 304
// ＝ 422.25，量出 422.35。*先前是拿用户导出的 PDF 量的，量成了 336*
// ——见下一条。
//
// *量用户导出的 PDF 要先扣掉汉字的字宽拉长。* 那两份是 macOS 版 Word
// 导出的，*汉字的字宽被拉长了 1.0195 倍*：三号（16pt）实测步进 16.31、
// 小二 18.35、小一 24.47，半角空格 8.16 同倍；下划线是文本渲染的一部分，
// 也跟着拉长。*西文不受影响*——同一批文件里 Times 的 'Abstract' 量出
// 13.000 / 9.004 / 7.006，与字体的 722 / 500 / 389 分毫不差。学校发的那两份
// PDF（硕士中期模板、《书写范例》）都没有这个倍数：汉字步进就是 16.00、
// 18.00、12.4920。所以它是那台机器导出时的事，不是 Word 的模型。
//
// 同一台 Word 把 .doc 转成 .docx 时还会*把这个字宽写进文件*：本科报告的
// `w:firstLineChars="686"` 被算成 `w:firstLine="2238"`（÷6.86 ＝ 16.31），
// 而没被重排的硕博那份仍是 `375 → 900`（÷3.75 ＝ 12.00）。所以缩进照
// firstLineChars 排（6.86 字 ＝ 109.76），不照 firstLine 那个绝对值。
//
// *没有分页符。* 五份文件里 w:br w:type="page" 一个都没有——正文接着这一页
// 往下流，首页只是「排到这儿正好满了」。所以这个部件不发 pagebreak。

#import "../../fonts/presets.typ": zihao
#import "../../layout/resolve.typ": layout-for, resolve-local
#import "../../layout/presets.typ": report-cover-layouts
#import "./wordmark.typ": wordmark
#import "../../fonts/glyphs.typ": outlined
#import "../../fonts/glyphs/lishu.typ": lishu-outline-font
#import "../../styles/paragraph.typ": paragraph, overflow-note
#import "../../styles/enter.typ": enter, enter-height
#import "../../terms/lookup.typ": term-table, term-for, variant-of
#import "../../document/info.typ": info-defaults
#import "../../document/info.typ": info-get, value-of
#import "../../styles/linebox.typ" as linebox
#import "../../text/plain.typ": plain, wrap-lines
#import "../../styles/rules.typ" as style-rules
#import "../../text/chars.typ" as chars
#import "../../msword.typ": emu, msword-run-spacing
#import "../../axes.typ": degree-type-for, campus-for
#import "./title.typ" as _report-title
#import "../../terms/lang.typ": resolve-lang

// 半角空格 n 个。
//
// *Word 的半角空格是半个全宽字*（那一节开着
// balanceSingleByteDoubleByteWidth），三号上就是 8pt；Typst 的西文空格只有
// 0.25em。text(spacing:) 改的正是空格自身的宽度，且*行尾那个不会丢*
// ——用 tracking 会少一份。实测 21 个空格 168.00pt，与 docx 那个 run 一样宽。
//
// *不走 chars.halfspace*：那一支钉在字符网格的格子上（char-pitch/2），而这一页
// 横向没有网格（两份的 docGrid 都没有 charSpace），char-pitch 退化成基准字号 12pt，
// 21 个空格会算成 126pt，比 Word 短 42pt。没有字符网格时半角空格跟的是
// *本段字号*。
#let sp(n) = text(spacing: 0.5em, " " * n)

// 标签撑到 n 个全宽字宽（本科五格 4 字，硕博六格 6 字）。
//
// *docx 里就是拿字面空格撑的*，不是分散对齐——那几段都没有
// w:jc="distribute"。学校自己发的硕士中期 PDF 上，六格的标签逐字量下来是
// （版心左缘 ＋ 左缩进起，一格 16pt）：
//
//   学@0  院@2.99  （@4.00  部@5.00  ）@6.00
//   导@0                    师@5.00
//   研@0  究@2.99           生@5.00
//   学@0                    号@5.09      （这一格另加了 1.2pt 字距）
//   中@0  期@1  报@2  告@3  日@4  期@5.00
//
// *每一格的最后一个汉字都落在第 5 格上*——标签是撑到 6 格的。而
// 「学院（部）」撑的是*到「部」为止*：「部」与「师」「生」「号」「期」齐，
// *「）」挂在第 6 格外面*。
//
// 所以撑宽*只数到最后一个汉字*，尾巴上的标点不计入。先前把「）」也数
// 进去，「学院（部）」只撑到 6 格（学 ＋ 两个半角 ＋ 院（部）），「部」落在
// 第 3 格上，比 Word 短了整整一格。
//
// 词条里存的是*裸标签*，空格在这儿补：markup 会把连续空格折叠成一个
// （实测「专␣␣␣␣业」在 markup 里只有 40pt），存进词条就废了。
//
// *空格只塞在汉字与汉字之间。* 「学院（部）」四个字要摊 4 个半角，逐缝
// 均摊会摊进括号旁边（学␣院␣（␣␣部）），而 Word 那一行是把它们全塞在「学」与
// 「院」之间。按码位挑缝，两边就对上了；另几格每一道缝都是汉字对汉字，
// 摊法与先前一样。
#let label-spread(chars, cells) = {
  // *收字符串也收内容*：cover 桶里存的是裸字符串，而从 base 桶读来的那几条
  // 是内容。撑宽要按字数摊空格，先取出纯文本
  let chars = if type(chars) == str { chars } else { plain(chars) }
  let cs = chars.clusters()
  let han(c) = c.contains(regex("\\p{Han}"))
  // 撑到*最后一个汉字*为止，尾巴上的标点挂在外面
  let hans = range(cs.len()).filter(i => han(cs.at(i)))
  if hans.len() == 0 { return text(spacing: 0.5em, chars) }
  let core = hans.last() + 1
  if core >= cells { return text(spacing: 0.5em, chars) }
  // 汉字对汉字的缝，记下标（缝 i 在 cs.at(i) 与 cs.at(i + 1) 之间）
  let slots = range(core - 1).filter(i => han(cs.at(i)) and han(cs.at(i + 1)))
  // *一道汉字缝都没有的，全塞在头一道。* 深圳那两份的头一格印的是
  // 「院（系）」——「院」之后就是括号，按上面那条一道缝都挑不出来，整格就撑不开
  // 了（下划线因此提早 48 起头）。文件里敲的正是「院␣␣␣␣␣（系）」，五个半角
  // 全在「院」与「（」之间
  let slots = if slots.len() > 0 { slots } else if core > 1 { (0,) } else { () }
  if slots.len() == 0 { return text(spacing: 0.5em, chars) }
  // 缺的宽度用半角摊进那几道缝：core 个字撑到 cells 个字宽，差 2×(cells−core)
  // 个半角。
  //
  // *摊不匀的那几个补在末一道缝*，不逐缝四舍五入——四舍五入会把宽度撑过头，
  // 而这一格的宽度是下划线长度的减数，差多少线就短多少。
  // *半角是整数个*：格数可以带小数（本部六格 20.5、深圳本科那两份是拿列宽
  // 折出来的），空格的个数不能——落到最近的整数
  let want = int(calc.round(2 * (cells - core)))
  let each = int(calc.floor(want / slots.len()))
  let extra = want - each * slots.len()
  let out = ""
  for (i, c) in cs.enumerate() {
    out += c
    if i in slots {
      out += " " * (each + if i == slots.last() { extra } else { 0 })
    }
  }
  text(spacing: 0.5em, out)
}

// 一格：标签 + 一条填到*整段内容宽*的线。
//
// *线覆盖的是真空格，不是一个盒子。* 原生 underline 只装饰真实字形——
// 实测 underline(box(width: 168pt)) 与 underline(h(168pt)) *一条线都不画*。
// 这反而与 Word 一致：那一段里带 w:u 的 run 装的就是一串空格。
//
// *total 是从缩进算起的整段宽，线 ＝ total − 已占。* 这样右缘齐，与两份
// 表单的意图一致：本科五格标签等宽（4 字），线也就等长 168，右缘 414.96 与
// Word 分毫不差；硕博六格标签在 Word 里不等宽（6～7.5 字，逐行改空格数），
// 但整段的格数逐份一样（六行里取多数），右缘因此齐。
//
// 值填进去占掉线的前一截，余下用空格补满；值超过 total 就折行、段落长高、
// 后面整体下移——与 Word 同。
//
// *线的位置要写死，不能留 auto。* auto 读的是*那一段字所用字体*的
// post 表：同一行里值走宋体（线心在基线下 1.375）、填充的空格走 Times
// （1.742），两截*错开 0.37* ——有字的地方和没字的地方接不上。Word 那边
// 是一条通线。
//
// 取值：本科那份 Word PDF 量出线顶在基线下 1.90、粗 1.44，线心 2.62；学校发的
// 硕士中期量出线顶 1.68、粗 1.56，线心 2.46。两者差 0.16pt，取中间的 2.48
// ＝ 0.155em（三号上 2.48）。粗细沿用 0.09em ＝ 1.44，与本科那份分毫不差。
//
// *与正文 #underline[] 那对数不共用*：正文那对是自己造 docx 在 macOS Word 上量
// 的（0.135em / 0.05em），粗细差一倍——这里对的是学校 Windows 排的表单，各用各的，
// 见 src/fonts/presets.typ 的 underline-offset。
//
// *evade: false*：Word 的下划线不绕开撇捺。
// 余量摊在*一串空格*上，个数取几个都行——text(spacing:) 定的是每个空格
// 的宽，总宽恒等于余量。取 21 只因为本科那一行 docx 里就是 21 个。
#let _fill-spaces = 21

#let _filled(
  label, value, cells: 4, total-cells: 15, gap: 1, gap-underlined: false,
) = context {
  // *一格就是一个全宽字，也就是本段的字号。* 表里存的是格数，折算放在
  // 这儿——存 pt 就把字号钉死了，也看不出那个数是数出来的
  let total = total-cells * text.size
  let lab = label-spread(label, cells)
  let sp = if gap > 0 { sp(gap) } else { [] }
  // 标签与值之间那个半角*在线外还是线上，两份表单不一样*。看 docx 里
  // 哪几个 run 带 w:u：
  //
  //   本科  「专␣␣␣␣业」＋一个*不带下划线*的半角，线从那之后才起
  //         （量出来线起于 250.56，而「业」收在 242.43，正好差 8）
  //   硕博  「导␣…␣师」之后*紧接着*就是带 w:u 的那一串空格，线中间不留缝
  //
  // 空白表单上看不出填进去的值该落在哪儿——两份都是一串空格。所以硕博这一档
  // 我们把半角*放在线上*：线的两端一分不动，值不至于贴着标签
  // （「导␣…␣师李四」难看），与本科那一档的视觉也就一致了。
  let head = lab + (if gap-underlined { [] } else { sp })
  // *标签区不足就补白*：线的左端对齐到这一份最宽的那个标签之后。补的白
  // 走 pad（一串空格调宽），不画线——原件里标签后那几个空格也不带 w:u
  // *标签区一律补到 cells 格，线的左端因此也齐。* 中文标签撑成等宽
  // （label-spread），本来就占满 cells 格；*英文标签撑不开*——那一支按码位
  // 挑缝摊空格，没有汉字就原样交回，于是线紧跟着标签、逐行各起各的。原件是拿
  // 尾随空格把标签补到一个固定宽度做的，深圳那两份补的正是 6 格：107.82 ＋ 96 ＝
  // 203.82，实测三行 204.24 / 205.68 / 207.36。
  //
  // *比 cells 格还宽的标签就顶出去*，线从它之后起——原件也是这样
  // （「Graduate Student:」那一行量得 244.32，别行 204–210）。*不按最宽的
  // 那个标签取齐*：那样六行的线一起缩到最短的那一条，整页看着就瘦了一圈。
  //
  // 补的白走 pad（一串空格调宽），*不画线*：原件里标签后那几个空格也不带 w:u
  let head-w = measure(head + sym.zws).width
  // *公共那一缘*：标签区补到 cells 格之后线该起的地方，六行都一样
  let base-column = cells * text.size + (
    if gap-underlined { 0pt } else { gap * 0.5 * text.size }
  )
  // 这一行自己的：标签比 cells 格还宽（「Graduate Student:」）就顶出去
  let column = calc.max(head-w, base-column)
  // 已占的宽度*要连着量一次，不能分段量再相加*——两处都会差：
  //
  //   ① 行尾的全角标点会被压掉半个字。「学院（部）」单独量出 88，接上值之后
  //      是 96——压缩是行尾才有的事。所以末尾缀一个零宽空格把它挡掉，
  //      值本身以全角标点收尾的那一档也一并挡住。
  //   ② 标签与值之间 Typst 会按 CJK-西文规则塞一段。「学␣…␣号」接
  //      「1160300000」实测 180 ＝ 96 ＋ 80 ＋ 4，那 4 分段量谁也算不着。
  //
  // 这两处都是*线的长度的减数*，少算多少线就长多少：先前分段量，
  // 「学院（部）」那一行的线长出 8、「学号」「日期」两行长出 4。
  let inner = (if gap-underlined { sp } else { [] }) + (
    if value == none { [] } else { value }
  )
  let used = column + measure(inner + sym.zws).width
  // *值在线上居中，不靠着标签左顶。* 空白表单上看不出填进去的值该落在
  // 哪儿——五份的这一格都是一串空格。左顶的话半行是字半行是空线，而这一页
  // 别的行都是居中的；把余量对半分在值的两边，一格才像填好的样子。
  //
  // *标签与值之间那个半角要并进左边那份，不能加在它外面。* 硕博那一档的
  // 半角本来就画在线上（见上），单摆在左边的话值就偏右半角那么多——实测「导
  // 师／李四」左边 104、右边 96。并进来之后两边各 100，值正落在线的正中。
  //
  // 它同时是*最低间隔*：值长到把余量吃光时，左边仍留这一个半角，
  // 值不至于贴上标签。
  //
  // *线的两端一分不动*：左端在标签区之后、右端在整段宽处，逐行都一样。
  let gapw = if gap-underlined { gap * 0.5 * text.size } else { 0pt }
  let room = total - used + gapw
  // *居中按公共那一缘算，不按这一行自己的线算。* 标签比 cells 格宽的那一行
  // （「学科/专业学位类别」「Graduate Student:」）线起得晚，若按自己那截线居中，
  // 值就比别行偏右一截——一页六行五行齐、一行歪。所以值的落点按「线从公共那一缘
  // 起」算，六行同一个中心；只有这一行的标签顶到了那个落点，才往右让开
  let inner-w = used - column
  let centred = base-column + (total - base-column - inner-w + gapw) / 2 - column
  let left = calc.max(centred, gapw)
  let pad(amount) = if amount > 0pt {
    text(spacing: amount / _fill-spaces, " " * _fill-spaces)
  }
  let rule(body) = underline(evade: false, offset: 0.155em, stroke: 0.09em, body)
  // 标签之后、线之前的那一段补白：把标签区补齐到 column
  let lead = { head; pad(column - head-w) }
  if room >= 0pt {
    // *值放得下：居中*，线的两端一分不动
    lead
    rule({
      pad(left)
      if value != none { value }
      pad(room - left)
    })
  } else {
    // *值放不下：自己折行，行行补白到整段右缘。*
    //
    // 交给 Typst 自己折是不行的——补白是照「一行装得下多少」算出来的两段空格，
    // 折了行那两段就落在错的行上：实测一个长学院名把线排成「从标签左缘起、到值
    // 中途止」，值的后半截没有线，整行还冲出整段右缘 20.6。
    //
    // *折行之后不再居中，改为左顶*——一行装不下的值在 Word 里是敲进那串
    // 空格里的，自然从线的左端起排；居中只在「一行有富余」时才谈得上。
    // 断行只断在空格处，一个词都放不下才逐字断。*线在换行处照旧覆盖行末
    // 的空格*（实测 linebreak 前的空格吃下划线），所以每一行都画到整段右缘。
    //
    // *折下来的行仍从标签区之后起，不探到版心左缘。* 这一格是一条填写栏，
    // 栏的左缘就是标签之后那一处；Word 那边的段落没有悬挂缩进，折下来的字会一直
    // 退到左缩进上，线也跟着退——那样线的左端就落在标签底下，看着像另起了一栏。
    // 用 h(标签区) 顶开（*不能用补白的空格*：行首的空白会被版面裁掉，
    // h 是间距元素，留得住——实测折行后线从 100.00 起，正是 20 ＋ 80）。
    //
    // *折下来的行退回公共那一缘。* 标签比 cells 格还宽的那一行（英文的
    // 「Graduate Student:」）首行的线是被标签顶出去的，可*第二行没有标签
    // 占位*——再照那一行自己的缩进排，就凭空缩进去一块。所以首行用它自己的
    // column，之后几行一律用 base-column，与别行的线左端对齐
    let words = plain(value)
    if words == none or words.trim() == "" {
      // 拆不出纯文本（值里带着格式）：不折，至少让线从标签区之后起
      lead
      rule({ pad(gapw); value })
    } else {
      // 首行从这一行自己的标签区之后起，之后几行退回公共那一缘
      let room-first = total - column - gapw
      let room-each = total - base-column - gapw
      // 断在空格处、每行 trim，见 src/text/plain.typ 的 wrap-lines
      let lines = wrap-lines(words, room-each, first: room-first)
      lead
      for (i, line) in lines.enumerate() {
        if i > 0 { h(base-column) }
        let room = if i == 0 { room-first } else { room-each }
        let used-here = measure(text(line) + sym.zws).width
        rule({
          pad(gapw)
          text(line)
          pad(room - used-here)
        })
        if i + 1 < lines.len() { linebreak() }
      }
    }
  }
}

// 首页那张字段表的*行表*，与内封那两张同一个形状（src/pages/titlepage.typ
// 的 _bachelor-rows / _graduate-rows）：*一行一个字段名*，标签与值各查各的表。
//
// 五个名字*与内封同名*——speciality / author / student-id / supervisor 在
// info 里早就有，一个新键都不加。日期这一格叫 date 而不是 defense-date：内封那格
// 印的是答辩日期，这一格印的是开题（中期）报告日期，两回事。
// 居中且带字距的那两行（校名、标题），末尾补一段字距。
//
// *Word 把末字那一段字距算进行宽，Typst 不算。* 「哈尔滨工业大学」七字
// 小二加宽 4pt：Word 排出来的行宽是 154（7 × 22），居中后左缘落在 220.73；
// Typst 按 150 居中，左缘 222.64——整行右移了半段字距 2pt。补一个 h(字距) 就
// 一致了（实测 220.68，与 Word 差 0.05）。
//
// *不改公共的 paragraph。* 论文封面、声明页那几行居中的也有同一处偏差
// （声明页小标题实测 +1.13，注释里记着），它们的对拍值是连着这点偏差一起钉
// 下来的；这一页自己补自己的。
// *西文吃半份*，与 src/styles/rules.typ 的 _latin-tracking 同一条——那边
// 折的是段里发给 text 的字距，这儿折的是补在行尾的那一份，两处要一致
#let _tracked(body, style) = body + h(
  style.at("tracking", default: 0pt)
    / (if style.at("font-zh", default: "songti") == "latin" { 2 } else { 1 }),
)

#let _bachelor-rows = ("speciality", "author", "student-id", "supervisor", "date")

// 硕博那三份*六格，字段也不同*：多一格「学院（部）」，「学科」按学位类别
// 换成「专业学位类别」，次序也不一样（学院在最上、学号在导师之后）。
#let _graduate-rows = (
  "affiliation", "speciality", "supervisor", "author", "student-id", "date",
)

// *本部研究生那四档是同一档。* 学校发的三份文件（硕开、硕中、博开）
// 横向本来就一样，差别全在竖向的三处，而*三处都是两票对一票*——按多数票
// 归一，四档（含手上没有文件的博中）因此塌成一档：
//
//   跨度                硕开     硕中     博开    取
//   校名→标题          64.56    63.84    63.84   63.84（标题二号；小一只有硕开一份）
//   题目→（学位论文）    42.49    42.49    73.69   42.49（博开自己多敲了一个空段）
//   （学位论文）→六格    37.97    88.37    37.76   37.9 （硕中自己多敲了两个空段）
//   六格逐行步进        36.31    36.31    35.00   36.31（1.75 倍；博开那份写的是
//                                                 w:line="700" exact ＝ 35pt）
//   第六格→落款        156.54   135.14   157.04  156.5
//
// 塌下来的这一档*与硕开逐条相同*，只有标题字号取了二号；博开上移 31.2、
// 硕中上移 50.4。*三份原件的落点不再逐份对得上*——对拍件里那三份的靶子
// 是按这一档重切的，不是任何一份原件的落点，见 tests/check-report-cover.py。
//
// *为什么敢归一*：这三处差别按学位归纳不出来（硕士两档就不同）、按阶段也
// 归纳不出来（博开与硕中同为二号），三个文件是三个人各敲各的，纸质表上是同一
// 张表。而横向那三处早就统一了，各有比「原件这么写」更硬的依据：
//
//   六格整段宽   20.5 格。本部五份一份一个数（18.5～20.5），连自己的上一代都
//                不沿用，纯手敲，没有稳定值——见 _graduate-field-cells
//   六格左缩进   按整段居中算。硕开与本科的 w:ind 本来就是居中的（差 0.26 /
//                2.68），另两份差 27.4 / 10.5——见 report-cover 里的 field-indent
//   form 的括号  与中间的词同为三号。硕中把两个括号敲成了小二，比词大一号
//
// *不照「六格在 form 与落款之间居中」排*：三份原件的六格全都偏上
// （区间中点减六格中点：硕开 59.3、硕中 23.4、博开 59.6）——底下那一大片空白是
// 留给填表人的，不是没排匀。所以规则是「六格紧跟 form、余量全甩在落款之前」，
// 题目变长时也正是先从那一片吃（见下面 blank-height 那一段）。
//
// 接口在这一页的 styles 参数（标题字号）；空段数眼下不开接口——它是段落序列
// 不是样式，真要改就改这张表。
//
// *博士中期手上没有文件*——四档归一之后这一条也就不必推了。
// 硕博六格整段占几个全宽字。*数 docx 里的格子*（全角字 1 格、半角空格
// 半格），六行里取多数。五份数下来一份一个数、连自己的上一代都不沿用——
// 硕开 19.5（留学生版）→ 20.5（现行），硕中 19.0 ＝ 19.0，博开 18.5——
// 纯手敲，没有稳定值。取硕开现行那一份。
//
// 整段已按居中排（见下面 field-indent），所以这个数只决定线有多长。
//
// *深圳那两份不走这一条*——它们的 w:ind 离居中差着 19.6 / 15.4，六行还
// 各行一致（1275 / 947 缇），是*定死的缩进*不是手抖；线的右端也跟着实测
// （量 PDF 里那六条下划线：开题到 20 格、中期到 19 格）。两处都写在上面那张表的
// field-indent 与 field-cells 上。
#let _graduate-field-cells = 20.5

// *校区那一层在最外面。* 深圳的开题与中期是另发的一套表单，段落序列与本部
// 那三份不同：没有 form 那一行（「（学位论文/实践成果）」是本部改版时加的）、
// 中期那份连落款都没有、校名之前的空段数与标题字号也各是各的。逐段取自
// 深圳硕士学位论文开题报告模板（2018版）.docx 与 深圳中期中文.docx。
// 本部研究生那四档（硕博 × 开题中期）*是同一档*，取值见上面那张多数票表。
// 段落序列写成三句：
//
//   form    紧跟题目（段前 12pt，前后不发空段）
//   落款    钉在参考位置（第六格之下 194.51，就是硕开原件那一处）
//   六格    *在 form 与落款之间居中*——中间的余量统共五个 1.25 倍空段
//           （22.80 一个），两个摊在上面、三个摊在下面
//
// *居中只能落在空段的粒度上*，正中要 2.6 个空段，落不到整数上：二上三下
// 是上 83.97 / 下 110.54，三上二下是上 106.97 / 下 87.54，两边的残差差不多。
// *取上小下大那一分*——版面的视觉中心本来就比几何中心略高，宁可上面紧
// 一点；反过来会显得整块往下坠。
//
// *上下两组要同高才谈得上分配*：先前上面那一组走 Normal 的 1.5 倍
// （31.20），与下面的 1.25 倍（22.80）不等高，挪一个上去落款就跟着掉 8.4。
#let _harbin-graduate = (
  title-size: zihao.erhao, blanks-before-form: 0, blanks-after-form: 2,
  field-first-above: 12pt, field-spacing: 1.75, field-snap: false,
  // 六格与末行之间：一串 (个数, 行距, 贴不贴)
  tail: ((3, 1.25, false),), blanks-after-seal: 0,
)

#let _graduate-sheet = (
  harbin: (
    master: (proposal: _harbin-graduate, interim: _harbin-graduate),
    doctor: (proposal: _harbin-graduate, interim: _harbin-graduate),
  ),
  // 深圳。*研究生那一套，硕士与博士同一份*；本科按本部排
  // （src/axes.typ 的 campus-for）。
  //
  //   开题  标题 sz48 ＝ 小一；校名前三个空段（Normal 1.5 倍）；题目行之后一个
  //         空段、六格头一格段前 12pt（w:before="240"）；六格后三个空段（1.25 倍）
  //         再落款「深圳校区教务部 制」
  //   中期  标题 sz44 ＝ 二号；校名前两个空段；题目行之后两个空段；六格后三个
  //         空段，*没有落款*（词条那边写的是 none，见 seal-shenzhen-interim）
  shenzhen: (
    // *研究生这一档，硕士与博士同一份*（查实过）。本科那边一份文件都没有，
    // 按本部排，见 src/axes.typ 的 campus-for
    master: (
      proposal: (
        title-size: zihao.xiaoyi, form-row: false,
        // 校名之前三个空段，*五号*（那一份 docDefaults 写的是 sz21）、1.5 倍
        blanks-before-university: (3, zihao.wuhao, 1.5),
        // 那个空段自己也写着 w:before="240"（12pt），六格头一格再来一份——两份都要
        blanks-before-fields: (1, 1, 12pt),
        field-first-above: 12pt, field-spacing: 1.75, field-snap: false,
        // 六格：整段左缩进 2.25cm（w:ind w:left="1275"，六行里五行都是这个数）、
        // 整段 20 格——*都不按居中算*，见 _graduate-field-cells 抬头
        field-indent: 2.25cm, field-cells: 20,
        // 英文版（Template of Master's Thesis Proposal for foreign students）：
        // 题目行与六格之间*两个*空段（都写着 w:before="240"），六格左缩进
        // 2cm（w:ind w:left="1134"）、整段 25 格，标题那一段也写着 w:spacing
        en: (
          title-spacing: 40, blanks-before-fields: (2, 1, 12pt),
          field-indent: 2cm, field-cells: 25, title-reserve: 2,
        ),
        tail: ((3, 1.25, false),), blanks-after-seal: 0,
      ),
      interim: (
        title-size: zihao.erhao, form-row: false,
        blanks-before-university: (2, zihao.xiaoer, 1), blanks-before-fields: (2, 1, 0pt),
        field-first-above: 0pt, field-spacing: 1.75, field-snap: false,
        // 六格：整段左缩进 1.67cm（w:ind w:left="947"，六行一致）、整段 19 格
        field-indent: 1.67cm, field-cells: 19,
        // 英文版（深圳中期英文.docx）：题目行与六格之间*三个*空段、头一格
        // 段前 12pt（中文那份没有）、六格整段左缩进 1.5cm 另加首行 0.86cm
        // （w:ind w:left="850" w:firstLine="489"）、整段 19.5 格
        en: (
          title-spacing: 40, blanks-before-fields: (3, 1, 0pt),
          field-first-above: 12pt, field-indent: 1.5cm, field-first-indent: 0.86cm,
          field-cells: 19.5,
        ),
        tail: ((3, 1, false),), blanks-after-seal: 0,
      ),
    ),
  ),
)

// 本部那三份都有 form 行、校名前两个空段——照旧那一套，写成默认省得每一档重复
#let _sheet-defaults = (
  form-row: true, blanks-before-university: (2, zihao.xiaoer, 1), blanks-before-fields: none,
  // 六格：按居中算、20.5 格，见 _graduate-field-cells 抬头。
  //
  // *「题 目：」那一行七份一律居中。* 原件里只有深圳开题那一份写着
  // w:jc="center"（另带左缩进 141 缇、首行 282 缇），另外六份都没写、顶着左缘
  // ——可*那六份的这一格都空着*（深圳中期填的是「******」），标签左起是
  // 「还没填」的样子。深圳开题是唯一一份把题目真填进去的原件（示例题目
  // 「机器人宇航员双臂协调轨迹规划」），它给出的正是填好之后该有的样子。
  // 填好之后这一行就是整页里的一行字，与校名、文种、（学位论文）、落款一样居中。
  //
  // 要照空白表单那样左起，styles 里把 title 那一档的 align 改回 left 即可，
  // 本科那份的首行缩进也就跟着回来。
  field-indent: auto, field-cells: _graduate-field-cells, title-centered: true,
  // 六格的*首行*再往右挪多少（本部与深圳中文都没有，只有深圳中期英文写着）
  field-first-indent: 0pt,
  // 标题那一段 run 里的 w:spacing（Word 的单位，见 msword-run-spacing）
  title-spacing: 40,
  // *原件给题目留了几行*：超出这个数才吃空段（见下面那段「题目长了就少发
  // 几个空段」）。五份中文表单的题目都排成一行；深圳开题的*英文版*原件
  // 那一行本来就占两行、六格也照两行的位置印着（Word 排出来量得 425.28），
  // 所以那一档留两行
  title-reserve: 1,
  // *英文版那一张的覆盖层*，只在文档语言为英文时并上来。本部那两份英文版
  // 与中文版*段落清单完全一样、只换词*，唯一的出入是标题那一段没写
  // w:spacing（硕开英第 89 段、硕中英第 61 段逐 run 查过）；深圳那两份另有一套，
  // 见上面那张表
  en: (title-spacing: 0),
)

#let cover(
  // proposal（开题）还是 interim（中期）
  stage: "proposal",
  info: info-defaults,
  // 这一页用哪一层词条排。auto 跟文档语言——留学生那两份是中英各一张封面，
  // 版式一样、只换词，见 src/terms/built-in.typ 的 en.cover
  lang: auto,
  // 印在「题 目：」后面的*论文题目*。auto 取 info.title。
  // *表单上这一格是空的*——官方那五份 docx 里「题 目：」后面什么都没有，
  // 是留给填表人写的。我们把 info 里的题目接上去，这一页才是排好的成品
  title: auto,
  terms: auto,
  overrides: (:),
  layout: auto,
  // 排不下时在纸角发一条红字提示。题目长了先靠减空段收（见下面 eat 那一段），
  // *校名之前那一组不动*，四组吃完仍装不下就发这一条。
  //
  // Typst 没有「警告」这一档，只有拦编译，而为了一页封面卡住整篇文档不合适
  // ——所以提示排进页面里，编译照常。与终稿封面、内封同一支，见
  // src/styles/paragraph.typ 的 overflow-note。
  //
  // auto ＝ 不写 ＝ 发。排不下是真出了事，默认该说一声
  warning: auto,
  // 印在首页上的*表单名*。auto 取词条。*不是论文题目*——题目走上面那个
  report-title: auto,
  // 这一页的各档取值，*一档一个名字*（与声明页同一个约定，
  // src/pages/declarations.typ）。
  //
  // *给了的那几档并进内置的那一份，不是整张表重打*——每一档并一层，所以
  // 「只换表单名的字号」就是一句话：
  //
  //     cover(styles: (report-title: (size: "xiaoyi")))
  //
  // *键名与这一页的参数对齐*：report-title 是「硕士学位开题报告」那一行、
  // title 是「题 目：」加论文题目那一行——先前这两档叫 title 与 title-label，
  // 与同名的两个参数正好错位，指的是哪一行说不清。硕博六格那一档叫 field、
  // 校名叫 university、「（学位论文）」叫 form、末行叫 seal，本科多一个
  // wordmark（校名题字）。词条那边同一处也叫 title（先前是 title-label，
  // *-label 是角色词、不是轴值*，占着轴后缀的位置）
  //
  // 硕博三份的标题字号本来就各写各的（见 _graduate-title-size），这个口子正是
  // 留给「我不同意那份的字号」的。名字写错*当场报错*——静默插一个没人读的
  // 键，页面上纹丝不动，与词条覆盖那一处同一个道理。
  //
  // 内置的两份底色不同（本科段前段后各 60 缇、行距 1.25、不贴网格；硕博一个
  // spacing 都没有、贴行网格），按 degree-level 挑，见文件抬头那张表。
  styles: (:),
) = context {
  // *跟文档语言。* 留学生那两份英文版就是中英各一份装在同一个 .doc 里，
  // 后半截那张英文封面与中文那张*段落清单完全一样*，只换词——所以这一页
  // 不分版式，只换词条桶。见 src/terms/built-in.typ 的 en.cover
  let this-lang = resolve-lang(lang)
  let t = if terms != auto { terms } else {
    term-table(this-lang, "cover", overrides: overrides)
  }
  let degree-level = info.degree-level
  let graduate = degree-level != "bachelor"
  // *按谁的格式排。* 深圳只发了硕士那两份表单，本科与博士按本部排——
  // 段落序列、版面、词条三处都跟着这一个数，见 src/axes.typ 的 campus-for。
  // 版面那一处在 src/layout/resolve.typ 的 default-inputs，同一句话
  let campus = campus-for(info.campus, degree-level)
  // 这一页的页面设置：文档那一份（iota-hit 按学位与阶段挑好的报告版面）、并上
  // 这一份表单*首页自成一节*的那点差额、再并上用户在这一页写的。
  //
  // 五份本部表单与深圳中期的首页与正文*同一节*（那五份里连分页符都没有，
  // 见文件抬头），差额是空的；只有深圳开题的首页另有一套页边距与网格，见
  // src/layout/presets.typ 的 report-cover-layouts
  let layout = resolve-local(
    layout-for(none, report-cover-layouts
      .at(campus, default: (:))
      .at(degree-level, default: (:))
      .at(stage, default: (:))),
    layout,
  )
  // 硕博逐份不同的那几处，见上面那张表。博士中期回落到博士开题
  let sheet = _sheet-defaults + (if graduate {
    // 校区 → 学位 → 阶段。本部的博士中期按博士开题走
    // *深圳的博士照硕士那一份*（查实过，两份表单相同），本部的博士中期
    // 按博士开题走
    let by-campus = _graduate-sheet.at(campus)
    let by-degree = by-campus.at(degree-level, default: by-campus.at("master"))
    by-degree.at(stage, default: by-degree.at("proposal"))
  } else {
    // 本科五格：整段 15 格，首行缩进按居中算（见 _graduate-field-cells 抬头）
    (title-size: zihao.xiaoyi, blanks-before-form: 0, blanks-after-form: 0,
      field-first-above: 0pt, field-spacing: 1.75, field-snap: false,
      field-cells: 15, tail: ((5, 1.25, false),), blanks-after-seal: 0)
  })
  // *英文那一张的覆盖层最后并*，见 _sheet-defaults 的 en
  let sheet = sheet + (if this-lang == "en" { sheet.en } else { (:) })
  // 这一页查词条时递哪几根轴。
  //
  // *学位类别只在硕博那张表上算*：这一页没有一格按它分档（「学科/专业学位类别」
  // 照字面印，见 src/terms/built-in.typ），递进去是为了 degree-type-for 那一道校验
  // （写了 academic 又写 practice 当场报错）。本科表单没有这个区分，不递。
  //
  // *全部的轴都递*（src/terms/lookup.typ 的 variant-of），这一页解出来的阶段、学位、校区、
  // 学位类别压过 info 的。先前 form 一根不递，为的是躲开 base 里内封那一档「类别」——
  // 那一档现在住内封自己的桶，base 只放各页共用的字，没什么要躲的了
  let variant = variant-of(info) + (stage: stage, degree-level: degree-level, campus: campus) + (
    if graduate {
      (degree-type: degree-type-for(degree-level, info.degree-type, info.form))
    } else { (:) }
  )
  let pick(name) = term-for(t, name, variant)
  // 表单名*与深圳那两份的页眉同一支*，见 src/pages/report/title.typ——
  // 那儿说了哪一档用学位的名、哪一档用文种
  let stage-word = _report-title.stage-word(t, variant)
  let composed-title = _report-title.report-title(t, this-lang, info, variant)
  // *各格的标签全走同一支解析器。* 专业、学号、指导教师三条住 base 桶
  // （两页共用，见 src/terms/built-in.typ），作者与日期两条住 cover 桶——term-table
  // 已经把 base 并进本页的表，所以一次 term-for 就够，不必分情况、也不必去读
  // 内封那个桶。
  //
  // *日期那一格只有硕博拼阶段名*：硕博三份印「开题报告日期」「中期报告
  // 日期」，本科两份印的是光「日  期」。所以拼不拼由 degree-level 定，不由 stage 定
  // *日期那一格中英两种拼法*：中文是「｛阶段名｝＋日期」（开题报告日期），
  // 英文按 stage 各写各的（Defense Date／The Date），词条里就分好了档。
  // 本科两份中文印的是光「日  期」。
  //
  // *判据是语言，不是「取不取得到阶段名」*——英文那一侧现在也有 stage-*
  // 了（深圳本科英文版的文种那一行要拿它拼「Undergraduate Thesis (Design)
  // ＋ Interim Report」），照「取得到就拼」办会把日期排成「Interim ReportThe Date」
  let label-of(name) = {
    let l = pick(name)
    if name == "date" and graduate and this-lang == "zh" and stage-word != none {
      stage-word + l
    } else { l }
  }

  // *语言跟着这一页走*——日期那一格靠它排（英文那一页排的是英文日期，
  // 见 src/terms/date.typ）。region 照旧 cn：它管的是汉字标点的形，与语言无关
  //
  // 这一节的 Normal 字号。*页面上没有一段吃它*——每一段（含空段）都写着
  // 自己的字号；写着是为了与文件对得上：本科那份 Normal 是 sz="24" ＝ 小四
  set text(lang: this-lang, region: "cn", size: zihao.xiaosi)
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)

  // *两档的底色不是一回事，来自各自的 Normal 样式*，见文件抬头那张表。
  // 各段自己写了的（硕博那几处 before=240、line=420／300／700）在下面压过来。
  let normal = if graduate {
    // 硕博：Normal 里*一个 spacing 都没有*（w:pPr 只有 widowControl 与
    // jc），行距因此是单倍；*贴行网格*——sectPr 的 docGrid 写着
    // w:type="lines"，段落一律吃，写着 snapToGrid=0 的那几处在下面关掉
    (above: 0pt, below: 0pt, line-spacing: 1,
      snap-to-docgrid: true, bold: true)
  } else {
    // 本科：Normal 行距 1.25，每一段自己又写着 before=60 after=60 缇 ＝ 各 3pt；
    // 网格不启用（docGrid 没有 w:type）
    (above: 3pt, below: 3pt, line-spacing: 1.25,
      snap-to-docgrid: false, bold: true)
  }
  // 字段格整段有多宽（格数 × 三号），以及*居中要缩进多少*。
  // 为什么本部按居中而不照文件的 w:ind、深圳为什么照，见 _graduate-field-cells 抬头
  let field-width = sheet.field-cells * zihao.sanhao
  let field-indent = if sheet.field-indent == auto {
    (layout.text-width - field-width) / 2
  } else { sheet.field-indent }
  // *英文那一页整页没有汉字*——行高、字距、字体三样都按西文那一档走。
  //
  // Word 也是这么排的：那几段只写了 w:eastAsia（校名 楷体_GB2312），西文一侧仍是
  // 正文样式的 Times。*三样都跟着*——六格的行距 1.75 倍，中文那份量出步进
  // 36.4（16 × 1.297 × 1.75），深圳英文版量出 32.40（16 × 1.15 × 1.75）；字距
  // 同一个 w:spacing 汉字拿两份、西文拿一份（校名 30 个字母量出每字母 ＋2.00，
  // 汉字那一侧 ＋4.00，见 src/msword.typ 的 msword-run-spacing）——
  // 折半那一步在 styles 里，font-zh 写 "latin" 就走那一支。
  let script(zh, font: auto) = if this-lang == "en" {
    (font-zh: "latin", font: "serif")
  } else {
    (font-zh: zh, font: if font == auto { zh } else { font })
  }
  let built-in = if graduate {
    (
      university: normal + script("kaishu", font: "kaishu-gb2312") + (
        size: zihao.xiaoer, align: center, tracking: msword-run-spacing(40),
      ),
      // 标题。*哪一档写着 w:spacing 由表说了算*——本部英文版那一段的 run 里
      // 一个都没写（硕开英第 89 段、硕中英第 61 段逐 run 查过，只有 b 与 sz44），
      // 中文各份与深圳英文版写的都是 val=40，见 _sheet-defaults 的 title-spacing
      report-title: normal + script("songti") + (
        size: sheet.title-size, align: center,
        tracking: msword-run-spacing(sheet.title-spacing),
      ),
      // 「题 目：」＋题目。*整行居中*，见下面发这一段的地方——深圳中期那份
      // 没写 w:jc，顶着版心左缘排，见上面那张表的 title-centered
      title: normal + script("songti") + (
        size: zihao.xiaoer, align: if sheet.title-centered { center } else { left },
      ),
      // 「（学位论文/实践成果）」：段前 12pt（w:spacing w:before="240"）
      form: normal + script("songti") + (
        size: zihao.sanhao, align: center, above: 12pt,
      ),
      // 六格：整段左缩进（w:ind left，含折行都从那里起）按居中算；行距
      // w:line=420 ＝ 1.75 倍；不贴网格（w:snapToGrid val="0"）
      field: normal + script("songti") + (
        size: zihao.sanhao,
        left-indent: field-indent, first-line-indent: sheet.field-first-indent,
        line-spacing: sheet.field-spacing, snap-to-docgrid: sheet.field-snap,
      ),
      seal: normal + script("songti") + (size: zihao.sanhao, align: center),
    )
  } else {
    (
      report-title: normal + (
        size: zihao.xiaoyi, font-zh: "songti", font: "songti",
        align: center, tracking: msword-run-spacing(40),
      ),
      wordmark: normal + (size: zihao.xiaoer, font-zh: "latin", align: center),
      // 「题 目：」＋题目。*整行居中*，见下面发这一段的地方。首行缩进是
      // 空白表单上那个值（中期 firstLineChars=300、开题 250），留着是为了与
      // 文件对得上——居中那一支不吃它（src/styles/paragraph.typ 的 paragraph），
      // 用户把 align 改回 left 就又生效
      title: normal + (
        size: zihao.xiaoer, font-zh: "songti", font: "songti", align: center,
        first-line-indent: (chars: if stage == "interim" { 3 } else { 2.5 }),
      ),
      // 五格：*首行*缩进（w:ind 写的是 firstLineChars=686 ＝ 6.86 字，
      // 我们按居中算，见 _graduate-field-cells 抬头），行距 w:line=360 ＝ 1.5 倍，
      // 段前 9.6pt（w:before="192"），段后跟 Normal。
      //
      // *本科这一档是首行缩进不是整段左缩进*，照文件——值折行时下一行
      // 顶到版心左缘，Word 也是这样
      field: normal + (
        size: zihao.sanhao, font-zh: "songti", font: "songti",
        first-line-indent: field-indent,
        line-spacing: 1.5, above: 9.6pt,
      ),
      seal: normal + (size: zihao.xiaoer, font-zh: "lishu", font: "lishu", align: center),
    )
  }
  let styles = {
    let out = built-in
    for (name, over) in styles {
      if name not in built-in {
        panic(
          "unknown style " + repr(name) + " on the report cover (expected one of "
            + built-in.keys().map(repr).join(", ") + ")",
        )
      }
      out.insert(name, built-in.at(name) + over)
    }
    out
  }
  // 空段走 enter，与本包别处同一支（论文封面、声明页、摘要都用它）。
  //
  // *段前段后、贴不贴网格、贴哪一张，三样全页同一份*，绑上去——往下写的
  // 就是 enter(2, size: "xiaoer") 这种，换几行就写几。三样都从 normal 取，
  // 与有字的段同一张底色，不另抄一遍。
  //
  // *¶ 走西文那一档*（enter 的 font 默认就是 serif）：段落标记取 rFonts 的
  // ascii 槽，而这五份表单的空段一个都没写 ascii（写着的 eastAsia 管不着它），
  // 见 src/styles/enter.typ 抬头与本文件上面那一段。
  // *行距也绑上*：enter 自己的默认是「跟正文那一档」（styles.body），而这一页
  // 是表单，段落属性得跟本页的 normal，两者不是一回事——本科那一份 normal 是
  // 1.25、硕博是单倍
  let enter = enter.with(
    line-spacing: normal.line-spacing,
    spacing: normal.above,
    snap: normal.snap-to-docgrid,
    layout: layout,
  )

  // ── 题目长了就少发几个空段 ──────────────────────────────────────────
  //
  // 与终稿封面同一个路子（src/pages/cover.typ 的求解器）：题目每折一行，就吃掉
  // 一个空段，六格与落款因此*留在原位*；空段吃光了才整页往下移。
  //
  // 表单上那一格是空着的，六格与落款的位置是表单印死的——填表人写长了，Word 里
  // 也是先把底下的空行删掉，而不是让落款掉到下一页。
  //
  // *先吃落款上面那一大片*——六格与落款之间是这一页最空的一带（硕开五个
  // 1.25 倍、硕中三个、本科两个，量下来 150 上下），题目长了正该从那儿找地方。
  // 不够再往上：题目行下面那组 → form 行上面那组 → 标题与题目行之间 → 校名
  // 之前。*这样落款留在原位，上面几行也不动*；先动上面的话校名会被提起来，
  // 而校名是这一页最先入眼的一行。
  //
  // *「题 目：」钉在版心左缘，题目在版心里居中。*
  //
  // 空白表单上这一行是标签左起、题目由填表人往右写；填好之后题目就是整页里的
  // 一行字，与校名、文种、（学位论文）、落款一样该居中。所以*标签不参与
  // 居中*——它停在版心左缘，题目自己的中线落在版心中线上。
  //
  // *逐行对着 x ＝ 0 居中，首行让标签一步。* 以版心中点为原点：标签的左缘
  // 在 −a（就是版心左缘），题目那一栏是 (−a, a)。
  //
  //   居中  每一行都对着 x ＝ 0 居中
  //   让位  首行左边被标签占着：它的左缘退到*标签右缘*就不再往左，剩下的
  //         往右排。*不另留空隙*——那个冒号是全角的，自己就占一格
  //
  // 于是短题目正居中、长题目贴着标签接着排，折下来的行也是页面居中。
  //
  // 原件里只有深圳开题那一份把题目真填进去了（示例题目「机器人宇航员双臂协调
  // 轨迹规划」），那一段写着 w:jc="center"、整行连标签一起居中；另外六份的这一格
  // 都空着（深圳中期填的是「******」），标签顶着左缘是「还没填」的样子。
  let title-value = if title != auto { title } else {
    // *英文那一页接英文题目*——info 的 title / title-en 是同一样东西的
    // 两档语言，由此处生效的语言选；与六格那张行表走同一支 value-of
    value-of(info, "title", lang: this-lang)
  }
  let title-metrics = linebox.metrics(styles.title, layout: layout)
  // 标签宽与每一行的宽都*按这一档的真样式量*（字号、字距、全角冒号两侧的
  // CJK-西文间距都算进去），光按字号量会算短
  let title-as(body) = {
    show: style-rules.rules.with(styles.title, layout: layout, set-font: true)
    body
  }
  let label-w = measure(title-as(pick("title") + sym.zws)).width
  // 折成几行：首行让掉标签那一截，其余整条版心。空段吃几个按行数算（见下面那一段）
  let title-rows = wrap-lines(
    title-value,
    layout.text-width,
    first: layout.text-width - label-w,
    measure-as: t => title-as(text(t)),
  )
  let title-lines = calc.max(1, title-rows.len())
  // *按高吃，不按个数吃*：题目一行 31.2（小二 1.2 倍）、落款前一个空段
  // 22.8（三号 1.25 倍），个数一对一地减是补不平的。各组的空段高各不相同，
  // 所以逐组按「还差多少」算要减几个。
  // *与发的时候同一份计算*（src/styles/enter.typ 的 enter-height）：字体
  // 系数、贴不贴网格都算进去，再加上每段的段前——先前这儿自己算，标题与题目
  // 之间那个空段实发 31.2 却按 20.75 算，余量落到了错的组上。
  // 默认的行距与贴网格跟 normal，与 enter 那一支的默认一致
  let blank-height(size, ls: auto, snap: auto, spacing: auto) = enter-height(
    size,
    line-spacing: if ls == auto { normal.line-spacing } else { ls },
    snap: if snap == auto { normal.snap-to-docgrid } else { snap },
    layout: layout,
  ) + (if spacing == auto { normal.above } else { spacing })
  // 各组现有的个数
  let n-below-title = if graduate and not sheet.form-row {
    sheet.blanks-before-fields.at(0)
  } else if graduate { sheet.blanks-after-form } else {
    // 本科：开题四个 1.5 倍、中期一个单倍加三个 1.5 倍
    if stage == "interim" { 4 } else { 4 }
  }
  let n-above-form = if graduate and sheet.form-row { sheet.blanks-before-form } else { 0 }
  let n-title-gap = if graduate { 1 } else { 2 }
  // 落款之前那一片：硕博逐份不同（见那张表），本科两个
  let n-before-seal = if graduate { sheet.tail.map(((n, ..)) => n).sum() } else { 2 }
  // 题目多出来的高，就是要吃掉的量
  let grow = (title-lines - sheet.title-reserve) * title-metrics.baseline-gap
  // 一组一组地吃：交回 (这一组还剩几个, 还差多少)。
  //
  // *四舍五入，不向上取整。* 空段有最小高（22.80），吃几个都对不齐题目
  // 多出来的那一截；向上取整会*一律多吃一个*，落款反被顶高——题目折成
  // 两行时多出 31.20，取整吃两个 45.60，落款上跳 14.40。四舍五入之后同一处只吃
  // 一个、落款下沉 8.40，偏差减半，方向也不再总是一边倒。
  //
  // 吃不完的余量往下一组传，可*不足半个空段的零头就不传了*——传下去只会
  // 让下一组多吃一个、把偏差又翻回去。
  let eat(n, h, left) = {
    if left <= 0pt or n == 0 { return (n, left) }
    let k = calc.min(n, int(calc.round(left / h)))
    (n - k, calc.max(left - k * h, 0pt))
  }
  // ① 落款之前：硕博照那张表的 tail（行距与贴网格逐份写着），本科是 enter 的默认
  let seal-h = if graduate {
    blank-height(zihao.sanhao, ls: sheet.tail.at(0).at(1), snap: sheet.tail.at(0).at(2))
  } else { blank-height(zihao.sanhao) }
  let (before-seal, left1) = eat(n-before-seal, seal-h, grow)
  let (below-title, left2) = eat(
    n-below-title,
    // *行距要与发的时候一致*：本部研究生这一组是 1.25 倍（与落款之前那一组
    // 同高，六格才分得匀，见 _harbin-graduate 抬头），先前这儿按单倍算，吃一个
    // 空段少算 2.05
    // ② 六格之上：本部研究生 1.25 倍不贴网格（与 ① 同高，六格才分得匀），
    // 深圳那两份照它们表里那一档，本科 1.5 倍
    blank-height(zihao.sanhao, snap: false, ls: if graduate and not sheet.form-row {
      sheet.blanks-before-fields.at(1)
    } else if graduate { 1.25 } else { 1.5 }),
    left1,
  )
  // ③ form 之上、④ 标题与题目之间：都走 enter 的默认（行距与贴网格跟 normal）
  let (above-form, left3) = eat(n-above-form, blank-height(zihao.sanhao), left2)
  let (title-gap, left4) = eat(n-title-gap, blank-height(zihao.sanhao), left3)
  // *校名之前那一组不动。* 校名是这一页最先入眼的一行，位置一变整页的
  // 气象就变了；上面四组吃完还不够，就不是「挤一挤」能解决的事了——照终稿封面
  // 那一档，在纸角发一条红字，编译照常（见 src/styles/paragraph.typ 的
  // overflow-note）。*Typst 没有「警告」这一档，只有拦编译*，而为了一页
  // 封面卡住整篇文档不合适


  // *整页先装进一个变量，量完再发。* 两个原因：
  //
  //   一  set page 要发在一切内容之前——页面设置落在已经排了字的页上，Typst
  //       会另起一页（实测多出一张空封面）
  //   二  「排不下」得*量出来*，不能拿「空段吃完了还有余量」当判据：
  //       减空段只是把疏密收紧，收紧之后整页照样可能装得下（题目七行那一档
  //       就是：四组吃完还差 48，可落款仍在版心里）
  let body = {
    // *页首那一段的段前要自己发。* Word 在页首照进段前（本科那份首段实测
    // 落在版心上边界下方 3.21，正是 Normal 的 3pt），而 Typst 的块间距在容器
    // 开头会被丢掉。硕博那份段前是 0，这一句发的是 v(0pt)，无害
    v(normal.above)


  if graduate {
    // 硕博：两个小二空段、*文字*校名（楷体_GB2312 小二加粗居中、字距 2pt）、
    // 一个小二空段。*没有题字图*——那是本科那两份专有的
    let (n-before, before-size, before-spacing) = sheet.blanks-before-university
    enter(n-before, size: before-size, line-spacing: before-spacing)
    // *校名走 pick 不直接取*：深圳那两份印全称（本部英文那一页印 HIT）
    let university = pick("university")
    paragraph(_tracked(university, styles.university), styles.university, layout: layout)
    enter(size: zihao.xiaoer)
  } else {
    // 本科：一个小四、两个小二、*校名题字*、一个小二
    enter(size: zihao.xiaosi)
    enter(2, size: zihao.xiaoer)
    // 题字*是段落里的一个内联对象*（docx 里 w:drawing 在 run 里），所以走
    // paragraph、由段落属性居中，不自己 align。尺寸*照那张图的 wp:extent
    // 写*（cx="2131060" cy="400685"，EMU）——折出来 167.8 × 31.55pt，
    // Word 导出的 PDF 里那张图量出 167.25 × 31.35，差 0.3%，是它自己的落笔取整。
    //
    // *盒高 ＝ 图高 ＋ 本段的行距余量。* Word 里这一行的行盒
    // ＝ max(图高, 自然行高) ＋ 余量，图坐在基线上、余量落在基线以下：实测
    // 图顶 146.19、基线 177.60（图底下方 0.05），下一段的上升部再往下 24.96
    // ——反推行深 5.09，而余量 ＝ (1.25 − 1) × 1.15 × 18 ＝ 5.175，对得上。
    // Typst 的内联盒是盒底坐基线、盒上不带行深，所以把余量并进盒高、图靠上放
    let m = linebox.metrics(styles.wordmark, layout: layout)
    paragraph(
      box(
        width: 2131060 * emu,
        height: 400685 * emu + m.baseline-gap - m.natural,
        align(top, wordmark(width: 2131060 * emu)),
      ),
      styles.wordmark,
      layout: layout,
    )
    enter(size: zihao.xiaoer)
  }

  paragraph(
    _tracked(
      if report-title != auto { report-title } else { composed-title },
      styles.report-title,
    ),
    styles.report-title,
    layout: layout,
  )

  // 标题之后：硕博一个三号空段，本科两个（题目长了会吃掉，见上）
  enter(title-gap, size: zihao.sanhao)
  // 「题 目：」那一行*接上题目*。表单上这一格空着，是留给填表人的；
  // 题目长了就折行、整页往下移，与 Word 同。
  //
  // *整行居中，这一处是有意不照 Word 排的。* 五份表单上这一行都是左起
  // （本科还带 2.5／3 字的首行缩进），可那是*空白表单*——标签左顶着，
  // 题目由填表人往右写。填好之后整行只占版心左半边，而这一页别的行（校名、
  // 标题、form、末行）全是居中的，独它偏左。所以填好的这一行整体居中。
  //
  // 要照空白表单那样左起，styles 里把这一档的 align 改回 left 即可，
  // 本科那份的首行缩进也就跟着回来。
  paragraph(
    {
      // *标签不裹 box*：裹进去之后它尾随的那个空格会被吃掉（英文那两份的
      // 词条是「Title: 」，排出来成了「Title:Trajectory…」）。空白用 h() 顶开
      // ——行首的空格会被版面裁掉，h 是间距元素，留得住
      pick("title")
      for (i, row) in title-rows.enumerate() {
        let w = measure(title-as(text(row))).width
        if i > 0 { linebreak() }
        // 对着 x ＝ 0 居中；首行从标签右缘算起，退不动就贴着标签排
        let mid = (layout.text-width - w) / 2
        h(calc.max(mid - (if i == 0 { label-w } else { 0pt }), 0pt))
        text(row)
      }
    },
    // *首行缩进要关掉*：本科那两份的这一档自带 2.5／3 字的首行缩进（空白
    // 表单上标签就是那么排的），而这里的横向位置是自己算好用 h() 顶出来的——
    // 缩进再吃一截，首行就装不下、末字被挤到下一行（本科那份实测掉了一个「究」）
    styles.title + (align: left, first-line-indent: (chars: 0)),
    layout: layout,
  )
  if graduate and not sheet.form-row {
    // 深圳那两份没有 form 行，题目行之后直接是空段（个数与行距见那张表）
    let (n, sp, above) = sheet.blanks-before-fields
    let n = below-title
    // 那个空段自己的段前（深圳开题写着 w:before="240"）：enter 收的是 spacing
    enter(n, size: zihao.sanhao, line-spacing: sp, spacing: above)
  } else if graduate {
    // 「（学位论文/实践成果）」那一行——按 form 印一个，表单的填写说明写着
    // 「选择其一，另一项删除」。段前 w:spacing before=240。
    //
    // *括号与词同一号（三号），前后不留空段。* 三份在这一带各不相同：
    // 硕开把原来那个空段*换成*这一行，硕中*插进去*、原来两个空段留着，
    // 博开*保留*空段、把这一行加在其后；硕中还把两个括号敲成了小二，比中间
    // 的词大一号。留学生版（上一代）根本没有这一行——三样都是同一次改版
    // （实践成果进来）留下的手痕，取硕开那一份：它是唯一把这次改版做干净的。
    //
    // *form 单独查*，不并进上面那个 variant，理由见 variant 那一段
    // form 那一行前后的空段*照各份的设计*，见上面那张表
    enter(above-form, size: zihao.sanhao)
    // *括号跟语言*：中文全角、英文半角
    let (open, close) = if this-lang == "en" { ([(], [)]) } else { ([（], [）]) }
    paragraph(
      open + term-for(t, "form", variant) + close,
      styles.form,
      layout: layout,
    )
    // *1.25 倍，与落款之前那一组同高*——六格要在 form 与落款之间居中，
    // 两组不同高就分不了（见 _harbin-graduate 抬头）
    enter(below-title, size: zihao.sanhao, line-spacing: 1.25, snap: false)
  } else {
    // 开题四个 1.5 倍；中期头一个是单倍（w:line 没写，跟 Normal 的 1.25），
    // 后三个才 1.5（w:line="360"）。题目长了从这一组吃起，*先吃单倍那一个*
    if stage == "interim" and below-title >= 4 { enter(size: zihao.sanhao) }
    enter(calc.min(below-title, if stage == "interim" { 3 } else { 4 }),
      size: zihao.sanhao, line-spacing: 1.5)
  }

  // 五格（本科）／六格（硕博）。*概念直接继承论文*——在 info 里早就有，
  // 一个新键都不加；换的只是这一页印的字样
  let field = styles.field
  // 值从 info 取，日期走日期那一支解析（写 ISO、排出「2026年3月」）。
  // *与内封的 _resolve-row 同一个约定*：行表给字段名，标签查词条、值查 info
  for (i, name) in (if graduate { _graduate-rows } else { _bachelor-rows }).enumerate() {
    // 取值走*与内封同一支*（src/document/info.typ 的 value-of）：按语言挑
    // info 的哪一份、日期走解析。*先前这儿是自己写的简化版、少了 -en 那
    // 一步*，于是英文封面的六格印的是中文值——学院、导师、学科都是，只有题目
    // 单独特判过
    let value = value-of(info, name, lang: this-lang)
    paragraph(
      // 本科：标签 4 字 + 一个半角、整段 15 格（五行都是这个数）
      // 硕博：标签 6 字 + 一个*画在线上*的半角、整段 20.5 格
      if graduate {
        _filled(
          label-of(name), value,
          cells: 6, total-cells: sheet.field-cells, gap-underlined: true,
        )
      } else {
        _filled(label-of(name), value, cells: 4, total-cells: sheet.field-cells, gap: 1)
      },
      field + (
        if graduate and i == 0 { (above: sheet.field-first-above) } else { (:) }
      ),
      layout: layout,
    )
  }

  // 六格与末行之间的空段：*逐份不同*（硕开五个 1.25 倍不贴网格、硕中三个
  // 单倍贴、博开一个 35pt 固定值加三个单倍），见那张表；本科两份都是两个
  if graduate {
    // *题目长了先从这一片吃*（见上）：逐组按顺序减，减到哪一组算哪一组
    let left = n-before-seal - before-seal
    for (n, line-spacing, snap) in sheet.tail {
      let eaten = calc.min(left, n)
      enter(n - eaten, size: zihao.sanhao, line-spacing: line-spacing, snap: snap)
      left -= eaten
    }
  } else {
    enter(before-seal, size: zihao.sanhao)
  }
  // *取到 none 就不排这一行*：深圳中期那份封面末尾直接是空段，没有落款
  // 本科那一行是隶书：没装这副字就画轮廓（src/fonts/glyphs.typ），字全在收录里
  // （「哈尔滨工业大学教务处制」）；硕博的「研究生院制」是宋体，走真字
  let seal = pick("seal")
  if seal != none {
    paragraph(
      if graduate { seal } else { context outlined("lishu", lishu-outline-font, seal) },
      styles.seal, layout: layout,
    )
  }
    // 末行之后：硕士中期两个（三号），本科中期一个（小二），另三份没有
    if graduate { enter(sheet.blanks-after-seal, size: zihao.sanhao) }
    else if stage == "interim" { enter(size: zihao.xiaoer) }
  }

  // 装不下就在纸角发一条红字（见这一页 warning 参数的说明）。*比的是版心*
  // ——量出来的高超过版心高，这一页就一定溢到第二页去了
  let too-tall = measure(block(width: layout.text-width, body)).height > layout.text-height
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin, header: none, footer: none,
    foreground: if too-tall and warning != false {
      overflow-note(pick("warning-overflow"), pick("warning-false"), lang: this-lang)
    },
  )
  body
}
