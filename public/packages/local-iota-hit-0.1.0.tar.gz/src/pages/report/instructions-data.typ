// 学校报告原件的说明文字。独立说明、文本框提示及表尾注释的来源见 docs/report-instructions.md。
// 这里只存原文和排版角色；不使用 heading、enum、figure 或 bibliography，避免影响正文计数。
#let _p(text, ..format) = metadata((iota-instructions-block: (kind: "paragraph", text: text, format: format.named())))
#let _h(text) = metadata((iota-instructions-block: (kind: "section", text: text)))
#let _levels(lang: "zh", shenzhen: false) = metadata((iota-instructions-block: (kind: "levels", lang: lang, shenzhen: shenzhen)))
#let _doc(source, kind, blocks, lang: "zh") = metadata((iota-instructions-source: (id: source, kind: kind, lang: lang))) + blocks.join()

#let _fonts-zh(subject: "论文") = (
  _p(subject + "中所用中文字体（除各级标题外）为宋体，各级标题用黑体；论文中所用数字、英文为新罗马字体。"),
  _p("节标题        小3号字，建议段前0.5行，段后0.5行；"),
  _p("条标题        4号字，建议段前0.5行，段后0.5行；"),
  _p("款、项标题    小4号字，建议段前0行，段后0行；"),
  _p("正文          小4号字，建议段前0行，段后0行，每页约33行。"),
)
#let _fonts-en = (
  _p("Section header  Size 15, 6 pound before and after paragraph"),
  _p("Article title  Size 14, 6 pound before and after paragraph"),
  _p("Item title  Size 12, 0 pound before and after paragraph"),
  _p("Main body  Size 12, 0 pound before and after paragraph, 33 lines each page"),
)
#let _references-zh(restart: true) = (
  _h("（1）图书文献："),
  _p("[1] 唐绪军. 报业经济与报业经营[M]. 北京：新华出版社，1999：117-121."),
  _p("[2] 霍斯尼 R K. 谷物科学与工艺学原理[M]. 李庆龙，译. 北京：中国仪器出版社，1989：32-35."),
  _h("（2）期刊论文"),
  _p("[" + (if restart { "1" } else { "3" }) + "] 覃睿，田先钰. 从创新潜力到创新成果：一个创新潜力形成与释放模型[J]. 科技进步与对策，2007（2）：148-152."),
  _h("（3）学术会议"),
  _p("[" + (if restart { "1" } else { "4" }) + "] 张佐光，张晓宏，仲伟虹，等. 多相混杂纤维复合材料拉伸行为分析[C]//第九届全国复合材料学术会议论文集（下册）. 北京：世界图书出版公司，1996：410-416."),
  _h("（4）学位论文"),
  _p("[" + (if restart { "1" } else { "5" }) + "] 金宏. 导航系统的精度及容错性能的研究[D]. 北京：北京航空航天大学自动控制学科博士学位论文，1998：60-63."),
)

#let bachelor-proposal = _doc("harbin-bachelor-proposal", "sheet", (
  _h("一、开题报告主要内容"),
  _p("1．课题来源及研究的目的和意义"),
  _p("（正文 宋体小4号字，行距1.25倍，段前0行，段后0行）"),
  _p("2．国内外在该方向的研究现状及分析"),
  _p("3．主要研究内容"), _p("4. 研究方案"),
  _p("5．进度安排，预期达到的目标"),
  _p("6．课题已具备和所需的条件、经费"),
  _p("7．研究过程中可能遇到的困难和问题，解决的措施"),
  _p("8．主要参考文献"),
  _h("二、开题报告要求"),
  _p("1．开题报告的字数应在3000字以上。"),
  _p("2．参考文献的要求："),
  _p("（1）本科毕业论文（设计）的参考文献一般不少于15篇，外文文献不少于3篇（特殊专业可酌情确定明确要求），应有近两年的参考文献。产品说明书、未公开发表的研究报告不宜作为参考资料。"),
  _p("（2）参考文献按在开题报告中出现的次序列出。"),
  _p("（3）参考文献书写顺序：序号 作者.文章名.学术刊物名.年，卷（期）：引用起止页。"),
))
#let bachelor-interim = _doc("harbin-bachelor-interim", "outline", (
  _p("一、论文（设计）工作是否按开题报告预定的内容及进度安排进行"),
  _p("（正文 宋体小4号字，行距1.25倍，段前0行，段后0行）"),
  _p("二、已完成的研究工作及成果"),
  _p("三、后期拟完成的研究工作及进度安排"),
  _p("四、存在的问题与困难"), _p("五、论文按时完成的可能性"),
))

#let master-proposal = _doc("harbin-master-proposal", "sheet", (
  _p("填写说明：封面（学位论文/实践成果）选择其一，另一项删除。"),
  _h("一、开题报告应包括下列主要内容："), _p("目录", left-indent: 24pt),
  _p("1．课题来源及研究目的和意义"),
  _p("1.1．课题的来源", left-indent: 24pt),
  _p("1.2．课题研究目的和意义（不少于500字）", left-indent: 24pt),
  _p("2．国内外研究现状及分析"),
  _p("2.1．国外研究现状", left-indent: 24pt), _p("2.2．国内研究现状", left-indent: 24pt),
  _p("（注意对所引用文献的准确标注）", left-indent: 24pt),
  _p("2.3．国内外文献综述的简析（不少于500字）", left-indent: 24pt),
  _p("（综合评述：国内外研究取得的成果，存在的不足或有待深入研究的问题）", left-indent: 24pt),
  _p("3．主要内容及方案（不少于1500字）"),
  _p("（撰写宜使用将来时态，切忌将论文目录直接作为主要内容，要突出本人研究内容）"),
  _p("4.预期达到的目标"),
  _p("5．已完成的学术研究/实践工作（根据课题情况选择）"),
  _p("（详细撰写目前已进行的学术研究或者实践工作的内容和完成情况）"),
  _p("6．进度安排"), _p("（建议从进入课题时间开始）"),
  _p("7．为完成课题所需的条件"), _p("8．研究过程中可能遇到的问题以及解决的措施"), _p("9．参考文献"),
  _h("二、对开题报告的要求"), _p("1．开题报告的字数应在5000字以上；"),
  _p("2．参考文献应在30篇以上，其中外文文献应不少于三分之一，且应有近两年的参考文献，参考文献以高水平期刊、会议文章、行业标准、国家规范等为主。本学科的基础和专业课教材不应列为参考文献。"),
  _p("三、开题报告进行后，此报告同《硕士学位论文开题报告评议结果》存各学院（部）研究生秘书处，以备研究生院及所属学院进行检查。"),
  _h("四、字体、字号及其他规定"), .._fonts-zh(subject: "报告"),
  _p("报告不要设置页眉。"), _h("五、层次代号及说明"), _levels(),
  _h("六、常用的四种参考文献类型标注形式。"), .._references-zh(),
))
#let master-interim = _doc("harbin-master-interim", "sheet", (
  _p("填写说明：封面（学位论文/实践成果）选择其一，另一项删除。"),
  _h("一、中期报告应包括下列主要内容"), _p("目录", left-indent: 24pt),
  _p("1．学术研究或者实践工作（根据课题情况选择）进度情况（具体写明研究的主要内容，已完成的主要内容，字数不少于300字）"),
  _p("2．目前已完成的学术研究或者实践工作内容和取得的研究结果（重点介绍本人独立已完成的具体研究内容及取得的结果，切忌将某某理论、硬件原理、芯片说明书之类内容填充在此部分，不少于3000字）"),
  _p("3.目前存在的或预期可能出现的问题"), _p("4.后期学术研究或者实践工作的进度安排"),
  _p("二、中期检查进行后，此报告同《硕士学位论文中期报告评议结果》存各学院（部）研究生秘书处，以备研究生院及所属学院进行检查。"),
  _h("三、字体、字号及其他规定"), .._fonts-zh(),
  _h("四、层次代号及说明"), _levels(),
))
#let master-proposal-en = _doc("harbin-master-proposal-en", "sheet", (
  _h("I Thesis proposal shall include the following contents："), _p("Table of Contents", left-indent: 24pt),
  _p("1．The source of topic, research purpose and significance"),
  _p("1.1．The source of topic", left-indent: 24pt),
  _p("1.2．Research background and significance（No less than 500 words）", left-indent: 24pt),
  _p("2．Literature review and analysis"), _p("2.1．Research review", left-indent: 24pt),
  _p("（Pay attention to accurate citation tagging of the referenced literatures）", left-indent: 24pt),
  _p("2.2．Analysis of literature review（No less than 500 words）", left-indent: 24pt),
  _p("（Comprehensive reviews：Research acquired results analysis inside and outside of country）", left-indent: 24pt),
  _p("3．Main contents of research（No less than1500 words）"),
  _p("（It is better to use future tense in composing avoid putting the table of contents directly as the research content, it is required to highlight the research work of the author.）"),
  _p("4. Expected goals"), _p("5．Already accomplished work"),
  _p("（Write down what you have done with the research work and the completion）"),
  _p("6．Time scheme（Suggest：starting from the time when the research topic was decided）"),
  _p("7．Required conditions"), _p("8．Anticipated problems and solutions"), _p("9．References"),
  _h("II Requirements for thesis proposal"),
  _p("1．The length of thesis proposals should be no less than 5000 words；"),
  _p("2．References should be more than 30, among them foreign references should account for no less than one third and include references published in recent 2 years. References mainly include high-level journals, conference papers, industry standards, national regulations, etc. Basic and major textbooks of the discipline are not acceptable references."),
  _p("III After the thesis proposal, this proposal should be filed by graduate secretary with Evaluation Results Form for Thesis Proposals of Master’s Candidates."),
  _h("IV Font, size, and other regulations"),
  _p("The proposal written in English should use Times New Roman font with size 12 in the main text, and use bold characters for titles, and capitalize the first letter of each substantive in the title."),
  .._fonts-en, _h("V Level mark and illustrations"), _levels(lang: "en"),
  _h("VI Reference annotation form"),
  _p("Number citations consecutively in square brackets. And number them in superscripts in the main text where it should be."),
  _h("(1) Journal"),
  _p("[1] Chiu, S., Fuzzy model identification based on cluster estimation. Journal of Intelligent and Fuzzy Systems[J]. 1994.2 (3): 267–278."),
  _h("(2) Text book"),
  _p("[2] M. Akay. Time frequency and wavelets in biomedical signal processing[M]. Piscataway, NJ: IEEE Press, 1998:123-135."),
  _h("(3) Conference article"),
  _p("[3] J. E. Monzon. The cultural approach to telemedicine in Latin American homes[C]//Proc. 3rd Conf. Information Technology Applications in Biomedicine, ITAB´00, Arlington, VA, 2002:50-53."),
  _h("(4) Dissertation"),
  _p("[4] J. R. Boheki. Adaptive AR model spectral parameters for monitoring neonatal EEG [D]. Biomed. Eng. program, Univ. Fed. Rio de Janeiro, Rio de Janeiro, Brazil, 2000."),
), lang: "en")
#let master-interim-en = _doc("harbin-master-interim-en", "sheet", (
  _h("I Interim report should include the following contents"),
  _p("1. The main research contents and progress"),
  _p("（Set out to the main contents of the study, completed contents, the main contents of no less than 300 words）"),
  _p("2. The completed research work and results（Introduce specific research contents and results, avoiding such as theories, hardware principles, or chip specifications, no less than 3000 words）"),
  _p("3. Existing problems and anticipated problems"), _p("4. Research plan to be implemented and schedule"),
  _p("II After the Interim inspection, this table should be filed with Evaluation Result Form for Interim Inspection of Master’s Thesis ."),
  _h("III Font, size, and other regulations"),
  _p("The whole paper should use Times New Roman font with size 12 in the main text, and use bold characters for titles, and capitalize the first letter of each substantive in the title."),
  .._fonts-en, _h("IV Level mark and illustrations"), _levels(lang: "en"),
), lang: "en")

#let doctor-proposal = _doc("harbin-doctor-proposal", "sheet", (
  _p("填写说明：封面（学位论文/实践成果）选择其一，另一项删除。"),
  _h("一、开题报告应包括下列主要内容"), _p("目录", left-indent: 24pt),
  _p("1.课题来源及研究的目的和意义"),
  _p("1.1．课题来源或研究背景", left-indent: 24pt),
  _p("1.2．研究的目的及意义（不少于1000字）", left-indent: 24pt),
  _p("2.国内外在该方向的研究现状及分析（文献综述）"),
  _p("2.1．国外研究现状", left-indent: 24pt), _p("2.2．国内研究现状", left-indent: 24pt),
  _p("（注意对所引用国内外文献的准确标注）", left-indent: 24pt),
  _p("2.3．国内外文献综述的简析（不少于1000字）", left-indent: 24pt),
  _p("（综合评述：国内外研究取得的成果，存在的不足或有待深入研究的问题）", left-indent: 24pt),
  _p("3.主要研究内容、实施方案及其可行性论证"),
  _p("3.1．主要研究内容（不少于2000字）", left-indent: 24pt),
  _p("（撰写宜使用将来时态，不能只列出论文目录来代替对研究内容的分析论述）", left-indent: 24pt),
  _p("3.2．实施方案及其可行性论证（不少于3000字）", left-indent: 24pt),
  _p("4.预期达到的目标"), _p("5.前期的学术研究或者实践工作的结果"),
  _p("6.进度安排（从确定博士选题收集文献写起）"),
  _p("7.预期创新点或者创新性成果（要根据研究内容和国内外研究现状准确提炼，充分体现创新性）"),
  _p("8.为完成课题已具备和所需的条件和外协计划"),
  _p("9.研究或者实践工作过程中可能遇到的问题以及解决的措施"), _p("10.参考文献"),
  _h("二、开题报告字数应不少于1.5万字。"),
  _h("三、字体、字号及其他规定"), .._fonts-zh(),
  _h("四、层次代号及说明"), _levels(),
  _h("五、常用的四种参考文献类型标注形式。"), .._references-zh(restart: false),
))
#let doctor-interim = _doc("harbin-doctor-interim", "notes", (
  _p("1.博士中期检查最迟于2.5学年末完成。考核结束后，此表须由研究生上传系统。"),
  _p("2.此表为A4大小，请双面打印。各栏空格不足可自行加页。红色字体部分请在打印时删除。"),
  _p("3.此表仅作为学生修改和后期各阶段审查及监督之用，不存入学生档案。"),
))

#let _toc-zh = (
  _p("目录应包括论文中全部章、节、条三级标题及其页码。中英文摘要及目录用罗马字符编码；正文及以后的页码用阿拉伯数字重新编码。"),
  _p("目录中各章标题用黑体小4号字，其余用宋体小4号字，数字及符号用Times New Roman字体。"),
  _p("对于超过一行的目录内容提前换行，换行后缩进至相应标题第一个字符处。"),
)
#let _toc-en = (
  _p("The table of contents shall cover all Chapter, Section and Subsection level headings in the thesis together with their corresponding page numbers."),
  _p("If any catalog entry extends beyond one line, a line break shall be inserted in advance; the wrapped text shall be indented to align with the first character of the corresponding heading."),
)
#let _bachelor-fonts-zh = (
  _p("章标题：黑体小2号字，多倍行距值1.25，段前1行，段后0.8行；"),
  _p("节标题：黑体小3号字，多倍行距值1.25，段前0.5行，段后0.5行；"),
  _p("条标题：黑体4号字，多倍行距值1.25，段前0.5行，段后0.5行；"),
  _p("款、项标题：黑体小4号字，多倍行距值1.25，段前0行，段后0行；"),
  _p("正文：宋体小4号字，多倍行距值1.25，段前0行，段后0行。"),
  _p("全文所有数字、英文：Times New Roman字体。"),
)
#let _bachelor-fonts-en = (
  _p("Chapter Titles: Times New Roman, 18 point, multiple line spacing set to 1.25, 1 line space before paragraph, 0.8 line space after paragraph."),
  _p("Section Titles: Times New Roman, 15 point, multiple line spacing set to 1.25, 0.5 line space before paragraph, 0.5 line space after paragraph."),
  _p("Clause Titles: Times New Roman, 14 point, multiple line spacing set to 1.25, 0.5 line space before paragraph, 0.5 line space after paragraph."),
  _p("Sub-clause and Item Titles: Times New Roman,12 point, multiple line spacing set to 1.25, 0 line space before paragraph, 0 line space after paragraph."),
  _p("Main Text: Times New Roman, 12 point, multiple line spacing set to 1.25, 0 line space before paragraph, 0 line space after paragraph."),
)
#let _bachelor-proposal-shenzhen(design: false) = _doc(
  if design { "shenzhen-bachelor-design-proposal" } else { "shenzhen-bachelor-proposal" }, "textboxes", (
  .._toc-zh, _h("一、字数及打印要求"),
  _p("开题报告的字数应在3000字以上，A4纸单面打印。"),
  _h("二、字体要求"), .._bachelor-fonts-zh,
  _h("三、其他说明"),
  _p("模板中所引用的示例，只作为开题报告书写格式的示范，并不代表研究内容的示范。如开题报告中涉及图、表及公式等内容，请详细参阅《本科生毕业论文（设计）写作指南》相关要求。"),
  _p("报告正文分章节撰写，每章应另起一页。"), _h("参考文献的要求："),
  _p("本科毕业" + (if design { "设计" } else { "论文" }) + "的参考文献一般不少于15篇，外文文献不少于3篇（特殊专业可酌情确定明确要求），应有近两年的参考文献。产品说明书、未公开发表的研究报告不宜作为参考资料。"),
  _p("参考文献按在开题报告中出现的次序列出。"),
  _p("参考文献书写顺序：[序号] 作者. 文章名. 学术刊物名. 年，卷（期）：引用起止页。"),
))
#let bachelor-proposal-shenzhen = _bachelor-proposal-shenzhen()
#let bachelor-design-proposal-shenzhen = _bachelor-proposal-shenzhen(design: true)
#let bachelor-interim-shenzhen = _doc("shenzhen-bachelor-interim", "textboxes", (
  .._toc-zh, _h("一、打印要求"), _p("A4纸单面打印。"),
  _h("二、字体要求"), .._bachelor-fonts-zh, _h("三、其他说明"),
  _p("模板中所引用的示例，只作为中期报告书写格式的示范，并不代表研究内容的示范。其他详细格式请参阅《本科生毕业论文（设计）写作指南》相关要求。"),
  _p("报告正文分章节撰写，每章应另起一页。"),
))
#let _bachelor-shenzhen-en(interim: false) = _doc(
  if interim { "shenzhen-bachelor-interim-en" } else { "shenzhen-bachelor-proposal-en" }, "textboxes", (
  .._toc-en, _h("I. Word Count and Printing Requirements"),
  // 英文中期原件也写 proposal 和 3,000；按原文保留，来源说明中记录此处模板残留。
  _p("The proposal shall contain no fewer than 3,000 words and be printed single-sided on A4 paper."),
  _h("II. Font Format Requirements"), .._bachelor-fonts-en,
  _h("III. Additional Instructions"),
  _p("If figures, tables, formulas or other elements are included in the proposal, please refer to the relevant specifications stipulated in Guidelines for Undergraduate Graduation Thesis (Design) for detailed requirements."),
  _p("Each chapter shall start on a new page."),
  ..(if interim { () } else { (
    _h("Requirements for References"),
    _p("Undergraduate graduation thesis (design) shall include no less than 15 references in general, among which at least 3 shall be foreign-language literature (adjustments may be made for specific majors as appropriate with clear requirements). References published within the past two years shall be included. Product specifications and unpublished research reports are not recommended as reference materials."),
    _p("The references should be listed in order of appearance in the thesis proposal."),
    _p("Reference writing order: [serial number] author. article name. academic publication name. year, volume (issue): the beginning and ending pages of the citation."),
  ) }),
), lang: "en")
#let bachelor-proposal-shenzhen-en = _bachelor-shenzhen-en()
#let bachelor-interim-shenzhen-en = _bachelor-shenzhen-en(interim: true)

#let master-proposal-shenzhen = _doc("shenzhen-master-proposal", "note", (
  _p("模板中所引用的示例，只作为开题报告书写格式的示范，并不代表研究内容的示范。如开题报告中涉及图、表及公式等内容，请详细参阅《哈工大研究生学位论文撰写规范》相关要求。"),
))
#let master-proposal-shenzhen-en = _doc("shenzhen-master-proposal-en", "note", (
  _p("The examples provided in the template are intended solely to illustrate the formatting of the thesis proposal and are not representative of the actual research content. For detailed instructions on figures, tables, formulas, and other elements in the proposal, please refer to the relevant sections of the Graduate Thesis Writing Guidelines of Harbin Institute of Technology."),
), lang: "en")
#let master-interim-shenzhen = _doc("shenzhen-master-interim", "sheet", (
  _p("（此页不打印,可将文字颜色全选为无色）"),
  _h("一、中期报告应包括下列主要内容"),
  _p("1．课题主要研究内容及进度情况（具体写明研究的主要内容，已完成的主要内容，字数不少于300字）"),
  _p("2．目前已完成的研究工作及结果（重点介绍本人独立已完成的具体研究内容及取得的结果，切忌将某某理论、硬件原理、芯片说明书之类内容填充在此部分，不少于3000字）"),
  _p("3．后期拟完成的研究工作及进度安排"), _p("4．存在问题、困难及其解决方案"),
  _p("5．如期完成全部论文工作的可能性"),
  _p("二、中期报告时间应最迟不得超过第二学年春季学期开学后第3周末。"),
  _p("三、中期检查进行后，此表同硕士学位论文中期报告评议结果提交各学院秘书处，以备研究生院及所属学院进行检查。"),
  _h("四、字体、字号及其他规定"), _p("目录不需有页眉。"),
  _p("论文中所用中文字体（除各级标题外）为宋体，各级标题用黑体；论文中所用数字、英文为新罗马字体。"),
  _h("五、层次代号及说明"), _levels(shenzhen: true),
  _p("六、中期报告的字体、字号及参考文献类型标注形式等格式要求请参照《哈尔滨工业大学学位论文撰写规范》。"),
))
#let doctor-proposal-shenzhen = _doc("shenzhen-doctor-proposal", "sheet", (
  _h("一、开题报告应包括下列主要内容"), _p("目录", left-indent: 24pt),
  _p("1．课题来源及研究的目的和意义"),
  _p("1.1．课题来源或研究背景", left-indent: 24pt),
  _p("1.2．研究的目的及意义（不少于1000字）", left-indent: 24pt),
  _p("2．国内外在该方向的研究现状及分析（文献综述）"),
  _p("2.1．国外研究现状", left-indent: 24pt), _p("2.2．国内研究现状", left-indent: 24pt),
  _p("（注意对所引用国内外文献的准确标注）", left-indent: 24pt),
  _p("2.3．国内外文献综述的简析（不少于1000字）", left-indent: 24pt),
  _p("（综合评述：国内外研究取得的成果，存在的不足或有待深入研究的问题）", left-indent: 24pt),
  _p("3．前期的理论研究与试验论证工作的结果"),
  _p("4．学位论文的主要研究内容、实施方案及其可行性论证"),
  _p("4.1．主要研究内容（不少于2000字）", left-indent: 24pt),
  _p("（撰写宜使用将来时态，不能只列出论文目录来代替对研究内容的分析论述）", left-indent: 24pt),
  _p("4.2．实施方案及其可行性论证（不少于3000字）", left-indent: 24pt),
  _p("5．论文进度安排，预期达到的目标"),
  _p("5.1．进度安排（从确定博士选题收集文献写起）", left-indent: 24pt),
  _p("5.2．预期达到的目标", left-indent: 24pt),
  _p("6．学位论文预期创新点（要根据研究内容和国内外研究现状准确提炼，充分体现创新性）"),
  _p("7．为完成课题已具备和所需的条件、外协计划及经费"),
  _p("8．预计研究过程中可能遇到的困难、问题，以及解决的途径"),
  _p("9．主要参考文献（应在50篇以上，其中外文资料不少于二分之一，参考文献中近五年（从开题当年算起）内发表的文献一般不少于三分之一，且必须有近二年内发表的文献资料）。"),
  _h("二、开题报告字数应不少于1.5万字。"),
  _p("三、开题报告时间应最迟应于第四学期结束前完成。"),
  _p("四、若本次开题报告未通过，需在三个月内再次进行开题报告。第二次学位论文开题报告仍未通过者，将取消其学籍。"),
  _p("五、开题报告结束后，评议小组要填写《博士学位论文开题报告评议结果》上报院（系）研究生教学秘书备案。"),
  _h("六、字体、字号及其他规定"), .._fonts-zh(),
  _h("七、层次代号及说明"), _levels(),
  _h("八、常用的四种参考文献类型标注形式。"), .._references-zh(),
))
#let doctor-interim-shenzhen = _doc("shenzhen-doctor-interim", "sheet", (
  _p("1．博士研究生学位论文中期报告一般在入学后的第五学期末完成。", left-indent: 14pt, first-line-indent: -13pt),
  _p("2．此报告由学生本人填写，请导师签字后提交一份给检查小组。答辩结束后由检查组长签署意见。", left-indent: 14pt, first-line-indent: -13pt),
  _p("3．报告经中期报告检查组长签字同意后，由学院保存，以备论文答辩时参考。教务部将对研究生的学位论文中期报告进行抽查。", left-indent: 14pt, first-line-indent: -13pt),
  _p("4．报告统一用A4纸打印。"),
))

// 字体、页面和段落格式属于模板，不属于可覆盖的说明文字。
#let profile(info, lang) = {
  let base = (
    body: (asian-font: "songti", size: 12pt, line-spacing: (exactly: 21pt),
      snap-to-grid: false, tracking: 0pt, first-line-indent: 0pt, above: 0pt, below: 0pt, justify: false),
    title: (asian-font: "heiti", size: 14pt, line-spacing: (exactly: 21pt), align: center,
      snap-to-grid: false, tracking: 0pt, first-line-indent: 0pt, above: 0pt, below: 0pt),
    section: (sticky: true),
    layout: (header: (shown: false), footer: (shown: false)),
    before: 0pt, gap: 21pt, title-gap: 1.5em, width: auto, body-left: 0pt, native-songti: false,
  )
  if info.degree-level == "bachelor" {
    base.body += (line-spacing: 1.25)
    if info.campus == "harbin" and info.stage == "proposal" {
      base.title += (size: 18pt, line-spacing: 1.25, weight: "bold")
      base.section += (asian-font: "heiti", size: 15pt, above: 6pt, below: 6pt, weight: "bold")
      base.before = 20pt
      base.gap = 10pt
    } else if info.campus == "shenzhen" {
      base.body += (fill: rgb("c00000"))
      base.title += (fill: rgb("c00000"))
      base.section += (weight: "bold")
    }
  } else if info.campus == "shenzhen" and info.degree-level == "master" and info.stage == "proposal" {
    base.title += (asian-font: "kaishu-gb2312", size: 22pt, weight: "bold", align: left, line-spacing: 1.25)
    base.body += (asian-font: "kaishu-gb2312", size: 16pt, line-spacing: 1.25)
    base.gap = 16pt
    if lang == "en" {
      base.title += (fill: rgb("ff0000"))
      base.body += (size: 12pt, fill: rgb("ff0000"), first-line-indent: 18.9pt)
    }
  } else if info.campus == "shenzhen" and info.degree-level == "doctor" and info.stage == "interim" {
    base.title += (asian-font: "songti", size: 16pt, weight: "bold", line-spacing: (exactly: 18.75pt), left-indent: 1pt)
    base.body += (size: 14pt, line-spacing: (exactly: 28.3pt))
    base.layout += (paper: (width: 595.25pt, height: 841.85pt), margin: (left: 28.3pt, right: 22.65pt, top: 22.65pt, bottom: 26.9pt))
    base.before = 137.75pt
    base.gap = 44.45pt
    base.title-gap = 3em
    base.width = 533.7pt
    base.body-left = 42.75pt
    base.native-songti = true
  }
  if lang == "en" { base.title += (weight: "bold") }
  base
}
