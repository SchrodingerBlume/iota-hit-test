#import "../../docxtyp.typ" as d
#import "@local/docxtyp:0.1.0" as core
#import d.styles: paragraph
#import d.content: plain-text, metadata-of
#import "../../info.typ": info-get
#import "../../axes.typ": report-stages
#import "../../terms/lookup.typ": term-table, term-for, variant-of
#import "../../terms/lang.typ": resolve-lang, title-of
#import "../../layout/parts.typ": layout-for
#import "../../layout/matter.typ": clear-page, cover-exit
#import "../../once.typ": once
#import "./instructions-data.typ" as data

#let _flat(c) = if c == none { () } else if type(c) == content and c.func() == [].func() {
  c.children.map(_flat).flatten()
} else { (c,) }

#let _literal(c) = {
  let s = plain-text(c)
  // 显式保护行首开标点。WJ 是字体角色选择器的边界；避免 ZWS 与括号同组后破坏共享字体映射。
  if s.starts-with(regex("[（〔［｛〈《「『【]")) { text("\u{2060}") + c } else { c }
}

#let _levels(lang, shenzhen, style, lay) = {
  let en = lang == "en"
  let p(c) = paragraph(_literal(c), style + (align: center), layout: lay, latin: en)
  let common = if en {
    "The title should be written in a sequence style, and the content should be written in a new paragraph."
  } else if shenzhen {
    "题序顶格书写，与标题间空1个半角字符,阐述内容另起一段"
  } else { "题序顶格书写，阐述内容另起一段" }
  let item = if en {
    "The sequence number should be written after four half-width character space, and the content is following another four half-width characters space by row."
  } else { "题序空4个半角字符书写，内容空4个半角字符接排" }
  // 版式表不经过论文数据表的字号／三线表规则；小表整体移动，避免合并格跨页裁字。
  block(width: 100%, above: 0pt, below: 0pt, breakable: false,
    grid(columns: (70pt, 135pt, 1fr), inset: (x: 3pt, y: 1pt), stroke: 0.5pt + black,
      align: center + horizon,
      p(if en { "Name" } else { "层次名称" }),
      p(if en { "Example" } else { "示例" }),
      p(if en { "Illustration" } else { "说明" }),
      p(if en { "Section" } else { "节" }), p("1 □□……□"), grid.cell(rowspan: 3, p(common)),
      p(if en { "Article" } else { "条" }), p("1.1 □□……□"),
      p(if en { "Item" } else { "款" }), p("1.1.1 □□……□"),
      p(if en { "Sequence Number" } else { "项" }), p("（1）□□…□    □□…□□…□□\n□□……"), p(item),
    ))
}

#let _render(body, label, info, lang, local-layout, source) = context {
  let spec = data.profile(info, lang)
  let base = layout-for(none, spec.layout)
  let lay = if local-layout == auto { base } else if d.layout.is-page-setup(local-layout) { local-layout }
    else { d.layout.merge-page-setup(base, local-layout) }
  let w = if spec.width == auto { lay.text-width } else { calc.min(spec.width, lay.text-width) }
  let body-style = spec.body
  let title-style = spec.title
  if spec.native-songti {
    let f = d.fonts.fontset-state.get()
    let native = core.fonts.profile(f.families.songti, metrics: f.metrics.songti,
      latin: f.families.songti, latin-metrics: f.metrics.songti)
    body-style += (font: native)
  }
  set page(width: lay.paper-width, height: lay.paper-height, margin: lay.margin,
    header: none, footer: none, numbering: none, background: none)
  // fill 属于原生文字属性，不在底层 Word 段落格式键中，由本页明确安装。
  set text(lang: lang, region: "cn", cjk-latin-spacing: none, fill: body-style.at("fill", default: black))
  set par(spacing: 0pt, leading: 0pt, first-line-indent: 0pt, justify: false)
  clear-page()
  metadata((iota-instructions-page: (language: lang, source: source)))
  v(spec.before)
  if label != none and label != [] {
    let words = plain-text(label)
    let label = if words == "说明" { [说#h(spec.title-gap)明] } else { label }
    block(width: w, above: 0pt, below: 0pt, {
      set text(fill: title-style.at("fill", default: black))
      paragraph(label, title-style, layout: lay, latin: lang == "en")
    })
    v(spec.gap)
  }
  let p(c, extra: (:)) = {
    let format = body-style + extra
    let literal = _literal(c)
    let height = measure(block(width: w - spec.body-left,
      paragraph(literal, format, layout: lay, latin: lang == "en"))).height
    // 短条目整体移到下一页，避免说明续页只剩半句话；超整页的段落仍允许续排。
    paragraph(literal, format + (breakable: height > lay.text-height), layout: lay, latin: lang == "en")
  }
  block(width: w, above: 0pt, below: 0pt, breakable: true, pad(left: spec.body-left, {
    if metadata-of(body, "iota-instructions-block").len() == 0 {
      d.styles.format(body-style, body, layout: lay)
    } else {
      for part in _flat(body) {
        if type(part) == content and part.func() == metadata and type(part.value) == dictionary {
          if "iota-instructions-source" in part.value { continue }
          if "iota-instructions-block" in part.value {
            let b = part.value.iota-instructions-block
            if b.kind == "levels" { _levels(b.lang, b.shenzhen, body-style, lay) }
            else { p(b.text, extra: if b.kind == "section" { spec.section } else { b.format }) }
            continue
          }
        }
        part
      }
    }
  }))
  pagebreak(weak: true)
}

/// 报告说明页。缺少英文原件时回落同一变体的中文原文；终稿和博后默认不排。
#let instructions(body: auto, title: auto, lang: auto, layout: auto, overrides: (:), shown: auto) = context {
  if shown != auto and type(shown) != bool { panic("instructions.shown: expected auto, true, or false") }
  let info = info-get()
  if shown == false or (shown == auto and info.stage not in report-stages) { return }
  let requested = resolve-lang(lang)
  let variant = variant-of(info)
  let terms = term-table(requested, "instructions", overrides: overrides)
  let payload = if body == auto { term-for(terms, "body", variant) } else { body }
  if payload == none or payload == [] {
    if shown == true and body == auto and payload == none {
      panic("instructions: no built-in instructions for this variant; supply body: [...] or use a report stage")
    }
    return
  }
  if type(payload) not in (content, str) {
    panic("instructions.body: expected content, string, auto, or none")
  }
  if title != auto and title != none and type(title) not in (content, str) {
    panic("instructions.title: expected content, string, auto, or none")
  }
  let source = metadata-of(payload, "iota-instructions-source")
  let language = if source.len() == 0 { requested } else { source.first().lang }
  once("instructions", key: language)
  cover-exit()
  _render(payload,
    if title == auto { term-for(terms, "title", variant) } else { title-of(title, requested) },
    info, language, layout, if source.len() == 0 { "custom" } else { source.first().id })
}
