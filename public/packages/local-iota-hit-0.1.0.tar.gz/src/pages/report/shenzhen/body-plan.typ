// 深圳博士中期正文的连续栏目分页。只计算几何，不改变原生内容、标题或计数器。
// “两栏一页”是普通长度的目标，不能作为每页的栏目数上限。

#let partition(sizes, capacity, first: auto, min-pages: auto) = {
  let n = sizes.len()
  if n == 0 { return () }
  let first = if first == auto { capacity } else { first }
  let minimum = if min-pages == auto { int(calc.ceil(n / 2)) } else { calc.max(1, calc.min(n, min-pages)) }
  let prev = ((score: 0.0, ends: ()),) + (none,) * n
  for pages in range(1, n + 1) {
    let next = (none,) * (n + 1)
    let room = if pages == 1 { first } else { capacity }
    for end in range(pages, n + 1) {
      let used = 0pt
      for start in range(pages - 1, end).rev() {
        used += sizes.at(start)
        if used > room { break }
        let prior = prev.at(start)
        if prior == none { continue }
        let count = end - start
        // 相同页数内优先双栏，避免前页落单；容许三栏及更多短栏来消化长栏造成的错位。
        let penalty = calc.pow(count - 2, 2) + (if count == 1 and end < n { 1 } else { 0 })
        let score = prior.score + penalty
        if next.at(end) == none or score < next.at(end).score {
          next.at(end) = (score: score, ends: prior.ends + (end,))
        }
      }
    }
    if pages >= minimum and next.last() != none { return next.last().ends }
    prev = next
  }
  none
}

// 在指定总高内分配内容格。先满足实际内容，再从其他格的空白中按比例让出空间。
#let distribute(minima, preferred, total) = {
  let grown = minima.zip(preferred).map(((m, p)) => calc.max(m, p))
  let spare = minima.zip(preferred).map(((m, p)) => calc.max(0pt, p - m))
  let excess = grown.sum(default: 0pt) - total
  if excess <= 0pt {
    return grown.map(h => h - excess / grown.len())
  }
  let available = spare.sum(default: 0pt)
  assert(available + 0.001pt >= excess, message: "body-plan: content exceeds page allocation")
  grown.zip(spare).map(((h, s)) => h - excess * (s / available))
}
