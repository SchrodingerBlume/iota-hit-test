#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing, latin-slot-box
#import banshi.fonts: zihao, underline-of
#import banshi.styles: paragraph, inline-math
#import "../../overflow.typ": overflow-note, wrap-lines
#import banshi.paragraph: paragraph-mark as enter
#import banshi.units: run-spacing, twip
#import banshi.runs: has-latin-slot, has-cjk
#import "../../../terms/lookup.typ": term-table, term-for, variant-of
#import "../../../info.typ": value-of
#import banshi.layout: merge-page-setup
#import "../../../layout/parts.typ": layout-for
#import "../../../layout/presets.typ": report-cover-layouts
#import "../title.typ" as _report-title
#import "../../../glyphs.typ": outlined
#import "../../../glyphs/xinwei.typ": xinwei-outline-font
#import banshi.content: plain-text
#import banshi.styles as style-rules
#import "../../checkbox.typ": checkbox
#let _columns = (
  zh: (
    proposal: (2250 * twip, 3691 * twip),
    interim: (2206 * twip, 3735 * twip),
  ),
  en: (
    proposal: (3357 * twip, 4961 * twip),
    interim: (3357 * twip, 4961 * twip),
  ),
)
#let _cell-inset = 108 * twip
#let _label-cells = 5.5
#let _label-size = zihao.xiaosan
#let _label-en-spaces = (title: 3, field: 4)
#let _label-en-size = 16pt

#let _label(chars, size, spaces: none) = {
  let words = plain-text(chars)
  let cut = if spaces == none { -1 } else { words.position("/") }
  let head = if cut == none or cut < 0 { words } else { words.slice(0, cut) }
  let tail = if cut == none or cut < 0 { "" } else { words.slice(cut) }
  let cs = head.clusters()
  let han(c) = c.contains(regex("\\p{Han}"))
  let hans = range(cs.len()).filter(i => han(cs.at(i)))
  let latin = if tail == "" { [] } else {
    text(size: _label-en-size, font: ("Times New Roman", "SimSun"), weight: "regular", {
      show regex("[^\\p{Han}\\p{P}]+|[/:]"): it => strong(it)
      tail
    })
  }
  if hans.len() < 2 { return text(size: size, head) + latin }
  let core = hans.last() + 1
  let slots = range(core - 1).filter(i => han(cs.at(i)) and han(cs.at(i + 1)))
  let gaps = if spaces != none { if core == 2 { spaces * size / 2 } else { 0pt } } else {
    (_label-cells - core) * _label-size
  }
  let gap = gaps / calc.max(slots.len(), 1)
  if slots.len() == 0 or gap <= 0pt { return text(size: size, head) + latin }
  let out = []
  for (i, c) in cs.enumerate() {
    out += text(size: size, c)
    if i in slots { out += h(gap) }
  }
  out + latin
}
#let _rows = ("author", "student-id", "affiliation", "speciality", "supervisor", "date")
#let _fixed(body) = context box(width: measure(body).width, body)
#let _table = (
  line-spacing: 1.5,
  cell-above: 12pt,
  title-height: 2251 * twip,
  title-paragraphs: 2,
  align: top,
  blanks: (
    zh: ((size: zihao.erhao, line-spacing: 1.25, snap: false),),
    en: ((size: zihao.xiaoyi, line-spacing: (exactly: 19pt), snap: false),),
  ),
  table-from-text: 995 * twip,
  anchor: (above: 12pt, line-spacing: (exactly: 19pt)),
)
#let _flat(c) = if type(c) == content and c.has("children") {
  c.children.map(_flat).sum(default: ())
} else { (c,) }
#let _paragraphs(value) = {
  let out = ((),)
  for c in _flat(value) {
    if type(c) == content and c.func() in (linebreak, parbreak) {
      out.push(())
    } else {
      out.at(out.len() - 1) = out.last() + (c,)
    }
  }
  let blank(c) = type(c) == content and plain-text(c).trim() == ""
  out
    .map(parts => {
      let a = 0
      let b = parts.len()
      while a < b and blank(parts.at(a)) { a += 1 }
      while b > a and blank(parts.at(b - 1)) { b -= 1 }
      parts.slice(a, b).sum(default: [])
    })
}

#let cover(
  stage: "proposal",
  info: none,
  lang: "zh",
  terms: auto,
  overrides: (:),
  title: auto,
  layout: auto,
  styles: (:),
  warning: auto,
) = context {
  let layout = merge-page-setup(
    layout-for(none, report-cover-layouts
      .at("shenzhen", default: (:))
      .at("bachelor", default: (:))
      .at(stage, default: (:))),
    layout,
  )
  let t = if terms != auto { terms } else {
    term-table(lang, "cover", overrides: overrides)
  }
  let variant = variant-of(info) + (stage: stage, campus: "shenzhen")
  let pick(name) = term-for(t, name, variant)
  let normal = (above: 0pt, below: 0pt, line-spacing: 1,
    snap-to-grid: false)
  let field-size = zihao.xiaosan
  let title-size = zihao.xiaoer
  let built-in = (
    university: normal + (
      size: zihao.xiaochu, asian-font: "xinwei",
      align: center, line-spacing: 1.2, bold: true,
      ..(if lang == "en" { (above: 12pt) } else { (:) }),
    ),
    report-title: normal + if lang == "en" {
      (size: zihao.xiaoyi, asian-font: "songti", align: center,
        line-spacing: 1, bold: true,
        above: 3.9pt, below: 3.9pt)
    } else {
      (size: zihao.xiaochu, asian-font: "xinwei",
        align: center, line-spacing: 1.2, bold: true)
    },
    university-latin: normal + (
      size: 20pt, latin-font: "serif",
      align: center, line-spacing: 1.25, bold: true, above: 12pt,
    ),
    report-title-latin: normal + (
      size: 16pt, latin-font: "serif",
      align: center, line-spacing: 1, bold: true,
      above: 3.9pt, below: 3.9pt,
    ),
    label: normal + (asian-font: "heiti", size: zihao.xiaosan),
    value: normal + (asian-font: "songti", size: zihao.xiaosan),
    title-value: normal + (
      asian-font: "heiti", latin-font: "serif", size: zihao.xiaoer,
      latin-bold: true,
    ),
  )
  let styles = {
    let out = built-in
    for (name, over) in styles {
      if name not in built-in {
        panic(
          "unknown style " + repr(name) + " on the report cover (expected one of "
            + built-in.keys().map(repr).join(", ") + ")",
        )
      }
      out.insert(name, built-in.at(name) + over)
    }
    out
  }

  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin, header: none, footer: none,
  )
  set text(lang: lang, region: "cn", size: zihao.xiaosi)
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
  let squeezed(body, style) = box(scale(
    x: 90%, reflow: true,
    text(tracking: run-spacing(20) / 0.9, context outlined("xinwei", xinwei-outline-font, body)),
  ))

  let form = _table
  let title-value = if title != auto { title } else {
    value-of(info, "title", lang: lang)
  }
  let columns = _columns.at(lang).at(stage)
  let blanks = form.blanks.at(lang)
  v(12pt)
  paragraph(
    {
      checkbox(info.form != "practice")
      term-for(t, "form", variant + (form: "dissertation"))
      text(spacing: 0.5em, "  ")
      checkbox(info.form == "practice")
      term-for(t, "form", variant + (form: "practice"))
    },
    normal + (
      size: zihao.xiaosi, line-spacing: (exactly: 19pt), above: 12pt,
    ),
    layout: layout,
  )
  for b in blanks {
    enter(
      size: b.size, line-spacing: b.line-spacing, snap: b.snap, spacing: 12pt,
      layout: layout,
      ..(if "font" in b { (font: b.font) } else { (:) }),
    )
  }
  let zh-terms = if lang == "zh" { t } else {
    term-table("zh", "cover", overrides: overrides)
  }
  let pick-zh(name) = term-for(zh-terms, name, variant)
  let centered-lines(value, style) = {
    let room = layout.text-width
    let lines = wrap-lines(
      value, room, measure-as: t => squeezed(text(size: style.size, t), style),
    )
    if lines.len() <= 1 { return squeezed(value, style) }
    squeezed(lines.map(l => text(l)).join(linebreak()), style)
  }
  paragraph(
    centered-lines(pick-zh("university"), styles.university), styles.university,
    layout: layout,
  )
  if lang == "en" {
    paragraph(pick("university"), styles.university-latin, layout: layout)
    enter(size: 8pt, line-spacing: 1.25, spacing: 12pt, layout: layout)
  }
  let report-title-of(table, doc-lang) = if title != auto { title } else {
    _report-title.report-title(table, doc-lang, info, variant)
  }
  paragraph(
    if lang == "en" {
      text(tracking: run-spacing(40), report-title-of(zh-terms, "zh"))
    } else {
      centered-lines(report-title-of(zh-terms, "zh"), styles.report-title)
    },
    styles.report-title,
    layout: layout,
  )
  if lang == "en" {
    paragraph(report-title-of(t, "en"), styles.report-title-latin, layout: layout)
  }
  v(form.table-from-text)
  let (label-width, value-width) = columns
  let _label-cell(body, top: form.cell-above) = grid.cell(
    inset: (left: _cell-inset, right: 0pt, top: top, bottom: 0pt),
    body,
  )
  let label-of(name) = term-for(t, name, variant)
  let label-spaces = if lang == "en" { _label-en-spaces } else {
    (title: none, field: none)
  }
  let title-label-size = if lang == "en" { _label-en-size } else { title-size }
  let sq0 = (gap: form.cell-above, shrink: 0pt)
  let sq-of(delta, base: form.cell-above) = (
    gap: calc.max(base - delta, 0pt),
    shrink: calc.max(delta - base, 0pt),
  )
  let ls-of(style, size, sq, line-box: auto) = if line-box == auto and sq.shrink == 0pt { form.line-spacing } else {
    let own = if line-box == auto {
      spacing(style + (size: size, line-spacing: form.line-spacing), layout: layout).line-height
    } else { line-box }
    own - sq.shrink
  }
  let inner = value-width - 2 * _cell-inset
  let absolute(l, size) = l.abs + l.em * size
  let metrics(style, size, sq: sq0, line-box: auto, latin: false) = {
    let u = underline-of(style, latin: latin)
    spacing(
      style + (size: size, line-spacing: ls-of(style, size, sq, line-box: line-box)), layout: layout, latin: latin,
    ) + (rule: (center: absolute(u.center, size), thickness: absolute(u.thickness, size)))
  }
  let own-box(style, size) = spacing(style + (size: size, line-spacing: form.line-spacing), layout: layout).line-height
  let latin-of(style, size, sq: sq0) = metrics(style, size, sq: sq, latin: true)
  let mark(ml) = text(top-edge: ml.top-edge, bottom-edge: -ml.bottom-edge, sym.zws)
  let cell(body, style, size, sq: sq0, line-box: auto, leading: auto) = {
    paragraph(
      latin-slot-box(style + (size: size, line-spacing: ls-of(style, size, sq)), layout, body),
      style + (size: size, line-spacing: ls-of(style, size, sq, line-box: line-box)),
      layout: layout, leading: leading,
    )
  }
  let pieces(body) = _flat(body).map(c => {
    if type(c) == str { c.clusters().map(text) } else if type(c) == content and c.func() == text {
      c.text.clusters().map(text)
    } else { (c,) }
  }).flatten()
  let line-geometry(body, style, size, sq, line-box, pitch, lines) = {
    let m = metrics(style, size, sq: sq, line-box: line-box)
    let ml = latin-of(style, size, sq: sq)
    let s = plain-text(body)
    let cjk = has-cjk(s)
    let ps = pieces(body)
    let all-text = ps.all(c => type(c) == str or (type(c) == content and (c.func() == text or repr(c.func()) == "space")))
    let mixed = cjk and has-latin-slot(s.replace(regex("\s"), ""))
    let uniform = {
      let mi = if cjk { m } else { ml }
      ((cjk: cjk, box: mi.line-height, ascent: mi.ascent, body: none),) * lines
    }
    if all-text and (lines <= 1 or not mixed) { return uniform }
    let leading = pitch - m.line-height
    let h(k, tail: none) = measure(block(
      width: inner,
      cell(
        ps.slice(0, k).join() + (if k == ps.len() { mark(ml) } else { [] }) + (if tail == none { [] } else { tail }),
        style + (align: center), size, sq: sq, line-box: line-box, leading: leading,
      ),
    )).height
    let heights = range(1, ps.len() + 1).map(k => h(k))
    let is-space(c) = (
      (type(c) == str and c.trim() == "")
        or (type(c) == content and c.func() == text and c.text.trim() == "")
        or (type(c) == content and repr(c.func()) == "space")
    )
    let breakable(k) = {
      let prev = plain-text(ps.at(k - 1))
      is-space(ps.at(k - 1)) or prev.ends-with("-") or has-cjk(prev) or has-cjk(plain-text(ps.at(k)))
    }
    let starts = (0,)
    for k in range(1, ps.len()) {
      if heights.at(k) - heights.at(k - 1) > pitch / 2 {
        let a = k
        while a > starts.last() + 1 and not breakable(a) { a -= 1 }
        starts.push(a)
      }
    }
    let ends = starts.slice(1) + (ps.len(),)
    let probe = 200pt
    let geo = starts.zip(ends).enumerate().map(((i, (a, b))) => {
      let total = heights.at(b - 1)
      let top = if i == 0 { 0pt } else { heights.at(a - 1) + leading }
      let bb = b
      while bb > a + 1 and is-space(ps.at(bb - 1)) { bb -= 1 }
      let tall = h(bb, tail: box(width: 0pt, height: probe))
      let line = ps.slice(a, b).join()
      (cjk: has-cjk(plain-text(line)), box: total - top, ascent: probe - (tall - total), body: line)
    })
    if geo.len() != lines { uniform } else { geo }
  }
  let lines-of(body, style, size, line-box: auto) = {
    let h = measure(block(width: inner, cell(body + mark(latin-of(style, size)), style + (align: center), size, line-box: line-box, leading: sq0.gap))).height
    let box = if has-cjk(plain-text(body)) { metrics(style, size, line-box: line-box).line-height } else { latin-of(style, size).line-height }
    int(calc.round((h + sq0.gap) / (box + sq0.gap)))
  }
  let steps-of(geo, pitch, box, shrink: 0pt, pad: none) = geo.enumerate().map(((i, g)) => {
    let own = g.box - shrink
    if i + 1 < geo.len() { calc.max(pitch, own + pitch - (box - shrink)) }
    else if pad != none { calc.max(own, pad - shrink) } else { own }
  })
  let own-of(geo, m, ml) = if geo.any(g => g.cjk) { m.line-height } else { ml.line-height }
  let ruled(body, style, size, sq, line: auto, lines: auto, line-box: auto, pitch: auto, pad: false) = context {
    let m = if line == auto { metrics(style, size, sq: sq, line-box: line-box) } else { line }
    let ml = latin-of(style, size, sq: sq)
    let n = calc.max(if lines == auto { lines-of(body, style, size, line-box: line-box) } else { lines }, 1)
    let pitch = if pitch == auto { m.line-height + sq.gap } else { pitch }
    let empty = plain-text(body).trim() == ""
    let geo = if empty { ((cjk: false, box: ml.line-height, ascent: ml.ascent, body: none),) } else {
      line-geometry(body, style, size, sq, line-box, pitch, n)
    }
    let own = own-of(geo, m, ml)
    let steps = steps-of(geo, pitch, own, pad: if pad { m.line-height } else { none })
    let y = 0pt
    for (i, g) in geo.enumerate() {
      let mi = if g.cjk { m } else { ml }
      place(top + left, dy: y + g.ascent + mi.rule.center, std.line(length: inner, stroke: mi.rule.thickness))
      y += steps.at(i)
    }
    let height = steps.sum()
    if geo.map(g => g.cjk).dedup().len() <= 1 {
      block(height: height, above: 0pt, below: 0pt, width: 100%,
        cell(body + mark(ml), style + (align: center), size, sq: sq, line-box: line-box, leading: pitch - own))
    } else {
      for (i, g) in geo.enumerate() {
        block(height: steps.at(i), above: 0pt, below: 0pt, width: 100%,
          cell(g.body + (if i + 1 == geo.len() { mark(ml) } else { [] }),
            style + (align: center), size, sq: sq, line-box: line-box, leading: 0pt))
      }
    }
  }
  let label-m = spacing(
    styles.label + (size: if lang == "en" { calc.max(field-size, _label-en-size) } else { field-size },
      line-spacing: form.line-spacing),
    layout: layout,
  )
  let field-box = calc.max(
    label-m.line-height,
    spacing(styles.value + (size: field-size, line-spacing: form.line-spacing), layout: layout).line-height,
  )
  let values = _rows.map(name => value-of(info, name, lang: lang, date-lang: lang))
  let value-lines = values.map(v => calc.max(lines-of(v, styles.value, field-size, line-box: field-box), 1))
  let pitch = field-box + form.cell-above
  let field-ml0 = latin-of(styles.value, field-size)
  let field-geo = values.enumerate().map(((i, v)) => {
    if plain-text(v).trim() == "" { ((cjk: false, box: field-ml0.line-height, ascent: field-ml0.ascent),) } else {
      line-geometry(v, styles.value, field-size, sq0, field-box, pitch, value-lines.at(i))
    }
  })
  let row-height(i, z) = {
    let own = if field-geo.at(i).any(g => g.cjk) { field-box } else { field-ml0.line-height }
    let value = steps-of(field-geo.at(i), field-box + z.field.gap, own, shrink: z.field.shrink, pad: field-box).sum()
    z.field.gap + calc.max(label-m.line-height - z.field.shrink, value)
  }
  let row(name, value, lines, sq, size: field-size) = {
    let label = {
      cell(
        _fixed(_label(label-of(name), size, spaces: label-spaces.field)),
        styles.label,
        size,
        sq: sq,
      )
    }
    let label = _label-cell(label, top: sq.gap)
    (label, ruled(value, styles.value, size, sq, lines: lines, line-box: field-box, pad: true))
  }
  let blank-style = styles.title-value + (snap-to-grid: false)
  let blank-line(sq) = metrics(blank-style, title-size, sq: sq, latin: true)
  let filled-line(sq) = metrics(styles.title-value, title-size, sq: sq)
  let blank-rule = (
    filled-line(sq0).line-height - filled-line(sq0).ascent + form.cell-above + blank-line(sq0).ascent
      + blank-line(sq0).rule.center - filled-line(sq0).rule.center
  )
  let title-pitch = blank-rule
  let title-gap = title-pitch - filled-line(sq0).line-height
  let ratio = title-pitch / pitch
  let title-pitch-of(z) = title-pitch - z.delta * ratio
  let title-paragraphs = {
    let given = _paragraphs(title-value).map(seg => {
      let n = lines-of(seg, styles.title-value, title-size)
      (
        body: seg,
        rows: calc.max(n, 1),
        blank: n == 0,
        style: if n == 0 { blank-style } else { styles.title-value },
        geo: if n == 0 { ((cjk: false, box: blank-line(sq0).line-height, ascent: blank-line(sq0).ascent),) } else {
          line-geometry(seg, styles.title-value, title-size, sq0, auto, title-pitch, calc.max(n, 1))
        },
      )
    })
    let lines = given.map(p => p.rows).sum(default: 0)
    let blank = (
      body: [], rows: 1, blank: true, style: blank-style,
      geo: ((cjk: false, box: blank-line(sq0).line-height, ascent: blank-line(sq0).ascent),),
    )
    given + (blank,) * calc.max(form.title-paragraphs - lines, 0)
  }
  let title-lines = title-paragraphs.filter(p => not p.blank).map(p => p.rows).sum(default: 0)
  let squeeze(delta) = {
    let f = sq-of(delta)
    let t = sq-of(delta * ratio, base: title-gap)
    (
      field: f, title: t, blank: f,
      top: form.cell-above,
      bottom: if title-paragraphs.last().blank { 0pt } else { t.shrink - f.shrink },
      delta: delta,
    )
  }
  let title-sq(p, z) = if p.blank { z.blank } else { z.title }
  let title-line(p, z) = metrics(p.style, title-size, sq: title-sq(p, z))
  let above-of(i, z) = if title-paragraphs.at(i).blank {
    z.title.gap + form.cell-above - title-gap
  } else { z.title.gap }
  let title-height(z) = z.top + title-paragraphs.enumerate().map(((i, p)) => {
    let above = if i == 0 { 0pt } else { above-of(i, z) }
    let last = i + 1 == title-paragraphs.len()
    let base = if p.geo.any(g => g.cjk) { filled-line(sq0) } else { latin-of(p.style, title-size) }
    above + steps-of(p.geo, title-pitch-of(z), base.line-height, shrink: title-sq(p, z).shrink, pad: if last { filled-line(sq0).line-height } else { none }).sum()
  }).sum(default: 0pt) + z.bottom
  let table-height(z, min: 0pt) = calc.max(min, title-height(z)) + range(_rows.len()).map(i => row-height(i, z)).sum()
  let z0 = squeeze(0pt)
  let empty-height = calc.max(
    form.title-height,
    form.cell-above + filled-line(sq0).line-height + form.cell-above + blank-line(sq0).line-height,
  ) + _rows.len() * pitch
  let natural-height = table-height(z0, min: form.title-height)
  let growths = (
    calc.max(title-height(z0) - form.title-height, 0pt),
    ..range(_rows.len()).map(i => row-height(i, z0) - (form.cell-above + field-box)),
  ).filter(g => g > 0pt)
  let absorbed(mask) = growths.enumerate().map(((i, g)) => {
    if calc.rem(calc.quo(mask, calc.pow(2, i)), 2) == 1 { g } else { 0pt }
  }).sum(default: 0pt)
  let ink-of(body, style, size) = measure(block(width: 100 * layout.paper-width, {
    show: style-rules.rules.with(style + (size: size), layout: layout, set-font: true)
    inline-math(par(text(top-edge: "bounds", bottom-edge: "baseline", body)))
  })).height
  let field-m = metrics(styles.value, field-size, line-box: field-box)
  let field-ml = latin-of(styles.value, field-size)
  let field-of(cjk) = if cjk { field-m } else { field-ml }
  let field-classes = field-geo.map(gs => gs.map(g => g.cjk))
  let field-inks = values.map(v => ink-of(v, styles.value, field-size))
  let title-bodies = title-paragraphs.filter(p => not p.blank).map(p => p.body)
  let title-ink = ink-of(if title-bodies.len() == 0 { [] } else { title-bodies.join([]) }, styles.title-value, title-size)
  let last = title-paragraphs.last()
  let last-g = last.geo.last()
  let last-m = (if last-g.cjk { title-line(last, z0) } else { latin-of(last.style, title-size, sq: z0.title) }) + (box: last-g.box, ascent: last-g.ascent)
  let clearance(pitch0, prev, ink) = pitch0 - prev.rule.center - prev.rule.thickness - ink
  let field-label-m = metrics(styles.label, field-size)
  let title-label-m = metrics(styles.label, title-label-size)
  let caps = (
    form.cell-above + field-label-m.line-height - field-label-m.ascent,
    form.cell-above + title-label-m.line-height - title-label-m.ascent,
    clearance(
      last-m.line-height - last-m.ascent + form.cell-above + field-of(field-classes.at(0).first()).ascent,
      last-m, field-inks.at(0),
    ),
  ) + (
    if title-lines >= 2 {
      let first = title-paragraphs.find(p => not p.blank)
      let any-cjk = title-paragraphs.any(p => p.geo.any(g => g.cjk))
      let prev = if any-cjk { title-line(first, z0) } else { latin-of(first.style, title-size, sq: z0.title) }
      (clearance(title-pitch, prev, title-ink) / ratio,)
    } else { () }
  ) + (
    range(_rows.len()).map(i => {
      let above = if i > 0 { (clearance(pitch, field-of(field-classes.at(i - 1).last()), field-inks.at(i)),) } else { () }
      let own = if value-lines.at(i) >= 2 {
        (clearance(pitch, field-of(field-classes.at(i).slice(0, -1).any(c => c)), field-inks.at(i)),)
      } else { () }
      above + own
    }).flatten()
  )
  let squeeze-max = calc.max(caps.fold(caps.first(), calc.min), 0pt)
  let fits(z, target) = table-height(z) + z.field.shrink <= target
  context {
    let table-top = here().position().y
    let page-bottom = calc.max(
      layout.margin.top + layout.text-height - (form.anchor.above + form.anchor.line-spacing.exactly),
      table-top + empty-height,
    )
    let overflow = table-top + natural-height > page-bottom
    let room = page-bottom - table-top
    let target = range(calc.pow(2, growths.len()))
      .map(mask => natural-height - absorbed(mask))
      .filter(t => t <= room)
      .fold(empty-height, calc.max)
  let (z, crowded) = if not overflow { (z0, false) } else if not fits(squeeze(squeeze-max), target) {
    (squeeze(squeeze-max), true)
  } else {
    let lo = 0pt
    let hi = squeeze-max
    for _ in range(40) {
      let mid = (lo + hi) / 2
      if fits(squeeze(mid), target) { hi = mid } else { lo = mid }
    }
    (squeeze(hi), false)
  }
  let sq = z.field
  if crowded and warning != false {
    overflow-note(pick("warning-crowded"), pick("warning-false"), lang: lang)
  }
  align(center, block(width: label-width + value-width, grid(
    columns: (label-width, value-width),
    rows: (
      calc.max(if z.delta == 0pt { form.title-height } else { 0pt }, title-height(z)),
      ..(auto,) * _rows.len(),
    ),
    inset: (x: _cell-inset, top: sq.gap, bottom: 0pt),
    align: form.align + left,
    _label-cell(cell(
      _fixed(_label(label-of("title"), title-label-size, spaces: label-spaces.title)),
      styles.label, title-label-size, sq: sq,
    ), top: z.top),
    grid.cell(inset: (x: _cell-inset, top: z.top, bottom: z.bottom), {
      for (i, p) in title-paragraphs.enumerate() {
        block(
          above: if i == 0 { 0pt } else { above-of(i, z) },
          below: 0pt,
          ruled(p.body, p.style, title-size, title-sq(p, z),
            line: title-line(p, z), lines: p.rows, pitch: title-pitch-of(z), pad: i + 1 == title-paragraphs.len()),
        )
      }
    }),
    ..range(_rows.len()).map(i => row(_rows.at(i), values.at(i), value-lines.at(i), sq)).flatten(),
  )))
  }
}
