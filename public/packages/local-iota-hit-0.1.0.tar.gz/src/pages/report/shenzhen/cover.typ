// 深圳校区*本科*那两份表单的首页（本科毕业设计开题报告_模板.docx、
// 本科毕业论文（设计）中期报告-模板.dotx）。
//
// *只管本科这一档。* 深圳的研究生那两份与本部同构——同一串段落、同一支
// 六格，差的只是缩进、格数与前后空段的个数，那些是数，留在 ../cover.typ 的
// _graduate-form 表里；本科这两份是*另一页*：
//
//                本部本科（教务处发的）      深圳本科
//   头两行       校名题字（矢量图）          *文字*两行，小初华文新魏加粗
//                ＋「本科毕业论文…开题报告」  （校名一行、文种一行）
//   字段         五格，一段一格、首行缩进    *一张两列的表*：左列标签、
//                值画在下划线上              右列的下划线是单元格的下边框
//   正文         教务处那一套表单版面        *照终稿排*（见 src/layout/presets.typ
//                                            的 _shenzhen-bachelor-proposal）
//
// 重叠的只有块级件（paragraph / enter）与标签撑宽那一支（../cover.typ 的
// label-spread），所以这一页自己排自己的，不套那张表。
//
// ── 两份的差别：原件有，我们不留 ─────────────────────────────────────
//
// 段落序列一样（两个空段、校名、文种、表），原件差在表怎么画：
//
//           开题                              中期
//   题目行  一行，行高 2251 缇 ＝ 112.55       *两行*（原件第二行印着
//           （留给两行题目）                  「（题目长可分两行写）」）
//   线      *文字下划线*：值那一格是一串   *单元格的下边框*
//           带 w:u 的半角（题目行 23 个、
//           另六行 24 个）
//   行高    段前 12pt ＋ 行距 1.5 倍           行高至少 822 缇 ＝ 41.1，
//                                             段前 12pt ＋ 行距 19pt 固定值
//   列宽    1991 / 4354 缇                    1990 / 3951 缇
//
// 两份的表都*整体居中*（开题是浮动表 tblpXSpec="center"，中期是
// w:jc="center"），所以这一页只认列宽，不认页边距。
//
// *这张表是存档，不是分支*（用户定的）：开题原件那一页——浮动表、手打的
// 下划线、一格 112.55、行高不齐——不复刻，*整页照中期那一份排，只换字*。
// 版面（src/layout/presets.typ 的 report-cover-layouts）、列宽、空段、表在页上的
// 落点两份共用一份，见下面的 _columns 与 _table；开题与中期的差别只剩校名下那
// 一行与题目那一格的标签，跟词条走（src/terms/built-in.typ 的
// report-title-bachelor-…-shenzhen）。
#import "../../../fonts/presets.typ": zihao
#import "../../../styles/paragraph.typ": paragraph, overflow-note, inline-math
#import "../../../styles/enter.typ": enter
#import "../../../msword.typ": msword-run-spacing, twip, latin-slot-run
#import "../../../fonts/presets.typ": underlines
#import "../../../terms/lookup.typ": term-table, term-for, variant-of
#import "../../../document/info.typ": value-of
#import "../../../layout/resolve.typ": layout-for, resolve-local
#import "../../../layout/presets.typ": report-cover-layouts
#import "../title.typ" as _report-title
#import "../../../fonts/glyphs.typ": outlined
#import "../../../fonts/glyphs/xinwei.typ": xinwei-outline-font
#import "../../../styles/linebox.typ" as linebox
#import "../../../text/plain.typ": has-cjk, plain, wrap-lines
#import "../../../styles/rules.typ" as style-rules
#import "../../checkbox.typ": checkbox

// 表格的列宽，照各份的 w:tblGrid。*2026 年 9 月版两份各一套*——开题
// 2250/3691、中期 2206/3735，差 44 缇 ＝ 2.2pt（同一次改版发的两份表，多半是
// 手拉的；用户定的：跟原件，不归一）
#let _columns = (
  zh: (
    proposal: (2250 * twip, 3691 * twip),
    interim: (2206 * twip, 3735 * twip),
  ),
  // *英文版两个阶段同一套*（3357/4961，两份 docx 逐字相同），比中文那两份
  // 宽——标签那一列要装下双语（「学号/ Student ID：」）
  en: (
    proposal: (3357 * twip, 4961 * twip),
    interim: (3357 * twip, 4961 * twip),
  ),
)

// 单元格左右的留白：Word 的表格默认单元格边距，w:tblCellMar 没写就是 108 缇
#let _cell-inset = 108 * twip

// 标签摊到几个全宽字宽，以及*摊的那个空格照哪个字号*。
//
// 两份原件的标签都是拿字面空格撑的，量下来：
//
//   姓       名   姓(15) ＋ 7 个半角(7.5) ＋ 名(15)      ＝ 82.5
//   指 导 教 师   四个字(15) ＋ 3 个半角(7.5)            ＝ 82.5
//   题       目   *题(18)* ＋ 7 个半角(7.5) ＋ 目(18) ＝ 88.5
//
// 前两行是「摊到 5.5 个小三格」，第三行的字大一号、*空格却还是小三的*
// ——*钉住的是缝，不是总宽*：缝共 (5.5 − 核心汉字数) 个小三格，汉字跟本行
// 的字号走。所以题目那一行比另六行宽 9（原件量的正是 106.5 与 97.5，「目：」
// 探出去；旧版中期那份是齐的，新版两份都不齐了）。
// 摊法（只摊在汉字与汉字之间、摊不匀的补在末一道缝）与本部那两页同一条，
// 见 ../cover.typ 的 label-spread
#let _label-cells = 5.5
#let _label-size = zihao.xiaosan

// *英文版的标签是双语的*：中文核心（黑体，摊开几个半角）＋「/ English」
// （Times *加粗*三号）＋ 冒号（*宋体*全角三号，不加粗）。逐字量原件
// （英文中期首页）：
//
//   题   目/ Title:     题(16) ＋ 3 个半角(8.0) ＋ 目(16)，「/ Title:」 Times 粗 16
//   姓    名/ Name：    姓(15) ＋ 4 个半角(7.5) ＋ 名(15)，「/ Name」 Times 粗 16、
//                       冒号宋体 16
//
// *缝是「几个半角」，不是摊到同一个宽度*——两档的格数不同（题目 3、六格 4），
// 摊出来两行也不齐（105.69 与 124.51）。中文版那一档反过来，见上面的 _label-cells。
//
// 「/」是这一族词条自己的分界（title-bachelor-shenzhen 那一串都写着「中文/ English」），
// 拿它切，前一半跟中文那一档的字号走、后一半三号。
#let _label-en-spaces = (title: 3, field: 4)
#let _label-en-size = 16pt

#let _label(chars, size, spaces: none) = {
  let words = plain(chars)
  // 英文版：先切出「/ English」那一截，只摊前一半
  let cut = if spaces == none { -1 } else { words.position("/") }
  let head = if cut == none or cut < 0 { words } else { words.slice(0, cut) }
  let tail = if cut == none or cut < 0 { "" } else { words.slice(cut) }
  let cs = head.clusters()
  let han(c) = c.contains(regex("\\p{Han}"))
  let hans = range(cs.len()).filter(i => han(cs.at(i)))
  let latin = if tail == "" { [] } else {
    // 西文加粗、冒号不加粗：冒号是全角，走中文槽，原件量的是 SimSun 不是粗体
    text(size: _label-en-size, font: ("Times New Roman", "SimSun"), weight: "regular", {
      show regex("[^\\p{Han}\\p{P}]+|[/:]"): it => strong(it)
      tail
    })
  }
  if hans.len() < 2 { return text(size: size, head) + latin }
  let core = hans.last() + 1
  let slots = range(core - 1).filter(i => han(cs.at(i)) and han(cs.at(i + 1)))
  // *摊的是同样多个半角，不是同一个总宽*——见上：中文版的缝钉在小三上，
  // 汉字跟本行的字号走，题目那一行因此比另六行宽 9；英文版的缝是本行字号的
  // 半个字，几个见 _label-en-spaces
  // *英文版只有两个字的标签才摊*——原件里「指导教师」四个字是挨着的，
  // 一个空格都没敲（逐字量：95.04 / 110.04 / 125.04 / 140.04，步进就是 15）
  let gaps = if spaces != none { if core == 2 { spaces * size / 2 } else { 0pt } } else {
    (_label-cells - core) * _label-size
  }
  let gap = gaps / calc.max(slots.len(), 1)
  if slots.len() == 0 or gap <= 0pt { return text(size: size, head) + latin }
  let out = []
  for (i, c) in cs.enumerate() {
    out += text(size: size, c)
    if i in slots { out += h(gap) }
  }
  out + latin
}

// 六格的字段名，次序照两份表单（题目单列，见下面）。*与内封、与本部那两页
// 同名*——info 里早就有这几条，一个新键都不加
#let _rows = ("author", "student-id", "affiliation", "speciality", "supervisor", "date")

// 按自然宽给死的一个盒：*装不下就探出去，不折行*。box 不给宽度时内容照样
// 会在容器宽度上折，measure 量的才是「不折时有多宽」。
//
// 光给死宽度还不够——盒比这一行宽时 Typst 会把它整个挪到下一行去，于是标签落到
// 第二行上。所以标签那一格的*右留白不占位*（见下面 grid 里的 _label-cell），
// 让盒有地方探出去；原件里 Word 也是这么办的：英文版「指导教师/ Supervisor：」
// 量得 159.2，比格子内缘 157.05 还宽，Word 让它探出去，没折
#let _fixed(body) = context box(width: measure(body).width, body)

// 表怎么画，照*中期那一份*的 docx——*两份共用一套，只换字*。
//
// *开题原件那一页不复刻（用户定的）*：它的线是一串带 w:u 的手打半角
// （题目那行 23 个、另六行 24 个），表还是浮动的（w:tblpPr vertAnchor="text"
// tblpY="995"），一行一个长短、行高也不齐，题目那一格高 112.55 是留死的。同一套
// 表单的中期那份用的是真表格加单元格边框，齐整得多——所以*整页取中期的*：
// 版面（见 src/layout/presets.typ 的 report-cover-layouts）、列宽、空段、表在页上
// 的落点全照它，开题与中期的差别只剩印出来的那几个字（校名下那一行与题目那一格
// 的标签，见 src/terms/built-in.typ 的 report-title-bachelor-…-shenzhen）。
#let _table = (
  // 每一格一段：段前 12pt（w:spacing w:before="240"）、行距 1.5 倍
  // （w:line="360" auto）。*段前走单元格的上留白*——Typst 的块间距在容器
  // 开头会被丢掉，而格里那一段正好在开头
  line-spacing: 1.5,
  cell-above: 12pt,
  // 第一行（题目那一格）*至少*这么高（w:trHeight val="2251" 没写 hRule
  // ＝ atLeast）；另六行没写行高，自然高
  title-height: 2251 * twip,
  // *题目那一格是两段*（原件里是两串各自带 w:u 的空格，各写着
  // w:before="240"）。那一格的说明「题目长可分两行写」说的就是这两段：题目长了
  // *写到第二段去*。所以题目里敲的换行 ＝ 换到下一段；两段刚好填满，不另
  // 多出一条线。*行数*不足这个数就补空段（那条留着的线）——题目自己折到两行
  // 也算够了，不再补；多写就往下长
  title-paragraphs: 2,
  // *线是格子里那串空格的下划线*，不是单元格边框（新版两份的 tcBorders
  // 与 tblBorders 都没写）。线的位置、粗细跟着*这一行的字体*走，见下面的 ruled 与
  // src/fonts/presets.typ 的 underlines；这儿不存数。
  // 格里的字*顶对齐*（新版没写 vAlign；旧版中期写的是 bottom）
  align: top,
  // 校名之前两个空段：一个小一（sz48）、段前 12pt、行距 19pt 固定值、不贴网格
  // ——*2026 年 9 月版这一段有字了*，印的是「☐毕业论文　☐毕业设计」，
  // 见下面的勾选行；另一个二号（sz44）、段前 12pt、行距 1.25 倍、贴网格
  blanks: (
    // 二号（sz44）、段前 12pt、行距 1.25 倍、*不贴网格*——首页那一节的
    // docGrid 写着 395/1861 可*没有 w:type*，整节的网格都不启用
    zh: ((size: zihao.erhao, line-spacing: 1.25, snap: false),),
    // *英文版这一段与勾选行同一档*：小一（sz48）、行距 19pt 固定值
    en: ((size: zihao.xiaoyi, line-spacing: (exactly: 19pt), snap: false),),
  ),
  // *表是浮动的*，2026 年 9 月版两份都是：w:tblpPr vertAnchor="text" tblpY="995"
  // ——表顶离锚定段落的顶 995 缇 ＝ 49.75；文种与表之间*没有*空段（旧版中期那份
  // 是一个小初空段加不浮动的表，先前照它排的）。锚定的是表之后那个空段，它的顶
  // 就是文种那一行的行盒底，所以表顶 ＝ 文种行盒底 ＋ 49.75。中英两版的两份原件
  // 题目基线都量到 341.0（zh）／407.3（en），照这个式子排差 1.2 以内
  table-from-text: 995 * twip,
  // *表之后那个空段*（就是浮动表的锚定段，这一节的末段）：段前 240 缇 ＝ 12pt、固定值
  // 380 缇 ＝ 19pt，字号跟 Normal（小四）——三份 docx（中文开题、中期，英文开题）一样，
  // 英文中期那份 .doc 没转、没查。它不排出来（表浮在它上面，Word 里两者重叠），只在
  // 判「信息栏超页」时给它留地方（用户定的，见下面的 overflow）
  anchor: (above: 12pt, line-spacing: (exactly: 19pt)),
)

// 摊平成一串元素（内容序列会套内容序列）
#let _flat(c) = if type(c) == content and c.has("children") {
  c.children.map(_flat).sum(default: ())
} else { (c,) }

// 按题目里敲的换行拆段（\ 与空行都算）。*内容原样往下传*——只挑出换行那
// 几个元素，别的一个不动，强调、上下标、行内公式都还在
#let _paragraphs(value) = {
  let out = ((),)
  for c in _flat(value) {
    if type(c) == content and c.func() in (linebreak, parbreak) {
      out.push(())
    } else {
      // *数组是值*：out.last() 拿到的是副本，push 上去落不回原处
      out.at(out.len() - 1) = out.last() + (c,)
    }
  }
  // 换行两边那个空格是 markup 里 `\` 前后的，居中时会算进行宽，摘掉
  let blank(c) = type(c) == content and plain(c).trim() == ""
  out
    .map(parts => {
      let a = 0
      let b = parts.len()
      while a < b and blank(parts.at(a)) { a += 1 }
      while b > a and blank(parts.at(b - 1)) { b -= 1 }
      parts.slice(a, b).sum(default: [])
    })
}

#let cover(
  stage: "proposal",
  info: none,
  lang: "zh",
  terms: auto,
  overrides: (:),
  title: auto,
  layout: auto,
  styles: (:),
  // 信息栏压到底仍装不下时纸角那条红字，三态：auto ＝ 发，false 关。见下面「装不下时整体压缩」
  warning: auto,
) = context {
  // 首页自成一节的那一份（开题）在这儿并差额，与 ../cover.typ 同一条路子
  let layout = resolve-local(
    layout-for(none, report-cover-layouts
      .at("shenzhen", default: (:))
      .at("bachelor", default: (:))
      .at(stage, default: (:))),
    layout,
  )
  let t = if terms != auto { terms } else {
    term-table(lang, "cover", overrides: overrides)
  }
  // *form 也递进去*：这两份印的是「毕业论文」还是「毕业设计」跟它走，
  // 见 src/terms/built-in.typ 的 report-title-bachelor-…-shenzhen
  let variant = variant-of(info) + (stage: stage, campus: "shenzhen")
  let pick(name) = term-for(t, name, variant)

  // *Normal 是小四宋体*（两份 docx 的 Normal 都只写着 sz24），页面上没有
  // 一段吃它——每一段都写着自己的字号，写着是为了与文件对得上
  let normal = (above: 0pt, below: 0pt, line-spacing: 1,
    snap-to-docgrid: false)
  let field-size = zihao.xiaosan
  let title-size = zihao.xiaoer
  let built-in = (
    // 校名与文种：小初华文新魏加粗、字距 20（＝ 2pt，见 msword-run-spacing）、
    // *字宽 90%*（w:w="90"），行距 1.2 倍（w:line="288"）、不贴网格
    // *英文版这一行还带 12pt 段前*（w:beforeLines="100"，网格不启用时一行
    // ＝ 正文一个字号 12）；中文版那一段一个 w:before 都没写
    university: normal + (
      size: zihao.xiaochu, font-zh: "xinwei", font: "xinwei",
      align: center, line-spacing: 1.2, bold: true,
      ..(if lang == "en" { (above: 12pt) } else { (:) }),
    ),
    // *文种那一行中英两版不同*：中文版与校名同一档（小初华文新魏、压 90%
    // 字宽），*英文版是宋体小一加粗、字距 40*（w:sz="48" w:spacing="40"，
    // 一个 w:w 都没写，量出来 SimSun 23.76），段前段后各 78 缇 ＝ 3.9
    report-title: normal + if lang == "en" {
      (size: zihao.xiaoyi, font-zh: "songti", font: "songti", align: center,
        line-spacing: 1, bold: true,
        above: 3.9pt, below: 3.9pt)
    } else {
      (size: zihao.xiaochu, font-zh: "xinwei", font: "xinwei",
        align: center, line-spacing: 1.2, bold: true)
    },
    // *英文版才有的两行*：校名与文种各在中文那一行下面再排一行英文。
    // 都是 Times 加粗、居中，字号与行距逐行量原件——
    //
    //   校名英文  sz40 ＝ 20pt，行距 1.25 倍（w:line="300"），段前 12pt
    //   文种英文  sz32 ＝ 16pt，字距 20 ＝ 2pt，段前段后各 3.9
    // *font-zh 写 "latin"*：这两行没有汉字，行高只有 Times 参与（1.15）；先前写的
    // "serif" 不在 natural-coefs 里、静默落到中易的 1.2969，两行各高出 3.6／2.3，
    // 文种与表跟着往下掉 2.2 ＋ 1.2（拿原件的变体在 Word 里量证过：Harbin 那一行
    // 1.25 倍多出来的正是 0.25 × 20 × 1.15）
    university-latin: normal + (
      size: 20pt, font-zh: "latin", font: "serif",
      align: center, line-spacing: 1.25, bold: true, above: 12pt,
    ),
    report-title-latin: normal + (
      size: 16pt, font-zh: "latin", font: "serif",
      align: center, line-spacing: 1, bold: true,
      above: 3.9pt, below: 3.9pt,
    ),
    // 表里的标签：黑体，题目那一行小二、另六行小三
    label: normal + (font-zh: "heiti", font: "heiti", size: zihao.xiaosan),
    // 值：另六行宋体小三（中期那份的 w:rFonts 写的是宋体）
    value: normal + (font-zh: "songti", font: "songti", size: zihao.xiaosan),
    // *题目那一格是黑体小二，西文走 Times 加粗*：中文汉字黑体，夹的西文与整条
    // 英文题目都是粗体新罗马（与内封那几格「Candidate：」同一档：SimHei ＋
    // TimesNewRomanPS-Bold，见 src/fonts/resolve.typ 的 font()）。2026 年 9 月版三份
    // docx 的题目格 run 只写 eastAsia="黑体"，ascii 槽落到默认的 Times——先前照旧版
    // 中期那份（ascii/hAnsi 也是黑体）让西文走 Arial，错了。*加粗是用户定的*：
    // 那三份的 run 上没有 <w:b/>，空表单里也看不出填进去的字粗不粗
    title-value: normal + (
      font-zh: "heiti", font: "heiti", font-latin: "serif", size: zihao.xiaoer,
      latin-bold: true,
    ),
  )
  let styles = {
    let out = built-in
    for (name, over) in styles {
      if name not in built-in {
        panic(
          "unknown style " + repr(name) + " on the report cover (expected one of "
            + built-in.keys().map(repr).join(", ") + ")",
        )
      }
      out.insert(name, built-in.at(name) + over)
    }
    out
  }

  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin, header: none, footer: none,
  )
  set text(lang: lang, region: "cn", size: zihao.xiaosi)
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)

  // 字宽 90%：Word 的 w:w 只压字形的步进，run 的字距（w:spacing）不跟着压，
  // 所以字距先除以 0.9，压回来正好是 2pt
  // *裹一层 box*：带 reflow 的 scale 是块级的，paragraph 居中那一支现在是显式的 par()
  // （见 src/styles/paragraph.typ），块级的东西进去会被 Typst 丢掉；box 让它成行内
  // *没装华文新魏就画轮廓*（src/fonts/glyphs.typ）：校名与文种两行的字都在收录里，
  // 字距一并画进去（outline-text 读 text.tracking）；用户改了词条、字出了收录，交回
  // 字体表顺着楷体、宋体回落
  let squeezed(body, style) = box(scale(
    x: 90%, reflow: true,
    text(tracking: msword-run-spacing(20) / 0.9, context outlined("xinwei", xinwei-outline-font, body)),
  ))

  let form = _table
  // 校名之前的两个空段，见 _table 的 blanks。
  //
  // ── 题目长了往下延伸 ────────────────────────────────────────────────
  //
  // 题目那一格原件*留了两行的地方*（w:trHeight val="2251" ＝ 112.55，没写
  // w:hRule ＝*至少*这么高），而两行只用掉 94——中间那截夹缝正是留给第三行的。
  // 所以*行不动、格自己长高*：三行仍在这一格里，姓名那一行往下让 28。
  //
  // *不减上面的空段*（用户定的）：那是「往上挤」，校名与文种会被提起来，
  // 而这一页最先入眼的正是那两行。本部报告首页那一套减空段的做法不搬过来——
  // 那一页的六格是段落序列，这一页是表格，表格本来就会往下长。
  let title-value = if title != auto { title } else {
    value-of(info, "title", lang: lang)
  }
  let columns = _columns.at(lang).at(stage)
  let blanks = form.blanks.at(lang)
  // *头一段是勾选行*（2026 年 9 月版新加）：「☐毕业论文　☐毕业设计」，
  // 按 form 勾一个——与本科内封第一行同一对词、同一副轮廓（base 桶的
  // form-bachelor-dissertation / form-bachelor-practice，src/pages/checkbox.typ）。原件那一段
  // 右边还浮着一个「勾选毕设类型」的提示文本框，那是给填表人看的，不排。
  //
  // 段落属性照原件：小一（sz48）、段前 12pt、行距 19pt 固定值、不贴网格。
  //
  // *页首那一段的段前要自己发*：Word 在页首照进段前（这一行的基线量出
  // 99.12 ＝ 版心顶 72 ＋ 12 ＋ 19pt 固定值行盒里基线那一处 15.2），而 Typst 的
  // 块间距在容器开头会被丢掉
  v(12pt)
  paragraph(
    {
      checkbox(info.form != "practice")
      term-for(t, "form", variant + (form: "dissertation"))
      // 两个框之间空两个半角（原件敲的就是两个）。*要写 spacing*——
      // markup 里连续的空格会折成一个
      text(spacing: 0.5em, "  ")
      checkbox(info.form == "practice")
      term-for(t, "form", variant + (form: "practice"))
    },
    normal + (
      // *字是小四，不是小一*——那一段的 w:rPr 写着 sz="48"，可那是*段落
      // 标记*的字号；两个框与四个字的 run 上一个 sz 都没写，跟 Normal 走（sz24 ＝
      // 小四 12pt）。Word 排出来量得正是 12（SimSun 12 与 Wingdings2 12）。
      // 行盒是 19pt 固定值，与字号无关
      size: zihao.xiaosi, line-spacing: (exactly: 19pt), above: 12pt,
    ),
    layout: layout,
  )
  for b in blanks {
    enter(
      size: b.size, line-spacing: b.line-spacing, snap: b.snap, spacing: 12pt,
      layout: layout,
      ..(if "font" in b { (font: b.font) } else { (:) }),
    )
  }
  // *中文那两行的字*。英文版的校名与文种*各排两行*，上面那一行印的
  // 是中文——同一个词、另一种语言，所以到 zh 桶里取，不在 en 桶里另抄一份
  let zh-terms = if lang == "zh" { t } else {
    term-table("zh", "cover", overrides: overrides)
  }
  let pick-zh(name) = term-for(zh-terms, name, variant)
  // *校名与文种自己折行*：这两行居中，而 Typst 自然折行时行末那个空格
  // 会算进居中，整行偏半个空格（英文档下量得 4.05）。按「压 90% 字宽加字距」
  // 之后的样子量，见 src/text/plain.typ 的 wrap-lines
  let centered-lines(value, style) = {
    let room = layout.text-width
    let lines = wrap-lines(
      value, room, measure-as: t => squeezed(text(size: style.size, t), style),
    )
    if lines.len() <= 1 { return squeezed(value, style) }
    squeezed(lines.map(l => text(l)).join(linebreak()), style)
  }
  // *校名那一行只有中文那一档压 90% 字宽*（squeezed）——英文版下面那一行
  // 是 Times，w:w 一个都没写
  paragraph(
    centered-lines(pick-zh("university"), styles.university), styles.university,
    layout: layout,
  )
  if lang == "en" {
    paragraph(pick("university"), styles.university-latin, layout: layout)
    // 校名与文种之间那个空段：段前 12pt、行距 1.25 倍，*¶ 只有 8pt*
    // （w:sz="16"）——原件那一段排出来是一个 7.92 的空行，不是一整行小四
    enter(size: 8pt, line-spacing: 1.25, spacing: 12pt, layout: layout)
  }
  let report-title-of(table, doc-lang) = if title != auto { title } else {
    _report-title.report-title(table, doc-lang, info, variant)
  }
  // *英文版的文种两行不压字宽*（一个 w:w 都没写）。字距*只有中文那一行
  // 有*：它的 run 上写着 w:spacing="40" ＝ 4pt（见 msword-run-spacing）；英文那一行
  // 的 20 写在*段落标记*上、run 上一个都没有，排出来也确实没有（原件那一行
  // 宽 329.48，加上 43 个字的 2pt 就成了 415）。中文版那一行与校名同一档，压 90%
  // 字宽加 2pt
  paragraph(
    if lang == "en" {
      text(tracking: msword-run-spacing(40), report-title-of(zh-terms, "zh"))
    } else {
      centered-lines(report-title-of(zh-terms, "zh"), styles.report-title)
    },
    styles.report-title,
    layout: layout,
  )
  if lang == "en" {
    paragraph(report-title-of(t, "en"), styles.report-title-latin, layout: layout)
  }

  // 文种到表：浮动表离锚定段落顶 995 缇，见 _table 的 table-from-text
  v(form.table-from-text)

  // ── 表 ──────────────────────────────────────────────────────────────
  //
  // *一张两列的真表格*（w:tbl，jc=center、tblInd 0），左列标签、右列一条
  // 线。*线是格子里那串空格的下划线*，不是单元格边框——新版两份的
  // tblBorders 与 tcBorders 都没写，值那一格里是一串带 w:u="single" 的空格，
  // 题目那一格是两串（两行）。
  let (label-width, value-width) = columns
  // 标签那一格：*右留白不占位*，见 _fixed
  // top 收这一页解出来的段前（压缩时跟着缩，见下面「装不下时整体压缩」）——
  // 标签那一格不缩的话，一行的高被它顶住，值那一格缩了也白缩
  let _label-cell(body, top: form.cell-above) = grid.cell(
    inset: (left: _cell-inset, right: 0pt, top: top, bottom: 0pt),
    body,
  )
  // 标签与另六格的值同名，与内封、与本部那两页一路；题目那一格的标签也叫 title
  let label-of(name) = term-for(t, name, variant)
  // 摊法：中文版摊到 5.5 个小三格（none），英文版是「几个半角」，见 _label
  let label-spaces = if lang == "en" { _label-en-spaces } else {
    (title: none, field: none)
  }
  // *题目那一格的标签，英文版是三号*（w:sz="32" ＝ 16），中文版是小二；
  // 值那一格两版都是黑体小二（w:sz="36"）
  let title-label-size = if lang == "en" { _label-en-size } else { title-size }
  // 一格里的段：段前 12pt 走单元格的上留白（Typst 的块间距在容器开头会被丢掉），
  // 行距 1.5 倍
  // ── 装不下时整体压缩 ────────────────────────────────────────────
  //
  // 值折了行、题目折了行，表就往下长；长到超过空表单那张表的底就*每一行匀着压*
  // （用户定的）：每行的步进减同一个 Δ，压到整张表的底正好回到空表单那一处。
  // Δ 先吃各行的段前（12pt），吃光了再吃行盒里基线以下那一截（1.5 倍多出来的
  // 空当）——基线在行盒里的位置不动，只是行盒变矮。*压到字要碰上一行的线就停*：
  // 行盒顶（基线 − 上升部）不能低于上一条线的底（基线 ＋ 线心 ＋ 线宽），再往下
  // 压就把 Δ 钉在这个上限，纸角发红字（行高不足），与本部报告首页的溢出红字同一
  // 个机制。sq 是 (gap: 段前, shrink: 行盒减多少)，先按不压（sq0）量行数、算总高，
  // 再按算出的 Δ 排。
  // 一种行的压法：base 是它本来的段前（六格与题目段首 12；题目折出来的行是
  // 页距减题目行盒，见下面 title-gap），Δ 先吃 base、吃光了再吃行盒
  let sq0 = (gap: form.cell-above, shrink: 0pt)
  let sq-of(delta, base: form.cell-above) = (
    gap: calc.max(base - delta, 0pt),
    shrink: calc.max(delta - base, 0pt),
  )
  // 行盒减 shrink：写成裸长度交给 linebox.metrics——那一档*不设下限*（见 src/styles/rules.typ
  // 的 resolve），压得到自然行高以下；基线仍在上升部处，缩掉的全是基线以下那一截。
  // 先前写成倍数，倍数那一档取行距与自然行高的较大者，压到自然行高就停了——字离上一条
  // 线还有 5～9pt 就叫「行高不足」，英文（Times 的自然行高松）早叫一行
  // line-box：这一档的行盒按给定的高来（值那六格按整行的盒，见下面 field-box），auto ＝
  // 按样式自己的 1.5 倍
  let ls-of(style, size, sq, line-box: auto) = if line-box == auto and sq.shrink == 0pt { form.line-spacing } else {
    let own = if line-box == auto {
      linebox.metrics(style + (size: size, line-spacing: form.line-spacing), layout: layout).box
    } else { line-box }
    own - sq.shrink
  }
  // leading：折出来的行之间的空当（段前那一截，见下面），交给 paragraph 的 par()
  let inner = value-width - 2 * _cell-inset
  // ── 值那一格：*线自己画，字原样交给 Typst 排* ────────────────────
  //
  // *不拿「带下划线的空格」假装那条线。* 先前是那样排的，一条路上四个
  // 毛病一条根：原生 underline 只装饰真字形 → 得拿空格把一行填满 → 得知道填
  // 多少 → 得把内容摊成*字符串*再自己折行（强调、上下标全丢；折行也不再
  // 是 Typst 排的，原件里 Word 压得下的一行我们要折，因为不压全角括号）→
  // 行首行末的空白会被版面裁掉 → 得塞零宽空格挡着 → 零宽空格落在西文槽里，
  // 把*紧跟的头一个字*也拖进西文字体（`author: [□□□]` 的头一个 □ 排成了
  // Times 的 6.84×6.12，另两个是宋体的 10.62×10.08）。
  //
  // 现在：值就是值（居中，折行走 Typst），线按行盒画在基线下——行盒高与基线
  // 位置都由 linebox.metrics 给，与这一页别处同一套换算。
  //
  // *居中这一处不照原件*：2026 年 9 月版那几段写的是 w:jc="left"（旧版写的
  // 是 center），可空白表单上看不出填进去的字该落在哪儿——那一格里就是一串
  // 空格。左顶的话半行是字半行是空线，而这一页别的行都是居中的；与本部那五份
  // 的六格同一条（见 ../cover.typ 的 _filled）。
  let absolute(l, size) = l.abs + l.em * size
  // *这一行的字体决定线在哪儿*（Word 画的是那个 run 的下划线）：西文槽的行照 Times 的
  // post 表，中文槽的行照 Word 给中文字的那条规则，见 src/fonts/presets.typ 的 underlines。
  // 折成这一档字号上的绝对量，线心与线宽随行盒一起交出去
  let metrics(style, size, sq: sq0, line-box: auto) = {
    let u = if style.at("font-zh", default: "songti") in ("latin", "ascii") { underlines.latin } else { underlines.cjk }
    linebox.metrics(
      style + (size: size, line-spacing: ls-of(style, size, sq, line-box: line-box)), layout: layout,
    ) + (rule: (center: absolute(u.center, size), thickness: absolute(u.thickness, size)))
  }
  // 这一档不压时自己的行盒（1.5 倍）
  let own-box(style, size) = linebox.metrics(style + (size: size, line-spacing: form.line-spacing), layout: layout).box
  // *每一行按自己的字体*（Word 的自然行高：一行的高是这一行里字体的最大值）。*西文槽的 run
  // 挂 Times 自己的两条边*（1.5 倍的 Times 行盒，顶是 Times 的上升部）：一行里全是西文（纯
  // 数字、英文题目折出来的某一行、空着的格）这一行就是一个 Times 的行盒——基线比有汉字的行
  // 高一截、行盒矮一截，后面的行跟着上移；有一个汉字的行取最大值，顶与底都是中文字的（Times
  // 的底比中文字的浅，混着的行不会被撑高）。与原件填字后量的一样：题目填英文 Times 基线比
  // 「题目：」高 1.4，填中文与它齐；题目只写一个西文字母，下面那条空线与题目留空时同位。
  // 线跟着各行的基线走，见 ruled。*不按 line-box 撑*：那是给这一档中文字的行盒（六格按整行）
  // 用的，西文行照自己的
  let latin-of(style, size, sq: sq0) = metrics(style + (font-zh: "latin"), size, sq: sq)
  // *段落标记也算一个 run*（Word 的 ¶ 带着段落自己的字号字体，撑着末行）：每段末尾跟一个
  // 零宽的、带这一档 Times 两条边的字。往小三的格里填一段 12pt 的字（占位符那一档的 raw、
  // 用户手写的小字），那一行仍有 Times 小三那么高，小字坐在 ¶ 的基线上，不浮上去——先前
  // 那一行只有 12pt 高，基线比标签高 4.0。汉字行、正常西文行、公式撑高的行取最大值，不受它
  // 影响。空着的格就只剩这个 ¶，一行照排、线照画。*只落在末行*，量几何时也只在整段末尾加
  let mark(ml) = text(top-edge: ml.top-edge, bottom-edge: -ml.bottom-edge, sym.zws)
  let cell(body, style, size, sq: sq0, line-box: auto, leading: auto) = {
    let l = latin-of(style, size, sq: sq)
    paragraph(
      {
        show latin-slot-run: set text(top-edge: l.top-edge, bottom-edge: -l.bottom-edge)
        body
      },
      style + (size: size, line-spacing: ls-of(style, size, sq, line-box: line-box)),
      layout: layout, leading: leading,
    )
  }
  // *一格里折出来的行按行距排*，不按段内换行排：折行的第二行与第一行之间
  // 加上一个段前（12pt），行与行的步进就与格与格的步进一样——整页的下划线等距，
  // 折了行的那一格看着就是多了一格。*这一处不照原件*：Word 里段内换行没有段前，
  // 折出来的两条线只隔一个行盒（27），比格距（41）挤一截；填表的人看着像两种线距。
  // 题目那一格的两段本来就各带段前，折行之后与它同一个步进
  // *空当走 paragraph 的 leading 参数*（落在它显式的 par() 上）：先前是把 set par(leading:)
  // 写在内容里、靠 align 隐式成段来吃；paragraph 改成显式 par 之后（行间公式转行内要它，
  // 见 src/styles/paragraph.typ），内容里的 set 管不到 par 自己
  // 一格里每行一条线，落在这一行的基线下、这一行字体的线心处；行与行之间是这一行的行盒
  // 加段内空当。geo 是各行的几何（见 line-geometry）：行盒与上升部是量出来的，线心按这一行
  // 有没有汉字——有，按 m（这一档的中文字）；没有，按 ml（Times）。*线是块级的*，摆在段的前面（同一个格里），不占位、
  // 不参与折行。线心与线宽是 metrics 折好的绝对量——线摆在段落块外面，那儿的字号是页面默认
  // 的小四，em 交给 dy 会按 12pt 折
  // 把一段内容拆成能逐个累加的碎片：裸文字按簇拆，别的元素（上下标、强调、公式）整个算一片
  let pieces(body) = _flat(body).map(c => {
    if type(c) == str { c.clusters().map(text) } else if type(c) == content and c.func() == text {
      c.text.clusters().map(text)
    } else { (c,) }
  }).flatten()
  // *一格里各行的几何*：每一行有没有汉字（线心按它挑）、行盒多高、上升部多高（基线在哪儿）。
  // 一行或多行的裸文字、整格一种字，不必量：行盒与上升部就是那一档的。别的——折了行又中西
  // 混着的，或者带公式、上下标这类会把行撑高的东西——*全从 Typst 自己排出来的量取*：把碎片逐个
  // 累加着量高度，高度每多出大半个线距就是换了一行（不两端对齐，Typst 走贪心断行，前缀怎么折
  // 整段就怎么折），一行的行盒就是它排完比排完上一行多出来的；上升部则在这一行末尾塞一个
  // 零宽、比谁都高的探针再量一次，多出来的就是探针比这一行的上升部高出的那截。先前假定每行
  // 都是文字那一档的盒子，题目里一个 $W^(1,p)$ 的上标把第四行撑高 4，线就画到了字上面
  let line-geometry(body, style, size, sq, line-box, pitch, lines) = {
    let m = metrics(style, size, sq: sq, line-box: line-box)
    let ml = latin-of(style, size, sq: sq)
    let s = plain(body)
    let cjk = has-cjk(s)
    let ps = pieces(body)
    // 空格元素没有可引用的函数名，按它的 repr 认
    let all-text = ps.all(c => type(c) == str or (type(c) == content and (c.func() == text or repr(c.func()) == "space")))
    let mixed = cjk and s.replace(regex("\s"), "").match(latin-slot-run) != none
    let uniform = {
      let mi = if cjk { m } else { ml }
      ((cjk: cjk, box: mi.box, ascent: mi.ascent, body: none),) * lines
    }
    if all-text and (lines <= 1 or not mixed) { return uniform }
    let leading = pitch - m.box
    // ¶ 只在整段末尾（k 到头了）才加，探针跟在它后面
    let h(k, tail: none) = measure(block(
      width: inner,
      cell(
        ps.slice(0, k).join() + (if k == ps.len() { mark(ml) } else { [] }) + (if tail == none { [] } else { tail }),
        style + (align: center), size, sq: sq, line-box: line-box, leading: leading,
      ),
    )).height
    let heights = range(1, ps.len() + 1).map(k => h(k))
    // 空格碎片：按簇拆出来的 text(" ")、markup 里独立的 space 元素、裸字符串
    let is-space(c) = (
      (type(c) == str and c.trim() == "")
        or (type(c) == content and c.func() == text and c.text.trim() == "")
        or (type(c) == content and repr(c.func()) == "space")
    )
    // 能不能在第 k 片前面断：前面是空格、前一片以连字符收尾、或两侧任一片是汉字（汉字之间
    // 哪儿都能断）。高度是在一个词放不下的*那一簇*跳的（整个词挪到下一行），行首得退回到
    // 这个词的开头，不然逐行排的时候词会被劈开
    let breakable(k) = {
      let prev = plain(ps.at(k - 1))
      is-space(ps.at(k - 1)) or prev.ends-with("-") or has-cjk(prev) or has-cjk(plain(ps.at(k)))
    }
    let starts = (0,)
    for k in range(1, ps.len()) {
      if heights.at(k) - heights.at(k - 1) > pitch / 2 {
        let a = k
        while a > starts.last() + 1 and not breakable(a) { a -= 1 }
        starts.push(a)
      }
    }
    let ends = starts.slice(1) + (ps.len(),)
    let probe = 200pt
    let geo = starts.zip(ends).enumerate().map(((i, (a, b))) => {
      let total = heights.at(b - 1)
      let top = if i == 0 { 0pt } else { heights.at(a - 1) + leading }
      // 零宽的盒子坐在基线上往上伸 probe 那么高（baseline 不动，默认就在盒底）。*行末的空格
      // 先去掉*：换行时它本来就被丢掉，可探针跟在它后面它就留下了，还带着段落那一档（黑体）
      // 的底沿，量出来的上升部少 2.6
      let bb = b
      while bb > a + 1 and is-space(ps.at(bb - 1)) { bb -= 1 }
      let tall = h(bb, tail: box(width: 0pt, height: probe))
      // body：这一行的碎片，排的时候逐行自己排（见 ruled）
      let line = ps.slice(a, b).join()
      (cjk: has-cjk(plain(line)), box: total - top, ascent: probe - (tall - total), body: line)
    })
    // 量出来的行数与 lines-of 数的对不上就退回一种（宁可线位差一截，不画错条数）
    if geo.len() != lines { uniform } else { geo }
  }
  // 一段的行数：段高按「n 个行盒加 n − 1 个段前」反推（行盒定高，除得尽）。
  // *排不出内容的段回 0*——空段在 Typst 里没有行盒，调用处得自己认这一档
  // *量的样式要与排的一样带 align: center*：paragraph 的居中支是 align(center, 内容)，
  // 里面那句 set par(leading:) 落得到；左对齐支是显式的 par(…) 元素，内容里的 set
  // 管不到元素自己的 leading——先前少量了 align，折行的格每次都少数一行、少画一条线
  // 行数按不压的那一档量——压不压不改折行
  // 一格都是西文的按 Times 的行盒除（几行都准）；混着的按中文字的行盒除，西文的行矮一截
  // （小三 3.30），除出来偏小一点，六行以内四舍五入得回来
  let lines-of(body, style, size, line-box: auto) = {
    let h = measure(block(width: inner, cell(body + mark(latin-of(style, size)), style + (align: center), size, line-box: line-box, leading: sq0.gap))).height
    let box = if has-cjk(plain(body)) { metrics(style, size, line-box: line-box).box } else { latin-of(style, size).box }
    int(calc.round((h + sq0.gap) / (box + sq0.gap)))
  }
  // line 收这一段的行盒（题目留空时走西文那一档，见下面），auto ＝ 按样式算
  // *空着的格塞一个零宽空格撑出一行*：空段在 Typst 里没有行盒，那一行的高就全由标签格撑；
  // 英文标签一行里有 15pt 汉字与 16pt 尾巴两种 run，压缩转成绝对行盒后它比整行的盒矮
  // 0.95（见 field-box 那一段），六格全空时末线就比目标高几个点（用户量到的「英文版上移」，
  // 中文版标签与值同宽所以钉得住）。有了这一行，行高始终由值格定、与模型一致
  // *一格里各行占多高*（线与线的距离；用户定的）：折出来的行，步进不短于线距——纯西文的行
  // 盒矮（Times），不让下一行提前；公式、上标撑高的行照它自己的。末行下面留的空按这一档
  // 中文字的行盒算（pad）：末行是 Times 也不让下一格提前。单一种字的格交给 Typst 折行，
  // 空当按那一档的行盒算，步进正好是线距；中西混着、带公式的格各行几何是量出来的，逐行
  // 自己排（见 ruled）。shrink：压缩时各行的行盒减多少（几何按不压那一档量的时候用）
  // box：这一格「本来」的行盒——有汉字行的格按中文字的，纯西文的格按 Times 的（own-of）；空当
  // ＝ 线距减它，排的时候也是这个空当，两边才对得上。pad：末行下面留空按哪个行盒（这一档
  // 中文字的，与格里的字无关），none ＝ 不留
  let steps-of(geo, pitch, box, shrink: 0pt, pad: none) = geo.enumerate().map(((i, g)) => {
    let own = g.box - shrink
    if i + 1 < geo.len() { calc.max(pitch, own + pitch - (box - shrink)) }
    else if pad != none { calc.max(own, pad - shrink) } else { own }
  })
  let own-of(geo, m, ml) = if geo.any(g => g.cjk) { m.box } else { ml.box }
  // pitch：有汉字的行与行之间线的距离（折了行的格每行一条线），auto ＝ 行盒加段前。
  // 各行的几何在这儿按排的那一档（sq）现量（见 line-geometry）。pad：这一段是这一格的末段，
  // 末行下面按中文字的行盒留空
  let ruled(body, style, size, sq, line: auto, lines: auto, line-box: auto, pitch: auto, pad: false) = context {
    let m = if line == auto { metrics(style, size, sq: sq, line-box: line-box) } else { line }
    let ml = latin-of(style, size, sq: sq)
    let n = calc.max(if lines == auto { lines-of(body, style, size, line-box: line-box) } else { lines }, 1)
    let pitch = if pitch == auto { m.box + sq.gap } else { pitch }
    // 按内容判空，不按 n：六格调这儿时 lines 已经取过 max(…, 1)
    let empty = plain(body).trim() == ""
    // 空着的一格照画一条线，按 Times（格里那串空格是西文槽的），行由 ¶ 撑着
    let geo = if empty { ((cjk: false, box: ml.box, ascent: ml.ascent, body: none),) } else {
      line-geometry(body, style, size, sq, line-box, pitch, n)
    }
    let own = own-of(geo, m, ml)
    let steps = steps-of(geo, pitch, own, pad: if pad { m.box } else { none })
    // 线：各行的基线下、这一行字体的线心处
    let y = 0pt
    for (i, g) in geo.enumerate() {
      let mi = if g.cjk { m } else { ml }
      // std.line：这一层的 line 是上面那个参数（这一段的行盒）
      place(top + left, dy: y + g.ascent + mi.rule.center, std.line(length: inner, stroke: mi.rule.thickness))
      y += steps.at(i)
    }
    let height = steps.sum()
    // *能不重发就不重发*：逐行自己排要把字按簇重新发一遍，span 就丢了（tinymist 从预览点题目
    // 跳不回源码）。各行同一种字（纯汉字、纯西文、带公式的英文题目）的格，原内容交给 Typst
    // 折行，空当按这一档的行盒算，步进正好是 pitch，公式撑高的行自然更高——与 steps-of 一致；
    // 量出来的几何只用来画线、算高。只有既有汉字行又有纯西文行的格才逐行排：西文行的盒矮，
    // 要给它补到一个步进，段落的空当是一个数，做不到
    if geo.map(g => g.cjk).dedup().len() <= 1 {
      block(height: height, above: 0pt, below: 0pt, width: 100%,
        cell(body + mark(ml), style + (align: center), size, sq: sq, line-box: line-box, leading: pitch - own))
    } else {
      for (i, g) in geo.enumerate() {
        block(height: steps.at(i), above: 0pt, below: 0pt, width: 100%,
          cell(g.body + (if i + 1 == geo.len() { mark(ml) } else { [] }),
            style + (align: center), size, sq: sq, line-box: line-box, leading: 0pt))
      }
    }
  }
  // ── 六格的行盒：*按整行算，不按值那一段自己算* ─────────────────
  //
  // 一行的高是标签格与值格里较高的那个。中文版两格都是小三、都是 29.18；*英文版的
  // 标签带 16pt 的「/ English」尾巴*（_label-en-size），Word 里一行的行高取这一行
  // 最大的 run，标签那一格就是 1.5 × 1.2969 × 16 ＝ 31.13，六行的步进因此是 43.13
  // 而不是 41.18（原件量得 43.2）。值那一格的行盒就写成这个数（长度那一档，见 ls-of）
  // ——行高由值格撑、不由标签撑，折了行的格每一行都是这个盒，压缩时也从这个数减；
  // 先前按值那一段自己的 29.18 算，英文版每一格的模型都矮 1.95，压缩钉不准末线，
  // 折出来的行也比整页的线距挤 1.95
  let label-m = linebox.metrics(
    styles.label + (size: if lang == "en" { calc.max(field-size, _label-en-size) } else { field-size },
      line-spacing: form.line-spacing),
    layout: layout,
  )
  let field-box = calc.max(
    label-m.box,
    linebox.metrics(styles.value + (size: field-size, line-spacing: form.line-spacing), layout: layout).box,
  )
  // 六格的值与各自的行数（先量，压缩要用）
  // 日期按这一页的语言当场渲染（date-lang），不留成 context 块——line-geometry 要拿 plain()
  // 看这一格有没有汉字
  let values = _rows.map(name => value-of(info, name, lang: lang, date-lang: lang))
  let value-lines = values.map(v => calc.max(lines-of(v, styles.value, field-size, line-box: field-box), 1))
  // *六格的页距*：行盒 ＋ 段前 12 ＝ 41.18（英文版 43.13）。折出来的行也按它，见上面
  let pitch = field-box + form.cell-above
  // 六格各自各行的几何（不压那一档量的，见 line-geometry）：有汉字的行线在中文那一档，
  // 纯西文的在 Times 那一档、行也矮一截
  let field-ml0 = latin-of(styles.value, field-size)
  let field-geo = values.enumerate().map(((i, v)) => {
    if plain(v).trim() == "" { ((cjk: false, box: field-ml0.box, ascent: field-ml0.ascent),) } else {
      line-geometry(v, styles.value, field-size, sq0, field-box, pitch, value-lines.at(i))
    }
  })
  // 第 i 格这一行的高：段前 ＋ 标签格与值格里高的那个（值格是各行的行盒加段内空当；压缩时
  // 各行的行盒减 shrink——公式撑高的行也这么算，差在基线以下那一截，够用）
  let row-height(i, z) = {
    let own = if field-geo.at(i).any(g => g.cjk) { field-box } else { field-ml0.box }
    let value = steps-of(field-geo.at(i), field-box + z.field.gap, own, shrink: z.field.shrink, pad: field-box).sum()
    z.field.gap + calc.max(label-m.box - z.field.shrink, value)
  }
  let row(name, value, lines, sq, size: field-size) = {
    let label = {
      cell(
        // *裹一层 box*：标签里的空隙是 h()，不裹会成为断行点。
        // *宽度按自然宽给死*——英文版「指导教师/ Supervisor：」量得 159.2，
        // 比标签那一列的内缘 157.05 还宽，不给死就折成两行；原件里 Word 也是
        // 让它探出去，不折
        _fixed(_label(label-of(name), size, spaces: label-spaces.field)),
        styles.label,
        size,
        sq: sq,
        // *标签格按自己的行盒缩，不用整行的*：英文标签一行里有 15pt 汉字与 16pt 尾巴两种
        // run，配上绝对量的行盒，行高成了「最大上升部 ＋ 最大深度」、多出 1pt，六行高矮
        // 交错（试过）。按自己的缩它就比值格矮，行高由值格定
      )
    }
    let label = _label-cell(label, top: sq.gap)
    (label, ruled(value, styles.value, size, sq, lines: lines, line-box: field-box, pad: true))
  }
  // ── 题目那一格：*照原件的段落结构* ──────────────────────────────
  //
  // 原件那一格是*两段*，各写着 w:before="240"（12pt）、行距 1.5 倍：
  // 头一段是题目，第二段空着——所以第二段那条线是「题目下面还留着的一条」，
  // 不是题目的第二行。*题目长了在头一段里自己折行*，折出来的行之间只隔一
  // 个行盒（段内换行没有段前）；那条空线仍旧跟在后面、仍旧自带 12pt 段前。
  //
  // 往原件的题目格里填了字再量，三种都对得上：
  //
  //   两段各写一行  两条线相距 46.80（12 ＋ 34.80），六格*不下移*
  //   一段写满两行  34.80（段内折行），那条空线仍在后面 45.60 处
  //   一格都不填    42.96 ＝ 12 ＋ 1.5×1.15×18
  //
  // *空段的行高按段落标记的西文槽算*（1.15），不按黑体——那一段里一个汉字
  // 都没有。这与 src/styles/enter.typ 是同一条规矩，所以高度也走它；线的位置
  // 同理落到六格那一档（Word 按西文画）。
  // 空段的样式：字体角色照题目那一档（排字时要查字体表），行的度量按段落标记的西文槽
  let blank-style = styles.title-value + (font-zh: "ascii", snap-to-docgrid: false)
  let blank-line(sq) = metrics(blank-style, title-size, sq: sq)
  let filled-line(sq) = metrics(styles.title-value, title-size, sq: sq)
  // *题目各行一步 45.30*（用户定的）：按空表单自己的题目行距——题目一行时第二条线是那条
  // 空线的（Times 空行：题目行深 ＋ 段前 12 ＋ 空行上升部，再差两行线心之差，两线相距
  // 45.30），题目折到两行第二行就落在这条线上，三行、四行都按这一步；题目字大（小二），比
  // 六格的页距略高。先前折出来的行按页距 41.18（题目行与六格一样高），又给「恰好两行」开过
  // 特判，都收了。*压缩也按这个比例*：题目行按 45.30、六格按 41.18 同乘一个系数，不是每行减同一个
  // Δ——先前那样压完题目行与六格一样高，用户否了：空表单里题目行就比六格高一截，压完
  // 也该高这一截
  let blank-rule = (
    filled-line(sq0).box - filled-line(sq0).ascent + form.cell-above + blank-line(sq0).ascent
      + blank-line(sq0).rule.center - filled-line(sq0).rule.center
  )
  let title-pitch = blank-rule
  let title-gap = title-pitch - filled-line(sq0).box
  let ratio = title-pitch / pitch
  // 压缩后题目那一档的线距：题目行按 title-gap 缩，缩完线距正好少 Δ × ratio
  let title-pitch-of(z) = title-pitch - z.delta * ratio
  // 一段一段排：段数照原件补足（见 _table 的 title-paragraphs），每一段自己
  // 折行、自己算行盒
  // *补空段按行数补，不按段数补*：题目一行时下面多留一条线（原件那格就是两条），
  // 题目自己折到两行、三行就不再补——折出来的行已经各带一条线，再补一条空线
  // 就成了第四条。所以先把写的几段各量行数，凑不够 title-paragraphs 那么多行才补
  let title-paragraphs = {
    let given = _paragraphs(title-value).map(seg => {
      let n = lines-of(seg, styles.title-value, title-size)
      (
        body: seg,
        rows: calc.max(n, 1),
        blank: n == 0,
        // 空段按段落标记的西文槽算；有字的段行盒按黑体，每一行的基线与线再按内容定（见 ruled）
        style: if n == 0 { blank-style } else { styles.title-value },
        // 各行的几何（不压那一档量的）：压缩模型算格高、上限要用
        geo: if n == 0 { ((cjk: false, box: blank-line(sq0).box, ascent: blank-line(sq0).ascent),) } else {
          line-geometry(seg, styles.title-value, title-size, sq0, auto, title-pitch, calc.max(n, 1))
        },
      )
    })
    let lines = given.map(p => p.rows).sum(default: 0)
    let blank = (
      body: [], rows: 1, blank: true, style: blank-style,
      geo: ((cjk: false, box: blank-line(sq0).box, ascent: blank-line(sq0).ascent),),
    )
    given + (blank,) * calc.max(form.title-paragraphs - lines, 0)
  }
  let title-lines = title-paragraphs.filter(p => not p.blank).map(p => p.rows).sum(default: 0)
  // 各种行按 Δ 压出来的样子。Δ 是六格那一档的；题目那一档按比例是 Δ × ratio，*按 title-gap
  // 缩*（缩得比别处早），它之后接的东西要把多缩的（shrink 之差）补回来，好让题目格→姓名
  // 那一步也正好减 Δ；空线那一段按 12 那一档
  let squeeze(delta) = {
    let f = sq-of(delta)
    let t = sq-of(delta * ratio, base: title-gap)
    (
      field: f, title: t, blank: f,
      // 题目格顶上那一截：*不压*，就是段前 12——头一行上面没有线，它的段前是表的顶留白，
      // 不是行与行的空当；压了它整张表就往上蹿（用户导出的那份「题目：」从 340.8 跑到
      // 328.8）。表顶不动、末线钉回，Δ 由二分自己放大。左边标签格同一个数（见 grid 里的
      // 题目标签），先前两边都写 f.gap 一起往上跑；补回来的那份只该出现在题目行的*后面*
      // （行盒缩的是基线以下那一截），顶上补了就把题目头一行压得比「题目：」低
      top: form.cell-above,
      // 题目格底：末段是题目就补回多缩的那份，是空线就不必
      bottom: if title-paragraphs.last().blank { 0pt } else { t.shrink - f.shrink },
      delta: delta,
    )
  }
  let title-sq(p, z) = if p.blank { z.blank } else { z.title }
  let title-line(p, z) = metrics(p.style, title-size, sq: title-sq(p, z))
  // 题目格里段与段之间留多少。*题目段接题目段*（题目里手写的换行）：与折出来的行同一
  // 步——行盒都是黑体那一档的，留题目线距减行盒（t.gap）就够，各行的基线与线再按内容定。
  // *接的是空线那一段*：照 Word 的段前 12（压缩时减 Δ，题目行盒多缩的那份补回来）——
  // 题目一行是黑体时算出来正好也是一个题目线距（title-pitch 就是这么定的），题目留空时
  // 头一段是 Times 空行、两条线相距 12 ＋ Times 行盒 ＝ 43.05，与空白原件量的 42.96 对上
  let above-of(i, z) = if title-paragraphs.at(i).blank {
    z.title.gap + form.cell-above - title-gap
  } else { z.title.gap }
  // 题目那一格的高：顶上一截 ＋ 各段（段前 ＋ 各行占的高，见 steps-of）＋ 底。末段的末行下面
  // 按黑体的行盒留空（pad），题目末行是 Times 也不让姓名那一行提前
  let title-height(z) = z.top + title-paragraphs.enumerate().map(((i, p)) => {
    let above = if i == 0 { 0pt } else { above-of(i, z) }
    let last = i + 1 == title-paragraphs.len()
    let base = if p.geo.any(g => g.cjk) { filled-line(sq0) } else { latin-of(p.style, title-size) }
    above + steps-of(p.geo, title-pitch-of(z), base.box, shrink: title-sq(p, z).shrink, pad: if last { filled-line(sq0).box } else { none }).sum()
  }).sum(default: 0pt) + z.bottom
  // 表的总高：题目那一格加六格各自的行数 × (行盒 ＋ 段前)。min 是那一格 112.55 的
  // 下限——只在不压时守着；压起来那截留白先让出去
  let table-height(z, min: 0pt) = calc.max(min, title-height(z)) + range(_rows.len()).map(i => row-height(i, z)).sum()
  let z0 = squeeze(0pt)
  // 空表单那张表的高：题目一行加一条空线（装进 112.55 的下限），六格各一行
  let empty-height = calc.max(
    form.title-height,
    form.cell-above + filled-line(sq0).box + form.cell-above + blank-line(sq0).box,
  ) + _rows.len() * pitch
  let natural-height = table-height(z0, min: form.title-height)
  // *压回哪儿*（用户定的）：哪一格长出来（题目超过表单留的两行、六格折了行）把页撑爆，
  // 就把*那一格*的增长压掉，压完表底回到「那一格没长」时的位置——题目短时日期在哪儿，
  // 题目长了压完日期还在哪儿（用户拿两版对过）；学院折了四行撑爆页，压完日期也回到学院
  // 一行时的位置。几格一起长时退哪几格？*退得最少而整张表装得下的那一种*（候选按格的
  // 子集枚举，最多七格 128 种）：只退题目就装得下，学院折出来的那一格就照实际留着。
  // 先前钉的是空表单的底，学院折成两行时日期就落到了指导教师那一行上；再先前只给题目
  // 留了这条路，六格自己撑爆时只压到页底
  let growths = (
    calc.max(title-height(z0) - form.title-height, 0pt),
    ..range(_rows.len()).map(i => row-height(i, z0) - (form.cell-above + field-box)),
  ).filter(g => g > 0pt)
  let absorbed(mask) = growths.enumerate().map(((i, g)) => {
    if calc.rem(calc.quo(mask, calc.pow(2, i)), 2) == 1 { g } else { 0pt }
  }).sum(default: 0pt)
  // 压到字碰线的上限。*看墨迹，不看字体的上升部*：Times 的上升部 0.891em，大写字母只到
  // 0.66em，按上升部算英文早叫一行（用户量的）。每一处「上一行有线、下一行有字」的相邻
  // 两行都是一道上限：Δ ≤ 两行的基线距 − 上一行的线心 − 线宽 − 下一行字的墨迹高（线心与
  // 线宽是 em 长度，折到那一档的字号上）。墨迹高按整格的值量（top-edge: "bounds"，一格里
  // 最高的那个字形），折了行的格每一行都按它算，偏保守不到半个字形。
  // *行盒可以比上升部矮*：矮过了基线就落到盒底（src/styles/linebox.typ 的 resolve，裸长度
  // 那一档），线跟着基线走（rules 用 m.ascent），所以不必另设一道「盒不低于上升部」的底
  // ——先前设了，英文题目压到离线还有 2.6 就停
  // 量墨迹要用排的那一套字体（黑体 ＋ 粗 Times、Times……），所以套 style-rules.rules 再量；
  // 两条边显式写在 text 上，压得过 rules 里 set 的行盒
  // *先把行间公式转行内再量*（排的时候 paragraph 会转，量的时候得自己转）：块级公式进了
  // box 是整块摞在字下面，墨迹量成几十磅，上限算成 0，一点都不压就红字（用户撞到的）
  // *量的是一个显式的 par*，宽到不折行：行间公式转行内那条规则只在显式的 par 上生效（见
  // src/styles/paragraph.typ），套在 box 或 text 外面都不管用（试过）
  let ink-of(body, style, size) = measure(block(width: 100 * layout.paper-width, {
    show: style-rules.rules.with(style + (size: size), layout: layout, set-font: true)
    inline-math(par(text(top-edge: "bounds", bottom-edge: "baseline", body)))
  })).height
  let field-m = metrics(styles.value, field-size, line-box: field-box)
  let field-ml = latin-of(styles.value, field-size)
  let field-of(cjk) = if cjk { field-m } else { field-ml }
  let field-classes = field-geo.map(gs => gs.map(g => g.cjk))
  let field-inks = values.map(v => ink-of(v, styles.value, field-size))
  let title-bodies = title-paragraphs.filter(p => not p.blank).map(p => p.body)
  let title-ink = ink-of(if title-bodies.len() == 0 { [] } else { title-bodies.join([]) }, styles.title-value, title-size)
  let last = title-paragraphs.last()
  // 题目末行的度量：线心按它有没有汉字，行盒与上升部用量出来的
  let last-g = last.geo.last()
  let last-m = (if last-g.cjk { title-line(last, z0) } else { latin-of(last.style, title-size, sq: z0.title) }) + (box: last-g.box, ascent: last-g.ascent)
  // 上一行的线（线心 ＋ 线宽）到这一行字的墨迹顶之间还剩多少：prev 是上一行的度量
  let clearance(pitch0, prev, ink) = pitch0 - prev.rule.center - prev.rule.thickness - ink
  // 标签格没有线管着，可行盒压过上升部基线就落到盒底、字往上跑（英文题目六行时「日期」
  // 的字比线高了 1.6）：标签的行盒不低于它的上升部——按标签样式自己那一档（小三黑体；
  // 英文标签的 16pt 尾巴只是一个 run，段的两条边跟样式走），题目标签同理
  let field-label-m = metrics(styles.label, field-size)
  let title-label-m = metrics(styles.label, title-label-size)
  let caps = (
    form.cell-above + field-label-m.box - field-label-m.ascent,
    form.cell-above + title-label-m.box - title-label-m.ascent,
    // 题目格 → 姓名那一格：末段是空线就按它的线心，是题目就按题目的
    clearance(
      last-m.box - last-m.ascent + form.cell-above + field-of(field-classes.at(0).first()).ascent,
      last-m, field-inks.at(0),
    ),
  ) + (
    // 题目自己折了行或分了段：一步题目线距；这一道限的是题目那一档的 Δ × ratio，折回 Δ。
    // 哪一行的线最低（有汉字的）就按哪一行
    if title-lines >= 2 {
      let first = title-paragraphs.find(p => not p.blank)
      let any-cjk = title-paragraphs.any(p => p.geo.any(g => g.cjk))
      let prev = if any-cjk { title-line(first, z0) } else { latin-of(first.style, title-size, sq: z0.title) }
      (clearance(title-pitch, prev, title-ink) / ratio,)
    } else { () }
  ) + (
    // 六格：第二格起上面有上一格的线；自己折了行的格，第二行起上面是自己的线
    range(_rows.len()).map(i => {
      let above = if i > 0 { (clearance(pitch, field-of(field-classes.at(i - 1).last()), field-inks.at(i)),) } else { () }
      // 自己折了行：第二行起上面是自己的线，按上一行的类；哪一行的线最低就按哪一行
      let own = if value-lines.at(i) >= 2 {
        (clearance(pitch, field-of(field-classes.at(i).slice(0, -1).any(c => c)), field-inks.at(i)),)
      } else { () }
      above + own
    }).flatten()
  )
  let squeeze-max = calc.max(caps.fold(caps.first(), calc.min), 0pt)
  // *钉的是末行那条线的位置*，不是表的底：Δ 吃到行盒里之后末行的行盒变矮的是
  // 基线以下那一截，基线（线跟着它）离表底就近了 shrink 那么多——光钉表底的话
  // 最后那条线会比目标低一截。所以比的是「表高 ＋ 末行的 shrink」
  let fits(z, target) = table-height(z) + z.field.shrink <= target
  // *触发的条件是表要溢出这一页*，不是表比空表单高——表比空表单高但页上还装得下，
  // 就照旧往下长；溢出了才压，一压就压回空表单那一处。表顶的位置从 here() 取（这一句
  // context 就发在表的落点上）。
  // *页底是版心底再减去表后那个空段*（用户定的，见 _table 的 anchor）：只比版心底的话，
  // 「多两行、题目再多一行」那一族填法表底落在版心底上方 0.5pt，判装得下，末条线离下边距
  // 只剩 12——看着就是贴着页底没压。Word 那边这条线没法照抄：把原件填成题目四行、学院
  // 两行，Word 让浮动表伸进下边距（日期基线量到 768，表底越过版心底），并不挪页
  context {
    // 不叫 top：那是对齐值，下面纸角红字的 place(top + left) 还要用它
    let table-top = here().position().y
    let page-bottom = calc.max(
      layout.margin.top + layout.text-height - (form.anchor.above + form.anchor.line-spacing.exactly),
      // *空表单自己不算超页*：英文版的表底离版心底只剩 22，留不下那个空段，减了就把
      // 一格都没填的表也判成超页、压掉题目格的留白（英文中期那份 demo 量歪过）。所以
      // 英文版六格哪一格折了行都压，中文版空表单下面还有一截可长
      table-top + empty-height,
    )
    let overflow = table-top + natural-height > page-bottom
    // 装得下的候选里取最高的（＝ 退回的格最少）；全退回就是空表单，它一定装得下
    let room = page-bottom - table-top
    let target = range(calc.pow(2, growths.len()))
      .map(mask => natural-height - absorbed(mask))
      .filter(t => t <= room)
      .fold(empty-height, calc.max)
  let (z, crowded) = if not overflow { (z0, false) } else if not fits(squeeze(squeeze-max), target) {
    // 压到上限仍回不到目标：钉在上限，纸角出声
    (squeeze(squeeze-max), true)
  } else {
    // 总高随 Δ 单调降，可不是一条直线（题目那几截补回来的量分段），二分找到
    // 「末行那条线正好回到目标那一处」的 Δ；40 轮之后误差在千分之一磅以下
    let lo = 0pt
    let hi = squeeze-max
    for _ in range(40) {
      let mid = (lo + hi) / 2
      if fits(squeeze(mid), target) { hi = mid } else { lo = mid }
    }
    (squeeze(hi), false)
  }
  let sq = z.field
  // 压到底仍装不下：纸角红字，与本部报告首页的溢出红字同一个机制（warning: false 关）。
  // *发在表格前面*：表格装不下时会跨页或整张挪到下一页，红字排在它后面就跟着落到
  // 下一页角上；排在前面才钉在封面这一页的角上
  if crowded and warning != false {
    overflow-note(pick("warning-crowded"), pick("warning-false"), lang: lang)
  }
  align(center, block(width: label-width + value-width, grid(
    columns: (label-width, value-width),
    // *题目那一格「至少」112.55*（w:trHeight 2251 没写 hRule ＝ atLeast）
    // ——题目一行时两段只用掉 90，余下那截留白落在格底；题目折到三行、四行
    // 就按内容长高，姓名那一行跟着往下让。另六行没写行高，自然高
    rows: (
      // 压起来那一格的下限就不守了，见 table-height
      calc.max(if z.delta == 0pt { form.title-height } else { 0pt }, title-height(z)),
      ..(auto,) * _rows.len(),
    ),
    inset: (x: _cell-inset, top: sq.gap, bottom: 0pt),
    align: form.align + left,
    // 题目行的标签：顶留白与题目格一样不压（z.top），行盒照六格那一档缩
    _label-cell(cell(
      _fixed(_label(label-of("title"), title-label-size, spaces: label-spaces.title)),
      styles.label, title-label-size, sq: sq,
    ), top: z.top),
    grid.cell(inset: (x: _cell-inset, top: z.top, bottom: z.bottom), {
      // 一段一段发。*每一段的高写死成「行数 × 行盒」*：Word 里空段照样占
      // 一行，而 Typst 里排不出内容的段高是 0——题目留空时下面那条线会提前一
      // 整行（量到 352.44，该在 383.49）。与 src/styles/enter.typ 同一条。
      //
      // 头一段的段前走单元格的上留白（Typst 的块间距在容器开头会被丢掉），
      // 第二段起自己发
      for (i, p) in title-paragraphs.enumerate() {
        // 段与段之间的空当走 above；段自己多高由 ruled 里那些定高的块定（与 title-height 同一个算法）
        block(
          above: if i == 0 { 0pt } else { above-of(i, z) },
          below: 0pt,
          ruled(p.body, p.style, title-size, title-sq(p, z),
            line: title-line(p, z), lines: p.rows, pitch: title-pitch-of(z), pad: i + 1 == title-paragraphs.len()),
        )
      }
    }),
    ..range(_rows.len()).map(i => row(_rows.at(i), values.at(i), value-lines.at(i), sq)).flatten(),
  )))
  }
}
