#import "../../../docxtyp.typ" as d
#import "@local/docxtyp:0.1.0" as core
#import d.styles as styles
#import d.styles: paragraph
#import d.layout: page-setup-state
#import d.content: plain-text
#import d.runs: has-cjk
#import d.paragraph: paragraph-mark as enter
#import "../../../terms/lookup.typ": term-table, term-for, term-apply, subject-of, variant-of
#import "../../../terms/date.typ" as dates
#import "../../../terms/lang.typ": title-of
#import "../../../info.typ": info-get
#import "../../../settings/resolve.typ": resolve-openright
#import "../../checkbox.typ": checkbox
#import "./doctor-interim.typ" as sheet

#let _list(value) = if value == none { () } else if type(value) == dictionary { (value,) } else { value }
#let _check-signature(record, where) = {
  let value = record.at("signature", default: none)
  if value != none and type(value) != content { panic(where + ".signature: expected content or none, found " + repr(value)) }
}
#let _date(value, fallback, lang) = {
  if value == auto { return dates.entry(info-get().date, fallback, lang: lang) }
  if value == none { return [] }
  if type(value) == str { return dates.render(value, lang: lang) }
  if type(value) == content { return title-of(value, lang) }
  panic("defense: signature date: expected ISO date, content, none, or auto, found " + repr(value))
}

#let review(
  supervisor: none, chair: none, members: (), resolution: none, result: none,
  lang: "zh", overrides: (:), form: auto, title: auto, openright: auto,
) = context {
  let supervisor = if supervisor == none { (:) } else { supervisor }
  if type(supervisor) != dictionary { panic("defense.supervisor: expected dictionary or none") }
  for key in supervisor.keys() {
    if key not in ("opinion", "completion", "date", "signature") { panic("defense.supervisor: unknown key " + repr(key)) }
  }
  let completion = supervisor.at("completion", default: none)
  let completions = ("on-time", "delay", "dismissal")
  let results = ("pass", "revise", "dismissal")
  if completion not in (none,) + completions { panic("defense.supervisor.completion: expected none, \"on-time\", \"delay\", or \"dismissal\"") }
  if result not in (none,) + results { panic("defense.result: expected none, \"pass\", \"revise\", or \"dismissal\"") }
  _check-signature(supervisor, "defense.supervisor")
  let chairs = _list(chair)
  let members = _list(members)
  if type(chairs) != array or type(members) != array { panic("defense: chair and members: expected personnel records") }
  for person in chairs + members {
    if type(person) != dictionary { panic("defense: expected personnel dictionaries") }
    _check-signature(person, "defense.person")
  }
  let t = term-table(lang, "defense", overrides: overrides)
  let variant = variant-of(info-get()) + (if form == auto { (:) } else { (form: form) })
  let pick(key) = term-for(t, key, variant)
  let people = chairs + members
  let people = people + range(calc.max(0, 5 - people.len())).map(_ => (:))
  let blank-chair = if chairs.len() == 0 { ((:),) } else { chairs }
  let lay = page-setup-state.get()
  let fonts = d.fonts.fontset-state.get()
  let native = core.fonts.profile(fonts.families.songti, metrics: fonts.metrics.songti,
    latin: fonts.families.songti, latin-metrics: fonts.metrics.songti)
  let body-style = sheet.body-style + (font: native, first-line-indent: 0pt,
    above: 0pt, below: 0pt, line-spacing: (exactly: 14.25pt))
  let small = body-style + (size: 11pt, line-spacing: (exactly: 12.75pt))
  let opinion-style = body-style + (line-spacing: (exactly: 24.25pt))
  let w = calc.min(sheet.width, lay.text-width + 2 * sheet.inset)
  let p(body, style: body-style, leading: auto) = paragraph(body, style, layout: lay, latin: lang == "en", leading: leading)
  let signatures = blank-chair.map(person => (
    signature: person.at("signature", default: []),
    date: _date(person.at("date", default: auto), "interim", lang),
  ))
  let supervisor-date = _date(supervisor.at("date", default: none), "interim", lang)
  let supervisor-signature = supervisor.at("signature", default: [])
  let as-body(body, style: body-style) = styles.format(style, body, layout: lay)
  let columns = (28.4pt, 136.25fr, 113.2fr, 127.9fr, 127.95fr)
  let field-widths = (name: 136.25pt, title: 113.2pt, discipline: 127.9pt, signature: 127.95pt)
  let field-scale = (w - 28.4pt) / (sheet.width - 28.4pt)
  let cell-heights = people.map(person => calc.max(sheet.row-height,
    ..("name", "title", "discipline", "signature").map(key => {
      let c = person.at(key, default: [])
      measure(block(width: field-scale * field-widths.at(key) - 2 * sheet.inset, as-body(c))).height + 2 * sheet.inset
    }),
  ))
  // 意见栏沿用原表的最小高度；超长时增长、跨页，不把其余栏目挤到页底。
  let opinion(body, minimum, style: opinion-style, left: 0pt, top: 0pt) = {
    let content = as-body(body, style: style)
    let natural = measure(block(width: w - 2 * sheet.inset - left, content)).height + top + 2 * sheet.inset
    block(width: 100%, height: if natural <= minimum { minimum } else { auto },
      above: 0pt, below: 0pt, breakable: true,
      inset: (left: sheet.inset + left, right: sheet.inset, top: sheet.inset + top, bottom: sheet.inset), content)
  }
  let row(body, style: body-style, height: sheet.row-height, left: 1pt, right: 0pt, stroke: none, sticky: false, prepared: false) = {
    let content = if prepared { body } else { p(body, style: style) }
    let natural = measure(block(width: w - 2 * sheet.inset - left - right, content)).height
    block(width: 100%, above: 0pt, below: 0pt, stroke: stroke, sticky: sticky,
      height: calc.max(height, natural), inset: (left: sheet.inset + left, right: sheet.inset + right, y: 0pt),
      align(horizon, content))
  }
  let signature-line(label, signature, style: body-style, left: 0pt, column: auto) = {
    let value = if signature == none { [] } else { box(signature) }
    if column == auto {
      row({ label; h(0.5em); value }, style: style, left: left)
    } else {
      row(grid(columns: (column, 1fr), p(label, style: style), p(value, style: style)),
        style: style, left: left, prepared: true)
    }
  }
  let card(body) = {
    enter(size: 1pt, font: "serif", line-spacing: 1, snap: false, layout: lay)
    v(0.5pt)
    pad(left: -sheet.inset, right: -sheet.inset,
      block(width: w, above: 0pt, below: 0pt, breakable: true, stroke: sheet.rule + black, body))
  }
  // 竖向合并标签只覆盖本页的行；不能让一个 rowspan 跨过整份长名单，否则原生表格会裁掉页外行。
  let member-table(people, heights, available: auto) = context {
    let full-page = lay.text-height - sheet.row-height - 2 * sheet.rule
    let available = if available == auto {
      lay.paper-height - lay.margin.bottom - here().position().y - sheet.row-height - 2 * sheet.rule
    } else { available }
    if heights.first() > lay.text-height - sheet.row-height - 2 * sheet.rule {
      panic("defense: a committee member row is taller than a page; reduce the signature size or shorten the entry")
    }
    let n = 0
    let used = 0pt
    for height in heights {
      if used + height > available { break }
      used += height
      n += 1
    }
    if n == 0 {
      return {
        colbreak(weak: true)
        member-table(people, heights, available: full-page)
      }
    }
    let label = pick("committee")
    let words = plain-text(label)
    let label = if words == none or words == "" { label } else if has-cjk(words) {
      let chars = words.clusters()
      let size = calc.min(11pt, (used + sheet.row-height) / chars.len() / 1.2)
      text(size: size, stack(dir: ttb, spacing: 0pt, ..chars))
    } else {
      let size = calc.min(11pt, 11pt * used / measure(text(size: 11pt, words)).width)
      rotate(90deg, reflow: true, text(size: size, words))
    }
    // 版式表使用 grid，避免正文 table 的字号、三线表和题注规则介入。
    // 左侧竖排标签连表头一起合并，原表不是只合并五个人员行。
    let form = grid(
      columns: columns,
      rows: (sheet.row-height,) + heights.slice(0, n),
      inset: (x: sheet.inset, y: 0pt), stroke: sheet.rule + black, align: center + horizon,
      grid.cell(rowspan: n + 1, align: center + horizon, label),
      ..("column-name", "column-title", "column-discipline", "column-signature").map(key => p(pick(key), style: small + (align: center))),
      ..people.slice(0, n).map(person => ("name", "title", "discipline", "signature").map(key =>
        p(if key == "signature" { box(person.at(key, default: [])) } else { person.at(key, default: []) }, style: body-style + (align: center)),
      )).flatten(),
    )
    {
      show: styles.rules.with(small, layout: lay, set-font: true)
      form
    }
    if n < people.len() {
      colbreak(weak: true)
      member-table(people.slice(n), heights.slice(n), available: full-page)
    }
  }
  let document = {
    let odd = resolve-openright("mainmatter", degree-level: "doctor", local: openright)
    let next() = if odd { pagebreak(weak: true, to: "odd") } else { pagebreak(weak: true) }
    next()
    card({
      // 导师页：原表提示占两行，意见栏 10080 缇，其后保留判断、勾选与签字日期各行。
      row(if title == auto { pick("supervisor-opinion") } else { title-of(title, lang) })
      // 原表的提示语占两个 28.3pt 行；字的行盒仍为 12.75pt，不能把行盒本身拉大。
      row(p(pick("supervisor-hint"), style: small, leading: sheet.row-height - 12.75pt),
        height: 2 * sheet.row-height, prepared: true)
      opinion(supervisor.at("opinion", default: []), 504pt, left: 14pt, top: 5pt)
      row(pick("completion-question"), style: small, height: 30pt)
      row(grid(columns: (107.85pt, 85.2pt, 14.2pt, 85.05pt, 14.15pt, 84.9pt, 1fr),
        [], ..completions.map(key => (
          p({ checkbox(completion == key); pick("completion-" + key) }, style: small + (align: center)),
          [],
        )).flatten()), style: small, left: 0pt, prepared: true)
      v(33pt)
      signature-line(pick("supervisor-signature"), supervisor-signature, style: small, left: 279.15pt, column: 99.05pt)
      v(21pt)
      row(supervisor-date, style: small, height: 25.5pt, left: 378.2pt)
      v(25pt)
    })

    next()
    card({
      // 检查组页：意见栏 2834 缇；成员表紧接日期，外框随表结束，不延伸到页底。
      row(term-apply(t, "resolution", variant, subject-of(t, variant)))
      opinion(if resolution == none { [] } else { resolution }, 141.7pt)
      row(pick("result"))
      for key in results {
        row({ checkbox(result == key); pick("result-" + key) }, left: 57.8pt)
      }
      for signed in signatures {
        signature-line(pick("chair-signature"), signed.signature, left: 235.4pt)
        row(signed.date, left: 335.45pt)
      }
      row(pick("members-title"), style: body-style + (align: center), stroke: (top: sheet.rule + black, bottom: sheet.rule + black), sticky: true)
      member-table(people, cell-heights)
    })
  }
  set page(background: none)
  set text(cjk-latin-spacing: none)
  document
}
