#import "../../../docxtyp.typ" as d
#import "@local/docxtyp:0.1.0" as core
#import d.styles as styles
#import d.styles: paragraph
#import d.paragraph: paragraph-mark as enter, paragraph-mark-height as enter-height
#import d.layout: page-setup-state
#import "../../../heading/numbering.typ": heading-top
#import "../../../terms/lang.typ": title-of, doc-lang
#import "./body-plan.typ" as planning
#import "../../../terms/lookup.typ": term-table, term-for, variant-of, document-type-of
#import "../../../terms/date.typ" as dates
#import "../../../info.typ": info-get, value-of
#import "../../overflow.typ": overflow-note

// 《博士中期评议表.doc》实际为 RTF。原始单位为缇：表宽 10674，行高 680／566，边框 20。
#let width = 533.7pt
#let inset = 0.5pt
#let row-height = 28.3pt
#let rule = 1pt
#let cover-inputs = (margin: (left: 28.3pt, right: 22.65pt, top: 22.65pt, bottom: 26.9pt))
#let wanted(info) = info.campus == "shenzhen" and info.degree-level == "doctor" and info.stage == "interim"
#let frame-active = state("iota-hit-shenzhen-doctor-interim-frame", false)
#let header-format = state("iota-hit-shenzhen-doctor-interim-header", none)
#let body-style = (
  // 原件为 1.5 倍；该文档的宋体单倍取 Word 实测 15.6pt（见文档级字体 profile）。
  asian-font: "songti", size: 12pt, line-spacing: 1.5,
  snap-to-grid: false, first-line-indent: 0pt, justify: false,
)

// Word 导出的正文第3—5页与原始 RTF 的实际行高：标题格／内容格，内容垂直居中。
#let _body-rows = (
  (head: 31.35pt, body: 309pt, indent: 1pt, gap: 0pt, new-page: false),
  (head: 35.05pt, body: 397pt, indent: 1pt, gap: 0pt, new-page: false),
  (head: 28.3pt, body: 405pt, indent: 1pt, gap: 18pt, new-page: true),
  (head: 28.3pt, body: 325pt, indent: 7pt, gap: 0pt, new-page: false),
  (head: 28.3pt, body: 741pt, indent: 1pt, gap: 0pt, new-page: true),
)
#let _flat(c) = if c == none { () } else if type(c) == content and c.func() == [].func() {
  c.children.map(_flat).flatten()
} else { (c,) }
#let _heading(c) = {
  if c.func() == heading { return c }
  if c.has("styles") and c.has("child") { return _heading(c.child) }
  none
}
#let _trim(parts) = {
  let blank(c) = c.func() in (parbreak, [ ].func()) or (c.func() == text and c.text == "")
  let a = 0
  let b = parts.len()
  while a < b and blank(parts.at(a)) { a += 1 }
  while b > a and blank(parts.at(b - 1)) { b -= 1 }
  parts.slice(a, b).join()
}

#let _page-start(lay) = {
  enter(size: 1pt, font: "serif", line-spacing: 1, snap: false, layout: lay)
  v(0.5pt)
}
#let _page-offset(lay) = enter-height(1pt, font: "serif", line-spacing: 1, snap: false, layout: lay) + 0.5pt
#let _head-style(row) = styles.current-styles().at("heading-1") + (
  above: 0pt, below: 0pt, first-line-indent: row.indent,
)
#let _plain-head(item, continued: false) = paragraph({
  item.number
  h(item.row.gap)
  title-of(item.native.body, doc-lang.get())
  if continued { if doc-lang.get() == "en" { [ (continued)] } else { [（续）] } }
}, _head-style(item.row))
#let _head(item, w) = {
  header-format.update(item.row)
  block(width: w, height: item.row.head, inset: (x: inset, y: 0pt), stroke: rule + black,
    above: 0pt, below: 0pt, sticky: true, breakable: false,
    align(horizon, block(width: 100%, item.head)))
  header-format.update(none)
}
#let _whole(item, height, w) = pad(left: -inset, right: -inset, {
  // 内容格不可拆，标题 sticky 随正文移动；避免再包一个需预布局的不可拆容器。
  _head(item, w)
  block(width: w, height: height, inset: inset, stroke: rule + black,
    above: 0pt, below: 0pt, breakable: false,
    align(horizon, block(width: 100%, item.content)))
})
#let _flow(item, w) = pad(left: -inset, right: -inset, {
  let page-key = (iota-interim-flow-page: item.index)
  let number-key = (iota-interim-flow-number: item.index)
  grid(columns: (w,), rows: (item.row.head, auto), inset: 0pt, stroke: rule + black,
    grid.header({
      metadata(page-key)
      context {
        let pages = query(metadata.where(value: page-key))
        let first = pages.len() == 0 or here().page() == pages.first().location().page()
        header-format.update(item.row)
        block(width: 100%, height: item.row.head, inset: (x: inset, y: 0pt), above: 0pt, below: 0pt,
          align(horizon, block(width: 100%, {
            if first {
              item.head
              metadata(number-key)
            } else {
              let marker = query(metadata.where(value: number-key))
              let item = if marker.len() == 0 { item } else {
                item + (number: numbering(heading.numbering, ..counter(heading).at(marker.first().location())))
              }
              _plain-head(item, continued: true)
            }
          })))
        header-format.update(none)
      }
    }),
    grid.cell(inset: inset, breakable: true, item.content),
  )
})

#let _planned(whole, ends, lay, w, room, calibrated: false, open-last: false) = {
  let capacity = lay.text-height - _page-offset(lay)
  let start = 0
  for (p, end) in ends.enumerate() {
    if p > 0 {
      pagebreak(weak: true)
      _page-start(lay)
    }
    let group = whole.slice(start, end)
    let heads = group.map(item => item.row.head).sum()
    let minima = group.map(item => item.minimum - item.row.head)
    let available = if p == 0 { room } else { capacity }
    let budget = if calibrated {
      calc.min(available, calc.max(heads + minima.sum(), group.map(item => item.row.head + item.row.body).sum()))
    } else { available }
    // 长栏前的末页不填空白，让长栏从实际余量开始，而不是人为增加一页。
    let open = open-last and end == whole.len()
    let preferred = if calibrated { group.map(item => item.row.body) } else {
      ((budget - heads) / group.len(),) * group.len()
    }
    let heights = if open { minima } else { planning.distribute(minima, preferred, budget - heads) }
    for (item, height) in group.zip(heights) { _whole(item, height, w) }
    start = end
  }
}

// 顺序分页：页数不低于原表“两栏一页”的普通页数，再求可行的最少页数。
// 多页长栏交给原生 grid 分页；之后读取真实剩余高度，重新规划后续栏目。
#let _adaptive(items, lay, w, origin, target, total) = context {
  if items.len() == 0 { return }
  let capacity = lay.text-height - _page-offset(lay)
  let long = items.position(item => item.minimum > capacity)
  if long == 0 {
    return {
      _flow(items.first(), w)
      _adaptive(items.slice(1), lay, w, origin, target, total)
    }
  }
  let room = calc.min(capacity, lay.paper-height - lay.margin.bottom - here().position().y)
  if items.first().minimum > room {
    return {
      pagebreak(weak: true)
      _page-start(lay)
      _adaptive(items, lay, w, origin, target, total)
    }
  }
  let whole = if long == none { items } else { items.slice(0, long) }
  let used = here().page() - origin.page()
  let minimum-pages = if long == none { calc.max(1, target - used) } else {
    if used >= target { 1 } else { int(calc.ceil(whole.len() / 2)) }
  }
  let ends = planning.partition(whole.map(item => item.minimum), capacity,
    first: room, min-pages: minimum-pages)
  assert(ends != none, message: "doctor-interim: no feasible page allocation")
  _planned(whole, ends, lay, w, room, calibrated: total == 5 and items.len() == 5 and ends == (2, 4, 5), open-last: long != none)
  if long != none { _adaptive(items.slice(long), lay, w, origin, target, total) }
}

// 无可拆分标题时保留普通正文流；必须在 body 前定义，供空正文／仅评议情形调用。
#let framed(doc) = context {
  let lay = page-setup-state.get()
  let w = calc.min(width, lay.text-width + 2 * inset)
  set page(background: place(top + left,
    dx: lay.margin.left - inset, dy: lay.margin.top,
    rect(width: w, height: lay.text-height, stroke: rule + black),
  ))
  frame-active.update(true)
  doc
  frame-active.update(false)
}

#let body(doc) = context {
  let nodes = _flat(doc)
  let sections = ()
  let current = none
  let prefix = ()
  let tail = ()
  let ended = false
  let top-level = heading-top.get()
  for c in nodes {
    if c.func() == metadata and type(c.value) == dictionary and c.value.at("iota-defense-start", default: false) {
      ended = true
    }
    if ended { tail.push(c); continue }
    let h = _heading(c)
    let level = if h == none { none } else {
      let l = h.at("level", default: auto)
      if l == auto { h.at("depth", default: 1) } else { l }
    }
    if level == top-level {
      if current != none { sections.push(current) }
      current = (head: c, body: ())
    } else if current == none { prefix.push(c) } else {
      current.body.push(c)
    }
  }
  if current != none { sections.push(current) }
  // 被 context 或自定义 show 隐藏的结构不强行拆解，保留完整正文流。
  if sections.len() == 0 { return framed(doc) }
  let lay = page-setup-state.get()
  let w = calc.min(width, lay.text-width + 2 * inset)
  set page(background: none)
  set text(cjk-latin-spacing: none)
  _trim(prefix)
  let items = sections.enumerate().map(((i, section)) => {
    let row = _body-rows.at(i, default: (head: row-height, body: 0pt, indent: 1pt, gap: 0pt))
    let content = _trim(section.body)
    let natural = measure(block(width: w - 2 * inset, content)).height
    let item = (index: i, number: [#(i + 1)．], native: _heading(section.head), head: section.head,
      row: row, content: content)
    let height = measure(block(width: w - 2 * inset, _plain-head(item))).height
    let row = row + (head: calc.max(row.head, height))
    let capacity = lay.text-height - _page-offset(lay)
    if row.head + natural + 2 * inset > capacity {
      // “（续）”可能多折一行；第一页和续页统一使用能容纳两种标题的格高。
      let continuation = measure(block(width: w - 2 * inset, _plain-head(item + (row: row), continued: true))).height
      row.head = calc.max(row.head, continuation)
    }
    let first-line = measure(block(width: w - 2 * inset, paragraph([字], styles.current-styles().body))).height
    if row.head + calc.min(natural, first-line) + 2 * inset > capacity {
      panic("doctor-interim: section " + str(i + 1) + " heading is taller than a page; shorten the heading")
    }
    for part in _flat(content) {
      let visual = if part.func() == figure { part.body } else { part }
      let fixed = (visual.func() in (image, box, rect, circle, ellipse, polygon)
        or (visual.func() == block and visual.at("breakable", default: true) == false))
      if fixed and measure(block(width: w - 2 * inset, part)).height + row.head + 2 * inset > capacity + 0.001pt {
        panic("doctor-interim: section " + str(i + 1) + " contains an unbreakable object taller than a form page; reduce its height or split it")
      }
    }
    item + (row: row, minimum: row.head + calc.max(0pt, natural) + 2 * inset)
  })
  let original = (items.len() == 5
    and items.all(item => item.minimum <= item.row.head + item.row.body
      and item.row.head == _body-rows.at(item.index).head)
    and (0, 2, 4).all(i => _body-rows.slice(i, calc.min(i + 2, 5)).map(r => r.head + r.body).sum() <= lay.text-height - _page-offset(lay)))
  if original {
    // 常规五栏直接保留原件；无需让已知固定布局依赖下一轮的位置查询。
    for item in items {
      if item.row.new-page { pagebreak(weak: true) }
      if item.index == 0 or item.row.new-page { _page-start(lay) }
      _whole(item, item.row.body, w)
    }
  } else if (items.all(item => item.minimum <= lay.text-height - _page-offset(lay))
    and measure(block(width: w - 2 * inset, _trim(prefix))).height == 0pt) {
    // 完整栏目可在当前新节的纸面上直接规划，不依赖目录页码和 here() 的相互回算。
    let capacity = lay.text-height - _page-offset(lay)
    let ends = planning.partition(items.map(item => item.minimum), capacity)
    _page-start(lay)
    _planned(items, ends, lay, w, capacity, calibrated: items.len() == 5 and ends == (2, 4, 5))
  } else {
    _page-start(lay)
    context {
      _adaptive(items, lay, w, here(), int(calc.ceil(items.len() / 2)), items.len())
    }
  }
  _trim(tail)
}

#let divider() = context block(width: 100%, height: 0pt, above: 0pt, below: 0pt,
  place(top + left, dx: -inset,
    line(length: calc.min(width, page-setup-state.get().text-width + 2 * inset), stroke: rule + black)),
)

#let cover(info, lang: "zh", title: auto, overrides: (:), layout: auto, warning: auto) = context {
  let t = term-table(lang, "cover", overrides: overrides)
  let variant = variant-of(info)
  let pick(key) = term-for(t, key, variant)
  let w = calc.min(width, layout.text-width)
  set page(
    width: layout.paper-width, height: layout.paper-height, margin: layout.margin,
    header: none, footer: none, background: none,
  )
  set text(lang: lang, region: "cn")
  set par(leading: 0pt, spacing: 0pt, first-line-indent: 0pt, justify: false)
  let field-style = (
    asian-font: "songti", size: 14pt, line-spacing: (exactly: 16.5pt),
    snap-to-grid: false, first-line-indent: 0pt,
  )
  // 原始 RTF 的填写值含西文数字也显式用 f13（宋体），标签的 b 独立于填写值。
  let fonts = d.fonts.fontset-state.get()
  let value-style = field-style + (if lang == "zh" {
    (font: core.fonts.profile(fonts.families.songti, metrics: fonts.metrics.songti,
      latin: fonts.families.songti, latin-metrics: fonts.metrics.songti))
  } else { (:) })
  // 行级 trgaph10 覆盖 Normal Table 的 108 缇留白；Word 导出证实为 0.5pt。
  let cell-inset = 0.5pt
  let as-field(body, label: false, indent: 1pt) = {
    let style = if label { field-style + (weight: "bold") } else { value-style }
    show: styles.rules.with(style, layout: layout, set-font: true)
    pad(left: indent, body)
  }
  // 原表左侧空列 1872 缇，标签 3401 缇，填写区 4252 缇。列界固定，标点计入标签列。
  let left = 93.6pt
  let label-column = 170.05pt
  let value-column = 212.6pt
  let labels = ("author", "enrollment", "title", "specialty", "date", "supervisor")
  let values = (
    grid(columns: (99.2pt, 1fr), value-of(info, "student-id", lang: lang), value-of(info, "author", lang: lang)),
    dates.entry(info.date, "period.start", lang: lang),
    if title == auto { value-of(info, "title", lang: lang) } else { title },
    value-of(info, "specialty", lang: lang),
    dates.entry(info.date, "interim", lang: lang),
    value-of(info, "supervisor", lang: lang),
  )
  let cells = ()
  let heights = ()
  for (key, value) in labels.zip(values) {
    let label = pick(key)
    // 首行研究生标签 li80=4pt，其余标签和值沿用 li20=1pt。
    let indent = if key == "author" { 4pt } else { 1pt }
    let height = calc.max(34pt,
      measure(block(width: value-column - 2 * cell-inset, as-field(value))).height + rule,
      measure(block(width: label-column - 2 * cell-inset, as-field(label, label: true, indent: indent))).height + rule,
    )
    heights.push(height)
    let cell(body, label: false, indent: 1pt) = grid.cell(
      inset: (x: cell-inset, y: 0pt), stroke: (bottom: rule + black), align: std.left + horizon,
      as-field(body, label: label, indent: indent),
    )
    cells += (cell(text(spacing: 0.5em, label), label: true, indent: indent), cell(value))
  }
  let body = block(width: w, {
    // 原件在首张表之前还有一个 Times New Roman 1pt 空段。
    enter(size: 1pt, font: "serif", line-spacing: 1, snap: false, layout: layout)
    v(90.7pt)
    let head = (
      asian-font: "songti", size: 22pt, weight: "bold", line-spacing: (exactly: 25.5pt),
      snap-to-grid: false, align: center, first-line-indent: 0pt, left-indent: 1pt,
    )
    block(height: 34pt, pad(x: cell-inset, align(horizon, paragraph(pick("university") + sym.zws, head, layout: layout))))
    block(height: 25.5pt, pad(x: cell-inset, paragraph(document-type-of(t, lang, variant), head, layout: layout)))
    v(113.35pt)
    v(0.5pt) // 原表空白行的白色边框；Word 封面 PDF 的信息栏起点据此复核。
    pad(left: left, grid(columns: (label-column, value-column), rows: heights, ..cells))
  })
  if warning != false and measure(body).height > layout.text-height {
    set page(foreground: overflow-note(pick("warning-overflow"), pick("warning-false"), lang: lang))
    body
  } else { body }
}
