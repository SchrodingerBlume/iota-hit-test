#import "../../terms/lookup.typ": term-for
#let stage-word(t, variant) = if "stage-" + variant.stage in t {
  term-for(t, "stage", variant)
} else { none }
#let report-title(t, lang, info, variant) = {
  let degree-level = term-for(t, "degree", variant)
  let document-type = term-for(t, "document-type", variant)
  term-for(t, "report-title", variant)(
    degree-level, document-type, stage-word(t, variant),
  )
}
