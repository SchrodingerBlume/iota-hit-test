#import "../../terms/lookup.typ": term-for, term-table, has-term, document-type-of
#let stage-word(t, variant) = if has-term(t, "stage", variant) {
  term-for(t, "stage", variant)
} else { none }
#let document-type(t, lang, variant) = document-type-of(t, lang, variant, base-terms: term-table(lang, "base"))
