#import "../heading/heading.typ": term-page

#let resume = term-page("resume")
