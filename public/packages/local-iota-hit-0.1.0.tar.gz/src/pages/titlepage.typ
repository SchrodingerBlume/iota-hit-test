// 学位论文内封（扉页，封面二）。
//
// 照 Word 范例的段落序列排——本科取「1-8 页+规范章补全+中英摘要 本科毕业论文
// 书写范例（理工类）.docx」的第三页。结构与取值全部从 docx 的 w:pPr / w:rPr /
// w:tbl 读出来，行高位置在 Word 排出来的 PDF 上逐条量过。
//
//   项    内容              字号   行距        贴格   备注
//   45    密级              小四   单倍        贴     首行缩进 13 字
//   46    空段              继承   单倍        不贴
//   47–48 空段 ×2           继承   单倍        贴
//   49    本科毕业论文       小二   单倍        不贴   *加粗*
//   50–51 批注 ×2
//   52    中文题目          二号   单倍        贴     黑体，*不加粗*
//   53–54 批注 ×2
//   55–57 空段 ×3           二号   *固定 39pt*
//   59    字段表            四号   1.5 倍       贴     7 行 3 列
//
// *与封面一的两处不同。* 一是「本科毕业论文」这里是小二加粗（封面一是
// 小一）；二是中间那三个空段用的是*固定行距*（w:lineRule="exact"），
// 不是倍数——固定行距下行高就是那个数，与字体字号无关。
//
// *没有复刻的：* 第 57 项里挂着一个浮动文本框（wp:anchor + txbxContent），
// 装的是「冒号左侧用黑体4号字…」那条批注。它是批注，真扉页上没有；而且浮动
// 定位与文字环绕不属于这一层要解决的问题。annotated 只复刻普通段落的批注。

#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing
#import banshi.fonts: zihao
#import banshi.units: twips
#import banshi.runs: has-cjk
#import banshi.content: plain-text
#import banshi.styles as style-rules
#import banshi.layout: halfspace
#import banshi.paragraph: paragraph-mark as enter
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": standalone-layout
#import banshi.styles: paragraph, overflow-note
#import "../axes.typ": axes
#import banshi.errors as _errors
#import "../terms/lookup.typ": static-terms, term-for, variant-of
#import "../terms/date.typ" as _date
#import "../info.typ": info-defaults, value-of

// 表格列宽写磅。出处是 docx 的 w:gridCol 1806 / 301 / 2951 缇（合计 5058 缇 =
// 252.9pt），整表居中——版心 425.2，左缘落在 85.05 + (425.2−252.9)/2 = 171.2，
// 与 Word 排出来的第一列首字 x=171.3 对得上。
#let _field-columns = (90.3pt, 15.05pt, 147.55pt)

// 分散对齐。Word 的 w:jc="_distribute" 把一格里的字均匀铺满整格宽：首字贴左缘、
// 末字贴右缘，字与字之间等距。实测「本科生」三个字落在 171.3 / 209.1 / 247.1，
// 末字右缘 261.1 正是第一列的右边界。
//
// Typst 没有这个对齐方式，用 1fr 的间距铺出来是同一回事。
//
// *只有纯文字才铺得开*，理由与 src/heading/spread.typ 的 spread-heading 一样
// ——拆不开就居中排（用户自定义的字段标签可能带样式或空格，那是 sequence）
#let _distribute(body) = context {
  let s = if type(body) == str { body } else { plain-text(body) }
  if s == none { return align(center, body) }
  let cs = s.clusters()
  if cs.len() <= 1 { return align(center, body) }
  stack(dir: ltr, spacing: 1fr, ..cs)
}

// 字段表的*行表*：每行说「哪个字段排在第几行」。
//
// *三层分开。* 标签的字在 src/terms/built-in.typ、值在 src/info.typ、
// 排哪几行按什么顺序在这里。要把「本科生」改成「作者」，改的是词条一条：
// overrides: (titlepage-author-bachelor: [作者])；要换姓名，改的是
// info(author: …)；要增删行或换顺序，才动 fields 参数。先前这三样揉成一张
// (标签, 值) 的表，改一个字得把七行整份重打。
//
// *一行就是一个字段名。* 两张表用同一套键名，标签与值各查各的表，所以
// 写一个 speciality 就够了。本科印「专业」研究生印「学科」是词条那边按学位轴
// 分的档，行表不必知道，见 src/axes.typ——先前那个
// (term: "discipline", info: "speciality") 是标签与数据不同名留下的映射，
// 键名统一之后就没有了。
//
// 行的三种写法：
//
//   "student-id"                        词条 student-id 配 info.student-id
//   (term: "speciality", tracking: -0.4pt)  要额外排版参数时写成字典；
//                                       数据另有出处时再写 info:
//   (label: [自定义], value: [随便])       完全自己给，可另带 line-spacing / tracking
//
// line-spacing 是值那一格的*固定行距*（磅），tracking 是值那一格的字符间距，
// 两个都只对英文那张表起作用：中文那张表的行距是本档的 1.5 倍贴格，不逐行改。
#let _bachelor-rows = (
  "author",
  "student-id",
  "supervisor",
  "speciality",
  "affiliation",
  "defense-date",
  "institution",
)

// 研究生。与本科差的是多一行「申请学位」、少一行「学号」，其余同名不同字
#let _graduate-rows = (
  "author",
  "supervisor",
  // 「无副导师的研究生不列此项」「无行业导师不列此项」——值是 none 的行
  // *整行不排*，见下面 _drop-empty。本科那张表没有这两行
  "co-supervisor",
  "industry-supervisor",
  "degree-applied",
  "speciality",
  "affiliation",
  "defense-date",
  "institution",
)

// 把一行折成字典 (label:, value:, line-spacing:, tracking:)——渲染那一段收的
// 就是这个形状。后两个键没写就是 none，渲染那头按键取，各自回默认。
//
// *按键不按位置。* 先前折成 (标签, 值, [固定行距], [字距]) 的元组，后两项有
// 哪个写哪个——只写 tracking 不写 line-spacing 的行，tracking 就顶到了行距那个
// 位置上，−0.4pt 成了固定行距，值格整个塌掉，还不报错。
//
// *variant 是这一页处在哪几档*，眼下只有学位一档，词条按它挑后缀。
//
// *lang 干两件事*：挑 info 里的哪一份（英文内封读 -en 那些），以及日期
// 照哪种语言排。语言与字段身份是两回事，所以在这一层统一贴，行表里不必逐行
// 写 author-en。
//
// *-en 那份写 auto 就回落到原值*——答辩日期只存一个 ISO，中英各自排，
// 不必存两遍；用户想手写一份英文的，照旧写 defense-date-en 即可。
#let _resolve-row(row, terms, info, variant, lang: "zh") = {
  // 取值走共用的那一支（src/info.typ 的 value-of）：按语言挑 info 的
  // 哪一份、日期走解析。报告首页那张行表用的是同一支
  let resolved(name) = value-of(info, name, lang: lang)
  let paired(term-name, info-name) = (
    label: [#term-for(terms, term-name, variant)],
    value: [#resolved(info-name)],
  )
  let extras = (line-spacing: none, tracking: none)
  if type(row) == str { return paired(row, row) + extras }
  // (标签, 值) 的二元组，与写 (label:, value:) 同义
  if type(row) == array {
    if row.len() != 2 { panic("expected (label, value), found " + repr(row)) }
    return (label: row.at(0), value: row.at(1)) + extras
  }
  if type(row) == dictionary {
    for k in row.keys() {
      if k not in ("term", "info", "label", "value", "line-spacing", "tracking") {
        panic("unexpected key \"" + k + "\" in titlepage row " + repr(row))
      }
    }
    let extras = (
      line-spacing: row.at("line-spacing", default: none),
      tracking: row.at("tracking", default: none),
    )
    if "label" in row {
      return (label: [#row.label], value: [#row.at("value", default: [])]) + extras
    }
    return paired(row.term, row.at("info", default: row.term)) + extras
  }
  panic("expected string, array, or dictionary, found " + str(type(row)))
}

// 值空着的行整行丢掉——「无副导师的研究生不列此项」（指南 3.3.2 那张表的括注）。
//
// *判的是解好的值，不是字段名。* 规范只对副导师与行业导师写了这句话，
// 但「没值就没这一行」对哪一行都成立，而且用户自己写 fields: 加的行也吃得到
// 这一条；反过来按名字硬编码那两个，用户换个字段名就漏了。
//
// 空的定义只有 none 与空内容两种：[] 是「写了但空着」，与没写同义。写了空格
// 的（[ ]）不算空——那是用户*有意*留白的一行。
#let _drop-empty(rows) = rows.filter(row => row.value != none and row.value != [])

// 内封第一行左边那两个选项框，轮廓与深圳本科报告首页那一行共用，
// 见 src/pages/checkbox.typ
#import "./checkbox.typ": checkbox as _checkbox, checkbox-advance

#let titlepage(
  degree-level: "doctor",
  // 标签那一行，宋体小二号加粗。auto 按学位取
  label: auto,
  // 中文题目，黑体二号，不加粗
  title: [局部多孔质气体静压轴承关键技术的研究],
  // 本地化词条表与元信息。默认那两份是静态的；用户的由 frontpages 那一层传进来
  terms: static-terms("zh", "titlepage"),
  info: info-defaults,
  // 交的是哪一种东西，见 src/axes.typ 的 form。本科这一档只改第一行
  // 勾哪个框；硕博那一档换的是通篇的字，由词条表管
  form: "dissertation",
  // 副题目。「当有副题目时，格式同封面」（指南 3.3.2 末句），所以排法与
  // src/pages/report/cover.typ 那一处逐条相同；none ＝ 没有
  subtitle: none,
  // 密级。规范给的是「公开」
  secrecy: [公开],
  // 研究生表头上另外三格。本科那一页没有这一档，只有密级。
  classified-index: [××××],
  udc: [××××],
  school-code: [××××],
  // 字段表，(标签, 内容) 的有序表。标签走黑体四号分散对齐，内容走宋体四号
  fields: auto,
  // 这一页的页面设置。auto ＝ 本档默认加内封差额（行距 19.75、不出页眉页脚）；
  // 用户那条路由 src/pages/front.typ 在 context 里并好文档＋段那一份再传进来，理由
  // 同 src/pages/cover.typ
  layout: auto,
  // 排不下时在纸角发一条红字提示，与封面同一条，见 banshi/src/styles/parts.typ。
  // auto ＝ 不写 ＝ 发：排不下是真出了事，默认该说一声
  warning: auto,
  // 排成范例那一页的样子（带批注），对拍用。见 src/pages/report/cover.typ
  annotated: false,
) = {
  let warning = warning != false
  assert(
    degree-level in axes.degree-level,
    message: _errors.expected-one-of(axes.degree-level, degree-level),
  )
  // 递全部的轴（src/terms/lookup.typ 的 variant-of），这一页参数里的学位与文种压过 info 的
  let variant = variant-of(info) + (degree-level: degree-level, form: form)
  let label = if label == auto {
    term-for(terms, "document-type", variant)
  } else { label }
  let rows = if fields != auto {
    fields
  } else if degree-level == "bachelor" {
    _bachelor-rows
  } else {
    _graduate-rows
  }
  let fields = _drop-empty(rows.map(row => _resolve-row(row, terms, info, variant)))

  let layout = if layout == auto { standalone-layout("titlepage") } else { layout }
  // 引擎画字符网格那一档：这一页的 set par(linebreaks:)（没给 --input linebreaks 就什么都不发），见 banshi/src/layout/resolve.typ
  show: linebreaks-sets.with(layout)
  // 页眉页脚按 layout 那两条记录的 shown 定：内封差额写的是 false（指南 3.4）
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin,
    ..(if layout.header.shown == false { (header: none) } else { (:) }),
    ..(if layout.footer.shown == false { (footer: none) } else { (:) }),
  )
  // 这一节的 Normal 是 sz24，小四 12pt。空段的高按 ¶ 的字号算，
  // ¶ 没写字号时继承 Normal，所以基准字号要在这里设。
  set text(size: zihao.xiaosi, lang: "zh", region: "cn")
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)

  // 批注段：关掉时行留着、只是字没了，与封面一同一个约定。
  //
  // *这一页的批注段各不相同*，不像封面一那样清一色。第 50、53、54 段
  // *贴行网格*（单倍行高 15.5625 装不下一格，占满一格 19.75），
  // 第 51 段不贴格但走 1.25 倍（19.45）。差别虽小，四段累起来就是 11pt。
  let note(body, snap: false, line-spacing: 1, both: none) = {
    let style = (
      size: zihao.xiaosi, font-zh: "songti", line-spacing: line-spacing,
      snap-to-docgrid: snap,
    )
    if annotated and both != none {
      // 研究生表头那两条批注是左右各一个。*左右不同句*——左列注的是
      // 分类号与 UDC，右列注的是学校代码与密级，各写各的参数名。
      block(width: 100%, {
        show: style-rules.rules.with(style, layout: layout, set-font: true)
        show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
        body
        h(1fr)
        both
      })
    } else if annotated {
      paragraph(
        {
          show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
          body
        },
        (font: "songti", size: zihao.xiaosi, line-spacing: line-spacing, snap-to-docgrid: snap, align: center),
        layout: layout,
      )
    } else {
      context block(height: spacing(style, layout: layout).line-height, spacing: 0pt, [])
    }
  }

  // 密级那一行。首行缩进 13 字（w:ind firstLineChars="1300"，存盘时折成
  // firstLine=3238 缇 = 161.9pt，正是 13 × 12.4543 一格），*贴行网格*。
  //
  // 范例那一页上，缩进之后先是「（宋体小4号字）」这条批注，再隔十个空格才是
  // 「密级：公开」——所以它落在 x=409.2，不是版心右缘。真扉页上批注没了，
  // 剩下的靠什么定位规范没说；hithesis 是 \hfill 顶到右缘（hit-thesis.cls:6959），
  // 我们跟它。
  // 一行左右各一格的表头。左边贴版心左缘、右边贴右缘。
  //
  // *Word 那边是拿字面空格撑开的*（第 48 段 28 个、第 49 段 32 个），
  // 排版的人一个个敲出来的——学校代码落在 x=409.7、密级落在 433.2，纯粹是
  // 空格数的结果，换个值就散。hithesis 是左右两块加 \hfill 顶开
  // （hit-thesis.cls:7000），我们跟它：右边一律顶到版心右缘。
  // 代价是右侧几格的 x 与范例差几个磅，纵向基线不受影响。
  // 表头一行：左边一格、右边一格顶到右缘。
  //
  // *两格各占半幅，不是一段里塞个 h(1fr)。* 先前是后者，短值时看不出
  // 分别（左顶左缘、右顶右缘，与范例逐条对得上），值一长就露馅：h(1fr) 是
  // 「把右边那截推到行尾」，推不下也照推——实测密级写「内部（保密期至 2030 年
  // 6 月）」时右缘量到 516.2，*冲出版心 6pt*；学校代码写长了则折到下一行的
  // *左*边距去，与它自己那一格对不上。
  //
  // 两格各半幅之后，长值在自己那半幅里折行，一格也不越界。短值那一档排出来
  // 一点不动：左格左对齐从 85.05 起、右格右对齐到 510.20 止，正是先前的落点。
  let head-line(left, right, snap: false, line-spacing: 1) = {
    block(width: 100%, {
      show: style-rules.rules.with(
        (
          size: zihao.xiaosi, font-zh: "songti", line-spacing: line-spacing,
          snap-to-docgrid: snap,
        ),
        layout: layout,
        set-font: true,
      )
      grid(
        columns: (1fr, 1fr),
        std.align(std.left, left),
        std.align(std.right, right),
      )
    })
  }

  // 表头那一段（本科一行、研究生两行）。与 head 一样收成内容，好一起量
  let masthead = if degree-level == "bachelor" {
    // 本科只有密级一格。
    //
    // *缩进要直接给 par，不能靠 set。* Typst 0.15.1 里 first-line-indent
    // 对 block *内*的段落不生效，连 all: true 也不行（实测：顶层 set 缩进
    // 47.36，同样的 set 挪进 block 就退回 10.00，而 #par(first-line-indent: …)
    // 照样缩）。style-rules.rules 里那句 set par 因此在这一档是空转的。
    // 上游哪天改了，这里可以退回 set。
    context {
      let style = (
        size: zihao.xiaosi, font-zh: "songti",
        snap-to-docgrid: true,
      )
      let halfspace = (n) => halfspace(n, layout)
      // 左边两个选项：☐毕业论文␣␣☐毕业设计。design 决定勾哪个
      let options = {
        _checkbox(form != "practice")
        terms.form-bachelor-dissertation
        halfspace(2)
        _checkbox(form == "practice")
        terms.form-bachelor-practice
      }
      // *批注挂到版心外，行本身两档一个样。* Word 那一页是把批注塞在行
      // *里*的——选项 → 十个空格 → 批注 → 十个空格 → 密级（实测
      // 218.58 → 281.38 与 380.65 → 443.45 都是 62.80，正是 10 × (6 + 0.227)）。
      // 那是给「（宋体小4号字）」留的位置：量下来行尾到版心右缘只剩 6.78，写得下
      // 八个全角，写不下*一条*带参数名的批注（试过的都折行）。而这一行有
      // *两*样要注——勾选框由 form 定、密级由 secrecy 定——一条也塞不下。
      //
      // 所以两条都从上面指下来，挂在天头里；行本身回到真内封那个排法（密级顶
      // 右缘，跟 hithesis）。place 不占位，行的站位与基线一点不动。
      //
      // *挂出去那一条是两行*：参数名一行、箭头单占一行，与版心里那几条 ↑
      // 同款（箭头自己一行，指着紧邻的那一行）。不占位，两行也不用付代价。
      if annotated {
        // *挂出去的这两行不贴行网格*：贴格的行高 19.75 比字身高出一截，
        // 箭头与它所指的那一行之间就空得太远。不占位，也没有对齐网格的义务。
        let hung = (size: zihao.xiaosi, font-zh: "songti")
        let row(l, r) = block(width: 100%, spacing: 0pt, {
          show: style-rules.rules.with(hung, layout: layout, set-font: true)
          show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
          l
          h(1fr)
          r
        })
        place(top, dy: -1 * spacing(hung, layout: layout).line-height, {
          row([`form:`], [`secrecy:`])
          row([↓], [↓])
        })
      }
      block(width: 100%, {
        show: style-rules.rules.with(style, layout: layout, set-font: true)
        options
        box(width: 1fr)
        [#terms.secrecy：#secrecy]
      })
    }

    // 第 46 段不贴格（snapToGrid=0），第 47、48 段贴格——三个空段高不一样：
    // 13.80 / 19.75 / 19.75。¶ 都是继承来的 Times 小四。
    //
    // 贴格的空段不能用 paragraph 发：那是排一行字的，空内容排不出行，块会塌成
    // 零高。直接按算出来的行高发一个定高块。
    enter(size: zihao.xiaosi, line-spacing: 1)
    context {
      let h = spacing(
        (size: zihao.xiaosi, font-zh: "latin", font: "serif", snap-to-docgrid: true),
        layout: layout,
      ).line-height
      for _ in range(2) { block(height: h, spacing: 0pt, []) }
    }
  } else {
    // 研究生的表头是两行四格：左列两个图书分类号，右列学校代码与密级。
    // 第 48 段单倍、第 49 段 1.25 倍，两段都不贴格。
    // *第一行那两格的批注挂到版心外。* 表头是两行四格，而版心里只放得下
    // *一*条批注行——下面那条 ↑ 指的是第二行（UDC 与密级），第一行的分类号
    // 与学校代码只能*从上面指下来*。表头上方就是天头，这一页 header: none，
    // 空着。
    //
    // *place 不占位*，所以表头一动不动——批注是排版的一部分，站位不能变。
    // 代价是判据要按「在不在版心内」筛基线，见 tests/check-titlepage-graduate.py。
    // *这一块先前没受 annotated 管*：每一份研究生内封的天头里都印着这两行参数名与箭头
    if annotated {
      context {
        let hung = (size: zihao.xiaosi, font-zh: "songti")
        let row(l, r) = block(width: 100%, spacing: 0pt, {
          show: style-rules.rules.with(hung, layout: layout, set-font: true)
          show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
          l
          h(1fr)
          r
        })
        place(top, dy: -2 * spacing(hung, layout: layout).line-height, {
          row([`classified-index:`], [`school-code:`])
          row([↓], [↓])
        })
      }
    }
    head-line(
      [#terms.classified-index：#classified-index],
      [#terms.school-code：#school-code],
    )
    head-line(
      [#terms.udc：#udc], [#terms.secrecy：#secrecy],
      line-spacing: 1.25,
    )
    // 第 50 段贴格、第 51 段 1.25 倍不贴格，与下面那两条批注同款。
    // *这一条只管第二行*，第一行由上面挂出去的那一条管。
    note([↑], snap: true, both: [↑])
    note([（`udc:`）], line-spacing: 1.25, both: [（`secrecy:`）])
    // 第 52–54 段：三个空段，都贴格
    context {
      let h = spacing(
        (size: zihao.xiaosi, font-zh: "latin", font: "serif", snap-to-docgrid: true),
        layout: layout,
      ).line-height
      for _ in range(3) { block(height: h, spacing: 0pt, []) }
    }
  }

  // 标签那一行到副题目为止。*收成一份内容*是为了下面那一段让步——
  // 要量「全页有多高」，就得先能把这一段与空段、字段表拼起来量
  let head = {
    paragraph(label, (font: "songti", size: zihao.xiaoer, bold: true, align: center), layout: layout)
    note([↑], snap: true)
    note([（由 `degree-level: "bachelor"|"master"|"doctor"` 决定）], line-spacing: 1.25)
    // 中文题目：黑体，*不加粗*（w:rPr 里没有 w:b），贴行网格
    paragraph(
      title, (font: "heiti", size: zihao.erhao, snap-to-docgrid: true, latin-bold: true, align: center),
      layout: layout,
    )
    note([↑], snap: true)
    note([（通过 `title: []` 键入）], snap: true)
    // 副题目「格式同封面」：另起一行、小 2 号、破折号起头、比主题目退 4 个半角
    // 字符（居中位置右移 2 个汉字 ＝ 左边让出 4 个汉字）。算法与那一处同源，
    // 注释见 src/pages/report/cover.typ
    if subtitle != none {
      pad(left: 4 * zihao.xiaoer, paragraph(
        [——] + subtitle,
        (font: "heiti", size: zihao.xiaoer, latin-bold: true, align: center), layout: layout,
      ))
    }
  }

  // 第 55–57 段：固定行距 39pt（w:line="780" lineRule="exact"）。固定行距下行高
  // 就是那个数，与 ¶ 的字体字号无关——这是 Word「固定值」与「多倍」的根本区别。
  let blanks(n) = for _ in range(n) { block(height: 39pt, spacing: 0pt, []) }

  // 字段表
  let table = context {
    let metrics = spacing(
      (
        size: zihao.sihao, font-zh: "songti", line-spacing: 1.5,
        snap-to-docgrid: true,
      ),
      layout: layout,
    )
    let cell(body, font: "songti", spread: false) = {
      show: style-rules.rules.with(
        (
          size: zihao.sihao, font-zh: font, font: font, line-spacing: 1.5,
          snap-to-docgrid: true,
        ),
        layout: layout,
        set-font: true,
      )
      // 外面那个 align(center) 是给整张表用的，会漏进格子里把内容也居中。
      // 每格自己声明对齐：标签分散、别的靠左。
      if spread { _distribute(body) } else { align(left, body) }
    }
    // *行高不写死。* 先前这里写的是 rows: metrics.line-height——一行的高，值一长
    // 折了行，第二行就压在下一行上（实测「学科」折成三行时，第二、三行与
    // 「所在单位」那一行*重叠*）。Word 那边表格行是「至少」不是「固定」，
    // 折几行就长几行。
    //
    // auto 在*一行的档上给的正是 metrics.line-height*：格子里那一段的行距、字号、
    // 贴格都由 cell 的 style-rules.rules 设好了，auto 量的就是它——所以范例那几页排出来
    // 一点不动（check-titlepage 与 check-titlepage-graduate 两组基线照旧）。
    align(center, grid(
      columns: _field-columns,
      rows: auto,
      ..fields.map(f => (
        cell(f.label, font: "heiti", spread: true),
        cell([：]),
        cell(f.value),
      )).flatten(),
    ))
  }

  // *让步：字段表多几行时，让第 55–57 段那三个空段。*
  //
  // 范例那一页是七行字段，三个空段之后正好排到版心底附近。规范允许的行数不止
  // 七行——「无副导师的研究生不列此项」反过来说就是有的人多两行（副导师、行业
  // 导师），多出来的两行会把表推到下一页去，静默排成两页的内封。
  //
  // *让的是空段，不是行距，也不是字号*——Word 里的人手上也只有这一个旋钮：
  // 题目与字段表之间那三个空行，删一个 39pt。三个让光还装不下就溢出，交给用户
  // 自己看（这一页没有 warning 那一档；真到那一步说明字段表已经十几行了）。
  //
  // 三个都用得上时排出来与先前逐字节相同——范例那一档走的就是 n ＝ 3。
  context {
    let fits(n) = measure(
      block(width: layout.text-width, masthead + head + blanks(n) + table),
    ).height <= layout.text-height
    let n = 3
    while n > 0 and not fits(n) { n -= 1 }
    // 三个空段让光还装不下：*说一声*。先前是一声不吭地流到第二页去的
    // ——实测所在单位写 62 个字就能触发，排出来的内封是两页，没有任何提示
    let body = { masthead; head; blanks(n); table }
    if warning and not fits(n) {
      set page(foreground: overflow-note(terms.warning-overflow, terms.warning-false))
      body
    } else {
      body
    }
  }
}

// ────────────────────────────────────────────────────────────────────────
// 英文内封。
//
// *只有硕士与博士有这一页。* hithesis 的 \makecover 里写着
// （hit-thesis.cls:7132）：
//
//   \bool_lazy_or:nnF { postdoc } { bachelor } { … \hit@english@cover … }
//
// 也就是「不是博士后、也不是本科」才排。所以 titlepage-en 对 bachelor 直接
// 什么都不发，调用方不必自己判断。
//
// 照 Word 范例第四页排（研究生那一份）。与中文内封的三处不同：
//
//   一、表头是两行，右边跟的是批注而不是另一个字段
//   二、字段表是 *2 列*（4262 / 4406 缇 = 213.1 / 220.3pt），合计 433.4
//       比版心还宽 8.2，Word 居中让它两边各溢出 4.1
//   三、这张表*保留了默认单元格边距*（左右各 108 缇 = 5.4pt），中文那张
//       是显式清零的——所以第一列的字落在 80.95+5.4 = 86.35（实测 86.3），
//       第二列落在 294.05+5.4 = 299.45（实测 299.6）
//
// 行距是*固定值* 22pt。范例第二列的第 4–6 行是 18pt，我们不跟，见 _graduate-rows-en。

#let _degree-attributes = (master: [Master's], doctor: [Doctoral])

// 每项是字段名或字典，字典可带值那一格的*固定行距*与*字符间距*，见上面
// _resolve-row。
//
// *范例里第 4–6 行的值是 18pt，我们排 22pt。* 范例那三行不是因为放得下放不下
// （June, 2020 很短也是 18pt），是排版的人选中一段行改的；后果是那三行的值比
// 标签*高 3.2*（固定行距的首基线在 0.8 倍行高处，0.8 × 4）——Word 出的 PDF 里
// Speciality 标签 587.9、值 584.9，就是不齐的。用户填一行日期看见基线错开，报
// 的是 bug。这不是版式规定，所以不跟：值格与标签同是 22，六行一个规则，单行的
// 行高一个不变，只有折行的那一行从 36 长到 44。tests/check-titlepage-en.py
// 那几条值基线按我们的排法钉。
//
// *第 4、5 行的值还带着 −0.2pt 的紧缩*（run 上的 <w:spacing w:val="-4"/>，
// 字体对话框「紧缩 0.2 磅」）。不缩的话 School of Mechatronics Engineering 宽
// 213.16，超过可用的 209.5 会折行；缩完 206.4，与 Word 实测的 206.5 对得上。
// 这是排版的人为了塞下一行手工加的，不是版式规定，所以做成可选项而不是默认。
//
// *写 −0.4pt，不是 −0.2pt。* 样式的 tracking 一律存汉字实排的值——Word 给
// 汉字发对话框的两份、给西文发一份（banshi/src/paragraph/latin.typ 的 latin-tracking），
// 西文这一行拿一半，正是对话框的 −0.2：h→o 步进 7.000 = 7 + 0.227 − 0.2 − 0.027。
#let _graduate-rows-en = (
  "author",
  "supervisor",
  "co-supervisor",
  "industry-supervisor",
  "degree-applied",
  "speciality",
  (term: "affiliation", tracking: -0.4pt),
  (term: "defense-date", tracking: -0.4pt),
  "institution",
)

// 2 列，写磅（w:gridCol 4262 / 4406 缇）；单元格左右边距是 Word 的默认 0.19cm
// （w:tblCellMar 108 缇，0.19 × 567 = 107.73 → 108）
#let _field-columns-en = (213.1pt, 220.3pt)
#let _cell-margin-en = twips(0.19cm)

// *只有英文内封有的那几个参数。* 一次 #titlepage() 排两页，而
// src/pages/front.typ 那层把 ..args 送给中文页；这三个中文页没有，写了会
// 撞上「unexpected argument」。列在这里，由那一层认出来转给英文页。
//
// 别的参数照旧送中文页（annotated、fields、terms 这些两页都有，但含义各是各的
// ——中文页的 terms 是 zh 那张表），要单独摆弄英文页仍走 en: 那个口子。
// 范例第四页的英文题目。*锚点靠它算*——见下面那段让步阶梯的说明。
#let sample-title-en = [RESEARCH ON KEY TECHNOLOGIES OF PARTIAL POROUS
  EXTERNALLY PRESSURIZED GAS BEARING]

#let en-only-keys = ("title-en", "title-en-xiaoer", "subtitle-en", "degree-attribute")

#let titlepage-en(
  degree-level: "doctor",
  // 「Dissertation for the … Degree」那一行。auto 按学位取 Doctoral / Master's
  degree-attribute: auto,
  // 本地化词条表与元信息，英文那一档
  terms: static-terms("en", "titlepage"),
  info: info-defaults,
  title-en: sample-title-en,
  // 英文副题目，用冒号接在主题目同一段里，见 src/pages/report/cover.typ
  subtitle-en: none,
  // 交上去的是哪一种东西，见 src/axes.typ 的 form
  form: "dissertation",
  // 英文题目用小二还是二号。*这一页的批注自己写着这条规则*——「Times New
  // Roman 2号字加粗，题目太长时可用小2号字」，与封面同一条，所以同一个开关。
  //
  //   auto   先按二号排，整页装不下才降小二
  //   true   用户主动缩
  //   false  用户强制二号，装不下宁可溢出
  //
  // 与封面那一处不同的是：这一页是固定序列，没有空行让步的阶梯，题目一长后面
  // 整体下移，所以判据就是「整页高度超没超版心」。
  title-en-xiaoer: auto,
  classified-index: [××××],
  udc: [××××],
  fields: auto,
  // 这一页的页面设置。auto ＝ 本档默认加内封差额（行距 19.75、不出页眉页脚）；
  // 用户那条路由 src/pages/front.typ 在 context 里并好文档＋段那一份再传进来，理由
  // 同 src/pages/cover.typ
  layout: auto,
  // 排不下时在纸角发一条红字提示，与封面、中文内封同一条
  warning: auto,
  annotated: false,
) = {
  let warning = warning != false
  // 本科与博士后没有英文内封
  if degree-level not in _degree-attributes { return }
  let attr = if degree-attribute == auto {
    _degree-attributes.at(degree-level)
  } else { degree-attribute }
  let rows = if fields == auto { _graduate-rows-en } else { fields }
  let fields = _drop-empty(rows.map(row =>
    _resolve-row(row, terms, info, variant-of(info) + (degree-level: degree-level, form: form), lang: "en")))

  let layout = if layout == auto { standalone-layout("titlepage") } else { layout }
  // 引擎画字符网格那一档：这一页的 set par(linebreaks:)（没给 --input linebreaks 就什么都不发），见 banshi/src/layout/resolve.typ
  show: linebreaks-sets.with(layout)
  // 页眉页脚按 layout 那两条记录的 shown 定：内封差额写的是 false（指南 3.4）
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin,
    ..(if layout.header.shown == false { (header: none) } else { (:) }),
    ..(if layout.footer.shown == false { (footer: none) } else { (:) }),
  )
  set text(size: zihao.xiaosi, lang: "en")
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)

  // 一行西文。行高按西文那一档算——*但先看这一行上真有什么字*：Word 的
  // 行高取该行实际用到的字体里最高的那个，英文内封里敲了汉字，Word 会按中易的
  // 行高撑高。判据与目录、题注那两处统一成 has-cjk（中易 1.296875 > 西文 1.15）。
  let line-en(body, size: zihao.xiaosi, bold: false, snap: false, line-spacing: 1, centered: true) = {
    let zh = has-cjk(plain-text(body))
    block(width: 100%, {
      show: style-rules.rules.with(
        (
          size: size, font-zh: if zh { "songti" } else { "latin" }, bold: bold,
          line-spacing: line-spacing,
          snap-to-docgrid: snap,
        ),
        layout: layout, set-font: true,
      )
      if centered { align(center, body) } else { body }
    })
  }
  // 空段：西文 ¶，可贴格
  let blank(snap: false, size: zihao.xiaosi) = context {
    let h = spacing(
      (size: size, font-zh: "latin", snap-to-docgrid: snap),
      layout: layout,
    ).line-height
    block(height: h, spacing: 0pt, [])
  }
  // 表头那两行：左边字段、右边批注
  let head-en(left, note-body, snap: true) = {
    block(width: 100%, {
      show: style-rules.rules.with(
        (
          size: zihao.xiaosi, font-zh: "latin",
          snap-to-docgrid: snap,
        ),
        layout: layout, set-font: true,
      )
      // *参数名走等宽，但不许它撑大行高。* 批注里 `foo:` 那种原样文本会被
      // 换成等宽字体（见 lib.typ 的 show raw），而等宽比宋体高——这两行*贴
      // 行网格*，多出来的高度会把盒子顶进下一格，底下整页跟着下移（实测 +2.2）。
      // 把它的上下缘归零，行高就仍由这一行的字定。批注是排版的一部分，站位不能变。
      //
      // *只给贴格的行发*：不贴格的那几条批注（下面的 note）本来就由字体档
      // 定行高，加这一道反而多切一道 run 边界、把行撑宽半个字，长批注会因此折行。
      show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
      left
      h(1fr)
      if annotated { note-body }
    })
  }
  // 批注行*含汉字*（「↑」也是中易字形），行高要按中易那一档算，
  // 不能跟着这一页别的西文行走 1.15——实测差 0.9，四条批注累起来就是 3.6。
  let note(body, snap: false) = {
    let style = (
      size: zihao.xiaosi, font-zh: "songti",
      snap-to-docgrid: snap,
    )
    if annotated {
      block(width: 100%, {
        show: style-rules.rules.with(style, layout: layout, set-font: true)
        align(center, body)
      })
    } else {
      context block(height: spacing(style, layout: layout).line-height, spacing: 0pt, [])
    }
  }

  // 第 65 段（空段）不在这一页上——Word 排出来第一条基线就是 Classified Index
  // 的 122.03，正是版心顶 107.75 加一个贴格行的上升部 14.28。多发一个空段
  // 会整页下移 19.75（实测过）。
  // 字段表一行的取值。*提到外面*是因为锚点要拿它的上升部反算，见下面。
  let _row-style(exact) = (
    size: zihao.sihao, font-zh: "latin",
    line-spacing: (exactly: exact),
    snap-to-docgrid: false,
  )

  // 版面的可让空段与让步阶梯。
  //
  //   表头两行            钉在页顶（第一条基线 122.03 ＝ 版心顶 + 贴格行上升部）
  //   空 3（小四贴格）     *最后*才让——表头到「Dissertation」那一段是版式
  //                       骨架，范例上 141.80 → 232.83 就是它撑出来的
  //   Dissertation 一行 + 两条批注
  //   空 1（小二贴格）     其次让
  //   *英文题目*     变长的就是它
  //   两条批注
  //   空 2（二号贴格）     *先让*——离被钉住的字段表最近
  //   *字段表*       要钉住的东西
  //
  // *先让离字段表最近的。* 与封面同一套：那边「中英题目之间」是最后的可让
  // 项，先让的是姓名、校名前面那几段。让近处的，题目块本身的呼吸留到最后。
  let blanks = (after-head: 3, before-title: 1, before-table: 2)
  // n 为正是让掉几个，为负是*补*几个——题目短的时候光减是钉不住的，得往
  // 字段表上方补，才让表落回参考位置而不是浮上去。补在离表最近那一处：只把表
  // 压下去，题目那一块留在它自己的位置上。
  let give-up(n) = {
    let rest = calc.max(0, n - blanks.before-table)
    (
      after-head: calc.max(0, blanks.after-head - calc.max(0, rest - blanks.before-title)),
      before-title: calc.max(0, blanks.before-title - rest),
      before-table: calc.max(0, blanks.before-table - n),
    )
  }
  let max-squeeze = blanks.values().sum()
  // 最多补几个。一个贴格空段 19.75，八个够把一行的短题目压回参考位置还有余
  let max-pad = 8

  // 字段表*之前*的全部内容。squeeze 是让掉的空段数。
  // 「英文则用冒号相连」——接在主题目同一段里，注释见 src/pages/report/cover.typ
  let title-en-full = if subtitle-en == none { title-en } else {
    title-en + [：] + subtitle-en
  }
  let upto-table(en-size, squeeze, title: title-en-full) = {
    let b = give-up(squeeze)
      head-en([#terms.classified-index: #classified-index], [← `classified-index:`])
      head-en([#terms.udc: #udc], [← `udc:`])
      for _ in range(b.after-head) { blank(snap: true) }

      line-en([Dissertation for the #attr Degree], size: zihao.xiaoer, snap: true)
      note[↑]
      note[（由 `degree-level:` 与 `degree-attribute:` 决定）]
      for _ in range(b.before-title) { blank(snap: true, size: zihao.xiaoer) }
        line-en(title, size: en-size, bold: true, line-spacing: 1.25)
      note[↑]
      note[（通过 `title-en: []` 键入，太长时可用 `title-en-xiaoer: true` 转为小 2 号字）]
      for _ in range(b.before-table) { blank(snap: true, size: zihao.erhao) }

  }

  // 字段表与页尾。这一段的高是固定的，不参与让步。
  let table-and-tail = {
    // 字段表
    context {
      // 网格字距照吃（西文半份）。
      //
      // *这里曾经踩过一个坑。* 量 'School of Mechatronics Engineering' 时
      // 'h→o'、'o→o'、'o→l' 的步进都是 7.000 整，看着像「表内的西文不吃字距」；
      // 可那一格的 run 上带着 <w:spacing w:val="-4"/>，也就是排版的人手工把它
      // *紧缩了 0.2pt*——半份增量 0.227 减去 0.2 净剩 0.027，才显得像零。
      // 换一格没紧缩的（Harbin Institute of Technology）量，每字形 +0.2119，
      // 半份增量原样都在。
      //
      // 那两格为什么要紧缩：不缩的话 213.16 宽，超过可用的 209.5 会折行；
      // 缩完 206.4，与 Word 实测的 206.5 对得上。
      let style = _row-style
      // 行距一律 22pt；行表里逐行写了 line-spacing 的值格按写的来
      let cell(body, bold: false, exact: 22pt, squeeze: 0pt) = block(
        width: 100%, inset: (x: _cell-margin-en),
        {
          show: style-rules.rules.with(
            style(exact) + (bold: bold, tracking: squeeze),
            layout: layout, set-font: true,
          )
          align(left, body)
        },
      )
      // 这张表比版心还宽 8.25，Word 居中让它*两边各溢出 4.125*。
      // Typst 的 align(center) 不会往版心外让，只会把它顶在左边距上——
      // 用 move 把它挪回去。move 只挪不改版面尺寸，正合适。
      let total = _field-columns-en.sum()
      move(dx: (layout.text-width - total) / 2, grid(
        columns: _field-columns-en,
        ..fields.map(f => (
          cell([#f.label：], bold: true),
          cell(
            f.value,
            exact: if f.line-spacing == none { 22pt } else { f.line-spacing },
            squeeze: if f.tracking == none { 0pt } else { f.tracking },
          ),
        )).flatten(),
      ))
    }

    blank()
    note[↑（各行取自 `author-en:` 一类的参数，没写就退到不带 -en 的）]
  }

  // *让步阶梯，与封面同一套。* 题目一长，下面整块跟着下移，字段表就离开
  // 它该在的位置；先减空段把它拉回来，空段减到无可减仍装不下，才把题目降小二。
  // 字号是阶梯的*最外层*——小二该尽量避免，这一页的批注写的也是「题目太长
  // 时*可用*小2号字」。
  //
  // *锚点不是一个数，是范例那一页的排法。* 把范例照 docx 排一遍——名义空段
  // 3/1/2、小二的题目、范例那个题目本身——量出「字段表之前该有多高」，拿它跟当前
  // 内容比：高了就减空段，矮了就补。
  //
  // *这样锚点里没有量出来的坐标*，只有 Word 界面上填得出的东西：空段数、
  // 字号、行距，以及范例那一页的题目（sample-title-en，也正是 title-en 的默认值）。
  // 先前这里写过 396.63pt（量我们自己的输出）和 521.90pt（量范例的 PDF），两个都是
  // 换一台机器、换一版模型就要重测的数。
  //
  // 显式写了 title-en-xiaoer 就只在那一个字号上让空段，不再换字号。
  context {
    let height-of-title(size, squeeze, title) = measure(
      block(width: layout.text-width, upto-table(size, squeeze, title: title)),
    ).height
    let height-of(size, squeeze) = height-of-title(size, squeeze, title-en-full)
    let sizes = if title-en-xiaoer == auto {
      (zihao.erhao, zihao.xiaoer)
    } else if title-en-xiaoer {
      (zihao.xiaoer,)
    } else {
      (zihao.erhao,)
    }
    // *取离参考位置最近的一格，上下都算。* 空段有最小粒度——表上方那两个
    // 是*二号贴格*，一个占两行 39.5，所以多半落不到正点上；只许「不超过」
    // 的话会白白挑一个远的（实测长题目那一档：让 1 个差 −22.17，不让差 +17.25）。
    //
    // 页面装不下的那些格先排除：字段表与页尾的高是固定的，加上去超过版心就不算
    // 一个可选项。整档都装不下，说明这个字号不行，换下一档。
    // 锚点：范例那一页照名义排法排出来的高
    let table-top = height-of-title(zihao.xiaoer, 0, sample-title-en)
    let tail = measure(block(width: layout.text-width, table-and-tail)).height
    let pick = none
    for size in sizes {
      let best = none
      for adjust in range(-max-pad, max-squeeze + 1) {
        let h = height-of(size, adjust)
        if h + tail > layout.text-height { continue }
        let off = calc.abs(h - table-top)
        if best == none or off < best.first() { best = (off, adjust) }
      }
      if best != none { pick = (size, best.last()); break }
    }
    // 让到头也装不下：用最小的字号、把空段让光，*再在纸角说一声*
    // ——先前这里写的是「剩下的溢出交给用户自己看」，可溢出的样子就是安安静静
    // 流到第二页，用户看不出那是出了事还是本来就两页
    let overflow = pick == none
    if overflow { pick = (sizes.last(), max-squeeze) }
    let body = { upto-table(pick.first(), pick.last()); table-and-tail }
    if warning and overflow {
      set page(foreground: overflow-note(terms.warning-overflow, terms.warning-false, lang: "en"))
      body
    } else {
      body
    }
  }
}
