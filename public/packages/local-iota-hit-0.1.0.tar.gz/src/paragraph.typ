#import "@local/docxtyp:0.1.0" as d
#import "./fonts/resolve.typ": fontset as _fontset, fontset-state, font as _font
#import "./fonts/style.typ": ready, resolve as _resolve
#import "./fonts/presets.typ": en-roles
#import "./fonts/regex.typ": latin-role-run
#import d.fonts: profile
#import d.paragraph: (families-of as _families-of, spacing as _spacing, latin-box as _latin-box,
  latin-line-rules as _latin-line-rules, use-latin-metrics)
#import d.paragraph: paragraph-mark as _paragraph-mark, paragraph-mark-height as _paragraph-mark-height
#import d.paragraph: amount, indent as _indent, no-docgrid, tracking-of, zero-docgrid, enum-hanging, list-hanging
#let _defaults = _fontset()
#let asian-font-of(style) = style.at("asian-font", default: "songti")
#let latin-font-of(style) = style.at("latin-font", default: "serif")
#let _arguments(args) = {
  let values = args.named()
  if "layout" in values {
    if "page-setup" in values { panic("expected layout or page-setup, not both") }
    values.insert("page-setup", values.remove("layout"))
  }
  values
}
#let indent(style, ..args) = _indent(style, .._arguments(args))
#let families-of(style, fontset, latin: false) = _families-of(if ready(style) { style } else { _resolve(style, fontset) },
  latin: latin)
#let spacing(style, metrics: auto, ..args) = {
  if metrics == auto and ready(style) { return _spacing(style, .._arguments(args)) }
  let f = if metrics == auto { fontset-state.get() } else { _defaults + (metrics: metrics) }
  _spacing(_resolve(style, f, metrics: metrics), .._arguments(args))
}
#let latin-box(style, layout, doc) = context _latin-box(_resolve(style, fontset-state.get()), layout, doc)
#let latin-line-rules(style, doc, ..args) = context _latin-line-rules(
  _resolve(style, fontset-state.get()), ..args.named(), doc)
#let latin-role-box(style, layout, doc) = context d.paragraph.run-metrics(
  _resolve(style, fontset-state.get()), latin-role-run, page-setup: layout, latin: true, doc)
#let _mark(font, f) = if font in en-roles {
  profile(_font(font, f.families), metrics: f.metrics.latin)
} else if type(font) == str and font in f.families {
  profile(_font(font, f.families), metrics: f.metrics.at(font))
} else { font }
#let paragraph-mark(..args, font: "serif") = context _paragraph-mark(
  ..args.pos(), .._arguments(args), font: _mark(font, fontset-state.get()))
#let paragraph-mark-height(size, font: "serif", ..args) = _paragraph-mark-height(
  size, font: _mark(font, fontset-state.get()), .._arguments(args))
