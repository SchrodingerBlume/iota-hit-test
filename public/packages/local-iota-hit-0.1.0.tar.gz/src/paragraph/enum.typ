// 编号列表（enum）：默认照 Word 排成段，不悬挂；#enum-hanging 单次改回悬挂。
//
// *Word 那边没有列表这回事。* 两份范例的 docx 里一个 w:numPr 都没有——「（1）气体
// 静压轴承　加压气体……」（本科范例第 127、130、185 段）就是普通段落：Body Text
// First Indent，首行缩进两字（w:firstLine=507），续行回到左缘，编号是手敲的全角
// 括号。Typst 的 enum 反过来：内部是一张 grid，编号一列、正文一列，续行自动悬挂到
// 正文起点，*没有参数能关*。所以这儿把每一条重排成一个正文段：编号＋正文，首行
// 缩进跟正文（section-sets 那句 first-line-indent all: true 一并罩住），续行回左缘。
//
// *括号按语言*：中文全角「（1）」、编号后不空（范例）；英文半角「(1)」、后面一个
// 空格——深圳英文写作指南 29 处、深圳中期英文 9 处、留学生开题模板 1 处全是这样，
// 没有一处全角（本部硕士开题／中期「英文版」里的「（1）」全在中文的说明页与占位
// 行上，不算）。用户在元素上写 #enum(numbering: "a)") 照原生压过。
//
// *嵌套一层多缩两字*——范例没有嵌套的例子，这是自己定的，好歹分得出层次。
//
// *悬挂三层*：文档级 enum-hanging: auto | true | false（auto ＝ 跟模板 ＝ 不悬挂，见
// src/settings/defaults.typ）；单次 #enum-hanging[…]／#enum-hanging(false)[…]／
// #enum-hanging(auto)[…]（auto ＝ 跟文档级，写了等于没写，收着是为了三态齐全）。
// 悬挂那一档就是原生的 enum（show 规则里原样交回 it）；不悬挂那一档 indent 与
// body-indent 照原生的意思映射到段上（见 enum-rules），number-align 那种只对 grid
// 有意义的不管。
//
// *圆点列表另有一份*（src/paragraph/list.typ，list-hanging）：指南对圆点列表没有规定，
// 原生的悬挂就是它该有的样子，所以那边 auto ＝ 悬挂；三层开关与排成段的办法与这儿同。
#import "../layout/chars.typ" as chars
#import "../plain.typ": plain
#import "../settings/resolve.typ": setting-of

// 悬不悬挂的三层开关，编号列表与圆点列表各造一份（键名、auto 的解各是各的）：
//   once   单次覆盖 #enum-hanging[…]／#list-hanging[…]：进去压一个、出来弹一个
//   now    眼下该不该悬挂：栈顶不是 auto 就照它，否则文档级，文档级 auto ＝ default
//          *要在 context 里调*
#let _switch(key, default) = {
  let stack = state("iota-hit-" + key, ())
  (
    once: (..args, body) => {
      let v = args.pos().at(0, default: true)
      if args.pos().len() > 1 or args.named().len() > 0 or v not in (auto, true, false) {
        panic(key + ": expected auto, true, or false, then the body, found " + repr(args.pos()))
      }
      stack.update(s => s + (v,))
      // *套一层 block*：光发内容的话，Typst 会把这里面的条目与外面紧挨着的条目
      // 收成同一个列表（state 更新是不可见元素，隔不开），于是整组一起排、还从
      // 外面那组接着编号（实测四条连号）。block 是容器，列表到它这儿断开
      block(body)
      stack.update(s => s.slice(0, -1))
    },
    now: () => {
      let local = stack.get().rev().find(v => v != auto)
      if local != none { return local }
      let doc = setting-of(key)
      if doc == auto { default } else { doc }
    },
  )
}

#let _enum = _switch("enum-hanging", false)
#let enum-hanging = _enum.once
#let _hanging = _enum.now

// 编号后空不空：全角括号自带边距不空，半角后面一个空格——与题注引用（captions 的
// _ref-gap）同一条判据
#let _gap(num) = if plain(num).ends-with(regex("[）。．、）】」]")) { [] } else { " " }

#let _numbering(lang) = if lang == "en" { "(1)" } else { "（1）" }

// 外层各级的编号，栈：进一条压这条的号、出来弹掉。长度就是嵌套深度；full: true
// 的编号（"1.a."）要把外层的号一并传给 numbering()
#let _numbers = state("iota-hit-enum-numbers", ())

#let enum-rules(lang, doc) = {
  set enum(numbering: _numbering(lang))
  show enum: it => context {
    if _hanging() { return it }
    // *原生参数照它们本来的意思映射到段上，所以让开不拦*：
    //
    //   indent       原生是编号离左缘多远。这儿编号默认落在正文的首行缩进处（两字，
    //                嵌套一层多两字）；写了就*替换*——这一条的首行缩进就是它，编号
    //                从那儿起，嵌套的自动缩进也让位（写 2em 就在 2em，不是 2em 再加
    //                两字）。0pt 是出厂值，当没写。*要与正文对齐就别写它*：正文的
    //                「两字」是 2 × 12.4543（字号加字符网格增量），2em 是 24，差 0.91
    //   body-indent  原生是编号与正文之间的空当，这儿就是编号后那一截。没写（还是
    //                出厂的 0.5em）按语言默认：中文全角括号后不空、英文半角后一个
    //                空格（写了 0.5em 与没写分不出来，那也无妨，两种情形都按默认排）
    //   spacing      条与条之间的距离，写了就发到条的上下（auto ＝ 跟正文的段距）
    //   start / reversed / full / enum.item 的 number   照原生的意思编号
    //   number-align 只对 grid 有意义（编号在这儿是行内的字），不管
    let outer = _numbers.get()
    let depth = outer.len()
    let count = it.children.len()
    let n = if it.start != auto { it.start } else if it.reversed { count } else { 1 }
    let step = if it.reversed { -1 } else { 1 }
    for item in it.children {
      let given = item.at("number", default: auto)
      if given != auto and given != none { n = given }
      let num = if it.full { numbering(it.numbering, ..outer, n) } else { numbering(it.numbering, n) }
      let gap = if it.body-indent == 0.5em { _gap(num) } else { h(it.body-indent) }
      // 嵌套多缩两字：inset 推整段。*块里先发一个 parbreak*：光放行内内容的话
      // Typst 不当它是段落，section-sets 发的首行缩进落不上（实测顶在左缘）；包成
      // par() 也不行——条目正文里的 context（#ccwd()、#heiti[…]）、嵌套的条目、图
      // 都进不了 par()，被 Typst 丢掉或劈成两行。parbreak 之后正文按流排：行内的
      // 成段、块级的（嵌套列表、图、第二段）照旧是块，什么都不用拆
      _numbers.update(s => s + (n,))
      let given = it.indent != 0pt
      block(
        inset: (left: if not given and depth > 0 { chars.ccwd(2 * depth) } else { 0pt }),
        ..(if it.spacing != auto { (above: it.spacing, below: it.spacing) } else { (:) }),
        {
          // *条件 set 用 set … if 的写法*——写成 if given { set … } 的话 set 只罩住
          // if 那个块自己，外面的段落吃不到（实测编号纹丝不动）
          set par(first-line-indent: (amount: it.indent, all: true)) if given
          parbreak()
          num + gap + item.body
        },
      )
      _numbers.update(s => s.slice(0, -1))
      n += step
    }
  }
  doc
}
