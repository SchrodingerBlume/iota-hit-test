// 术语列表（term list）的版式——两列悬挂：标签一列顶格，说明一列从固定位置排到
// 右边距、长了悬挂折行。名字取自原生 terms 元素在文档里的全名（term list）——
// 输入语法、hanging-indent 这个参数名都是从它来的。缩略语表与物理量名称及符号表
// 共用这一套（合并页就是它调两次），解析器 eqdenote 也用。
//
// *版式学 thuthesis 与 bithesis*：CTAN 上有这类页的中文模板五家里四家是两列
// description 列表（thuthesis denotation / bithesis symbols / njuthesis notation /
// fduthesis notation），hithesis 的 symbols 环境参数也与 thu 逐条相同。数取 thu/bit：
// labelwidth 2.5cm、labelsep 0.5cm、labelindent 0——标签顶格，说明从 3cm 处起、
// 续行悬挂回 3cm。
//
// *首列宽度 auto 时按内容定*：最宽的标签，下限 2.5cm（短标签的表仍是 thu/bit
// 的样子），上限版心的三分之一（再宽说明就没地方了）；超过上限的标签不参与取宽，
// 只推自己那一行。写了 hanging-indent 就照写的，不看内容。fduthesis 那种 longtable
// 的 l 列是「最宽的撑整列、没有上限」，一个离群值把整表推到版心中间。
//
// *标签从不折行，宽了只推自己那一行。* LaTeX 的 \@item 把标签放进一个盒子，
// 比 labelwidth 宽就按自然宽放（\wd\@tempboxa > \labelwidth 那一句），说明紧跟其后
// 再空 labelsep，续行仍回 leftmargin；别的行纹丝不动；比行还宽的标签溢出到右边距
// 外，说明掉到下一行。pdflatex 拿 thuthesis 那套参数实测：2.5cm 的标签说明起于
// 170.08，超宽标签那一行说明起于 287.67 ＝ 标签右缘 273.50 + 14.17，续行 170.08。
//
// 排法：一张两列 grid（首列 ＋ 剩余，列距 0.5cm）。标签放在 box 里——盒子不折行，
// 正与 hbox 同义，比列宽就溢出到右边；说明那一格的开头垫一段溢出量的横向空当，
// 于是首行紧跟标签之后再空 0.5cm，续行回到列的左缘，别的行不受影响——三条都与
// \@item 一致。
// *格里不发显式的 par*（垫空当用 h，不用 first-line-indent）：正文那条
// show par 会把纯西文的段（SVM Support Vector Machine）换成西文行盒，表就不等距了
// （实测 18.55 / 20.36 夹在 19.45 里）；格里的行内内容不是那条规则管的 par，
// 整表一个行盒。行与行不另加距（thuthesis 是 nosep）。
// 不画线，列头默认不印（画线的只有 nwafuthesis 一家）。

// thuthesis / bithesis 的 labelwidth（auto 的下限）与 labelsep
#let _label-width = 2.5cm
#let _label-sep = 0.5cm
// auto 的上限：首列不超过版心的这个比例
#let _label-ratio = 1 / 3

// 把 terms 元素拆成 item 的数组。
//
// *markup 里拿到的是一串 terms.item，不是一个 terms。* 「/ 标签: 说明」在
// 内容树上直接就是 item，只有走 show 规则时 Typst 才把它们装进 terms 元素——
// 实测 `[/ $x$: 甲\n/ $y$: 乙]` 的 children 是 ("space","item","space","item","space")。
// 所以按 terms.item 收，顺带也认整个 terms（用户自己 terms(...) 造出来那一档）。
// *要递归着找*：#for 生成的那一批还会多套一层 sequence，只认最外层或只下钻
// 一层都会漏，所以整棵树走一遍，按序把 item 收齐。eqdenote 与 nomenclature 共用
#let items(c) = {
  if c.func() == terms.item { (c,) }
  else if c.func() == terms { c.children.map(items).flatten() }
  else if c.has("children") { c.children.map(items).flatten() }
  else { () }
}

// hanging-indent 的验法，各页同一句话
#let check-hanging-indent(name, value) = {
  if value != auto and type(value) != length {
    panic(name + ": hanging-indent: expected length or auto, found " + repr(value))
  }
  if value != auto and value <= _label-sep {
    panic(
      name + ": hanging-indent: must be larger than the gap between label and description ("
        + repr(_label-sep) + ")",
    )
  }
}

// 列头：页函数收的是*开关*，三态布尔——auto ＝ 跟模板（眼下＝不印，hithesis 与
// thu 都不印列头）、true ＝ 印、false ＝ 不印。*字不在参数里*：列头的字是词条
// （column-symbol／column-description、column-short／column-long），改字走 overrides，
// 合并页两段各改各的桶——参数收内容的话字就有了第二个来路，而且合并页一对内容
// 只能两段共用。先前收过 none／一对内容／格里 auto 那一套，都是这个毛病
#let check-header(name, value) = {
  if value not in (auto, true, false) {
    panic(
      name + ": header: expected auto, true, or false (the column headings are terms; "
        + "change the words with overrides, as in list-of-symbols-column-symbol: [...]), found "
        + repr(value),
    )
  }
}

// 开关解成 term-list 要的：印就给这张表的那一对（已做好样式），不印给 none
#let resolve-header(value, pair) = if value == true { pair } else { none }

// hanging-indent 的 auto 档解出来的值：最宽的、没超过版心 1/3 的标签，下限 2.5cm，
// 再加 0.5cm 间距。单独成名是给合并页用的——同一页上两段的说明列必须对齐，它把
// *两段合起来*的标签递进来算一个值，再分别传给两次 term-list。
// 要在 context（能 measure 的地方）里调，size 是版心
#let auto-hanging-indent(labels, size) = {
  let cap = size.width * _label-ratio
  calc.max(_label-width, ..labels.map(l => measure(l).width).filter(w => w <= cap)) + _label-sep
}

// 一张表。rows 是 (标签, 说明) 的数组，header 收 none 或一对*做好样式*的列头；
// hanging-indent ＝ 说明从哪儿起（首列宽 + 0.5cm），auto 按内容定，见文件头。
// *要在 context 里调*
// header 收 none 或一对做好样式的列头（页函数用 resolve-header 解出来的）
#let term-list(rows, hanging-indent: auto, header: none) = {
  if header != none and (type(header) != array or header.len() != 2) {
    panic("term-list: header: expected none or an array of exactly two items, found " + repr(header))
  }
  let labels = rows.map(((label, _)) => label) + (
    if header == none { () } else { (header.first(),) }
  )
  // 首列宽度要知道版心多宽（上限是它的三分之一），layout 给
  std.layout(size => {
    let width = (
      if hanging-indent != auto { hanging-indent } else { auto-hanging-indent(labels, size) }
    ) - _label-sep
    // 一行两格：标签盒不折行，比首列宽就溢出；说明的开头让开溢出的那一截
    let row = ((label, description)) => {
      let overflow = measure(label).width - width
      (box(label), if overflow > 0pt { h(overflow) + description } else { description })
    }
    grid(
      columns: (width, 1fr), column-gutter: _label-sep, row-gutter: 0pt,
      align: left + top,
      ..(if header == none { () } else { row(header) }),
      ..rows.map(row).flatten(),
    )
  })
}
