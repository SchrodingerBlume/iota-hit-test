// 参考文献那一块交给 omni-gb7714 的*默认取值*。
//
// *它是配置不是排版*——参考文献表由 omni 排，我们只出章壳（那一页在
// src/pages/references.typ）与这张表。所以它住 config/，与 numbering、settings
// 同族；先前混在 pages/ 里，而那一族按规矩「只负责页面本身排版」。
// 交给 omni 的默认取值。*只写范例上量得出来的那几条*，别的一概用它自己的默认
// ——它按 GB/T 7714—2025 调好了，我们没有比它更好的依据。
//
// *两处全角，一处半角，是逐字量的*（「1-8 页+规范章补全+中英摘要」的 docx）：
//
//   正文标注     R.R.Willis[3]、二次铣削[1]、由文献[3]可知     半角 U+005B/005D
//   文献表编号   ［1］唐绪军…、［1］林来兴…                    *全角* U+FF3B/FF3D
//   类型标识     ［M］［J］［C］［D］［EB/OL］                   *全角*
//
// 所以只动后两处，正文那一轴保持半角——omni 把它们分成了两个参数
// （bib-numbering-style 管表、cite-numbering-style 管正文），正好对得上。
//
// *类型标识那一条与 GB 的通例相左。* omni 的默认是 "half"，注释写着
// 「GB 标准」；而范例印的是全角，且写在规范章「文中常用的六种参考文献类型标注
// 形式」那一节里——对 HIT 的论文，它自己的范例压过通例。用户想跟 GB 就写
// iota-hit(gb7714: (mark-medium-bracket-style: "half"))，这张表让得开。
//
// *以上说的是理工那一档。人文社科范例的方括号全是半角*——两份博士范例整篇数
// 出来：s-hss 全角 ［ 零个、半角 [ 二十六个；d-stem 全角三十个、半角一个（正文角标
// 那处）。文献表的序号「[1] KINESY A…」与类型标识「[M]」「[J]」都是半角，正文角标
// 「[81]」两档一样是半角。所以那两条按门类分档，见 gb7714-for。
//
// *著录标点不分档*：人文那几条的逗号冒号也以全角为主（「哈尔滨：哈尔滨工业
// 大学出版社，2015：236-250.」），夹着几处半角是手打的出入（同一页里「1949: 22」与
// 「2000：91-100」并存），不跟。bib-punct-style 两档都是 "full"
#let gb7714-defaults = (
  // 参考文献表的标题＝我们的章壳，见上面「章壳从 title 进去」；那一条要按文档
  // 语言生成，由 lib.typ 用 references-title 补进来，不在这张静态表里
  version: 2015,
  bib-numbering-style: "fullwidth-bracket",
  mark-medium-bracket-style: "full",
  bib-punct-style: "full",
  back-ref: true,
  hyperlink: true,
  hyperlink-title: true,
  correct-punct: true,
  hyphenate: true,
  note-numbering-style: (circled: "quan"),
  // *titles-text-case 不写*，用 omni 的默认（none，按 .bib 原样）。先前这儿写着
  // "sentence"，与本表开头那句「只写范例上量得出来的那几条」自相矛盾：两份范例的
  // 英文题名都是*作者手打什么就印什么*——d-stem 的「Static Oxidation Model of
  // Al-Mg/C…」、s-hss 参考文献的「Sexual Behavior in the Human Male」都是题式，而同一页
  // 的「Homosexuality in modern Japan」是句式，可见没有统一的规矩，只是原样。
  // GB/T 7714 自己的示例确实用句式，但那是通例，范例压过它。
  //
  // 代价也实测过：句式会把*首位大写的专名*压下去——「Sexuality in China in 2013」
  // 成了「in china」、「Chang E Lunar Probe」成了「chang e」（omni 的自动保护只认词内
  // 大写，这一类躲不过）。要转就自己写 gb7714: (titles-text-case: "sentence")，
  // 专名在 .bib 里套花括号
  date-fallback: "urldate",
  number-gutter: 0pt,
)

// 按学科门类挑的那几条。
//
// *编号后那点空当跟着括号的宽窄走。* 全角「］」自带右侧的空当，序号与正文紧挨着
// 就是范例的样子（「［1］林来兴. 空间控制技术」），所以理工写 0pt；半角「]」没有，
// 范例是在正文里*手打了一个半角空格*（「[1] KINESY A…」，那一段没有制表符）。
// Word 导出的 s-hss.pdf 逐字量：Times 12 磅，「]」在 95.41、空格在 99.63、正文首字在
// 103.60——「]」的字宽 0.333em ＝ 4.0，空格 0.25em ＝ 3.0，余下是首字的左边距与两端
// 对齐拉开的一点。所以人文那一档取 0.25em，就是那一个空格
#let gb7714-for(category) = if category == "hass" {
  gb7714-defaults + (
    bib-numbering-style: "bracket",
    mark-medium-bracket-style: "half",
    number-gutter: 0.25em,
  )
} else {
  gb7714-defaults
}
