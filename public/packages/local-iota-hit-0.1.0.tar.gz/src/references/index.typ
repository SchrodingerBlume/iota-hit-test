#import "@local/banshi:0.1.0" as banshi
#import "@preview/auto-pinyin:0.1.0": to-pinyin
#import banshi.content: plain-text
#import banshi.runs: has-han
#let zh-segment = "zh"
#let en-segment = "en"
#let entry-label = <iota-hit-index-entry>
#let sort-key(term, pinyin: auto) = {
  if pinyin != auto {
    if type(pinyin) != str {
      panic("idx: pinyin: expected string or auto, found " + repr(pinyin))
    }
    return (letter: upper(pinyin.first()), sort: lower(pinyin))
  }
  if not has-han(term) {
    let head = term.clusters()
    if head.len() == 0 { panic("idx: expected a non-empty term") }
    return (letter: upper(head.first()), sort: lower(term))
  }
  let key = to-pinyin(term, style: "tone-num-end").join("")
  (letter: upper(key.first()), sort: key)
}
#let mark(term, pinyin: auto) = {
  let text = plain-text(term)
  if text == none or text.trim() == "" { return }
  let word = text.trim()
  let key = sort-key(word, pinyin: pinyin)
  context [#metadata((
      segment: if has-han(word) { zh-segment } else { en-segment },
      letter: key.letter,
      sort: key.sort,
      term: word,
      page: numbering(here().page-numbering(), ..counter(page).at(here())),
      order: here().page(),
    ))#entry-label]
}
#let idx(entry: auto, pinyin: auto, ..body) = {
  let given = body.pos()
  if given.len() > 1 {
    panic("idx: expected at most one positional argument (the text to typeset), found " + str(given.len()))
  }
  if body.named().len() > 0 {
    panic("idx: unexpected argument: " + body.named().keys().first())
  }
  let shown = if given.len() == 1 { given.first() } else { none }
  let term = if entry != auto { entry } else if shown != none { shown } else {
    panic("idx: expected a term (write idx[word], or idx(entry: [word]) to only register it)")
  }
  mark(term, pinyin: pinyin)
  shown
}
#let segment(which) = {
  let marks = query(entry-label).filter(it => it.value.segment == which)
  let groups = (:)
  for it in marks {
    let m = it.value
    let by-letter = groups.at(m.letter, default: (:))
    let e = by-letter.at(m.term, default: (sort: m.sort, pages: ()))
    if m.page not in e.pages.map(((n, _, _)) => n) {
      e.pages.push((m.page, it.location(), m.order))
    }
    by-letter.insert(m.term, e)
    groups.insert(m.letter, by-letter)
  }
  groups
    .pairs()
    .sorted(key: ((letter, _)) => letter)
    .map(((letter, by-term)) => (
      letter,
      by-term
        .pairs()
        .sorted(key: ((term, e)) => (e.sort, term))
        .map(((term, e)) => (term, e.pages.sorted(key: ((n, l, o)) => o))),
    ))
}
