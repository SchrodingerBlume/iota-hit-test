// 索引：正文里标词，论文之后印一页。
//
// 研究生规范 2.18：「为便于检索文中内容，*可*编制索引置于学位论文之后（根据需要
// 决定是否设置）。索引以学位论文中的*专业词语*为检索线索，指出其相关内容的
// 所在页码。索引用*中、英两种文字*书写，*中文在前*。中文按各词汉语拼音
// 第一个字母排序，英文按该词第一个英文字母排序。索引示例见附录6。」
//
// *标记与收集是我们自己的，只有拼音接包。* 试过 @preview/in-dexter（Universe
// 上唯一做索引的通用包），它把标记的*页与 x/y 坐标*一起记进 metadata；而正文里
// 的缩写要 link 到缩略语表那一行——*标签链*的解析与坐标记录一起绕成一个圈，
// 两个以上缩写用法再加*任意一个*索引标记就超过 Typst 的五轮上限：实测
// warning: document did not converge，索引条目印重。逐项换过：URL 链没事、标签链必炸；
// 挪动标记位置、去掉多余 context、把「表排过没有」从 query 换成状态旗再换成
// 声明期的取值，都不解决。
//
// 自己写就只记*页码*，不记坐标——页码在版面稳下来之后就不动了，圈断了。
// 换来的代价很小：索引这件事本身简单（标记、收集、按首字母分组、页码去重合并），
// 与缩略语那边「首次判定、复数、修饰符、重置」完全不是一个量级，那一处才值得接包。
//
// *两段各一个名*：中文段与英文段分开收，「中文在前」是两次渲染的先后，
// 而不是排序的花招——混成一个的话，中文的 T 组与英文的 T 组会并在一起。
//
// *拼音：auto-pinyin 推、pinyin 覆盖*（甲＋乙）。分组字母取首字读音的第一个
// 字母，组内按整词的带调拼音排（hithesis 也用带调键，只是它把键印出来当分组标题了，
// 那是它的错）。
//
// *多音字只能靠人。* auto-pinyin 给的是最常见的一读（实测「重复」推成 zhongfu，
// 该是 chongfu），而 Typst *没有*用户级的警告（warn / std.warn 都不存在，实测），
// 发不出 hithesis 那句 pinyin-multiple。好在猜错了是*看得见*的——那一条会排在
// 错的字母组下，校样时一眼认出，改法就是给这一处写 pinyin:。
#import "@local/banshi:0.1.0" as banshi
#import "@preview/auto-pinyin:0.1.0": to-pinyin
#import banshi.content: plain-text
#import banshi.msword: has-han

// 两段的名。收集时按它分堆
#let zh-segment = "zh"
#let en-segment = "en"

// 标记落在文档里的标签。*只记页码，不记坐标*，见文件头
#let entry-label = <iota-hit-index-entry>

// 一个词的分组字母与组内排序键。
//
//   中文  首字的读音定字母（体 → ti3 → T），整词的带调拼音当组内键
//   西文  首字母定字母，整词小写当组内键
//
// pinyin 写了就照写（多音字、生僻字、或者想按别的读音归组）
#let sort-key(term, pinyin: auto) = {
  if pinyin != auto {
    if type(pinyin) != str {
      panic("idx: pinyin: expected string or auto, found " + repr(pinyin))
    }
    return (letter: upper(pinyin.first()), sort: lower(pinyin))
  }
  if not has-han(term) {
    let head = term.clusters()
    if head.len() == 0 { panic("idx: expected a non-empty term") }
    return (letter: upper(head.first()), sort: lower(term))
  }
  let key = to-pinyin(term, style: "tone-num-end").join("")
  (letter: upper(key.first()), sort: key)
}

// 只登记，不印字。缩略语那一条也走它，见 src/references/abbreviations.typ 的 render
#let mark(term, pinyin: auto) = {
  let text = plain-text(term)
  if text == none or text.trim() == "" { return }
  let word = text.trim()
  let key = sort-key(word, pinyin: pinyin)
  context [#metadata((
      segment: if has-han(word) { zh-segment } else { en-segment },
      letter: key.letter,
      sort: key.sort,
      term: word,
      // *印出来的那个页码*，不是物理页——前置是罗马、正文以后是阿拉伯。
      // *存的是排好的字样，不是那个整数*：存整数的话罗马那一段会印成阿拉伯，
      // 而且「摘要第 I 页」与「正文第 1 页」按数字去重会被当成同一页合掉（实测
      // 四处标记印出「1, 2, 3」，其中那个 1 点过去落在摘要页）
      page: numbering(here().page-numbering(), ..counter(page).at(here())),
      // 排序用：物理页。同一个词的几处按文档顺序排，罗马那几处自然在前
      order: here().page(),
    ))#entry-label]
}

// 正文里的标记。
//
//   #idx[体细胞拷贝数变异]           印它、按它登记
//   #idx(entry: [乔峰])[乔帮主]      印「乔帮主」、登记「乔峰」
//   #idx(entry: [乔峰])              没给正文槽 ＝ 只登记不印
//   #idx(pinyin: "ti3")[体细胞…]     多音字或想换归组的读音
//
// *「不印」不是一个取值，是没给正文槽*——参数少一个，也不用为二态造枚举。
#let idx(entry: auto, pinyin: auto, ..body) = {
  let given = body.pos()
  if given.len() > 1 {
    panic("idx: expected at most one positional argument (the text to typeset), found " + str(given.len()))
  }
  if body.named().len() > 0 {
    panic("idx: unexpected argument: " + body.named().keys().first())
  }
  let shown = if given.len() == 1 { given.first() } else { none }
  let term = if entry != auto { entry } else if shown != none { shown } else {
    panic("idx: expected a term (write idx[word], or idx(entry: [word]) to only register it)")
  }
  mark(term, pinyin: pinyin)
  shown
}

// 收拢成 [(字母, [(词, ((页码, 落点)…))…])…]，一段一次。*要在 context 里调*。
//
// 组按字母排，组内按排序键（同键的按词面），页码去重、升序——同一个词在同一页标
// 两次只出一个数。
//
// *落点是标记元素自己的 location()，不存进 metadata。* 页码要能点回正文
// （与目录、引用一致），所以得有个跳转目标；in-dexter 的做法是把 loc.position()
// 记进 metadata，而那正是不收敛的根子（见文件头）。query 回来的是元素本身，
// 它的 location() 现拿现用，一个字都不用存。
#let segment(which) = {
  let marks = query(entry-label).filter(it => it.value.segment == which)
  let groups = (:)
  for it in marks {
    let m = it.value
    let by-letter = groups.at(m.letter, default: (:))
    let e = by-letter.at(m.term, default: (sort: m.sort, pages: ()))
    // 去重按*印出来的字样*——罗马 I 与阿拉伯 1 是两页，不该合成一条
    if m.page not in e.pages.map(((n, _, _)) => n) {
      e.pages.push((m.page, it.location(), m.order))
    }
    by-letter.insert(m.term, e)
    groups.insert(m.letter, by-letter)
  }
  groups
    .pairs()
    .sorted(key: ((letter, _)) => letter)
    .map(((letter, by-term)) => (
      letter,
      by-term
        .pairs()
        .sorted(key: ((term, e)) => (e.sort, term))
        // 按物理页排：罗马那几处在前，阿拉伯在后，与读者翻书的顺序一致
        .map(((term, e)) => (term, e.pages.sorted(key: ((n, l, o)) => o))),
    ))
}
