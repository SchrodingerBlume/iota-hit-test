// 图表的几种 kind，以及「标签指向的元素换成真正排出来的那一张」。

#import "../heading/marks.typ": find-algorithm

// 三种第一方的 kind：图、表、伪代码。伪代码的 kind 是字符串——Typst 的 figure(kind:)
// 收元素函数或字符串，不是元素的只能是字符串；全词，与 image / table 一路
#let algorithm-kind = "algorithm"

#let kinds = (
  (kind: image, term: "image"), (kind: table, term: "table"),
  (kind: algorithm-kind, term: "algorithm"),
  // 代码清单：kind 是 Typst 自己的 raw，名走词条（中文「代码」、英文 Listing），
  // overrides: (caption-raw: …) 换词，题注、引用、续排标注一起变
  (kind: raw, term: "raw"),
)


// 图、表、公式的引用*自己重建*，为的是两件事。
//
// *一、章号要在对象位置上取。* 我们的按章编号写成闭包，里面
// counter(heading).get()——而 Typst 渲染引用时是在*引用点*调那个闭包的。
// 实测第一章里的公式在第二章引用，三类全错：对象印「(1-1)」「图1-1」「表1-1」，
// 引用却印「式 (2-1)」「图 2-1」「表 2-1」。裸 Typst 一样复现，是这个写法本身的坑。
// 分图那一支本来就是按落点取的（counter(heading).at(e.loc)），漏的是普通那几类。
//
// *二、名与号之间那个空格。* Typst 的 ref 会插一个 U+0020（实测步进 3.000），
// 而指南三类都没有空格：「见式（1-1）」「见图1-1」「如表1-1所示」「见表1」。
// 但两种情形要留：*英文名*（Fig. 1-1，西文本来就该空）与*半角括号*
// （「式 (1-1)」，半角「(」几乎没有左边距，贴上去挤）。全角括号自带边距，不留。
//
// *认不出的原样交回。* 文献引用的 it.element 是 none，第一道就放行——
// omni-gb7714 也装 show ref，它同样把不是文献键的交回（实测两条规则嵌套时，
// 内层 return it 之后外层照样接手），所以两边不冲突。
// running：是不是行文里的引用。公式清单的条目（src/pages/outline.typ）写 false——清单里的号与
// 公式自己那个号同形，跟 equation-numbering-fullwidth；行文里的引用照中文标点走，见下

// 伪代码的 figure 是重造的（见 caption-rules 里那条 show figure），用户写的那个 kind 还是
// image 的*原件*仍然在：可查、记数、进 outline（实测被换掉的元素照样在 query 里，图的
// 计数器也被它步进了一格——原件后面那张图印成「图1-3」、插图索引里多一条「图1-2 算法」）。
// 所以凡是按 kind 查图的地方都要把原件剔掉，计数器由重造那条规则退回去
#let original(f) = f.kind == image and find-algorithm(f.body) != none

// 标签指向的元素换成真正排出来的那一张：用户的标签留在原件上，紧跟在它之后的第一张
// algorithm 就是替它排的那一张。别的元素原样交回。*要在 context 里调*

// 标签指向的元素换成真正排出来的那一张：用户的标签留在原件上，紧跟在它之后的第一张
// algorithm 就是替它排的那一张。别的元素原样交回。*要在 context 里调*
#let resolve(el) = {
  if el == none or el.func() != figure { return el }
  if el.kind != image or find-algorithm(el.body) == none { return el }
  let after = query(figure.where(kind: "algorithm").after(el.location(), inclusive: true))
  if after.len() == 0 { el } else { after.first() }
}

// 三种第一方的 kind：图、表、伪代码。伪代码的 kind 是字符串——Typst 的 figure(kind:)
// 收元素函数或字符串，不是元素的只能是字符串；全词，与 image / table 一路
