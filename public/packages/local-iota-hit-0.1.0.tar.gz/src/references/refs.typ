// 图、表、公式的名与号：题注与引用共用的那一半——词条里的名、用户给的名、续排标注、
// 引用的号与名号之间的空当、引用并组。show ref 那条规则仍在 caption.typ 的链上。

#import "../content.typ": plain-text
#import "../msword.typ": has-cjk
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-table, term-for, term-apply, info-variant
#import "../info.typ": info-get
#import "../axes.typ": campus-for
#import "../settings/resolve.typ": setting-of
#import "../figure/kinds.typ" as kinds

// 图、表、公式的引用*自己重建*，为的是两件事。
//
// *一、章号要在对象位置上取。* 我们的按章编号写成闭包，里面
// counter(heading).get()——而 Typst 渲染引用时是在*引用点*调那个闭包的。
// 实测第一章里的公式在第二章引用，三类全错：对象印「(1-1)」「图1-1」「表1-1」，
// 引用却印「式 (2-1)」「图 2-1」「表 2-1」。裸 Typst 一样复现，是这个写法本身的坑。
// 分图那一支本来就是按落点取的（counter(heading).at(e.loc)），漏的是普通那几类。
//
// *二、名与号之间那个空格。* Typst 的 ref 会插一个 U+0020（实测步进 3.000），
// 而指南三类都没有空格：「见式（1-1）」「见图1-1」「如表1-1所示」「见表1」。
// 但两种情形要留：*英文名*（Fig. 1-1，西文本来就该空）与*半角括号*
// （「式 (1-1)」，半角「(」几乎没有左边距，贴上去挤）。全角括号自带边距，不留。
//
// *认不出的原样交回。* 文献引用的 it.element 是 none，第一道就放行——
// omni-gb7714 也装 show ref，它同样把不是文献键的交回（实测两条规则嵌套时，
// 内层 return it 之后外层照样接手），所以两边不冲突。
// running：是不是行文里的引用。公式清单的条目（src/pages/outline.typ）写 false——清单里的号与
// 公式自己那个号同形，跟 equation-numbering-fullwidth；行文里的引用照中文标点走，见下
#let number(el, fig-by-chapter, eq-by-chapter, running: true) = {
  let loc = el.location()
  // *括号单列一栏，不从编号串里切。* 按章那一档拼不出整串交给 numbering()
  // ——章号可能是字母（附录），而 numbering() 只吃整数，见 src/heading/numbering.typ。
  // 先前这里拿 pat 的首尾字符当括号，图表那一档的 pat 是 "1-1"，于是把 1 当成
  // 了括号，排出「图11-11」。
  let (cnt, chap, open, close) = if el.func() == figure {
    (counter(figure.where(kind: el.kind)), fig-by-chapter, "", "")
  } else if el.func() == math.equation {
    // *中文档里引用一律全角括号，不跟公式自己那个号*。指南 2.11 写「见式（1-1）」、
    // 博士范例正文写「由公式（4-1）、（4-2）」——都是全角、名与号之间不空；而范例
    // 里公式自己印的号是半角「(4-1)」（MathType）。两处本来就不是一副括号：号是
    // 排在版心右缘的一个标记，引用是行文里的字，行文照中文标点走。先前引用跟着
    // equation-numbering-fullwidth（默认半角），又嫌半角「(」贴着「式」挤、补了一个
    // 空格，排出「式 (1-1)」——指南与范例里都没有这个样子。英文档照旧跟那个设定
    // （Equation (1-1)，西文本来就空一格）
    (
      counter(math.equation),
      eq-by-chapter,
      ..(if (running and doc-lang.get() == "zh") or setting-of("equation-numbering-fullwidth") == true {
        ("（", "）")
      } else { ("(", ")") }),
    )
  } else {
    return none
  }
  let n = cnt.at(loc)
  if chap {
    // 公式那一档的「附」在括号里（（附1-1）），图表那一档在名上（见 supplement）
    _numbering.chapter-numbered(
      loc, n, open: open, close: close,
      prefix: if el.func() == math.equation {
        _numbering.appendix-prefix(loc, doc-lang.get(), by-chapter: chap)
      },
    )
  } else {
    numbering(open + "1" + close, ..n)
  }
}

// 一处引多个时*名只印一遍*：「由公式（4-1）、（4-2）求得」，范例第 4 章印的
// 就是这个。
//
// *做法学 omni-gb7714*（它把 [1][2][3] 并成 [1-3] 用的是同一套）：show ref
// 不直接排，先吐出*记号包着的标签*；再用一条 show regex 把*相邻的几个
// 记号*整段抓住，交给组处理器一次排完。
//
// *妙在记号是纯文本*——regex 看得见「两个引用之间夹了什么」，而那一层
// show par 拿不到（返回重建的内容就再触发自己，报 maximum grouping depth
// exceeded；metadata 记号也挡不住，重新分组发生在规则看到记号之前）。
//
// 记号取私用区的三字组，与 omni 同一个理由：正文里撞不上，而且三个字连着更不会
// 被别的规则误伤。我们的 latin-run 只收到 U+024F，私用区落在外面，不会被切。

// 一处引多个时*名只印一遍*：「由公式（4-1）、（4-2）求得」，范例第 4 章印的
// 就是这个。
//
// *做法学 omni-gb7714*（它把 [1][2][3] 并成 [1-3] 用的是同一套）：show ref
// 不直接排，先吐出*记号包着的标签*；再用一条 show regex 把*相邻的几个
// 记号*整段抓住，交给组处理器一次排完。
//
// *妙在记号是纯文本*——regex 看得见「两个引用之间夹了什么」，而那一层
// show par 拿不到（返回重建的内容就再触发自己，报 maximum grouping depth
// exceeded；metadata 记号也挡不住，重新分组发生在规则看到记号之前）。
//
// 记号取私用区的三字组，与 omni 同一个理由：正文里撞不上，而且三个字连着更不会
// 被别的规则误伤。我们的 latin-run 只收到 U+024F，私用区落在外面，不会被切。
#let MARK = "\u{E7A1}\u{E3D2}\u{EB09}"

// 载荷里「标签」与「用户自己给的名」之间的隔子。名（@a[公式]）得跟着标签一起
// 传到组处理器手里，不然一组里只有头一个能定名。*记号是纯文本，带不了内容*，
// 所以只带得动纯文本的名——不是纯文本的（@a[*图*]）就不并组，原样单排，
// 见 single 里那道 text-only。

// 载荷里「标签」与「用户自己给的名」之间的隔子。名（@a[公式]）得跟着标签一起
// 传到组处理器手里，不然一组里只有头一个能定名。*记号是纯文本，带不了内容*，
// 所以只带得动纯文本的名——不是纯文本的（@a[*图*]）就不并组，原样单排，
// 见 single 里那道 text-only。
#let NAME-SEP = "\u{E4B6}\u{EA25}\u{ED73}"

// 这一段内容是不是*纯文本*（只有文字与空格）。不是就带不过记号，
// 那一档退回单排——宁可不并组，也不能把用户写的格式悄悄丢掉。

#let SEP-RE = "[ \u{00A0}\t]*[、，,；;]?[ \u{00A0}\t]*"

// *名。* 从词条取，不从元素上读——图表的 supplement 是用
// show figure.where(kind:): set figure(supplement:) 设的，那是 show 规则里的 set，
// 换个上下文读 el.supplement 拿到的是 Typst 自己的默认值。中文档恰好也是「图」「表」
// 所以看不出来，英文档当场露馅：该印 Fig. 印成了 Figure。

// 这一段内容是不是*纯文本*（只有文字与空格）。不是就带不过记号，
// 那一档退回单排——宁可不并组，也不能把用户写的格式悄悄丢掉。
#let space-func = [ ].func()

#let text-only(c) = {
  if type(c) == str { return true }
  if type(c) != content { return false }
  if c.func() == text or c.func() == space-func { return true }
  if c.has("children") { return c.children.all(text-only) }
  false
}

// 相邻的判据：*中间只许夹分隔标点与空白*。「@a@b」「@a、@b」「@a, @b」都算，
// 「@a 与 @b」不算——那中间是实词，并起来会把话说坏。
// 题注里那个字（图／表、Fig. / Figure / Table）*按档取*——深圳的英文档写
// 全称 Figure，见 src/terms/built-in.typ 的 caption 桶。*档从 info 取*：题注
// 这一路本来就都在 context 里，不必再从 iota-hit 一层层递进来；校区先过
// campus-for（那边没发过这一档表单的学位归本部），与页眉、封面同一个办法

// 相邻的判据：*中间只许夹分隔标点与空白*。「@a@b」「@a、@b」「@a, @b」都算，
// 「@a 与 @b」不算——那中间是实词，并起来会把话说坏。
// 题注里那个字（图／表、Fig. / Figure / Table）*按档取*——深圳的英文档写
// 全称 Figure，见 src/terms/built-in.typ 的 caption 桶。*档从 info 取*：题注
// 这一路本来就都在 context 里，不必再从 iota-hit 一层层递进来；校区先过
// campus-for（那边没发过这一档表单的学位归本部），与页眉、封面同一个办法
#let word(lang, key) = term-for(term-table(lang, "caption"), key, info-variant())

// *用户在这一张图表上显式写的 supplement*（figure(image(…), supplement: [照片])）：
// 写了就照它印——题注、引用、清单三处同一条。没写返回 auto。
//
// *怎么知道写没写。* 图表的 supplement 出厂就是 auto，Typst 实现元素时按 kind 与
// text.lang 填上它自己的字样（image: 图 / Figure，table: 表 / Table），fields() 里读到
// 的就是这个*填好的值*，与用户显式写的分不出来；而我们那句 show-set 填进去的词
// （Fig.）在 fields() 里看不见，只在 it.supplement 里有。所以判据是「fields() 里的值
// 不是 Typst 自己那两个字样」——那两个字样按语言列在下面，是 Typst 的 l10n 表，不是
// 我们的词（我们的在 src/terms/built-in.typ）。代价：英文档里显式写 [Figure] 会被当成
// 没写、印成 Fig.；要全篇改字样走 overrides，README 写着。supplement: none（只要号）
// 照 Typst 的意思：名空着。

// *用户在这一张图表上显式写的 supplement*（figure(image(…), supplement: [照片])）：
// 写了就照它印——题注、引用、清单三处同一条。没写返回 auto。
//
// *怎么知道写没写。* 图表的 supplement 出厂就是 auto，Typst 实现元素时按 kind 与
// text.lang 填上它自己的字样（image: 图 / Figure，table: 表 / Table），fields() 里读到
// 的就是这个*填好的值*，与用户显式写的分不出来；而我们那句 show-set 填进去的词
// （Fig.）在 fields() 里看不见，只在 it.supplement 里有。所以判据是「fields() 里的值
// 不是 Typst 自己那两个字样」——那两个字样按语言列在下面，是 Typst 的 l10n 表，不是
// 我们的词（我们的在 src/terms/built-in.typ）。代价：英文档里显式写 [Figure] 会被当成
// 没写、印成 Fig.；要全篇改字样走 overrides，README 写着。supplement: none（只要号）
// 照 Typst 的意思：名空着。
#let typst-supplements = (
  image: (zh: "图", en: "Figure"), table: (zh: "表", en: "Table"), raw: (zh: "代码", en: "Listing"),
)

#let given-supplement(fields, kind, lang) = {
  let k = kinds.kinds.find(k => k.kind == kind)
  if k == none { return auto }
  let v = fields.at("supplement", default: auto)
  if v == auto { return auto }
  if v == none { return [] }
  // 伪代码那一档 Typst 没有自己的字样，fields() 里填的就是我们那句 set 给的词——与它
  // 相同就是没写
  if k.term not in typst-supplements { return if plain-text(v) == plain-text(word(lang, k.term)) { auto } else { v } }
  let dflt = typst-supplements.at(k.term).at(lang, default: typst-supplements.at(k.term).zh)
  if plain-text(v) == dflt { auto } else { v }
}
// 续排的标注：「（续」加这一种东西的名（图／表／算法／照片…），词条是函数，
// 见 src/terms/built-in.typ 的 continued

// 续排的标注：「（续」加这一种东西的名（图／表／算法／照片…），词条是函数，
// 见 src/terms/built-in.typ 的 continued
#let continued-mark(lang, name) = {
  let i = info-get()
  term-apply(
    term-table(lang, "caption"), "continued",
    (degree-level: i.degree-level, campus: campus-for(i.campus, i.degree-level)),
    name,
  )
}

// *名。* 从词条取，不从元素上读——图表的 supplement 是用
// show figure.where(kind:): set figure(supplement:) 设的，那是 show 规则里的 set，
// 换个上下文读 el.supplement 拿到的是 Typst 自己的默认值。中文档恰好也是「图」「表」
// 所以看不出来，英文档当场露馅：该印 Fig. 印成了 Figure。
#let supplement(el, by-chapter) = {
  let lang = doc-lang.get()
  // 引「附表1-1」时名也得带「附」——号在被引对象那一处求，「附」也一样
  // （公式那一档的「附」在括号里，不在名上，见 number）
  let prefix = if el.func() == math.equation { none } else {
    _numbering.appendix-prefix(el.location(), lang, by-chapter: by-chapter)
  }
  if el.func() == math.equation { return word(lang, "equation") }
  let k = kinds.kinds.find(k => k.kind == el.kind)
  // *自造的 kind 用它自己的名*（figure(kind: "algo", supplement: [算法])）：那一档
  // Typst 逼着用户写 supplement，而我们那句 set figure(supplement:) 只落在图与表上，
  // 所以这儿读到的就是用户写的，不是出厂默认——图表那两档才读不得，见 word；
  // 图表上显式写的 supplement 另有判法，见 given-supplement
  let given = given-supplement(el.fields(), el.kind, lang)
  prefix + (if k == none { el.supplement } else if given != auto { given } else { word(lang, k.term) })
}

// *名与号之间空不空。* Typst 的 ref 会插一个 U+0020（实测步进 3.000），
// 而指南三类都没有空格：「见式（1-1）」「见图1-1」「如表1-1所示」「见表1」。
// 但两种情形要留：*英文名*（Fig. 1-1，西文本来就该空）与*半角括号*
// （英文档的「Equation (1-1)」；中文档的公式引用一律全角，见 number）。全角
// 括号自带边距，*不论名是中是英都不留*——「Equation（1-1）」再空一格就是两份边距。

// *名与号之间空不空。* Typst 的 ref 会插一个 U+0020（实测步进 3.000），
// 而指南三类都没有空格：「见式（1-1）」「见图1-1」「如表1-1所示」「见表1」。
// 但两种情形要留：*英文名*（Fig. 1-1，西文本来就该空）与*半角括号*
// （英文档的「Equation (1-1)」；中文档的公式引用一律全角，见 number）。全角
// 括号自带边距，*不论名是中是英都不留*——「Equation（1-1）」再空一格就是两份边距。
#let gap(sup, num) = {
  let n = plain-text(num)
  if n.starts-with("（") { [] }
  else if not has-cjk(plain-text(sup)) or n.starts-with("(") { sym.space.nobreak }
  else { [] }
}

// 号与*续排标注*之间空不空，判据与 gap 同源：全角括号自带边距，不空
// （「表1-1（续表）」，范例就是这个样子）；半角括号几乎没有左边距，贴上去成了
// 「Fig. 1-2(Continued)」，要空一个。空的是不折行的空格——号与标注是一体的

// 号与*续排标注*之间空不空，判据与 gap 同源：全角括号自带边距，不空
// （「表1-1（续表）」，范例就是这个样子）；半角括号几乎没有左边距，贴上去成了
// 「Fig. 1-2(Continued)」，要空一个。空的是不折行的空格——号与标注是一体的
#let continued-gap(mark) = if plain-text(mark).starts-with("（") { [] } else {
  sym.space.nobreak
}

// 认不出的原样交回。文献引用的 it.element 是 none，第一道就放行——omni-gb7714
// 也装 show ref，它同样把不是文献键的交回（实测两条规则嵌套时，内层 return it
// 之后外层照样接手），所以两边不冲突。

// 认不出的原样交回。文献引用的 it.element 是 none，第一道就放行——omni-gb7714
// 也装 show ref，它同样把不是文献键的交回（实测两条规则嵌套时，内层 return it
// 之后外层照样接手），所以两边不冲突。
#let single(it, fig-by-chapter, eq-by-chapter) = {
  let el = kinds.resolve(it.element)
  if el == none { return it }
  if number(el, fig-by-chapter, eq-by-chapter) == none { return it }
  let given = it.fields().at("supplement", default: auto)
  // supplement: none 是「只要号」，那一份没有名可并，直接排
  if given == none { return link(el.location(), number(el, fig-by-chapter, eq-by-chapter)) }
  // 用户给的名不是纯文本就带不过记号，退回单排——宁可不并组，也不能把格式丢掉
  if given != auto and not text-only(given) {
    let num = number(el, fig-by-chapter, eq-by-chapter)
    return link(el.location(), given + gap(given, num) + num)
  }
  // 吐记号，交给下面那条组规则排。单个也走它——组正则的重复部分是 *，一个也匹配
  MARK + str(it.target) + (if given == auto { "" } else { NAME-SEP + plain-text(given) }) + MARK
}

// 把一组记号排成「名 号、号、号」。分隔符*原样保留用户写的那个*——中文写
// 顿号、英文写逗号，各随各的习惯，我们不替他选。
// 并组的判据是*同一类*，不是「名的文字相同」。
//
// 「@eq:a、@fig:a、@tbl:a」这一串挨着，三个不同类——一并省掉就成了
// 「式 (1-1)、1-1、1-1」。而按文字比又太紧：用户在头一个上写了 @a[公式]，
// 后面几个没写，文字不同就并不起来，排出「公式 (1-1)、式 (1-2)」，难看。
//
// 所以：*类相同就并*，名取组内*头一个*的；后面某一个又显式写了别的名，
// 就从那里另起一组。

// 把一组记号排成「名 号、号、号」。分隔符*原样保留用户写的那个*——中文写
// 顿号、英文写逗号，各随各的习惯，我们不替他选。
// 并组的判据是*同一类*，不是「名的文字相同」。
//
// 「@eq:a、@fig:a、@tbl:a」这一串挨着，三个不同类——一并省掉就成了
// 「式 (1-1)、1-1、1-1」。而按文字比又太紧：用户在头一个上写了 @a[公式]，
// 后面几个没写，文字不同就并不起来，排出「公式 (1-1)、式 (1-2)」，难看。
//
// 所以：*类相同就并*，名取组内*头一个*的；后面某一个又显式写了别的名，
// 就从那里另起一组。
#let class(el) = if el.func() == math.equation { "equation" } else {
  repr(el.at("kind", default: none))
}

#let group(text, fig-by-chapter, eq-by-chapter) = {
  // 「MARK k1 MARK s1 MARK k2 MARK」拆开是 ("", k1, s1, k2, "")：奇数位是载荷，
  // 偶数位（首尾除外）是用户写在两个引用之间的那一段
  let parts = text.split(MARK)
  let loads = ()
  let seps = ()
  for (i, p) in parts.enumerate() {
    if calc.odd(i) { loads.push(p) } else if i > 0 and i < parts.len() - 1 { seps.push(p) }
  }
  let out = ()
  let cls = none          // 当前这一组的类
  let name = none         // 当前这一组的名（纯文本，用来判后面有没有换名）
  let custom = false      // 本组的名是不是引用上显式写的（是就管住整组）
  for (i, load) in loads.enumerate() {
    let bits = load.split(NAME-SEP)
    let key = bits.first()
    let given = if bits.len() > 1 { bits.at(1) } else { none }
    let found = query(label(key))
    if found.len() == 0 { return text }
    let el = kinds.resolve(found.first())
    let num = number(el, fig-by-chapter, eq-by-chapter)
    if num == none { return text }
    if i > 0 { out.push(seps.at(i - 1)) }
    let k = class(el)
    // 另起一组：类换了；或者这一个在引用上显式写了个跟本组不一样的名；或者本组的名
    // 不是引用上写的、而这一个对象自己的名跟它不一样——图表上显式写的 supplement
    // （figure(…, supplement: [照片])）算对象自己的名，「见图1-1、照片1-2」不能并成
    // 「图1-1、1-2」。引用上写了名的组管住整组（头一个写「公式」，后面的都跟着）
    let own = supplement(el, fig-by-chapter)
    if k != cls or (given != none and given != name) or (given == none and not custom and plain-text(own) != name) {
      cls = k
      custom = given != none
      let sup = if given != none { given } else { own }
      name = plain-text(sup)
      out.push(link(el.location(), if sup == none { num } else {
        sup + gap(sup, num) + num
      }))
    } else {
      out.push(link(el.location(), num))
    }
  }
  out.join()
}




// 序与名之间的 2 个半角字符。
//
// 半角字在 Word 的字符网格里吃半格：字身宽的一半加网格增量的一半。两个就是
// 一个全角字的宽度。实测本科范例「表6-1」到表名是 11.28，差的 0.33 是字形的
// 左右边距，不是间距本身。
// 编号与题名之间。auto *按文档语言*取：中文一个字、英文四分之一个
// （Times 的一个空格，原件敲的就是一个），取值与出处见 src/settings/defaults.typ
// 的 caption-body-indent-auto。*跟文档语言不跟这一行的语言*——中文档里
// 双语题注的英文行照样空一个字，与标题那一档同一条，见 heading-body-indent。
// *要在 context 里调*
