#let openright-points = ("titlepage", "frontmatter", "mainmatter", "backmatter")
#let openright-auto = (
  bachelor: (titlepage: false, frontmatter: false, mainmatter: false, backmatter: false),
  master: (titlepage: false, frontmatter: false, mainmatter: false, backmatter: false),
  doctor: (titlepage: true, frontmatter: false, mainmatter: false, backmatter: false),
  postdoc: (titlepage: false, frontmatter: false, mainmatter: false, backmatter: false),
)
// shown: auto 除了只排终稿，还按学位挡：博后模板没有声明页与答辩页，写 shown: true 照样强排
#let shown-auto = (
  declarations: (postdoc: false),
  defense: (postdoc: false),
  // 博士生期间那一章、永久通讯地址只有博后报告有
  achievements-doctoral: (bachelor: false, master: false, doctor: false),
  permanent-address: (bachelor: false, master: false, doctor: false),
)
// 目录里前置各章与正文第一章之间空一个 Normal 段：博后模板有，硕博范例没有；不开参数
#let toc-front-blank = (postdoc: true)
#let caption-bilingual-auto = (
  final: (bachelor: false, master: false, doctor: true, postdoc: true),
  proposal: (bachelor: false, master: false, doctor: false),
  interim: (bachelor: false, master: false, doctor: false),
)
#let caption-numbering-by-top-level-heading-auto = (final: true, proposal: false, interim: false)
#let report-caption-by-section = (
  harbin: (bachelor: ("proposal",)),
  shenzhen: (master: ("interim",), doctor: ("interim",)),
)
#let algorithm-style-auto = (
  frame: "tabular", keyword-case: "upper", indent-guide: "bar", line-numbering: "1",
)
#let raw-style-auto = (frame: "tabular", line-numbering: "1")

#let em-dash-auto = (
  shenzhen: (
    bachelor: ("proposal", "interim"),
    master: ("proposal", "interim"),
    doctor: ("proposal", "interim"),
  ),
)
#let equation-numbering-by-top-level-heading-auto = (final: true, proposal: false, interim: false)
#let theorem-numbering-by-top-level-heading-auto = (final: true, proposal: false, interim: false)
#let theorem-body-indent-auto = (chars: 1)
#let setting-defaults = (
  openright: auto,
  fake-bold: auto,
  fake-italic: auto,
  algorithm-style: auto,
  raw-style: auto,
  em-dash: auto,
  caption-bilingual: auto,
  subcaption-numbering: "(a)",
  subcaption-separator: ";",
  subcaption-bilingual: auto,
  subcaption-gap: auto,
  equation-numbering-fullwidth: auto,
  heading-body-indent: auto,
  theorem-body-indent: auto,
  note-width: auto,
  appendix-numbering: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  abbreviation-indexed: auto,
  enum-hanging: auto,
  list-hanging: auto,
  two-hanzi: auto,
  page-numbering: auto,
  title-case: auto,
  top-level-heading-pagebreak-before: auto,
  caption-numbering-by-top-level-heading: auto,
  equation-numbering-by-top-level-heading: auto,
  theorem-numbering-by-top-level-heading: auto,
  abbreviation-fullwidth: auto,
  abbreviation-links: auto,
)
// 设定还能在哪几个公开函数上就地写（名字就是函数名，也是词条桶名）；参数名不同的写成「函数(参数)」
#let setting-homes = (
  "openright": (
    "abstract",
    "table-of-contents",
    "list-of-figures",
    "list-of-tables",
    "list-of-equations",
    "list-of-symbols",
    "list-of-abbreviations",
    "nomenclature",
    "titlepage",
    "conclusions",
    "achievements",
    "declarations",
    "defense",
    "index",
    "acknowledgements",
    "resume",
    "permanent-address",
    "chapter",
    "frontmatter",
    "mainmatter",
    "backmatter",
  ),
  "two-hanzi": (
    "table-of-contents",
    "list-of-figures",
    "list-of-tables",
    "list-of-equations",
    "list-of-symbols",
    "list-of-abbreviations",
    "nomenclature",
    "conclusions",
    "achievements",
    "declarations",
    "defense",
    "index",
    "acknowledgements",
    "resume",
    "chapter",
  ),
  "subcaption-gap": ("subs(gap)",),
  "subcaption-numbering": ("subs(numbering)",),
  "note-width": ("note(width)",),
  "heading-body-indent": ("table-of-contents", "list-of-figures", "list-of-tables", "list-of-equations"),
  "appendix-numbering": ("appendix",),
  "outline-entry-right-margin": ("table-of-contents", "list-of-figures", "list-of-tables", "list-of-equations"),
  "outline-entry-number-align": ("table-of-contents", "list-of-figures", "list-of-tables", "list-of-equations"),
)
#let report-heading-body-indent = (shenzhen: (master: (chars: 0.5), doctor: (chars: 0.5)))
// heading-body-indent 的 auto 按学位另有一档：博后目录与页眉里章号后是手打的中文空格（半个字宽）
#let heading-body-indent-by-degree = (postdoc: (chars: 0.5))
// 标题编号后的空当：博后的章号是 Word 自动编号，后缀空格 0.2875em（48 磅实测）；只在 heading-body-indent 没写时
#let heading-number-suffix = (postdoc: 0.2875em)
// 两个汉字的章级标题撑开：博后模板不撑
#let two-hanzi-auto = (postdoc: false)
// 交给 banshi 的 Word 设置，名字照 OOXML：各档原件 docx 的 settings.xml 里写没写
// html-paragraph-auto-spacing：docx 写着 w:doNotUseHTMLParagraphAutoSpacing 的为 false（段后与下段段前相加）——
// 博后模板写了，硕博范例没有
#let html-paragraph-auto-spacing = (postdoc: false)
// w:adjustLineHeightInTable（格子里的行贴网格）：硕博范例写了，博后模板没有
#let adjust-line-height-in-table = (postdoc: false)
// 编号列表：中文文档默认「（1）」，博后模板是半角「(1)」；博后编号级别 w:suff 缺省即 tab、
// w:tab w:val="num" 在 903 缇，w:defaultTabStop 578 缇
#let enum-numbering-by-degree = (postdoc: "(1)")
#let numbering-tab-by-degree = (postdoc: (numbering-suffix: "tab", numbering-tab-stop: 45.15pt, default-tab-stop: 28.9pt))
// 目录与图表清单 lang: auto 出哪几种：博士中英两份，其余只中文（英文文档、报告另判）
#let outline-languages-auto = (doctor: ("zh", "en"))
// 摘要里关键词上面那个空段的行距：博后跟正文（1.1 倍贴网格），其余 1.25
#let keywords-blank-line-spacing-auto = (postdoc: auto)
#let caption-separator-auto = (zh: (chars: 1), en: (chars: 0.25))
// 题注编号后的空当按每一行的语言取：博后中文行两个半角空格（一个字）、英文行一个 Times 空格；其余各档整条跟文档语言
#let caption-separator-by-line = (postdoc: true)

#let heading-body-indent-auto = (
  zh: (
    stem: ((chars: 1), (chars: 1), (chars: 1), (chars: 1)),
    hass: ((chars: 1), (chars: 0), (chars: 0), (chars: 0.5)),
  ),
  en: (stem: ((chars: 1), (chars: 1), (chars: 1), (chars: 1)), hass: ((chars: 1), (chars: 1), (chars: 1), (chars: 1))),
)
#let appendix-numbering-auto = (
  zh: (
    stem: (bachelor: "1", master: "A", doctor: "A", postdoc: "A"),
    hass: (bachelor: "一", master: "一", doctor: "一"),
  ),
  en: (
    stem: (bachelor: "A", master: "A", doctor: "A", postdoc: "A"),
    hass: (bachelor: "A", master: "A", doctor: "A"),
  ),
)
#let appendix-patterns = ("A", "I", "1", "一", "One")
