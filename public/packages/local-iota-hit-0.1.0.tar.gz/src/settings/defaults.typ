#let openright-points = ("titlepage", "frontmatter", "mainmatter", "backmatter")
#let openright-auto = (
  bachelor: (titlepage: false, frontmatter: false, mainmatter: false, backmatter: false),
  master: (titlepage: false, frontmatter: false, mainmatter: false, backmatter: false),
  doctor: (titlepage: true, frontmatter: false, mainmatter: false, backmatter: false),
)
#let caption-bilingual-auto = (
  final: (bachelor: false, master: false, doctor: true),
  proposal: (bachelor: false, master: false, doctor: false),
  interim: (bachelor: false, master: false, doctor: false),
)
#let caption-numbering-by-chapter-auto = (final: true, proposal: false, interim: false)
#let report-caption-by-section = (
  harbin: (bachelor: ("proposal",)),
  shenzhen: (master: ("interim",), doctor: ("interim",)),
)
#let algorithm-style-auto = (
  frame: "tabular", keyword-case: "upper", indent-guide: "bar", line-numbering: "1",
)
#let raw-style-auto = (frame: "tabular", line-numbering: "1")

#let em-dash-auto = (
  shenzhen: (
    bachelor: ("proposal", "interim"),
    master: ("proposal", "interim"),
    doctor: ("proposal", "interim"),
  ),
)
#let equation-numbering-by-chapter-auto = (final: true, proposal: false, interim: false)
#let theorem-numbering-by-chapter-auto = (final: true, proposal: false, interim: false)
#let theorem-body-indent-auto = (chars: 1)
#let setting-defaults = (
  openright: auto,
  fake-bold: auto,
  fake-italic: auto,
  algorithm-style: auto,
  raw-style: auto,
  em-dash: auto,
  caption-bilingual: auto,
  subcaption-numbering: "(a)",
  subcaption-separator: ";",
  subcaption-bilingual: auto,
  subcaption-gap: auto,
  equation-numbering-fullwidth: auto,
  heading-body-indent: auto,
  theorem-body-indent: auto,
  figure-note-width: auto,
  appendix-numbering: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  abbreviation-indexed: auto,
  enum-hanging: auto,
  list-hanging: auto,
)
#let setting-homes = (
  "heading-body-indent": ("toc", "lof", "lot", "loe"),
  "appendix-numbering": ("appendix",),
  "outline-entry-right-margin": ("toc", "lof", "lot", "loe"),
  "outline-entry-number-align": ("toc", "lof", "lot", "loe"),
)
#let report-heading-body-indent = (shenzhen: (master: (chars: 0.5), doctor: (chars: 0.5)))
#let caption-separator-auto = (zh: (chars: 1), en: (chars: 0.25))

#let heading-body-indent-auto = (
  zh: (
    stem: ((chars: 1), (chars: 1), (chars: 1), (chars: 1)),
    hass: ((chars: 1), (chars: 0), (chars: 0), (chars: 0.5)),
  ),
  en: (stem: ((chars: 1), (chars: 1), (chars: 1), (chars: 1)), hass: ((chars: 1), (chars: 1), (chars: 1), (chars: 1))),
)
#let appendix-numbering-auto = (
  zh: (
    stem: (bachelor: "1", master: "A", doctor: "A"),
    hass: (bachelor: "一", master: "一", doctor: "一"),
  ),
  en: (
    stem: (bachelor: "A", master: "A", doctor: "A"),
    hass: (bachelor: "A", master: "A", doctor: "A"),
  ),
)
#let appendix-patterns = ("A", "I", "1", "一", "One")
