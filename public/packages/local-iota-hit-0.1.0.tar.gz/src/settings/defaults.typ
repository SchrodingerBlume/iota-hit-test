// 文档级开关的取值：默认表、各 *-auto 表与 setting-homes。*只放值*——state 与
// 解析函数（settings-overrides、setting-of、resolve-*）住在 src/settings/resolve.typ。
//
// *与 src/info.typ 分开。* info 装的是*印在纸上*的信息——题目、
// 姓名、答辩日期；这里装的是*不印在纸上*的取值——单面还是双面、是不是
// 送审版。两者的生命周期与来源都不同，混在一处会让「这一项会不会出现在页面上」
// 变得说不清。

// 右翻页的四个*切页点*。
//
//   titlepage    内封、英文内封（封面之后那几跳；封面本身恒为第 1 页，不用跳）
//   frontmatter  前置里的章：摘要、目录
//   mainmatter   正文里的章，以及入口那一跳（入口跳就是第一章的跳，只是要提前
//                到页码重置之前发出，见 src/layout/matter.typ）
//   backmatter   后置里的章
//
// *内封为什么与前置的章分开。* hithesis 就是分开的：封面序列走
// \__hit_cover_break:（无条件双页清），摘要目录走 \hit@clear@page（由 openright
// 管、默认关）。博士的默认形态正是「内封跳、摘要目录不跳」，一个"前置"档盖不住。
#let openright-points = ("titlepage", "frontmatter", "mainmatter", "backmatter")

// 总闸给 auto 时按学位查这张表。
//
// *本硕全 false*——指南 3.8 写死「单面复印或胶印」，单面没有右手页可言。
//
// *博士只有内封那一档 true*，跟 hithesis：封面之后、中文内封之后各一次
// 无条件双页清；而摘要、目录、各章、后置都由 openright 管，默认关。研究生范例
// 逐页量下来也是这样——Abstract 落印码 II、Contents 落 IV、结论落 8，全是偶数页。
//
// *学位耦合只住在这张表里*：看得见、有出处，用户在任何一层写显式值都能
// 盖掉，写 auto 与不写等价。
#let openright-auto = (
  bachelor: (titlepage: false, frontmatter: false, mainmatter: false, backmatter: false),
  master: (titlepage: false, frontmatter: false, mainmatter: false, backmatter: false),
  doctor: (titlepage: true, frontmatter: false, mainmatter: false, backmatter: false),
)

// 题注要不要排双语。总闸给 auto 时按学位查这张表。
//
// *只有博士双语。* 研究生写作指南（人文社科类）的表题条款写着「硕士学位
// 论文只用中文，博士学位论文用中、英两种文字居中排写，中文在上」，总则那句
// 「博士学位论文的扉页、摘要、目录、图题及表题等要求中、英文两种文字」也是
// 这么说。博士范例逐页量下来正是双语（图题 Fig.1-1 那一行、表题 Table6-1 那
// 一行），本科范例只有中文。
//
// *那份指南的图题条款漏写了学位限定*——它无条件写「用中、英两种文字」，
// 没提硕士；只有表题条款和总则写了「博士」。按后两处实现。
//
// *来源有个缺口*：研究生那份我只找到人文社科类，而范例是理工类。图表
// 条款与本科那份几乎逐字相同，两类通用是推定，不是查证。
//
// *报告那两档不双语*：规范那句「博士学位论文的扉页、摘要、目录、图题及表题等
// 要求中、英文两种文字」点的是*学位论文*；三份报告表单里图题表题一个字没写，
// 而中英两版是*两份表单*（写中文报告用中文那份、写英文报告用英文那份），不是
// 一份里排两遍。hithesis 同——它的报告类明写「报告类没有 lang 选项，语言一律按中文
// 取」（hit-report-float.dtx）。目录同理，见 src/pages/outline.typ 的 want。
#let caption-bilingual-auto = (
  final: (bachelor: false, master: false, doctor: true),
  proposal: (bachelor: false, master: false, doctor: false),
  interim: (bachelor: false, master: false, doctor: false),
)

// 题注编号按不按章。auto 指向哪一档。
//
// *现在只有一个值*——学位论文一律按章。指南 2.12 / 2.13.1：「图序按章编排，
// 如第 1 章第一个插图的图号为『图1-1』」，前面还有个「一般」——那两个字正是
// 连续编号的口子，所以 false 那一档不算违规，只是不该当默认。
//
// *报告那几档多数是 false*：报告没有「章」这一级，按顶层编就成了「图3-1」
// ——3 是节号。本部硕博的表单对图表一个字没写，hithesis 的报告类也走 article
// 默认，就是连续的「图1」「表1」。
//
// *有几份是按顶层编的，逐份列出来*——两处证据一致：
//
//   本部本科开题    hithesis 特设 \thesection-\arabic（hit-report-float.dtx）
//   深圳硕士中期    原件里印的是「图2-4」（2 是那一节的号），hithesis 也特设
//
// 深圳本科那两份不在这张表上——它们的*正文照终稿排*（见 src/axes.typ
// 的 final-body），走 final 那一档，原件印的正是「图1-1」「表2-1」。
#let caption-numbering-by-chapter-auto = (final: true, proposal: false, interim: false)

// 按顶层标题编号的那几份报告，校区 → 学位 → 阶段，见上
#let report-caption-by-section = (
  harbin: (bachelor: ("proposal",)),
  shenzhen: (master: ("interim",), doctor: ("interim",)),
)


// 破折号 U+2014 排哪一副字：中文字体（"cjk"）还是西文字体（"latin"）。
//
// *Word 里这个字看 run 上的 w:hint*：eastAsia 就排中文字，没有就排西文字，
// 全凭作者的输入法留下什么——同一份里两样都有。而两副字长得不一样：中易宋体的
// 杠占 0.031–0.973 em，两个「——」中间断开一截（Word 用宋体排的也断，研究生范例
// p23 放大看得见）；Times 的杠占 −0.009–1.009 em，两头各出头一点，连成一条，只是
// 位置低 1.5pt（杠在 0.22–0.26 em，宋体在 0.34–0.38 em）。黑体、楷体的杠 0.000–0.996
// em，几乎连上。
//
// auto 跟*各分支自己的原件*（用户定的），逐份数 hint：
//
//   深圳本科中期（中文）  16 个全没 hint → Times      英文中期 5 个同样
//   深圳本科开题          两份都没有破折号，跟同分支的中期
//   本科范例 1-8 页       26 eastAsia : 10 没有     → 宋体
//   研究生范例 d-stem     6 : 6，指南 g-stem / p-stem 39 : 10、g-hss 8 : 3 → 宋体
//   深圳硕博四份表单      没有破折号——跟同校区的本科报告走西文（用户定的），
//                        不跟终稿
//
// 所以深圳的报告一律西文，论文中文。表里列的是 "latin" 那几档
// （校区 → 学位 → 阶段，与 report-caption-by-section 同形）。
// 伪代码样子的默认值，algorithm-style 里没写（或写 auto）的键取这里，见 setting-defaults
#let algorithm-style-auto = (
  frame: "tabular", keyword-case: "upper", indent-guide: "bar", line-numbering: "1",
)
// 代码清单样子的默认值，raw-style 里没写（或写 auto）的键取这里
#let raw-style-auto = (frame: "tabular", line-numbering: "1")

#let em-dash-auto = (
  shenzhen: (
    bachelor: ("proposal", "interim"),
    master: ("proposal", "interim"),
    doctor: ("proposal", "interim"),
  ),
)

// 公式编号按不按章。指南 2.11 明写「公式序号按章编排，如第 1 章第 1 个公式的
// 序号为『（1-1）』」，所以 auto ＝ 按章。
//
// *与题注那一条分开。* 公式与图表是两个部件，共用一个开关就表达不了
// 「图表按章、公式连续」这种组合。不进 state 的理由与题注那一条相同，见
// src/settings/resolve.typ 的 resolve-caption-numbering-by-chapter。
#let equation-numbering-by-chapter-auto = (final: true, proposal: false, interim: false)

// 取值表。*一张扁平表，不分桶。* 键名的前缀就是分组——caption-、subfigure-、
// heading- 一眼看得出谁管谁，公开面上本来写的也是这些扁平键。
//
// *为什么不像 terms 那样分桶。* terms 的桶是承重墙：每一页都要
// term-table(lang, page) 把本页那一桶整个端走，桶是主要读法。settings 这边
// 数过——九个读点里只有一处整桶取，桶白搭一层，还倒贴三样东西：断键要在
// 「base 可省桶名」与每个「桶-」前缀之间试探、要防两种断法同时命中、
// 覆盖还要先折成嵌套再逐桶合并。
#let setting-defaults = (
  // 右翻页的总闸，三态：
  //   false  一段都不跳
  //   true   四个点全跳
  //   auto   按学位查 openright-auto 那张表
  //
  // 单段用 frontmatter / mainmatter / backmatter 的同名参数覆盖，单页单章用
  // #titlepage(openright:)、#chapter(openright:)、部件参数覆盖。每一层都收
  // auto，含义都是「我不表态，交给上一层」。
  //
  // *没有 library 这个开关。* hithesis 需要它，是因为它有*关不掉*的
  // 跳——\__hit_cover_break: 不受 openright 控制，只能另开一个总否决
  // （README:377「向图书馆提交的电子版……要求没有任何空白页」）。我们四个点
  // 层层可覆盖，图书馆版要的「不跳、不留空白、页码连续」就是 openright: false。
  //
  // *报告里它只管两处*：#show: mainmatter 入口那一跳、深圳本科报告目录第一页那一跳。
  // 各节不跳页（heading-1-pagebreak 在报告里默认 false，节前跳页会把五千字排成五页），
  // 所以 openright: true 落不到节上——不是静默失效，是那两处仍然生效、节这一头本来
  // 就没有页可跳；要节也跳，另写 heading-1-pagebreak: true。四份深圳本科报告与本部
  // 五份表单都写着「A4 纸单面打印」或没提，右手页在报告里本来无从谈起
  openright: auto,
  // 中文*加粗*怎么办。三态：
  //
  //   auto   探当前字体有没有真粗体，没有才描边合成
  //   true   一律描边
  //   false  从不描边——那就是没做这一档时的样子：中文加粗*完全哑掉*
  //          （实测 #strong[加粗] 与正文同一个 SimSun 子集，字重纹丝不动）
  //
  // 西文那边自动就对：Times 有真粗体，auto 探出来就不合成。
  //
  // 描边线宽 字号/35，与 Word 一致——由 Word 建的 docx 导出 PDF 实测标定：
  // 48.025pt 加粗给 1.3721w、24pt 给 0.68571w，都精确等于 字号/35。
  fake-bold: auto,
  // 中文*强调*怎么办。三态：
  //
  //   auto   探*楷体在不在*——在就换楷体（指南与 hithesis 的做法），
  //          不在才斜切宋体
  //   true   一律斜切宋体，有楷体也不用（就想要斜的那档用户）
  //   false  从不斜切：没楷体时排正体宋体，强调看不出来
  //
  // *两个 auto 问的不是同一个问题，这是故意的*：伪粗是真粗的*替代品*，
  // 所以问「这个字体自己有没有真粗」；伪斜是「换楷体」的*第三顺位*——汉字
  // 没有斜体，首选换字体，楷体也没有才退到斜切。
  //
  // 倾斜 -18.4°，与 cutix 同源。
  fake-italic: auto,
  // 伪代码的样子，一个字典，三个键都收 auto（＝ 不写 ＝ 默认）：
  //
  //   frame         框，PlutoThesis 记的哈工大各实验室的三个门派（都是 algorithm2e 的选项，
  //                 差别只在框，本体一样）：
  //                   "tabular"  类似表格型（生信、网安）：题注在上、表外；粗线、输入输出、
  //                              细线、正文、粗线——三线表的样子，Word 里也正是拿表格排的
  //                   "ruled"    线条型（自然语言）：粗线、题注、细线、正文、粗线，题注在两线间
  //                   "boxed"    框图型（社会计算）：一圈框，题注在框外下方（与图同）
  //                 默认表格型（用户定的）。三个词都是形容词：boxed、ruled 是 algorithm2e
  //                 的原名，第三档 algorithm2e 叫 plainruled、PlutoThesis 叫「类似表格型」，
  //                 取 tabular——LaTeX 里表格环境的名字。线宽与三线表同一套
  //   keyword-case  关键字印成什么大小写。关键字是语义单位（algorithm2e 的 \For 印成什么
  //                 由样式定），用户敲 for / For / FOR 都认，印出来统一按这一档：
  //                   "upper"  FOR（默认；中文论文里通行全大写，用户定的）
  //                   "lower"  for（algorithm2e 的默认）
  //                   "title"  For
  //                 只动西文；用 overrides 换成中文词的不受影响。词表见 src/terms/built-in.typ
  //   indent-guide  块左侧那条缩进引导线（编辑器与 lovelace 都叫 indentation guide；
  //                 algorithm2e 的 lined / vlined / noline 三个开关管的就是它）：
  //                   "bar"   光竖线（默认——PlutoThesis 三段都没动这一项，排出来就是它）
  //                   "hook"  竖线到块尾收一个小钩（algorithm2e 的 vlined，CS 论文里常配不写 end）
  //                   none    不画
  //   line-numbering  行号的样子，Typst 的 numbering 记法："1"（默认，光数字——algorithm2e
  //                 的样子，CLRS 也是）、"1:"（algorithmicx 的样子）、"①"（圈码，交给 quan
  //                 画，⑪ 起字体里没有的也齐）……也收函数；none 不编行号
  //
  // *跨不跨页不在这张表里*：走原生的 show figure.where(kind: "algorithm"): set block(breakable:)，
  // 默认拆（三档都拆）。拆开的样子各按各的框：表格型页底收底线、续页从顶线起、右上角
  // 「算法N-N（续算法）」（与续表同）；线条型页底与续页都不画线、不标注，行号接着数；框图型
  // 按续图的排法——题注跟头一片、续片末尾「算法N-N（续算法）」，每一片各画一圈框（指南
  // 2.13.2 分图转页那一句）。先前这里有一键 breakable，理由是「默认值随框变、show-set 给不了
  // context」；三档都拆之后理由没了，口子撤掉
  //
  // 一篇论文一个样子，不给单条覆盖。收成字典的先例是 layout / styles / gb7714——
  // 上面那段说的「不分桶」说的是这张表本身，不是字典值。
  algorithm-style: auto,
  // 代码清单（进了 figure 的代码块）的样子，与 algorithm-style 同型，键都收 auto：
  //
  //   frame           "tabular"（默认）顶粗线 ／ 代码 ／ 底粗线，题注在上、居中——三线表少了表头
  //                   那一道；"ruled" 粗线 ／ 题注（居左）／ 细线 ／ 代码 ／ 粗线；"boxed" 一圈
  //                   框、题注在下；none 不画框、题注位置随用户。线宽走三线表的（顶／底 1.5、
  //                   中 1.0）。题注位置随框定，与伪代码同。跨页各按各的框：tabular 页底收
  //                   底线、续页从顶线起、顶线之上右侧「代码N-N（续代码）」；ruled 不画线不
  //                   标注、接着排；boxed 按续图的排法、每片各画框
  //   line-numbering  行号，与 algorithm-style 的同一档记法："1"（默认）、"1:"、"①"、函数、none
  //
  // *只管进了 figure 的代码*：散在正文里的代码块是段落（Word 里就是段落），没框没行号。
  // codly / zebraw 这类代码包接管了 body 的，框与行号都归它们（它们的 show raw 在用户文档里、
  // 更内层，这里那条到不了 body）；题注位置仍随 frame 定
  raw-style: auto,
  // 破折号排中文字体还是西文字体，三态：
  //
  //   auto     按分支查 em-dash-auto 那张表（深圳的报告西文，其余中文）
  //   "cjk"    一律中文字体——中易宋体的「——」中间断一截
  //   "latin"  一律西文字体——Times 的连成一条线，位置低 1.5pt
  //
  // 两副字的杠长得不一样、Word 按 run 的 hint 两样都排，见那张表的注释。
  // 引号、省略号、间隔号不归它管，仍归中文字体（banshi/src/fonts/resolve.typ 的 latin-entries）。
  em-dash: auto,
  // 题注排不排双语，三态：false 一律只排中文 / true 一律双语 /
  // auto 按学位查 caption-bilingual-auto 那张表。
  //
  // 双语开着而某个题注没写 #en[…] 时，那一条就只排中文——不拿中文冒充英文。
  // 英文档（iota-hit(lang: "en")）另说：只排英文那一份，没写 #en 才回落中文，
  // 与标题同一条规则，见 src/terms/lang.typ 的 title-of。
  caption-bilingual: auto,
  // 题注里*编号与题名之间*那一格*没有设定项*——它就是原生的
  // figure.caption(separator:)，用户直接写那一句：
  //
  //     #set figure.caption(separator: h(2em))
  //
  // 没写时的默认按文档语言取，见下面的 caption-separator-auto。先前这儿另有一条
  // caption-body-indent，与原生那一格说的是同一件事、我们却把原生那句拦下报错
  // ——同一件事两种拼法，删了。
  // 分图号的写法，收 Typst 的编号串。三份文件三种说法：本科指南 2.13.1 的正文写
  // 全角「（a）、（b）」，本科范例*印出来*是半角「(a) 」，研究生规范又另写作
  // 「a)、b)」（连左括号都没有）。
  //
  // *默认跟范例的半角*——印出来的东西比叙述里的那一句实。想跟指南的叙述就写
  // "（a）"。*括号后那个空当不写进这里*：半角时自动补一个半角空当（范例量到
  // 5.77，正好半个字身加字距），全角时不补（全角括号自带边距）。同一条判据也管着
  // 引用里「图1-1 (a)」那个空当。
  subcaption-numbering: "(a)",
  // 分图题之间的分隔。本科指南 2.13.1 的正文写「用『；』间隔」，本科范例*印
  // 出来*是半角「; 」。默认跟范例，与分图号那一档同一个取舍。
  //
  // *后面那个空当不写进这里*，与分图号同一条判据：半角标点后自动补一个半角
  // 空当，全角不补（全角标点自带边距）。想跟指南的叙述就写 "；"。
  //
  // *研究生规范里没有这一条*——它只说分图题「置于分图之下或图题之下」，
  // 连排与分隔都没提，所以硕博也跟着本科这份走。
  subcaption-separator: ";",
  // *分图题*排不排双语。三态，*auto ＝ 不排*——图题表题那一档不管这里。
  //
  // *默认不排是有出处的*：研究生规范说分图题「*可以只用中文书写*」，
  // 而双语那句（「博士学位论文的扉页、摘要、目录、图题及表题等要求中、英文两种
  // 文字」）点的是图题与表题，没点分图题；两份范例里也没有一条双语分图题。所以
  // 与 caption-bilingual 分开：那一档 auto 按学位（博士双语），这一档 auto 恒是
  // 不排，想要就显式写 true。
  //
  // 开着而某一条没写 #en[…] 时，*整组都不排英文行*——一行是一行，缺一条就
  // 参差（实测 (a) 两行 (b) 一行，把母图题顶了下去），理由见 caption.typ 的
  // _sub-langs。
  subcaption-bilingual: auto,
  // *图题与连排分图题之间*插什么。三态：auto ＝ 什么都不插 / 长度 ＝ 空这么高 /
  // *内容 ＝ 原样插进去*（写 enter(1) 就是空一行，写别的就排别的）。
  //
  // *auto 是零，范例量得出来*：本科范例 p9 那张带分图题的图，图题基线 375.41、
  // 分图题基线 394.97，差 19.56 正好是那一节的一个行距——两行连着排，中间一个数
  // 都没设（docx 里这两段的 pPr 一个 w:spacing 都没写）。
  //
  // *名字用 Typst 的词*：这正是 figure(gap:) 的位置与含义（题与它上面那一块之间
  // 的空当）。收内容而不是只收长度，是因为「在两者之间插点东西」本来就没有规定，
  // 收窄成一个数反而挡住了用处：这一档在流里，直接插。（图块表块与正文之间那
  // 三段空当不在这儿，在样式表上：styles.figure.image / .table 的 above、gap、
  // below，见 src/styles/presets.typ 的 _figure。）
  //
  // 只管*连排*那一档：「分图之下」那种排法里分图题贴在自己那张分图下面，与
  // 母图题不相邻，那一段是 Typst 自己的 figure(gap:)。
  subcaption-gap: auto,
  // 公式编号的括号用不用全角。三态，auto ＝ 半角。
  //
  // *只放开括号这一个自由度。* 指南 2.11 把别的都写死了——「将序号置于括号
  // 内」「公式序号按章编排」；唯一留有余地的是括号宽窄：指南的*叙述*写全角
  // 「（1-1）」（U+FF08/FF09），范例*印出来*却是半角 U+0028/0029。这与分图号
  // 是同一处矛盾的两个面（指南写「（a）」、范例印「(a) 」），两边照同一条取舍走：
  // 印出来的东西比叙述里的那一句实，默认跟范例。
  //
  // *为什么不收编号串。* 收串就等于把「括号里放什么」「按不按章」也一并放开，
  // 用户写得出 "[1.1]" 这种不合规的东西；而快捷键在这个模板里有一半的用处正是
  // 拦住这个。分图号那一条收串是另一回事——它的写法真有三种（「(a)」「（a）」
  // 「a)」，研究生规范连左括号都没有）。
  //
  // *只管公式自己那个号，不管行文里的引用。* 中文档里「见式（1-1）」一律全角——
  // 指南 2.11 与博士范例正文都这么写，号是版心右缘的标记、引用是行文里的字，
  // 见 src/references/refs.typ 的 number；英文档的引用跟这个设定。
  //
  // *连字符不跟着变全角。* 指南那句原话里，全角括号中间夹的是*半角*
  // 连字符 U+002D（逐字量过）。范例里那个 U+2212 减号两侧还带数学间距，那是 Word
  // 把「1-1」当算式排的实现细节，两样都不跟。
  equation-numbering-fullwidth: auto,
  // 标题里*题序与标题之间*空多少。收长度，与 caption-body-indent 同义。
  //
  // *auto ＝ 一个汉字宽*（chars(1)）。本科指南 3.2 明写「题序顶格书写，
  // *与标题间空 2 个半角字符*，阐述内容另起一段」——2 个半角就是 1 个全角。
  // 两份范例印出来也是这个：章标题（18pt）号末到题名首 ~17.9、节（15pt）~15.8、
  // 条（14pt）~14.7，都恰好是那一级自己的一个字宽。
  //
  // *Typst 自己插的是 0.3em*，章标题只空 5.4——差着 12.5，一眼就看得出来。
  // hithesis 走 ctex 的 aftername=\enspace（半个字），与范例印出来的也不符。
  //
  // *英文档的 auto 是半个字*，取值住 heading-body-indent-auto 那张表；跟的是
  // *文档语言*不是那一页的语言——中文档的英文目录仍空一个字，理由见那张表。
  heading-body-indent: auto,
  // 附录的章号用字母（附录A）还是数字（附录1）。*三态*，auto 按学位——
  // 本科数字、硕博字母，与 hithesis 的
  // \ctexset{appendix/number = \ifhit@bachelor\arabic{chapter}\else\Alph{chapter}\fi}
  // 一致（hithesis.dtx:8120）。
  //
  // *指南对此一个字都没规定。* 本科指南 2.15 与研究生规范 2.16 一字不差，通篇只讲
  // 「什么内容可以放进附录」，没有编号、没有标题格式；两份范例里也没有附录实例。
  // 所以这一档只能跟 hithesis。
  //
  // *名字里的元素是「附录」不是「章」。* 表里的键名说的是它*作用在什么
  // 上*——写 chapter- 的话，文档级读起来像正文章标题也要变成「第 A 章」。
  //
  // *数那三档的图表公式另加「附」*：附录1 的图叫「附图1-1」，与正文第 1 章的
  // 「图1-1」分得开；字母那一档不加，「图A-1」本来就不撞。判据与拼法见
  // src/heading/numbering.typ 的 appendix-numeric 与 src/heading/numbering.typ。
  // hithesis 不加（它就让附录1 的图印成「图1-1」，与正文撞号）。
  //
  // *收的是编号串本身*，不是布尔——原生 numbering() 认的就是 "A" / "1" /
  // "一"，写 letters: true 那种既说不出第三档（人文社科的汉字数字），也要在下游
  // 再翻译一次。五档：
  //
  //     "A"    附录A ／ A.1 ／ A.1.1        硕博（理工）、*英文档一律*
  //     "I"    附录I ／ I.1 ／ I.1.1        罗马数字，指南没有，用户要的；图表与字母那档同形（图I-1）
  //     "1"    附录1 ／ 1.1 ／ 1.1.1        本科（理工）
  //     "一"   附录一 ／ 一、／（一）        人文社科——*与正文同一套写法*
  //     "One"  Appendix One ／ 一、／（一）  人文社科的英文写法
  //
  // *"One" 那一档是我们自己数的*——numbering() 没有英文数词，表在
  // src/heading/numbering.typ（en-words）。它*不做任何一档的默认*：英文档默认
  // 用字母（见 appendix-numbering-auto），而中文档的英文目录里「附录一」本来就印
  // 成「Appendix One」（appendix-mark-en）。留着它是因为英文档写得出「Appendix One」
  // 这种要求——先前英文档没有这一档，落到「一」上，章标题印成「Appendix 一」。
  //
  // *只有一个附录就不编号*：章标题光印「附录」「Appendix」，中文档的图表跟着
  // 少一位（「附图1」），英文档照旧印字母（Fig. A-1）。见 src/layout/matter.typ
  //
  // auto 按文档语言、门类与学位，见 appendix-numbering-auto
  appendix-numbering: auto,
  // 目录条目正文*每一行*右边留多宽。*auto ＝ 0*：正文一直排到制表位，只有
  // 末行给点线与页码让路，页码永不独占一行——这是 Word 与范例的排法：博士范例英文
  // 目录「Chapter 4 … FLUENT software」加粗后超过版心，Word 在 software 前折，首行
  // 一直排到右边距（右端 492.5，边距 510.2）。机理见 src/pages/outline.typ 的条目规则。
  //
  // *写 4em 就是 hithesis 的排法*：它把 \@pnumwidth 与 \@tocrmarg 都设成 4em，
  // 注释写着「规定中的提前悬挂」（hithesis.dtx:8030），把指南 3.6「对于超过一行的
  // 目录内容提前换行」读成每行提前 4em。实测它的输出（hithesis-v3.1e-dev.20260128.pdf
  // 第 12 页）：折行条目首行末字右缘 462.24，页码 504.24。范例不是这样，所以不做
  // 默认；想要它的显式写。
  //
  // *名字取自原生元素。* 目录与两份图表索引都用 outline() 排、条目都是
  // outline.entry，共用同一条规则，所以键名说的是那个元素，不是某一页。
  outline-entry-right-margin: auto,
  // 目录条目的编号怎么摆。收 alignment，与 enum(number-align:) 同名同型：
  //
  //   auto / none  不取列：编号排自然宽，后面空一个字，标题起点跟着编号长短走
  //                （范例：按字形原点量「章」→「绪」25.00 = 一个字 + 一个全角空格）
  //   left         编号靠左排进一列，列宽 = 这一级最宽的编号；编号后空*半个*字
  //   right        编号靠右贴齐列缘，后面空一个字；一列标题的起点对齐。下一级的
  //                缩进再加上上面各级里最窄编号被推开的那一段（列宽 − 最窄编号宽）：
  //                窄编号靠右被推向列缘，章多起来「第1章」就推到节的缩进上、一二级
  //                平齐；让过之后最窄的上级编号与本级编号仍差一个缩进，与 none 同款
  //
  // 抄的是 hithesis 的 toc/number-align 三态（本地 ~/hithesis 的 acf8ce4：natural /
  // left / right），两处不同：它的列宽是 \@dottedtocline 写死的额定值（2em / 3em），
  // 我们量这一级最宽的编号——原生 outline(indent: auto) 就是这么做的；它 left 档
  // 一律「实宽 + 半个间距」（ctex 半字号参数化来的），我们按最宽编号的位数定：不到
  // 两位数空一个字，两位以上半个字（列被那一位数字撑宽了半个字，再空整字题名就漂远）。
  //
  // *默认不取列*（范例的排法：编号与题名之间是两个空格）。跟着各自编号走只在编号
  // 等宽时才齐，附录 A／B 字母不等宽、章过十就错开，介意的写 left。
  //
  // *间距本身不另开口子*：三档的「一个字」都是 heading-body-indent 那一个值
  // （页眉里的章标题也跟它）。hithesis 的 toc/number-gap 我们不抄。
  outline-entry-number-align: auto,
  // 缩略语要不要顺带登记进索引。*默认不登记*——规范 2.18 说索引收的是
  // 「专业词语」，把全部缩写自动灌进去会失焦；hithesis 的 abbr/indexing 默认是开的，
  // 这一条我们不跟。
  //
  // 三层，每层 auto ＝ 不表态：逐条（条目里的 indexed）→ 这一次调用
  // （#abbreviations(indexed:)）→ 这一条 → 默认 false。开了之后中英两条都登记
  // （中文全称进中文段、英文全称进英文段），登记的是每次 @缩写 出现的那一页，
  // 与 hithesis 的 abbr/indexing 同义。见 src/references/abbreviations.typ
  abbreviation-indexed: auto,
  // 编号列表的续行悬不悬挂到正文起点。三态，auto ＝ 跟模板 ＝ 不悬挂：Word 那边
  // 根本没有列表（两份范例一个 w:numPr 都没有），「（1）……」就是首行缩进两字的
  // 普通段落，续行回左缘；Typst 的 enum 是一张 grid、天生悬挂、没有参数能关。
  // 单次覆盖写 #enum-hanging[…]。见 banshi/src/paragraph/enum.typ
  enum-hanging: auto,
  // 圆点列表的续行悬不悬挂。三态，auto ＝ 悬挂（指南没规定圆点列表，原生的悬挂就是
  // 它该有的样子）；false 排成段，与编号列表同一个排法。单次覆盖写 #list-hanging(false)[…]。
  // 见 banshi/src/paragraph/list.typ
  list-hanging: auto,
)

// *下面几张 *-auto 默认表与 openright-points 不带下划线，是有意的。* 包里的
// 约定是「没人 import 的加 _」，而这几张表*是给人查的*——注释里到处写着
// 「取值与依据见 xxx-auto」，读的人得能一眼找到它们；加了下划线反而像在说
// 「别看这个」。它们本身也确实被别的文件 import（axes 那几张）或被 README 引用。
//
// 一条设定除了 iota-hit，还能写在哪几页上。
//
// *这张表是唯一的抄本。* 页面级收不收某条设定、报错该指向哪儿，全查它——
// 先前那份白名单在 toc.typ 里另抄了一遍（for-page 的 accepts:），一份信息两处
// 手抄，必然烂一份。
//
// 表与页函数的签名仍是两处，Typst 没法从表里长出参数来；靠 tests/check-settings.py
// 遍历这张表逐项调用来锁住——分家了当场红。
#let setting-homes = (
  // *三页都收*——先前只登记了 toc，而 lof / lot 的签名里同样有它、也真接上了
  // 下游：用户写 #lof(overrides: (heading-body-indent: 2em)) 会被告知「这一页不收」，
  // 可它收。表说反话比表不全更坏
  "heading-body-indent": ("toc", "lof", "lot", "loe"),
  "appendix-numbering": ("appendix",),
  "outline-entry-right-margin": ("toc", "lof", "lot", "loe"),
  "outline-entry-number-align": ("toc", "lof", "lot", "loe"),
)

// 题序与标题之间那一档的 auto 解成什么，按*文档语言*：空几个字。
//
// zh 那档出自本科指南 3.2「与标题间空 2 个半角字符」与两份范例（章 ~17.9、
// 节 ~15.8、条 ~14.7，都是那一级自己的一个字宽），见 setting-defaults 里的
// heading-body-indent；en 那档 0.5 是*暂定值（2026-08-31），待英文版范例
// 核验*——量到了改这张表。
//
// *存字数不存长度*：「一个字」在标题（本级字号的 chars）、页眉（1em）、
// 目录（目录版面的 chars）折出来是三个不同的数，各消费点自己折才对。
//
// *按级存，因为人文社科那档按级不同。* 两份指南的「表2」说明是同一句
// （节到款合并的那一格：「题序顶格书写，与标题间空 2 个半角字符」），但*范例
// 里不是这么排的*——《博士研究生学位论文书写范例（人文社科类）》逐条量：
// 「一、问题的提出」「（一）课题来源」*不空*，「1. 认知风险」空一个半角，
// 章仍拉开。编号自带顿号与括号，本来就分开了，再空一个字反而散。按证据次序
// 范例压过指南原话，所以人文社科档存 (1, 0, 0, 0.5)。
//
// *按 doc-lang 不按那一页的语言*：这个间距定的是编号列的宽度，页眉、目录、
// 正文标题跨页共用，一本论文里只能有一个值——中文档的英文目录（Contents 那一份）
// 若换成半个字，两份目录的编号列就对不齐了。resolver 收的是 doc-lang，
// 每页语言递不进来，这条是结构保证的。
// *深圳研究生那两份报告是 1 个半角*，不是 2 个：说明页的层次表上多着一句
// 「题序顶格书写，*与标题间空1个半角字符*，阐述内容另起一段」（本部三份的
// 同一张表上没有这半句，本科指南 3.2 写的是 2 个半角）。原件量得实：深圳中期
// 正文的「1 课题主要研究内容及进度」，数字尾到首字 7.44 ＝ 小三 15.12 的半个字。
//
// *深圳本科那两份不在其内*——它们的说明页只列了各级标题的字体字号，没提这
// 一档，排出来是一个字（开题量得 18.00 ＝ 小二一个字宽）。
#let report-heading-body-indent = (shenzhen: (master: (chars: 0.5), doctor: (chars: 0.5)))

// 题注里*编号与题名之间*空多少的 auto 档，按文档语言。取值与依据见上面
// 原生的 figure.caption(separator:)：用户没写时用这一档。
//
// *中文一个字*：本科指南「表序与表名之间空 2 个半角字符」，两份范例印出来
// 也是——中文那边两个半角就是一个全角，中期原件量得「1」→「叶」正好 12.00
// ＝ 小四一个字。
//
// *英文四分之一个字*，那就是 Times 的一个空格。原件敲的就是*一个*
// 空格（深圳本科英文版中期 word/document.xml：「Figure 2-1 Identify…」
// 「Table 2-1 Performance…」，深圳研究生那份中期英文同样是一个），排出来
// 「1」→「P」量得 2.595 ／ 10.56 ＝ 0.246 个字。
//
// *与标题那一档不同数，别照抄。* 同一份原件里标题敲的是两个空格、排出来
// 是一个字（见下面 heading-body-indent-auto 的量），题注敲一个、排出来就只有
// 0.25 个字——跟排出来的数，不跟哪一条叙述。
//
// *英文那一档写宽了：真正验过的只有深圳那两份（本科中期、研究生中期）。*
// 这一格按语言分，于是所有英文档都吃它——本部的英文档、英文论文都没验过。
// 本部博士范例的英文题注*自己都不一致*（第 14 页 Fig. 后一个空格、第 15 页
// 两个），给不出定数，所以没为它另分一档；而深圳本科英文版写作指南 2.12／2.13
// 的*叙述*写的是「separated by 2 half-width spaces」，与它自家表单印出来的
// 一个空格对不上——这儿跟的是排出来的样子。哪天本部的英文件能定下来，这一张
// 该改成按校区（或按 stage）分档，别把 0.25 个字当成全档通用。
#let caption-separator-auto = (zh: (chars: 1), en: (chars: 0.25))

#let heading-body-indent-auto = (
  zh: (
    // 理工类：四级都空一个字（指南 3.2「与标题间空 2 个半角字符」，两份范例也是）
    stem: ((chars: 1), (chars: 1), (chars: 1), (chars: 1)),
    // 人文社科类：节与条不空、款空半个字，见上面那段
    hass: ((chars: 1), (chars: 0), (chars: 0), (chars: 0.5)),
  ),
  // *英文档四级也是一个字*，与中文那一档同数——先前写的是半个字（暂定值，
  // 注着「待英文版范例核验」）。核验的是 2026 年 9 月版*深圳本科英文版*
  // 那两份表单，逐级量原件（号末到名首）：
  //
  //   章  「1」107.69 →「M」126.04   18.35 ／ 18    ＝ 1.02 个字
  //   节  「1」103.77 →「M」119.00   15.23 ／ 15.12 ＝ 1.01
  //   条  「1」112.91 →「P」126.96   14.05 ／ 13.92 ＝ 1.01
  //
  // 原件那三处敲的都是*两个半角*，与中文版一样——中文那边两个半角就是一个
  // 全角，英文这边 Times 的半角只有 0.25em，可*排出来仍是一个字*：那两个
  // 空格各带了约 0.26em 的额外步进。跟排出来的数，不跟敲了几个空格。
  //
  // *这一档也写宽了：验的只有深圳本科英文版那两份表单*，本部的英文件没有
  // 一份带标题实例（留学生那两份的说明页只有条目文字）。所有英文档都吃这一格，
  // 拿到别的档的英文原件要重核。*与题注那一格不同数*（那边是 0.25 个字，见上面
  // 的 caption-body-indent-auto）——同一份原件里标题敲两个空格、题注敲一个。
  // 两个门类同
  en: (stem: ((chars: 1), (chars: 1), (chars: 1), (chars: 1)), hass: ((chars: 1), (chars: 1), (chars: 1), (chars: 1))),
)

// 附录章号那一档的 auto 解成什么，按文档语言、门类与学位。取值与依据见上面
// setting-defaults 里的 appendix-numbering。
//
// *人文社科不分学位*：那一档的附录与正文同一套写法（附录一 ／ 一、／（一）），
// 而正文那一套本来就不按学位分。
//
// *英文档一律用字母*，不分门类学位：英文里附录靠字母与正文分开（Appendix A、
// Table A-1），这是通行写法（APA 的 Table A1、GB/T 7713.1 的「图A.1」都是这个形状），
// 也因此英文不需要「附图」那样的词。数那三档在英文档里照样写得出来（"1"／"一"／
// "One" 都收），只是不做默认；图表公式那一位*在英文档里恒是字母*，不跟章标题
// 的号走，见 src/heading/numbering.typ。
//
// 与 heading-body-indent-auto 同形：外层语言、里层门类
#let appendix-numbering-auto = (
  zh: (
    stem: (bachelor: "1", master: "A", doctor: "A"),
    hass: (bachelor: "一", master: "一", doctor: "一"),
  ),
  en: (
    stem: (bachelor: "A", master: "A", doctor: "A"),
    hass: (bachelor: "A", master: "A", doctor: "A"),
  ),
)

// 附录章号那一位的五档。前四档是*原生 numbering() 认的编号串*，取的是这一串
// 的头一个（"A" → A B C、"I" → I II III、"1" → 1 2 3、"一" → 一 二 三）；"One" 那一档
// numbering 不认识，是我们自己按 en-words 那张表数的，取名照样是头一个词——英文档的
// 附录印的就是「Appendix One」，与英文目录里那一条同一个写法。罗马数字指南里没有，
// 是用户要的：写法与字母那一档同形（附录I ／ I.1 ／ 图I-1）
#let appendix-patterns = ("A", "I", "1", "一", "One")
