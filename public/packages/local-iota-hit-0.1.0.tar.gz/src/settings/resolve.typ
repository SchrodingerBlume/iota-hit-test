// 文档级开关的机制：state 与解析。取值表在 src/settings/defaults.typ，这里 import 来查。
//
// 都由 iota-hit 在最外层写进来，别处只读。

#import "@local/banshi:0.1.0" as banshi
#import banshi.errors as _errors
#import banshi.options as _options
#import "../axes.typ": report-stages
#import "./defaults.typ": (
  appendix-numbering-auto, appendix-patterns, caption-bilingual-auto, caption-numbering-by-chapter-auto,
  algorithm-style-auto, raw-style-auto, em-dash-auto, equation-numbering-by-chapter-auto, heading-body-indent-auto, openright-auto,
  report-caption-by-section,
  setting-defaults, setting-homes,
)

#let settings-state = state("iota-hit-settings", none)

// 文档级覆盖。*只由 iota-hit 的具名参数喂*——用户不再能把设定写进
// overrides，那条路在 src/terms/lookup.typ 的 _resolve-key 里当场报错。
#let settings-overrides(value) = {
  for (key, v) in value {
    if key not in setting-defaults {
      panic(
        "unknown setting: " + key + " (" + _errors.one-of(
          setting-defaults.keys().map(k => repr(k)),
        ) + ")",
      )
    }
  }
  settings-state.update(old => (
    if old == none { setting-defaults } else { old }
  ) + value)
  // *Word 那一层的几个开关转发过去*（伪粗、伪斜、列表悬挂）：
  // 消费它们的 show 规则在 banshi/src/options.typ 那个 state 里读，不读这儿的
  _options.options-overrides(value.pairs().filter(((k, _)) => k in _options.option-defaults).to-dict())
}

// 取一个取值。与 terms 的 term-of 对位，*要在 context 里调*
#let setting-of(key) = {
  let v = settings-state.get()
  let all = if v == none { setting-defaults } else { v }
  if key not in all { panic("unknown setting: " + key) }
  all.at(key)
}

// 认得出这个键吗。overrides 的分派与词条那边的报错都要用它试探，
// 所以*不报错*，认不出给 none。
#let lookup-key(flat) = if flat in setting-defaults { flat } else { none }

// 「它是设定不是词条」这句话。*文案从 setting-homes 生成，不手抄。*
#let not-a-term(key, page: none) = {
  let homes = setting-homes.at(key, default: ())
  key + " is a setting, not a term (" + (
    if page == none {
      "settings are named arguments: iota-hit(" + key + ": ...)"
    } else if page in homes {
      "write " + page + "(" + key + ": ...)"
    } else {
      "the " + repr(page) + " page does not take it; write iota-hit("
        + key + ": ...)"
    }
  ) + ")"
}

// 题注编号按不按章。两层：这次调用 → 默认表。
//
// *它不进 settings-state。* 别的开关进 state 是因为部件要在文档中途读；
// 这一个只在 iota-hit 装 show 规则那一刻用一次，读 state 反而要在写入的同一个
// context 里读刚写的值——那正是 cover-exited 那次不收敛的坑。所以由 iota-hit
// 解出来当参数传给 caption-rules。
#let resolve-caption-numbering-by-chapter(
  local: auto, stage: "final", campus: "harbin", degree-level: "doctor",
) = {
  if local != auto { return local }
  // *按顶层标题编号的那几份报告单列*，见 src/settings/defaults.typ 的
  // report-caption-by-section：本部本科开题、深圳硕博中期
  if stage in report-caption-by-section
    .at(campus, default: (:))
    .at(degree-level, default: ()) { return true }
  caption-numbering-by-chapter-auto.at(stage, default: caption-numbering-by-chapter-auto.final)
}


// *解出来的那个值*，由 iota-hit 写进来，供*文档中途*的部件读——插图与
// 表格索引里的编号得与题注一致（先前 #lof 硬写 true：文档级写了 false 时正文印
// 「图1」、索引却印「图 1-1」，而那个 1- 连按章的口径都不成立）。
//
// *存的是解好的值，不是原始设定*——原始设定不进 state 的理由见上面那一段
// （在写入的同一个 context 里读刚写的值会不收敛）；这一份是 iota-hit 先算好再写，
// 读它的 #lof / #lot 排在文档中途，与写入不在同一个 context 里
#let caption-by-chapter = state("iota-hit-caption-by-chapter", caption-numbering-by-chapter-auto)
// 公式编号按不按章，同上：公式清单在文档中途读它
#let equation-by-chapter = state("iota-hit-equation-by-chapter", equation-numbering-by-chapter-auto)

#let resolve-equation-numbering-by-chapter(local: auto, stage: "final") = {
  if local != auto { return local }
  equation-numbering-by-chapter-auto.at(stage, default: equation-numbering-by-chapter-auto.final)
}

// 局部 → 文档级 → 按语言与门类、逐级的默认表，每一层都用 auto 表示「我不表态」。
// 返回长度或 (chars: n)，折算各消费点自己做（chars.resolve-chars／页眉的 n × 1em）。
// *写死了就四级同值*——用户写一个数是「这篇论文的编号后就空这么多」。
//
// *附录不另开一档*：附录里的编号与正文同一套写法（理工「附录A ／ A.1」、
// 人文社科「附录一 ／ 一、／（一）」，见 src/layout/matter.typ），间距自然跟着
// 同一行取值走。
#let resolve-heading-body-indent(local: auto, lang: "zh", category: "stem", level: 1) = {
  let value = if local != auto { local } else { setting-of("heading-body-indent") }
  if value != auto { return value }
  let by-lang = heading-body-indent-auto.at(lang, default: heading-body-indent-auto.zh)
  let by-category = by-lang.at(category, default: by-lang.stem)
  by-category.at(calc.min(level, by-category.len()) - 1)
}

// 缩略语进不进索引：逐条 → 这一次调用 → 文档级 → 默认（不进）。
// 每层 auto ＝ 不表态，见 setting-defaults 里的 abbreviation-indexed
#let resolve-abbreviation-indexed(entry: auto, local: auto) = {
  if entry != auto { return entry }
  if local != auto { return local }
  let gate = setting-of("abbreviation-indexed")
  if gate != auto { return gate }
  false
}

// 局部 → 文档级 → 按语言、门类与学位，每一层都用 auto 表示「我不表态」，与 toc
// 那一处的 heading-body-indent 同形
#let resolve-appendix-numbering(local: auto, degree-level: "doctor", category: "stem", lang: "zh") = {
  let value = if local != auto { local } else { setting-of("appendix-numbering") }
  if value != auto {
    if value not in appendix-patterns {
      // *传裸值*——expected-one-of 内部会 map(repr)，先前传了带引号的串，
      // 排出来是 expected "\"A\"", "\"1\"", or "\"一\"" 这种双重引号
      panic(_errors.expected-one-of(appendix-patterns, value) + " (appendix-numbering)")
    }
    return value
  }
  let by-lang = appendix-numbering-auto.at(lang, default: appendix-numbering-auto.zh)
  let by-category = by-lang.at(category, default: by-lang.stem)
  by-category.at(degree-level, default: by-category.bachelor)
}

// 某个切页点跳不跳。四层，逐层让位：
//
//   local   这次调用自己的参数（或标题正文里的记号）
//   matter  所在那一段的显式取值——frontmatter 罩着 titlepage 与前置各章，
//           backmatter 的兜底是 mainmatter 已解出的值
//   总闸    iota-hit 的 openright
//   默认表  按学位，见 openright-auto
//
// 每一层都用 auto 表示「我不表态」。
#let resolve-openright(point, degree-level: "doctor", local: auto, matter: auto) = {
  if local != auto { return local }
  if matter != auto { return matter }
  let gate = setting-of("openright")
  if gate != auto { return gate }
  openright-auto.at(degree-level, default: openright-auto.bachelor).at(point)
}

// 伪代码的样子：设定里的字典并到默认上，没写的键、写 auto 的键取默认；不认识的键、
// 不在档内的值当场报错。要在 context 里调
// from：不从 state 读、直接解这个值（lib.typ 入口处 show-set 要用，那儿 state 还没写）
#let resolve-algorithm-style(from: none) = {
  let given = if from == none { setting-of("algorithm-style") } else { from }
  let given = if given == auto { (:) } else { given }
  if type(given) != dictionary {
    panic("algorithm-style: expected auto or dictionary, found " + repr(given))
  }
  let allowed = (
    frame: ("tabular", "ruled", "boxed"),
    keyword-case: ("upper", "lower", "title"),
    indent-guide: ("bar", "hook", none),
  )
  for (k, v) in given {
    if k == "line-numbering" {
      // 编号记法：字符串或 none，照 Typst 的 numbering
      if v != auto and v != none and type(v) not in (str, function) {
        panic("algorithm-style.line-numbering: expected numbering pattern (string), a function, or none, found " + repr(v))
      }
      continue
    }
    if k not in allowed {
      panic("algorithm-style: unknown key " + repr(k) + " (" + _errors.one-of((allowed.keys() + ("line-numbering",)).map(repr)) + ")")
    }
    if v != auto and v not in allowed.at(k) {
      panic("algorithm-style." + k + ": " + _errors.expected-one-of(allowed.at(k), v))
    }
  }
  let out = algorithm-style-auto
  for (k, v) in given { if v != auto { out.insert(k, v) } }
  out
}

// 代码清单的样子，与 resolve-algorithm-style 同一个办法。要在 context 里调
#let resolve-raw-style(from: none) = {
  let given = if from == none { setting-of("raw-style") } else { from }
  let given = if given == auto { (:) } else { given }
  if type(given) != dictionary {
    panic("raw-style: expected auto or dictionary, found " + repr(given))
  }
  let frames = ("tabular", "ruled", "boxed", none)
  for (k, v) in given {
    if k == "line-numbering" {
      if v != auto and v != none and type(v) not in (str, function) {
        panic("raw-style.line-numbering: expected numbering pattern (string), a function, or none, found " + repr(v))
      }
    } else if k == "frame" {
      if v != auto and v not in frames {
        panic("raw-style.frame: " + _errors.expected-one-of(frames, v))
      }
    } else {
      panic("raw-style: unknown key " + repr(k) + " (" + _errors.one-of(("frame", "line-numbering").map(repr)) + ")")
    }
  }
  let out = raw-style-auto
  for (k, v) in given { if v != auto { out.insert(k, v) } }
  out
}

// 破折号排哪一副字。这次调用 → 按分支查 src/settings/defaults.typ 的 em-dash-auto
// （表里列的是 "latin" 那几档）。*不进 state*：字体表在 iota-hit 最外层解一次，
// 值随表走（banshi/src/fonts/resolve.typ 的 resolve），别处读表不读它。
#let resolve-em-dash(local: auto, campus: "harbin", degree-level: "doctor", stage: "final") = {
  if local != auto {
    if local not in ("cjk", "latin") {
      panic(_errors.expected-one-of(("cjk", "latin"), local) + " (em-dash)")
    }
    return local
  }
  if stage in em-dash-auto.at(campus, default: (:)).at(degree-level, default: ()) { "latin" }
  else { "cjk" }
}

// 题注排不排双语。三层：这次调用 → 总闸 → 按学位的默认表。要在 context 里调。
#let resolve-caption-bilingual(degree-level: "doctor", stage: "final", local: auto) = {
  if local != auto { return local }
  let gate = setting-of("caption-bilingual")
  if gate != auto { return gate }
  let by-stage = caption-bilingual-auto.at(stage, default: caption-bilingual-auto.final)
  by-stage.at(degree-level, default: by-stage.bachelor)
}

// *分图题*排不排双语。局部 → 文档级 → *不排*。与图题那一档分开：
// 规范说分图题「可以只用中文书写」，双语那句点的是图题与表题，见 config 那张表
#let resolve-subcaption-bilingual(local: auto) = {
  if local != auto { return local }
  let gate = setting-of("subcaption-bilingual")
  if gate != auto { return gate }
  false
}

// 图题与连排分图题之间插什么。局部 → 文档级 → *什么都不插*。长度折成 v()，
// 内容原样交回，见 config 那张表
#let resolve-subcaption-gap(local: auto) = {
  let value = if local != auto { local } else { setting-of("subcaption-gap") }
  if value == auto or value == none { return none }
  if type(value) == length { return v(value, weak: false) }
  value
}

