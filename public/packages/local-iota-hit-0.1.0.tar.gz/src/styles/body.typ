// 接到正文上。
//
// 换算层算出来的行盒在这里落到 Typst 的三个 set 上。对照 hithesis 的
// src/utils/hit-format.dtx「接到正文上」一节——那边要写的东西比这里多得多，
// 因为 TeX 的行高是「这一行各个字形外框的最大值」，得靠一根撑杆
// （\hit@format@strut:）把每一行的行盒撑成 Word 的尺寸，还要另外接
// \topskip、\maxdepth、\@colroom 与 \flushbottom 四处。
//
// Typst 的 top-edge / bottom-edge 写成显式长度之后就是 Word 那个固定行盒：
//
//   行盒高   = top-edge + |bottom-edge|
//   基线落点 = top-edge
//   基线步进 = 行盒高 + leading
//
// 所以撑杆、\topskip 与那几个换页补丁在这边一个都不用写，见下面的注解。

#import "../paragraph/linebox.typ" as linebox
#import "./rules.typ" as style-rules
#import "../paragraph/latin.typ" as western
#import "./sheet.typ" as sheet
#import "../paragraph/linebox.typ" as linebox
#import "../fonts/resolve.typ" as fonts
#import "../msword.typ": latin-run, latin-par-tag
#import "../fonts/tracking.typ": tracking-pad
#import "../layout/resolve.typ" as _layout

// 把算出来的行盒装到 Typst 上。
//
// 一、行距。leading 置零，行盒高与基线落点全由 top-edge / bottom-edge 定。
//     写成显式长度还有一层用处：它完全盖掉字体自己的度量。hithesis 一律按
//     中易那一系的 1.296875 排，不问实际加载的是哪一个宋体，好让换字体不动版面；
//     这里同理——苹方的自然行高是 1.82，差了四成，但排出来逐条基线不变。
//
// 二、首行基线。Typst 把首行的行盒顶放在版心顶，基线因此落在版心顶下方一个
//     top-edge 处，正是 Word 的规则四（版心顶到首行基线的距离等于首行基线在
//     自己行盒里的落点）。不用另设 \topskip。
//
// 三、换页判据。Word 要末行的行盒底不越版心底，TeX 比的却是末行基线，差一个
//     行深，所以 hithesis 要把 \@colroom 与 \vsize 各减掉一个行深。Typst 的
//     行盒本来就带着 bottom-edge 那一段进页面高度的账，判据天然与 Word 一致。
//
// 四、孤行寡行。范例的 Normal 样式写着 widowControl=0，全文 566 个段落没有一个
//     覆盖它，也就是孤行寡行控制全程关闭。Typst 默认会拦，costs 置零放开——
//     不放开的话，该排 33 行的页面会被压成 32 行。
//
// 五、段前段后。Word 相邻两段取段后与段前的较大者，不相加；Typst 的块间距
//     也是取大者，语义正好相同。两个值不等时 Typst 表达不出来，正文这一档
//     Word 里本来就是 0/0，不受影响。
//
// 六、横轴只用 tracking 调到与 Word 大体一致，不追精确。字距发的是
//     网格字距减字号，汉字因此撑满一格。
//
//     *行末余量没有接。* Word 的行宽是「版心宽减一个字距增量」——行末
//     那个字不带增量。不扣这一段，Typst 会把整行拉满版心，偏差从行首往
//     行尾线性累积：第 1 字 0.0138pt，第 17 字 0.2208pt，行末 0.4543pt
//     （0.16mm）。断行位置不受影响，34 个字自然宽 423.4462，两种版心都是
//     放得下 34 个、放不下 35 个，逐行断点相同。
//
//     算法留在换算层的 linebox.line-end-slack 里，接上去只要把下面那两行放开。
//     0.16mm 与横轴上其余几处已有的偏差同级（汉字接拉丁字母 0.4543、
//     中西文间距 0.064），所以按「大体一致」这个目标不接。
//
//     再细的更不追：Word 那边是逐字符的刚性格子加按需的标点压缩，
//     Typst 没有这个粒度。
//
// 七、两条边不写成算好的长度，写成「em 系数 + 绝对量」的复合长度，
//     取值由换算层的 top-edge / bottom-edge 给。写死长度的话行盒纹丝不动，
//     行内混进的大字会直接压到上下两行的墨迹上；写成复合长度就跟着该 run 的
//     字号长高，与 Word 的「一行的行高取这一行实际用到的各个字体的最大值」
//     一致，也与 hithesis 那根按 \f@size 现算的撑杆一致。
//
//     两截分开记是必须的：上升部是 1.008 × 字号 + 0.082pt，那个常数项不随
//     字号缩放。整个量先折成一个数再按比例套给别的字号的话，常数项会跟着
//     被缩放一次，混排行差 0.082pt。分开记之后 1.008em + 0.082pt 原样写进
//     top-edge，任何字号都精确。
// 版心由 src/layout/rules.typ 的 page-rules 设，这里只管字与段。
//
// *这里只装 show 规则。* 正文那一档的 set text / set par 是「一节的 set」的一部分，
// 由 src/layout/section.typ 的 section-sets 发——iota-hit 在文档级发一次，三个 matter 用
// 段级并好的版面再发一次（set 规则内层压外层、不叠加）。show 规则绝不能重发（latin-run
// 那条会在西文前补 h(tracking)，重发就补两次），所以只在这里装一次，规则里用到版面的
// 数都在各自的 context 里从 layout-state 取（style-rules.shows 的 current），不用装规则时
// 捕获的那份。layout 是文档级那一份，只管「装不装」，见 style-rules.shows。
#let body-rules(layout, style, doc) = {
  // 字与段的 show 规则交给部件层，正文与封面、标题共用同一套。
  show: style-rules.shows.with(style, layout: layout, current: true)

  // *强调用楷体，不用斜体*——汉字没有斜体，Typst 的 emph 会给它*合成*
  // 一个倾斜，那是把西文的做法硬套在汉字上。中文排版里强调历来是换字体（楷体）
  // 或加着重号；hithesis 也是走楷体那一档（\kai）。
  //
  // *夹在中间的西文照旧斜体。* 西文有真正的斜体字面，换成楷体反而不对。
  // 靠 latin-run 那条正则把西文段挑出来单独设 style: "italic"，与「中文行里的
  // 西文要不要加粗」是同一套办法，见 src/styles/rules.typ 的 latin-bold。
  //
  // *直接排 it.body，不走默认的 emph*——默认那条会先把整段设成 italic，
  // 汉字就已经被合成倾斜了，再换字体也回不来。
  // *补偿要自己发。* 两条 show emph 里*后定义的先执行*，这一条把 emph
  // 元素换掉之后，src/fonts/tracking.typ 那条 show emph: tracking-pad 就再也匹配不到，
  // run 边界上那段字距会丢（实测「字→强」步进掉回 12.0000，该是 12.4543）。
  // 所以这里自己套一次 tracking-pad——它本来就是给这种 run 边界准备的。
  // 夹的西文斜体由 fonts.kaishu 的 italic 那一档发（整段 set style italic，楷体落空、Times 换上
  // 真斜体面），数字、希腊字母也斜——先前这儿靠 show latin-run 挑字母，#emph[2026] 不斜
  show emph: it => tracking-pad(
    fonts.kaishu(it.body, italic: true),
    // 判据要拿*原件*去判：重建出来的那一坨是 context 块，plain 钻不进去
    probe: it.body,
  )

  // 纯西文行按西文的行高系数排，理由与代价见 styles.typ 的 latin-line-rules。
  //
  // *挂在 par 上，不挂在整篇文档上。* 挂在文档上的话它会漏进标题：
  // 同一属性上外层赢，标题里按本级行距重发的那一条压不过它，于是西文章标题
  // 的行盒拿到*正文*的 1.25 倍——实测盒高 25.87 = 1.25×1.15×18，
  // 而章标题该用 1.2（24.84），行深 9.01 而不是 7.97，摘要页的
  // 「Abstract → 首行」因此比 Word 大 0.88。
  //
  // 标题的内容不是 par（实测 show par: 改不到它），圈进 par 就正好把标题让开，
  // 而每一段正文照样收到。
  //
  // *还要把部件自己的段落让开。* 目录条目为了做悬挂缩进要发一个显式的
  // par（指南 3.6：折行后缩进至标题首字处），而 hanging-indent 只有直接给
  // par 才吃得上——set 无论放在 box 里、block 里还是外层都不生效。那个 par
  // 一旦出现就会被这一条罩住：同一属性上外层赢，这一条在文档层、目录那条在
  // 里层，于是目录里的西文条目行距被从 1.2 改回正文的 1.25，实测步进
  // 17.25 而不是 16.56。
  //
  // 判据读 text.features 里的 latin-par 标签（src/msword.typ）：正文的 sets
  // 与索引写 1，别的部件写 0。这是个样式查询，不进布局回路，不会像 here().position()
  // 那样不收敛。
  // 正文那一档的西文断字。默认关（范例的 settings.xml 里没有 w:autoHyphenation），
  // 见 src/settings/defaults.typ 的 hyphenate
  show: western.hyphenate-rules

  // *守门按声明，不按数值。* 先前比的是 text.top-edge 的 em 式子等不等于正文那份
  // ——页眉写同一个式子就漏进来（混排页眉整行抬 1.944，只好把页眉的行盒边改写成 pt
  // 躲开），索引则是碰巧相等才吃到（它的西文 run 靠这条拿西文行盒，边界字距补偿也按
  // 这个结构定，一收紧就右移 0.91）。现在谁要谁声明：section-sets 与索引写
  // latin-par: true，其余 style-rules.rules 与页眉的 styled 写 0，这里只读那一位。
  // 行盒与网格按当前这一节的版面现算：段级改了 latin-line-height 或行跨度，这里跟着
  //
  // *整段没有汉字的段落整段换。* 逐 run 换会漏掉不含拉丁字母的碎片（两对引号
  // 之间的「, 」），整段换就没有漏网的；英文摘要、英文版全文的正文段都自动走这一支，
  // 不用任何标记，见 src/paragraph/latin.typ 的 latin-par。判据拿段落的字面文字看有没有
  // 汉字（msword.typ 的 has-cjk），空段落不算。
  show par: it => context {
    if text.features.at(latin-par-tag, default: 0) != 1 { return it }
    // *原生的 leading 挡住并出声。* 本包的行盒按 Word 的模型算：leading 置零，
    // 整个行高写在 top-edge / bottom-edge 上（见 src/styles/rules.typ 的 sets）。
    // 用户写的 set par(leading: 8pt) 不是被忽略，是*加在我们的行盒上*——排出来
    // 一行 27.45 而不是 8，写了什么就不是什么了。这类「写得进去、意思变了」的才挡；
    // set par(spacing:) 与 first-line-indent 说什么就是什么，让开不管。
    if par.leading != 0pt {
      // *把这一档现在的行距报出来*：用户要改的正是它，写法也在同一句里
      panic(
        "set par(leading: " + repr(par.leading) + ") does not set the line spacing "
          + "here: this template keeps leading at zero and puts the whole line box "
          + "into the text edges (Word's model), so your value is added on top of it. "
          + "The body line spacing is currently "
          + repr(sheet.styles-state.get().body.at("line-spacing", default: auto))
          + "; write iota-hit(styles: (body: (line-spacing: ...))) to change it",
      )
    }
    let layout = _layout.current-layout()
    // *章级版面*：#chapter(layout:) 把这一章的网格写进了 layout-state，而正文那档的
    // set text(字距、行盒边)是 section-sets 按这一节发的，改不到这一章；两份不同时在
    // 这儿按当前那份重发一遍——与 sets 同一个式子（src/styles/rules.typ），引擎画网格那档
    // 连 set par(linebreaks:) 一起。相同时一句不发，与先前逐字节相同
    let section = _layout.section-layout-state.get()
    if section != none and layout != section {
      // *引擎画网格那档，段要重造。* par 的 linebreaks 在收段时就按样式链定死了，show
      // 规则里再 set 改不到（实测步进纹丝不动）；只能把这一段按当前那份 linebreaks 重造
      // 一遍——重造的段再进这条规则时 fields 里已带着它，不再重造。代价是这一段的 span
      // 换了人（tinymist 跳回源码落进本文件），只在章级改了网格又走引擎时付
      let lb = layout.docgrid.at("linebreaks", default: none)
      if lb != none and it.fields().at("linebreaks", default: none) != lb {
        let f = it.fields()
        let body = f.remove("body")
        return par(..f, linebreaks: lb, body)
      }
    }
    // 判据与「换成哪一份」都在 western.latin-auto 里，标题与题注走的是同一条
    let out = western.latin-auto(style, layout, it)
    if section == none or layout == section { out } else {
      // 套在外面：纯西文段自己那份（latin-par 的半份字距、西文行盒）在里层，照旧赢
      let computed = linebox.resolve(style, docgrid: layout.docgrid)
      set text(
        tracking: western.set-tracking(style, computed),
        top-edge: computed.top-edge, bottom-edge: -computed.bottom-edge,
      )
      out
    }
  }

  // 行末余量要接的话放开下面四行。收窄的是\段落的排版宽度，不是版心：
  // 整篇包一层 block 不行——那是容器，章标题的 pagebreak 进不去；而且标题
  // 不该吃这一段，LaTeX 那边标题走 \centering，它自己把 rightskip 设成
  // 0pt plus 1fil，本来就不吃。所以要挂在 par 上，并在标题块里关掉
  // ——src/heading/rules.typ 里那句 show par: it => it 就是为它留的。
  // 放开之后记得把 linebox.line-end-slack 加回本文件顶上的 import；版面与行盒同上面
  // 那条一样在 context 里按当前这一节取。
  //
  // show par: it => context {
  //   let layout = _layout.current-layout()
  //   let metrics = linebox.metrics(style, layout: layout)
  //   let slack = linebox.line-end-slack(metrics, text-width: layout.text-width, cells: layout.cells)
  //   let spacing = calc.max(metrics.above, metrics.below)
  //   if slack == 0pt { it } else {
  //     block(width: layout.text-width - slack, above: spacing, below: spacing, it)
  //   }
  // }

  doc
}
