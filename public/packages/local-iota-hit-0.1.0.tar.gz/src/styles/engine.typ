#import "@local/docxtyp:0.1.0" as d
#import "../fonts/resolve.typ": fontset as _fontset, fontset-state
#import "../fonts/style.typ": ready, resolve as _resolve, renderer, resolve-tree, typography
#import "./sheet.typ": styles as _styles
#import "./state.typ": current-styles
#import "./local.typ": new-styles as _new-styles, restore-styles
#import "./figure.typ": figure-spacing as _figure-spacing
#import d.paragraph: block-spacing, inline-math, rules as _rules
#import d: par as _paragraph
#import d.content: plain-text
#import d.paragraph: use-latin-metrics
#import "../fonts/presets.typ": zh-roles, en-roles
#let _defaults = _fontset()
#let native-format(value) = value.pairs().filter(((key, _)) => key in d.paragraph.format-keys).to-dict()
#let _arguments(args) = {
  let values = args.named()
  if "layout" in values {
    if "page-setup" in values { panic("expected layout or page-setup, not both") }
    values.insert("page-setup", values.remove("layout"))
  }
  values
}

// 字体角色与 latin-bold 的校验和逐层合并归 iota。
#let _policy-keys = ("asian-font", "latin-font", "latin-bold")
// 只剥样式记录内的策略键，表顶层的错误键仍交给底层校验。
#let _without-policy(table, record: false) = table.pairs().filter(((key, _)) => not record or key not in _policy-keys).map(((key, value)) => (
  key, if type(value) == dictionary and key != "font" { _without-policy(value, record: true) } else { value },
)).to-dict()
#let _with-policy(table, base, preset, local) = {
  let result = table
  for (key, value) in table {
    if type(value) == dictionary and key != "font" {
      let child(source) = {
        let v = source.at(key, default: (:))
        if type(v) == dictionary { v } else { (:) }
      }
      result.insert(key, _with-policy(value, child(base), child(preset), child(local)))
    }
  }
  for source in (base, preset, local) {
    for key in _policy-keys {
      if key in source { result.insert(key, source.at(key)) }
    }
  }
  result
}
#let _check-policy(table) = {
  for (key, value) in table {
    if key == "latin-bold" and type(value) != bool { panic("latin-bold: expected true or false") }
    if key == "asian-font" and value not in zh-roles { panic("asian-font: unknown iota font role " + repr(value)) }
    if key == "latin-font" and value not in en-roles { panic("latin-font: unknown iota font role " + repr(value)) }
    if type(value) == dictionary and key != "font" { _check-policy(value) }
  }
}
#let styles(base, local, preset: (:)) = {
  if type(base) != dictionary or type(local) != dictionary or type(preset) != dictionary {
    return _styles(base, local, preset: preset)
  }
  _check-policy(base)
  _check-policy(local)
  _check-policy(preset)
  let result = _styles(_without-policy(base), _without-policy(local), preset: _without-policy(preset))
  _with-policy(result, base, preset, local)
}

#let paragraph(body, style, ..args) = {
  if ready(style) and args.named().at("metrics", default: auto) == auto {
    let words = plain-text(body)
    let latin = args.named().at("latin", default: auto)
    let latin = if latin == auto { use-latin-metrics(words) } else { latin }
    return _paragraph(body, native-format(style), rules: renderer(style, latin: latin), .._arguments(args))
  }
  context {
    let resolved = _resolve(style, fontset-state.get(), metrics: args.named().at("metrics", default: auto))
    let words = plain-text(body)
    let latin = args.named().at("latin", default: auto)
    let latin = if latin == auto { use-latin-metrics(words) } else { latin }
    _paragraph(body, native-format(resolved), rules: renderer(resolved, latin: latin),
      .._arguments(args).pairs().filter(((k, _)) => k != "metrics").to-dict())
  }
}
/// 将一条模板样式解析成完整内容范围的有效格式；索引等连续段落流使用。
#let format(style, body, layout: auto) = context {
  let resolved = if ready(style) { style } else { _resolve(style, fontset-state.get()) }
  let extra = renderer(resolved)
  show: if extra == none { it => it } else { extra }
  d.paragraph.format(native-format(resolved), page-setup: layout, body)
}
#let rules(style, doc, ..args) = {
  if ready(style) {
    return _rules(native-format(style), rules: renderer(style, latin: args.named().at("latin", default: false)), .._arguments(args), doc)
  }
  context {
    let resolved = _resolve(style, fontset-state.get())
    _rules(native-format(resolved), rules: renderer(resolved, latin: args.named().at("latin", default: false)), .._arguments(args), doc)
  }
}
#let new-styles(local, body) = context {
  let f = fontset-state.get()
  let cur = current-styles()
  let merged = styles(cur, local)
  let resolved = (:)
  for (name, value) in local {
    resolved.insert(name, resolve-tree(((name): merged.at(name)), f).at(name))
  }
  _new-styles(resolved, if "body" in resolved { typography(resolved.body, body) } else { body })
}
#let figure-spacing(layout, metrics, ..styles) = {
  let resolved = styles.named().pairs().map(((k, v)) => (k, _resolve(v, _defaults, metrics: metrics))).to-dict()
  _figure-spacing(layout, none, ..resolved)
}
