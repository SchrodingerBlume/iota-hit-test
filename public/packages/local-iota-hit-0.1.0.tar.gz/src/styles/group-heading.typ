#import "@local/banshi:0.1.0" as banshi
#import banshi.styles: paragraph
#import banshi.fonts as _synth

#let group-heading(body, layout) = paragraph(
  context {
    let b = text(weight: "bold", body)
    if _synth.wants-bold-for("songti") { _synth.fake-bold(b) } else { b }
  },
  (
    snap-to-grid: false, line-spacing: 1.25,
    first-line-indent: (chars: 0), above: 5pt, below: 5pt,
  ),
  layout: layout,
)
