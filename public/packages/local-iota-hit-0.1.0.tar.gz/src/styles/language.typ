// 中文档未标注的西文在开启断字时按英语处理，显式指定的其他语言不变。
#let hyphenate-rules(doc) = {
  let latin-run = regex(
    "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
      + "\p{Latin}"
      + "[\u{0020}-\u{0021}\u{0023}-\u{0026}\u{0028}-\u{024F}\u{2013}]*"
  )
  show latin-run: it => context {
    if text.hyphenate == true and text.lang == "zh" { set text(lang: "en"); it } else { it }
  }
  doc
}
