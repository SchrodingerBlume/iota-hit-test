// 安装和恢复局部样式；状态合并逻辑位于 state.typ。
#import "./sheet.typ" as sheet
#import "@local/docxtyp:0.1.0" as d

// 保存进入局部样式前的实际段落设置；文档样式未写出的属性也能恢复。
#let _paragraph-contexts = state("iota-local-paragraph-contexts", ())

// 正文属性属于节级 set rule，修改 state 后还需在局部作用域重新安装。
#let _emit(with-body, body) = if not with-body { body } else {
  context {
    let style = sheet.current-styles().body
    d.paragraph.format(style.pairs().filter(((key, _)) => key in d.paragraph.format-keys).to-dict(), body)
  }
}

/// 在局部 show 作用域内覆盖样式，离开作用域后自动恢复。`local` 的结构与 `styles` 相同。`body` 就地
/// 重装；别的条目只记进当前样式（`current-styles()`），由读它的上层模板在排的时候取。
///
/// ```typ
/// #show: new-styles.with((body: (size: 10.5pt, line-spacing: "single")))
/// 这一段使用五号单倍行距。
/// ```
/// -> content
#let new-styles(local, body) = {
  context {
    sheet.check-local(local, base: sheet.styles-state.get())
    let original = (alignment: align.alignment, justify: par.justify,
      first-line-indent: par.first-line-indent, hanging-indent: par.hanging-indent)
    _paragraph-contexts.update(st => st + (original,))
    sheet.local-styles.update(st => st + (local,))
    _emit("body" in local, body)
    sheet.local-styles.update(st => st.slice(0, -1))
    _paragraph-contexts.update(st => st.slice(0, -1))
  }
}

/// 暂时清空所有局部样式，恢复 `document` 安装的文档级样式。用于嵌套组件不应继承
/// 外层局部正文设置的场合。
/// -> content
#let restore-styles(body) = {
  sheet.local-styles.update(st => st + (none,))
  context {
    let before = {
      let document = sheet.styles-state.get()
      let s = document
      for local in sheet.local-styles.get().slice(0, -1) {
        s = if local == none { document } else { sheet.merge-local(s, local, shape: document) }
      }
      s
    }
    let contexts = _paragraph-contexts.get()
    let with-body = before.body != sheet.styles-state.get().body
    if with-body and contexts.len() > 0 {
      let original = contexts.first()
      set align(original.alignment)
      set par(justify: original.justify, first-line-indent: original.first-line-indent,
        hanging-indent: original.hanging-indent)
      _emit(true, body)
    } else {
      _emit(with-body, body)
    }
  }
  sheet.local-styles.update(st => st.slice(0, -1))
}
