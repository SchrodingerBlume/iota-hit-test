// 按档查样式值——模板这一层：本档与终稿不一样的那几格（src/styles/presets.typ 的
// variant-styles）与目录行距按学位挑。并表、验键那一半是通用的，在 ./sheet.typ；
// 查法与词条一样走 src/terms/lookup.typ 的 term-for
#import "@local/banshi:0.1.0" as banshi
#import "./presets.typ": default-styles, toc-line-spacing-auto, variant-styles
#import "../terms/lookup.typ": term-for
#import banshi.styles as _state

// 当前生效的样式表，没进过 iota-hit 的文档从本档默认表起（见 state.typ 的 current-styles）。
// *要在 context 里调*
#let current-styles() = _state.current-styles(default: default-styles)

// 按档取一条样式值，查 src/styles/presets.typ 的 variant-styles：*先按语言取桶
// （不分语言的 base 桶先并进来），桶里的档位后缀交给 term-for 分辨*——词条用的
// 是同一个查法。档写成具名参数，*报告也是其中一档*（stage）：
//
//     variant-style("body-indent", lang: "en", degree-level: "bachelor",
//                   stage: "interim", campus: "shenzhen")
//
// 终稿那一档不必在调用处判——它自己会落到光键名上（多半是 auto ＝ 不覆盖）。
#let variant-style(name, lang: "zh", ..variant) = term-for(
  variant-styles.base + variant-styles.at(lang), name, variant.named(),
)

// 目录条目的行距按学位挑。局部（用户在 styles: (toc-1: (line-spacing: …)) 写的）
// 不是 auto 就照写的；auto 查 src/styles/presets.typ 的 toc-line-spacing-auto——本科
// 1.25，研究生 1.2。与 src/settings/linebox.resolve.typ 的 resolve-openright 同一个写法。
#let resolve-toc-line-spacing(
  local: auto, degree-level: "doctor", category: "stem",
  stage: "final", lang: "zh",
) = {
  if local != auto { return local }
  // *报告另有一档*，写在键名的 -not-final 上；写 auto 的那几格没有自己的数，
  // 落回下面终稿那一套
  let v = variant-style("toc-line-spacing", lang: lang, degree-level: degree-level, stage: stage)
  if v != auto { return v }
  let by-degree = toc-line-spacing-auto.at(category, default: toc-line-spacing-auto.stem)
  by-degree.at(degree-level, default: by-degree.bachelor)
}
