// 样式记录的形状与合并；文档表和局部状态共用，不读取排版上下文。
#import "@local/docxtyp:0.1.0" as d
#let style-keys = d.paragraph.format-keys

#let is-record(v) = type(v) == dictionary and (
  v.len() == 0 or v.keys().any(k => k in style-keys) or v.values().all(x => type(x) == dictionary)
)
#let sub-keys(base) = if base == none { () } else {
  base.pairs().filter(((k, v)) => k not in style-keys and k not in ("inset", "stroke") and is-record(v))
    .map(((k, _)) => k)
}

#let _merge-entry(current, local, shape) = {
  let result = current + local
  for key in sub-keys(shape) {
    if key in local and key in current {
      result.insert(key, _merge-entry(current.at(key), local.at(key), shape.at(key)))
    }
  }
  result
}

// shape 固定为基准表；某层覆盖不能改变后续覆盖对“子记录/属性值”的判断。
#let merge-table(current, local, shape: auto) = {
  let shape = if shape == auto { current } else { shape }
  let result = current
  for (name, entry) in local {
    result.insert(name, if name in current {
      _merge-entry(current.at(name), entry, shape.at(name, default: current.at(name)))
    } else { entry })
  }
  result
}
