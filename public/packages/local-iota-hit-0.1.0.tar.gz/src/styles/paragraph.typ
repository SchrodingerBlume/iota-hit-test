// 前置页面共用的零件。
//
// 封面、内封、摘要、目录都要用到的三样东西，先前散在 cover.typ 与
// abstract.typ 里，别的页面反过来去 import——目录去封面拿版面、内封去封面拿
// 行、目录又去摘要拿标题。页面之间互相引用，改一处得翻三个文件。放这里，
// 页面模块之间从此互不相识。

#import "../fonts/presets.typ": zihao
#import "./linebox.typ" as linebox
#import "./rules.typ" as style-rules
#import "../text/plain.typ": plain
#import "../fonts/resolve.typ" as fonts
// 排不下时在纸角发的那条红字。
//
// *Typst 没有「警告」这一档*，只有拦编译——为了一页封面卡住整篇文档不
// 合适，所以提示排进页面里，编译照常。提示落在*纸角*上，不占版心、不影响
// 任何基线；走 page 的 foreground 是为了「每一页都有」——溢出时是两页。
//
// 先前只有封面有这一条，内封（中英两页）排不下是*一声不吭*地流到第二页
// 去的，实测所在单位写 62 个字就能触发。三处现在共用这一份。
//
// *字面从词表来，两个都传进来*：body 是「哪一页排不下、该怎么办」，各页
// 各一句（terms.warning-overflow）；off 是「怎么关掉本提示」，三处同一句（base 桶
// 的 warning-false）。先前两样都写死在这儿与调用处，改不动也查不着。
//
// *语言跟着词表那一侧走。* 英文内封读的是 en 侧，字面是英文，字体就不能
// 还是黑体——黑体是中文那一档的无衬线，西文那一档对应的是 sans（见
// src/fonts/presets.typ 的 en-roles）。中文那两页仍走黑体，与先前逐字节相同。
#let overflow-note(body, off, lang: "zh") = place(top + left, dx: 8mm, dy: 8mm, block(
  width: 180mm,
  {
    // 提示自己要有正常行距。这几页把 leading 压成 0、两条边写死了行盒，那是
    // 给版面用的；这段字不属于版面，把默认行为还回来。
    let f = fonts.current.get()
    set text(
      size: zihao.xiaoer, fill: rgb("#cc0000"), weight: "bold",
      font: if lang == "en" { f.sans } else { f.heiti }, lang: lang,
      top-edge: "ascender", bottom-edge: "descender",
    )
    set par(leading: 0.5em)
    body
    linebreak()
    off
  },
))

// 封面上的一行。收的是 Word 段落对话框上的那几格，折成 style 交给部件层——
// 行盒、字距、网格开关、字体角色全在那边落，这里只管居中与段前。
// *排一个 Word 段。* 封面、内封、声明页三处共用——单位是段（<w:p>），不是
// 行：声明页正文那几段都折了好几行。要的东西全在 style 里，一一对应 w:rPr 与
// w:pPr：字体字号行距、首行缩进、对齐（w:jc）、段前段后（w:spacing）。
//
// *段前段后走块的 above / below，不发 v()。* Typst 的块间距相邻时取大者，
// 正好就是 Word 那条「基线步进 ＝ 上块行深 + 下块上升部 + max(段后, 段前)」。
//
// *首行缩进要直接发 par，不能靠 set。* style-rules.rules 里那条
// set par(first-line-indent:) 在块里不生效——实测首行仍落在 85.05，而声明页范例
// 是 110.05。与目录悬挂缩进、摘要关键词行、内封密级行是同一个坑。
//
// *行首那个零宽空格是挡压缩的。* 两端对齐一开，Typst 会把行首的全角开括号
// 压窄——实测「（1）学校可以…」的首字从 38.68 挪到 37.13，而 Word 那份正好落在
// 缩进位上（103.80），没压。垫一个零宽空格就不压，与行尾悬挂标点同一招。
// 居中那一支不发 par，也就不需要它。
//
// *只在正文槽以全角开标点起头时才发。* 无条件发有代价：U+200B 在*黑体*里
// 是全宽的（SimHei 给它一个整格），实测人文成果页的组标题「二、发表的国际会议论文」
// 被推到 100.05，该顶格 85.05；宋体里才是零宽，所以先前只在正文里发、一直没露头。
// 挡压缩本来就只对开标点起头的那一段有意义，不起头的段发它是白发
//
// *段前段后收 (lines: n)*，与「空几个字」的 (chars: n) 同形——先前这一层收的是
// *裸数字*（space-before: 0.5），而 README 立的规矩是「裸数字不收：一个数看不出
// 它是几行、按哪档字号算的」，且同一个 style 字典里 styles.resolve 那一层读的
// above 收的正是 (lines: n)，一个字典里两个键说同一件事、各归各的层读。
// 现在两层同名同型：above / below，值一律 (lines: n) 或长度。
// *layout 必给*：段前段后的「行」按它的网格跨度折，没有默认那一份可拿
// ——哪一份版面由页函数从 layout-state 并出来（见 src/layout/resolve.typ）。
// Typst 会压缩的那几个全角开标点（typst-layout 的 shaping.rs 按码表判，不看 lang）
#let _open-puncts = ("（", "〔", "［", "｛", "〈", "《", "「", "『", "【")

#let _needs-zws(body) = {
  let s = plain(body)
  if s == none { return false }
  let cs = s.clusters()
  cs.len() > 0 and cs.first() in _open-puncts
}

// 封面、内封、声明页排的都是 Word 段，*Word 段里没有行间公式这一档*。写进 title /
// author 那些值里的 `$ x $`（两边带空格 ＝ 行间）到了下面的 par() 里会被 Typst 直接
// 丢掉（只给一句 warning），到了居中那一支就整块撑高格子——各分支的封面信息框都会
// 栽。所以一律转成行内公式（行内没有编号，编号一并去掉）。挂在 paragraph 里，各分支
// 的封面、内封、报告首页的值都从这儿过，不必逐处记得
#let inline-math(body) = {
  show math.equation.where(block: true): it => math.equation(block: false, numbering: none, it.body)
  body
}

// leading：段内行与行之间的空当，auto ＝ 跟 sets 里的 0（行盒定高，行距全在盒里）；深圳
// 本科报告首页折了行的格要按段前排折出来的行，从这儿给——写在内容里的 set par(leading:)
// 管不到显式的 par 自己
#let paragraph(body, style, layout: none, above: auto, leading: auto) = {
  if layout == none { panic("paragraph: layout is required (pass the page's layout)") }
  let lines(key) = {
    let v = style.at(key, default: 0pt)
    if type(v) == dictionary and "lines" in v {
      let n = v.at("lines")
      if type(n) not in (int, float) {
        panic("expected number for \"lines\", found " + str(type(n)))
      }
      n * layout.docgrid.line-unit
    } else if type(v) == length { v } else {
      panic("expected length or dictionary with \"lines\", found " + repr(v))
    }
  }
  let computed = linebox.metrics(style, layout: layout)
  block(
    above: if above == auto { lines("above") } else { above },
    below: lines("below"),
    width: 100%,
    // *整段左缩进落在块的 inset 上*。Typst 的 par 没有这一档，只有首行与
    // 悬挂；Word 的 w:ind left 推的是整段（含折行），只能由块来推。
    // 算在 src/styles/linebox.typ 的 _indent，用在这里
    inset: (left: computed.indent.at("left", default: 0pt)),
    {
      show: style-rules.rules.with(style, layout: layout, set-font: true)
      // *规则套在 par 外面，不裹在段的内容上*：裹在内容上，零宽空格与头一个字之间多了
      // 一层 styled，run 边界一变字距就丢一份（声明页首行缩进量到少 5.81 ＝ 一个字距）
      show: inline-math
      if style.at("align", default: left) == center {
        // 居中那几行不吃首行缩进。代价是仍吃字符网格的行末余量（约 0.45），
        // 实测声明页小标题偏 +1.13，半格以内
        // *显式的 par()*，不靠 align 里隐式成段：行间公式转行内那条 show 规则只在显式的
        // par 上生效——隐式成段时 Typst 先按「行间」把段拆开、再套规则，公式仍独占一行
        // （实测；show 规则改返回 box 也一样）。首行缩进、悬挂从 sets 那句 set 继承，
        // 与隐式成段一样
        align(center, par(
          ..(if leading != auto { (leading: leading) } else { (:) }),
          body,
        ))
      } else {
        par(
          first-line-indent: (amount: computed.indent.first-line, all: true),
          hanging-indent: computed.indent.hanging,
          (if _needs-zws(body) { sym.zws }) + body,
        )
      }
    },
  )
}

#let centered-line(
  body,
  font: "songti",
  size: zihao.xiaoer,
  bold: false,
  above: 0pt,
  line-spacing: 1,
  // 贴不贴*行*网格。范例封面上只有中文题目那一段贴（它没写 snapToGrid，
  // 取默认的开），别的段都写着 0。字符网格由版面给，全段都吃，不受这个开关影响。
  snap: false,
  // 这一行里夹的西文要不要加粗（中文题目那一档要）
  latin-bold: false,
  layout: none,
) = {
  let is-latin = font in ("serif", "sans", "mono")
  paragraph(
    body,
    (
      size: size,
      // 自然行高按哪一档算：西文角色排的是纯西文行，按西文的 1.15；
      // 中文角色排汉字行，按中易的 1.296875
      font-zh: if is-latin { "latin" } else { font },
      // 字体角色。与 font-zh 分开，理由见 src/styles/rules.typ
      font: font,
      line-spacing: line-spacing,
      snap-to-docgrid: snap,
      bold: bold,
      latin-bold: latin-bold,
      align: center,
    ),
    layout: layout,
    above: above,
  )
}
