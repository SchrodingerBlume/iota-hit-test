#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
#import banshi.msword: cm as msword-cm
// 样式表：Word 样式窗格里的那几条，一条 = 字体对话框 + 段落对话框。*只放值*
// ——并局部字典、验键名是 banshi/src/styles/sheet.typ 的 styles 的事。
//
// *所有学位共用这一套*——本硕博的版面规定是一样的，所以不按学位分档，
// 名字也不写学位。目录条目的行距是唯一的例外——研究生只差这一格，与别的学位
// 耦合一样只住在默认表里：toc-1～toc-4 写 auto，按学位查下面的 toc-line-spacing-auto。
//
// *住在这里而不是 lib.typ，是为了让部件也能用。* 声明页、索引页要用正文那一档，
// 先前它们自己抄了一份——抄的时候漏了两端对齐，一直到重新对范例才发现。部件
// import lib.typ 会成环（lib → api → 各部件），所以这一族住在这儿，两边都从
// 这里取。用户那边只见 iota-hit(styles:)，键名就是下面这张表的键。
//
// 每条能写的键（词汇照 Word 的对话框，键名照 Typst 有的词）：
//
//   font-zh              这一行的自然行高按哪一档字体算，也是中文字体的角色
//   font                 字体角色（serif / sans / mono 或中文角色），不写从 font-zh 推
//   size                 字号，长度（zihao.xiaosi 或 12pt）
//   bold                 加粗
//   tracking             字体对话框的「字符间距」，磅。*只表示这一项*——字符网格
//                        的增量由版面给，不写在这里（见 banshi/src/paragraph/linebox.typ 的 _snap-of）
//   line-spacing         行距：倍数、"single" / "double"、(exactly: 长度)、(at-least: 长度)
//   above/below  段前段后：(lines: n) 或长度
//   first-line-indent / hanging-indent / left-indent   (chars: n) 或长度
//   align                对齐，照 Typst 的 alignment（left / center / right）
//   snap-to-docgrid      段落对话框的「对齐到网格」勾，布尔，只管纵向
//   justify              两端对齐

// 正文：宋体小四、多倍 1.25、不对齐网格（本科的正文行是拉满版心的，不贴格子）、
// 首行缩进两字（Normal 样式 firstLineChars=200）、两端对齐（<w:jc w:val="both"/>）。
#let _body = (
  font-zh: "songti",
  size: zihao.xiaosi,
  line-spacing: 1.25,
  snap-to-docgrid: false,
  first-line-indent: (chars: 2),
  justify: true,
)

// *开题与中期报告的正文行距*（下面那张表的 body-line-spacing 那几条），
// 按学位。别的一律照终稿那一档（小四宋体、首行缩进两字、两端对齐），标题四级
// 也照原样错开一格用，见 src/heading/rules.typ 的 report-levels。
//
// *本科那两份把话印在纸上*：开题报告的说明页写着「（正文　宋体小4号字，
// *行距1.25倍*，段前0行，段后0行）」——与论文正文同一档，不必改。
//
// *硕博那三份没写倍数，两条证据把它钉死*：
//
// 一、*三份都要排 33 行*。中文写「正文　小4号字……每页约33行」，英文版写得更
// 干脆——「Main body　Size 12, 0 pound before and after paragraph, *33 lines each
// page*」，连「约」都没有。三份的下边距各不同（2.2／2.3／2.5cm），版心高 708.75 /
// 705.9 / 700.2，要三份*都*恰好排 33 行，行距只能落在
//
//     708.75/34 < p ≤ 700.2/33  →  20.85 < p ≤ 21.22
//
// 二、*表单自己的正文段就是 21pt*：w:line="420" w:lineRule="exact"，中英四份
// 表单的说明页整页正文段一律如此，不是个别段落。21 落在上面那个窗口里，也是窗口里
// 唯一的整数。
//
// 另两种读法当场出局：单倍贴网格（15.6）排 45 行、1.25 倍（19.45）排 36 行。
// 实排验过：满满一页正好 33 行，见 tests/check-report-body.py。

// 报告那几档与论文*不一样的样式*，一张表收齐。*把档写在键名上*
// ——与 src/terms/built-in.typ 一个写法：光键名是默认档，-bachelor 这样的档位后缀
// 压在上面，反档写 -not-bachelor，段的顺序照 axes；查表用同一个 term-for，包在
// banshi/src/styles/sheet.typ 的 variant-style 里。
//
// *「报告」也是一根轴上的一档*，所以它*也写在键名里*：stage 那根轴有
// final／proposal／interim 三档，报告就是 -not-final。先前这张表叫 report-*什么*
// 、由调用处写 if is-report 决定问不问它——那等于把一根轴挪进了代码，同一件事
// 表里一半、代码里一半。现在调用处照问，终稿那一档自己会落到光键名上。
//
// *语言不进键名，分桶。* 它不在 axes 里，也不该进：词条表的覆盖键
// （title-en）已经把 -en 这个后缀占掉了，两套写法撞在一张表上就没法断。
// *不按语言分的那几条住 base 桶*，查表时先并进本语言那一桶——与词条表
// 把 base 并进每一页同一个办法，免得两桶各抄一遍。
//
// *默认档常常是「不覆盖」，写 auto*：那一格没有自己的数，照终稿那一套排。
// 查不着不回落，term-for 当场报错——所以每条都得有光键名那一档。
//
// ── *英文那一桶写宽了，手上的英文原件就这么几份* ──────────────────
//
// 英文档不能没有取值，所以下面这几条的键名*比证据宽*——每一条都只有一个
// 校区的原件为证，键名里却没写校区：
//
//   heading-bold      -not-final 的 3        本部留学生开题、中期英文那两份
//   heading-spacing   -not-final 的 6 磅     本部留学生那两份的说明页
//   heading-bold      -bachelor-not-final 2  深圳本科英文版那两份
//   toc-line-spacing  -bachelor-not-final    深圳本科英文版那两份
//   body-indent       三个字                 深圳本科英文版那两份（这一条*写了*
//                                            -shenzhen，因为中文版与深圳研究生英文
//                                            版都是两个字，深圳本科自己一档）
//
// 也就是说：*研究生那两条没有深圳的证据，本科那三条没有本部的证据*。眼下
// 这么写是因为一个校区的数总比没有强，*不是因为另一个校区也这样*——哪天
// 拿到别的档的英文件，该添 -shenzhen／-harbin 的添、该改数的改。
//
// 手上的英文件全部就这些：深圳本科英文版开题、中期（2026 年 9 月版，两份都*带
// 英文说明页*）与深圳本科英文版写作指南（整份就是规矩），本部留学生开题、中期英文
// （*带说明页*），深圳研究生中期英文（*没有说明页*，正文就是中文样张的
// 译文），本部博士范例的英文那几页（论文，不是报告）。
//
// *已知一处对不上*：深圳那份研究生中期英文的 styles.xml 里 heading 1
// *没*写 <w:b/>、2/3 写了，与本部留学生那两份的「三级都加粗」相反。它没有
// 说明页、也不是自成一套的表单，所以眼下不据它分档——深圳发了正式的研究生英文
// 表单再说。
//
// *body-line-spacing　正文行距*。*本部硕博那个 21pt 是反推的*（说明页
// 自己的段落写着 w:line=420 exact，而版心高 708.75 ÷ 21 ＝ 33.75，正落在「每页约
// 33行」上），本科那份 1.25 倍是表单印在纸上的。*深圳四份都是段落自己写的*，
// 不必反推：研究生那两份的正文段写着 w:line="288" auto ＝ 1.2 倍（Word 排出来量得
// 18.72 ＝ 12 × 1.296875 × 1.2），本科那两份写的是 w:line="300" ＝ 1.25 倍（量得
// 19.44）——本科那一档与本部同数，两个校区一条 -bachelor 收齐。
//
// *heading-bold　加粗到第几级*（值就是级数，0 ＝ 一级都不加）。
// *英文档的报告标题，西文那一槽加粗*（汉字不加——黑体没有粗体面，整段
// 加粗会走描边合成，见 banshi/src/styles/rules.typ 的 latin-bold）。中文那几份不写
// <w:b/>，汉字照旧走黑体，所以中文桶是 0。本部那几份英文版给不出正反证据——
// 它们的「说　明」页只有条目文字（一律小四），一条真标题也没有。英文桶里两档
// 不同：
//
//   研究生（留学生开题、中期英文）  heading 1/2/3 *都*写着 <w:b/>
//   本科（2026 年 9 月版英文版）    heading 1/2 写着，*3 没写*
//
// 本科那一档是逐字量出来的：「2.1.1  Parameter Design of XXXX」排出来是
// TimesNewRomanPS*MT*（章与节是 -BoldMT），styles.xml 里 styleId="3" 那一条
// 也确实没有 <w:b/>。
//
// *heading-spacing　节与条的段前段后*：中文报告 0.5 行、英文报告 6 磅。
// *那句英文出自本部留学生那两份*（硕士开题英文版、硕士中期英文版），逐字是
// 「Section head　Size 15, *6 pound* before and after paragraph」；中文版对应
// 那一行写的是「节标题　小3号字，建议段前0.5行，段后0.5行」。*深圳本科英文版
// 那两份写的是「line」不是「pound」*（0.8 line／0.5 line），可*它那一档读不到
// 这一条*——深圳本科的正文照终稿排，节与条的段前段后走终稿那一套，见 lib.typ 的
// report-body。所以这一条眼下只对本部（与将来深圳的研究生英文）生效，而深圳研究生
// 那份中期英文没有说明页，验不了。*两个数不等值*
// ——拿表单原件造探针问过 Word（同一份 docx 里三段：段前 0、段前 0.5 行、段前 6 磅，
// 逐段量基线差）：0 是 24.99、0.5 行 32.67、6 磅 30.99，也就是这一份文档里
// *0.5 行 ＝ 7.68 ≈ 7.8*（正是网格行距 15.6 的一半），不是 6。
//
// *各按各的来，不判谁错*：英文版那一段的头一句写着「The proposal written in
// English should use Times New Roman font with size 12 in the main text」——它就是给
// *英文报告*的那一份规定，而且别的数它都换对了（Size 15 / 14 / 12 对小3／4号／
// 小4，33 lines each page 对每页约33行），只有这一处与「0.5 行」对不上。官方给英文
// 报告印的数就照它排。款项两档两版都是 0，不分。
//
// *body-indent　正文首行缩进*，只列与「两个字」不同的那一档。
// *深圳本科英文版是三个字*：那两份原件的正文段写着
// w:ind w:firstLineChars="300" w:firstLine="720"（＝ 36 ＝ 3 × 12），排出来
// 首行 120.96、续行 84.96，差正是 36。中文版那两份写的是 200（24 ＝ 2 × 12），
// *深圳研究生英文版也是 200*——所以这一条只落在本科英文那一格上。
//
// *toc-line-spacing　目录条目行距*，只列与终稿那一档不同的：本科英文报告是
// 1.5 倍——深圳本科英文中期原件的 TOC1/2/3 都写着 w:line="360"（条目步进量得
// 20.44 ＝ 1.5 × 12 × 1.152），英文开题的 TOC1/2 也是 360、*TOC3 却是 300*：
// 三级条目一共三行，一份目录里一二级 1.5、三级 1.25 说不出道理，当漏改论（用户定的），
// 三级照 1.5；中文版那两份三级都写的是 300（19.44），与论文本科那一档同数，
// 不必另列。*只有深圳本科那两份验过*，键名里没写 -shenzhen 是因为
// 本部根本没发过本科的英文报告；本部哪天发了，这一条要么加 -shenzhen、要么按
// 那一份重来。
// 目录那一页的红字*英文版少了一条*：中文版三条，第二条是「目录中各章标题用
// 黑体小4号字，其余用宋体小4号字」；英文版只有两条，没有讲字体字号的那一条。
// 所以这一档没有条文，跟的是原件排出来的样子。
#let variant-styles = (
  base: (
    // *章标题那一格与终稿不同的两条*，值是一份并到 default-styles.chapter
    // 上的样式（空字典 ＝ 不覆盖）：
    //
    //   行距 1.25  说明页写着「章标题　黑体小2号字，多倍行距值1.25」（英文版
    //              「Chapter Titles: … multiple line spacing set to 1.25」），
    //              原件的段落也是 w:line="300" auto。终稿那一档是 1.2（范例如此），
    //              两边差在行深上：18pt 的行深 10.95 对 9.79，章→节因此差 1.17。
    //   字距 0     论文范例的章标题 run 上写着 w:spacing="-8"（-0.4 磅），*报告
    //              那几份一个都没写*——中英四份表单的 heading 1 样式只有 w:kern 与
    //              w:sz。带着 -0.4 排，英文章标题「Completed」量得 77.40，原件是
    //              83.98；置 0 之后 83.99，而且折行位置跟着对上了。
    chapter: (:),
    chapter-not-final: (line-spacing: 1.25, tracking: 0pt),
    body-line-spacing: auto,
    body-line-spacing-bachelor-not-final: 1.25,
    body-line-spacing-not-bachelor-not-final-harbin: (exactly: 21pt),
    body-line-spacing-not-bachelor-not-final-shenzhen: 1.2,
  ),
  zh: (
    // 图表这一把伞（image / table / caption 三个子键，见 _figure）：中文版原件的
    // 装图段与正文同属性（1.25 倍、小四宋体，没有段后），就是 default-styles.figure
    // 那一份，不覆盖。*只有深圳本科的中文报告图表与正文贴着排*——那两份原件
    // （开题、中期）的图块和表块前后都没有空段，上下都是 0；gap 照 auto 推
    // （(1.25 − 1) × 15.56 ＝ 3.89）。本部没发过本科报告，硕博报告里没有图表可量
    figure: (:),
    figure-bachelor-not-final-shenzhen: (
      image: (above: 0pt, below: 0pt),
      // 网格不启用，格里按原件那几格写的 1.25 倍（w:line="300"）
      table: (above: 0pt, below: 0pt, line-spacing: 1.25),
    ),
    heading-bold: 0,
    heading-spacing: auto,
    heading-spacing-not-final: (lines: 0.5),
    body-indent: auto,
    toc-line-spacing: auto,
  ),
  en: (
    // *图表这一把伞*（image / table / caption 三个子键，见 _figure）。英文版原件
    // 的装图段走 Figure 样式（w:line="360" ＝ 1.5 倍、12pt Times），段落自己再写着
    // w:after="60" ＝ 段后 3 磅。图与图题之间那一截因此是 (1.5 − 1) × 13.824 ＝ 6.91
    // 加段后 3 ＝ 9.91——*这一格写数不写 auto*，因为装图段的段后在这棵树上
    // 没有自己的位置（image.below 是图块之下、题注到正文那一头），auto 只推得出
    // 6.91 那一半。四个空当是四个数：图之上 0、图题之下 3（题注段 w:after=60）；
    // 表题之上 0.2 行（beforeLines=20 ＝ 2.4 磅）、表之下 0。
    // *只有深圳本科那两份英文版（开题、中期）验过*，键名没写 -bachelor-shenzhen
    // 是因为别的英文报告原件里没有图表可量；哪天量到了不一样的，这一条要拆
    figure: (:),
    figure-not-final: (
      image: (font-zh: "latin", line-spacing: 1.5, above: 0pt, gap: 9.91pt, below: 3pt),
      // 网格不启用，格里 1.25 倍（与中文那两份同一个来历）
      table: (above: 2.4pt, gap: 0pt, below: 0pt, line-spacing: 1.25),
    ),
    heading-bold: 0,
    heading-bold-not-final: 3,
    heading-bold-bachelor-not-final: 2,
    heading-spacing: auto,
    heading-spacing-not-final: 6pt,
    body-indent: auto,
    body-indent-bachelor-not-final-shenzhen: (chars: 3),
    toc-line-spacing: auto,
    toc-line-spacing-bachelor-not-final: 1.5,
  ),
)

// 四级标题，写作指南 3.2 节那一份（bottom = ragged 这一档）：
//
//            字体字号    行距      段前 / 段后
//   章标题    黑体小二   多倍 1.25  1 行 / 0.8 行
//   节标题    黑体小三   多倍 1.25  0.5 行 / 0.5 行
//   条标题    黑体四号   多倍 1.25  0.5 行 / 0.5 行
//   款项标题  黑体小四   多倍 1.25  0 / 0
//
// *四级一律 1.25，章标题也是*。两份指南原话都这么写（研究生「章标题 小2号字，建议
// 行间距1.25倍」、本科「章标题 黑体小2号字，多倍行距值1.25」），本科范例自己动过手的
// 章标题段（摘要、参考文献、目录）直接格式全是 line=300，章→正文量得 38.50。1.2 的
// 来路只有 styles.xml 里 heading 1 那个 288——Word 模板自带的底子，范例作者在动过的
// 页面上全敲成了 1.25；博士范例致谢那页走的是样式（37.50），是没动过手的一页；研究生
// 指南「摘要」那一句写 1.2 是它自己跟自己打架。先前章标题照样式表取 1.2、目录标题
// 又单独 1.25，两处特例，用户 2026-09-15 定了全用 1.25。
//
// 四级都不对齐网格（heading 1/2/3 样式都写着 snapToGrid=0）。「一行」恒指网格
// 行距 19.55pt（391 缇，出处见 src/layout/presets.typ），折成长度时往下截到整缇：
// 0.8 行是 312.8 缇截成 312 ＝ 15.6pt，0.5 行是 195.5 缇截成 195 ＝ 9.75pt——两个数
// 都是 Word 写进本科理工范例 .docx 的（heading 1 段的 after=312、声明页小标题的
// before=195）。
//
// *章标题的字符间距 −0.4 磅。* heading 1 样式写着 <w:spacing w:val="-4"/>，
// 对话框上是「紧缩 0.2 磅」，可两台 Word 都排成两倍（出处与量法见
// banshi/src/msword.typ 的 msword-run-spacing）：官方本科理工范例第 11 页
// 「第4章 基于FLUENT…」汉字步进 18.000 / 18.234 交替，平均 18.04 = 18 + 0.4543 − 0.4。
// 字符网格那 0.4543 由版面给，这里只写字符间距本身。节、条、款项的样式没写
// w:spacing，步进 15.48 = 15 + 0.4543 就是网格增量，不写 tracking。
#let _headings = (
  chapter: (
    font-zh: "heiti", size: zihao.xiaoer, align: center,
    snap-to-docgrid: false, tracking: -0.4pt,
    line-spacing: 1.25,
    above: (lines: 1), below: (lines: 0.8),
  ),
  section: (
    font-zh: "heiti", size: zihao.xiaosan,
    snap-to-docgrid: false,
    line-spacing: 1.25,
    above: (lines: 0.5), below: (lines: 0.5),
  ),
  subsection: (
    font-zh: "heiti", size: zihao.sihao,
    snap-to-docgrid: false,
    // 1.25 不是 1.2：两份研究生指南与本科指南都写「条标题 4号字，建议行间距
    // 1.25倍」，本科两份范例的条标题段也都直接写着 line=300；样式表里 heading 3
    // 的 288（1.2）从没在哪一页真正印出来——博士范例每一段都用直接格式盖掉了它
    // （1.5 倍、23 磅固定值，互相打架，不跟）。
    line-spacing: 1.25,
    above: (lines: 0.5), below: (lines: 0.5),
  ),
  subsubsection: (
    font-zh: "heiti", size: zihao.xiaosi,
    snap-to-docgrid: false,
    line-spacing: 1.25,
  ),
)

// 题注那一档。字号五号由指南写死（「表题…用宋体5号字」「图题…用宋体5号字」）。
//
// *行距 1.25 不跟范例改。* 两份范例的题注段落都是排版的人*一段一段手敲
// 的直接格式*，而且自己就打架——同一份文件里：
//
//   图1-1（第一处）  无 spacing              单倍
//   图1-1（第二处）  w:line="280" exact      固定 14pt
//   表6-1           beforeLines=20 line=288  1.2 倍，段前 0.2 行
//   表6-2           beforeLines=20 line=300  1.25 倍，段前 0.2 行
//   表6-1（续表）    无 spacing              单倍
//
// styles.xml 里*根本没有「题注」这个样式*，所以没有一处文档级的规矩可依。
// 1.25 是那几个值里唯一与正文一致的，范例自己也用过（表6-2）。
//
// *判据的次序*：样式定义（styles.xml，章标题那三档就是这么印证的）→ 指南
// 原话 → 段落级直接格式。题注这几段全在第三档，不该拿它推翻前两档。
//
// 汉字步进吃网格增量：范例第 12 页「表6-1  1号试样渗透率测试数据」逐字 10.993 /
// 10.742 交替，平均 10.94 = 10.5 + 0.4543（Word 落笔取整到 1/300 英寸）。
#let _caption = (
  size: zihao.wuhao,
  line-spacing: 1.25,
  first-line-indent: (chars: 0),
)

// 目录四级的取值。每级一条样式，left-indent 是整条的左缩进（Word 的 w:ind w:left）。
//
// *编号后一律空一个字，标题从那里起排，折行也悬挂到那里。* 三级同一条
// 规则，没有定宽的编号盒——编号再宽标题跟着挪。这是 hithesis 目录修正后的
// 默认（本地 ~/hithesis 的 e6832ae「number-gap 默认改成 1\ccwd，量宽取齐退成
// auto 档」），实测它编出的博士目录（examples/demo/thesis.pdf 第 11 页）：
// 「第1章」→「哈」12.44、「1.1」→「内」12.47、「1.1.1」→「题」12.46、
// 「1.2.10」→「数」12.46，折行的章条目悬挂到标题首字（134.54 对 134.53）。
//
// Word 范例第六页：「第1章」→「绪」12.55（作者敲的一个全角空格）、
// 「1.2.1」→「气」12.34，都是一个字；只有「1.1」→「课」是 9.55——那是 TOC 域里
// 的制表符落在字符网格上（标题落在版心左缘起第 3 格，37.5 ≈ 3 × 12.4543），
// 不是作者的意思。指南 3.2 写的是「题序与标题间空 2 个半角字符」，与正文
// 标题同一条；三级一律一个字，不跟范例那一处的制表符。
//
// 先前二三级照 hithesis 老版的 \@dottedtocline{1}{1em}{2em} / {2}{2em}{3em}
// 装进 2em / 3em 的定宽盒，标题在 121.05 / 145.05；范例是 122.55 / 146.58，
// hithesis 修正后是 124.96 / 146.41。
//
// 缩进写磅：0 / 12pt / 24pt / 36pt，出处是范例 TOC1 / TOC2 / TOC3 / TOC4 样式的
// w:ind left=0 / 240 / 480 / 720 缇，正好等于 hithesis 的 0 / 1em / 2em / 3em，两边
// 一致。*不写 (chars:)*——一个字是 249 缇（12.4543pt），不是 240。
//
// *第四级（款项）默认不进目录*（#toc(depth:) 默认 3，范例也只收到条级），
// 写 depth: 4 才用得上 toc-4。范例的 TOC4 样式只有缩进是它自己的（w:ind left=720），
// 字号那一格 w:sz=18（9pt）是 Word 内置「目录 4」的默认值，没人碰过——范例里一条
// 四级条目都没有，那个 9 磅从没排出来过。所以字号行距跟 toc-2/3 走：宋体小四、1.25。
//
// *横轴吃网格字距，不用写。* TOC1/TOC3 的样式里写着 snapToGrid=0，但那一条
// 只管*行*间距，不管字距（见 banshi/src/paragraph/linebox.typ 的 _snap-of）。实测 Word 的
// 条目里「绪」→「论」步进 25.03 = 12.4543 × 2，字距照加。
//
// *行距写 auto，按学科与学位查 toc-line-spacing-auto*（理工本科 1.25、研究生 1.2，
// 人文固定值 23 磅），解法在
// banshi/src/styles/sheet.typ 的 resolve-toc-line-spacing；用户 styles: (toc-1: (line-spacing: …))
// 写了就照写的。
#let _toc-1 = (
  font-zh: "heiti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-docgrid: false, left-indent: 0pt,
)
#let _toc-2 = (
  font-zh: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-docgrid: false, left-indent: 12pt,
)
#let _toc-3 = (
  font-zh: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-docgrid: false, left-indent: 24pt,
)
#let _toc-4 = (
  font-zh: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-docgrid: false, left-indent: 36pt,
)

// 默认表。iota-hit(styles:) 的局部字典逐条并到它上面，见 banshi/src/styles/rules.typ 的
// styles；键名就是 Word 样式窗格里的那几条。
// *图表这一条是一把伞*，照 Typst 自己的那棵树：figure(kind: image)、
// figure(kind: table)、figure.caption——
//
//   image    装图的那一段自己（字体、字号、行距）＋ 这一种图块的三段空当
//   table    Word 那张「表格」卡：单元格里的段落与字体（选中表格 → 段落／字体对话框）、
//            表格属性里的单元格边距、边框和底纹的三条线，再加表块的三段空当
//   caption  题注那一段，图题表题共用一条（四档原件字号行距都一样，差的只是
//            段前段后，而那归各自 kind 的三段空当）
//
// *三段空当用 Typst 的三个词*：above（块之上）、gap（图与题之间）、below
// （块之下），裸写，与 block(above:, below:) 和 figure(gap:) 一个拼法。
//
//   above / below   **(lines: 1)**——就是 Word 段落对话框里填的「段前 1 行 / 段后 1 行」，
//                   写几行是几行，不写解出来的那个磅数（与标题的 heading-spacing 同一个
//                   解 linebox.amount：几行 × line-unit）。
//                   *空当长在题注那一段上，不是手敲的空段*：题注在上是它的段前
//                   （w:beforeLines），在下是它的段后（w:afterLines）——都朝着正文那一侧，
//                   两档一个单位。两份范例（本科理工、博士 d-stem）的表题段落写的正是
//                   `beforeLines`；图题那头范例是手排的（一堆 (a) (b) (c) 夹着空段），
//                   没写段后，量不出数。段前段后与空段差在页首：前者翻页会被丢掉，空段
//                   不会——我们这两个键是 Typst 的块间距，与段前同向，表落在页首时空当
//                   确实没了（实测）。
//                   *「一行」是多高*不在这儿定，归 line-unit：网格开着（论文）就是网格行
//                   19.55，字号（五号）不参与——探针（本科理工范例的正文段与表题段，
//                   只改 beforeLines，Word 导出量基线）实测段前 1 行净加 19.8、0.5 行 9.8、
//                   0.2 行 4.0，正好是整、半、五分之一；网格关着就是正文的一个字号。
//                   *取 1 行*：指南 2.12 的字面是「空一行」，与范例表题的 0.2 行、研究生
//                   写作指南自己排的那两张表的 0.5 行打架，用户 2026-09-15 权衡后定了 1 行。
//   gap（image）    *Word 自己加的那一截*：图在 Word 里是坐在一条文字基线上
//                   的内联对象，图底下带着那一段多倍行距比单倍多出来的那一份
//                   （(倍数 − 1) × 自然行高）；网格开着时装图那一行还要占整数个
//                   网格行、图居中，见 src/figure/caption.typ。
//   gap（table）    0——表题在表上，四份原件表题的段后都是 0。
//
// 写了具体的数就照数，与 Typst 一样（figure(gap: 20pt) 就是 20pt）；写 auto 就是
// 「模板定」，退回上面那一档。*各档原件
// 的数在 variant-styles 里*（深圳本科英文报告：图 0／9.91／3，表 2.4／0／0），
// 模板不必写。单个图要不一样，走原生：#figure(gap: …)、或
// #block(above: …, below: …, figure(…))。
//
// *终稿那一档装图的段跟正文*：两份范例装图的段落一个 w:spacing 都没写，属性
// 全从 Normal 继承（小四宋体、1.25 倍），gap 因此是 (1.25 − 1) × 15.5625 ＝ 3.89。
// 三线表。六张范例表（本科三张、博士三张）的单元格段落一个 w:line 都没写（单倍）、一个
// snapToGrid 都没写（Word 的默认就是贴格）、字五号；逐条量过：本科范例表 6-1 数据行步进
// 19.08–19.20，表头折的三行也是 19.08 / 19.20，一行一个网格行。*网格不启用的那几档*（深圳
// 本科报告）没有格可贴，原件那几格写着 w:line="300" ＝ 1.25 倍，在 variant-styles 里给。
//
// *单元格边距*：表格属性 → 单元格 → 选项，范例左右 0.19cm、上下 0（docx 的 tblCellMar
// left/right 108 缇）。Word 的边距从线的*内沿*量，Typst 的 inset 从线心量，差半条线——挨线
// 的那一边由排的时候补，用户写的也当 Word 的边距收（src/figure/kinds/table.typ 的 cell-inset）。
//
// *三条线*：边框和底纹里的磅数，范例顶线 w:sz=12 ＝ 1.5 磅、表头下 sz=8 ＝ 1 磅、底线 12
// （指南 2.12「表格采用三线表」没给磅数，数是范例的）。header 那一条是表头行的下边，Typst
// 的 stroke 字典里没有这个位置，所以这三个键是我们的、不是 table(stroke:) 的形状；元素上
// 显式写了 table(stroke:) 就整表听他的
//
// 文档级写在 iota-hit(styles: (figure: (table: (…))))，局部用 #show: new-styles.with((figure:
// (table: (…))))，见 banshi/src/styles/sheet.typ 的 styles
#let _table = (
  size: zihao.wuhao,
  line-spacing: "single",
  snap-to-docgrid: true,
  first-line-indent: (chars: 0),
  inset: (x: msword-cm(0.19), y: 0pt),
  stroke: (top: 1.5pt, header: 1pt, bottom: 1.5pt),
  above: (lines: 1), gap: auto, below: (lines: 1),
)

#let _figure = (
  image: (
    font-zh: "songti",
    size: zihao.xiaosi,
    line-spacing: 1.25,
    above: (lines: 1), gap: auto, below: (lines: 1),
  ),
  table: _table,
  caption: _caption,
)

#let default-styles = (
  body: _body,
  .._headings,
  figure: _figure,
  toc-1: _toc-1,
  toc-2: _toc-2,
  toc-3: _toc-3,
  toc-4: _toc-4,
)

// 目录条目的行距按学位挑：本科 1.25，研究生（硕士、博士）1.2。别的逐项相同——
// 两份 docx 的 TOC1/TOC2/TOC3 样式除一个 w:lang 外逐字节一样，页面与文档网格
// （pgMar、linePitch 391、charSpace 1861）也一样，右制表位同为 8494 缇，
// 四级缩进同为 0 / 240 / 480 / 720 缇，收到第三级，摘要与 Abstract 都进目录。
//
// 两边是从不同方向凑到同一个数的：本科 TOC1 用样式的 line=300，TOC2/TOC3
// 在段上直接格式覆盖成 300；研究生 TOC1/TOC2 段上直接格式写 288，TOC3 用
// 样式的 288。实测条目步进本科 19.45、研究生 18.50~18.75（1.2 × 15.5625
// = 18.675），标题基线两份都是 145.55。
//
// *目录标题不在这里，跟着章标题走*（1.25，见上面四级标题那一段）。
//
// 与 src/settings/defaults.typ 的 openright-auto 同一种表：先按学科、再按学位查，
// 解法在 banshi/src/styles/sheet.typ 的 resolve-toc-line-spacing。对拍件
// tests/demo-toc-graduate.typ（理工）、tests/demo-hass.typ（人文）。
//
// *人文社科是固定值 23 磅*：博士范例 s-hss 与本科范例（人文社科类）的目录
// 三级全写着 line=460 exact（缇，＝23 磅），三档学位一个数；理工那两份是倍数
// （本科 300 auto、博士 288 auto）。
#let toc-line-spacing-auto = (
  stem: (bachelor: 1.25, master: 1.2, doctor: 1.2),
  hass: (bachelor: (exactly: 23pt), master: (exactly: 23pt), doctor: (exactly: 23pt)),
)

// 图表索引条目的一级取值。宋体（不像目录章级那样黑体——hithesis 的
// \l@figure 也是默认罗马体），不缩进；编号后空一个字，与目录同一条规则。
#let list-levels = (
  font-zh: "songti", size: zihao.xiaosi, line-spacing: 1.25,
  snap-to-docgrid: false, left-indent: 0pt,
)
