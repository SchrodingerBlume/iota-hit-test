#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
#import banshi.units: twips
// 此处只存 Word 实测值；派生间距由 banshi 计算。
#let _body = (
  asian-font: "songti",
  size: zihao.xiaosi,
  line-spacing: 1.25,
  snap-to-grid: false,
  first-line-indent: (chars: 2),
  justify: true,
)
#let variant-styles = (
  base: (
    chapter: (:),
    chapter-not-final: (line-spacing: 1.25, tracking: 0pt),
    body-line-spacing: auto,
    body-line-spacing-bachelor-not-final: 1.25,
    body-line-spacing-not-bachelor-not-final-harbin: (exactly: 21pt),
    body-line-spacing-not-bachelor-not-final-shenzhen: 1.2,
  ),
  zh: (
    figure: (:),
    theorem: (head: (asian-font: "heiti")),
    figure-bachelor-not-final-shenzhen: (
      image: (above: 0pt, below: 0pt),
      table: (above: 0pt, below: 0pt, line-spacing: 1.25),
    ),
    heading-bold: 0,
    heading-spacing: auto,
    heading-spacing-not-final: (lines: 0.5),
    body-indent: auto,
    toc-line-spacing: auto,
  ),
  en: (
    figure: (:),
    theorem: (head: (bold: true)),
    figure-not-final: (
      image: (line-spacing: 1.5, above: 0pt, gap: 9.91pt, below: 3pt),
      table: (above: 2.4pt, gap: 0pt, below: 0pt, line-spacing: 1.25),
    ),
    heading-bold: 0,
    heading-bold-not-final: 3,
    heading-bold-bachelor-not-final: 2,
    heading-spacing: auto,
    heading-spacing-not-final: 6pt,
    body-indent: auto,
    body-indent-bachelor-not-final-shenzhen: (chars: 3),
    toc-line-spacing: auto,
    toc-line-spacing-bachelor-not-final: 1.5,
  ),
)
#let _headings = (
  heading-1: (
    asian-font: "heiti", size: zihao.xiaoer, align: center,
    snap-to-grid: false, tracking: -0.4pt,
    line-spacing: 1.25,
    above: (lines: 1), below: (lines: 0.8),
    pagebreak-before: true, sticky: true,
  ),
  heading-2: (
    sticky: true,
    asian-font: "heiti", size: zihao.xiaosan,
    snap-to-grid: false,
    line-spacing: 1.25,
    above: (lines: 0.5), below: (lines: 0.5),
  ),
  heading-3: (
    sticky: true,
    asian-font: "heiti", size: zihao.sihao,
    snap-to-grid: false,
    line-spacing: 1.25,
    above: (lines: 0.5), below: (lines: 0.5),
  ),
  heading-4: (
    sticky: true,
    asian-font: "heiti", size: zihao.xiaosi,
    snap-to-grid: false,
    line-spacing: 1.25,
  ),
)
#let _caption = (
  size: zihao.wuhao,
  line-spacing: 1.25,
  first-line-indent: (chars: 0),
  align: center,
)
#let _toc-1 = (
  asian-font: "heiti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 0pt,
)
#let _toc-2 = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 12pt,
)
#let _toc-3 = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 24pt,
)
#let _toc-4 = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 36pt,
)
#let _table = (
  size: zihao.wuhao,
  line-spacing: "single",
  snap-to-grid: true,
  first-line-indent: (chars: 0),
  inset: (x: twips(0.19cm), y: 0pt),
  stroke: (top: 1.5pt, header: 1pt, bottom: 1.5pt),
  above: (lines: 1), gap: auto, below: (lines: 1),
  // 表题与图题不同的那几项，并在 figure.caption 上
  caption: (:),
)

#let _figure = (
  image: (
    asian-font: "songti",
    size: zihao.xiaosi,
    line-spacing: 1.25,
    above: (lines: 1), gap: auto, below: (lines: 1),
  ),
  table: _table,
  caption: _caption,
  // 图注、表注：在 iota-hit 里从 caption 派生（左起、不缩进）
  note: (:),
)

#let default-styles = (
  body: _body,
  .._headings,
  // 目录、参考文献这类不编号的章级标题；报告正文没有章，它仍是章的样子
  term-heading: _headings.heading-1,
  figure: _figure,
  toc-1: _toc-1,
  toc-2: _toc-2,
  toc-3: _toc-3,
  toc-4: _toc-4,
  // 定理：body 是定理段的段落样式（跟 body、上下 0），head 只收字体那几个键；在 iota-hit 里按语言与 body 补齐
  theorem: (head: (:), body: (:)),
)
// 博后报告：读自《博士后研究工作报告模板》docx。Word 的段落默认贴网格，banshi 默认不贴，所以逐条写明。
// 正文是 Normal 加每段直接格式的 1.1 倍；标题样式都带 b（黑体没有粗体面，Word 自己合成）
#let _postdoc-heading = (asian-font: "heiti", bold: true, line-spacing: "single", snap-to-grid: true)
#let _postdoc-chapter = _postdoc-heading + (
  size: zihao.xiaoer, align: center, above: 12pt, below: 6pt,
  pagebreak-before: true, breakable: false,
)
#let _postdoc-toc = (asian-font: "songti", size: zihao.xiaosi, line-spacing: "single", snap-to-grid: true)
#let postdoc-styles = default-styles + (
  body: _body + (line-spacing: 1.1, snap-to-grid: true),
  heading-1: _postdoc-chapter,
  heading-2: _postdoc-heading + (size: zihao.xiaosan, above: 6pt, below: 6pt, sticky: true, breakable: false),
  heading-3: _postdoc-heading + (size: zihao.sihao, above: 7pt, sticky: true, breakable: false),
  heading-4: _postdoc-heading + (size: zihao.xiaosi),
  term-heading: _postdoc-chapter,
  figure: _figure + (
    caption: _caption + (line-spacing: "single", snap-to-grid: true),
    // 表题两行与它上面那个空段都是固定值 15 磅（直接格式），图题是 Normal 贴网格
    table: _table + (
      stroke: (top: 0.5pt, header: 0.5pt, bottom: 0.5pt),
      above: 15pt,
      caption: (line-spacing: (exactly: 15pt), snap-to-grid: false),
    ),
  ),
  toc-1: _postdoc-toc + (asian-font: "heiti", bold: true, left-indent: 0pt),
  // 左缩进 1、2 字符：docx 里的 w:left=249 / 498 缇
  toc-2: _postdoc-toc + (left-indent: 12.45pt),
  toc-3: _postdoc-toc + (left-indent: 24.9pt),
  toc-4: _postdoc-toc + (left-indent: 37.35pt),
)
// 终稿按学位换整张样式表（报告另走 report-styles）
#let final-styles-by-degree = (postdoc: postdoc-styles)
// 报告没有章：顶级是节，整表左移一格（指南表2），款之下是项（列表），没有第四级
#let report-styles = default-styles.pairs().filter(((k, _)) => k != "heading-4").to-dict() + (
  heading-1: _headings.heading-2, heading-2: _headings.heading-3, heading-3: _headings.heading-4,
)
#let toc-line-spacing-auto = (
  stem: (bachelor: 1.25, master: 1.2, doctor: 1.2),
  hass: (bachelor: (exactly: 23pt), master: (exactly: 23pt), doctor: (exactly: 23pt)),
)
#let list-levels = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: 1.25,
  snap-to-grid: false, left-indent: 0pt,
)
