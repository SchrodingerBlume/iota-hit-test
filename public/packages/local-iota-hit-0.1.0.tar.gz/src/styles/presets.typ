#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
#import banshi.units: twips
// 此处只存 Word 实测值；派生间距由 banshi 计算。
#let _body = (
  asian-font: "songti",
  size: zihao.xiaosi,
  line-spacing: 1.25,
  snap-to-grid: false,
  first-line-indent: (chars: 2),
  justify: true,
)
#let variant-styles = (
  base: (
    chapter: (:),
    chapter-not-final: (line-spacing: 1.25, tracking: 0pt),
    body-line-spacing: auto,
    body-line-spacing-bachelor-not-final: 1.25,
    body-line-spacing-not-bachelor-not-final-harbin: (exactly: 21pt),
    body-line-spacing-not-bachelor-not-final-shenzhen: 1.2,
  ),
  zh: (
    figure: (:),
    theorem: (head: (asian-font: "heiti")),
    figure-bachelor-not-final-shenzhen: (
      image: (above: 0pt, below: 0pt),
      table: (above: 0pt, below: 0pt, line-spacing: 1.25),
    ),
    heading-bold: 0,
    heading-spacing: auto,
    heading-spacing-not-final: (lines: 0.5),
    body-indent: auto,
    toc-line-spacing: auto,
  ),
  en: (
    figure: (:),
    theorem: (head: (bold: true)),
    figure-not-final: (
      image: (line-spacing: 1.5, above: 0pt, gap: 9.91pt, below: 3pt),
      table: (above: 2.4pt, gap: 0pt, below: 0pt, line-spacing: 1.25),
    ),
    heading-bold: 0,
    heading-bold-not-final: 3,
    heading-bold-bachelor-not-final: 2,
    heading-spacing: auto,
    heading-spacing-not-final: 6pt,
    body-indent: auto,
    body-indent-bachelor-not-final-shenzhen: (chars: 3),
    toc-line-spacing: auto,
    toc-line-spacing-bachelor-not-final: 1.5,
  ),
)
#let _headings = (
  chapter: (
    asian-font: "heiti", size: zihao.xiaoer, align: center,
    snap-to-grid: false, tracking: -0.4pt,
    line-spacing: 1.25,
    above: (lines: 1), below: (lines: 0.8),
    page-break-before: true, sticky: true,
  ),
  section: (
    sticky: true,
    asian-font: "heiti", size: zihao.xiaosan,
    snap-to-grid: false,
    line-spacing: 1.25,
    above: (lines: 0.5), below: (lines: 0.5),
  ),
  subsection: (
    sticky: true,
    asian-font: "heiti", size: zihao.sihao,
    snap-to-grid: false,
    line-spacing: 1.25,
    above: (lines: 0.5), below: (lines: 0.5),
  ),
  subsubsection: (
    sticky: true,
    asian-font: "heiti", size: zihao.xiaosi,
    snap-to-grid: false,
    line-spacing: 1.25,
  ),
)
#let _caption = (
  size: zihao.wuhao,
  line-spacing: 1.25,
  first-line-indent: (chars: 0),
  align: center,
)
#let _toc-1 = (
  asian-font: "heiti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 0pt,
)
#let _toc-2 = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 12pt,
)
#let _toc-3 = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 24pt,
)
#let _toc-4 = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: auto,
  snap-to-grid: false, left-indent: 36pt,
)
#let _table = (
  size: zihao.wuhao,
  line-spacing: "single",
  snap-to-grid: true,
  first-line-indent: (chars: 0),
  inset: (x: twips(0.19cm), y: 0pt),
  stroke: (top: 1.5pt, header: 1pt, bottom: 1.5pt),
  above: (lines: 1), gap: auto, below: (lines: 1),
)

#let _figure = (
  image: (
    asian-font: "songti",
    size: zihao.xiaosi,
    line-spacing: 1.25,
    above: (lines: 1), gap: auto, below: (lines: 1),
  ),
  table: _table,
  caption: _caption,
  // 图注、表注：在 iota-hit 里从 caption 派生（左起、不缩进）
  note: (:),
)

#let default-styles = (
  body: _body,
  .._headings,
  figure: _figure,
  toc-1: _toc-1,
  toc-2: _toc-2,
  toc-3: _toc-3,
  toc-4: _toc-4,
  // 定理：body 是定理段的段落样式（跟 body、上下 0），head 只收字体那几个键；在 iota-hit 里按语言与 body 补齐
  theorem: (head: (:), body: (:)),
)
#let toc-line-spacing-auto = (
  stem: (bachelor: 1.25, master: 1.2, doctor: 1.2),
  hass: (bachelor: (exactly: 23pt), master: (exactly: 23pt), doctor: (exactly: 23pt)),
)
#let list-levels = (
  asian-font: "songti", size: zihao.xiaosi, line-spacing: 1.25,
  snap-to-grid: false, left-indent: 0pt,
)
