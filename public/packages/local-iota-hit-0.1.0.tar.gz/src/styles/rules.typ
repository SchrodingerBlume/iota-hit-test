// 样式落到 Typst 上：sets（set text / set par）、shows（纯西文段、伪粗、字距补偿……）、
// rules 是两者合一。纯西文行／段那一支在 paragraph/latin.typ，字体表由 fonts.font 给。

#import "../msword.typ": latin-run, latin-run-lead-at-start, latin-run-led, latin-slot-run, role-features, latin-par-features
#import "../fonts/resolve.typ" as fonts
#import "../fonts/fake.typ" as _synth
#import "../layout/state.typ": layout-state
#import "../paragraph/linebox.typ" as linebox
#import "../paragraph/latin.typ" as western

// 把 style 落到 Typst 上。用法是 show: rules.with(style, layout: …)，
// 或者在一个块里直接调用。
//
// 正文、各级标题、页眉页脚、纯西文段、封面上的每一行——这些都是同一套机制的
// 不同取值：一段 Word 段落属性（字号、字体、行距倍数、贴不贴网格、段前段后、
// 缩进、字距）经换算层折成行盒，再落到 Typst 的 text / par 上。
//
// 这一层就是那个「落」的动作，各部件共用。放在这里的好处有三层：
//
// 一、网格三个参数（行距、一格的宽、字距增量）只在这里从 layout 里取一次。
//     以前每个部件各写一遍 grid-lead / grid-char / grid-space 三个参数，
//     加一个参数就得改七处，漏一处就是一个不报错的静默偏差。
//
// 二、*贴不贴网格是一个取值，不是一段特判。* 范例封面上只有中文题目那一段
//     贴行网格（它没写 snapToGrid，取默认的开），别的段都写着 0；而字符网格
//     全段都吃。这一差别现在就是 style 里的 snap-to-docgrid，与字号、行距同级，
//     由这个函数统一读，部件自己不写分支。
//
// 三、Word 的段落对话框上有什么，style 里就有什么，词汇一致，对着 docx 抄。
//
// *拆成 sets 与 shows 两半*，rules 只是把两半叠起来。拆开是为了正文那一档：
// set 规则能重发（内层压外层、不叠加），iota-hit 在文档级发一次，三个 matter 用
// 段级并好的版面再发一次，段级改的行跨度、版心就落到正文段落上；show 规则
// *绝不能重发*——latin-run 那条会在西文前补 h(linebox.tracking)，重发就补两次——
// 所以只在文档级装一次，用到版面的数改成在自己的 context 里从 layout-state 取
// （layout: auto）。部件层照旧写 rules，两半用同一份版面。

// 字体角色：style 的 font；没写就从 font-zh 推——font-zh 是「这一行的自然行高
// 按哪一档字体算」，"latin" 意思是这行没有汉字、按西文算，字体自然走 serif。
// 两者分开是必须的：英文题目那一行 font-zh 是 "latin"（西文行高），
// 字体却要 serif 这个角色，一个键担不了两件事。

// 字体角色：style 的 font；没写就从 font-zh 推——font-zh 是「这一行的自然行高
// 按哪一档字体算」，"latin" 意思是这行没有汉字、按西文算，字体自然走 serif。
// 两者分开是必须的：英文题目那一行 font-zh 是 "latin"（西文行高），
// 字体却要 serif 这个角色，一个键担不了两件事。
#let _role-of(style) = style.at("font", default: {
  let zh = style.at("font-zh", default: "songti")
  if zh == "latin" { "serif" } else { zh }
})

// 纯西文段（font-zh: "latin"——这一段没有汉字）：西文吃半格，直接 set，不发
// latin-run 那条 show 规则里的边界补偿。那条规则给每个西文 run 前面补「前一个汉字在
// run 边界丢掉的字距」，可这一段前面没有汉字，补出来就是一段假缩进（实测目录里
// 「Abstract」的 A 落在 85.50，Word 85.03）。英文摘要、英文目录、英文内封、英文题注
// 都走这一支。

#let _table-bold(style) = (
  style.at("latin-bold", default: false) and fonts.lacks-bold(_role-of(style))
)

#let _regex-bold(style) = (
  style.at("latin-bold", default: false) and not fonts.lacks-bold(_role-of(style))
)

// 西文的字距是汉字的一半——两截都是。
//
// *网格增量*：Word 按「占几格」发，全宽字占一格拿整份（charSpace/4096 =
// 0.4543），半宽的西文占半格拿半份 0.227，见 shows 里 latin-run 那条规则的注释。
//
// *样式的字符间距*（字体对话框「字符间距：加宽／紧缩 n 磅」）：Word 给汉字
// 发*两份*、给西文发*一份*。量官方本科理工范例 PDF 第 11 页的章标题
// 「第4章 基于FLUENT软件的轴承静态特性分析」（heading 1 样式紧缩 0.2 磅）：汉字
// 实排步进 18.04 = 18 + 0.4543 − 0.4，紧缩了对话框的两倍；F/L/U/E/N/T 的步进
// 10.008 / 10.998 / 12.996 就是 Times 18pt 的字身宽——半格 0.227 与一份 0.2
// 相抵。样式表里 linebox.tracking 存的是汉字实排的那两份（chapter −0.4pt），西文对半：
//
//   西文每字   字身宽 + 0.227 − 0.2 = 字身宽 + 0.027（范例 +0.004，差在 Word
//              1/300 英寸落笔）
//   汉字每字   字号 + 0.4543 − 0.4 = 字号 + 0.054
//
// 对拍：tests/check-heading.py 逐字量 FLUENT 的步进。

#let sets(style, layout: linebox.no-docgrid, families: none, latin-par: false, doc) = {
  let computed = linebox.resolve(style, docgrid: layout.docgrid)
  let bold = style.at("bold", default: false)
  set text(
    size: computed.size,
    // 行盒：两条边写成「em 系数 + 绝对量」的复合长度，leading 置零。
    // 行盒高与基线落点全由这两条边定，字体自己的度量完全被盖掉——
    // 换成苹方（自然行高 1.82，差四成）逐条基线不变。
    top-edge: computed.top-edge,
    bottom-edge: -computed.bottom-edge,
    // 范例的 Normal 写着 widowControl=0，全文没有一段覆盖它。
    // Typst 默认会拦孤行寡行，不放开的话该排 33 行的页面被压成 32 行。
    costs: (widow: 0%, orphan: 0%),
    // 字距增量与字号无关，见 src/layout/linebox.resolve.typ 的规则八。全宽字一整份，
    // 纯西文段半份（见 western.pure-latin）
    tracking: western.set-tracking(style, computed),
    weight: if bold { "bold" } else { "regular" },
    ..(if families != none { (font: families) } else { (:) }),
    // 角色写进 text，给视觉矫正认，见 src/msword.typ 的 role-tags；
    // 参不参与正文那条 show par 也写在这儿
    features: role-features(_role-of(style)) + latin-par-features(latin-par),
  )
  // *行内代码的行盒跟这一段的*，不跟 lib.typ 那条 show raw 给的等宽字体单倍行盒。那条
  // 是给代码块的（codly / zebraw 量它定框高），show-set 又钻得进任何地方——内封字段表
  // 的值格里只有一个占位符 `supervisor`（src/info.typ 的默认值），格子自己的行盒
  // 就成了 Consolas 单倍的 12.9，比标签那一格的 1.5 倍四号矮，值整个浮到标签上面（实测
  // 高 4.8）。正文里夹的行内代码本来就不撑行（行盒取各 run 最高的），改成同一个盒子
  // 不动任何东西。写成绝对量：em 在 raw 那个小一号的字号上解就又矮了一截
  show raw.where(block: false): set text(
    top-edge: computed.top-edge.abs + computed.top-edge.em * computed.size,
    bottom-edge: -(computed.bottom-edge.abs + computed.bottom-edge.em * computed.size),
  )
  set par(
    leading: 0pt,
    spacing: calc.max(computed.above, computed.below),
    justify: style.at("justify", default: false),
    // 两个方向各是各的，见上面的 _indent——带 em 的长度在
    // context 外比不了大小，所以不折成带符号的一个数再 calc.max 拆回来
    first-line-indent: (amount: computed.indent.first-line, all: true),
    hanging-indent: computed.indent.hanging,
  )
  // 视觉矫正（把这一档的字挪到 Windows 那一档的高度）*不在这儿发*：全篇只挂
  // 一条，在 lib.typ，按 text.font 反推角色——部件层各挂一份会层层累加、外层压
  // 内层，见 src/fonts/linebox.resolve.typ 的 baseline-rules。这儿写进 text 的 font 就是
  // 它反推的依据。
  doc
}

// 一条样式的 show 那一半：伪粗、代码字的字距、西文 run 的字距与加粗。
//
// 部件层照旧：layout 给整份，规则里的数都按它算。正文那一档（iota-hit 在文档级
// 装一次）把 current 打开：规则里用到版面的数（字距的三份、西文行盒、版心宽）改在
// 每条规则自己的 context 里从 layout-state 取——段级改了字距、版心，正文里的西文
// 跟着换；layout 那时只管一件事：*装不装那两条 show 规则*。字符网格有没有
// （snap-h）决定要不要把西文 run 切出来，而一条 show regex 哪怕原样交回也会造 run
// 边界、动到字距（实测无网格的段落加一条 show latin-run: it => it，PDF 就不同），
// 所以不能一律装上再在里面判。段级只能改网格的数，不能开关网格——
// src/layout/matter.typ 在并版面时拦这一档。

// 一条样式的 show 那一半：伪粗、代码字的字距、西文 run 的字距与加粗。
//
// 部件层照旧：layout 给整份，规则里的数都按它算。正文那一档（iota-hit 在文档级
// 装一次）把 current 打开：规则里用到版面的数（字距的三份、西文行盒、版心宽）改在
// 每条规则自己的 context 里从 layout-state 取——段级改了字距、版心，正文里的西文
// 跟着换；layout 那时只管一件事：*装不装那两条 show 规则*。字符网格有没有
// （snap-h）决定要不要把西文 run 切出来，而一条 show regex 哪怕原样交回也会造 run
// 边界、动到字距（实测无网格的段落加一条 show latin-run: it => it，PDF 就不同），
// 所以不能一律装上再在里面判。段级只能改网格的数，不能开关网格——
// src/layout/matter.typ 在并版面时拦这一档。
#let shows(style, layout: linebox.no-docgrid, current: false, doc) = {
  // 装规则时的版面：只用来定装不装
  let installed = linebox.resolve(style, docgrid: layout.docgrid)
  let bold = style.at("bold", default: false)
  let role = _role-of(style)
  let pure-latin = western.pure-latin(style)
  let latin-bold = style.at("latin-bold", default: false)
  // *加粗这一档也要能合成。* 封面、内封那些加粗走的是 sets 里那条
  // weight: "bold"，不是 #strong——src/fonts/fake.typ 挂的 show strong 够不着它们。
  // 中易宋体没有粗体面，Typst 静默换成常规面，排出来与正文一模一样；这一处
  // 把 synth 那一份描边补上，判据与 #strong 那一路同一个（见 wants-bold-for）。
  //
  // *latin-bold 走字体表那一层*：整段 set weight，中西两槽各自挑面。Typst 从不
  // 合成粗体（见 src/fonts/fake.typ 抬头），黑体没有粗体面就静默用常规面，汉字
  // 纹丝不动；Times 有真粗面，西文槽的字形连同数字、希腊字母、± % №、上下标、
  // box/link 隔出来的碎片一律跟着粗。与 Word 同构——那边也是 run 上一个 <w:b/>、
  // 两槽各自找面（博士范例内封「20 年 6 月」每个 run 都带 <w:b/>，学校发的 PDF 里
  // 2020 与 6 是 TimesNewRomanPS-BoldMT）。
  //
  // *为什么不继续用下面那条 show 规则*：它认的是 latin-run，中间那一位是
  // \p{Latin}，*一段字里没有拉丁字母就整段匹配不上*——纯数字、希腊字母、% ± №，
  // 以及被 #super / #sub / #box / #link 隔成独立片段的纯数字，全都留在常规面
  // （H#sub[2]O 里 H 粗、下标 2 细）。放宽那条正则要另抄一张「哪个码位排在哪一槽」
  // 的白名单，与字体表那张正本注定漂移；而且每放宽一次就多切一处 run 边界，每处
  // 边界丢一份网格增量（见 src/msword.typ 的 cjk-run）。走字体表一条
  // show 规则都不加，版面一格不动。
  //
  // *门：这一档中文字不能有真粗体面*。Noto、Fandol 那几档有，整段 set weight 会把
  // 汉字也排成真粗，而原件那几行 run 上没有 <w:b/>——那几档走下面 bold-rules 那条
  // show 规则。家族不在也走那条，理由见 fonts.lacks-bold——与伪粗那一路共一句判据。
  //
  // *公式不用挡，也别去挡*：Typst 选数学字面不读 text.weight（0.15.1 实测整段
  // 加粗前后逐字节相同）。反过来写 show math.equation: set text(weight: "regular")
  // 才是改坏了——typst 档实测把 NewCMMath-Book 换成了 NewCMMath-Regular。
  show: it => context {
    if bold and _synth.wants-bold-for(role) { _synth.fake-bold(it) } else if _table-bold(style) {
      set text(weight: "bold")
      // *「× ↑ □」那几个全宽符号由宋体那条 covers 抢走*（见 fonts.cjk-first）。
      // 宋体有真粗面的档会把它们也排成真粗，而原件里它们是常规——挑回来。
      // 没粗面的档一条规则都不装，免得白造一处 run 边界
      if not fonts.lacks-bold("songti") {
        show fonts.cjk-first: set text(weight: "regular")
        it
      } else { it }
    } else { it }
  }
  // 西文那一段单发一条 show 规则，管两件事。
  //
  // *一、西文只吃半份字距增量。* Word 的网格按「占几格」发字距：全宽字
  // 占一格拿一整份（charSpace/4096 = 0.4543），半宽的西文占半格只拿 0.227。
  // 实测封面的英文题目，Word 的字形步进 R→E 13.230；不分宽窄一律发满是
  // 13.450，每个字形多 0.220——一行三十几个字形就多出 7.95，约合半个字符，
  // 满行时正好少放一个字母。
  //
  // *二、中文标题里夹的西文要加粗*（而中文本身、黑体，不加粗）。字体表
  // 的条目只有 name 与 covers 带不了字重，整行 set weight 又会把黑体合成加粗，
  // 只能靠 show 规则分出这一段。
  //
  // *两件事必须合在一条规则里。* show 规则只在它自己所在的块里生效：
  // 写成 if computed.snap-h { show … } 而把 doc 放在外面，那条规则等于没发（实测
  // 西文步进纹丝不动）。而两条 show 规则匹配同一段文本又会互相嵌套。
  //
  // 代价是这条规则造 run 边界、吃掉边界处那一段 linebox.tracking。纯西文的行整行
  // 就是一个 run，只有首尾两处；中西混排的行每段西文两处。加粗那一档套一层
  // tracking-pad 补回来（见 src/text/linebox.tracking.typ）。比起每个字母都多 0.220，
  // 这个代价小得多。
  // 边界丢掉的那一段在*左侧*补。
  //
  // 前面那个汉字丢的是整份 linebox.tracking，补在这一段西文的左缘，位置与丢的地方
  // 重合，是等价的。
  //
  // *右侧不能补。* 右侧那一段间距会夹在西文与后面的字符之间，
  // 智能引号的开闭状态机看「前一个字符」，看到的成了间距而不是字母，
  // 于是把闭引号也判成开引号——实测 "the second chapter" 排出来是
  // 「“the second chapter“」，右引号方向错了，而且吞掉一个空格。
  // 只在左侧补则完全没有这个问题（逐层隔离验过：恒等函数、只在左侧补、
  // 函数里换字距都正常，只有右侧补会坏）。
  //
  // 代价是「西文接汉字」那一侧的半份 0.227 补不回来。比起排错引号，
  // 这个代价小得多。
  //
  // 下面两条规则里的数（字距的三份、西文行盒、版心宽）都在 context 里按当前版面
  // 现算，不用装规则时那一份——段级改了字距，正文里的西文跟着换。
  // *代码字按西文算。* Word 把 raw 里的字当西文：行内代码与代码块在带字符
  // 网格的段里每字只吃半格 0.227（连带样式字符间距的那一份），不是汉字的整份
  // 0.4543。sets 里 set 的整份字距会原样落到代码上——下面那条 latin-run 规则钻不进
  // raw 元素（regex 只匹配裸文本），实测 demo-mono 的代码行每字 0.4543，该是
  // 0.227。这儿按元素单发一条，取同一个 latin-tracking；块级 raw 同一条。
  //
  // *只在 snap-h 时发。* 没有字符网格的段（报告、typst 档）里 latin-tracking
  // 只剩样式那半份，而那里的代码本来就该按外面 set 的字距排；那儿连规则都不挂。
  //
  // *层层套着的 rules 里外层赢*，与下面 latin-run 那条一样：正文那一份挂在
  // 整篇上，章标题里的行内代码会被章那一份与正文那一份先后各处理一次，后处理的
  // 正文那一份 set 的字距贴着字——实测章标题里的 `abcd` 每字 +0.227，该是章的
  // 0.027。所以同样比「当前生效的 linebox.tracking 是不是本档 set 的那一份」：内层处理过
  // 的 raw 上字距已经换成半份，外层读到的对不上，放行。
  //
  // *进入 raw 的那处边界照 latin-run 的办法在左侧补一整份*：前面那个字丢的是
  // 外面那一档的整份 linebox.tracking。行内的才补，块级的自成一段，没有边界。不能写 weak
  // ——弱间距紧挨着前面的空格时是取代它，不是取较大者（实测「码 `abc`」的空格
  // 被吃掉，排成「码abc」）；代价是段首的行内代码前多 0.4543 的空，与 latin-run
  // 那条一样。
  //
  // *已知缺陷。* raw 里面 latin-run 那条 regex 照样切 run（引号、汉字两侧），
  // 切开处丢的是半份 0.227，而下面那条规则在 raw 里认不出本档（字距已经是半份），
  // 不补——`print("hi")` 两个引号处各窄 0.227。先前是各宽 0.227（补的是整份）。
  // *raw 里的汉字也按半份*：Word 把代码字当西文，没有靶子，PIN。
  let raw-rules(body) = if installed.snap-h {
    show raw: it => context {
      let computed = linebox.resolve(style, docgrid: western.layout-of(layout, current).docgrid)
      let full-tracking = linebox.tracking(computed, tracking: style.at("tracking", default: 0pt))
      if text.tracking != full-tracking { it } else {
        if not it.block { h(full-tracking * fonts.boundary-loss()) }
        set text(tracking: western.latin-tracking(style, computed))
        it
      }
    }
    body
  } else {
    body
  }
  show: raw-rules
  // *走不了字体表的那几档*：逐段挑出西文槽的字包一层 weight。选择器是 latin-slot-run
  // ——字体表分槽的补集，不是 latin-run（那条要求有一个拉丁字母垫底，纯数字、希腊字母、
  // 上下标里的碎片够不着）。*只包不 set*：包一层压得过下面那条规则 set 的字距，两条不
  // 打架（那条注释里「两件事必须合在一条规则里」讲的是 set）。*要先定义*：后定义的先
  // 执行，让下面那条先把「前导汉字＋西文」连着处理完，这条再包，前导字才不会被这条
  // 先切走、左侧补偿才发得出。
  //
  // 代价：汉字接「没有拉丁字母的片段」处多一道 run 边界，丢一份网格增量（补不了——
  // 补法会连 Typst 的 0.25em 中西文间距一起吃掉）。这几档本来就没有 Word 标定。
  let bold-rules(body) = context {
    if not _regex-bold(style) { return body }
    show latin-slot-run: r => context {
      if text.font.contains(lower(fonts.current.get().math)) { r } else { text(weight: "bold", r) }
    }
    body
  }
  show: bold-rules
  // 纯西文段的字距已经在 sets 里 set 好；这条规则对它仍要发——拆超长单词与加粗都在
  // 这里做，只有那段边界补偿不发，见 western.pure-latin
  if installed.snap-h or latin-bold {
    show latin-run-led: it => context {
    let l = western.layout-of(layout, current)
    let computed = linebox.resolve(style, docgrid: l.docgrid)
    let full-tracking = linebox.tracking(computed, tracking: style.at("tracking", default: 0pt))
    let set-tracking = western.set-tracking(style, computed)
    let latin-tracking = western.latin-tracking(style, computed)
    // 本档西文 run 的行盒，与 western.latin-line-rules 算的是同一份
    let latin-line = linebox.resolve(style + (font-zh: "latin"), docgrid: l.docgrid)
    // *只管本档自己的段落。* rules 是层层套着用的：正文那一份挂在
    // 整篇文档上，目录、摘要、封面各自再挂一份。同一属性上外层赢，于是
    // 部件里的西文 run 拿到的是*正文*那一份——连带下面那段左侧补偿
    // 也照发，而部件里的西文常常是整条的头一个 run，前面没有字可补，补出来
    // 就是一段假缩进（实测目录里的西文条目左缘落在 85.50，Word 85.03）。
    //
    // 判据取当前生效的 top-edge：行盒是 sets 写在 text 两条边上的，与本档的一份
    // 相同才是本档的段落。这是个样式查询，不进布局回路。src/styles/body.typ 里
    // 那条 show par 用的是同一个判据。
    //
    // *西文行盒的那一份也算本档。* western.latin-line-rules（标题、题注、目录条目
    // 都挂）给同一段西文 run 换上西文的行盒，而它是内层、先落到 run 上，这儿读到
    // 的 top-edge 就成了西文那一份——只认汉字那一份的话整条规则被跳过，半份字距
    // 与加粗都发不出去：实测章标题「基于FLUENT软件」里 F 的步进 10.062 =
    // 10.008 + 0.4543 − 0.4，吃的是汉字的整份网格增量与整份紧缩（该是半份 0.227
    // 与一份 0.2，净 +0.027）；英文档的「Chapter 1 Introduction」同样每字 +0.055。
    // 两份都按本档的 style 算。
    //
    // *可西文那一份各档写的是同一个 em 式子*（0.08pt + 0.93em，正文与四级标题
    // 一样），只比它认不出是谁的段落：正文那一份挂在整篇上，章标题的西文 run 会被
    // 章那一份与正文那一份先后各处理一次，后处理的（外层）那一份 set 的字距贴着
    // 字，压掉内层——实测章标题的 F 步进 10.235 = 10.008 + 0.227，紧缩没了。所以
    // 再比*当前生效的 linebox.tracking 是不是本档 set 的那一份*：内层处理过的 run 上
    // 字距已经换成半份，外层读到的对不上本档的整份，放行；别档的段落整份也不同。
    // 纯西文段 set 的本来就是半份（western.pure-latin），拿半份认——拿整份认的话英文题目
    // 整段被放行，超长单词不拆了（实测封面英文题目里的长词溢出版心）。
    // 这同样是样式查询，不进布局回路。
    //
    // *西文行盒那一份不认公式里的字。* 行内公式里正体的 Re、Im
    // （src/math/rules.typ 用 op 排的）也是拉丁字母，行盒又被正文那条 show par 的
    // western.latin-line-rules 换成了西文那一份——认了西文行盒之后这条规则会钻进行内公式，
    // 补偿那一段 h() 把 op 与操作数之间的细空打断（实测 2.0 掉到 0.68，
    // tests/check-math.py 当场红）。公式里的字距没有 Word 的靶子（OMML 对象），
    // 一切照旧：行内公式先前就不在这条规则里（行盒是西文那一份），行间公式先前
    // 就在（行盒是汉字那一份，d、p 那些字母吃半份、前面补一整份），两边都不动。
    // 认公式：math-rules 给公式设的字体表里有数学字体，正文的表里没有
    // （text.font 报的家族名是小写的）。PIN。
    let in-math = text.font.contains(lower(fonts.current.get().math))
    // *公式里的字一律不碰*：这条规则把匹配到的字重新发成一段字符串，math 给
    // 变量的斜体样式（𝐸、𝑚、𝑐 那套码位）在重发时就丢了——实测行间公式 E = m c²
    // 与符号表里的 $E$ 排成了直立的 E（tests/check-nomenclature.py 当场红）。
    // 先前靠 own-line 只把行内公式挡在外面，行间公式与符号表的 $E$ 行盒是汉字那
    // 一份，挡不住。公式里的字距没有 Word 的靶子，不发也无妨。
    let own-line = (
      not in-math and (
        text.top-edge == computed.top-edge or text.top-edge == latin-line.top-edge
      )
    )
    // *前面有没有汉字，正则自己看。* 匹配的是 latin-run-led：西文 run 连它前面
    // 那一个不在西文字符集里的字（汉字、中文标点、弯引号）一起吞进来。有这个字，它
    // 在 run 边界上丢的整份字距要补；段首、智能引号元素之后的西文前面没有它，什么
    // 都不补——先前这里不分青红皂白补一整份，以西文起头的段落、目录条目、成果条目
    // 全都多出 0.4543 的假缩进（目录里的西文条目左缘 85.50，Word 85.03）。
    let lead = it.text.match(latin-run-lead-at-start)
    let latin-text = if lead == none { it.text } else { it.text.slice(lead.end) }
    if not own-line or text.tracking != set-tracking { it } else {
      // 放不下的超长单词就地拆开，见上面 western.long-word-min 的注释。
      //
      // *拆开的那一段字距要照发一整份。* 零宽空格本身不吃 linebox.tracking
      // （实测发半份，每个字母就少 0.114，一行反而多塞进一个字母），所以
      // 拆开之后每个字母的步进与没拆时一样，都是「字宽 + 半份网格增量」。
      //
      // 这一段得*显式*写 text(tracking:)：插了零宽空格之后这段文本
      // 不再匹配 latin-run（那条规则的字符集里没有 U+200B），外面 set 的
      // 半份字距落不到它头上，会退回汉字那一档的整份 0.4543——实测每个
      // 字母多 0.454，32 个字母的行多出 7.3pt，正好吞掉最后一个字母。
      //
      // 拆词*必须在这条规则里做*，不能另发一条 show 规则：两条规则
      // 匹配同一段文本时，同一属性上外层赢，另发的那条改不动这里设的
      // linebox.tracking（实测步进纹丝不动）。
      // *没有超长单词就原样放行，不要重建。* 把 it.text 拆成词再拼回去
      // 会把*行首那个空格*弄丢——拼出来的内容里它成了一段独立的空白，
      // Typst 在段落开头会把它裁掉，实测「chapter" and」排成「chapter”and」。
      // 而超长单词是极罕见的，绝大多数 run 走不到重建那一支。
      let avail = l.text-width
      let words = latin-text.split(" ")
      let needs-break = avail != 0pt and words.any(w => (
        w.clusters().len() >= western.long-word-min and measure(text(w)).width > avail
      ))
      let body = if not needs-break { latin-text } else {
        words.map(w => {
          if w.clusters().len() >= western.long-word-min and measure(text(w)).width > avail {
            text(tracking: latin-tracking, western.long-word-chunks(w.clusters()).join("\u{200B}"))
          } else { w }
        }).join(" ")
      }
      // *已知缺陷。* 这一段 weak 间距紧跟在*闭引号*后面时，会把
      // 引号与西文之间那个字面空格吃掉——「chapter" and」排成
      // 「chapter”and」。试过「run 以空格开头就不补」这个判据，能治引号
      // 那一档，却会把「汉字接西文」那一档（基于 CFD 方法，中间有空格）
      // 的补偿一并去掉，实测「于」的步进从 22.4543 掉到 22.0。
      // 两害相权，先保住字距，缺陷记在这里。
      // 前导的那个汉字自己排出来，两侧各补一整份：它前面那个字因为这里造的
      // 边界丢了整份，它自己在西文前面又丢一份。
      // 补多少份由开机探针定（fonts.typ 的 probe-boundary）：上游修了 run 边界丢字距
      // 的 bug，这里自动归零。
      //
      // *纯西文段（font-zh: "latin"）的前导字只排不补*：它的字距本来就是半份，
      // 没有整份可丢。但前导字*必须排出来*——封面英文题目「…BEARING：A CASE
      // STUDY」里的全角冒号就是它，先前这一支把它连同补偿一起省掉，冒号丢了
      // （tests/check-subtitle.py 当场红）。
      // *能不重发就不重发。* 返回字符串等于把这一段文字*重新发一遍*，它的
      // span（源码位置）就成了本文件这一行——tinymist 从预览跳回源码时，西文落进包里，
      // 汉字却好好的（没有一条规则重发汉字）。所以除了拆超长单词那一支，一律原样交回。
      //
      // *前导字那一支靠里层规则。* 补偿要落在「前导字之前」与「前导字与西文之间」
      // 两处，先前是把整段拆成 h + 前导字 + h + 西文串重拼，西文那一半就重发了。改成
      // 里层再挂一条只管西文那一段的规则：它自己发第二份补偿、自己 set 字距与加粗，
      // 前导字与西文都原样过。两条规则的选择器不同（latin-run 认不出前导那个汉字），
      // 不会互相递归；里层造出的 run 边界与先前拆开时那一处是同一个，补的数也一样。
      if not needs-break {
        let loss = if lead == none or pure-latin { 0 } else { fonts.boundary-loss() }
        show latin-run: r => {
          if loss != 0 { h(full-tracking * loss) }
          set text(tracking: latin-tracking)
          r
        }
        if loss != 0 { h(full-tracking * loss) }
        it
      } else {
        if lead != none {
          if pure-latin { lead.text } else {
            let loss = fonts.boundary-loss()
            h(full-tracking * loss); lead.text; h(full-tracking * loss)
          }
        }
        {
          set text(tracking: latin-tracking)
          body
        }
      }
    }
    }
    doc
  } else {
    doc
  }
}

// 两半叠起来：set 在外、show 在内，与先前一个函数里先 set 后 show 的嵌套一样。
//
// set-font 默认关：正文那一档的字体是 iota-hit 在最外层设的，部件不该盖掉它。
// 标题、封面这些自己指定字体的部件把它打开，字体从 style 的 font-zh 取角色。

// 两半叠起来：set 在外、show 在内，与先前一个函数里先 set 后 show 的嵌套一样。
//
// set-font 默认关：正文那一档的字体是 iota-hit 在最外层设的，部件不该盖掉它。
// 标题、封面这些自己指定字体的部件把它打开，字体从 style 的 font-zh 取角色。
#let rules(
  style,
  layout: linebox.no-docgrid,
  set-font: false,
  // 直接给字体表（已经解析好的家族名）。标题那一档的角色表是从外面传进来的，
  // 不走 fonts.current，用这个口子把它送进来。给了就不再查 fonts.current。
  families: auto,
  // 这一档参不参与正文那条「纯西文段换西文行盒」的 show par，见 sets
  latin-par: false,
  doc,
) = {
  let apply(families) = {
    show: sets.with(style, layout: layout, families: families, latin-par: latin-par)
    show: shows.with(style, layout: layout)
    doc
  }
  if families != auto {
    return apply(families)
  }
  if set-font {
    context apply(fonts.font(
      _role-of(style),
      fonts.current.get().families,
      latin: style.at("font-latin", default: "serif"),
      em-dash: fonts.current.get().at("em-dash", default: "cjk"),
    ))
  } else {
    apply(none)
  }
}

// ── 样式表 ────────────────────────────────────────────────────────
//
// Word 的样式窗格：一条 = 字体对话框 + 段落对话框。默认表住 src/styles/presets.typ
// （只放值），iota-hit(styles:) 收的局部字典在这里逐条并到默认表上——用户写
// styles: (body: (size: "wuhao")) 只换字号，正文那一档别的键照旧。
//
// *键名不认识当场报错*，表级与条目级都验：写错的键静默失效就是排出一份
// 不合格的东西还不知道。条目级的词汇就是下面 sheet.style-keys 这一张，与 rules / linebox.resolve
// 读的键一一对应。
