// 样式表：Word 的样式窗格，一条 = 字体对话框 + 段落对话框。默认表住 presets.typ，
// iota-hit(styles:) 收的局部字典在这里逐条并到默认表上、键名与值域逐条验、记进 state。

#import "../fonts/presets.typ": zihao, natural-coefs, en-roles, zh-roles
#import "./presets.typ": default-styles, toc-line-spacing-auto, variant-styles
#import "../terms/lookup.typ": term-for
#import "../errors.typ" as _errors
#import "../paragraph/linebox.typ" as linebox
#import "./rules.typ" as style-rules

// ── 样式表 ────────────────────────────────────────────────────────
//
// Word 的样式窗格：一条 = 字体对话框 + 段落对话框。默认表住 src/styles/presets.typ
// （只放值），iota-hit(styles:) 收的局部字典在这里逐条并到默认表上——用户写
// styles: (body: (size: "wuhao")) 只换字号，正文那一档别的键照旧。
//
// *键名不认识当场报错*，表级与条目级都验：写错的键静默失效就是排出一份
// 不合格的东西还不知道。条目级的词汇就是下面 style-keys 这一张，与 style-rules.rules / linebox.resolve
// 读的键一一对应。
#let style-keys = (
  "font-zh", "font", "size", "bold", "latin-bold", "tracking", "line-spacing",
  "above", "below",
  "first-line-indent", "hanging-indent", "left-indent",
  "align", "snap-to-docgrid", "justify",
)

// 每个键的值域。键名对了、值不认识也要当场报错——先前 align: "center"（字符串，
// 不是 Typst 的 center）静默按左对齐排、font: "italic" 静默走 serif、
// tracking: 1（没单位）到排版时才炸出「cannot add length and integer」。
//
//   font-zh   这一行的自然行高按哪一档字体算：中文角色名，或 "latin"（这一行没有汉字）
//   fonts.font      字体角色：serif / sans / mono，或直接写中文角色名（标题、封面那些）
//   size      字号，长度（zihao.xiaosi 或 12pt）
//   linebox.tracking  Word 字体对话框的「字符间距」，磅——存汉字实排的值（对话框的两倍），
//             西文与代码拿一半，见 style-rules.rules 里的 latin-tracking
//   line-spacing  Word 段落对话框的「行距」：single / double / 倍数 / 长度 /
//             (exactly:) (at-least:) (white:)，见 _baseline-gap-endpoint
//   above / below   (lines: n) 或长度，见 linebox.amount
//   first-line-indent / hanging-indent / left-indent   (chars: n) 或长度，见 _indent
//   align     Typst 的 alignment（left / center / right），不收字符串
//   latin-bold  只加粗这一行里的*西文*，汉字不动。*中文字体不该被伪粗*
//             ——黑体没有粗体面，整行 set weight 会让它走描边合成；英文档的报告
//             标题（深圳那两份英文版的 heading 1/2/3 写着 <w:b/>）要的正是
//             「西文粗、黑体照旧」。机制见上面 style-rules.shows 里那一段
//   bold / latin-bold / snap-to-docgrid / justify   布尔

// 每个键的值域。键名对了、值不认识也要当场报错——先前 align: "center"（字符串，
// 不是 Typst 的 center）静默按左对齐排、font: "italic" 静默走 serif、
// tracking: 1（没单位）到排版时才炸出「cannot add length and integer」。
//
//   font-zh   这一行的自然行高按哪一档字体算：中文角色名，或 "latin"（这一行没有汉字）
//   fonts.font      字体角色：serif / sans / mono，或直接写中文角色名（标题、封面那些）
//   size      字号，长度（zihao.xiaosi 或 12pt）
//   linebox.tracking  Word 字体对话框的「字符间距」，磅——存汉字实排的值（对话框的两倍），
//             西文与代码拿一半，见 style-rules.rules 里的 latin-tracking
//   line-spacing  Word 段落对话框的「行距」：single / double / 倍数 / 长度 /
//             (exactly:) (at-least:) (white:)，见 _baseline-gap-endpoint
//   above / below   (lines: n) 或长度，见 linebox.amount
//   first-line-indent / hanging-indent / left-indent   (chars: n) 或长度，见 _indent
//   align     Typst 的 alignment（left / center / right），不收字符串
//   latin-bold  只加粗这一行里的*西文*，汉字不动。*中文字体不该被伪粗*
//             ——黑体没有粗体面，整行 set weight 会让它走描边合成；英文档的报告
//             标题（深圳那两份英文版的 heading 1/2/3 写着 <w:b/>）要的正是
//             「西文粗、黑体照旧」。机制见上面 style-rules.shows 里那一段
//   bold / latin-bold / snap-to-docgrid / justify   布尔
#let _font-zh-values = (zh-roles + natural-coefs.keys()).dedup()

#let _font-values = en-roles + zh-roles

#let _line-spacing-ok(v) = (
  v in ("single", "double")
    or type(v) in (int, float)
    or type(v) == length
    or (type(v) == dictionary and v.keys().len() == 1 and (
      "exactly" in v or "at-least" in v or "white" in v
    ))
)

// 验一条样式。name 是报错里的路径（"styles.body"、"header.style"）。
// line-spacing-auto：这一条的行距收不收 auto——只有默认表里本来就写 auto 的那几条
// （toc-1～toc-4，按学位挑）收，别的条写 auto 没有解法，当场报错。

// 验一条样式。name 是报错里的路径（"styles.body"、"header.style"）。
// line-spacing-auto：这一条的行距收不收 auto——只有默认表里本来就写 auto 的那几条
// （toc-1～toc-4，按学位挑）收，别的条写 auto 没有解法，当场报错。
#let _figure-keys = ("image", "table", "caption")

// kind：正在验的是 figure 底下哪个子键（"image" / "table" / "caption"），顶层与别的
// 条目是 none；只有 image 与 table 有三段空当那三个键

// kind：正在验的是 figure 底下哪个子键（"image" / "table" / "caption"），顶层与别的
// 条目是 none；只有 image 与 table 有三段空当那三个键
#let validate-style(entry, name, line-spacing-auto: false, kind: none) = {
  if type(entry) != dictionary {
    panic(name + ": expected a dictionary, found " + repr(entry))
  }
  for (key, v) in entry {
    // *figure 是一把伞*，底下三个子键照 Typst 自己的树：image、table
    // （figure(kind:) 的两种）与 caption（figure.caption），值各是一份样式，递归验；
    // 别的条目上写这三个就是写错了地方。见 src/styles/presets.typ 的 _figure
    if name.ends-with("figure") {
      if key not in _figure-keys {
        panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(_figure-keys, key))
      }
      validate-style(v, name + "." + key, kind: key)
      continue
    }
    // 三段空当只有图块表块有：above / below 收 auto（＝ 空一行），gap 是 Typst 的
    // figure(gap:)，同样收 auto（图按内联对象推、表按题注段后），见 lib.typ
    if kind in ("image", "table") and key in ("above", "gap", "below") {
      if not (v == auto or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))) {
        panic(name + "." + key + ": expected auto, a length, or a dictionary with \"lines\", found " + repr(v))
      }
      continue
    }
    // 表格那一档另有两个 Word 表格属性上的键：单元格边距（inset，收长度或 (x:, y:) 字典，
    // 当 Word 的边距、从线内沿量）、三条线（stroke，(top:, header:, bottom:) 三个磅数）
    if kind == "table" and key == "inset" {
      let ok(x) = type(x) == length
      if not (ok(v) or (type(v) == dictionary and v.keys().all(k => k in ("x", "y")) and v.values().all(ok))) {
        panic(name + ".inset: expected a length or a dictionary with \"x\" and \"y\" (Word's cell margins), found " + repr(v))
      }
      continue
    }
    if kind == "table" and key == "stroke" {
      if not (type(v) == dictionary and v.keys().all(k => k in ("top", "header", "bottom")) and v.values().all(x => type(x) == length)) {
        panic(name + ".stroke: expected a dictionary with \"top\", \"header\", \"bottom\" (the three style-rules.rules, in pt), found " + repr(v))
      }
      continue
    }
    if key not in style-keys {
      panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(style-keys, key))
    }
    let where = name + "." + key + ": "
    if key == "font-zh" and v not in _font-zh-values {
      panic(where + _errors.expected-one-of(_font-zh-values, v))
    } else if key == "font" and v not in _font-values {
      panic(where + _errors.expected-one-of(_font-values, v))
    } else if key == "size" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length such as zihao.xiaosi or 12pt, found " + repr(v))
    } else if key in ("bold", "latin-bold", "snap-to-docgrid", "justify") and type(v) != bool {
      panic(where + "expected true or false, found " + repr(v))
    } else if key == "tracking" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length (Word's character spacing, in pt), found " + repr(v))
    } else if key == "line-spacing" and not (_line-spacing-ok(v) or (line-spacing-auto and v == auto)) {
      panic(
        where + "expected \"single\", \"double\", a number, a length, or a dictionary with "
          + "\"exactly\", \"at-least\", or \"white\""
          + (if line-spacing-auto { ", or auto (by degree-level and category)" } else { "" })
          + ", found " + repr(v),
      )
    } else if key in ("above", "below") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",))
    ) {
      panic(where + "expected length or dictionary with \"lines\", found " + repr(v))
    } else if key in ("first-line-indent", "hanging-indent", "left-indent") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("chars",))
    ) {
      panic(where + "expected length or dictionary with \"chars\", found " + repr(v))
    } else if key == "align" and type(v) != alignment {
      panic(where + "expected alignment (left, center, or right), found " + repr(v))
    }
  }
}

// 当前生效的样式表与文档级那一份，定义住在 src/styles/state.typ（那边说了为什么），这里再导出一次
#import "./state.typ": styles-state, local-styles, current-styles, merge-local

// ── 局部样式：new-styles / restore-styles ──────────────────────────
//
// `#show: new-styles.with((body: (line-spacing: (exactly: 18pt))))`，从这里起按这张表排，字典
// 形状与 iota-hit(styles:) 一模一样；块里用（#[ … ]）出块自动回，顶层用配 `#show: restore-styles`
// 回到文档级那一份——与 new-layout / restore-layout 同一对形状，new- 说的是「从这儿起换一份」。
//
// *两路*：有原生对应的键折成原生 show-set 套在 body 外（表格的字号 → show table: set text(size:)），
// 没原生的改 styles-state、出作用域还原，规则在各自的 context 里读。正文（body）那一档还要
// *在作用域里重发一次正文的 set*（字号、行盒边、字距、缩进、对齐，与 section-sets 发的同一个
// 式子）——它们是节级 set 的，光改 state 改不到；西文 run 与纯西文段那几条规则则从 state 现取
// body（western.style-of）。有原生的仍推荐直接写原生（#[ #show table: set text(size: …) … ]），
// 这里只是把 Word 那张卡的格名翻成原生。
//
// *眼下只接了 body 与 figure.table*：标题、题注那些的消费者读的是 iota-hit 传下去的那一份、
// 不读 state，写了当场报错，不静默。
#let _local-keys = ("body", "figure")
#let _check-local(local) = {
  if type(local) != dictionary {
    panic("new-styles: expected a dictionary (the same shape as iota-hit(styles:)), found " + repr(local))
  }
  for (name, entry) in local {
    if name not in _local-keys or (name == "figure" and (type(entry) != dictionary or entry.keys().any(k => k != "table"))) {
      panic(
        "#show: new-styles.with(...): only body and (figure: (table: ...)) can be changed locally for now; "
          + "change " + repr(name) + " at document level with iota-hit(styles: ...)",
      )
    }
    validate-style(entry, "styles." + name)
  }
}
// 发的那一半（压栈、body 的 set 重发、出作用域弹栈）住在 src/styles/local.typ——要读当前版面
// （layout/resolve），而 resolve 反过来 import 这里验样式，不能在此处调；并表在 state.typ 的 merge-local
#let local-keys = _local-keys
#let check-local = _check-local

// preset 是*这一档材料自带的那一层*（眼下只有报告的正文行距），摆在默认表
// 之上、用户写的之下——用户仍压得过它

// preset 是*这一档材料自带的那一层*（眼下只有报告的正文行距），摆在默认表
// 之上、用户写的之下——用户仍压得过它
#let resolve-styles(local, preset: (:)) = {
  if type(local) != dictionary {
    panic("styles: expected a dictionary, found " + repr(local))
  }
  // *figure 那一条要深并一层*：image / table / caption 是它底下的子键，浅并
  // 会整份换掉
  let join(base, entry) = {
    let out = base + entry
    for key in _figure-keys {
      if key in entry and key in base {
        out.insert(key, base.at(key) + entry.at(key))
      }
    }
    out
  }
  let merged = default-styles
  for (name, entry) in preset { merged.insert(name, join(merged.at(name), entry)) }
  for (name, entry) in local {
    if name not in default-styles {
      panic(
        "styles: unknown style \"" + name + "\"; "
          + _errors.expected-one-of(default-styles.keys(), name),
      )
    }
    validate-style(
      entry, "styles." + name,
      line-spacing-auto: default-styles.at(name).at("line-spacing", default: none) == auto,
    )
    merged.insert(name, join(merged.at(name), entry))
  }
  merged
}

// 按档取一条样式值，查 src/styles/presets.typ 的 variant-styles：*先按语言取桶
// （不分语言的 base 桶先并进来），桶里的档位后缀交给 term-for 分辨*——词条用的
// 是同一个查法。档写成具名参数，*报告也是其中一档*（stage）：
//
//     variant-style("body-indent", lang: "en", degree-level: "bachelor",
//                   stage: "interim", campus: "shenzhen")
//
// 终稿那一档不必在调用处判——它自己会落到光键名上（多半是 auto ＝ 不覆盖）。

// 按档取一条样式值，查 src/styles/presets.typ 的 variant-styles：*先按语言取桶
// （不分语言的 base 桶先并进来），桶里的档位后缀交给 term-for 分辨*——词条用的
// 是同一个查法。档写成具名参数，*报告也是其中一档*（stage）：
//
//     variant-style("body-indent", lang: "en", degree-level: "bachelor",
//                   stage: "interim", campus: "shenzhen")
//
// 终稿那一档不必在调用处判——它自己会落到光键名上（多半是 auto ＝ 不覆盖）。
#let variant-style(name, lang: "zh", ..variant) = term-for(
  variant-styles.base + variant-styles.at(lang), name, variant.named(),
)

// 目录条目的行距按学位挑。局部（用户在 styles: (toc-1: (line-spacing: …)) 写的）
// 不是 auto 就照写的；auto 查 src/styles/presets.typ 的 toc-line-spacing-auto——本科
// 1.25，研究生 1.2。与 src/settings/linebox.resolve.typ 的 resolve-openright 同一个写法。

// 目录条目的行距按学位挑。局部（用户在 styles: (toc-1: (line-spacing: …)) 写的）
// 不是 auto 就照写的；auto 查 src/styles/presets.typ 的 toc-line-spacing-auto——本科
// 1.25，研究生 1.2。与 src/settings/linebox.resolve.typ 的 resolve-openright 同一个写法。
#let resolve-toc-line-spacing(
  local: auto, degree-level: "doctor", category: "stem",
  stage: "final", lang: "zh",
) = {
  if local != auto { return local }
  // *报告另有一档*，写在键名的 -not-final 上；写 auto 的那几格没有自己的数，
  // 落回下面终稿那一套
  let v = variant-style("toc-line-spacing", lang: lang, degree-level: degree-level, stage: stage)
  if v != auto { return v }
  let by-degree = toc-line-spacing-auto.at(category, default: toc-line-spacing-auto.stem)
  by-degree.at(degree-level, default: by-degree.bachelor)
}
