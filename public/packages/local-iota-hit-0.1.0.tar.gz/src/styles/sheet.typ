// iota 模板的样式配置表与覆盖校验，不作为引擎的命名样式协议。

#import "@local/docxtyp:0.1.0" as d
#let _errors = d.errors
#import "./merge.typ": style-keys, is-record, sub-keys as _sub-keys, merge-table

// 样式值在合并前校验，避免拼错键名或把字符串 `"center"` 当作 Typst alignment。

#let _line-spacing-ok(v) = (
  v in ("single", "double")
    or type(v) in (int, float)
    or type(v) == length
    or (type(v) == dictionary and v.keys().len() == 1 and (
      ("exactly" in v and type(v.exactly) == length)
        or ("at-least" in v and type(v.at-least) == length)
    ))
)

// line-spacing-auto：这一条的行距收不收 auto；只有基准表里本来就写 auto 的那几条收（模板自己按别的条件解），别的条写 auto 没有解法，当场报错。
// 子记录：基准表里值是样式记录（有样式键，或空）或记录的记录（值全是字典）的键——figure.image、theorem.head……
// 形状由基准表定，用户只能写基准表里有的子键；子记录各自再按样式验。值是长度字典的（模板自己的
// inset: (x:, y:) 之类）不算子记录，原样放过、归模板验

// lenient：拿不到基准表时（局部样式）只验样式键，别的键放过、字典往里再验
#let validate-style(entry, name, line-spacing-auto: false, base: none, lenient: false) = {
  if type(entry) != dictionary {
    panic(name + ": expected a dictionary, found " + repr(entry))
  }
  let subs = _sub-keys(base)
  for (key, v) in entry {
    if key == "bold" {
      panic(name + ".bold: use weight for native text weight")
    }
    if key not in style-keys and key in subs {
      validate-style(
        v, name + "." + key, base: base.at(key),
        line-spacing-auto: base.at(key).at("line-spacing", default: none) == auto,
        lenient: lenient,
      )
      continue
    }
    // 模板自己的键（基准表里有、又不是样式键，如表格的 inset、stroke）：原样放过，归模板验
    if key not in style-keys and base != none and key in base { continue }
    if subs.len() > 0 and key not in style-keys {
      panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(subs, key))
    }
    if key not in style-keys and lenient {
      if type(v) == dictionary { validate-style(v, name + "." + key, lenient: true) }
      continue
    }
    if key not in style-keys {
      panic(name + ": unknown key \"" + key + "\"; " + _errors.expected-one-of(style-keys, key))
    }
    let where = name + "." + key + ": "
    if key == "font" and v != auto and type(v) not in (str, array, dictionary) {
      panic(where + "expected a native font description or font profile")
    } else if key == "size" and (type(v) != length or v.em != 0) {
      panic(where + "expected absolute length such as zihao.xiaosi or 12pt, found " + repr(v))
    } else if key in ("weight", "style", "lang", "region", "baseline", "tracking") {
      // 取值域交给 Typst，避免另建一份字重、语言和地区协议。
      let _ = text(..((key): v), [])
    } else if key in ("kerning", "snap-to-grid", "justify", "pagebreak-before", "sticky", "breakable") and type(v) != bool {
      panic(where + "expected true or false, found " + repr(v))
    } else if key == "line-spacing" and not (_line-spacing-ok(v) or (line-spacing-auto and v == auto)) {
      panic(
        where + "expected \"single\", \"double\", a number, a length, or a dictionary with "
          + "\"exactly\" or \"at-least\""
          + (if line-spacing-auto { ", or auto (this style resolves it by itself)" } else { "" })
          + ", found " + repr(v),
      )
    } else if key in ("above", "below") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("lines",)
        and type(v.lines) in (int, float))
    ) {
      panic(where + "expected none, length, or dictionary with numeric \"lines\", found " + repr(v))
    } else if key in ("first-line-indent", "hanging-indent", "left-indent") and not (
      v == none or type(v) == length or (type(v) == dictionary and v.keys() == ("chars",)
        and type(v.chars) in (int, float))
    ) {
      panic(where + "expected none, length, or dictionary with numeric \"chars\", found " + repr(v))
    } else if key == "align" and type(v) != alignment {
      panic(where + "expected alignment (left, center, or right), found " + repr(v))
    }
  }
}

#import "./state.typ": styles-state, local-styles, current-styles, merge-local

// 局部样式通过 state.typ 的栈生效；已有文档时按基准表检查样式名和子记录。
// 模板扩展属性保留给模板校验。只有 body 就地重装，其他条目由消费模板读取。
#let check-local(local, base: none) = {
  if type(local) != dictionary {
    panic("new-styles: expected a dictionary (the same shape as document(styles:)), found " + repr(local))
  }
  for (name, entry) in local {
    if type(entry) != dictionary { panic("new-styles: " + name + ": expected a dictionary, found " + repr(entry)) }
    if base != none and name not in base {
      panic("new-styles: unknown style \"" + name + "\"; " + _errors.expected-one-of(base.keys(), name))
    }
    let record = if base == none { none } else { base.at(name) }
    validate-style(entry, "styles." + name, base: record, lenient: true,
      line-spacing-auto: record != none and record.at("line-spacing", default: none) == auto)
  }
}

/// 校验并合并基准样式、模板预设与用户覆盖，优先级为 `base < preset < local`。
/// 同名样式按基准表声明的子记录递归合并；属性值整体替换，保留未覆盖的同级属性。
///
/// `body` 是必需样式，别的条目叫什么、怎么分由上层模板定。哪些条目带子记录由基准表的形状决定
/// （值是样式记录或记录的记录，如 `theorem: (head: …, body: …)`）；基准表里模板自己的键（如表格的
/// `inset`、`stroke`）docxtyp 不认识，原样放过，由模板验。
///
/// ```typ
/// #let resolved = styles(
///   (body: (size: 12pt, line-spacing: 1.25)),
///   (body: (first-line-indent: (chars: 2), justify: true)),
/// )
/// ```
/// -> dictionary
#let styles(base, local, preset: (:)) = {
  if type(base) != dictionary { panic("styles.base: expected a dictionary, found " + repr(base)) }
  for (name, entry) in base {
    if type(entry) != dictionary { panic("styles.base." + name + ": expected a dictionary, found " + repr(entry)) }
  }
  let check(table, source) = {
    if type(table) != dictionary { panic(source + ": expected a dictionary, found " + repr(table)) }
    for (name, entry) in table {
      if name not in base {
        panic(source + ": unknown style \"" + name + "\"; " + _errors.expected-one-of(base.keys(), name))
      }
      validate-style(entry, source + "." + name, base: base.at(name),
        line-spacing-auto: base.at(name).at("line-spacing", default: none) == auto)
    }
  }
  check(preset, "styles.preset")
  check(local, "styles")
  merge-table(merge-table(base, preset, shape: base), local, shape: base)
}
