// 文档级样式存于 state；局部样式以栈记录，离开 show 作用域后恢复。
#let styles-state = state("iota-styles", none)
#let local-styles = state("iota-local-styles", ())

#import "./merge.typ": merge-table as merge-local

/// 读取文档级样式表与 `new-styles` 局部覆盖的合并结果。必须在 context 中调用。
/// 这是模板配置表；引擎不读取该表或其中的 body、chapter 等名称。
/// -> dictionary
#let current-styles(default: none) = {
  let document = styles-state.get()
  if document == none {
    document = default
    if document == none { panic("no iota styles in effect") }
  }
  let s = document
  for local in local-styles.get() {
    s = if local == none { document } else { merge-local(s, local, shape: document) }
  }
  s
}

// 选择规则使用的正文样式：`current` 为真时读取局部覆盖后的当前样式，否则返回传入的 `style`。
// 必须在 context 中调用。
// -> dictionary
