// 本地化词条的字面：from(桶) 哨兵与 term-defaults 那张表。*只放值*——state、
// 覆盖键的解析与查表（terms-overrides、term-table、term-of、term-for…）住在
// src/terms/lookup.typ。
//
// *放字面，以及*属于某个字面*的取值。* 分隔符是字面（它是一段内容）；
// in-english-toc 是那一页在英文目录里的字面。两字标题撑开先前也是这里逐条写的
// title-spread，现在是判据（恰好两个汉字），住在 src/heading/spread.typ，表里不再有。
//
// 不属于任何字面的*版面取值*仍然不进来：字体角色、编号函数这些的来源是
// Word 范例实测，不是「因为这段是中文所以如此」，而且已经在各部件里连着实测
// 记录一起写着（英文关键词那行的冒号走宋体、中文那行走黑体，就是量出来的）。
//
// *做兄弟键，不嵌进 heading 里。* 写成 heading: (text: …, spread: …) 的话，
// 用户只想改字面时写 heading: (text: [中文摘要]) 会*连带丢掉* spread
// ——我们的合并只有一层深。
//
// *两级：语言 → 页。* 不摊平成一层——摊平之后 author-bachelor 与
// abstract 并排躺着，看不出前者只有内封用得上；而且两页各有一个 title 时只能
// 靠前缀区分，越加越长。各页一个桶，*真有多页在印*的进 base。
//
// 查表是「本页的桶盖在 base 上」，本页没有就用 base 的，两处都没有就报错。
// 这不是回落兜底，是*两个位置的定义域*——base 里的校名本来就属于所有页。
//
// *叫 base，是因为名字该说位置。* 它在查表里的位置就是最底下那一层，页桶
// 盖在它上面。叫 default 会在用户一覆盖之后开始说谎——那时它不再是任何意义上的
// 默认，而 from("base") 那个哨兵还得指着它。
//
// *但收谁是另一条规矩，而且是紧的：确实有两页以上在印这几个字才进来。*
// 「这东西概念上属于文档级」不算理由——学位类别（「（学术学位论文）」）只有封面
// 印，「年」「月」「日」只有声明页的签名行印，都留在原处。字面本来就是死的，
// 挪进 base 换不来任何东西，只会让这一桶变成「一时不知道放哪」的杂物袋。
//
// *两档语言，zh 与 en。* HIT 的规范里没有第三种，留 ja / de 的空位等于
// 留一堆填不满的表。整篇英文论文那一档（hithesis 的 en 选项）眼下不做，口子
// 留着——那需要再加一层文档级默认语言。
//
// 「这一格不自己定字，跟 base 那一条走」。
//
// *为什么要占这个位置而不是干脆不写。* 不写的话查表自然会落到 base 上，
// 但用户就*没有只改这一页的办法*了——覆盖键要求词条确实住在那个桶里，
// header-document-type-bachelor 会当作写错的键报错。占着位置，两种改法都在：
// 改 base-* 全篇一起变，改 header-* 只动这一页。
//
// *换的是 base 里*当时*的值，不是表里写死的那个。* 文档级覆盖改的
// 就是 base 桶本身，所以哨兵自然跟着走；这也是它与「抄一遍」的全部区别。
//
// 用 metadata 而不是某个字符串：词条的值是内容、有时还是函数（声明页那两条
// 收题目给整段），随便挑个字面量都可能与真词条撞上；metadata 认得出、也能用
// == 比。
//
// *指向哪个桶是参数*：from("caption") 是「跟 caption 桶里同名那条走」——清单桶的
// 图／表／公式默认就是题注里那个字，用户改了 caption-image 清单跟着变，改
// list-of-figures-image 只动清单；页眉那几条写 from("base")。*对方桶里叫别的名*
// 就写 key:——声明页的签名角色「行业导师」跟内封那一格同字：
// from("titlepage", key: "industry-supervisor")。解析在 src/terms/lookup.typ 的
// _resolve-from，搬的是一族（光键名连同各档）
#let from(bucket, key: none) = metadata((iota-hit-from: bucket, key: key))

// *条号引的是哪一版。* 两份官方文件同时在用，注释里分别叫：
//
//   *本科指南*  《本科毕业论文（设计）写作指南（理工类）》，条号形如 2.12、3.2
//   *研究生规范* 研究生那份。2025 年 3 月研究生院重发为《哈尔滨工业大学学位论文
//                    写作指南（理工类）／（人文社科类）》（本机 ~/Downloads/最新版硕博
//                    的 g-stem.docx / g-hss.docx），*条号整体重编*：旧版 1.1.x
//                    「内容要求」成了 1.x，旧版 1.2.x「书写规定」成了 2.x，附录也顺移
//                    一位（法定计量单位 附录1 → 附录2，索引示例 附录5 → 附录6）。
//                    *注释里一律引新版*。对照：
//
//                      旧 1.1.5 → 新 1.5   参考文献（本人成果不列入）
//                      旧 1.1.6 → 新 1.6   成果（新版多了「专著、产品、行业标准、
//                                          研究报告、竞赛获奖等可单独分项分别列出」）
//                      旧 1.1.9 → 新 1.10  个人简历
//                      旧 1.2.2 → 新 2.2   页码（前置罗马、正文以后阿拉伯）
//                      旧 1.2.4 → 新 2.4   目录内容
//                      旧 1.2.7 → 新 2.8   名词术语（第一次出现的缩写词注明英文原词）
//                      旧 1.2.8 → 新 2.9   物理量标注
//                      旧 1.2.15 → 新 2.16 附录
//                      旧 1.2.16 → 新 2.17 成果的书写格式
//                      旧 1.2.17 → 新 2.18 索引
//                      旧 1.2.18 → 新 2.19 个人简历
//
//                    新版另有一条*新增*：2.7 人工智能生成合成内容标识。
//
// 本科指南的条号*没变*，那一份不动。
#let term-defaults = (
  zh: (
    // 跨页共用
    // *base 桶只存字面，不是谁的页。* 几页印同一个词（校名、文种、导师……）时字写
    // 在这儿一份，*印它的每一页在自己的桶里各写一条 xxx: from("base")*——用户改
    // 一页就覆盖那一页的键（cover-university），改所有页就覆盖 base 的
    // （base-university），两种改法都留着。term-table 虽然把 base 并进每一页，可
    // 光靠并进去，页的桶里没有那个键，页面级的覆盖就报「unknown term key」，用户
    // 改不了单独一页。from 连着档位一族一起搬，见 src/terms/lookup.typ 的 _resolve-from
    base: (
      // 那条红字末尾都缀这一句，三页（封面、内封、报告首页）各 from 一条——排在
      // 纸角的东西越少越好，可不说一声「怎么关掉」，用户只能翻文档。
      //
      // *后缀是那个值，不是「关掉」。*照 form-dissertation、degree-type-academic、
      // document-type-bachelor 那一路：后缀写下的是参数取的*那个值*，于是
      // 键名与句子里那半句 `warning: false` 对得上，改参数时 grep 得到。
      warning-false: [强制关闭本警告请用 `warning: false`],
      // *校名，不叫 institution。* 内封那一格的*标签*才叫
      // institution（本科印「学校」、研究生印「授予学位单位」），它的*值*
      // 是这里这几个字。一个是字段身份、一个是这所学校的名字，两回事；同名的话
      // term-for 沿着档位往上退时会退到校名头上，把「哈尔滨工业大学」当标签印
      // 在冒号左边，编译还不报错。
      university: [哈尔滨工业大学],
      // *深圳本科那两份印的是第三个字面*：首页与页眉都印「深圳校区」那个，
      // 而研究生的页眉印「哈尔滨工业大学（深圳）」（那一条只有页眉在印，留在
      // header 桶）。*两页在印就该住 base*——先前 cover 与 header 各抄了
      // 一份同样的字，改一处会漏；分支照旧靠轴后缀，解析器自己挑更专的那条
      university-bachelor-shenzhen: [哈尔滨工业大学深圳校区],
      // *文种，不是学位。* 印出来的是「本科毕业论文（设计）」这种*东西
      // 的名目*，学位是「学士」——两回事。hithesis 那边也分着写
      // （document-type-bachelor 与 degree-level-zh，hit-thesis.cls:566/574）。
      // 先前这三条叫 degree-*，照的是「按学位分档」这件事，把*档*写进了
      // 字段身份里。
      //
      // *带括号。* 官方范例（理工类）的封面第 2 页与内封第 3 页印的都是
      // 「本科毕业论文（设计）」；不带括号的是「1-8 页」那个节选本，旧版
      document-type-bachelor: [本科毕业论文（设计）],
      document-type-master: [硕士学位论文],
      document-type-doctor: [博士学位论文],
      // 实践成果那一档（form: "practice"，见 src/axes.typ）。字取自
      // 《研究生实践成果写作指南》3.3.1 封面（「□士实践成果」）与 3.4 页眉
      // （「哈尔滨工业大学博士实践成果」）。*本科没有这一档*——本科那份
      // 指南通篇写「本科毕业论文（设计）」，括号已经把设计一并覆盖了，所以
      // form 在本科只改内封勾哪个框，不换任何字
      document-type-master-practice: [硕士实践成果],
      document-type-doctor-practice: [博士实践成果],
      // *同一样东西，不带学位。* document-type 是「硕士学位论文」，这两条是
      // 「学位论文」——差的正是前面那个学位。报告首页那一行
      // 「（学位论文/实践成果）」印的是它（表单上两个都印着，填写说明写「选择
      // 其一，另一项删除」，那就是 form 轴）；声明页与答辩决议页的标题、小标题、
      // 那句「本人知悉…的使用权限」印的也是它。
      //
      // *住 base，因为三页在印*——先前只住 cover 桶，另两页各自把这两个词
      // 抄进了自己的六条词条里（statement/-practice/-bachelor 那种），改一处措辞
      // 要改六处。取值走 subject-of，见 src/terms/lookup.typ。
      //
      // *本科不在这两条上分档*：指南通篇写「本科毕业论文（设计）」，括号已经
      // 把设计一并覆盖了（见 src/axes.typ 的 form），所以本科那一档取的是
      // document-type-bachelor，不在这儿再写一条——写了会与 -practice 一样专，
      // term-for 判歧义而报错。
      // *一族四条，键名是 form 的档名再按学位分*：硕博两条印在报告首页那一行、
      // 声明页与答辩决议页（取值走 subject-of）；本科两条是勾选框那两行的字——本科
      // 内封第一行（☐毕业论文 ☐毕业设计）与深圳本科报告首页那一行（2026 年 9 月版
      // 新加）*两页在印*，所以住这儿。本科那两条*只当勾选框的标签*：本科
      // 的「这份东西叫什么」是 document-type-bachelor（毕业论文（设计）），不按 form 分
      form-dissertation: [学位论文],
      form-practice: [实践成果],
      form-bachelor-dissertation: [毕业论文],
      form-bachelor-practice: [毕业设计],

      // ── 两页共用的字段标签 ──────────────────────────────────────────────
      //
      // 内封与报告首页各有一张字段表，这三条在两张表上*逐字相同*，字写这儿；
      // 两页各自 from 过去（cover 桶、titlepage 桶）。只有*两页不同*的才直接住
      // 各自桶里：作者（内封「本科生」／报告「学生」）与日期（内封「答辩日期」／
      // 报告「开题报告日期」）。
      student-id: [学号],
      supervisor: [导师],
      supervisor-bachelor: [指导教师],
      speciality: [学科],
      speciality-bachelor: [专业],
      // *base 只放各页共用的字*。硕博实践成果那一档内封印「类别」——那是内封一页的字，
      // 住 titlepage 桶；先前住这儿，from("base") 把它连族搬进了报告首页的桶，与首页要印的
      // 带斜杠的全称一样专，得再写更专的档压回去，一处一处补。一页专有的档住那一页
    ),
    // 封面。*只有中文这一份*——#cover 排的就是中文封面（英文那一页是内封，
    // 走 titlepage-en）。先前英文侧躺着一个 cover 桶，两条 degree-type 谁都读不到
    // ——term-table("en", "cover") 在整个包里一次都没出现过；补第三条只是多一条
    // 死词，删掉才对。哪天封面真有了英文档，那时候一次补齐
    // 封面。*只有中文这一份*——#cover 排的就是中文封面（英文那一页是内封，
    // 走 titlepage-en）。先前英文侧躺着一个 cover 桶，两条 degree-type 谁都读不到
    // ——term-table("en", "cover") 在整个包里一次都没出现过；补第三条只是多一条
    // 死词，删掉才对。哪天封面真有了英文档，那时候一次补齐。
    //
    // *终稿封面与报告首页同住这一桶*——#cover() 按 stage 派给两处排版
    // （src/pages/cover.typ 与 src/pages/report/cover.typ），*页是同
    // 一页*，桶按页分、档由轴分，这是全表一以贯之的做法。
    //
    // *排序按族，不按「哪一页在用」。* 一个词条属于终稿还是报告，是 stage
    // 这根轴的事，不该在表里再劈一遍——劈了之后同族的键分散在两段（先前
    // degree-type 在上、speciality-not-bachelor-harbin 在下，中间隔着七条），查表的人
    // 得两处都翻。族名字母序，族内光键名在前、其余照轴的档序。
    cover: (
      // 学位论文／实践成果那一族住 base，from 过来（报告首页那一行、深圳首页的勾选框）
      form: from("base"),
      // 文种那一族住 base，from 过来
      document-type: from("base"),
      // 校名住 base（字见那儿）；这一页 from 一条，页面级才改得动——改法见 base 桶抬头
      university: from("base"),
      // 红字末尾那句住 base，from 过来
      warning-false: from("base"),
      // 排不下时在纸角发的那条红字。*三处的字面各自不同、都住在自己那一页
      // 的桶里*——先前是写死在 src/pages/cover.typ、src/pages/titlepage.typ 的
      // 调用处的，改不动、查不着，对称性对拍也管不上。
      //
      // *它不属于版面，是说给作者听的*，所以跟着读者的语言走：中文内封走 zh
      // 侧、英文内封走 en 侧（src/api.typ 的 titlepage），两页各自会排不下，
      // 两条也各说各的语言。
      // *论文封面只走 zh 侧*（src/api.typ 的 cover），可*报告首页有英文
      // 那一档*（深圳那两份留学生版、本部硕中英文版），所以 en 侧也写了一条。
      warning-overflow: [封面排不下，已溢出到第二页。请缩短题目。],
      // 深圳本科报告首页那张信息表：值折了行把表撑长，各行匀着压到字要碰上一行的线
      // 仍装不下，见 src/pages/report/shenzhen/cover.typ「装不下时整体压缩」
      warning-crowded: [信息栏装不下，行距已压到底仍溢出。请缩短题目或学院名。],
      // 硕博那三份多两格，字与内封也不同：内封印「所在单位」「学科」，
      // 这一页印「学院（部）」「学科/专业学位类别」。*本科那两份没有这两格*
      // ——它的表只有五格，行表在页面里按学位分，见 src/pages/report/cover.typ
      affiliation: [学院（部）],
      // *深圳那两份另有一套字*（校区那根轴，见 src/axes.typ）：
      // 「院（系）」而不是「学院（部）」；学科那一格开题印「学科/专业」、中期
      // 印光「学科」（本部两份都印「学科/专业学位类别」，按学位类别分档）。
      // 逐字取自 深圳硕士学位论文开题报告模板（2018版）.docx 与 深圳中期中文.docx
      affiliation-shenzhen: [院（系）],
      // 深圳本科那两份印「学院」，2026 年 9 月版加了全角冒号（下同）
      affiliation-bachelor-shenzhen: [学院：],
      // *五格里只有两条是这一页自己的*：作者与日期。专业、学号、指导教师
      // 三条与内封逐字相同，住 base 桶（term-table 把 base 并进每一页），
      // 这儿不抄。
      //
      // *存裸标签*：docx 里是拿字面空格撑成 4 个字宽的（「专」+四个半角+
      // 「业」＝ 64pt，与「指导教师」齐），但 markup 会把连续空格折叠掉，存进
      // 词条就废了——撑宽在 src/pages/report/cover.typ 的 _label 里做。
      //
      // *不带 -proposal/-interim*：开题与中期这两格的字一模一样，写成一对
      // 后缀就是同一个词抄两遍，还得为「这两档」发明一个上位档——那层机制包里
      // 删过一次（见 src/axes.typ 开头）。终稿那一档根本不问这两个键：
      // 论文封面上姓名不带标签、日期也不是这一格。
      //
      // *但作者那一格要按学位分。* 本科两份印「学生」，硕博三份印
      // 「研究生」（硕士开题上是「研   究   生」，字面空格撑到 4 字宽）。
      // 光键名给硕博、本科另写一条，与 base 里的 supervisor / speciality
      // 同一个约定——先前这里只写了光键名的「学生」，硕博也就跟着印错。
      author: [研究生],
      author-bachelor: [学生],
      // 深圳本科那两份印「姓名」，不是本部那两份的「学生」
      author-bachelor-shenzhen: [姓名：],
      student-id: from("base"),
      // *这一档七个标签都带全角冒号*（2026 年 9 月版）。学号、专业、指导教师、
      // 日期四条的光键名住 base（与内封同字、那边不带冒号），所以这一页各写一条
      // ——冒号是这一页的字面，不是那四条的
      student-id-bachelor-shenzhen: [学号：],
      supervisor: from("base"),
      supervisor-bachelor-shenzhen: [指导教师：],
      date: [日期],
      date-bachelor-shenzhen: [日期：],
      // 学位类别，照 hithesis 的 student-type（hit-thesis.cls:403）      // *学位的名。* 开题与中期报告的标题头一截用它：「硕士学位开题报告」。
      //
      // *与上面的文种是两样东西*，虽然只差两个字：文种是「交上去的那份
      // 东西叫什么」（硕士学位论文／硕士实践成果），学位是「读的是什么学位」。
      // 报告标题印的是后者——那份材料还没成文，只能报学位。
      //
      // *本科那一条印不到报告标题上*——本科那两份表单的标题头一截是文种
      // （「本科毕业论文（设计）开题报告」）不是学位，那一档的模板取的是
      // document-type。留着它是因为英文版要（Thesis Proposal of *Bachelor*
      // Candidates），成果那一章的「攻读学士学位期间」将来也要。
      //
      // *也不能拿它去拼文种。* 「硕士学位」＋「论文」的确等于
      // document-type-master，可实践成果那一档拼不出来——「硕士实践成果」中间
      // 没有「学位」二字。要强行统一就得再拆成三段、按 (degree-level, form) 分档，
      // 8 条换 8 条、一个不省，还多一层间接。
      degree-bachelor: [学士学位],
      degree-master: [硕士学位],
      degree-doctor: [博士学位],

      degree-type-academic: [（学术学位论文）],
      degree-type-professional: [（专业学位论文）],
      // 实践成果那一档，《实践成果写作指南》3.3.1 印的是「（专业学位□□……□）」。
      //
      // *□□……□ 填的是实践成果类型*（调研报告、案例分析报告、产品设计
      // 报告……），不是学科、也不是专业学位类别。两处对得上：3.3.1 封面那一段
      // 后面紧跟着「实践成果类型可参考表2」加表 2 实践成果类型列表；附录 7 的
      // 空白封页示例把这一行逐行注了出来——「博/硕」→「实践成果类型，参考表2」
      // →「中文论文题目」→「英文论文题目」，与封面四行一一对上。
      //
      // 拿学位论文那一档比也是这个读法：「（专业学位论文）」＝ 专业学位 ＋ 论文，
      // 实践成果就是专业学位 ＋ 那一类报告。
      //
      // *写成收值的函数*：词条的值本来就允许是函数（声明页那两条同款），
      // 括号里那一截由 cover 把 info.practice-type 填进来。*学术学位没有
      // 这一档*——实践成果只有专业学位才交，写了会当场报错
      degree-type-professional-practice: practice-type => [（专业学位#practice-type）],
      // 首页末一行。硕博三份印「研究生院制」（三号，与字段同号），本科两份印
      // 「哈尔滨工业大学教务处制」（隶书小二）——字、字号、字体三样都不同。
      // 光键名给硕博，本科另写一条
      seal: [研究生院制],
      seal-bachelor: [哈尔滨工业大学教务处制],
      // 深圳：开题印「深圳校区教务部 制」（中间一个半角空格，逐字照原件），
      // *中期那一份没有落款*——封面末尾直接是空段，所以写 none：页面按
      // 「取到 none 就不排这一行」办，见 src/pages/report/cover.typ
      seal-proposal-shenzhen: [深圳校区教务部 制],
      seal-interim-shenzhen: none,
      // 三格标签住 base（内封同字），from 过来
      speciality: from("base"),
      // *「学科/专业学位类别」照字面印，不按学位类别挑一个。* 本部硕博三份表单
      // （博士开题、硕士开题、硕士中期）这一格印的都是带斜杠的全称，而填写说明
      // 只对「（学位论文/实践成果）」写了「选择其一，另一项删除」，对这一格一个字
      // 没说——先前按 degree-type 拆成「学科」「专业学位类别」两档是类推，不是出处。
      // 只印一个的走词条覆盖：overrides: (cover-speciality: [学科])。
      //
      // *只限本部硕博*：深圳研究生那两份（2018 版）这一格是光「学科」（base 桶的
      // 光键名），本科各份是「专业」（speciality-bachelor）；英文版各份是光 Discipline
      speciality-not-bachelor-harbin: [学科/专业学位类别],
      speciality-bachelor-shenzhen: [专业：],
      // 报告标题 ＝ ｛头一截｝＋｛阶段名｝，日期那一格 ＝ ｛阶段名｝＋日期，
      // *两个词槽，没有第三段*：
      //
      //   本科：本科毕业论文（设计）＋ 开题报告      开题报告 ＋ 日期
      //   硕博：硕士学位            ＋ 中期报告      中期报告 ＋ 日期
      //
      // *拼，不逐档写死。* 写死的话「本科毕业论文（设计）」要抄两遍、硕博
      // 一来再翻一倍，而且手上没有的「博士中期」也就无处安放——拼出来它自然成立。
      // 五份官方表单在字这一层就是同一张模板加这两个词槽（版面那一层原件各改
      // 各的，已统一，见 src/pages/report/cover.typ）。
      //
      // 头一截不在这儿存——本科取 base 的 document-type、硕博取 base 的
      // degree-level，那边写着两者为什么不是一回事。
      //
      // *「报告」两个字并在阶段名里*，不单独成一条：日期那一格是
      // 「开题报告日期」＝ 阶段名 ＋ 日期，正好共用同一个词。
      // 首页那一行*表单名*的拼法。收三样：学位的名、文种、阶段名，
      // *每一档只用它要的那几样*——中英的语序与用料都不同：
      //
      //   zh 硕博   ｛学位｝＋｛阶段｝            硕士学位 ＋ 开题报告
      //   zh 本科   ｛文种｝＋｛阶段｝            本科毕业论文（设计）＋ 开题报告
      //   en 开题   Thesis Proposal of ｛学位｝Candidates
      //   en 中期   Interim Report for ｛文种｝
      //
      // *英文两个阶段的句式互不相同*（一个要学位词、一个要文种），所以英文
      // 那一侧按 stage 分档、中文这一侧按 degree-level 分档——同一个键名，两种分法。
      // 写死成六条也行，但那样博士中期与本科英文版就只能靠手抄；拼出来它们自然
      // 成立，与报告标题一路的道理（见下面 stage-*）。
      report-title: (degree, document-type, stage) => degree + stage,
      report-title-bachelor: (degree, document-type, stage) => document-type + stage,
      // 深圳那两份用的是*文种*那一截：「硕士学位论文」＋「开题报告」——
      // 与本科那一档同一个拼法，本部硕博才是「硕士学位」＋「开题报告」
      report-title-shenzhen: (degree, document-type, stage) => document-type + stage,
      // *本科那一档要写第二遍*：report-title-bachelor 与 report-title-shenzhen
      // 一样专，本科的深圳文档会撞上——两条的拼法本就相同，写出来它就不再是歧义
      // 深圳本科那两份印的是*「毕业论文（设计）」＋阶段*——不带「本科」
      // 两个字（本部那两份印的是「本科毕业论文（设计）开题报告」）。
      //
      // *2026 年 9 月版不再按 form 换字*：先前那两份原件一份印「毕业设计
      // 开题报告」、一份印「毕业论文中期报告」，我们照它按 form 分了四条；新版
      // 两份都印「毕业论文（设计）」，论文还是设计*改由首页那一行勾选框*
      // 表示（☐毕业论文 ☐毕业设计，与本科内封第一行同一对词，见 base 桶的
      // form-bachelor-dissertation / form-bachelor-practice）。所以这里只剩一条，form 不再进键名
      report-title-bachelor-shenzhen: (
        (degree, document-type, stage) => [毕业论文（设计）] + stage
      ),
      stage-proposal: [开题报告],
      stage-interim: [中期报告],
      // 「题 目：」那一行。中间一个半角空格，冒号是全角
      title: [题 目：],
      // 深圳本科那两份的表里*冒号是 2026 年 9 月版加的*（旧版那一格光印
      // 「题　　　目」）；撑宽在 src/pages/report/shenzhen/cover.typ 的 _label 里做，
      // 冒号跟在撑开的两个字之后
      title-bachelor-shenzhen: [题目：],
    ),
    titlepage: (
      supervisor: from("base"),
      // 字段标签住 base（报告首页同字），from 过来
      speciality: from("base"),
      // 硕博实践成果那一档印「类别」——《实践成果写作指南》3.3.2 那张表：
      // 「类        别：□□…□（按授予学位的专业学位类别名称填写）」。
      // 学位论文那一档指南写的是「学科或类别」，但*范例印的是「学科」*
      // （博士范例第 3 页），范例为准。*只有内封印它*，所以住这儿不住 base。
      // *写 -not-bachelor-practice，不写光 -practice*：本科毕业设计走的也是 form:
      // practice（design 是它的别名），光 -practice 与 -bachelor 一样专，本科毕业设计当场
      // 判成歧义（实测 degree-level: "bachelor", form: "design" 报 ambiguous term）；本科这一格
      // 只有「专业」，「类别」只限硕博实践成果。反档的写法见 src/axes.typ
      speciality-not-bachelor-practice: [类别],
      // 勾选框那两条住 base，from 过来
      form: from("base"),
      // 文种那一族住 base，from 过来（第一行印它）
      document-type: from("base"),
      // 红字末尾那句住 base，from 过来
      warning-false: from("base"),
      // 排不下时在纸角发的那条红字，字面先前写死在 src/pages/titlepage.typ 的
      // 调用处。*中英两侧说的是两页*——中文内封走 zh 侧、英文内封走 en 侧
      // （src/api.typ 的 titlepage），两页各自会排不下，两条也各说各的语言。
      // *补了「请缩短题目」*：先前三条里只有这一条光说现象不给出路。
      warning-overflow: [内封排不下，已溢出到第二页。请缩短题目。],
      // 表头那几格
      secrecy: [密级],
      classified-index: [国内图书分类号],
      udc: [国际图书分类号],
      school-code: [学校代码],
      // 字段表的标签，也就是冒号*左边*那几个字。
      //
      // *键名 = 字段身份，两个容器共用。* 冒号右边的值在
      // src/info.typ，同名——terms.speciality-graduate 是「学科」，
      // info.speciality 是「机械制造及其自动化」。哪一边是标签由*住在哪张
      // 表*决定，不靠键名上的前缀：先前那个 field- 只在拼字符串的时候起了个装饰
      // 作用，而且表头那四格（密级、国内图书分类号……）同样是带冒号的标签、
      // 却没有前缀，一半带一半不带。
      //
      // *印出来的字不进键名。* 英文侧先前叫 field-candidate 与
      // field-degree-institution，是照抄了自己这一档的印刷文字；中文侧印的是
      // 「本科生」「授予学位单位」，于是看着像另起了一套名字，同一个字段落得
      // 三个名（数据侧还有第三个 author / institution）。印什么字是*值*
      // 的事，Candidate 与 Degree-Conferring-Institution 一个字母没少，都在
      // 下面 en 档里。
      //
      // *后缀是档，不是另一个词条。* 本科印「指导教师」、研究生印「导师」，
      // 是同一格按学位换字，不是两个不相干的说法；后缀由 term-for 按学位轴挑，
      // 见 src/axes.typ。
      //
      // *光键名是默认档（硕博），本科那条紧跟其后。* 成对相邻是有意的：
      // 光键名在这张表里有两种意思——defense-date 那条所有档都印，institution
      // 那条只管研究生。挨着写，扫一眼就知道下面有没有跟一条 -bachelor。
      //
      // 姓名那一格三档各印各的字，没有默认可言，所以三条都带后缀。
      author-bachelor: [本科生],
      author-master: [硕士研究生],
      author-doctor: [博士研究生],

      // 「副导师：□□□（副）教授（无副导师的研究生不列此项）」「行业导师：
      // □□…□（姓名职称，无行业导师不列此项）」——指南 3.3.2 内封那张表。
      // *括号里那句就是机制*：值空着整行不排，见 src/pages/titlepage.typ
      co-supervisor: [副导师],
      industry-supervisor: [行业导师],
      degree-applied: [申请学位],

      affiliation: [所在单位],
      affiliation-bachelor: [学院],
      defense-date: [答辩日期],
      institution: [授予学位单位],
      institution-bachelor: [学校],
    ),
    abstract: (
      title: [摘要],
      // 「摘  要」在 docx 里就是「摘」+ 两个空格 +「要」。逐字之间插一段，
      // N 个字插 N−1 段，与 hithesis 的 \__hit_spread_by:nn 一致。
      // *只有两个字的标题撑开*——判据与开关住在 src/heading/spread.typ，表里不写。
      // 这一页在*英文目录*里的那一条叫什么，见 src/terms/lang.typ 的 en。
      //
      // *名字里带个介词是有意的。* 它说的是「*在*英文目录中的叫法」，
      // 不是英文目录本身；而且不能叫 toc-en——扁平写法里 -zh / -en 是*语言*
      // 的位置，那样会与「toc 桶的 en 档」撞，得靠枚举断法才分得开。
      //
      // *只有摘要要写这一条。* 别的部分在英文目录里就叫它英文版的标题
      // （结论那条是 en.conclusion.title = Conclusions），原语默认就去 en
      // 桶取。摘要是唯一的例外：一个部分*两页*，英文目录里得把两页
      // 分别叫出来，而 en.abstract.title 只有一个「Abstract」，叫不全。
      //
      // 字是英文，但它是*中文摘要页*的条目，所以住在 zh 档：判据是
      // 「这是谁的条目」，不是「这几个字是什么语言」。
      // Chinese / English 是专名，套花括号让 title-case 两档都不动它（花括号在印出来
      // 之前剥掉，见 src/fonts/case.typ）；那个 In 不括——按英文惯例它是介词，句式
      // 与题式里都该小写，范例写大写是 Word「每个单词首字母大写」留下的，none 档照印
      in-english-toc: [Abstract (In {Chinese})],
      // 人文博士范例的英文目录里 Abstract 后没有空格（s-hss.docx 的 run 是 A + bstract(In
      // Chinese)），两条都是；理工那份有。各照各的范例
      in-english-toc-hass: [Abstract(In {Chinese})],
      keywords: [关键词],
      keywords-separator: [；],
    ),
    // 目录。*桶名与部件同名*（table-of-contents、list-of-figures…），缩写只留在
    // 配置项那一头（样式表的 toc-1、setting-homes 的 toc / lof / lot / loe）
    table-of-contents: (
      title: [目录],
      // 目录自己默认不进目录（范例里没有这一条）；写 outlined: true 才进，那时博士档
      // 中英两页靠这一条分开，与摘要、清单同一套
      in-english-toc: [Contents (In {Chinese})],
    ),
    // 图表索引。*规范里没有这一项*——指南与规范章都只提「索引」，那是
    // 2.18 的*专业词语*索引（按拼音／首字母排序、指出页码），不是图表
    // 清单。字样跟 hithesis：它是唯一给了这两份的参考实现（listfigurename /
    // listtablename，hithesis.dtx:6153），而且只在英文档里发。
    list-of-figures: (
      title: [插图索引],
      // 英文目录里这一条叫什么。*与摘要同一个问题*：博士档两份索引各出
      // 中英两页，而它们在英文目录里默认都取「en 那一份的标题」——两页重名，
      // 一模一样的两条挨在一起（实测 List of Figures 出现两次）。所以像摘要
      // 那样把两页分别叫出来。只有 outlined: true 时才用得上
      in-english-toc: [List of Figures (In {Chinese})],
      // 清单里图叫什么：「图1-1」。*三张清单各自有这一条*，默认跟题注里的字走
      // （from("caption")：改 caption-image 清单跟着变，改 list-of-figures-image 只动
      // 清单）；公式那张两处不同字（引用「式」、清单「公式」）所以自己写死。键是被叫
      // 的东西，照 caption 桶
      image: from("caption"),
    ),
    list-of-tables: (
      title: [表格索引],
      in-english-toc: [List of Tables (In {Chinese})],
      table: from("caption"),
    ),
    // 公式清单：条目是编号加公式本身。规范与 hithesis 都没有这一页，字样照上面两条的
    // 形状起
    list-of-equations: (
      title: [公式索引],
      in-english-toc: [List of Equations (In {Chinese})],
      // 清单里公式叫什么：「公式 (2-1)」。引用时按指南 2.11 写短的「式」（caption 桶），
      // 清单里写全称——三张清单里唯一与题注不同字的一条，见上面 figure 那条
      equation: [公式],
    ),
    // 结论。字样照 hithesis 的 conclusion-heading-zh / -en（hit-thesis.cls:611）
    conclusion: (
      title: [结论],
    ),
    // 附录。*章标题是「附录 + 号」*，号那一位的写法由
    // chapter-numbering-letters 定（见 src/settings/defaults.typ），
    // 这里只出「附录」两个字。
    appendix: (
      title: [附录],
    ),
    // 参考文献。字样照 hithesis 的 \bibname。
    //
    // *不撑开*：四个字。判据见 src/heading/spread.typ；实测研究生范例第 18 页
    // 「参考文献」逐字步进 18.00 / 18.00 / 18.00，正好是 18pt 汉字的字身宽，
    // hithesis 那边 \bibname 也是光秃秃地过 \hit@appendix@chapter*（hit-thesis.cls:8399）
    references: (
      title: [参考文献],
    ),
    // 致谢。字样照 hithesis 的 acknowledgement-heading-zh / -en
    // （hit-thesis.cls:613）
    // 攻读学位期间取得创新性成果。本科指南 1.6 / 研究生规范 1.6 与 2.17，排法见
    // src/pages/achievements.typ。
    //
    // *字样按学位，三档各一条，没有光键名。* 本科范例 p31「攻读学士学位期间
    // 取得创新性成果」、博士范例 p22「攻读博士学位期间取得创新性成果」，硕士照推。
    // hithesis 哈尔滨硕博写的是「攻读×学位期间发表的论文及其他成果」
    // （hit-defaults.dtx:1413），与范例相左，不跟。
    achievements: (
      // 三档同一个句式，*都说「创新性成果」*。
      //
      // *有人会想给硕士去掉「创新性」*——规范正文里确实有这么一句：
      //
      //     博士创新性成果或硕士成果须是学位申请人在攻读学位期间在导师指导下完成，
      //     且与学位论文或者实践成果工作密切相关的成果。
      //
      // *但那句管的是「什么样的成果够格列进来」，不是这一章叫什么。* 标题
      // 那一层的证据是齐的、且都指向「创新性成果」：研究生指南 1.6 的*节名*
      // 是「攻读学位期间取得创新性成果」，*不分学位*；本科指南的节名是
      // 「攻读学士学位期间取得创新性成果」，连学士都这么写；两份范例的章标题逐字
      // 如此。拿一句讲收录门槛的话去改标题，是把两层混了。
      //
      // （2026-09-03 一度按那句把硕士改成「取得的成果」，当天改回。记在这儿，
      // 免得下次再犯。）
      title-bachelor: [攻读学士学位期间取得创新性成果],
      title-master: [攻读硕士学位期间取得创新性成果],
      title-doctor: [攻读博士学位期间取得创新性成果],
      // 分组的编号：本科范例「一、发表的学术论文」，博士范例「（一）发表的学术
      // 论文」——光键名是研究生那一档，本科另写一条，与内封字段同一个约定。
      //
      // *group- 这个前缀不能省。* 这一页有*两处*编号：组标题的
      // （一）（二）（三），与每组表里条目的［1］［2］［3］（那个由原生的
      // bibliography(group:) 管，见下面）。省成 numbering 就分不出说的是哪一个
      // ——桶名圈得住范围，圈不住这一页里的两件事。
      //
      // *收的是原生的 numbering 模式*（模式串或函数），与
      // set heading(numbering:)、numbering() 同一样东西；排出来是
      // numbering(这个值, 第几组)。
      //
      // *与被哨兵挡住的那个 numbering 不是一回事*：层次编号是规范定死的
      // （两份指南各一张「表2 层次代号及说明」），所以 set heading(numbering:)
      // 会当场报错（src/heading/rules.typ）；这一处规范只说「可单独分项分别列出」，
      // 分几组、叫什么名都是作者的事，编号样式跟着范例走、照常可覆盖
      group-numbering: "（一）",
      group-numbering-bachelor: "一、",
      // 人文那一档是「一、」——s-hss 的四组组标题就是这么编的，而且那几段用的是
      // *标题 2 样式*（pStyle=2），与正文里节标题的编号「一、」同一套。
      // *写反档 -not-bachelor-hass 而不是 -hass*：本科那条也是「一、」，两条对
      // 人文本科会一样专、判成歧义（见 src/axes.typ）；写成反档，人文本科
      // 走 -bachelor，人文硕博走这条
      group-numbering-not-bachelor-hass: "一、",
      // 三组的名，两份范例逐字相同（专利那组范例后面还带着「（无专利时此项
      // 不必列出）」，那是给作者看的话，不是字样——没有条目就不排这一组）
      papers: [发表的学术论文],
      // 国际会议论文单成一组——人文范例（s-hss）的第二组。*理工范例不拆*：
      // d-stem 论文组的第 ［6］ 条就是 ［C］（Discrete Sliding Mode…Jinan, 2006），
      // 会议论文排在「（一）发表的学术论文」底下。所以这一组只有人文默认列出，
      // 见 src/pages/achievements.typ
      conferences: [发表的国际会议论文],
      patents: [申请及已获得的专利],
      // *「及获奖情况」跟着内容走*：这一组里有 @award 才带那半句。两份范例
      // 都自证——理工那组有一条「黑江省科学技术二等奖」，名字就是「参与的科研项目
      // 及获奖情况」；人文那组只有一条基金项目，名字就是「参与的课题项目」。
      // 判在 src/pages/achievements.typ，不是开关
      projects: [参与的科研项目],
      projects-with-awards: [参与的科研项目及获奖情况],
      // 人文那一档范例写「课题项目」，不是「科研项目」
      projects-hass: [参与的课题项目],
      projects-with-awards-hass: [参与的课题项目及获奖情况],
      // *规范点了名的各成一组*——1.6 那句是「可*单独分项分别*列出」，
      // 把专著、行业标准、研究报告一个个点了名，合成一组等于把分项又合了回去。
      //
      // *句式照范例那三条*：「*发表的*学术论文」「*申请及已获得的*
      // 专利」「*参与的*科研项目及获奖情况」——都是「动词 + 的 + 名词」。
      // 先前这三条我照抄了规范枚举里的裸名词（「专著」「行业标准」「研究报告」），
      // 想的是「不自造」；可排在一起就露怯了——前三条都在说*作者做了什么*，
      // 到这几条只剩一个孤零零的名词，读着像另一份文件里掉进来的。
      //
      // *动词是我们补的*，规范只给了名词——但句式是范例定的，补一个动词
      // 让它归队，比留一个裸名词更贴那三条。要改走 overrides。
      // *字样取自人文范例*（s-hss 第三组「三、参与的专著」，条目是一章析出的
      // ——「第十三章：……唐魁玉. 虚拟社会人类学导论[M]」，所以 @incollection 也归这组）。
      // 理工范例没有这一组；先前这条写「出版的」，动词是我自造的，范例有字就照范例
      books: [参与的专著],
      standards: [参与制定的行业标准],
      reports: [完成的研究报告],
      // 最后一组*才是兜底*，收规范那句「如……*等*」放开的别的形式。
      //
      // *名取规范自己的词*：1.6 那句的主语是「攻读学位期间所获得的*不同
      // 形式的成果*，如……等可单独分项分别列出」——兜底收的正是「等」放开的那些
      // *形式*，所以「其他形式的成果」是把那半句补完，一个字都没自造。
      //
      // *没写「研究成果」*：那个「研究」是限定词，而竞赛获奖、产品、行业标准
      // 算不算研究成果是可以争的——兜底组恰恰要收说不清的，名字比内容窄就尴尬。
      //
      // *也没写「创新性成果」*：一来章标题已经是「攻读…期间取得创新性成果」，
      // 组名再说一遍是在章里重复章名，前六组也没有一个带它；二来「创新性」在规范里
      // 是博士那一档的词——「博士创新性成果或硕士成果须是……」，硕士那一档只说
      // 「成果」，组名写上去等于替硕士作者多认一层。
      //
      // *它非有不可*：单子是开口的，所以「不认识就报错」比规范还严。
      others: [其他形式的成果],
    ),
    acknowledgement: (
      title: [致谢],
    ),
    // 索引。规范 2.18 的字样；*两个字拉开*，与摘要、目录、致谢同——
    // 见 src/pages/index.typ
    index: (
      title: [索引],
    ),
    // 个人简历。字样照博士范例 p27 与 hithesis 的 resume-heading-zh；四个字，
    // 不拉开（范例那一行 bbox 多出的 4.7 是行尾的空格）。见 src/pages/resume.typ
    resume: (
      title: [个人简历],
    ),
    // 缩略语表。*规范与范例都没有这一页*（博士范例中英目录里都没有），字样照
    // hithesis 的 list-of-abbreviations-heading-zh（hit-thesis.cfg:616）；四个字不拉开，
    // 同「个人简历」。两列：缩写、说明（中英全称合成一格）；列头默认不印，
    // header 不是 none 才印。见 src/pages/abbreviations.typ
    // 物理量名称及符号表。字样研究生规范 2.4 逐字（目录内容那条：「物理量名称及符号表
    // （参照附录2，采用国家标准规定符号者可略去此表）」）；八个字不拉开。
    // 见 src/pages/nomenclature.typ
    list-of-symbols: (
      title: [物理量名称及符号表],
      // 列头，header: auto 才印。*按格里装的是什么起名*（与缩略语表的 column-short /
      // column-long 同一个起法），不照 terms 元素的字段名——先前叫 column-term。
      // 左格只有符号，名称跟着单位在右格（/ $sigma$: 应力，MPa），所以左格头是
      // 「符号」不是标题里那句「物理量名称及符号」。字样没有出处——hithesis 与 thu
      // 都不印列头。英文单数：列头说的是这一列每一格是什么，标题才是复数
      column-symbol: [符号],
      column-description: [说明],
    ),
    // 符号及缩略语——合并页 #nomenclature。字样照 hithesis 的
    // list-of-symbols-and-abbreviations-heading-zh（hit-thesis.cfg:617），它手册说这页
    // 给「只列一张“本文符号及缩写”」的论文；页内两段的小标题用两张单页各自的 title。
    // 见 src/pages/nomenclature.typ
    nomenclature: (
      title: [符号及缩略语],
    ),
    // 伪代码的关键字。*键是探测用的词*（algorithm[…] 里按整词、不分大小写认），
    // *值是印出来的样子*：默认就是它自己，大小写由 algorithm-keywords 设定统一
    // （默认全大写）；中文的实验室写 overrides: (algorithm-for: [对于], …) 换词，
    // 中文不受大小写设定影响。清单是 algorithm2e 那一套（\If \For \While \Return
    // \KwIn \KwOut …）；and / or / not / in 不收——逻辑运算写在公式里（$and$），in
    // 是英文里最常见的介词，收进来一行英文叙述里的 or、in 都会被粗（foreach 那一行
    // 的 in 在 algorithm2e 里也只是文字）。见 src/figure/kinds/algorithm.typ
    algorithm: (
      // 键要带引号：if / for / while / return / in / and / or / not / break / continue
      // 是 Typst 的保留字
      "input": [input], "output": [output],
      "if": [if], "then": [then], "else": [else],
      "for": [for], "to": [to], "do": [do], "while": [while], "repeat": [repeat], "until": [until],
      "each": [each],
      "return": [return], "end": [end],
      "function": [function], "procedure": [procedure],
      "break": [break], "continue": [continue],
    ),
    list-of-abbreviations: (
      title: [缩略语表],
      column-short: [缩写],
      column-long: [全称],
    ),
    // 学位论文评阅人、答辩委员会名单及答辩决议。字样逐字取自新增版 docx 那张表
    // （博士范例 p23 印出来的也是这些字），见 src/pages/defense.typ
    defense: (
      // 章标题里那个 subject（学位论文／实践成果）从这一族取（subject-of）；住 base，from 过来
      form: from("base"),
      // 章标题：*只差「这份东西叫什么」*，收成一条收槽的函数，见 subject-of
      title: subject => subject + [评阅人、答辩委员会名单及答辩决议],
      // 《实践成果写作指南》1.7 这一节就叫这个名（「实践成果评阅人、答辩委员会
      // 名单及答辩决议（博士需增加此项）」，括注是适用范围不是标题）
      // 三块的标签与表头
      // docx 那一格是两个段落：「评阅人」一段、「（根据实际人数填写）」一段，后一段
      // 在 Word 的格宽（76.32 减两边 0.19cm 边距）里折成「（根据实际／人数填写）」。
      // 我们的格距跟 hithesis 收到 1pt（见 src/pages/defense.typ），格宽下能
      // 排六个字，自然折就成了「（根据实际人数／填写）」——所以照 hithesis 的
      // resolution-reviewer 把三行写死
      reviewers: [评阅人\ #h(0.001pt)（根据实际\ 人数填写）#h(0.001pt)],
      committee: [答辩委员会成员],
      chair: [主席],
      member: [委员],
      secretary: [秘书],
      column-role: [职务],
      column-name: [姓名],
      column-title: [职称（是否博导）],
      column-affiliation: [工作单位],
      column-discipline: [所在学科],
      resolution: [答辩委员会决议（对论文的评语及是否建议授予博士学位等）：],
      // *这一条没有出处*。上面那句是从新增版 docx 那张表逐字抄的，而实践
      // 成果没有对应的 docx——两份指南都只写到「1.7 ……及答辩决议」为止，表里
      // 那句括注没人写过。照上面那句把「论文」换成「实践成果」，别的一字不动
      resolution-practice: [答辩委员会决议（对实践成果的评语及是否建议授予博士学位等）：],
    ),
    // 题注的名。指南 2.12 / 2.13 的「表序」「图序」，排出来是「图1-1」「表6-1」
    caption: (
      image: [图],
      table: [表],
      // 伪代码的名。指南没有这一种东西，词取 PlutoThesis／algorithm2e 的「算法」
      algorithm: [算法],
      // 代码清单的名。指南没有；Typst 给 raw 的就是「代码」，照它
      raw: [代码],
      // 续排那一页的标注，指南 2.12 / 2.13.2：「编号后加『（续表）』」
      // 「下页标『图序（续图）』字样」——「续」加这一种东西的名，一条函数词条管所有
      // kind：图「（续图）」、表「（续表）」、自造的算法「（续算法）」、显式写了名的
      // 「（续照片）」
      continued: name => [（续#name）],
      // 引用公式时的名。指南 2.11：「文中引用公式时，一般用『见式（1-1）』
      // 或『由公式（1-1）』」——取短的那一个
      equation: [式],
      // 公式底下那份符号注释的引导词。指南 2.11 的两个示例都写「式中」，
      // 范例第 4 章与规范章那张表也都是它。见 src/math/eqdenote.typ
      denote: [式中],
      // 附录里的图表公式，名前加的那个字：「附图1-1」「附表1-1」「（附1-1）」。
      // *只有中文这一份*——英文靠字母把附录的图表与正文分开（Fig. A-1），
      // 没有「附图」这样的词法，也就没有这个字。加不加、什么时候加见
      // src/heading/numbering.typ 的 appendix-prefixed；「附录」那个整词在 appendix 桶
      appendix: [附],
    ),
    // 原创性声明与使用权限。*正文是规范给死的，不是用户写的*——指南 1.7
    // 只说「作者可直接在教务处网站下载本部分内容电子版」。
    //
    // *本科这一份抄的就是教务处那个电子版*：
    // 「本科毕业论文（设计）写作指南及范例/哈尔滨工业大学本科毕业论文（设计）
    // __原创性声明和使用权限.doc」。它与「1-8 页+规范章补全…」第 32 页那一版
    // 有三处实质不同，都以官方这一份为准：
    //
    //   一、通篇「本科毕业论文*（设计）*」带括号。那份 32 页的是旧版，
    //       不带括号；hithesis 抄的是带括号这一版
    //   二、原创性声明末尾多一句*AI 声明*——新版加的
    //   三、使用权限那一节是*两段*（引言一段、三条权限一段），不是一整段
    //
    // 研究生那一份仍抄自「博士研究生学位论文书写范例」第 24 页——*手上没有
    // 研究生的官方单独文件*，所以它有没有跟着加 AI 那一句、措辞有没有更新，
    // 都还不知道。拿到再校。
    declarations: (
      form: from("base"),
      // 小标题里那个 subject（学位论文／实践成果／本科毕业论文（设计））从这两族取（subject-of）；住 base，from 过来
      document-type: from("base"),
      // 页面顶端那个大标题，*也就是这一页在目录里的名字*——本科范例目录
      // 第 6 页上排的正是「哈尔滨工业大学本科毕业论文原创性声明和使用权限」
      // 整条，没有另起一个短名。
      //
      // 先前这里还躺着一条短的 heading: [原创性声明和使用权限]，是「每个桶都
      // 得有个 heading」这个印象留下的，*从来没人读过*：term-chapter 只在
      // title 是 auto 时才取它，而 declarations() 每次都把大标题传进去。
      // 改名跑全套测试，42 项照过，于是删了。英文桶里那条 heading 另有用处
      // ——英文目录里这一页叫什么，见下面 en 档。
      //
      // *不写硬换行*——官方那份排成两行、hithesis 也拆成 line-one /
      // line-two 两条，那是 LaTeX 时代的办法；交给 Typst 自己按宽度断行更好，
      // 版心一变、字号一变都不用改这里
      title: [哈尔滨工业大学学位论文原创性声明和使用权限],
      // *实践成果那一档写 -not-bachelor-practice*：本科毕业设计的 form 也是
      // practice，光 -practice 与下面的 -bachelor 一样专，本科毕业设计报歧义；本科只有
      // 「本科毕业论文（设计）」一套字。这一桶五条 -practice 都这么写，见 src/axes.typ
      title-not-bachelor-practice: [哈尔滨工业大学实践成果原创性声明和使用权限],
      // *换行写 #linebreak() 而不是「\ 」*：后者在 Typst 里解析成
      // linebreak() 加*一个独立的空格元素*（实测 repr 是
      // sequence([甲乙], linebreak(), [ ], [丙丁])），目录里把换行折掉之后那个
      // 空格还在，排出来成了「…（设计） 原创性声明…」。两份范例的目录里这一条
      // 都是直接接上的，没有空格。
      title-bachelor: [哈尔滨工业大学本科毕业论文（设计）#linebreak()原创性声明和使用权限],

      // 小标题、那句「本人知悉…」——*三档只差「这份东西叫什么」*，收成一条
      // 收槽的函数，槽由 subject-of 给（见 src/terms/lookup.typ）。先前是六条把
      // 「学位论文／实践成果／本科毕业论文（设计）」各抄一遍，改一处措辞要改六处。
      //
      // *值是函数，这在本表里不是新花样*：cover 桶的
      // degree-type-professional-practice 收实践成果类型，声明页的 statement-text
      // 收题目，都是同一个形状。用户想整段自己写，给内容也收——见页面里那个
      // 「两种写法都收」的判断。
      statement: subject => subject + [原创性声明],
      // *题目那一格收成参数。* 两条正文都写成「收题目、给整段」的函数——
      // 题目是 info 里的东西，不该硬编在词条里；用户想留空手写也得能留。
      // 由 declarations() 把 info.title 填进来，空的时候填一段占位空白。
      // 用户覆盖时函数与整段内容两种写法都收，见 src/pages/declarations.typ
      // *2025 年 3 月这一版改过字*：加了「或专业实践工作」、把「引用文献」
      // 改成「引用文献、资料」、把「已发表的研究成果」改成「已发表的成果」，
      // 末尾多一句 AI 工具的标注。先前这一条抄的是旧版范例第 24 页，三处都旧了
      statement-text: title => [本人郑重声明：此处所提交的学位论文《#title》，是本人在导师指导下，在哈尔滨工业大学攻读学位期间独立进行学术研究工作或专业实践工作所取得的成果，且学位论文中除已标注引用文献、资料的部分外不包含他人完成或已发表的成果。对本学位论文的学术研究工作或专业实践工作做出重要贡献的个人和集体，均已在文中以明确方式注明；对使用AI工具的情况均已在文中以明确方式标注。],
      // 实践成果那一档：把「学术研究工作或专业实践工作」收窄成「专业实践工作」，
      // 其余逐字同上（《实践成果写作指南》附录 1）
      statement-text-not-bachelor-practice: title => [本人郑重声明：此处所提交的实践成果《#title》，是本人在导师指导下，在哈尔滨工业大学攻读学位期间独立进行专业实践工作所取得的成果，且实践成果中除已标注引用文献、资料的部分外不包含他人完成或已发表的成果。对本实践成果的专业实践工作做出重要贡献的个人和集体，均已在文中以明确方式注明；对使用AI工具的情况均已在文中以明确方式标注。],
      statement-text-bachelor: title => [本人郑重声明：此处所提交的本科毕业论文（设计）《#title》，是本人在导师指导下，在哈尔滨工业大学攻读学士学位期间独立进行研究工作所取得的成果，且毕业论文（设计）中除已标注引用文献的部分外不包含他人完成或已发表的研究成果。对本毕业论文（设计）的研究工作做出重要贡献的个人和集体，均已在文中以明确方式注明。本毕业论文（设计）对使用AI工具的情况进行了明确标注。],
      authorization: subject => subject + [使用权限],

      authorization-text-lead: [学位论文是研究生在哈尔滨工业大学攻读学位期间完成的成果，知识产权归属哈尔滨工业大学。学位论文的使用权限如下：],
      authorization-text-lead-not-bachelor-practice: [实践成果是研究生在哈尔滨工业大学攻读学位期间完成的成果，知识产权归属哈尔滨工业大学。实践成果的使用权限如下：],
      authorization-text-lead-bachelor: [本科毕业论文（设计）是本科生在哈尔滨工业大学攻读学士学位期间完成的成果，知识产权归属哈尔滨工业大学。本科毕业论文（设计）的使用权限如下：],
      // *第（3）条也改过*：2025 年 3 月这一版是「与此学位论文*内容*
      // 相关」，先前抄的旧版写的是「研究成果相关」
      authorization-text-items: [（1）学校可以采用影印、缩印或其他复制手段保存研究生上交的学位论文，并向国家图书馆报送学位论文；（2）学校可以将学位论文部分或全部内容编入有关数据库进行检索和提供相应阅览服务；（3）研究生毕业后发表与此学位论文内容相关的学术论文和其他成果时，应征得导师同意，且第一署名单位为哈尔滨工业大学。],
      authorization-text-items-not-bachelor-practice: [（1）学校可以采用影印、缩印或其他复制手段保存研究生上交的实践成果，并向国家图书馆报送实践成果；（2）学校可以将实践成果部分或全部内容编入有关数据库进行检索和提供相应阅览服务；（3）研究生毕业后发表与此实践成果内容相关的学术论文和其他成果时，应征得导师同意，且第一署名单位为哈尔滨工业大学。],
      authorization-text-items-bachelor: [（1）学校可以采用影印、缩印或其他复制手段保存本科生上交的毕业论文（设计），并向有关部门报送本科毕业论文（设计）；（2）根据需要，学校可以将本科毕业论文（设计）部分或全部内容编入有关数据库进行检索和提供相应阅览服务；（3）本科生毕业后发表与此毕业论文（设计）研究成果相关的学术论文和其他成果时，应征得导师同意，且第一署名单位为哈尔滨工业大学。],
      // 「使用权限」那一节的收尾两段。*带节的前缀*——这一节的每一条都是
      // authorization-*（标题、正文、签名），扫一眼就知道它们是一伙的；先前这两条
      // 光着，看不出属于哪一节。*正文四段都是 -text-*：lead（「…使用权限如下：」
      // 那一段）、items（（1）（2）（3））、secrecy、acknowledge——四段是四种段落
      // （缩进各不同、一段带档、一段带槽），所以拆开；先前只有头一段叫 -text，
      // 好像后三段不是正文似的
      //
      // *secrecy 还有一层*：内封桶里也有个 secrecy，那个是「密级」。两处
      // 不在一个桶里撞不着，但同一个词在这个包里指两样东西，读的人要停一下。
      // 带上前缀之后，authorization-text-secrecy 是「保密的那一句」、titlepage-secrecy
      // 是「密级那一格」，各说各的。
      //
      // 保密那一句本科与研究生共用（本科范例上也是「保密论文」），所以没有
      // -bachelor 那一条
      authorization-text-secrecy: [保密论文在保密期内遵守有关保密规定，解密后适用于此使用权限规定。],
      authorization-text-secrecy-not-bachelor-practice: [保密实践成果在保密期内遵守有关保密规定，解密后适用于此使用权限规定。],
      authorization-text-acknowledge: subject => [本人知悉] + subject + [的使用权限，并将遵守有关规定。],
      // *签名行：拼法一处、角色各一键。* 「X签名：」由 signature 那支函数拼，各行只存
      // 角色词。声明、授权两节都有「作者签名：」，同一个词只留一键（signer-author），
      // 两节共用——先前按节各一键（statement-signer-author / authorization-signer-author），
      // 同一个词两处，用户改一处漏一处（用户定的）。日期那一列的对齐由
      // src/pages/declarations.typ 按标签的字数补空，与键无关
      signer-author: [作者],
      // *不 from base 的 supervisor*：那一族带着 -bachelor ＝「指导教师」，搬过来本科
      // 就印成「指导教师签名：」，而三份范例（本科范例也是）签名行都是「导师签名：」
      signer-supervisor: [导师],
      // 实践成果那一档在导师之下多一行（《实践成果写作指南》附录 1）。
      // *值空着这一行照排*——它是签名栏，栏本身就是要留白给人签的，
      // 与内封那两行「无……不列此项」是两回事。字与内封那一格同（「行业导师」）
      signer-industry-supervisor: from("titlepage", key: "industry-supervisor"),
      // 「X签名：」的拼法，两节四行共用；收角色词
      signature: role => role + [签名：],
      date: [日期：],
      year: [年],
      month: [月],
      day: [日],
    ),
    // 开题报告与中期报告的首页。*字样出自两份 .docx 本身*，不是指南——
    // 那两张表单没有配套的写作说明，表上印着什么就是什么。
    //
    // *五格的键名跟着 info 走*（speciality / author / student-id /
    // supervisor / date），概念与论文内封同一套；换的只是印出来的字：论文本科
    // 档那一格印「本科生」，报告印「学　生」。所以这里只放字样，一个新 info 键
    // 都不加。
    //
    // 标签里的空格是 docx 里*敲出来的*（「专    业」中间四个半角），
    // 不是分散对齐——两份文件里这几格都没有 w:jc="distribute"。
    // 页眉里校名后面跟的那一行，就是文种。
    //
    // *字跟 base 走，但在这里占一个位置。* 先前这三条是把 base 里的字
    // *抄一遍*，于是用户改 base-document-type-bachelor 时页眉纹丝不动
    // ——自己那份把底层盖住了，成了个改不动的死角。
    //
    // 写成 from("base") 两头都有：不写就跟着 base 变，而 header-document-type-
    // bachelor 仍是个合法的覆盖键，只压页眉这一页。留这个位置是因为两处将来
    // 可能分叉：本科这一档带「（设计）」是照写作指南 3.4 的原文，而本科范例的
    // 页眉印的是不带的；哪天认定范例为准，把这三条换成字面即可，封面内封不动。
    header: (
      degree: from("cover"),
      stage: from("cover"),
      document-type: from("base"),
      // 论文页眉的校名与文种住 base，from 过来；深圳那一档的校名只有页眉在印，直接住这儿
      university: from("base"),
      // *报告那两档的页眉*。本部三份写着「报告不要设置页眉」，排出来一片
      // 空白——这一条只在用户自己把 header.shown 打开时才用得上；深圳那几份是
      // 真有页眉，word/header*.xml 里逐字抄下来的是：
      //
      //   研究生开题  哈尔滨工业大学（深圳）硕士学位论文开题报告  ＝ 校名 ＋ 表单名
      //   研究生中期  哈尔滨工业大学（深圳）中期报告              ＝ 校名 ＋ *只有阶段名*
      //   本科两份    哈尔滨工业大学深圳校区毕业设计开题报告      ＝ *另一个校名* ＋ 表单名
      //
      // 两档拼法不同，所以按 stage 各写一条；表单名那一截与首页那一行同一支
      // （src/pages/report/title.typ）。*校名逐档不同*：首页印「哈尔滨工业
      // 大学」，研究生页眉印带（深圳）的（只有页眉在印，所以这一条住这儿），
      // 本科那两份首页与页眉同字，住 base（university-bachelor-shenzhen）
      university-shenzhen: [哈尔滨工业大学（深圳）],
      // 深圳报告页眉的表单名与首页同一支（src/pages/report/title.typ），料——表单名的模板、阶段名、学位的名——住 cover 桶，from 过来页眉才有自己的键
      report-title: from("cover"),
      report: (university, report-title, stage) => university + report-title,
      report-proposal-shenzhen: (university, report-title, stage) => university + report-title,
      report-interim-shenzhen: (university, report-title, stage) => university + stage,
      // 本科那两份两个阶段同一个拼法（校名 ＋ 表单名），与上面 report 那一条
      // 相同——但那一条比它泛，撞上了就是歧义，所以两个阶段各写出来
      report-bachelor-proposal-shenzhen: (
        (university, report-title, stage) => university + report-title
      ),
      report-bachelor-interim-shenzhen: (
        (university, report-title, stage) => university + report-title
      ),
    ),
  ),
  en: (
    base: (
      // *这一侧说英文。*提示是说给作者听的，而读英文那一份的作者未必读中文
      // ——留学生那一档整篇都走 en 侧。排法也跟着换，见 src/styles/parts.typ
      // 的 overflow-note：中文黑体 ↔ 西文 sans。
      warning-false: [To turn this warning off, pass `warning: false`],
      university: [Harbin Institute of Technology],
      // 见 zh 侧同名那一条：深圳本科那两份首页与页眉同字，所以住 base
      university-bachelor-shenzhen: [Harbin Institute of Technology, Shenzhen],
      document-type-bachelor: [Bachelor's Thesis],
      document-type-master: [Master's Thesis],
      document-type-doctor: [Doctoral Dissertation],
      // 实践成果那一档。*学校的文件里没有*——四份官方文件里实践成果的英文一个
      // 字都没有（英文内封只说「格式同中文内封」）。字取《中华人民共和国学位法》
      // 的英译（chinalawtranslate.com，第 20、21、25、26、30 条一律 practical
      // results；同一份译文里学位论文是 dissertation、毕业论文 thesis、毕业设计
      // graduation project）。先前是我们自己挑的 Practice Report，有出处就换。
      // 学院给了别的说法就一行覆盖：overrides: (base-document-type-doctor-practice: […])
      document-type-master-practice: [Master's Practical Results],
      document-type-doctor-practice: [Doctoral Practical Results],
      // 勾选框那两行的字，同 zh 那两条。*官方英文版是双语的*——2026 年 9 月版
      // 深圳本科开题·中期的英文版首行印的就是「☐毕业论文Thesis ☐毕业设计Design」
      // （逐字量的：SimSun 12 的四个汉字紧接 Times 12 的英文，中间那 3pt 是汉字
      // 接西文的字距，我们自己会补）。与这一页的字段标签同一个路子（学院/ School：），
      // 见下面的 affiliation-bachelor-shenzhen 那一族。
      //
      // *英文那一头只有这一页在印*：本科没有英文内封，所以不为别处另分档。
      // 同 zh：一族四条，硕博两条是不带学位的那个说法，见那边的说明
      form-dissertation: [Dissertation],
      form-practice: [Practical Results],
      form-bachelor-dissertation: [毕业论文Thesis],
      form-bachelor-practice: [毕业设计Design],
      // 两页共用的字段标签，与中文侧对称，见那边
      supervisor: [Supervisor],
      speciality: [Speciality],
    ),
    // 封面。*英文这一份只有报告首页在用*——论文的英文那一页是内封（走
    // titlepage-en），封面本身只排中文。先前这一桶是空的、被删过，注释里写着
    // 「哪天封面真有了英文档，那时候一次补齐」；开题与中期的英文版就是那一天。
    //
    // *它是中英各一份装在同一个 .doc 里的后半截*（硕士开题英文版第 84–103
    // 段、硕士中期英文版第 56–75 段）。段落清单与中文那份*完全一样*——同样
    // 的 w:ind left、w:line=420 auto、snapToGrid=0、尾部空段——只换词，所以这一页
    // 不另开版式，只多一档词条。
    //
    // *本科与博士是推的*：学校只发了硕士那两份英文版，没有官方译法。推法
    // 写在各条的模板里（见 report-title-*），改起来就是改那一行。
    cover: (
      // *学位的名，作定语用*。开题报告的英文标题拿它拼：Thesis Proposal of
      // *Master* Candidates。*本科这一档英文有、中文没有*——中文那两份
      // 表单的标题头一截印文种不印学位，见 zh 那边。
      //
      // *博士取 Doctoral 不取 Doctor*：官方只发了硕士那两份，博士与本科的
      // 英文是照它推的（学校没有官方译法），取形容词形才与 Candidates 搭得上。
      degree-bachelor: [Bachelor],
      degree-master: [Master],
      degree-doctor: [Doctoral],
      // 学位论文／实践成果那一族住 base，from 过来（深圳本科首页的勾选框）
      form: from("base"),
      // 文种那一族住 base，from 过来（报告表单名要拼它）
      document-type: from("base"),
      // 报告首页那一格印*缩写*，不是 base 的全称——英文档的*页眉*还在用
      // 全称（Harbin Institute of Technology Doctoral Dissertation），所以不能去改
      // base，只在这一页盖一层
      university: [HIT],
      // *深圳那两份印全称*（Harbin Institute of Technology），不是缩写——
      // 逐字取自 深圳中期英文.docx 与 深圳 Template of Master's Thesis Proposal
      university-shenzhen: [Harbin Institute of Technology],
      // 红字末尾那句住 base，from 过来
      warning-false: from("base"),
      // 排不下时纸角那条红字。*报告首页有英文那一档*（深圳那两份留学生版、
      // 本部硕中英文版），题目长了照样排不下，所以两侧都要有；论文封面只走 zh 侧
      warning-overflow: [The cover does not fit and has overflowed onto a second page. Please shorten the title.],
      warning-crowded: [The cover table does not fit even with its rows squeezed. Please shorten the title or the affiliation.],
      // 六格。*三条与 base／内封那一份不同*：内封印 Affiliation、Speciality，
      // 这一页印 School（Department）、Discipline；作者那一格印 Postgraduate
      // *半角括号*：官方那两份自己就不一致（硕开英敲的是全角、硕中英是
      // 半角），英文里取半角
      //
      // *深圳那两份六格的字全不同，且都带半角冒号*：School: / Major: /
      // Supervisor: / Graduate Student: / Student ID: / Date:（本部那份不带冒号，
      // 字段值直接接在下划线上）。冒号存进词条里——它是这一档字面的一部分
      affiliation: [School (Department)],
      affiliation-shenzhen: [School:],
      // *官方英文版是双语的*（2026 年 9 月版）：标签是「中文 ／ English：」
      // 并排，不是整格英文；中文那两个字由代码撑开（见
      // src/pages/report/shenzhen/cover.typ 的 _label），斜杠与英文挂在后面。
      // 冒号中英混用是原件的手抖（题目那格半角、另六格全角），照抄
      affiliation-bachelor-shenzhen: [学院/ School：],
      author: [Postgraduate],
      author-shenzhen: [Graduate Student:],
      author-bachelor-shenzhen: [姓名/ Name：],
      // *本科那两份没有英文版*，这两条是推的（中文印「学生」与「哈尔滨工业
      // 大学教务处制」）。教务处的英文取学校官网那个说法
      author-bachelor: [Student],
      // 导师标签住 base，from 过来
      supervisor: from("base"),
      // *本科的深圳文档要写出来*：author-bachelor 与 author-shenzhen 一样专，
      // 撞上了就是歧义。字面照深圳那一套（都带半角冒号），学位的词照本科那一档
      supervisor-shenzhen: [Supervisor:],
      supervisor-bachelor-shenzhen: [指导教师/ Supervisor：],
      speciality: [Discipline],
      speciality-shenzhen: [Major:],
      speciality-bachelor-shenzhen: [专业/ Major：],
      student-id: [Student Number],
      student-id-shenzhen: [Student ID:],
      student-id-bachelor-shenzhen: [学号/ Student ID：],
      // 日期那一格*两档措辞不同，也拼不出来*：开题那份印 Defense Date、中期
      // 那份印 The Date。中文那边是「｛阶段｝＋日期」拼的，英文这边只能各写各的。
      // *深圳那两档都印 Date:*，仍按阶段各写一条——写一条 date-shenzhen 会与
      // 这两条一样专。
      //
      // *再写上反档 -not-bachelor*：深圳本科那一条是 date-bachelor-shenzhen
      // （两根轴），与 date-{阶段}-shenzhen 一样专，term-for 判歧义当场报错——
      // 英文档的深圳本科报告因此编不过。写法见 base 桶的
      // speciality-not-bachelor-practice；*段的次序照轴表*（degree-level → stage
      // → campus，见 src/axes.typ 的 axes），写反了一条都挑不出来
      date-proposal: [Defense Date],
      date-interim: [The Date],
      date-not-bachelor-proposal-shenzhen: [Date:],
      date-not-bachelor-interim-shenzhen: [Date:],
      date-bachelor-shenzhen: [日期/ Date：],
      // 表单名，见 zh 那一侧的说明。*按 stage 分档*——英文两个阶段的句式
      // 互不相同：开题要学位词（of *Master* Candidates），中期要文种
      // （for *Master's Thesis*）。博士与本科由此自然落出来：
      //
      //   Thesis Proposal of Doctoral Candidates    Interim Report for Doctoral Dissertation
      //   Thesis Proposal of Bachelor Candidates    Interim Report for Bachelor's Thesis
      report-title-proposal: (degree, document-type, stage) => (
        [Thesis Proposal of ] + degree + [ Candidates]
      ),
      report-title-interim: (degree, document-type, stage) => (
        [Interim Report for ] + document-type
      ),
      // *深圳两档的句式又是另一套*：开题「Master's Thesis Proposal」、中期
      // 「Mid-term Report for Master's Thesis」——都拿文种那一截拼，博士与本科
      // 自然落出来（Doctoral Dissertation Proposal / Mid-term Report for …）
      // *反档 -not-bachelor 与日期那两条同一个道理*：深圳本科那一条也是
      // 两根轴，不写反档就一样专、当场判歧义。段的次序照轴表（degree-level → stage
      // → campus，见 src/axes.typ）
      report-title-not-bachelor-proposal-shenzhen: (degree, document-type, stage) => (
        document-type + [ Proposal]
      ),
      report-title-not-bachelor-interim-shenzhen: (degree, document-type, stage) => (
        [Mid-term Report for ] + document-type
      ),
      // *深圳本科那两份的英文版是双语的*（2026 年 9 月版）：校名与文种
      // 各排*两行*——中文一行、英文一行。这一条是英文那一行，中文那一行
      // 取 zh 桶的同名词条，见 src/pages/report/shenzhen/cover.typ。
      //
      // 句式与中文那条同构（「毕业论文（设计）」＋阶段），阶段名见下面的 stage-*
      report-title-bachelor-shenzhen: (
        (degree, document-type, stage) => [Undergraduate Thesis (Design) ] + stage
      ),
      // 阶段名。*只有深圳本科英文版在用*——本部英文那两档的日期与表单名
      // 都是各写各的整句，拼不出来（见上面 date-proposal / report-title-proposal）
      stage-proposal: [Proposal Report],
      stage-interim: [Interim Report],
      seal: [Graduate School],
      seal-bachelor: [Office of Academic Affairs],
      // 深圳：开题印 Shenzhen Department of Academic Affairs，中期那份没有落款
      seal-proposal-shenzhen: [Shenzhen Department of Academic Affairs],
      seal-interim-shenzhen: none,
      // 「题 目：」那一行。官方那两份用的是*全角冒号*，与中文那份同一个字
      title: [Title：],
      // *深圳那两份是半角冒号加一个半角空格*——两份都这么敲（Title: ******）
      title-shenzhen: [Title: ],
      title-bachelor-shenzhen: [题目/ Title:],
    ),

    titlepage: (
      supervisor: from("base"),
      // 字段标签住 base，from 过来
      speciality: from("base"),
      // 实践成果那一档，中文侧印「类别」（指南 3.3.2「类别：□□…□，按授予学位的
      // 专业学位类别名称填写」）。*没有出处*——英文内封在四份官方文件里只有
      // 「格式同中文内封格式」一句，字样一个没给，与 co-supervisor 那两条同一处境。
      // 取 Category：中文那一格问的就是「哪一类」，这是最直白的对法。只有内封印它，
      // 住这儿不住 base（理由见 zh 侧 base 的 speciality）。反档的写法见 zh 侧
      speciality-not-bachelor-practice: [Category],
      // 文种那一族住 base，from 过来
      document-type: from("base"),
      // 红字末尾那句住 base，from 过来
      warning-false: from("base"),
      // 说的是英文内封那一页，见 zh 侧同名那一条。字说英文，见 base 桶 warning-false
      warning-overflow: [The English title page does not fit and has overflowed onto a second page. Please shorten the title or the affiliation.],
      // 范例上写的就是这两个词，U.D.C 后面没有句点
      secrecy: [Secrecy Level],
      classified-index: [Classified Index],
      udc: [U.D.C],
      school-code: [School Code],
      author: [Candidate],

      // *这两条没有出处*。2025 年 3 月这一版的写作指南与四份书写范例里，
      // 副导师与行业导师*只有中文*——范例那位研究生两样都没有，英文内封
      // 上根本没有这两行（「英文内封格式同中文内封格式」只说了格式）。行业导师
      // 更是这一版新加的行，hithesis 也没有。
      //
      // 所以这两个词是*我们挑的*：副导师跟 hithesis 的 Associate
      // Supervisor（hithesisbook.cfg:234），与哈工大自己把「副教授」译成
      // Associate Professor 同一个对法；行业导师跟着 Supervisor 一族取
      // Industry Supervisor，与上一行同系列。学院给了别的说法就一行覆盖：
      // overrides: (titlepage-co-supervisor: [Co-Supervisor])
      co-supervisor: [Associate Supervisor],
      industry-supervisor: [Industry Supervisor],
      degree-applied: [Academic Degree Applied for],

      affiliation: [Affiliation],
      defense-date: [Date of Defence],
      institution: [Degree-Conferring-Institution],
    ),
    abstract: (
      title: [Abstract],
      // 西文标题不撑开（判据只认两个汉字，见 src/heading/spread.typ）。撑的话会把
      // Abstract 拆成八个 run，每处边界丢一份 tracking（见 src/fonts/tracking.typ）；
      // hithesis 英文档的 title-spread 也是空值（hit-thesis.cls:622）
      // 同上，见 zh 档那一条的说明。两条字面都取自研究生范例第九页。
      // 英文摘要页自己的标题是上面那个 Abstract，与这一条不是一回事
      in-english-toc: [Abstract (In {English})],
      in-english-toc-hass: [Abstract(In {English})],
      keywords: [Keywords],
      keywords-separator: [, ],
    ),
    table-of-contents: (
      title: [Contents],
      in-english-toc: [Contents (In {English})],
      // 英文目录里那一条读起来是中文时印的红字。*插图索引、表格索引共用*
      // 这两条——它们也是目录，题注更少有人挂英文名。词条留在 toc 桶不另设一份，
      // 见 src/pages/outline.typ 的 _en-warn。
      //
      // *两种情形两句话*：
      //
      //   warning-english-missing  *压根没写* #en[…]（写了个空的也算，见
      //                       src/terms/lang.typ 的 find-en），回落那份顶上了
      //   warning-english-cjk      *写了* #en[…]，可里面读起来还是中文
      //
      // *两句都是 Warning!，都以 may not be in English 收尾*——因为触发它们的
      // 是同一条*启发式*判据（汉字占比过半，见 src/pages/outline.typ）。「这条读起来
      // 是中文」是我们*猜*的，不是断言：英文档里裸的标题本来就落进英文那一侧，
      // 作者完全可能有意在英文标题里放中文书名、人名。拿 Error! 去说一件猜出来的
      // 事，是把话说满了。
      //
      // 两句的差别在*前半截那件确定的事*：写没写 #en[…] 是查得出来的，所以
      // 第一句多一句「not specified」；写了的只剩后半截。
      //
      // *名字照全表的惯例*：主词是所印之物（warning，与 src/api.typ、
      // src/pages/titlepage.typ 里印在页面上的那个提示同一个词），后缀是「这一条
      // 说的是哪件事」，与 column-short / column-description 同型。
      //
      // *语言本身写全，不写 en。* en 在这个包里是*语言轴*——lang: "en"、
      // 词表的 en 那一侧、标题上挂的 #en[…]。这两条说的是「英文名」这样东西本身，
      // 照同一个桶里的 in-english-toc 写全称。cjk 不在此列：它是文种不是语言，
      // 包里一直这么叫（src/msword.typ 的 has-cjk、cjk-ratio）。
      //
      // *句式照 Word 的报错*：它那一套是「｛什么｝未｛怎么样｝」
      // （Error! Bookmark not defined. / Error! Filename not specified.）。
      warning-english-missing: [(Warning! English heading not specified, may not be in English.)],
      warning-english-cjk: [(Warning! English heading may not be in English.)],
    ),
    list-of-figures: (
      title: [List of Figures],
      in-english-toc: [List of Figures (In {English})],
      image: from("caption"),
    ),
    list-of-tables: (
      title: [List of Tables],
      in-english-toc: [List of Tables (In {English})],
      table: from("caption"),
    ),
    list-of-equations: (
      title: [List of Equations],
      in-english-toc: [List of Equations (In {English})],
      equation: [Equation],
    ),
    conclusion: (
      title: [Conclusions],
    ),
    appendix: (
      title: [Appendix],
    ),
    references: (
      title: [References],
    ),
    // 成果那一章的英文字样。*博士那条取自两份博士范例的英文目录*（理工
    // d-stem 与人文 s-hss 都印 Innovative achievements for Ph.D，Ph.D 后面没有
    // 句点，紧接着就是引导点）；hithesis 写的 Papers published in the period of
    // Ph.D. education（hit-defaults.dtx:1456）不是学校印的那句，先前照抄了它。
    // 硕士、本科没有英文范例，按学校这句的形状起（hithesis 给深圳硕士写的也是
    // Innovative achievements for Master，hit-defaults.dtx:1464）。分组的英文名
    // 规范与 hithesis 都没有（hithesis 连组名都是手打的），是我们起的
    achievements: (
      title-bachelor: [Innovative achievements for Bachelor],
      title-master: [Innovative achievements for Master],
      title-doctor: [Innovative achievements for Ph.D],
      // 见中文那一条。英文侧不分学位，三档都是 (1)——半角括号、阿拉伯数字、*括号后
      // 一个空格*，照哈工大自己的英文表单（硕士开题英文版 VI 节的分组列表：
      // 「(1) Journal」「(2) Text book」「(3) Conference article」，空格是同一个 run 里
      // 的一个空格字符）。手上没有英文版的学位论文书写范例，这是最近的先例；同一份
      // 表单里全角「（1）」只出现在中文行里。空格写在词条里，与 keywords-separator
      // 带自己的空格是同一个惯例；中文侧全角括号自带空当，不加。
      group-numbering: "(1) ",
      papers: [Papers published],
      conferences: [Conference papers published],
      patents: [Patents applied for and granted],
      // 「及获奖」跟着内容走，见 zh 那边。*英文侧不分门类*——中文人文写「课题
      // 项目」、理工写「科研项目」，英文两档都是 Research projects
      projects: [Research projects],
      projects-with-awards: [Research projects and awards],
      // 见 zh 那边：句式跟着上面三条（名词 + 过去分词）
      books: [Monographs contributed to],
      standards: [Standards drafted],
      reports: [Research reports completed],
      others: [Achievements in other forms],
    ),
    // 两份博士范例的英文目录拼法不同：理工 Acknowledgements、人文 Acknowledgments
    // ——都是对的拼法，各照各的范例印
    acknowledgement: (
      title: [Acknowledgements],
      title-hass: [Acknowledgments],
    ),
    // hithesis 的 index-heading-en 也是 Index（hit-thesis.cfg:332）
    index: (
      title: [Index],
    ),
    // 博士范例英文目录里那一条就是 Resume，hithesis 的 resume-heading-en 同
    resume: (
      title: [Resume],
    ),
    // 英文字样*没有出处*。hithesis 写的是 List of abbreviations（句首大写），
    // 范例英文目录里的条目一律词首大写（Chapter 1 Introduction / References /
    // List of Dissertation Reviewers … / Resume），跟范例。英文版的表只有两列
    // Nomenclature 是这类表在英文里的专门词；hithesis 写的是 List of physical
    // quantities and symbols（hit-thesis.cfg:620），太长且不专门，不跟
    // 英文字样照 hithesis 的 list-of-symbols-heading-en（List of physical quantities and
    // symbols，hit-defaults.dtx:1225），词首大写跟范例英文目录的其他条目
    list-of-symbols: (
      title: [List of Physical Quantities and Symbols],
      column-symbol: [Symbol],
      column-description: [Description],
    ),
    // 合并页叫 Nomenclature：工科论文里这个词本就常同时列符号与缩写（hithesis 是
    // List of symbols and abbreviations，hit-thesis.cfg:622，不跟）
    nomenclature: (
      title: [Nomenclature],
    ),
    // 关键字：与中文那份同一张，见那边的注释
    algorithm: (
      // 键要带引号：if / for / while / return / in / and / or / not / break / continue
      // 是 Typst 的保留字
      "input": [input], "output": [output],
      "if": [if], "then": [then], "else": [else],
      "for": [for], "to": [to], "do": [do], "while": [while], "repeat": [repeat], "until": [until],
      "each": [each],
      "return": [return], "end": [end],
      "function": [function], "procedure": [procedure],
      "break": [break], "continue": [continue],
    ),
    list-of-abbreviations: (
      title: [List of Abbreviations],
      column-short: [Abbreviation],
      column-long: [Full Form],
    ),
    // 英文那套没有出处，照抄 hithesis 的 resolution-* 十一条（hit-defaults.dtx:731–741,
    // 1179）
    defense: (
      // 见 zh 那一侧
      form: from("base"),
      // 同 zh：收槽的函数，见 subject-of
      title: subject => [List of ] + subject + [ Reviewers and Defense Committee and Defense Resolution],
      // 实践成果那一档。*英文一律叫 Practical Results*（《学位法》英译的词，见 base
      // 桶的 document-type-*-practice），两处必须一致，否则同一份英文文档里这东西
      // 一会儿叫 Results 一会儿叫别的
      reviewers: [Reviewers\ (Enter actual headcount)],
      committee: [Defense Committee],
      chair: [Chair],
      member: [Member],
      secretary: [Secretary],
      column-role: [Role],
      column-name: [Name],
      column-title: [Title],
      column-affiliation: [Affiliation],
      column-discipline: [Discipline],
      resolution: [Resolution of the defense committee (comments on the dissertation and whether the doctoral degree is recommended):],
      // 同样没有出处，见中文那一条。practice report 与上面的 title-practice
      // 用同一个词
      resolution-practice: [Resolution of the defense committee (comments on the practice report and whether the doctoral degree is recommended):],
    ),
    // 声明页在英文目录里的名字。*取自博士范例的英文目录*：理工 d-stem 印
    // Statement of copyright and Letter of authorization，人文 s-hss 同一句 letter
    // 小写——两份各是各的范例，按学科分两条，谁的就照谁印。先前那句
    // Declaration of Originality and Terms of Use 是我们自己起的，没有出处
    declarations: (
      title: [Statement of copyright and Letter of authorization],
      title-hass: [Statement of copyright and letter of authorization],
    ),
    // 英文题注的名。*取自范例，指南没写*——博士范例第 11 页排的是
    // 「Fig.1-1  Classification of…」、第 14 页「Table6-1 Data of…」。
    // 点后那个空格是我们补的：范例里 Fig. 与 Table 后面空几格自己都不一致
    // （p14 一个、p15 两个），统一按「Fig. 1-1」排
    //
    // *深圳那几份写全称 Figure*，这一档*指南自己写着*：深圳本科英文版
    // 写作指南 2.13 通篇「Figure 1-1」（2.13.1「the first figure in Chapter 1 would
    // be numbered "Figure 1-1"」、2.13.2「see Figure 1-1」），2.12 的表也确实是
    // 「Table 1-1」——所以只有图这一个字两档不同。深圳那三份英文件排出来也都是
    // 「Figure 2-1 …」：本科英文版开题、中期，以及研究生那一份中期英文
    // （Table 2-1 Main Blade Parameters／Figure 2-4 Cross-sectional Shapes…）。
    //
    // *分的是校区不是学位*：本科（深圳本科那两份表单＋指南）与研究生（深圳
    // 研究生中期英文）在深圳这边一致写 Figure，而 Fig. 那一条的出处是*本部*
    // 的博士范例。*两侧的证据都不厚*——本部只有那一份范例（论文，不是报告，
    // 而且它 Fig. 后空几格自己都不一致），深圳只有那三份；本部至今没发过本科的
    // 英文件。哪天本部出了英文版指南或英文范例，这一条要重核。
    caption: (
      image: [Fig.],
      image-shenzhen: [Figure],
      table: [Table],
      // 伪代码的名：本部通行写 Algo.（用户定的），深圳跟 Figure 那一档写全词
      algorithm: [Algo.],
      algorithm-shenzhen: [Algorithm],
      // 代码清单：Typst 给 raw 的英文名是 Listing（LaTeX 的 listings 也这么叫），照它；
      // 没有缩写的通行写法，本部深圳一个词
      raw: [Listing],
      // 英文档的续排标注*没有出处*——指南只写了中文那两个。取通行写法
      continued: name => [(Continued)],
      // 英文档*没有出处*，取通行写法
      equation: [Eq.],
      // 英文档*没有出处*。取国际通行的 where——它就是「式中」在英文数学
      // 写作里的那个词
      denote: [where],
      // 「附」的英文写法，只在*中文档*里用得上：双语题注的英文行与英文那份
      // 插图索引印「Appendix Fig. 1-1」，与中文行的「附图1-1」是同一个号、两种名。
      // *英文档到不了这里*——那一档的附录用字母（Fig. A-1），不加前缀，
      // 见 src/heading/numbering.typ。取全词不取 App.：那一行本就是给人读的译文
      appendix: [Appendix],
    ),
    header: (
      degree: from("cover"),
      stage: from("cover"),
      document-type: from("base"),
      // 见 zh 那一侧
      university: from("base"),
      // 见 zh 那一侧。深圳那两份英文版的页眉是*表单名在前、校名在后*，
      // 中间空开一段（原件敲的是三到四个半角，取四个 ＝ 2em）：
      //
      //   Master's Thesis Proposal    Harbin Institute of Technology, Shenzhen
      //   Mid-term Report for Master's Thesis   Harbin Institute of Technology, Shenzhen
      university-shenzhen: [Harbin Institute of Technology, Shenzhen],
      report-title: from("cover"),
      report: (university, report-title, stage) => report-title + h(2em) + university,
      report-proposal-shenzhen: (
        (university, report-title, stage) => report-title + h(2em) + university
      ),
      report-interim-shenzhen: (
        (university, report-title, stage) => report-title + h(2em) + university
      ),
      // *本科那两份的英文页眉只有表单名，没有校名*——逐字量原件（英文版
      // 开题·中期的 page 2 起）：印的就是「Undergraduate Thesis (Design)
      // Interim Report」，居中，小五，一个校名都没有。研究生那两份英文版才是
      // 「表单名 ＋ 校名」（上面两条）。先前这两条是照研究生那一支写的，多印
      // 了一截校名
      report-bachelor-proposal-shenzhen: (
        (university, report-title, stage) => report-title
      ),
      report-bachelor-interim-shenzhen: (
        (university, report-title, stage) => report-title
      ),
    ),
  ),
)
