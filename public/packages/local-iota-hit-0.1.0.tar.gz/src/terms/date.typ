#import "@local/banshi:0.1.0" as banshi
#import "./lang.typ": normalize
#import banshi.errors as _errors
#let _months-en = (
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
)

#let _all-digits(s, low, high) = {
  if s.len() < low or s.len() > high { return false }
  s.clusters().all(c => "0123456789".contains(c))
}
#let parse(value) = {
  if type(value) != str { return none }
  let parts = value.trim().split("-")
  if parts.len() > 3 { return none }
  if not _all-digits(parts.at(0), 4, 4) { return none }
  let out = (year: int(parts.at(0)), month: none, day: none)
  if parts.len() > 1 {
    if not _all-digits(parts.at(1), 1, 2) { return none }
    out.month = int(parts.at(1))
    if out.month < 1 or out.month > 12 { return none }
  }
  if parts.len() > 2 {
    if not _all-digits(parts.at(2), 1, 2) { return none }
    out.day = int(parts.at(2))
    if out.day < 1 or out.day > 31 { return none }
  }
  out
}
#let _parts(d, lang) = {
  if lang == "en" {
    if d.month == none { return [#d.year] }
    let day = if d.day == none { [] } else { [ #d.day] }
    return [#_months-en.at(d.month - 1)#day, #d.year]
  }
  if d.month == none { return [#(d.year)年] }
  if d.day == none { return [#(d.year)年#(d.month)月] }
  [#(d.year)年#(d.month)月#(d.day)日]
}
#let render(value, lang: auto) = {
  if type(value) != str { return value }
// 字符串按日期校验；自定义字面需显式传入内容。
  let d = parse(value)
  if d == none {
    panic(
      "expected an ISO date such as \"2026\", \"2026-06\", or \"2026-06-05\", found "
        + repr(value) + " (write content like [" + value + "] to print it as given)",
    )
  }
  if lang != auto { return _parts(d, normalize(lang)) }
  context _parts(d, normalize(text.lang))
}
#let _precisions = ("year", "month", "day")

#let today(precision: auto, lang: auto) = context {
  let want = if precision == auto { "day" } else { precision }
  if want not in _precisions {
    panic(_errors.expected-one-of(_precisions, precision))
  }
  let t = datetime.today(offset: 8)
  let d = (
    year: t.year(),
    month: if want == "year" { none } else { t.month() },
    day: if want == "day" { t.day() } else { none },
  )
  _parts(d, normalize(if lang == auto { text.lang } else { lang }))
}
