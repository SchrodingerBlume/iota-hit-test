#import "../docxtyp.typ" as banshi
#import "./lang.typ": normalize, title-of
#import "../axes.typ": aliases
#import banshi.errors as _errors
#let _months-en = (
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
)

#let _all-digits(s, low, high) = {
  if s.len() < low or s.len() > high { return false }
  s.clusters().all(c => "0123456789".contains(c))
}
#let parse(value) = {
  if type(value) != str { return none }
  let parts = value.trim().split("-")
  if parts.len() > 3 { return none }
  if not _all-digits(parts.at(0), 4, 4) { return none }
  let out = (year: int(parts.at(0)), month: none, day: none)
  if parts.len() > 1 {
    if not _all-digits(parts.at(1), 1, 2) { return none }
    out.month = int(parts.at(1))
    if out.month < 1 or out.month > 12 { return none }
  }
  if parts.len() > 2 {
    if not _all-digits(parts.at(2), 1, 2) { return none }
    out.day = int(parts.at(2))
    if out.day < 1 or out.day > 31 { return none }
  }
  out
}
#let _parts(d, lang) = {
  if lang == "en" {
    if d.month == none { return [#d.year] }
    let day = if d.day == none { [] } else { [ #d.day] }
    return [#_months-en.at(d.month - 1)#day, #d.year]
  }
  if d.month == none { return [#(d.year)年] }
  if d.day == none { return [#(d.year)年#(d.month)月] }
  [#(d.year)年#(d.month)月#(d.day)日]
}
#let render(value, lang: auto) = {
  if type(value) != str { return value }
// 字符串按日期校验；自定义字面需显式传入内容。
  let d = parse(value)
  if d == none {
    panic(
      "expected an ISO date such as \"2026\", \"2026-06\", or \"2026-06-05\", found "
        + repr(value) + " (write content like [" + value + "] to print it as given)",
    )
  }
  if lang != auto { return _parts(d, normalize(lang)) }
  context _parts(d, normalize(text.lang))
}
#let _keys = ("proposal", "interim", "final", "final-defense", "period")
#let _key(name) = if name == "postdoc-period" { "period" } else if name == "final-defence" { "final-defense" } else {
  aliases.stage.at(name, default: name)
}
#let _check-date(value, where) = {
  if value in (auto, none) or type(value) == content { return }
  if type(value) == str and parse(value) != none { return }
  panic(where + ": expected an ISO date, content, none, or auto; found " + repr(value))
}
#let checked(value) = {
  if value == auto { return (:) }
  if type(value) != dictionary {
    panic("date: expected a dictionary such as (final: \"2026-06\", final-defense: \"2026-06-12\"), found " + repr(value))
  }
  let result = (:)
  let seen = ()
  for (name, v) in value {
    let key = _key(name)
    if key not in _keys { panic("date: unknown key " + repr(name) + "; " + _errors.expected-one-of(_keys, name)) }
    if key in seen { panic("date: duplicate key " + repr(key) + " (including aliases)") }
    seen.push(key)
    if v == auto { continue }
    if key == "period" {
      // 通用就读／研究区间：单值是 start，none 明确清空整个区间。
      let v = if v == none { (start: none, end: none) } else if type(v) == dictionary { v } else { (start: v) }
      let period = (:)
      for (edge, date) in v {
        if edge not in ("start", "end") { panic("date.period: unknown key " + repr(edge)) }
        _check-date(date, "date.period." + edge)
        if date != auto { period.insert(edge, date) }
      }
      result.insert(key, period)
    } else {
      _check-date(v, "date." + key)
      result.insert(key, v)
    }
  }
  result
}
// 缺项各自占位，不从其他阶段或事件借日期。
#let entry(dates, name, lang: auto, precision: auto) = {
  let dates = checked(dates)
  let parts = name.split(".")
  let v = dates.at(_key(parts.first()), default: auto)
  if parts.len() > 1 {
    v = if type(v) == dictionary { v.at(parts.last(), default: auto) } else { auto }
  }
  if v == auto { return raw(if precision == "month" or name == "final" { "YYYY-MM" } else { "YYYY-MM-DD" }) }
  if type(v) == str {
    if precision == "month" {
      let d = parse(v)
      d.day = none
      return if lang == auto { context _parts(d, normalize(text.lang)) } else { _parts(d, normalize(lang)) }
    }
    return render(v, lang: lang)
  }
  if v == none { return none }
  context title-of(v, normalize(if lang == auto { text.lang } else { lang }))
}
#let _precisions = ("year", "month", "day")

#let today(precision: auto, lang: auto) = context {
  let want = if precision == auto { "day" } else { precision }
  if want not in _precisions {
    panic(_errors.expected-one-of(_precisions, precision))
  }
  let t = datetime.today(offset: 8)
  let d = (
    year: t.year(),
    month: if want == "year" { none } else { t.month() },
    day: if want == "day" { t.day() } else { none },
  )
  _parts(d, normalize(if lang == auto { text.lang } else { lang }))
}
