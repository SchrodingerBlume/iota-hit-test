// 日期。*一处解析，各处照自己的语言排。*
//
// 用户写 ISO：yyyy / yyyy-mm / yyyy-mm-dd。中文档排「2022年6月」，英文档排
// 「June, 2020」，同一个值两边同源，不必再写一份 -en。
//
// *写到哪一级就排到哪一级。* 不给任何一处声明「这里必须到日」——查过四处
// 落点，规范一处也没要求到日：
//
//   本科封面    「2022 年6 月」，旁边的批注原话是「*年、月*用阿拉伯数字，
//               宋体、Times New Roman 小 2 号字加粗」
//   本科内封    「答辩日期：2022 年6 月」
//   研究生封面  「2020年6月」
//   研究生内封  「2020年6月」／英文「June, 2020」
//
// hithesis 把本科那一档声明成 day（hit-thesis.cls:5501），与范例和批注都对不上，
// 不跟。而且声明了要求精度就得处理「用户写细了」——它那边是*截断*，用户
// 写 2026-06-05 却印出「2026年6月」，静默丢掉一级。写到哪一级排到哪一级没有这个
// 问题，也不必为每处维护一张精度表。
//
// *两种写法，各有一个意思。*
//
//     date: "2026-06"      字符串 ＝ 一个日期，交给我们排
//     date: [二〇二二年六月] 内容   ＝ 已经排好的字，原样印出去
//
// 所以*字符串只收 ISO*，认不出就报错并指出这两条路。原样放过的话，
// "2026/06"、"20266" 这类手滑会一声不响地印在封面上——而它们本来就只有
// 「我在写日期」这一个意思，不像内容那样还可能是用户*有意*要的字面。
// 「用户咋写就咋排」那一条仍然管用，只是要用内容说出来。
//
// *不用 Typst 原生的 datetime。* datetime(year: 2022, month: 6) 直接报
// 「date is incomplete」——原生类型表达不了月精度，而月正是这四处要的那一级。

#import "@local/banshi:0.1.0" as banshi
#import "./lang.typ": normalize
#import banshi.errors as _errors

// 英文月名。范例（博士研究生学位论文书写范例第 3 页）印的是「June, 2020」
// ——*逗号在月与年之间*，正常英文不这么写，但范例和 hithesis
// （\__hit_date_en:n）都如此，照范例。
#let _months-en = (
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
)

#let _all-digits(s, low, high) = {
  if s.len() < low or s.len() > high { return false }
  s.clusters().all(c => "0123456789".contains(c))
}

// 认得出就给 (year, month, day)，认不出给 none。缺的那几级是 none。
//
// 年必须四位——两位的「22-06」既能读成 2022 年 6 月也能读成 22 年 6 月，
// 认下来等于替用户猜。月日一到两位都收，「2022-6-5」与「2022-06-05」同解。
#let parse(value) = {
  if type(value) != str { return none }
  let parts = value.trim().split("-")
  if parts.len() > 3 { return none }
  if not _all-digits(parts.at(0), 4, 4) { return none }
  let out = (year: int(parts.at(0)), month: none, day: none)
  // *月日还要在范围内。* 只查位数的话「2022-13」会一路走到英文月名那张
  // 表上越界；认不出来当字面排出去，比崩了强，也比排出个第 13 个月强
  if parts.len() > 1 {
    if not _all-digits(parts.at(1), 1, 2) { return none }
    out.month = int(parts.at(1))
    if out.month < 1 or out.month > 12 { return none }
  }
  if parts.len() > 2 {
    if not _all-digits(parts.at(2), 1, 2) { return none }
    out.day = int(parts.at(2))
    if out.day < 1 or out.day > 31 { return none }
  }
  out
}

// 把一份 (year, month, day) 排成字。两处共用：render 与 today
#let _parts(d, lang) = {
  if lang == "en" {
    if d.month == none { return [#d.year] }
    let day = if d.day == none { [] } else { [ #d.day] }
    return [#_months-en.at(d.month - 1)#day, #d.year]
  }
  if d.month == none { return [#(d.year)年] }
  if d.day == none { return [#(d.year)年#(d.month)月] }
  [#(d.year)年#(d.month)月#(d.day)日]
}

// 排出来。非字符串（内容、auto）原样交回去，字符串必须是 ISO。
//
// *lang 默认跟 text.lang 走，不是跟文档语言走。* 两者绝大多数时候一样
// ——lib.typ 那句 set text(lang: doc-lang) 把文档语言铺到全文——但英文内封
// 自己设了 lang: "en"（titlepage.typ:509），于是同一个 defense-date 在中文内封
// 排「2020年6月」、在英文内封排「June, 2020」，不必由调用方逐处把语言传下来。
//
// 文档语言（src/terms/lang.typ 的 doc-lang）是「这篇论文是哪一版」，一篇只有一个；
// text.lang 是「这几个字是什么语言」，可以局部改。日期要的是后者。
//
// *中文那份不写空格。* 范例里「2022 年6 月」的空格是 Word 给汉字与拉丁
// 之间自动加的，不是排版的人打的；我们那一套在 banshi/src/styles/rules.typ 的 shows 里，照样会加。
#let render(value, lang: auto) = {
  if type(value) != str { return value }
  let d = parse(value)
  if d == none {
    panic(
      "expected an ISO date such as \"2026\", \"2026-06\", or \"2026-06-05\", found "
        + repr(value) + " (write content like [" + value + "] to print it as given)",
    )
  }
  if lang != auto { return _parts(d, normalize(lang)) }
  context _parts(d, normalize(text.lang))
}

// 编译那天。
//
//     #today()                    2026年8月28日
//     #today(precision: "month")  2026年8月
//     #today(lang: "en")          August 28, 2026
//
// *到日，不是到月。* 这个函数是就地打印用的（签名处、正文里写一句），
// 与封面内封那四处不是一回事——那四处规范只要年月，这里给的是「今天」，
// 略掉日反而是丢信息。写 precision 就按写的来。
//
// *时区钉死东八区。* 不跟编译机器走：同一份稿子在国外编译会差一天，而
// 「今天」在这里指的是学校所在地的今天。datetime.today() 的 offset 默认是本地
// 时区，所以这一条得明写。
//
// *每次编译都变。* 定稿的日期不该这么来——封面、内封那三个字段写死
// ISO 字符串，见 src/info.typ 的 date-fields。
#let _precisions = ("year", "month", "day")

#let today(precision: auto, lang: auto) = context {
  let want = if precision == auto { "day" } else { precision }
  if want not in _precisions {
    panic(_errors.expected-one-of(_precisions, precision))
  }
  let t = datetime.today(offset: 8)
  let d = (
    year: t.year(),
    month: if want == "year" { none } else { t.month() },
    day: if want == "day" { t.day() } else { none },
  )
  _parts(d, normalize(if lang == auto { text.lang } else { lang }))
}
