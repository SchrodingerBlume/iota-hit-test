#import "@local/banshi:0.1.0" as banshi
#import banshi.content: metadata-of, blank, trim-tail, edge as _edge
#import banshi.runs: has-cj

#let languages = ("zh", "en")
#let normalize(value) = if value == "en" { "en" } else { "zh" }
#let doc-lang = state("iota-hit-doc-lang", "zh")
#let resolve-lang(value) = {
  if value == auto { doc-lang.get() } else { normalize(value) }
}
#let part-lang = state("iota-hit-part-lang", auto)
#let effective-lang() = {
  let value = part-lang.get()
  if value == auto { doc-lang.get() } else { normalize(value) }
}
#let _flag(warning) = {
  if warning not in (auto, true, false) {
    panic("#en(warning:) / #zh(warning:): expected auto, true, or false, found " + repr(warning))
  }
  if warning == auto { (:) } else { (iota-lang-warning: warning) }
}
#let en(body, warning: auto) = metadata((iota-en: body) + _flag(warning))
#let zh(body, warning: auto) = metadata((iota-zh: body) + _flag(warning))
// 标题内部存的原文（撑开、折行之前那份）：拆分时它顶替没标记的那些片段；给空的就是「没标记的一律不算」
#let original(body) = metadata((iota-original: body))
#let find-en(c) = {
  let r = metadata-of(c, "iota-en")
  if r.len() == 0 or blank(r.first()) { none } else { r.first() }
}
#let find-zh(c) = {
  let r = metadata-of(c, "iota-zh")
  if r.len() == 0 or blank(r.first()) { none } else { r.first() }
}
#let find-en-warning(c) = {
  let r = metadata-of(c, "iota-lang-warning")
  if r.len() == 0 { auto } else { r.first() }
}

// 拆双语：#en[] 里的是英文、#zh[] 里的是中文，没标记的是文档语言（lang）。只扫顶层（嵌套的
// sequence 摊平）。段落随文档语言那一侧——两个标记之间它分了段，标记那侧也分段，否则接成同一段；
// 同一侧相邻两截之间的接缝：两侧都是中日文字才不留空格（谚文靠空格断词，算西文那边）。
// 没标记、没原文的内容原样两侧共用。
#let _space = [ ].func()
#let _tag(kid) = if type(kid) == content and kid.func() == metadata and type(kid.value) == dictionary {
  if "iota-en" in kid.value { "en" } else if "iota-zh" in kid.value { "zh" }
  else if "iota-original" in kid.value { "original" } else { none }
} else { none }
#let _flat(kids) = kids.map(k => if type(k) == content and k.has("children") { _flat(k.children) } else { (k,) }).flatten()
#let _seam(a, b) = {
  let x = _edge(a, true)
  let y = _edge(b, false)
  if x == "" or y == "" or (has-cj(x) and has-cj(y)) { () } else { ([ ],) }
}
#let _trim(out) = {
  while out.len() > 0 and (out.first().func() in (_space, parbreak)) { out = out.slice(1) }
  while out.len() > 0 and (out.last().func() in (_space, parbreak)) { out = out.slice(0, -1) }
  out
}
// 一侧的拼装：own-lang 是没标记那些片段归哪一侧
#let _side(pieces, want, own-lang) = {
  let out = ()
  let kept-space = false   // 两截没标记的片段之间用户自己敲的空格
  let cut = false          // 上一截之后隔着别的一侧的东西，接缝按两侧的字定
  for (tag, p) in pieces {
    if tag == "par" {
      if out.len() > 0 and out.last().func() != parbreak { out.push(p) }
      kept-space = false
      cut = false
    } else if tag == "space" {
      kept-space = true
    } else if tag == want or (tag == "own" and own-lang == want) {
      if out.len() > 0 and out.last().func() != parbreak {
        if cut or tag != "own" { out += _seam(out.last(), p) } else if kept-space { out.push([ ]) }
      }
      out.push(p)
      kept-space = false
      cut = false
    } else {
      cut = true
    }
  }
  let out = _trim(out)
  if out.len() == 0 { none } else { out.join() }
}
#let _pieces(body) = {
  if type(body) != content { return none }
  let kids = if body.has("children") { _flat(body.children) } else { (body,) }
  let tags = kids.map(_tag)
  if tags.all(t => t == none) { return none }
  let has-original = "original" in tags
  let pieces = ()
  for (kid, tag) in kids.zip(tags) {
    if tag == "original" {
      if not blank(kid.value.iota-original) { pieces.push(("own", kid.value.iota-original)) }
    } else if tag != none {
      let inner = kid.value.at("iota-" + tag)
      if not blank(inner) { pieces.push((tag, inner)) }
    } else if kid.func() == parbreak {
      pieces.push(("par", kid))
    } else if kid.func() == _space {
      pieces.push(("space", kid))
    } else if not has-original {
      pieces.push(("own", kid))
    }
  }
  pieces
}
#let split(body, lang: "zh") = {
  let pieces = _pieces(body)
  if pieces == none { return (zh: body, en: body, plain: true) }
  (zh: _side(pieces, "zh", lang), en: _side(pieces, "en", lang), plain: false)
}
// 只要没标记的那些片段（标题存原文用）
#let own-of(body) = {
  let pieces = _pieces(body)
  if pieces == none { body } else { _side(pieces, "own", "own") }
}
// 没标记的原样返回（末尾的空白与 metadata 去掉）；有标记的没那一半就用另一半
#let title-of(body, target, lang: auto) = {
  let lang = if lang == auto { doc-lang.get() } else { lang }
  let s = split(body, lang: lang)
  if s.plain { return trim-tail(body) }
  let mine = s.at(target)
  if mine != none { return mine }
  s.at(if target == "en" { "zh" } else { "en" })
}
