// 文档语言。
//
// *一篇一个值，中途改不了。* 它定的是整篇的结构：标题取哪一份、词条走
// 哪一层、目录出几份、页眉排哪一份、章节编号用哪一套。这些东西跨页，某一段
// 切了语言就抖起来是错的；而「中途换语言」本身也不是真实需求——一篇学位论文
// 只会是中文版或英文版。
//
// 曾经做过「逐处跟 text.lang」那一版，能跑，但接缝在编号上：换得掉标题正文，
// 换不掉 set heading(numbering:)——Typst 的 numbering 函数只收数字、进不了
// context。半套能换半套不能换，不如不换。
//
// 怎么定：
//
//     #show: iota-hit                                  中文（默认）
//     #show: iota-hit.with(lang: "en")                 英文
//     #set text(lang: "en")
//     #show: iota-hit.with(lang: auto)                 英文——auto 跟外层设的走，
//                                                      而那句 set 必须写在 show 之前
//
// *非中非英一律回落中文*——词条表只有这两档（见 src/terms/built-in.typ），
// 写 ja / ru 落到别处只会是一片空。
//
// *text.lang 只有这一个主人。* 别处不许拿它表示「这一段按西文排」——
// 排版那一档走 font-zh: "latin"，见 src/paragraph/latin.typ 的 latin-par 里「这里不设 lang」那段。

#let languages = ("zh", "en")

// 把任意 text.lang 归到我们认的两档
#let normalize(value) = if value == "en" { "en" } else { "zh" }

// 整篇那一个值。iota-hit 入口写一次，别处只读。*要在 context 里读*
#let doc-lang = state("iota-hit-doc-lang", "zh")

// 部件的 lang 参数解法：auto 跟随文档语言，写死的就照写的。
//
// 写死的那一档留着是有用的：中英摘要是*两个部分*，各自固定语言，
// 由 abstract 分别传 "zh" / "en"，不跟文档走。
//
// *要在 context 里调*
#let resolve-lang(value) = {
  if value == auto { doc-lang.get() } else { normalize(value) }
}

// 部件语言。*文档语言的例外，只有一处*：中英摘要各是一个部分、各自固定
// 语言（见上面 resolve-lang），而缩略语的首次展开要按*用的那一处*组字——
// 中文论文的英文摘要里写 @SCNA，出的得是「Somatic copy number alteration (SCNA)」，
// 不是中文那一套。hithesis 整篇一个开关（\g__hit_en_bool，声明时就把字组好了，
// hit-thesis.cls 的 \hit@abbr@declare:nn），那一页只能手写全称；我们比它好这一点。
//
// *不拿 text.lang 传这个信号*——它另有主人（见上）。自带语言的部件在自己
// 那一段里立它（abstract 一进一出），别处 auto ＝ 跟文档语言。目前只有缩略语
// 读它，见 src/references/abbreviations.typ 的 render
#let part-lang = state("iota-hit-part-lang", auto)

// 用的那一处的语言：部件立了就照部件，没立跟文档。*要在 context 里调*
#let effective-lang() = {
  let value = part-lang.get()
  if value == auto { doc-lang.get() } else { normalize(value) }
}
