// 文档语言，以及两种语言的名字（#en / zh 记号与按语言取名的 title-of）。
//
// *一篇一个值，中途改不了。* 它定的是整篇的结构：标题取哪一份、词条走
// 哪一层、目录出几份、页眉排哪一份、章节编号用哪一套。这些东西跨页，某一段
// 切了语言就抖起来是错的；而「中途换语言」本身也不是真实需求——一篇学位论文
// 只会是中文版或英文版。
//
// 曾经做过「逐处跟 text.lang」那一版，能跑，但接缝在编号上：换得掉标题正文，
// 换不掉 set heading(numbering:)——Typst 的 numbering 函数只收数字、进不了
// context。半套能换半套不能换，不如不换。
//
// 怎么定：
//
//     #show: iota-hit                                  中文（默认）
//     #show: iota-hit.with(lang: "en")                 英文
//     #set text(lang: "en")
//     #show: iota-hit.with(lang: auto)                 英文——auto 跟外层设的走，
//                                                      而那句 set 必须写在 show 之前
//
// *非中非英一律回落中文*——词条表只有这两档（见 src/terms/built-in.typ），
// 写 ja / ru 落到别处只会是一片空。
//
// *text.lang 只有这一个主人。* 别处不许拿它表示「这一段按西文排」——
// 排版那一档走 font-zh: "latin"，见 src/paragraph/latin.typ 的 latin-par 里「这里不设 lang」那段。
#import "../content.typ": metadata-of, blank, trim-tail

#let languages = ("zh", "en")

// 把任意 text.lang 归到我们认的两档
#let normalize(value) = if value == "en" { "en" } else { "zh" }

// 整篇那一个值。iota-hit 入口写一次，别处只读。*要在 context 里读*
#let doc-lang = state("iota-hit-doc-lang", "zh")

// 部件的 lang 参数解法：auto 跟随文档语言，写死的就照写的。
//
// 写死的那一档留着是有用的：中英摘要是*两个部分*，各自固定语言，
// 由 abstract 分别传 "zh" / "en"，不跟文档走。
//
// *要在 context 里调*
#let resolve-lang(value) = {
  if value == auto { doc-lang.get() } else { normalize(value) }
}

// 部件语言。*文档语言的例外，只有一处*：中英摘要各是一个部分、各自固定
// 语言（见上面 resolve-lang），而缩略语的首次展开要按*用的那一处*组字——
// 中文论文的英文摘要里写 @SCNA，出的得是「Somatic copy number alteration (SCNA)」，
// 不是中文那一套。hithesis 整篇一个开关（\g__hit_en_bool，声明时就把字组好了，
// hit-thesis.cls 的 \hit@abbr@declare:nn），那一页只能手写全称；我们比它好这一点。
//
// *不拿 text.lang 传这个信号*——它另有主人（见上）。自带语言的部件在自己
// 那一段里立它（abstract 一进一出），别处 auto ＝ 跟文档语言。目前只有缩略语
// 读它，见 src/references/abbreviations.typ 的 render
#let part-lang = state("iota-hit-part-lang", auto)

// 用的那一处的语言：部件立了就照部件，没立跟文档。*要在 context 里调*
#let effective-lang() = {
  let value = part-lang.get()
  if value == auto { doc-lang.get() } else { normalize(value) }
}

// ── 两种语言的名字 ──────────────────────────────────────────────────

// 往标题正文里塞的*记号*，以及「不编号」那个标签。
//
// *一种机制几个用户。* Typst 的 heading 不收自定义字段，想给某一个标题
// 附加信息（这一章的英文名、这一章要不要右翻页），办法是往它的*正文*里
// 塞一个 metadata——不显示、不占位、也不造 text run 边界（实测 18pt 加 1pt
// 字距的居中标题，塞与不塞逐字步进都是 19.0、左右缘都是 162.500 / 237.500），
// 而 show 规则拿到 it.body 就能挖出来。
//
// 三个记号：
//
//   en         这一章的英文名。*开放给用户*
//   zh         这一章的中文名。*内部件*——#chapter 与 term-chapter 替
//              用户塞。有了它，两份名字对称，取哪一份只看语言
//   subs       这个图的分图题。*开放给用户*，写在 caption 里
//   continued  这是上一个表的续表。*开放给用户*，同样写在 caption 里
//   openright  这一章要不要从右手页起。*内部件*——用户走
//              #chapter(openright: …)，那个函数替他塞
//
// 还有一个不走 metadata 的：*标签 <-> 表示不编号*，见文件末尾的
// nonumber-rules。它拿 label 当开关，是 Typst 生态里的既成写法
// （show ….where(label: …) 就是给这种用法留的）。

// 给标题挂英文名。
//
// *要写在 label 前面：*
//
//     = 绪论 #en[Introduction] <chap:intro>
//
// Typst 里标题行一旦出现 label，label *之后*的内容就不算标题正文了。
// 实测三种写法的 heading.body：
//
//     = 甲 #en[A] <a>     body = sequence([甲], [ ], metadata(…))   ✓
//     = 乙 <b> #en[B]     body = [乙]                              英文名没了
//     = 丙 <c>#en[C]      body = [丙]                              英文名没了
//
// label 那一侧不受影响——三种写法查出来 label 都贴在 heading 上（不是贴在
// metadata 上），\@ref 也都正常。所以只要守住「先 en 后 label」这一条即可，
// 而这本来就是 Typst 写 label 的惯例。
//
// 写反了不报错，只是英文目录里少一条。
//
// *= 那条路只挂名字，不换正文槽。* 英文档里「哪一份上台」由 #chapter 的
// 函数式写法管（它把两份都存成记号，正文槽按语言取），markup 标题的正文槽是
// 一段裸文字，show 规则换不掉它又不丢 label——所以 = 绪论 #en[Introduction]
// 在英文档里印的仍是「绪论」。要按语言切标题就用 #chapter，见 src/heading/heading.typ
//
// warning：英文目录、图表清单里这一条读着是中文时发不发那句红字（见 src/pages/outline.typ
// 的 _en-warn）。auto ＝ 不表态，跟那一页的 warning:；false 就地关这一条——#en(warning:
// false)[] 空着也不再报「没写英文名」；true 就地开。写在记号里，读的人 find-en-warning
#let en(body, warning: auto) = {
  if warning not in (auto, true, false) {
    panic("#en(warning:): expected auto, true, or false, found " + repr(warning))
  }
  metadata(if warning == auto { (iota-en: body) } else { (iota-en: body, iota-en-warning: warning) })
}

// 中文名。内部件，由 #chapter 与 term-chapter 塞——markup 标题没有这一个，
// 取中文时回落到正文槽本身。
#let zh(body) = metadata((iota-zh: body))

// 挖两份名字，挖不到*或挖出来是空的*都给 none。
#let find-en(c) = {
  let r = metadata-of(c, "iota-en")
  if r.len() == 0 or blank(r.first()) { none } else { r.first() }
}

// 这一条就地的 warning（auto ＝ 没写）
#let find-en-warning(c) = {
  let r = metadata-of(c, "iota-en-warning")
  if r.len() == 0 { auto } else { r.first() }
}

#let find-zh(c) = {
  let r = metadata-of(c, "iota-zh")
  if r.len() == 0 or blank(r.first()) { none } else { r.first() }
}

// 取某一语言那一份标题。
//
// *取不到就回落到有的那一份*——印出来的东西不能没有内容。标题、页眉、
// 目录条目三处都照这一条，不分「唯一的那份目录」与「附加的那份目录」：
// 英文档里英文目录是唯一一份，某章没写 #en 就整条不出的话，这一章会从目录里
// 消失；而分情况判「唯一 / 附加」要跨部件看别处出不出，讲不清也测不住。
//
// 代价是中文档的英文目录里会冒出中文标题。那正说明用户没给英文名，
// 露出来比悄悄藏起来容易发现。
#let title-of(body, lang) = {
  let mine = if lang == "en" { find-en(body) } else { find-zh(body) }
  if mine != none { return mine }
  // markup 标题（= 绪论 #en[…]）没有中文记号，正文槽本身就是中文那一份
  let own = trim-tail(body)
  if own != none { return own }
  if lang == "en" { find-zh(body) } else { find-en(body) }
}
