#import "@local/banshi:0.1.0" as banshi
#import banshi.content: metadata-of, blank, trim-tail, edge as _edge
#import banshi.runs: has-cj

#let languages = ("zh", "en")
#let normalize(value) = if value == "en" { "en" } else { "zh" }
#let doc-lang = state("iota-hit-doc-lang", "zh")
#let resolve-lang(value) = {
  if value == auto { doc-lang.get() } else { normalize(value) }
}
#let part-lang = state("iota-hit-part-lang", auto)
#let effective-lang() = {
  let value = part-lang.get()
  if value == auto { doc-lang.get() } else { normalize(value) }
}
#let en(body, warning: auto) = {
  if warning not in (auto, true, false) {
    panic("#en(warning:): expected auto, true, or false, found " + repr(warning))
  }
  metadata(if warning == auto { (iota-en: body) } else { (iota-en: body, iota-en-warning: warning) })
}
#let zh(body) = metadata((iota-zh: body))
#let find-en(c) = {
  let r = metadata-of(c, "iota-en")
  if r.len() == 0 or blank(r.first()) { none } else { r.first() }
}
#let find-en-warning(c) = {
  let r = metadata-of(c, "iota-en-warning")
  if r.len() == 0 { auto } else { r.first() }
}

#let find-zh(c) = {
  let r = metadata-of(c, "iota-zh")
  if r.len() == 0 or blank(r.first()) { none } else { r.first() }
}
// 拆双语：标记里的归标记那种语言，其余归另一种。只扫顶层（嵌套的 sequence 摊平）；
// 段落随没标记那一侧——两个标记之间它分了段，标记那侧也分段，否则接成同一段；
// 接缝两侧都是中日文字才不留空格（谚文靠空格断词，算西文那边）。没标记的内容原样两侧共用。
#let _space = [ ].func()
#let _marker(kid) = if type(kid) == content and kid.func() == metadata and type(kid.value) == dictionary {
  if "iota-en" in kid.value { "en" } else if "iota-zh" in kid.value { "zh" } else { none }
} else { none }
#let _flat(kids) = kids.map(k => if type(k) == content and k.has("children") { _flat(k.children) } else { (k,) }).flatten()
#let _seam(a, b) = {
  let x = _edge(a, true)
  let y = _edge(b, false)
  if x == "" or y == "" or (has-cj(x) and has-cj(y)) { () } else { ([ ],) }
}
#let _trim(out) = {
  while out.len() > 0 and (out.first().func() in (_space, parbreak)) { out = out.slice(1) }
  while out.len() > 0 and (out.last().func() in (_space, parbreak)) { out = out.slice(0, -1) }
  out
}
#let split(body) = {
  if type(body) != content { return (zh: body, en: body) }
  let kids = if body.has("children") { _flat(body.children) } else { (body,) }
  let marks = kids.map(_marker).filter(m => m != none).dedup()
  if marks.len() == 0 { return (zh: body, en: body) }
  // 两种标记都有（标题里模板自己既存 zh 又存 en）：各取各的，没有的那边用去掉标记的原文
  if marks.len() > 1 {
    let own = trim-tail(body)
    return (
      zh: { let v = find-zh(body); if v == none { own } else { v } },
      en: { let v = find-en(body); if v == none { own } else { v } },
    )
  }
  let marked = marks.first()
  let rest = if marked == "en" { "zh" } else { "en" }
  let own = ()         // 没标记那一侧
  let other = ()       // 标记那一侧
  let seam = false     // 刚去掉一个标记，等下一截来定接缝
  for kid in kids {
    if _marker(kid) != none {
      let inner = kid.value.at("iota-" + marked)
      if not blank(inner) {
        if other.len() > 0 and other.last().func() != parbreak { other += _seam(other.last(), inner) }
        other.push(inner)
      }
      while own.len() > 0 and own.last().func() == _space { own = own.slice(0, -1) }
      seam = true
    } else if kid.func() == parbreak {
      if own.len() > 0 and own.last().func() != parbreak { own.push(kid) }
      if other.len() > 0 and other.last().func() != parbreak { other.push(kid) }
      seam = false
    } else if kid.func() == _space {
      if not seam { own.push(kid) }
    } else {
      if seam and own.len() > 0 and own.last().func() != parbreak { own += _seam(own.last(), kid) }
      seam = false
      own.push(kid)
    }
  }
  let own = _trim(own)
  let other = _trim(other)
  let pack(xs) = if xs.len() == 0 { none } else { xs.join() }
  ((rest): pack(own), (marked): pack(other))
}
// 没标记的原样返回（末尾的空白与 metadata 去掉，同以前）；有标记的没那一半就用另一半
#let title-of(body, lang) = {
  let s = split(body)
  if s.zh == s.en { return trim-tail(body) }
  let mine = s.at(lang)
  if mine != none { return mine }
  s.at(if lang == "en" { "zh" } else { "en" })
}
