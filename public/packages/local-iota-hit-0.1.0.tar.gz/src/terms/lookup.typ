// 本地化词条的机制：state、覆盖键的解析与查表。字面（from(桶) 哨兵与 term-defaults
// 那张表）在 src/terms/built-in.typ，这里 import 来查。
//
// *找不到就报错，不回落到键名。* 两种找不到都是静默出错：
//
//   一、代码问的键表里没有。回落的话会把*键名本身*排到页面上——论文里
//       原地印出一个英文单词 nomenclature，编译不报错，得靠眼睛发现。
//   二、用户覆盖时把键名写错（abstrct）。深合并只会插一个没人读的键，
//       原来的字面纹丝不动，用户以为改了其实什么也没发生。
//
// 与 src/document/info.typ 挡住写错的键是同一个道理。

#import "./built-in.typ": term-defaults
#import "../axes.typ" as _axes
#import "../errors.typ" as _errors
#import "../settings/resolve.typ" as _settings
#import "./lang.typ": languages
#import "../document/info.typ": info-get

// 哨兵 from(桶)：这一格跟那个桶里同名那条走，见 src/terms/built-in.typ
#let _from-of(value) = {
  if type(value) != content or value.func() != metadata { return none }
  let v = value.value
  if type(v) == dictionary and "iota-hit-from" in v { v.iota-hit-from } else { none }
}
// from(桶, key: …) 那一档指的是对方桶里*另一个名字*的那一族；没写就是同名
#let _from-key-of(value, own) = {
  let v = value.value
  if type(v) == dictionary and "key" in v and v.key != none { v.key } else { own }
}

// 键 k 是不是 key 那一族的一档：去掉 "key-" 之后剩下的每一段都得是某根轴的
// 档名（或 not-档名）。光按前缀认会把 degree-type-academic 当成 degree 的一档搬走
#let _axis-segments = _axes.axes.values().flatten()
#let _is-variant-of(k, key) = {
  if not k.starts-with(key + "-") { return false }
  let parts = k.slice(key.len() + 1).split("-")
  let i = 0
  while i < parts.len() {
    if parts.at(i) == "not" {
      if i + 1 >= parts.len() or parts.at(i + 1) not in _axis-segments { return false }
      i += 2
    } else {
      if parts.at(i) not in _axis-segments { return false }
      i += 1
    }
  }
  true
}

// 把写着哨兵的那几格换成所指的桶里的字。那个桶不存在、或里面既没有同名那条
// 也没有它的任何一档，就报错——那是把哨兵指向了空处，静默的话页面上就是一格白
// （metadata 不可见）。所指的那条自己又是哨兵也报错，不追两层
//
// *跟的是那一条词条的整族，不只是光键名那一条。* caption 桶的图那一条
// 有两档（image ＝ Fig.、image-shenzhen ＝ Figure），清单桶写 from("caption")
// 就把两档一起搬过来，那边照样按学位挑得出来——只搬光键名的话，正文题注印
// 「Figure 2-1」、插图清单却印「Fig. 2-1」，同一个号两种名。*光键名可以没有*：
// document-type 那一族在 base 里只有 -bachelor / -master / -doctor 几档，页面写
// document-type: from("base") 就是搬这一族。桶自己已经写了同名的一档就不盖
#let _resolve-from(table, by-page, lang, page) = {
  let out = table
  for (key, value) in table {
    let target = _from-of(value)
    if target == none { continue }
    let where = "(language: " + repr(lang) + ", bucket: " + repr(page) + ", key: " + repr(key) + ")"
    if target not in by-page {
      panic("from(" + repr(target) + "): no such bucket " + where)
    }
    let bucket = by-page.at(target)
    // 对方桶里叫什么：默认同名，写了 key: 就按那个名找，搬过来时各档改回本名
    let src = _from-key-of(value, key)
    let family = bucket.pairs().filter(((k, v)) => k == src or _is-variant-of(k, src))
    if family.len() == 0 {
      panic("from(" + repr(target) + "): bucket " + repr(target) + " does not contain key " + repr(src) + " or any of its variants " + where)
    }
    if src in bucket {
      if _from-of(bucket.at(src)) != none {
        panic("from(" + repr(target) + "): the referenced entry is itself a from(...) sentinel " + where)
      }
      out.insert(key, bucket.at(src))
    } else {
      // 光键名那一格在目标桶里没有：哨兵本身不能留在表里（metadata 印出来是空），
      // 删掉，族里的各档就是全部
      let _ = out.remove(key)
    }
    for (k, v) in family {
      if k == src or _from-of(v) != none { continue }
      let own = key + k.slice(src.len())
      if own not in table { out.insert(own, v) }
    }
  }
  out
}

#let terms-state = state("iota-hit-terms", none)

// 语言那两档只有 src/terms/lang.typ 一份；词条表的桶得与它逐个对上，
// 少一档就是那一档整个没有字面，当场拦下
#assert(
  term-defaults.keys().sorted() == languages.sorted(),
  message: "term-defaults languages " + repr(term-defaults.keys()) + " do not match lang.typ " + repr(languages),
)

// 用户写的覆盖是*一层扁平字典*，键的形状是「[桶名-]词条[-语言]」：
//
//     #acknowledgement(overrides: (title-zh: [鸣谢]))   在致谢那一页里，桶名省了
//     #acknowledgement(overrides: (acknowledgement-title: […]))  写上桶名也对
//     #show: iota-hit.with(overrides: (base-university-zh: […]))  文档级，桶名必写
//
// *语言后缀省掉，就是此处生效的那一档语言*——文档级取文档主语言
// （iota-hit 的 lang），页面级取那一页自己的语言。所以整篇英文的文档里写
// overrides: (title: […]) 改的是英文那一条，不是中文那一条。
//
// *先前这一支写死了 zh*，于是英文档上光键名的覆盖*一声不响地不生效*
// ——它落进 zh 桶，而排版取的是 en 桶（实测 lang: "en" 的文档写
// overrides: (title: [Thanks])，致谢那一页照旧印 Acknowledgements）。这是包里
// 最不容许的那类毛病，见本文件抬头「找不到就报错，不回落到键名」。
//
// *与 info 那边的 X / X-en 是同一件事，不必分开记。* 那边 title / title-en
// 是中英两个题目，这边 title / title-en 是中英两档字面——都是「同一样东西的两档
// 语言」，选哪一档都由*此处生效的语言*定：中文封面取中文题目与中文词条，
// 英文内封取英文的；lang: "en" 的文档里中文封面照样印中文题目，因为那一页就是
// 中文页。所以*全项目一条规则*，两边都不特判。
//
// 唯一的差别不在命名上：词条*有默认表*（两档都填好了，用户不写也有字），
// info 是用户数据（可以没有，缺了就不排那一行）。
//
// *为什么要枚举断法。* 键里到处是连字符：词条本身叫 in-english-toc、
// keywords-separator，词条还带档位后缀（author-bachelor），桶名 toc 与词条名
// toc-en 还会撞——
// 「abstract-toc-en」既能读成「桶 abstract + 词条 toc-en」，也能读成
// 「桶 abstract + 词条 toc + 语言 en」。所以把所有断法都试一遍，要求*恰好
// 一种*讲得通：一种都不通就是写错了，通了两种就是真有歧义，两样都当场报错。
#let _hits(flat, page: none, lang: "zh") = {
  // 先按有没有语言后缀分出两组候选
  let candidates = ()
  for l in languages {
    if flat.ends-with("-" + l) {
      candidates.push((l, flat.slice(0, flat.len() - l.len() - 1)))
    }
  }
  // 没写后缀的那一档*落在此处生效的语言上*，不是写死的中文，见抬头
  candidates.push((lang, flat))

  // 桶里认不认这个键：写着这个键，或者写着它那一族里的哪一档（cover 桶只写了
  // document-type: from("base")，用户覆盖 cover-document-type-doctor 也得认——
  // 那一族是搬过来的，各档都是这一页的键）
  let known(table, key) = key in table or table.keys().any(k => (
    _is-variant-of(key, k) or _is-variant-of(k, key)
  ))
  let hits = ()
  for (lang, rest) in candidates {
    let buckets = term-defaults.at(lang)
    // 没写桶名：落在本页自己的桶里。文档级没有「本页」，这一支不走
    if page != none and page in buckets and known(buckets.at(page), rest) {
      hits.push((lang, page, rest))
    }
    // 写了桶名
    for (bucket, table) in buckets {
      if rest.starts-with(bucket + "-") {
        let key = rest.slice(bucket.len() + 1)
        if known(table, key) and (lang, bucket, key) not in hits {
          hits.push((lang, bucket, key))
        }
      }
    }
  }

  hits
}

// 认得出就给三元组，认不出给 none。*分派要用它试探*，所以这一支不报错
// ——报错的活儿留给 _resolve-key。（用它试探的是 nomenclature 那一页：合并页的
// 页面级覆盖要按桶名分派给三个桶，见 src/pages/nomenclature.typ 的 bucket-of。）
#let lookup-key(flat, page: none, lang: "zh") = {
  let hits = _hits(flat, page: page, lang: lang)
  if hits.len() == 1 { hits.first() } else { none }
}

#let _resolve-key(flat, page: none, lang: "zh") = {
  let hits = _hits(flat, page: page, lang: lang)
  if hits.len() == 0 {
    // *它是个取值、不是词条*的话把话说明白。用户那一份 overrides 里词条与
    // 设定两类键同住（设定那一张表在 src/settings/defaults.typ），写到不收取值的
    // 那一页上时，报「不认识这个词条」是把人往错的方向指。
    if _settings.lookup-key(flat) != none {
      panic(_settings.not-a-term(flat, page: page))
    }
    let where = if page == none {
      " (document-level overrides need the bucket name, " + "as in \"base-university\" or \"abstract-heading\")"
    } else {
      " (on the " + repr(page) + " page the bucket name may be omitted, " + "as in \"heading\")"
    }
    panic("unknown term key: " + flat + where)
  }
  if hits.len() > 1 {
    panic(
      "ambiguous term key: " + flat + " (reads as "
        + _errors.one-of(hits.map(((l, b, k)) => b + "." + k + " in " + repr(l)))
        + ")",
    )
  }
  hits.first()
}

// 把扁平的一份覆盖折成「语言 → 桶 → 词条」。page 给了就是页面级的那一档，
// 只许改本页的桶。
// 档位后缀按轴的次序排好（src/axes.typ 里 axes 的次序：学位、学位类别、门类、文种、
// 校区、阶段）：查的时候候选键是按这个次序拼的（variant-candidates），用户写成
// image-shenzhen-bachelor 也认，收进表里时改成 image-bachelor-shenzhen
#let _canonical(key) = {
  let parts = key.split("-")
  let tail = ()
  let i = parts.len() - 1
  while i >= 0 {
    let seg = parts.at(i)
    let neg = i > 0 and parts.at(i - 1) == "not"
    if seg in _axis-segments {
      tail.push((axis: _axes.axes.pairs().position(((a, vs)) => seg in vs), seg: if neg { "not-" + seg } else { seg }))
      i -= if neg { 2 } else { 1 }
    } else { break }
  }
  if tail.len() == 0 { return key }
  let base = parts.slice(0, i + 1).join("-")
  ((base,) + tail.sorted(key: t => t.axis).map(t => t.seg)).join("-")
}

#let expand-overrides(value, page: none, lang: "zh") = {
  if type(value) != dictionary {
    panic("expected dictionary, found " + str(type(value))
      + " (term overrides are one flat dictionary)")
  }
  let out = (:)
  for (flat, text) in value {
    let (lang, bucket, key) = _resolve-key(flat, page: page, lang: lang)
    // *只许改本页的桶。* 一份传给 acknowledgement() 的覆盖里写着
    // conclusion-heading，是把改动扔进了没人读的地方——那个桶合法，词条也
    // 合法，而这一页只取自己那个桶，于是一声不响地什么也没发生。
    if page != none and bucket != page {
      panic(
        "term overrides for the " + repr(page) + " page cannot change bucket "
          + repr(bucket),
      )
    }
    let by-page = out.at(lang, default: (:))
    let table = by-page.at(bucket, default: (:))
    table.insert(_canonical(key), text)
    by-page.insert(bucket, table)
    out.insert(lang, by-page)
  }
  out
}

// 文档级覆盖。整篇通用的改法走这里；只改一页的走那一页自己的 terms-overrides
// 参数，见 src/api.typ。
#let terms-overrides(value, lang: "zh") = {
  let expanded = expand-overrides(value, lang: lang)
  terms-state.update(old => {
    let base = if old == none { term-defaults } else { old }
    let merged = base
    for (lang, by-page) in expanded {
      let langs = base.at(lang)
      for (bucket, table) in by-page {
        langs.insert(bucket, langs.at(bucket) + table)
      }
      merged.insert(lang, langs)
    }
    merged
  })
}

// 某一页的整张表：本页的桶盖在 base 上。不进 state，给部件的默认值用。
#let static-terms(lang, page) = {
  let by-page = term-defaults.at(lang)
  _resolve-from(by-page.base + by-page.at(page), by-page, lang, page)
}

// 同上，但并进用户的覆盖。要在 context 里调。
//
// 给封面、内封这类*进不了 context* 的部件用：它们在函数体一开头就要用到
// 字面（封面那个求解器得连着题目一起量高），读不了 state。所以由
// src/api.typ 那一层在 context 里取好整张表、当参数传下去。
#let term-table(lang, page, overrides: (:)) = {
  if lang not in term-defaults {
    panic(_errors.expected-one-of(languages, lang))
  }
  let v = terms-state.get()
  let by-page = if v == none { term-defaults.at(lang) } else { v.at(lang) }
  let table = by-page.base + by-page.at(page)
  // 页面自己那一份压在文档级的上面
  if overrides != (:) {
    let expanded = expand-overrides(overrides, page: page, lang: lang)
    table = table + expanded.at(lang, default: (:)).at(page, default: (:))
  }
  // by-page 已经并过文档级覆盖，所以这里换到的是用户改后的值
  _resolve-from(table, by-page, lang, page)
}

// 取一个词条。要在 context 里调。
#let term-of(lang, page, key) = {
  let table = term-table(lang, page)
  if key not in table {
    panic(
      "bucket " + repr(page) + " does not contain term " + repr(key)
        + " (language: " + repr(lang) + ")",
    )
  }
  table.at(key)
}

// 按*档*取一个词条：词条名加零到多个档位后缀，取最贴切的那一条。
//
//     term-for(table, "supervisor", (degree-level: "doctor"))
//         依次试 supervisor-doctor → supervisor-graduate → supervisor
//
// *一并试、比专度，不是一条一条往下退。* 多根轴时候选不是一条链而是
// 一张网（-doctor-shenzhen / -not-bachelor-shenzhen / -doctor / …），退的顺序
// 没法排成一列；所以全试一遍，取最专的那一条。反档 -not-bachelor 是「这根轴上
// 除本科之外的任何档」，比正档松一级，见 src/axes.typ。
//
// *一样专的有两条就报错。* 那说明表里同时写了 -graduate 与 -shenzhen
// 这种谁也不压过谁的两条，挑哪条都是瞎猜。找不到也报错，理由同本文件开头。
#let term-for(table, name, variant) = {
  let hits = ()
  for candidate in _axes.variant-candidates(variant) {
    let key = ((name,) + candidate.segments).join("-")
    if key in table { hits.push((candidate.specificity, key)) }
  }
  if hits.len() == 0 {
    panic(
      "bucket does not contain term " + repr(name) + " for ("
        + variant.pairs().map(((a, v)) => a + ": " + repr(v)).join(", ") + ")",
    )
  }
  let best = hits.fold(0, (m, h) => calc.max(m, h.first()))
  let top = hits.filter(h => h.first() == best)
  if top.len() > 1 {
    panic(
      "ambiguous term " + repr(name) + ": "
        + top.map(h => repr(h.last())).join(" and ") + " are equally specific",
    )
  }
  table.at(top.first().last())
}

// 取一个词条，*它是收槽的函数就把槽填上*。
//
// 表里的值有三种形状：*内容*（多数）、*函数*（声明页那几段收题目、
// 内封的学位类别收类别名目、页眉那一条收校名与表单名）、*none*（深圳中期
// 那份没有落款）。函数那一档是因为「这几个字」里嵌着一截随文档变的东西，写成
// 函数才不必把整段拆成三条词条。
//
// *判断收在这一处。* 先前四处各写了一遍 if type(v) == function——声明页
// 两处、答辩页一处、封面一处，加一条函数词条就得记着改四个地方。*也收
// 内容*：用户把那一条整段自己写时给的是内容，只认函数会崩在「expected function,
// found content」上。
//
// none 不在这儿判——「取到 none 就不排这一行」是页面自己的事，与「这一条长什么
// 样」无关。
#let term-apply(table, name, variant, ..slots) = {
  let v = term-for(table, name, variant)
  if type(v) == function { v(..slots) } else { v }
}

// *查词条一律递全部的轴*：用户按分支规则自己起的档（overrides: (caption-raw-interim: [Code])，
// 表里本来没有）才能在任何一处都挑得到——查的时候只递一两根轴的话，带着别的轴的档永远
// 选不中、写了等于没写，而且拦不住（在 context 里按 state 拦会被迭代吞掉，见记忆）。默认表里
// 的档因此得在全轴之下也挑得对——*base 只放各页共用的字，一页专有的档住那一页的桶*
// （内封的「类别」曾住 base，from("base") 把它连族搬进报告首页的桶、与首页要印的字同专，
// 靠少递一根轴躲着；挪回 titlepage 桶就没什么要躲的了）
#let variant-of(info) = {
  let v = (
    degree-level: info.degree-level, form: info.form, stage: info.stage, category: info.category,
    campus: _axes.campus-for(info.campus, info.degree-level),
  )
  // 学位类别只在硕博上有意义，auto 按文种折（实践成果 → 专业学位）。*这里不校验*（学术学位
  // 配实践成果那种自相矛盾的写法由封面那一处 degree-type-for 报）：这一支在页眉、题注这些按
  // state 跑的 context 里到处被调，在那儿 panic 会被迭代吞掉、一声错不报，见记忆
  if info.degree-level != "bachelor" {
    let dt = info.at("degree-type", default: auto)
    let dt = if dt == auto { if info.form == "practice" { "professional" } else { "academic" } } else { dt }
    if dt in ("academic", "professional") { v.insert("degree-type", dt) }
  }
  v
}
// 当前文档的。*要在 context 里调*
#let info-variant() = variant-of(info-get())

// 「交上去的那份东西叫什么」，*不带学位*——学位论文／实践成果／本科毕业
// 论文（设计）。声明页的两个小标题与那句「本人知悉…」、答辩决议页的章标题、
// 报告首页那一行「（学位论文/实践成果）」，印的都是它。
//
// *硕博按 form，本科按 degree-level*，两支不对称是因为轴本身就不对称：本科不分
// 学位论文与实践成果（指南通篇写「本科毕业论文（设计）」，括号把设计一并覆盖
// 了，见 src/axes.typ 的 form），所以那一档取的是文种本身。
//
// *写成一支函数而不是让 term-for 一次挑。* form 那一族里本科那两条
// （form-bachelor-dissertation ＝ 毕业论文、form-bachelor-practice ＝ 毕业设计）
// 是勾选框的*标签*，两个都印；本科的「这份东西叫什么」是 document-type
// 那一条（毕业论文（设计））。带着 degree-level 去查 form 会挑到标签，所以本科这一支
// 单走 document-type，硕博那一支查 form 时不递 degree-level（-bachelor 那两条就不进候选）。
//
// degree-level 不给 ＝ 不是本科。答辩决议页只有硕博，它不必装模作样地递一个学位进来。
#let subject-of(table, variant) = if variant.at("degree-level", default: none) == "bachelor" {
  term-for(table, "document-type", variant)
} else {
  // 本科不走这一支，form 那一族里 -bachelor 那两档（勾选框的标签）在硕博的轴下选不中
  term-for(table, "form", variant)
}
