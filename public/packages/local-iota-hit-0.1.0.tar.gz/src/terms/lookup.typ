
#import "../docxtyp.typ" as banshi
#import "./built-in.typ": term-defaults
#import "../axes.typ" as _axes
#import banshi.errors as _errors
#import "../settings/resolve.typ" as _settings
#import "./lang.typ": languages
#import "../info.typ": info-get, canonical-field
#let _context-key = "__iota-hit-term-context"
#let _axis-names = _axes.axes.keys()
#let _axis-segments = _axes.axes.values().flatten()
#let _split(key) = {
  let parts = key.split("-")
  let tail = ()
  let seen = (:)
  let i = parts.len() - 1
  while i >= 0 {
    let seg = parts.at(i)
    let neg = i > 0 and parts.at(i - 1) == "not"
    if seg not in _axis-segments { break }
    let axis = _axes.axes.pairs().position(((a, vs)) => seg in vs)
    let condition = if neg { "not-" + seg } else { seg }
    let name = _axis-names.at(axis)
    if name in seen {
      panic("term key " + repr(key) + ": multiple conditions for axis " + repr(name)
        + " (" + repr(condition) + " and " + repr(seen.at(name)) + "); use one condition per axis")
    }
    seen.insert(name, condition)
    tail.push((axis: axis, seg: condition))
    i -= if neg { 2 } else { 1 }
  }
  (name: parts.slice(0, i + 1).join("-"), tail: tail)
}
#let _name-of(key) = _split(key).name
#let _checked-variant(variant) = {
  let v = _axes.normalize(variant)
  for (axis, value) in v {
    if axis not in _axes.axes { panic("unknown axis: " + axis) }
    if value not in _axes.axes.at(axis) {
      panic(_errors.expected-one-of(_axes.axes.at(axis), value) + " (axis: " + axis + ")")
    }
  }
  v
}
#let _index(table) = {
  let out = (:)
  for (key, value) in table {
    if key == _context-key { continue }
    let parsed = _split(key)
    let name = canonical-field(parsed.name)
    let rules = out.at(name, default: ())
    rules.push((key: key, tail: parsed.tail, value: value,
      specificity: parsed.tail.map(t => if t.seg.starts-with("not-") { 1 } else { 2 }).sum(default: 0)))
    out.insert(name, rules)
  }
  out
}
#let _pick(index, name, variant, exact: none) = {
  let hits = index.at(name, default: ()).filter(rule => {
    if exact != none { return rule.key == exact }
    rule.tail.all(t => {
      let axis = _axis-names.at(t.axis)
      if axis not in variant { return false }
      if t.seg.starts-with("not-") { variant.at(axis) != t.seg.slice(4) }
      else { variant.at(axis) == t.seg }
    })
  })
  if hits.len() == 0 { return none }
  let best = hits.fold(0, (m, h) => calc.max(m, h.specificity))
  let top = hits.filter(h => h.specificity == best)
  if top.len() > 1 {
    panic("ambiguous term " + repr(name) + ": "
      + top.map(h => repr(h.key)).join(" and ") + " are equally specific")
  }
  top.first()
}
#let _page-aliases = (acknowledgements: "acknowledgments")
#let _page(name) = if name == none { none } else { _page-aliases.at(name, default: name) }
#let _page-key(key) = {
  for (alias, name) in _page-aliases {
    if key.starts-with(alias + "-") { return name + key.slice(alias.len()) }
  }
  key
}
#let _from-of(value) = {
  if type(value) != content or value.func() != metadata { return none }
  let v = value.value
  if type(v) == dictionary and "iota-hit-from" in v { v.iota-hit-from } else { none }
}
#let _from-key-of(value, own) = {
  let v = value.value
  if type(v) == dictionary and "key" in v and v.key != none { v.key } else { own }
}
#let _is-variant-of(k, key) = {
  if not k.starts-with(key + "-") { return false }
  let parts = k.slice(key.len() + 1).split("-")
  let i = 0
  while i < parts.len() {
    if parts.at(i) == "not" {
      if i + 1 >= parts.len() or parts.at(i + 1) not in _axis-segments { return false }
      i += 2
    } else {
      if parts.at(i) not in _axis-segments { return false }
      i += 1
    }
  }
  true
}
#let _resolve-from(table, origins, by-page, lang, page) = {
  let out = table
  let origins = origins
  for (key, value) in table {
    let target = _from-of(value)
    if target == none { continue }
    let where = "(language: " + repr(lang) + ", bucket: " + repr(page) + ", key: " + repr(key) + ")"
    if target not in by-page {
      panic("from(" + repr(target) + "): no such bucket " + where)
    }
    let bucket = by-page.at(target)
    let src = _from-key-of(value, key)
    let family = bucket.pairs().filter(((k, v)) => k == src or _is-variant-of(k, src))
    if family.len() == 0 {
      panic("from(" + repr(target) + "): bucket " + repr(target) + " does not contain key " + repr(src) + " or any of its variants " + where)
    }
    if src in bucket {
      if _from-of(bucket.at(src)) != none {
        panic("from(" + repr(target) + "): the referenced entry is itself a from(...) sentinel " + where)
      }
      out.insert(key, bucket.at(src))
      origins.insert(key, (page: target, name: _name-of(src),
        exact: if src == _name-of(src) { none } else { src }))
    } else {
      let _ = out.remove(key)
    }
    for (k, v) in family {
      if k == src or _from-of(v) != none { continue }
      let own = key + k.slice(src.len())
      if own not in table {
        out.insert(own, v)
        origins.insert(own, (page: target, name: _name-of(src),
          exact: if src == _name-of(src) { none } else { src }))
      }
    }
  }
  (table: out, origins: origins, index: _index(out),
    references: _index(table.pairs().filter(((k, v)) => _from-of(v) != none).to-dict()))
}

#let terms-state = state("iota-hit-terms", none)
#assert(
  term-defaults.keys().sorted() == languages.sorted(),
  message: "term-defaults languages " + repr(term-defaults.keys()) + " do not match lang.typ " + repr(languages),
)
#let _field-key(key) = {
  let name = _name-of(key)
  canonical-field(name) + key.slice(name.len())
}
#let _hits(flat, page: none, lang: "zh") = {
  let page = _page(page)
  let candidates = ()
  for l in languages {
    if flat.ends-with("-" + l) {
      candidates.push((l, flat.slice(0, flat.len() - l.len() - 1)))
    }
  }
  candidates.push((lang, flat))
  let known(table, key) = key in table or table.keys().any(k => _name-of(k) == _name-of(key))
  let hits = ()
  for (lang, rest) in candidates {
    let rest = _page-key(rest)
    let buckets = term-defaults.at(lang)
    if page != none and page in buckets and known(buckets.base + buckets.at(page), _field-key(rest)) {
      hits.push((lang, page, _field-key(rest)))
    }
    for (bucket, table) in buckets {
      if rest.starts-with(bucket + "-") {
        let key = _field-key(rest.slice(bucket.len() + 1))
        if known(buckets.base + table, key) and (lang, bucket, key) not in hits {
          hits.push((lang, bucket, key))
        }
      }
    }
  }

  hits
}
#let lookup-key(flat, page: none, lang: "zh") = {
  let hits = _hits(flat, page: page, lang: lang)
  if hits.len() == 1 { hits.first() } else { none }
}

#let _resolve-key(flat, page: none, lang: "zh") = {
  let hits = _hits(flat, page: page, lang: lang)
  if hits.len() == 0 {
    if _settings.lookup-key(flat) != none {
      panic(_settings.not-a-term(flat, page: page))
    }
    let where = if page == none {
      " (document-level overrides need the bucket name, " + "as in \"base-university\" or \"abstract-title\")"
    } else {
      " (on the " + repr(page) + " page the bucket name may be omitted, " + "as in \"title\")"
    }
    panic("unknown term key: " + flat + where)
  }
  if hits.len() > 1 {
    panic(
      "ambiguous term key: " + flat + " (reads as "
        + _errors.one-of(hits.map(((l, b, k)) => b + "." + k + " in " + repr(l)))
        + ")",
    )
  }
  hits.first()
}
#let _canonical(key) = {
  let (name, tail) = _split(key)
  if tail.len() == 0 { return key }
  ((name,) + tail.sorted(key: t => t.axis).map(t => t.seg)).join("-")
}

#let expand-overrides(value, page: none, lang: "zh") = {
  let page = _page(page)
  if type(value) != dictionary {
    panic("expected dictionary, found " + str(type(value))
      + " (term overrides are one flat dictionary)")
  }
  let out = (:)
  for (flat, text) in value {
    let (lang, bucket, key) = _resolve-key(flat, page: page, lang: lang)
    if page != none and bucket != page {
      panic(
        "term overrides for the " + repr(page) + " page cannot change bucket "
          + repr(bucket),
      )
    }
    let by-page = out.at(lang, default: (:))
    let table = by-page.at(bucket, default: (:))
    let key = _canonical(key)
    if key in table { panic("duplicate term key: " + bucket + "-" + key + " (including aliases)") }
    table.insert(key, text)
    by-page.insert(bucket, table)
    out.insert(lang, by-page)
  }
  out
}
#let terms-overrides(value, lang: "zh") = {
  let expanded = expand-overrides(value, lang: lang)
  terms-state.update(old => {
    let base = if old == none { (:) } else { old }
    let merged = base
    for (lang, by-page) in expanded {
      let langs = base.at(lang, default: (:))
      for (bucket, table) in by-page {
        langs.insert(bucket, langs.at(bucket, default: (:)) + table)
      }
      merged.insert(lang, langs)
    }
    merged
  })
}
#let _page-table(by-page, page) = {
  let base = if page in ("cover", "header") {
    by-page.base.pairs().filter(((k, _)) => _name-of(k) != "document-type").to-dict()
  } else { by-page.base }
  let origins = if page == "base" { (:) } else {
    base.pairs().map(((k, _)) => (k, (page: "base", name: _name-of(k), exact: none))).to-dict()
  }
  for key in by-page.at(page).keys() {
    let _ = origins.remove(key, default: none)
  }
  (table: base + by-page.at(page), origins: origins)
}
#let _defaults = {
  let out = (:)
  for (lang, by-page) in term-defaults {
    let tables = (:)
    for page in by-page.keys() {
      let raw = _page-table(by-page, page)
      tables.insert(page, _resolve-from(raw.table, raw.origins, by-page, lang, page))
    }
    out.insert(lang, tables)
  }
  out
}
// 先选当前桶的显式规则；默认规则若引用其他桶，再沿那条引用查源桶的覆盖。
// 这样既统一覆盖优先级，也保留博后页眉等独立指定的默认来源。
#let _resolve(ctx, page, name, variant, exact: none) = {
  if page == ctx.page {
    let own = _pick(ctx.local, name, variant)
    if own != none { return own }
  }
  let given = _pick(_index(ctx.overrides.at(page, default: (:))), name, variant)
  if given != none { return given }
  let defaults = _defaults.at(ctx.lang).at(page)
  let fallback = _pick(defaults.index, name, variant, exact: exact)
  if fallback == none {
    // 源桶的用户规则可以扩展默认项的适用范围，不能因原来没有匹配值就丢掉引用。
    let reference = _pick(defaults.references, name, variant, exact: exact)
    if reference != none {
      let target = _from-of(reference.value)
      let src = _from-key-of(reference.value, reference.key)
      return _resolve(ctx, target, _name-of(src), variant,
        exact: if src == _name-of(src) { none } else { src })
    }
    if page != "base" and name in _defaults.at(ctx.lang).base.index {
      return _resolve(ctx, "base", name, variant)
    }
    return none
  }
  let origin = defaults.origins.at(fallback.key, default: none)
  if origin != none {
    return _resolve(ctx, origin.page, origin.name, variant, exact: origin.exact)
  }
  fallback
}
#let _tagged(lang, page, overrides: (:), local: (:)) = {
  _defaults.at(lang).at(page).table + ((_context-key): (
    lang: lang, page: page, overrides: overrides, local: _index(local),
  ))
}
#let static-terms(lang, page) = {
  let page = _page(page)
  _tagged(lang, page)
}
#let term-for(table, name, variant) = {
  let name = canonical-field(name)
  let variant = _checked-variant(variant)
  let result = if _context-key in table {
    let ctx = table.at(_context-key)
    _resolve(ctx, ctx.page, name, variant)
  } else { _pick(_index(table), name, variant) }
  if result == none {
    panic(
      "bucket does not contain term " + repr(name) + " for ("
        + variant.pairs().map(((a, v)) => a + ": " + repr(v)).join(", ") + ")",
    )
  }
  result.value
}
#let has-term(table, name, variant) = {
  let name = canonical-field(name)
  let variant = _checked-variant(variant)
  if _context-key in table {
    let ctx = table.at(_context-key)
    _resolve(ctx, ctx.page, name, variant) != none
  } else { _pick(_index(table), name, variant) != none }
}
#let select-terms(table, variant) = {
  let variant = _checked-variant(variant)
  if _context-key not in table { return table }
  let ctx = table.at(_context-key)
  let names = (_defaults.at(ctx.lang).at(ctx.page).index.keys()
    + _index(ctx.overrides.at(ctx.page, default: (:))).keys() + ctx.local.keys())
  let out = table
  for name in names.dedup() {
    let result = _resolve(ctx, ctx.page, name, variant)
    if result != none { out.insert(name, result.value) }
    else { let _ = out.remove(name, default: none) }
  }
  out
}

#let term-apply(table, name, variant, ..slots) = {
  let v = term-for(table, name, variant)
  if type(v) == function { v(..slots) } else { v }
}
#let document-type-of(table, lang, variant, base-terms: auto) = {
  let value = term-for(table, "document-type", variant)
  if type(value) != function { return value }
  let base = term-for(if base-terms == auto { static-terms(lang, "base") } else { base-terms }, "document-type", variant)
  let stage = if has-term(table, "stage", variant) { term-for(table, "stage", variant) } else { none }
  value(if has-term(table, "degree", variant) { term-for(table, "degree", variant) } else { none }, base, stage)
}
#let variant-of(info) = {
  let v = (
    degree-level: info.degree-level, form: info.form, stage: info.stage, category: info.category,
    campus: _axes.campus-for(info.campus, info.degree-level),
  )
  if info.degree-level != "bachelor" {
    let dt = info.at("degree-type", default: auto)
    let dt = if dt == auto { if info.form == "practice" { "professional" } else { "academic" } } else { dt }
    if dt in ("academic", "professional") { v.insert("degree-type", dt) }
  }
  v
}
#let info-variant() = variant-of(info-get())
#let term-table(lang, page, overrides: (:)) = {
  let page = _page(page)
  if lang not in term-defaults { panic(_errors.expected-one-of(languages, lang)) }
  let given = terms-state.get()
  let by-page = if given == none { (:) } else { given.at(lang, default: (:)) }
  let expanded = if overrides == (:) { (:) } else { expand-overrides(overrides, page: page, lang: lang) }
  let local = expanded.at(lang, default: (:)).at(page, default: (:))
  select-terms(_tagged(lang, page, overrides: by-page, local: local), info-variant())
}
#let term-of(lang, page, key) = term-for(term-table(lang, page), key, info-variant())
#let subject-of(table, variant) = if variant.at("degree-level", default: none) in ("bachelor", "postdoc") {
  term-for(table, "document-type", variant)
} else {
  term-for(table, "form", variant)
}
