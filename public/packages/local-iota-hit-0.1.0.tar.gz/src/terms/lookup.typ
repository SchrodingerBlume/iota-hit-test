
#import "@local/banshi:0.1.0" as banshi
#import "./built-in.typ": term-defaults
#import "../axes.typ" as _axes
#import banshi.errors as _errors
#import "../settings/resolve.typ" as _settings
#import "./lang.typ": languages
#import "../info.typ": info-get
#let _from-of(value) = {
  if type(value) != content or value.func() != metadata { return none }
  let v = value.value
  if type(v) == dictionary and "iota-hit-from" in v { v.iota-hit-from } else { none }
}
#let _from-key-of(value, own) = {
  let v = value.value
  if type(v) == dictionary and "key" in v and v.key != none { v.key } else { own }
}
#let _axis-segments = _axes.axes.values().flatten()
#let _is-variant-of(k, key) = {
  if not k.starts-with(key + "-") { return false }
  let parts = k.slice(key.len() + 1).split("-")
  let i = 0
  while i < parts.len() {
    if parts.at(i) == "not" {
      if i + 1 >= parts.len() or parts.at(i + 1) not in _axis-segments { return false }
      i += 2
    } else {
      if parts.at(i) not in _axis-segments { return false }
      i += 1
    }
  }
  true
}
#let _resolve-from(table, by-page, lang, page) = {
  let out = table
  for (key, value) in table {
    let target = _from-of(value)
    if target == none { continue }
    let where = "(language: " + repr(lang) + ", bucket: " + repr(page) + ", key: " + repr(key) + ")"
    if target not in by-page {
      panic("from(" + repr(target) + "): no such bucket " + where)
    }
    let bucket = by-page.at(target)
    let src = _from-key-of(value, key)
    let family = bucket.pairs().filter(((k, v)) => k == src or _is-variant-of(k, src))
    if family.len() == 0 {
      panic("from(" + repr(target) + "): bucket " + repr(target) + " does not contain key " + repr(src) + " or any of its variants " + where)
    }
    if src in bucket {
      if _from-of(bucket.at(src)) != none {
        panic("from(" + repr(target) + "): the referenced entry is itself a from(...) sentinel " + where)
      }
      out.insert(key, bucket.at(src))
    } else {
      let _ = out.remove(key)
    }
    for (k, v) in family {
      if k == src or _from-of(v) != none { continue }
      let own = key + k.slice(src.len())
      if own not in table { out.insert(own, v) }
    }
  }
  out
}

#let terms-state = state("iota-hit-terms", none)
#assert(
  term-defaults.keys().sorted() == languages.sorted(),
  message: "term-defaults languages " + repr(term-defaults.keys()) + " do not match lang.typ " + repr(languages),
)
#let _split(key) = {
  let parts = key.split("-")
  let tail = ()
  let i = parts.len() - 1
  while i >= 0 {
    let seg = parts.at(i)
    let neg = i > 0 and parts.at(i - 1) == "not"
    if seg in _axis-segments {
      tail.push((axis: _axes.axes.pairs().position(((a, vs)) => seg in vs), seg: if neg { "not-" + seg } else { seg }))
      i -= if neg { 2 } else { 1 }
    } else { break }
  }
  (name: parts.slice(0, i + 1).join("-"), tail: tail)
}
#let _name-of(key) = _split(key).name
#let _hits(flat, page: none, lang: "zh") = {
  let candidates = ()
  for l in languages {
    if flat.ends-with("-" + l) {
      candidates.push((l, flat.slice(0, flat.len() - l.len() - 1)))
    }
  }
  candidates.push((lang, flat))
  let known(table, key) = key in table or table.keys().any(k => _name-of(k) == _name-of(key))
  let hits = ()
  for (lang, rest) in candidates {
    let buckets = term-defaults.at(lang)
    if page != none and page in buckets and known(buckets.at(page), rest) {
      hits.push((lang, page, rest))
    }
    for (bucket, table) in buckets {
      if rest.starts-with(bucket + "-") {
        let key = rest.slice(bucket.len() + 1)
        if known(table, key) and (lang, bucket, key) not in hits {
          hits.push((lang, bucket, key))
        }
      }
    }
  }

  hits
}
#let lookup-key(flat, page: none, lang: "zh") = {
  let hits = _hits(flat, page: page, lang: lang)
  if hits.len() == 1 { hits.first() } else { none }
}

#let _resolve-key(flat, page: none, lang: "zh") = {
  let hits = _hits(flat, page: page, lang: lang)
  if hits.len() == 0 {
    if _settings.lookup-key(flat) != none {
      panic(_settings.not-a-term(flat, page: page))
    }
    let where = if page == none {
      " (document-level overrides need the bucket name, " + "as in \"base-university\" or \"abstract-heading\")"
    } else {
      " (on the " + repr(page) + " page the bucket name may be omitted, " + "as in \"heading\")"
    }
    panic("unknown term key: " + flat + where)
  }
  if hits.len() > 1 {
    panic(
      "ambiguous term key: " + flat + " (reads as "
        + _errors.one-of(hits.map(((l, b, k)) => b + "." + k + " in " + repr(l)))
        + ")",
    )
  }
  hits.first()
}
#let _canonical(key) = {
  let (name, tail) = _split(key)
  if tail.len() == 0 { return key }
  ((name,) + tail.sorted(key: t => t.axis).map(t => t.seg)).join("-")
}

#let expand-overrides(value, page: none, lang: "zh") = {
  if type(value) != dictionary {
    panic("expected dictionary, found " + str(type(value))
      + " (term overrides are one flat dictionary)")
  }
  let out = (:)
  for (flat, text) in value {
    let (lang, bucket, key) = _resolve-key(flat, page: page, lang: lang)
    if page != none and bucket != page {
      panic(
        "term overrides for the " + repr(page) + " page cannot change bucket "
          + repr(bucket),
      )
    }
    let by-page = out.at(lang, default: (:))
    let table = by-page.at(bucket, default: (:))
    table.insert(_canonical(key), text)
    by-page.insert(bucket, table)
    out.insert(lang, by-page)
  }
  out
}
#let terms-overrides(value, lang: "zh") = {
  let expanded = expand-overrides(value, lang: lang)
  terms-state.update(old => {
    let base = if old == none { term-defaults } else { old }
    let merged = base
    for (lang, by-page) in expanded {
      let langs = base.at(lang)
      for (bucket, table) in by-page {
        langs.insert(bucket, langs.at(bucket) + table)
      }
      merged.insert(lang, langs)
    }
    merged
  })
}
#let static-terms(lang, page) = {
  let by-page = term-defaults.at(lang)
  _resolve-from(by-page.base + by-page.at(page), by-page, lang, page)
}
#let term-table(lang, page, overrides: (:)) = {
  if lang not in term-defaults {
    panic(_errors.expected-one-of(languages, lang))
  }
  let v = terms-state.get()
  let by-page = if v == none { term-defaults.at(lang) } else { v.at(lang) }
  let table = by-page.base + by-page.at(page)
  if overrides != (:) {
    let expanded = expand-overrides(overrides, page: page, lang: lang)
    table = table + expanded.at(lang, default: (:)).at(page, default: (:))
  }
  _resolve-from(table, by-page, lang, page)
}
#let term-of(lang, page, key) = {
  let table = term-table(lang, page)
  if key not in table {
    panic(
      "bucket " + repr(page) + " does not contain term " + repr(key)
        + " (language: " + repr(lang) + ")",
    )
  }
  table.at(key)
}
#let term-for(table, name, variant) = {
  let hits = ()
  for candidate in _axes.variant-candidates(variant) {
    let key = ((name,) + candidate.segments).join("-")
    if key in table { hits.push((candidate.specificity, key)) }
  }
  if hits.len() == 0 {
    panic(
      "bucket does not contain term " + repr(name) + " for ("
        + variant.pairs().map(((a, v)) => a + ": " + repr(v)).join(", ") + ")",
    )
  }
  let best = hits.fold(0, (m, h) => calc.max(m, h.first()))
  let top = hits.filter(h => h.first() == best)
  if top.len() > 1 {
// 任取一个同专度键会让结果依赖字典顺序。
    panic(
      "ambiguous term " + repr(name) + ": "
        + top.map(h => repr(h.last())).join(" and ") + " are equally specific",
    )
  }
  table.at(top.first().last())
}
#let has-term(table, name, variant) = _axes.variant-candidates(variant).any(c => (
  ((name,) + c.segments).join("-") in table
))

#let term-apply(table, name, variant, ..slots) = {
  let v = term-for(table, name, variant)
  if type(v) == function { v(..slots) } else { v }
}
#let variant-of(info) = {
  let v = (
    degree-level: info.degree-level, form: info.form, stage: info.stage, category: info.category,
    campus: _axes.campus-for(info.campus, info.degree-level),
  )
  if info.degree-level != "bachelor" {
    let dt = info.at("degree-type", default: auto)
    let dt = if dt == auto { if info.form == "practice" { "professional" } else { "academic" } } else { dt }
    if dt in ("academic", "professional") { v.insert("degree-type", dt) }
  }
  v
}
#let info-variant() = variant-of(info-get())
#let subject-of(table, variant) = if variant.at("degree-level", default: none) == "bachelor" {
  term-for(table, "document-type", variant)
} else {
  term-for(table, "form", variant)
}
