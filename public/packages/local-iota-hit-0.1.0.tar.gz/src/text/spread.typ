// 两字章标题撑开：「摘  要」「绪  论」。
//
// 范例博士版的正文标题、目录、页眉三处都是「摘  要」「目  录」「结  论」「致  谢」
// 「第1章  绪  论」——两个半角空格 ＝ 一个字；指南对摘要题头也写着「两字之间空 2 个
// 半角字符」；节级「4.1 引言」不撑。所以机制只有一条：*章级标题的正文槽恰好两个
// 汉字，中间撑一个字*，长度固定 1em 不收配置；英文名不撑，节以下不撑。先前是词条表里
// 逐条写 title-spread: 1em / 0pt，那张表上撑的正好就是两字的那几条，一条不差，
// 于是换成判据、把表里那三十几行删掉。
//
// 开关两层：iota-hit(title-spread:) 全局（auto / true / false / 按槽的字典，形状与
// title-case 一样：term 学校字样、heading 用户的章标题、rest 兜底），页函数与
// #chapter() 的 spread: auto / true / false 就地压过它。true 只是把机制打开，不是强行
// 撑——「参考文献」写 true 也不动。
//
// *谁印谁撑，记号里存没撑的原文*：正文标题、目录、页眉各撑一次；撑过的内容
// 里夹着 h()，plain 抽出来仍是两个字，再撑一遍就是双份，所以记号不能存撑过的。
#import "./plain.typ": plain, has-cjk

#let title-spread-state = state("iota-hit-title-spread", auto)

#let slots = ("term", "heading")

#let _tri(v) = v in (auto, true, false)

#let check-title-spread(v) = {
  if _tri(v) { return }
  if type(v) != dictionary {
    panic("title-spread: expected auto, true, false, or a dictionary with keys "
      + (slots + ("rest",)).map(repr).join(", ") + "; found " + repr(v))
  }
  for (k, m) in v {
    if k not in slots + ("rest",) {
      panic("title-spread: unknown key " + repr(k) + "; expected one of " + (slots + ("rest",)).map(repr).join(", "))
    }
    if not _tri(m) { panic("title-spread." + k + ": expected auto, true, or false, found " + repr(m)) }
  }
}

// 某一槽开不开。auto ＝ 开
#let mode-for(v, slot) = {
  let m = if type(v) == dictionary { v.at(slot, default: v.at("rest", default: auto)) } else { v }
  m != false
}

// 把字拉开。*只有纯文字才拆得开*：用户写 #toc(title: [目 #emph[录]]) 这种富文本，
// 拆成字形再插空当会把里面的样式打散，拆不开就原样排——字没拉开是版式上的小事，
// 编不过是大事
#let spread-heading(body, gap) = {
  let s = if type(body) == str { body } else { plain(body) }
  if s == none { return body }
  let cs = s.clusters()
  if cs.len() <= 1 or (type(body) != str and body != [#s]) { return body }
  cs.intersperse(h(gap)).join()
}

// 恰好两个汉字
#let two-han(c) = {
  let s = if type(c) == str { c } else { plain(c) }
  if s == none { return false }
  let cs = s.trim().clusters()
  cs.len() == 2 and cs.all(has-cjk)
}

// 一条章级标题按开关撑开。*要在 context 里调*（读开关）。slot 见 slots；
// local 是页函数或 #chapter 就地给的 spread（auto 跟全局）
#let spread-title(c, slot: "heading", local: auto) = {
  if c == none { return none }
  let on = if local != auto { local } else { mode-for(title-spread-state.get(), slot) }
  if not on or not two-han(c) { return c }
  spread-heading(c, 1em)
}
