// 上下标按 Word 排：字号住在半磅格上，汉字与西文各一档。
//
// *数是自己造 docx 让 Word 导出量的*（七种字体 × 9–48pt，mutool trace 逐字形读
// 字号与基线；混排 run 西文 Times、中文宋体，即论文正文的真实情形）。Word 的规矩
// 按*字形所在的字体*走，不按 run 的主字体：
//
//   西文（Times、Arial）  字号 0.65 × 正文，*取到半磅*：五号 7.0、小四 8.0、四号
//                        9.0、小三 10.0、三号 10.5；抬升 ＝ 正文字号 − 上标字号
//                        （3.5 / 4.0 / 5.0 / 5.0 / 5.5），也就是上标的字身顶与正文
//                        字身顶齐。Typst 默认走字体 OS/2 表，Times 抬 0.453em，
//                        比 Word 高 1.2pt（12pt 上）
//   汉字（中易宋体、黑体） 字号 0.5 × 正文、抬 0.5 × 正文，也取半磅——正是这两副
//                        字体 OS/2 表里的数（ySuperscriptYSize / YOffset 都是 0.5）；
//                        小四的「二」6pt 抬 6pt。先前一律按 Times 那档 0.65 / 0.35
//                        排，汉字大了三成、低了 1.8pt
//   ①②③ 这类           Word 回落到 Cambria Math，按西文那档；它们不在 cjk-scripts
//                        里，这里也自然走西文那档
//   下标                 字号同上标。下沉：汉字 round(0.0625 × 正文) 到半磅（宋体
//                        OS/2 的 ySubscriptYOffset）；西文 Word 自己都不单调（9pt
//                        0.5、10.5pt 1.0、12pt 0.5、16pt 1.0），维持 0.08em，差不到
//                        半磅
//
// *0.65 与 0.5 不是本包挑的，是 OS/2 表里的 ySuperscriptYSize*。Word 逐字体读它，
// 我们只认两副：西文那档与中易那档；用户换别的字体（Cambria 抬 0.25、Consolas
// 抬 0.44）不逐副跟，那是字体的事不是版式的事。
//
// *不重造 super / sub 元素。* 用户写的 #super[2] 原样留着（编辑器点击跳转靠它的
// span），元素自己的 size / baseline 收成 1em / 0pt 不动字，字号与抬升由外面裹的
// text() 给——show 规则里 set super(size:) 改不到已经解好的那一个元素，实测无效。
// 汉字那档在裹的那一层里再发一条只管 cjk-scripts 的 show regex，只罩上下标的正文，
// 不碰外面（show regex 每切一处丢一份字距，正文里不能随便发，见 src/fonts/resolve.typ）。
//
// *抬沉用 text(baseline:) 给，还有一层用意*：Typst 画下划线不理会 text.baseline，线仍按
// 行的基线画，所以上下标的线天然留在正文线上——正是 Word 的画法，src/text/underline.typ
// 因此不必再拆段补偿。
#import "../fonts/resolve.typ": cjk-scripts

// Word 的字号都住在半磅格上
#let _half(x) = calc.round(x / 0.5pt) * 0.5pt

// 西文那档：字号与抬升／下沉，按正文字号 s 算
#let latin-size(s) = _half(0.65 * s)
#let super-raise(s) = s - latin-size(s)
#let sub-sink(s) = 0.08 * s

// 汉字那档
#let cjk-size(s) = _half(0.5 * s)
#let cjk-super-raise(s) = cjk-size(s)
#let cjk-sub-sink(s) = _half(0.0625 * s)

// 裹一层：西文按 shift(s) 抬／沉，汉字按 cjk-shift(s)。baseline 正值往下
#let _scripted(it, shift, cjk-shift) = context {
  let s = text.size
  show cjk-scripts: c => {
    set text(size: cjk-size(s), baseline: cjk-shift(s))
    c
  }
  text(size: latin-size(s), baseline: shift(s), it)
}

#let super-sub-rules(doc) = {
  // 元素自己不缩不抬，typographic 关掉——字体里的上标字形（OS/2 那套）位置是 Typst
  // 的，不是 Word 的
  set super(typographic: false, size: 1em, baseline: 0pt)
  set sub(typographic: false, size: 1em, baseline: 0pt)
  show super: it => _scripted(it, s => -super-raise(s), s => -cjk-super-raise(s))
  show sub: it => _scripted(it, sub-sink, cjk-sub-sink)
  doc
}
