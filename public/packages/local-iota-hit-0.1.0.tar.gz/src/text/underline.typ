// 下划线按 Word 画。
//
// *三件事，都是自己造 docx 在 Word 上量的*（中易宋体 + Times New Roman，24 / 48pt，
// 见 src/fonts/presets.typ 的 underline-offset）：
//
//   一 一个 run 一条线：「汉字 Latin 汉字」整段是一条通线，不按字体分段、中间没有缝。
//     Typst 是按 shaping run 各画各的，run 边界上那个字形丢掉的字距（0.4543）没线，
//     每条线两头各延 tracking/2 把缝填上。
//   二 上标的线*不跟上标走*：留在正文那条线上，粗细也是正文的（24pt 上上标段线心
//     +3.24、粗 1.20，与两旁正文相同）。
//   三 下标的线也留在正文那条线上。自己量的 macOS Word 里汉字下标是这样（24pt 上
//     线心 +3.48，与两旁正文相同）；西文下标那段量到低 0.03em、细一档（+3.96、粗
//     0.72），按用户在 Word 里看到的「上下标的线与正文一样高」，两种都归正文线，
//     不给西文下标另立一档。
//
// *二、三不必特意做*：上下标的抬与沉是 src/text/super-sub.typ 用 text(baseline:)
// 给的，而 Typst 画下划线不理会 text.baseline——线仍按行的基线画（实测 text(baseline:
// -4pt) 里的字抬了 4，线一点没动），offset 与 stroke 的 em 也按 underline 元素处的字号
// 解，上标那段的线因此天然与两旁同高同粗。先前上下标的抬沉写在 super / sub 元素自己的
// baseline 上，那一路线是跟着字形基线走的，得把整段按 super / sub 拆开、逐段在 offset
// 里把抬起的量补回去，还拆不到套在 strong 里面的那一层；现在一条线到底，套几层都行。
//
// *不递归*：只接用户写的 underline（evade 还是默认的 true），自己发出去的一律
// evade: false——Word 的线不绕开撇捺，正好也拿它当记号。
//
// 字距补偿（src/text/tracking.typ 的 tracking-pad）在整段外面发一次。
#import "../fonts/presets.typ": underline-offset, underline-stroke
#import "./tracking.typ": tracking-pad
#import "../fonts/resolve.typ": boundary-loss

#let _line(body, offset: underline-offset, stroke: underline-stroke) = context underline(
  offset: offset, stroke: stroke, evade: false, extent: text.tracking / 2 * boundary-loss(), body,
)

#let underline-rules(doc) = {
  show underline.where(evade: true): it => tracking-pad(_line(it.body), probe: it.body)
  doc
}
