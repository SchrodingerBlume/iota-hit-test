#import "../lib.typ": *
#show: iota-hit.with(
  degree-level: "doctor",
  fontset: presets.windows,
  // form: "design",
  // degree-type: "professional",
  title: [局部多孔质气体静压轴承关键技术的研究#en[RESEARCH ON KEY TECHNOLOGIES OF
    PARTIAL POROUS EXTERNALLY PRESSURIZED GAS BEARING]],
  author: [□□□],
  date: "2026-06",
  // category: "hass",
)

#show: frontmatter

#cover(
  title-en-xiaoer: true,
  annotated: true,
)

#titlepage(
  title-en-xiaoer: true,
  annotated: true,
)

#abstract(keywords: ([气体静压轴承#en[porous graphite]], [局部多孔质#en[$dots$]], [动态特性#en[Stability]], [数值仿真#en[Numerical simulation]]))[
  #idx[气体静压轴承]由于具有运动精度高、摩擦损耗小、发热变形小、寿命长、无污染等特点，在航空航天工业、半导体工业、纺织工业和测量仪器中得到广泛应用。本文在分析国内外气体静压轴承的基础上，以改善气体静压轴承的静态特性和稳定性为目的，通过理论分析、仿真计算和实验研究对局部多孔质气体静压止推轴承进行了研究，同时分析轴承的结构参数和工作参数对局部多孔质气体静压止推轴承工作特性的影响，为局部多孔质气体静压轴承的设计和工程应用奠定理论基础。

  建立基于分形几何理论的#idx[多孔质石墨]渗透率与分形维数之间关系的数学模型，该模型可预测多孔质石墨的渗透率，并可直观描述孔隙的大小对渗透率的影响。

  本文在理论分析的基础上，建立局部多孔质气体静压止推轴承静态特性的数学模型，在此基础上，通过工程方法和 @FEM 对所建立的模型进行求解。在采用 @FEM 时，首先通过加权余量法，将二阶偏微分方程降为一阶，从而，降低了对插值函数连续度的要求，同时，方便采用有限元方法进行求解。
  #en[
  Externally pressurized gas bearing has been widely used in the field of aviation, semiconductor, weave, and measurement apparatus because of its advantage of high accuracy, little friction, low heat distortion, long life-span, and no pollution. In this thesis, based on the domestic and overseas researching development about externally pressurized gas bearing, the author investigated the partial porous externally pressurized gas thrust bearing by theoretical analysis, computer simulation, and experiments to improve its static charaterictics and stability. The effects of structure and operating parameters on partial porous externally pressurized gas bearing has been studied. Therefore, a theoretical foundation for the designing and application for the partial porous externally pressurized gas bearing has been presented.

  Based on the fractal theory, a model was established to demonstrate the relationship between the porous graphite permeability and the fractal dimension. It can predict the permeability of porous graphite and show the effects of the pore size on the permeability.

  In this thesis, the author established a model about the static characteristics of partial porous externally pressurized gas thrust bearing, and it was analyzed by engineering solution and @FEM. While using @FEM, the second-order partial differential equation was reduced to one-order by adopting Galerkin weighted residual method, for decreasing the continuity degree requirement of the interpolation function and facilitating to the calculation.
  ]
]

#nomenclature(
  abbreviations: (FEM: (long: "有限元方法", long-en: "Finite Element Method")),
)[
  / $p$:   气膜压力，Pa
  / $h$:   气膜厚度，m
  / $eta$: 气体动力黏度，Pa$dot$s
]

#table-of-contents()

#show: mainmatter

= 绪#ccwd()论#en[Introduction]

== 课题背景及研究的目的和意义#en[Background, objective and significance of the subject]

发展国防工业、微电子工业等尖端技术需要精密和超精密的仪器设备，精密仪器设备要求高速、……

……

== 气体润滑轴承及其相关理论的发展概况#en[Developmental of gas-lubricated bearing and correlated theories]

气体轴承是利用气膜支撑负荷或减少摩擦的机械构件。……

……

=== 气体润滑轴承的发展#en[Developmental of gas-lubricated bearing]

1828年，R.R.Willis@willis1828 发表了一篇关于小孔节流平板中压力分布的文章，这是有记载的研究气体润滑的最早文献；近年的综述见@zhang2020@wang2019。……

根据间隙内气膜压力的产生原理，气体轴承可以分为四种基本形式：

（1）*气体静压轴承*#ccwd()加压气体经过节流器进入间隙，在间隙内产生压力气膜使物体浮起的气体轴承，……

=== 气体润滑轴承的分类#en[Classification of gas-lubricated bearing]

根据间隙内气膜压力的产生原理，气体轴承可以分为四种基本形式，其结构如@fig:1-1 所示。

（1）*气体静压轴承*#ccwd()加压气体经过节流器进入间隙，在间隙内产生压力气膜使物体浮起的气体轴承，结构如@fig:1-1a 所示。……

……

#figure(
  subs(
    image("images/气体静压轴承.png", width: 6.92cm),
    image("images/气体动压轴承.png", width: 6.65cm),
    image("images/气体动静压轴承.png", width: 6.72cm),
    image("images/气体压膜轴承.png", width: 7.71cm),
    columns: 2,
  ),
  caption: [气体润滑轴承的分类#subs([气体静压轴承<fig:1-1a>], [气体动压轴承], [气体动静压轴承], [气体压膜轴承],)],
) <fig:1-1>

（也可以按照下图范例书写）

#figure(
  subs(
    image("images/气体静压轴承.png", width: 6.87cm),
    image("images/气体动压轴承.png", width: 6.03cm),
    captions: ([气体静压轴承 <fig:1-2a>], [气体动压轴承 <fig:1-2b>]),
  ),
  caption: [气体润滑轴承的分类]
) <fig:1-2>

#pagebreak()

#figure(
  subs(
    image("images/气体动静压轴承.png", width: 6.70cm),
    image("images/气体压膜轴承.png", width: 7.17cm),
    captions: ([气体动静压轴承 <fig:1-2c>], [气体压膜轴承 <fig:1-2d>]),
  ),
  caption: [#continued()]
)

=== 多孔质气体静压轴承的研究#en[Research on porous externally pressurized gas bearing]

由于气体的压力低和可压缩性，……。

==== 多孔质静压轴承的分类#en[Classification of porous thrust bearing]

轴承工作面的整体或……。

==== 多孔质材料特性的研究#en[Research on characteristics of porous materials]

材料的主要特点是具有一定的……。

#[
  + #heiti[孔隙特性]#ccwd()多孔质材料是由……。
]

#ccwd(-2)……

== 本文的主要研究内容#en[Main research content of this subject]

本课题的研究内容主要是针对局部多孔质止推轴承的多孔质材料的渗透
率、静压轴承的静态特性、稳定性及其影响因素进行展开，……。

= 基于FLUENT软件的轴承静态特性研究#en[Research on static characteristics of bearing based on FLUENT 
software]

== 引言#en[Introduction]

利用现成的商用软件@iota-hit 来研究流场，可以免去对 N-S 方程求解程序的……

=== 边界条件的设定#en[Initialization of boundary conditions]

本文采用……，则每一个方向上的……由公@eq:2-1、@eq:2-2 求得：

$ phi.alt = D_"p"^2/150 psi^3/(1 - psi)^2 $<eq:2-1>
#v(.2em)
$ C_2 = 3.5/D_"p" (1 - psi)/psi^3 $<eq:2-2>

#eqdenote[
  / $D_"p"$: 多孔质材料的平均粒子直径（m）；
  / $psi$: 孔隙度（孔隙体积占总体积的百分比）；
  / $C_2$: 特征渗透性或固有渗透性（m#super[2]）。
]

……

== 本章小结#en[Brief summary]

……

= 局部多孔质静压轴承的试验研究#en[Experiment on partial porous thrust bearing]

== 引言#en[Introduction]

在前面几章中，分别对局部多孔质材料的渗透率……

== 多孔质石墨渗透率测试试验#en[Experiments on permeability of porous graphite]

……

1号试样的试验数据见@tab:3-1。

#figure(
  caption: [1号试样渗透率测试数据(温度：$T$=16 ℃  高度：$H$=5.31 mm)#en[Data of measured permeability of sample 1\ (Temperature:~$T$=16 ℃#ccwd()Height:~$H$=5.31 mm)]],
  table(
    columns: (1fr, 1fr, 1fr, 1fr, 1fr, 1fr,),
    align: center + horizon,
    table.header(
      [供气压力\ $P_"s"$~(MPa)],
      [流量测量\ $M'$~(m#super[3]/h)],
      [流量修正值 $M$~(m#super[3]/s)\ $×$10#super[-4]],
      [压力差\ $upright(Delta) P$ (Pa)],
      [$lg Delta P$],
      [$lg M$],
    ),
    [0.15], [0.009], [0.023 12], [46 900],  [4.671 17], [-5.636 01],
    [0.2],  [0.021], [0.045 84], [96 900],  [4.986 32], [-5.338 76],
    [0.25], [0.039], [0.074 13], [146 900], [5.167 02], [-5.130 01],
    [0.3],  [0.097], [0.167 47], [196 900], [5.294 24], [-4.776 06],
    [0.35], [0.136], [0.217 53], [246 900], [5.392 52], [-4.662 48],
    [0.4],  [0.171], [0.254 85], [296 900], [5.472 61], [-4.593 72],
    [0.45], [0.202], [0.284 67], [346 900], [5.540 20], [—],
  ),
)<tab:3-1>

#pagebreak()
#enter(2)

……如果表格超过一页时，可采用续表的形式移入下一页：

#figure(
  caption: [试样渗透率测试数据#en[Data of measured permeability of sample 1]],
  table(
    columns: (1fr, 1fr, 1fr, 1fr, 1fr, 1fr,),
    align: center + horizon,
    table.header(
      [供气压力\ $P_"s"$~(MPa)],
      [流量测量\ $M'$~(m#super[3]/h)],
      [流量修正值 $M$~(m#super[3]/s)\ $×$10#super[-4]],
      [压力差\ $increment P$ (Pa)],
      [$lg increment P$],
      [$lg M$],
    ),
    [0.15], [0.009], [0.023 12], [46 900],  [4.671 17], [-5.636 01],
    [0.2],  [0.021], [0.045 84], [96 900],  [4.986 32], [-5.338 76],
    [0.25], [0.039], [0.074 13], [146 900], [5.167 02], [-5.130 01],
    [0.15], [0.009], [0.023 12], [46 900],  [4.671 17], [-5.636 01],
    [0.2],  [0.021], [0.045 84], [96 900],  [4.986 32], [-5.338 76],
    [0.25], [0.039], [0.074 13], [146 900], [5.167 02], [-5.130 01],
    [0.15], [0.009], [0.023 12], [46 900],  [4.671 17], [-5.636 01],
    [0.2],  [0.021], [0.045 84], [96 900],  [4.986 32], [-5.338 76],
    [0.25], [0.039], [0.074 13], [146 900], [5.167 02], [-5.130 01],
    [0.15], [0.009], [0.023 12], [46 900],  [4.671 17], [-5.636 01],
    [0.2],  [0.021], [0.045 84], [96 900],  [4.986 32], [-5.338 76],
    [0.25], [0.039], [0.074 13], [146 900], [5.167 02], [-5.130 01],
    [0.15], [0.009], [0.023 12], [46 900],  [4.671 17], [-5.636 01],
    [0.2],  [0.021], [0.045 84], [96 900],  [4.986 32], [-5.338 76],
    [0.25], [0.039], [0.074 13], [146 900], [5.167 02], [-5.130 01],
    [0.15], [0.009], [0.023 12], [46 900],  [4.671 17], [-5.636 01],
    [0.2],  [0.021], [0.045 84], [96 900],  [4.986 32], [-5.338 76],
    [0.25], [0.039], [0.074 13], [146 900], [5.167 02], [-5.130 01],
    [$dots.v$],  [], [], [], [], [],
    [0.3],  [0.097], [0.167 47], [196 900], [5.294 24], [-4.776 06],
  ),
)<tab:3-2>

#pagebreak()

#figure(
  caption: [#continued()],
  table(
    columns: (1fr, 1fr, 1fr, 1fr, 1fr, 1fr,),
    align: center + horizon,
    table.header(
      [供气压力\ $P_"s"$~(MPa)],
      [流量测量\ $M'$~(m#super[3]/h)],
      [流量修正值 $M$~(m#super[3]/s)\ $×$10#super[-4]],
      [压力差\ $increment P$ (Pa)],
      [$lg increment P$],
      [$lg M$],
    ),
    [0.35], [0.136], [0.217 53], [246 900], [5.392 52], [-4.662 48],
    [0.4],  [0.171], [0.254 85], [296 900], [5.472 61], [-4.593 72],
    [0.45], [0.202], [0.284 67], [346 900], [5.540 20], [—],
  ),
)<tab:3-2-2>

== 本章小结#en[Brief summary]

……

#conclusion[
  本文对局部多孔质气体静压止推轴承的静态特性和稳定性进行了理论研究，对于局部多孔质气体静压径向轴承、圆锥轴承和球轴承仅需对止推轴承压力分布的数学模型进行适当的坐标变换即可对其特性进行求解。同时，本文对局部多孔质气体静压止推轴承进行了实验研究并与整体多孔质和小孔节流止推轴承的静态特性和稳定性进行了实验对比。

  本论文的主要创造性工作归纳如下：

  \1. 建立了基于分形几何理论的多孔质石墨渗透率与分形维数之间关系的数学模型，该模型可预测多孔质石墨的渗透率，并可直观描述各种孔隙的大小对渗透率的影响。通过实验验证了该模型的正确性。

  \2. 分别建立了基于气体连续性方程、Navier-Stokes 方程、Darcy 定律以及气体状态方程的局部多孔质气体静压轴承的承载能力、静态刚度和质量流量的数学模型，利用有限元法进行求解，给出了局部多孔质气体静压轴承的承载能力、静态刚度和质量流量特性曲线。

  ……

  今后还应在以下几个方面继续深入研究：

  \1. 本文仅是采用了局部多孔质圆柱塞这种节流方式，在以后的研究中，可以通过改变局部多孔质材料的形状来改变节流方式，从而通过性能对比，获得最优的节流效果。

  ……
]

#bibliography(read("refs.bib"), full: true)

#show: appendix

= 补充数据#en[Supplementary data]

正文里放不下的原始数据表放在这里。

#figure(
  table(
    columns: 3,
    table.header([试样], [孔隙率], [渗透率]),
    [1号], [0.35], [1.2],
    [2号], [0.41], [1.8],
  ),
  caption: [试样的孔隙率与渗透率#en[Porosity and permeability of samples]],
) <tab:a1>

附录里的表照样按章编号，见@tab:a1。

== 测量不确定度#en[Measurement uncertainty]

$ u_c = sqrt(sum_(i=1)^n c_i^2 u_i^2) $ <eq:a1>

公式编号也跟着换轴，见@eq:a1。

= 自编程序#en[Source code]

```python
def permeability(dp, q, mu, L, A):
    return q * mu * L / (A * dp)
```

#achievements(read("achievements.bib"))

#defense(
  reviewers: (
    (name: [×××], title: [教授（博导）], affiliation: [哈尔滨工业大学], discipline: [机械工程]),
    (name: [×××], title: [研究员], affiliation: [×××研究所], discipline: [机械工程]),
  ),
  chair: (name: [×××], title: [教授（博导）], affiliation: [哈尔滨工业大学], discipline: [机械工程]),
  members: (
    (name: [×××], title: [教授（博导）], affiliation: [哈尔滨工业大学], discipline: [机械工程]),
    (name: [×××], title: [教授], affiliation: [×××大学], discipline: [机械工程]),
  ),
  secretary: (name: [×××], title: [讲师], affiliation: [哈尔滨工业大学], discipline: [机械工程]),
  resolution: [
    答辩委员会听取了论文作者的报告，审阅了论文，经质询与讨论，认为……

    答辩委员会经过讨论，一致同意通过答辩，建议授予工学博士学位。
  ],
)

#declarations(
  title: []
)

#index()

#acknowledgement[
  衷心感谢导师×××教授对本人的精心指导。他的言传身教将使我终身受益。

  感谢×××教授，以及实验室全体老师和同窗们的热情帮助和支持！

  ……

  ……

  ……

  ……

  ……

  ……

  ……

  #enter()
  
  本课题承蒙××××基金资助，特此致谢。
  
  ……
]

#resume[
  ××××年××月××日出生于××××。

  ××××年××月考入××大学××院（系）××专业，××××年××月本科毕业并获得××学学士学位。

  ××××年××月——××××年××月，在××大学××院（系）××学科学习并获得××学硕士学位。

  ××××年××月——××××年××月，在××大学××院（系）××学科攻读博士学位。

  获奖情况：如获三好学生、优秀团干部、×奖学金等（不含科研学术获奖）。

  工作经历：
  
  // 范例在此留两行，并改用 1.35 倍行距。
  #enter(2, line-spacing: 1.35)

  // Typst 不压缩段首开括号，额外退入 0.25 字以补偿。
  *#ccwd(-2.25)（个人简历一般应包含从本科起的教育经历和工作经历）*
]
