#import "../lib.typ": *
// 博士后研究工作报告：照《出站报告封皮模板》与《博士后研究工作报告模板》的原文排
#show: iota-hit.with(
  degree-level: "postdoc",
  fontset: presets.windows,
  // 封皮的题名排两行：写了 \ 就在那儿断；英文题名排在内封，大写
  title: [标题 \ 标题#en[ENGLISH TITLE \ ENGLISH TITLE \ ENGLISH TITLE]],
  author: [无名氏],
  supervisor: [XXXXX教授],
  station: [],              // 流动站名称
  speciality: [],           // 专业名称
  classified-index: [],     // 分类号
  secrecy: [],              // 密级
  udc: [],
  report-number: [],        // 编号
  research-start-date: "2024-07-01",
  research-end-date: "2026-06-30",
  // 工作完成日期不写：取研究工作起止的年月；要别的字就写 work-finish-date: [...]
  report-submit-date: "2026-06",
  date: "2026-06",
)

#show: frontmatter

#cover()

#titlepage()

#abstract(keywords: ([模板#en[template]], [博士后研究报告#en[postdoctoral research report]]))[
  本模板是基于哈尔滨工业大学硕士研究生毕业论文模版\_Sunner版\_1.45修改而成。

  特别说明之处包括：

  + 章、节、小节等都已经定义，可以从“样式和格式”中直接选择，并且能够自动编号；
  + 图和表上下各留一个五号字的空行；
  + 表采用三线表，表格自动套用格式中有一个样式“nl论文”，可以采用，但不是很成熟，需要手动加入首行的下边框；
  + 参考文献建议写全所有作者。

  撰写时选中“常用”工具条中的“显示隐藏/隐藏编辑标志”。这样看到隐藏的一些分节符，建议不要删除或改动这些分节符。
  #en[
    This template is adapted from the master's thesis template of Harbin Institute of Technology.
  ]
]

#list-of-symbols[
  / $x$: 点点滴滴，m
  / $t$: 时间坐标，s
]

#table-of-contents()

#show: mainmatter

= 绪论#en[Introduction]

== 课题研究的背景和意义#en[Background and significance of the subject]

=== XXXXX#en[XXXXX]

章、节、小节等都已经定义，可以从“样式和格式”中直接选择，并且能够自动编号。

图和表上下各留一个五号字的空行。

#figure(
  image("images/气体静压轴承.png", width: 12.19cm),
  caption: [气体静压轴承#en[Externally pressurized gas bearing]],
) <fig:1-1>

表采用三线表，表格自动套用格式中有一个样式“nl论文”，可以采用，但不是很成熟，需要手动加入首行的下边框。

#figure(
  table(
    columns: 4,
    table.header([试样], [孔隙率], [渗透率], [备注]),
    [1号], [0.35], [1.2], [—],
    [2号], [0.41], [1.8], [—],
  ),
  caption: [试样的孔隙率与渗透率#en[Porosity and permeability of samples]],
) <tab:1-1>

== 国内外在该方向的研究现状及分析#en[Research status at home and abroad]

……

== 本文的主要工作#en[Main work of this report]

……

= XXXXX#en[XXXXX]

$ x = x_0 + v t $ <eq:2-1>

#eqdenote[
  / $x$: 点点滴滴(m)；
  / $t$: 时间坐标(s)。
]

== 本章小结#en[Brief summary]

……

= XXXXX#en[XXXXX]

== 本章小结#en[Brief summary]

……

= XXXXX#en[XXXXX]

== 本章小结#en[Brief summary]

……

#conclusions[
  ……
]

// 参考文献建议写全所有作者
#bibliography(read("refs.bib"), full: true)

#acknowledgements[
  ……
]

// 两章成果：博士生期间照博士学位论文的分组，博士后期间照模板的六组
#achievements(read("achievements.bib"), period: "doctoral")
#achievements(read("postdoc-achievements.bib"))

// 模板这一页给的是一张两列无框表：左边起止年月，右边经历；字跟正文一样是小四
#resume[
  #show: new-styles.with((figure: (table: (size: zihao.xiaosi))))
  #table(
    columns: (auto, 1fr),
    stroke: none,
    align: left,
    [××××年××月——××××年××月], [在××大学××院（系）××专业学习，获××学学士学位],
    [××××年××月——××××年××月], [在××大学××院（系）××学科学习，获××学硕士学位],
    [××××年××月——××××年××月], [在××大学××院（系）××学科学习，获××学博士学位],
    [××××年××月至今], [在哈尔滨工业大学××博士后科研流动站从事博士后研究工作],
    [获奖情况], [……],
    [工作经历], [……],
  )
]

#permanent-address(address: [], email: [], phone: [])
