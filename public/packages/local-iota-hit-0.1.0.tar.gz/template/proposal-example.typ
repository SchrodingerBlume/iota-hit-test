#import "../lib.typ": *

#show: iota-hit.with(
  fontset: presets.webapp,
  degree-level: "bachelor",
  stage: "mid-term",
  form: "practice",
  // degree-type: "professional",
  campus: "shenzhen",
  title: [论文题目\ （题目长可分两行写）],
  author: [□□□],
  student-id: [1160300000],
  supervisor: [某某某（副）教授],
  speciality: [机械制造及其自动化],
  affiliation: [机电工程学院],
  date: "2026-06",
  // lang: "en",
)

#cover()

#table-of-contents()

#show: mainmatter

= 课题来源及研究目的和意义

== 课题的来源或研究背景

=== 呜呜呜

==== 呜呜呜呜

本课题来源于□□□。

== 课题研究目的和意义

（不少于 500 字。）#lorem(30)

= 国内外研究现状及分析

== 国外研究现状

#lorem(20)

== 国内研究现状

注意对所引用文献的准确标注@zhang2020。

== 国内外文献综述的简析

（不少于 500 字；综合评述：国内外研究取得的成果，存在的不足或有待深入研究的问题。）

= 主要内容及方案

（不少于 1500 字。撰写宜使用将来时态，切忌将论文目录直接作为主要内容。）

图表照终稿那一套写，编号跟着节走：

#figure(
  table(
    columns: 3,
    table.header([供气压力], [流量测量], [压力差]),
    [0.15], [0.009], [46 900],
    [0.20], [0.021], [96 900],
  ),
  caption: [渗透率测试数据],
)

= 预期达到的目标

#lorem(15)

= 已完成的学术研究/实践工作

（根据课题情况选择；详细撰写目前已进行的学术研究或者实践工作的内容和完成情况。）

= 进度安排

（建议从进入课题时间开始。）

= 为完成课题所需的条件

= 研究过程中可能遇到的问题以及解决的措施

#bibliography(read("refs.bib"), full: true)
