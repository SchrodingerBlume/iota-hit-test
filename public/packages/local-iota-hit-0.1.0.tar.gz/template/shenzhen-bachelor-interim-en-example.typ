#import "../lib.typ": *
#show: iota-hit.with(
  degree-level: "bachelor",
  stage: "interim",
  form:        "design",
  campus:      "shenzhen",
  lang: "en",
  title:       [],
  author:      [],
  student-id:  [],
  affiliation: [School of \*\*\*\*\*\*\*\*\*, Shenzhen],
  speciality:  [],
  supervisor:  [],
  date:        [],
)

#show: frontmatter
#cover()
#table-of-contents()

#show: mainmatter

= Main Research Contents and Research Progress
== Main Research Contents

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

== Research Progress Overview

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

= Completed Research Work and Corresponding Results

== Design of XXXXXX

=== Parameter Design of XXXX

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

#figure(
  caption: [Performance of various secure scan designs],
  table(
    columns: (2cm, 2.3cm, 1.62cm, 4.6cm, 4.59cm),
    // 原件的 trHeight 是最小值；实测行高才能复现表格基线。
    rows: (20.88pt,) + (20.32pt,) * 3,
    align: center + horizon,
    table.header[Design][\u{2206}A(%)][Security][Testability][Other],
    [BK],      [Low],    [High], [Normal], [Limited applying scenarios],
    [BSO-128], [Normal], [High], [Normal], [128 clocks before testing],
    [ROS],     [Low],    [Low],  [Normal], [More clocks before testing],
  ),
)

#enter()

=== XXXXXXXXXXXXXXX

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

#figure(
  image("images/Identify-the-length-of-scan-chain-in-ROS-design.png", width: 13.45cm), // 原件 381.25pt
  caption: [Identify the length of scan chain in ROS design],
) <fig:2-1>

#pagebreak()
This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

$ italic("major") = italic("minor") + b_3/2 + display(abs(b_3/2 - italic("minor")))/2 $

$ italic("height") = italic("minor") + sqrt((italic("major"))^2 - (b_3/2)^2) $

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

= Planned Subsequent Research Work and Schedule Arrangement

== Planned Subsequent Research Work

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

== Schedule Arrangement

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

= Existing or Expected Difficulties and Problems

== Existing or Expected Difficulties and Problems

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

#enter()

== Solutions

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...

= Possibility of Completing the Thesis on Time

This is a format sample for the main text only and has no relation to the report; please delete it.........

..\..\...
