#import "../lib.typ": *
#show: iota-hit.with(
  // 以下是设定类
  degree-level: "bachelor",
  stage: "proposal",

  // 毕业论文写 "dissertation"（默认，注释掉此项即可），毕业设计写 "practice"（design 是它的别名）
  form:        "design",

  campus:      "shenzhen",

  lang: "en",

  title:       [], // Title
  author:      [], // Name
  student-id:  [], // Student ID
  affiliation:   [School of \*\*\*\*\*\*\*\*\*, Shenzhen], // School
  speciality:  [], // Major
  supervisor:  [], // Supervisor
  date:        [], // Date
)

// 前置部分；罗马数字计数
#show: frontmatter
#cover()             // 生成封面
#table-of-contents() // 生成目录

// 正文部分；阿拉伯数字计数
#show: mainmatter

= Background, Purposes and Significance of the Topic

== Background

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

== Purposes and Significance

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

= Research Status and Analysis at Home and Abroad

== Research Status at Home and Abroad

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

== Literature Review and Analysis

=== Research Status of XXX

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

=== Research Status of YYY

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

= Main Research Contents and Research Scheme

== Research contents

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

=== XXXXXX

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

#enter()

== Research Scheme

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

= Schedule of Research Progress and Expected Objectives

== Schedule of Research Progress

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

#enter()

== Expected Objectives

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

= Existing and Required Conditions and Funding

== Laboratory Conditions and Funding Support

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

== Required Conditions and Funding

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

= Anticipated Problems and Solutions

== Anticipated Problems and Technical Challenges

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

== Solutions

This is a format sample for the main text only and has no relation to the report; please delete it.........

\..\..\...

#bibliography(
  read("shenzhen-bachelor-interim-example.bib"),
  full: true
)