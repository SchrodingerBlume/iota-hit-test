#import "../lib.typ": *

#show: iota-hit.with(
  campus: "shenzhen",
  degree-level: "doctor",
  stage: "interim",
  title: [复杂航天器动力学建模与姿态轨道控制方法研究],
  author: [张三],
  student-id: [23B000001],
  supervisor: [李四],
  specialty: [机械],
  // 原件封面用紧凑年月和 ISO 字面；内容块按所写文字原样显示。
  date: (period: [202303], interim: [2025-04-14]),
)

#cover()
#instructions()
#show: mainmatter

= 论文工作是否按开题报告预定的内容及进度安排进行
论文工作按开题报告预定的研究内容及进度安排进行。目前已完成动力学建模及基础控制方法的研究。

= 目前已完成的研究工作及结果
== 动力学模型与控制方法
已完成系统建模、稳定性分析和数值仿真。研究结果表明，所设计的方法能够实现预定的控制目标。

= 后期拟完成的研究工作及进度安排
+ 进一步研究多种约束条件下的控制方法，并完善理论分析。
+ 开展对比实验，整理研究结果，撰写学位论文。

= 存在的困难与问题
模型参数不确定性增加了控制设计的难度，拟通过鲁棒控制方法及进一步实验解决。

= 如期完成全部论文工作的可能性
已完成的研究工作为后续研究提供了基础，现有条件和时间能够支持按期完成学位论文。

#defense(
  supervisor: (
    opinion: [该生已完成培养计划要求，研究工作进展正常，已取得阶段性成果。同意参加中期检查。],
    completion: "on-time",
    date: [2025年04月11日],
    // signature: [#image("signatures/supervisor.png", height: 8mm)],
  ),
  resolution: [研究工作进展正常。建议进一步完善模型参数不确定性分析，并补充实验验证。],
  result: "pass",
  chair: (name: [王五], title: [教授/博导], discipline: [力学], date: [2025年04月14日]),
  members: (
    (name: [李四], title: [教授/博导], discipline: [力学]),
    (name: [赵六], title: [教授/博导], discipline: [机械]),
    (name: [孙七], title: [教授/博导], discipline: [机械]),
    (name: [周八], title: [副教授/博导], discipline: [机械]),
  ),
)
