#import "@preview/quan:0.2.2": quan-style as _quan-style, _quan-draw-state

#let _FONT-CLASS = (
  "simsun": "song", "nsimsun": "song", "simhei": "song", "kaiti": "song", "fangsong": "song",
  "songti sc": "song", "stsong": "song", "stsongti": "song", "kaiti sc": "song", "stfangsong": "song",
  "fandolsong": "song", "fandolhei": "song", "fandolkai": "song", "fandolfang": "song",
  "fzshusong-z01": "song", "fzhei-b01": "song", "fzkai-z03": "song", "fzfangsong-z02": "song",
  "宋体": "song", "黑体": "song", "楷体": "song", "仿宋": "song",
  "noto serif cjk sc": "wide", "noto serif cjk tc": "wide", "noto serif cjk jp": "wide", "noto serif cjk kr": "wide",
  "noto sans cjk sc": "wide", "noto sans cjk tc": "wide", "noto sans cjk jp": "wide", "noto sans cjk kr": "wide",
  "source han serif sc": "wide", "source han sans sc": "wide", "source han serif": "wide", "source han sans": "wide",
  "heiti sc": "wide", "hiragino sans gb": "wide",
  "times new roman": "latin", "times": "latin", "tex gyre termes": "latin", "libertinus serif": "latin",
  "new computer modern": "latin", "stix two text": "latin",
)

#let _MARK = "omni-tune"
#let _RULES = (
  wide: (
    ("10-99", (size: 0.72em, kern: 0em, inset: (x: 0.07em, y: 0.015em), "omni-tune": true)),
  ),
  "latin-song": (
    ("11", (kern: -0.06em, inset: (x: 0.08em, y: 0.015em), "omni-tune": true)),
    ("10,12-99", (kern: -0.05em, inset: (x: 0.08em, y: 0.015em), "omni-tune": true)),
  ),
  "latin-wide": (
    ("10-99", (size: 0.78em, kern: -0.06em, inset: (x: 0.09em, y: 0.015em), "omni-tune": true)),
  ),
)

#let _user-tuned() = {
  let cfg = _quan-draw-state.get()
  if type(cfg) != dictionary { return false }
  let keys = cfg.at("user-keys", default: ())
  let rules = cfg.at("user-rules", default: ())
  keys.len() > 0 or rules.any(r => not (type(r) == dictionary and type(r.at("style", default: none)) == dictionary and r.style.at(_MARK, default: false) == true))
}

#let _font-names(font) = {
  let list = if type(font) == array { font } else { (font,) }
  list.map(f => lower(str(if type(f) == dictionary { f.at("name", default: "") } else { f })))
}

#let pick-rules(font) = {
  let all = _font-names(font).map(n => _FONT-CLASS.at(n, default: none))
  let known = all.filter(c => c != none)
  if known.len() == 0 { return () }
  let digit = if all.first() == none and known.any(c => c != "latin") { "latin" } else { known.first() }
  if digit == "song" { return () }
  if digit == "wide" { return _RULES.wide }
  let cjk = known.find(c => c != "latin")
  if cjk == "wide" { _RULES.at("latin-wide") } else { _RULES.at("latin-song") }
}

#let tune() = context {
  if _user-tuned() { return }
  let rules = pick-rules(text.font)
  if rules.len() > 0 { _quan-style(..rules) }
}
